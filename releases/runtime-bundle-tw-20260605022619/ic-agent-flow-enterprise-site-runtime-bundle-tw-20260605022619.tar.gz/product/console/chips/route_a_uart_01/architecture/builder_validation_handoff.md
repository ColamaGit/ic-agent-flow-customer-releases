> Companion Hash Guard
- schema_version: `upstream-markdown-companion-hash-guard.v1.0`
- companion_kind: `builder_validation_handoff`
- source_hash_algo: `sha256(stable_json)`
- source_hash_bundle: `51dcceeea4ccbb7c1682ac5835ac46fc9b3f7daacccfdb688aa98ff51ba0c655`
- generated_at: `2026-05-29T22:53:35.647824+08:00`
- source_ref_hash `/customer-home/imac/Documents/Code/ic-agent-flow/chips/route_a_uart_01/architecture/builder_validation_handoff.json`: `5fdc115a1c0a403dd6ad1800fd416bbc3790892f30e310f2e4f36ac17a615e05`
- source_ref_hash `/customer-home/imac/Documents/Code/ic-agent-flow/chips/route_a_uart_01/specs/requirement_item_review_package.json`: `b4eba39bbfcdadb48878994ae005874a852d16f59e805b0c117b189da971d925`

# Builder Validation Handoff — Human Companion

> Derived human-readable companion. Canonical handoff state remains in `builder_validation_handoff.json`.

- chip_id: `route_a_uart_01`
- scope_type: `CHIP_UPSTREAM`
- handoff_status: `PENDING_HUMAN_ADJUDICATION`
- graph_draft_ref: `/customer-home/imac/Documents/Code/ic-agent-flow/chips/route_a_uart_01/architecture/architecture_graph.draft.json`
- requirement_item_ref: `/customer-home/imac/Documents/Code/ic-agent-flow/chips/route_a_uart_01/specs/requirement_item.json`
- adjudication_record_ref: ``

## Authority Boundary

- builder_may_freeze: False
- builder_may_declare_canonical: False
- validator_may_declare_freeze: False
- human_decision_required: True

## Next Agent Handoff

- Local AI/repo agent may resume only after a valid machine-readable decision record exists.
- If `handoff_status` is `PENDING_VALIDATION`, proceed to bounded graph generation/refinement and graph validation.
- If `handoff_status` is `REQUEST_MORE_EVIDENCE`, collect missing evidence and return to human adjudication.
- If `handoff_status` is `REJECTED`, do not continue this PRD v1.0 path.
- This handoff remains `CHIP_UPSTREAM`; production-run evidence starts only after freeze and generation-plan/RTL handoff are ready.
