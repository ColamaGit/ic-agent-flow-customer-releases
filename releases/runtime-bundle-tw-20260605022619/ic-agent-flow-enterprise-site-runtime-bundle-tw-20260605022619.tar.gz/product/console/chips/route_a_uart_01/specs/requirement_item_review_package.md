> Companion Hash Guard
- schema_version: `upstream-markdown-companion-hash-guard.v1.0`
- companion_kind: `requirement_item_review_package`
- source_hash_algo: `sha256(stable_json)`
- source_hash_bundle: `1d089c200399e81f804bcfe5ac2357c7305930c16355780ac1648fbba2a595f6`
- generated_at: `2026-05-29T22:53:35.644317+08:00`
- source_ref_hash `/customer-home/imac/Documents/Code/ic-agent-flow/chips/route_a_uart_01/specs/requirement_item.json`: `ef51cc1329a3951f4ec5f9ea154526a0932378b03794295a57c3679a902c909d`
- source_ref_hash `/customer-home/imac/Documents/Code/ic-agent-flow/chips/route_a_uart_01/specs/requirement_item_review_package.json`: `b4eba39bbfcdadb48878994ae005874a852d16f59e805b0c117b189da971d925`

# Human Review Companion — Requirement Item

> Derived human-readable companion. Canonical machine truth remains in JSON files.

- chip_id: `route_a_uart_01`
- scope_type: `CHIP_UPSTREAM`
- review_status: `PENDING_HUMAN_ADJUDICATION`
- intake_session_id: `INTAKE-route_a_uart_01-20260526-012148`
- requirement_item_ref: `/customer-home/imac/Documents/Code/ic-agent-flow/chips/route_a_uart_01/specs/requirement_item.json`
- builder_handoff_ref: `/customer-home/imac/Documents/Code/ic-agent-flow/chips/route_a_uart_01/architecture/builder_validation_handoff.json`

## What Human Should Judge

- Are the requirement items specific enough to be verified?
- Are ambiguity, missing evidence, and acceptance criteria still open?
- Should the decision be approve, approve_with_conditions, request_more_evidence, or reject?
- This review does not create graph validation, freeze, generation plan, RTL, or production-run evidence.

## Requirement Items

- `REQ-ROUTE_A_UART_01-001` — UART controller with RX/TX interface and reset behavior (`OPEN`)

## Candidate Decisions

- approve
- approve_with_conditions
- request_more_evidence
- reject

## Next Step

- Use the Requirement Adjudication page to write `requirement_item_adjudication_record.json`.
- After adjudication, continue in Upstream Truth Flow for graph validation, freeze, generation plan, and RTL generation handoff.
