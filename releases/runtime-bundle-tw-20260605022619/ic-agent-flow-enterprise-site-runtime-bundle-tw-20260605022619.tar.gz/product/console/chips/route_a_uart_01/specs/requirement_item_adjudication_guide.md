> Companion Hash Guard
- schema_version: `upstream-markdown-companion-hash-guard.v1.0`
- companion_kind: `requirement_item_adjudication_guide`
- source_hash_algo: `sha256(stable_json)`
- source_hash_bundle: `708d8cefbc9e72cc9fa1dd50f23a49a27f619cca06e53d75f122e59aacb63b1a`
- generated_at: `2026-05-29T22:53:35.646187+08:00`
- source_ref_hash `/customer-home/imac/Documents/Code/ic-agent-flow/chips/route_a_uart_01/specs/requirement_item_adjudication_record.template.json`: `38427034894c741ee28a74a6e94a1ed1698ce49d3295340f61e850078add5014`
- source_ref_hash `/customer-home/imac/Documents/Code/ic-agent-flow/chips/route_a_uart_01/specs/requirement_item_adjudication_record.json`: `44136fa355b3678a1146ad16f7e8649e94fb4fc21fe77e8310c060f61caaff8a`
- source_ref_hash `/customer-home/imac/Documents/Code/ic-agent-flow/chips/route_a_uart_01/specs/requirement_item_review_package.json`: `b4eba39bbfcdadb48878994ae005874a852d16f59e805b0c117b189da971d925`

# Human Adjudication Guide

> Derived human-readable companion. The authority record is `requirement_item_adjudication_record.json`.

- chip_id: `route_a_uart_01`
- scope_type: `CHIP_UPSTREAM`
- adjudication_status: `PENDING_DECISION`
- decision_outcome: `None`
- authority_signer: `None`
- needs_reentry: `False`

## Decision Options

- `approve`: requirement/spec review is sufficient to continue.
- `approve_with_conditions`: continue, but keep explicit conditions attached.
- `request_more_evidence`: stop and ask local AI/repo agent to fill missing evidence.
- `reject`: stop this upstream path.

## Suggested Conditions

- Close ambiguity for baud/frame/FIFO-threshold/CDC/throughput-latency/error-handling.
- Ensure requirement_item acceptance criteria are machine-checkable.
- Keep builder handoff status aligned with adjudication outcome.

## Recorded Conditions

- none

## Authority Boundary

- Writing adjudication records requirements/spec judgment only.
- It must not create `run_id`, `artifacts/production-runs`, graph validation, freeze, generation plan, RTL generation, or tapeout/readiness claims.
