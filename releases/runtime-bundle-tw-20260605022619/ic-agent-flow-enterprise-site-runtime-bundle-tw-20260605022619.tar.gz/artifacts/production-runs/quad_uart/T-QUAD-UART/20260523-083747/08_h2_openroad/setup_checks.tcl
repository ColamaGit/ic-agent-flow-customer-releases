read_lef "/customer-home/imac/eda/openroad-cxx17/test/Nangate45/Nangate45_tech.lef"
read_lef "/customer-home/imac/eda/openroad-cxx17/test/Nangate45/Nangate45_stdcell.lef"
read_liberty "/customer-home/imac/eda/openroad-cxx17/test/Nangate45/Nangate45_typ.lib"
read_verilog "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/h1_yosys/yosys-5b63169b3df0/top.synth.v"
link_design quad_uart_top
read_sdc "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/constraints/base.sdc"
initialize_floorplan -site FreePDK45_38x28_10R_NP_162NW_34O -die_area {0 0 200 200} -core_area {20 20 180 180}
source "/customer-home/imac/eda/openroad-cxx17/test/Nangate45/Nangate45.tracks"
place_pins -hor_layers metal3 -ver_layers metal2
repair_design -pre_placement
set_wire_rc -signal -layer metal3
set_wire_rc -clock -layer metal6
estimate_parasitics -placement
report_checks -path_delay max -format json -fields {slew capacitance}
exit
