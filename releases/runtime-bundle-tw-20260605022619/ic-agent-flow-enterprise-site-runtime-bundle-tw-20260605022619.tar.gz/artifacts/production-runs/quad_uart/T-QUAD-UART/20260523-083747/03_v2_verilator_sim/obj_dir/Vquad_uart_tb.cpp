// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Model implementation (design independent parts)

#include "Vquad_uart_tb__pch.h"

//============================================================
// Constructors

Vquad_uart_tb::Vquad_uart_tb(VerilatedContext* _vcontextp__, const char* _vcname__)
    : VerilatedModel{*_vcontextp__}
    , vlSymsp{new Vquad_uart_tb__Syms(contextp(), _vcname__, this)}
    , rootp{&(vlSymsp->TOP)}
{
    // Register model with the context
    contextp()->addModel(this);
}

Vquad_uart_tb::Vquad_uart_tb(const char* _vcname__)
    : Vquad_uart_tb(Verilated::threadContextp(), _vcname__)
{
}

//============================================================
// Destructor

Vquad_uart_tb::~Vquad_uart_tb() {
    delete vlSymsp;
}

//============================================================
// Evaluation function

#ifdef VL_DEBUG
void Vquad_uart_tb___024root___eval_debug_assertions(Vquad_uart_tb___024root* vlSelf);
#endif  // VL_DEBUG
void Vquad_uart_tb___024root___eval_static(Vquad_uart_tb___024root* vlSelf);
void Vquad_uart_tb___024root___eval_initial(Vquad_uart_tb___024root* vlSelf);
void Vquad_uart_tb___024root___eval_settle(Vquad_uart_tb___024root* vlSelf);
void Vquad_uart_tb___024root___eval(Vquad_uart_tb___024root* vlSelf);

void Vquad_uart_tb::eval_step() {
    VL_DEBUG_IF(VL_DBG_MSGF("+++++TOP Evaluate Vquad_uart_tb::eval_step\n"); );
#ifdef VL_DEBUG
    // Debug assertions
    Vquad_uart_tb___024root___eval_debug_assertions(&(vlSymsp->TOP));
#endif  // VL_DEBUG
    vlSymsp->__Vm_deleter.deleteAll();
    if (VL_UNLIKELY(!vlSymsp->__Vm_didInit)) {
        VL_DEBUG_IF(VL_DBG_MSGF("+ Initial\n"););
        Vquad_uart_tb___024root___eval_static(&(vlSymsp->TOP));
        Vquad_uart_tb___024root___eval_initial(&(vlSymsp->TOP));
        Vquad_uart_tb___024root___eval_settle(&(vlSymsp->TOP));
        vlSymsp->__Vm_didInit = true;
    }
    VL_DEBUG_IF(VL_DBG_MSGF("+ Eval\n"););
    Vquad_uart_tb___024root___eval(&(vlSymsp->TOP));
    // Evaluate cleanup
    Verilated::endOfEval(vlSymsp->__Vm_evalMsgQp);
}

//============================================================
// Events and timing
bool Vquad_uart_tb::eventsPending() { return !vlSymsp->TOP.__VdlySched.empty() && !contextp()->gotFinish(); }

uint64_t Vquad_uart_tb::nextTimeSlot() { return vlSymsp->TOP.__VdlySched.nextTimeSlot(); }

//============================================================
// Utilities

const char* Vquad_uart_tb::name() const {
    return vlSymsp->name();
}

//============================================================
// Invoke final blocks

void Vquad_uart_tb___024root___eval_final(Vquad_uart_tb___024root* vlSelf);

VL_ATTR_COLD void Vquad_uart_tb::final() {
    contextp()->executingFinal(true);
    Vquad_uart_tb___024root___eval_final(&(vlSymsp->TOP));
    contextp()->executingFinal(false);
}

//============================================================
// Implementations of abstract methods from VerilatedModel

const char* Vquad_uart_tb::hierName() const { return vlSymsp->name(); }
const char* Vquad_uart_tb::modelName() const { return "Vquad_uart_tb"; }
unsigned Vquad_uart_tb::threads() const { return 1; }
void Vquad_uart_tb::prepareClone() const { contextp()->prepareClone(); }
void Vquad_uart_tb::atClone() const {
    contextp()->threadPoolpOnClone();
}
