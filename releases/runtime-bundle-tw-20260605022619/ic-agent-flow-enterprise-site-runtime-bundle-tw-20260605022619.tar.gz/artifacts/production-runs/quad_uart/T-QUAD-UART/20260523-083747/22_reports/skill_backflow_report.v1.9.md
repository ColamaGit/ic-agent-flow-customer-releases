# Skill Backflow Report v1.9

- chip_id: `quad_uart`
- run_id: `T-QUAD-UART`
- execution: `20260523-083747`
- report_family: `skill_backflow_report`
- report_version: `v1.9`
- generated_at: `2026-05-23T08:38:09.862174+08:00`

## Summary

- verdict: `PASS`
- rows_total: `14`
- pass: `0`
- warn: `0`
- blocked: `0`
- not_available: `14`

## Section Status

| section | row_id | status | notes | evidence_count |
|---|---|---|---|---|
| skill_routing_and_invocation | skill_v1_verilator_lint | NOT_AVAILABLE | skill_type=execution_skill | 3 |
| skill_routing_and_invocation | skill_v2_verilator_sim | NOT_AVAILABLE | skill_type=execution_skill | 3 |
| skill_routing_and_invocation | skill_v3_cdc_rdc | NOT_AVAILABLE | skill_type=execution_skill | 3 |
| skill_routing_and_invocation | skill_v3b_cdc_signoff_lite | NOT_AVAILABLE | skill_type=execution_skill | 3 |
| skill_routing_and_invocation | skill_h1_yosys | NOT_AVAILABLE | skill_type=execution_skill | 3 |
| skill_routing_and_invocation | skill_v4_yosys_lec | NOT_AVAILABLE | skill_type=execution_skill | 3 |
| skill_routing_and_invocation | skill_h2_openroad | NOT_AVAILABLE | skill_type=execution_skill | 3 |
| skill_routing_and_invocation | skill_h4_klayout | NOT_AVAILABLE | skill_type=execution_skill | 3 |
| skill_routing_and_invocation | skill_h3_netgen | NOT_AVAILABLE | skill_type=execution_skill | 3 |
| skill_routing_and_invocation | skill_route_b_b0_contract_materialization | NOT_AVAILABLE | skill_type=decision_tree_skill | 3 |
| skill_routing_and_invocation | skill_v1_0_upstream_truth_chain | NOT_AVAILABLE | skill_type=governance_skill | 3 |
| skill_routing_and_invocation | skill_v1_3_subject_binding_chain | NOT_AVAILABLE | skill_type=governance_skill | 3 |
| skill_routing_and_invocation | skill_v1_9_skill_usage_traceability | NOT_AVAILABLE | skill_type=decision_tree_skill | 3 |
| skill_routing_and_invocation | skill_v1_1_v1_2_readiness_compile_chain | NOT_AVAILABLE | skill_type=governance_skill | 3 |

## Action Items

- action_item_count: `0`

Canonical truth remains governed JSON objects and evidence references.
