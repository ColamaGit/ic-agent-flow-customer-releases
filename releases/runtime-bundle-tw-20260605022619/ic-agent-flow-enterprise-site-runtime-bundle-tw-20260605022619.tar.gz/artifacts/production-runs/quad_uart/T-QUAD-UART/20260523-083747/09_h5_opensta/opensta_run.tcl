read_lef "/customer-home/imac/eda/openroad-cxx17/test/Nangate45/Nangate45_tech.lef"
read_lef "/customer-home/imac/eda/openroad-cxx17/test/Nangate45/Nangate45_stdcell.lef"
read_liberty "/customer-home/imac/eda/openroad-cxx17/test/Nangate45/Nangate45_typ.lib"
read_verilog /customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/h1_yosys/yosys-5b63169b3df0/top.synth.v
link_design quad_uart_top
read_sdc "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/constraints/base.sdc"
report_worst_slack -max > /customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/h5_opensta/timing_summary.rpt
report_checks -path_delay max -group_count 20 > /customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/h5_opensta/timing_checks.rpt
report_checks -unconstrained -format summary > /customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/h5_opensta/unconstrained_checks.rpt
report_check_types -violators -verbose -format slack_only -max_delay -min_delay -max_slew -min_slew -max_fanout -min_fanout -max_capacitance -min_capacitance -min_pulse_width -min_period -max_skew > /customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/h5_opensta/check_types.rpt
puts "OPENSTA_H5_PASS"
exit
