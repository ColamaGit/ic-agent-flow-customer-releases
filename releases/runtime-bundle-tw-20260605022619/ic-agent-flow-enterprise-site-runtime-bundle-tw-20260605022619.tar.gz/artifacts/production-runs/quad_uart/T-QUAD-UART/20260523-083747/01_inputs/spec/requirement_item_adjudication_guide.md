> Companion Hash Guard
- schema_version: `upstream-markdown-companion-hash-guard.v1.0`
- companion_kind: `requirement_item_adjudication_guide`
- source_hash_algo: `sha256(stable_json)`
- source_hash_bundle: `f6f8b6e9b81cab08d239218cccb72fb65ffe554bed71c4937f7cc9fd11f84c02`
- generated_at: `2026-05-21T07:20:00.637535+08:00`
- source_ref_hash `/customer-home/imac/Documents/Code/ic-agent-flow/chips/quad_uart/specs/requirement_item_adjudication_record.template.json`: `b0580d9f0c2a3d2cecd8515eb16785c3e53149fd3d4fee6822c9e70009c0f821`
- source_ref_hash `/customer-home/imac/Documents/Code/ic-agent-flow/chips/quad_uart/specs/requirement_item_adjudication_record.json`: `7d5a62932f75d053469f37185e330a4aca9d279f3c4e19bb85ebdca4694e1a71`
- source_ref_hash `/customer-home/imac/Documents/Code/ic-agent-flow/chips/quad_uart/specs/requirement_item_review_package.json`: `b3586fa98c8929e981768e8fcbcbc1eb87bef4f022360abcff16004af0efca88`

# Human Adjudication Guide

> Derived human-readable companion. The authority record is `requirement_item_adjudication_record.json`.

- chip_id: `quad_uart`
- scope_type: `CHIP_UPSTREAM`
- adjudication_status: `DECISION_RECORDED`
- decision_outcome: `approve`
- authority_signer: `colama.wang@icaf.com`
- needs_reentry: `False`

## Decision Options

- `approve`: requirement/spec review is sufficient to continue.
- `approve_with_conditions`: continue, but keep explicit conditions attached.
- `request_more_evidence`: stop and ask local AI/repo agent to fill missing evidence.
- `reject`: stop this upstream path.

## Suggested Conditions

- Close ambiguity for baud/frame/FIFO-threshold/CDC/throughput-latency/error-handling.
- Ensure requirement_item acceptance criteria are machine-checkable.
- Keep builder handoff status aligned with adjudication outcome.

## Recorded Conditions

- none

## Authority Boundary

- Writing adjudication records requirements/spec judgment only.
- It must not create `run_id`, `artifacts/production-runs`, graph validation, freeze, generation plan, RTL generation, or tapeout/readiness claims.
