// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vquad_uart_tb.h for the primary calling header

#include "Vquad_uart_tb__pch.h"

void Vquad_uart_tb___024root___timing_ready(Vquad_uart_tb___024root* vlSelf);

VL_ATTR_COLD void Vquad_uart_tb___024root___eval_static(Vquad_uart_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquad_uart_tb___024root___eval_static\n"); );
    Vquad_uart_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    const uint64_t __VscopeHash = VL_MURMUR64_HASH(vlSelf->vlNamep);
    vlSelf->quad_uart_tb__DOT__unnamedblk2__DOT__unnamedblk3__DOT__read_back = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 4019911447833088964ull);
    vlSelfRef.__Vtrigprevexpr___TOP__quad_uart_tb__DOT__pclk__0 
        = vlSelfRef.quad_uart_tb__DOT__pclk;
    vlSelfRef.__Vtrigprevexpr___TOP__quad_uart_tb__DOT__presetn__0 
        = vlSelfRef.quad_uart_tb__DOT__presetn;
    Vquad_uart_tb___024root___timing_ready(vlSelf);
    do {
        vlSelfRef.__VactTriggeredAcc[vlSelfRef.__Vi] 
            = vlSelfRef.__VactTriggered[vlSelfRef.__Vi];
        vlSelfRef.__Vi = ((IData)(1U) + vlSelfRef.__Vi);
    } while ((0U >= vlSelfRef.__Vi));
}

VL_ATTR_COLD void Vquad_uart_tb___024root___eval_static__TOP(Vquad_uart_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquad_uart_tb___024root___eval_static__TOP\n"); );
    Vquad_uart_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    const uint64_t __VscopeHash = VL_MURMUR64_HASH(vlSelf->vlNamep);
    vlSelf->quad_uart_tb__DOT__unnamedblk2__DOT__unnamedblk3__DOT__read_back = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 4019911447833088964ull);
}

VL_ATTR_COLD void Vquad_uart_tb___024root___eval_initial__TOP(Vquad_uart_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquad_uart_tb___024root___eval_initial__TOP\n"); );
    Vquad_uart_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1U & (~ (IData)(vlSelfRef.quad_uart_tb__DOT____Vtogcov__pready)))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 170, 1U, vlSelfRef.quad_uart_tb__DOT____Vtogcov__pready);
        vlSelfRef.quad_uart_tb__DOT____Vtogcov__pready = 1U;
    }
    if (vlSelfRef.quad_uart_tb__DOT____Vtogcov__pslverr) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 172, 0U, vlSelfRef.quad_uart_tb__DOT____Vtogcov__pslverr);
        vlSelfRef.quad_uart_tb__DOT____Vtogcov__pslverr = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__pready)))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 730, 1U, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__pready);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__pready = 1U;
    }
    if (vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__pslverr) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 732, 0U, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__pslverr);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__pslverr = 0U;
    }
}

VL_ATTR_COLD void Vquad_uart_tb___024root___eval_final(Vquad_uart_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquad_uart_tb___024root___eval_final\n"); );
    Vquad_uart_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vquad_uart_tb___024root___dump_triggers__stl(const VlUnpacked<QData/*63:0*/, 1> &triggers, const std::string &tag);
#endif  // VL_DEBUG
VL_ATTR_COLD bool Vquad_uart_tb___024root___eval_phase__stl(Vquad_uart_tb___024root* vlSelf);

VL_ATTR_COLD void Vquad_uart_tb___024root___eval_settle(Vquad_uart_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquad_uart_tb___024root___eval_settle\n"); );
    Vquad_uart_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    IData/*31:0*/ __VstlIterCount;
    // Body
    __VstlIterCount = 0U;
    vlSelfRef.__VstlFirstIteration = 1U;
    do {
        if (VL_UNLIKELY(((0x00002710U < __VstlIterCount)))) {
#ifdef VL_DEBUG
            Vquad_uart_tb___024root___dump_triggers__stl(vlSelfRef.__VstlTriggered, "stl"s);
#endif
            VL_FATAL_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 3, "", "DIDNOTCONVERGE: Settle region did not converge after '--converge-limit' of 10000 tries");
        }
        __VstlIterCount = ((IData)(1U) + __VstlIterCount);
        vlSelfRef.__VstlPhaseResult = Vquad_uart_tb___024root___eval_phase__stl(vlSelf);
        vlSelfRef.__VstlFirstIteration = 0U;
    } while (vlSelfRef.__VstlPhaseResult);
}

VL_ATTR_COLD void Vquad_uart_tb___024root___eval_triggers_vec__stl(Vquad_uart_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquad_uart_tb___024root___eval_triggers_vec__stl\n"); );
    Vquad_uart_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__VstlTriggered[0U] = ((0xfffffffffffffffeULL 
                                      & vlSelfRef.__VstlTriggered[0U]) 
                                     | (IData)((IData)(vlSelfRef.__VstlFirstIteration)));
}

VL_ATTR_COLD bool Vquad_uart_tb___024root___trigger_anySet__stl(const VlUnpacked<QData/*63:0*/, 1> &in);

#ifdef VL_DEBUG
VL_ATTR_COLD void Vquad_uart_tb___024root___dump_triggers__stl(const VlUnpacked<QData/*63:0*/, 1> &triggers, const std::string &tag) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquad_uart_tb___024root___dump_triggers__stl\n"); );
    // Body
    if ((1U & (~ (IData)(Vquad_uart_tb___024root___trigger_anySet__stl(triggers))))) {
        VL_DBG_MSGS("         No '" + tag + "' region triggers active\n");
    }
    if ((1U & (IData)(triggers[0U]))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 0 is active: Internal 'stl' trigger - first iteration\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD bool Vquad_uart_tb___024root___trigger_anySet__stl(const VlUnpacked<QData/*63:0*/, 1> &in) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquad_uart_tb___024root___trigger_anySet__stl\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        if (in[n]) {
            return (1U);
        }
        n = ((IData)(1U) + n);
    } while ((1U > n));
    return (0U);
}

VL_ATTR_COLD void Vquad_uart_tb___024root___stl_sequent__TOP__0(Vquad_uart_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquad_uart_tb___024root___stl_sequent__TOP__0\n"); );
    Vquad_uart_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_access;
    quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_access = 0;
    // Body
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__pclk) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT____Vtogcov__pclk))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 0, vlSelfRef.quad_uart_tb__DOT__pclk, vlSelfRef.quad_uart_tb__DOT____Vtogcov__pclk);
        vlSelfRef.quad_uart_tb__DOT____Vtogcov__pclk 
            = vlSelfRef.quad_uart_tb__DOT__pclk;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__presetn) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT____Vtogcov__presetn))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2, vlSelfRef.quad_uart_tb__DOT__presetn, vlSelfRef.quad_uart_tb__DOT____Vtogcov__presetn);
        vlSelfRef.quad_uart_tb__DOT____Vtogcov__presetn 
            = vlSelfRef.quad_uart_tb__DOT__presetn;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__psel) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT____Vtogcov__psel))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 4, vlSelfRef.quad_uart_tb__DOT__psel, vlSelfRef.quad_uart_tb__DOT____Vtogcov__psel);
        vlSelfRef.quad_uart_tb__DOT____Vtogcov__psel 
            = vlSelfRef.quad_uart_tb__DOT__psel;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__penable) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT____Vtogcov__penable))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 6, vlSelfRef.quad_uart_tb__DOT__penable, vlSelfRef.quad_uart_tb__DOT____Vtogcov__penable);
        vlSelfRef.quad_uart_tb__DOT____Vtogcov__penable 
            = vlSelfRef.quad_uart_tb__DOT__penable;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__pwrite) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT____Vtogcov__pwrite))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 8, vlSelfRef.quad_uart_tb__DOT__pwrite, vlSelfRef.quad_uart_tb__DOT____Vtogcov__pwrite);
        vlSelfRef.quad_uart_tb__DOT____Vtogcov__pwrite 
            = vlSelfRef.quad_uart_tb__DOT__pwrite;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__paddr) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT____Vtogcov__paddr))) {
        VL_COV_TOGGLE_CHG_ST_I(12, vlSymsp->__Vcoverage + 10, vlSelfRef.quad_uart_tb__DOT__paddr, vlSelfRef.quad_uart_tb__DOT____Vtogcov__paddr);
        vlSelfRef.quad_uart_tb__DOT____Vtogcov__paddr 
            = vlSelfRef.quad_uart_tb__DOT__paddr;
    }
    if ((vlSelfRef.quad_uart_tb__DOT__pwdata ^ vlSelfRef.quad_uart_tb__DOT____Vtogcov__pwdata)) {
        VL_COV_TOGGLE_CHG_ST_I(32, vlSymsp->__Vcoverage + 34, vlSelfRef.quad_uart_tb__DOT__pwdata, vlSelfRef.quad_uart_tb__DOT____Vtogcov__pwdata);
        vlSelfRef.quad_uart_tb__DOT____Vtogcov__pwdata 
            = vlSelfRef.quad_uart_tb__DOT__pwdata;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT____Vtogcov__uart_rx))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 98, vlSelfRef.quad_uart_tb__DOT__uart_rx, vlSelfRef.quad_uart_tb__DOT____Vtogcov__uart_rx);
        vlSelfRef.quad_uart_tb__DOT____Vtogcov__uart_rx 
            = vlSelfRef.quad_uart_tb__DOT__uart_rx;
    }
    if ((vlSelfRef.quad_uart_tb__DOT__prdata ^ vlSelfRef.quad_uart_tb__DOT____Vtogcov__prdata)) {
        VL_COV_TOGGLE_CHG_ST_I(32, vlSymsp->__Vcoverage + 106, vlSelfRef.quad_uart_tb__DOT__prdata, vlSelfRef.quad_uart_tb__DOT____Vtogcov__prdata);
        vlSelfRef.quad_uart_tb__DOT____Vtogcov__prdata 
            = vlSelfRef.quad_uart_tb__DOT__prdata;
    }
    if ((vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg0 
         ^ vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_cfg0)) {
        VL_COV_TOGGLE_CHG_ST_I(32, vlSymsp->__Vcoverage + 210, vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg0, vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_cfg0);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_cfg0 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg0;
    }
    if ((vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg1 
         ^ vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_cfg1)) {
        VL_COV_TOGGLE_CHG_ST_I(32, vlSymsp->__Vcoverage + 274, vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg1, vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_cfg1);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_cfg1 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg1;
    }
    if ((vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg2 
         ^ vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_cfg2)) {
        VL_COV_TOGGLE_CHG_ST_I(32, vlSymsp->__Vcoverage + 338, vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg2, vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_cfg2);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_cfg2 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg2;
    }
    if ((vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg3 
         ^ vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_cfg3)) {
        VL_COV_TOGGLE_CHG_ST_I(32, vlSymsp->__Vcoverage + 402, vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg3, vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_cfg3);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_cfg3 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg3;
    }
    if ((vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx0 
         ^ vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_tx0)) {
        VL_COV_TOGGLE_CHG_ST_I(32, vlSymsp->__Vcoverage + 466, vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx0, vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_tx0);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_tx0 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx0;
    }
    if ((vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx1 
         ^ vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_tx1)) {
        VL_COV_TOGGLE_CHG_ST_I(32, vlSymsp->__Vcoverage + 530, vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx1, vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_tx1);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_tx1 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx1;
    }
    if ((vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx2 
         ^ vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_tx2)) {
        VL_COV_TOGGLE_CHG_ST_I(32, vlSymsp->__Vcoverage + 594, vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx2, vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_tx2);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_tx2 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx2;
    }
    if ((vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx3 
         ^ vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_tx3)) {
        VL_COV_TOGGLE_CHG_ST_I(32, vlSymsp->__Vcoverage + 658, vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx3, vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_tx3);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_tx3 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx3;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__tx_fire))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 722, vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire, vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__tx_fire);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__tx_fire 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire;
    }
    if ((1U & ((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire) 
               ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__tx_fire)))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 772, vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__tx_fire);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__tx_fire 
            = (1U & (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire));
    }
    if ((1U & ((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
               ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__uart_rx)))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 774, vlSelfRef.quad_uart_tb__DOT__uart_rx, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__uart_rx);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__uart_rx 
            = (1U & (IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx));
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch0__uart_tx) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__uart_tx))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 776, vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch0__uart_tx, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__uart_tx);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__uart_tx 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch0__uart_tx;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch0__irq) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__irq))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 778, vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch0__irq, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__irq);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__irq 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch0__irq;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT__rx_d) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__rx_d))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 780, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT__rx_d, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__rx_d);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__rx_d 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT__rx_d;
    }
    if ((1U & (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire) 
                >> 1U) ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__tx_fire)))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 791, 
                               ((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire) 
                                >> 1U), vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__tx_fire);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__tx_fire 
            = (1U & ((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire) 
                     >> 1U));
    }
    if ((1U & (((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
                >> 1U) ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__uart_rx)))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 793, 
                               ((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
                                >> 1U), vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__uart_rx);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__uart_rx 
            = (1U & ((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
                     >> 1U));
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch1__uart_tx) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__uart_tx))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 795, vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch1__uart_tx, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__uart_tx);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__uart_tx 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch1__uart_tx;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch1__irq) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__irq))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 797, vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch1__irq, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__irq);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__irq 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch1__irq;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT__rx_d) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__rx_d))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 799, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT__rx_d, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__rx_d);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__rx_d 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT__rx_d;
    }
    if ((1U & (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire) 
                >> 2U) ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__tx_fire)))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 810, 
                               ((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire) 
                                >> 2U), vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__tx_fire);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__tx_fire 
            = (1U & ((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire) 
                     >> 2U));
    }
    if ((1U & (((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
                >> 2U) ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__uart_rx)))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 812, 
                               ((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
                                >> 2U), vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__uart_rx);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__uart_rx 
            = (1U & ((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
                     >> 2U));
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch2__uart_tx) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__uart_tx))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 814, vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch2__uart_tx, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__uart_tx);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__uart_tx 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch2__uart_tx;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch2__irq) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__irq))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 816, vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch2__irq, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__irq);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__irq 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch2__irq;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT__rx_d) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__rx_d))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 818, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT__rx_d, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__rx_d);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__rx_d 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT__rx_d;
    }
    if ((IData)((((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire) 
                  >> 3U) ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__tx_fire)))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 829, 
                               ((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire) 
                                >> 3U), vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__tx_fire);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__tx_fire 
            = (1U & ((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire) 
                     >> 3U));
    }
    if ((IData)((((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
                  >> 3U) ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__uart_rx)))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 831, 
                               ((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
                                >> 3U), vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__uart_rx);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__uart_rx 
            = (1U & ((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
                     >> 3U));
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch3__uart_tx) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__uart_tx))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 833, vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch3__uart_tx, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__uart_tx);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__uart_tx 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch3__uart_tx;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch3__irq) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__irq))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 835, vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch3__irq, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__irq);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__irq 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch3__irq;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT__rx_d) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__rx_d))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 837, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT__rx_d, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__rx_d);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__rx_d 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT__rx_d;
    }
    vlSelfRef.quad_uart_tb__DOT__uart_tx = ((((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch3__uart_tx) 
                                              << 3U) 
                                             | ((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch2__uart_tx) 
                                                << 2U)) 
                                            | (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch1__uart_tx) 
                                                << 1U) 
                                               | (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch0__uart_tx)));
    vlSelfRef.quad_uart_tb__DOT__irq = ((((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch3__irq) 
                                          << 3U) | 
                                         ((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch2__irq) 
                                          << 2U)) | 
                                        (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch1__irq) 
                                          << 1U) | (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch0__irq)));
    quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_access 
        = ((IData)(vlSelfRef.quad_uart_tb__DOT__psel) 
           & (IData)(vlSelfRef.quad_uart_tb__DOT__penable));
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__uart_tx) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT____Vtogcov__uart_tx))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 174, vlSelfRef.quad_uart_tb__DOT__uart_tx, vlSelfRef.quad_uart_tb__DOT____Vtogcov__uart_tx);
        vlSelfRef.quad_uart_tb__DOT____Vtogcov__uart_tx 
            = vlSelfRef.quad_uart_tb__DOT__uart_tx;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__irq) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT____Vtogcov__irq))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 182, vlSelfRef.quad_uart_tb__DOT__irq, vlSelfRef.quad_uart_tb__DOT____Vtogcov__irq);
        vlSelfRef.quad_uart_tb__DOT____Vtogcov__irq 
            = vlSelfRef.quad_uart_tb__DOT__irq;
    }
    if (((IData)(quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_access) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__apb_access))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 734, quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_access, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__apb_access);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__apb_access 
            = quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_access;
    }
    vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_wr 
        = ((IData)(vlSelfRef.quad_uart_tb__DOT__pwrite) 
           & (IData)(quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_access));
    vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_rd 
        = ((~ (IData)(vlSelfRef.quad_uart_tb__DOT__pwrite)) 
           & (IData)(quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_access));
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_wr) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__apb_wr))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 736, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_wr, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__apb_wr);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__apb_wr 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_wr;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_rd) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__apb_rd))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 738, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_rd, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__apb_rd);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__apb_rd 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_rd;
    }
}

VL_ATTR_COLD void Vquad_uart_tb___024root___eval_stl(Vquad_uart_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquad_uart_tb___024root___eval_stl\n"); );
    Vquad_uart_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1ULL & vlSelfRef.__VstlTriggered[0U])) {
        Vquad_uart_tb___024root___stl_sequent__TOP__0(vlSelf);
    }
}

VL_ATTR_COLD bool Vquad_uart_tb___024root___eval_phase__stl(Vquad_uart_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquad_uart_tb___024root___eval_phase__stl\n"); );
    Vquad_uart_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ __VstlExecute;
    // Body
    Vquad_uart_tb___024root___eval_triggers_vec__stl(vlSelf);
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        Vquad_uart_tb___024root___dump_triggers__stl(vlSelfRef.__VstlTriggered, "stl"s);
    }
#endif
    __VstlExecute = Vquad_uart_tb___024root___trigger_anySet__stl(vlSelfRef.__VstlTriggered);
    if (__VstlExecute) {
        Vquad_uart_tb___024root___eval_stl(vlSelf);
    }
    return (__VstlExecute);
}

bool Vquad_uart_tb___024root___trigger_anySet__act(const VlUnpacked<QData/*63:0*/, 1> &in);

#ifdef VL_DEBUG
VL_ATTR_COLD void Vquad_uart_tb___024root___dump_triggers__act(const VlUnpacked<QData/*63:0*/, 1> &triggers, const std::string &tag) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquad_uart_tb___024root___dump_triggers__act\n"); );
    // Body
    if ((1U & (~ (IData)(Vquad_uart_tb___024root___trigger_anySet__act(triggers))))) {
        VL_DBG_MSGS("         No '" + tag + "' region triggers active\n");
    }
    if ((1U & (IData)(triggers[0U]))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 0 is active: @(posedge quad_uart_tb.pclk)\n");
    }
    if ((1U & (IData)((triggers[0U] >> 1U)))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 1 is active: @(negedge quad_uart_tb.presetn)\n");
    }
    if ((1U & (IData)((triggers[0U] >> 2U)))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 2 is active: @([true] __VdlySched.awaitingCurrentTime())\n");
    }
    if ((1U & (IData)((triggers[0U] >> 3U)))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 3 is active: @(negedge quad_uart_tb.pclk)\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD void Vquad_uart_tb___024root___ctor_var_reset(Vquad_uart_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquad_uart_tb___024root___ctor_var_reset\n"); );
    Vquad_uart_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    const uint64_t __VscopeHash = VL_MURMUR64_HASH(vlSelf->vlNamep);
    vlSelf->quad_uart_tb__DOT__pclk = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 3637641624986778667ull);
    vlSelf->quad_uart_tb__DOT__presetn = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 17989089105868752889ull);
    vlSelf->quad_uart_tb__DOT__psel = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 6273683013134996368ull);
    vlSelf->quad_uart_tb__DOT__penable = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 8244020611870110201ull);
    vlSelf->quad_uart_tb__DOT__pwrite = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 7175839933637209889ull);
    vlSelf->quad_uart_tb__DOT__paddr = VL_SCOPED_RAND_RESET_I(12, __VscopeHash, 98108414122787357ull);
    vlSelf->quad_uart_tb__DOT__pwdata = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 2128322158108862097ull);
    vlSelf->quad_uart_tb__DOT__uart_rx = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 12106253118568085420ull);
    vlSelf->quad_uart_tb__DOT__prdata = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 3714102872025080425ull);
    vlSelf->quad_uart_tb__DOT__uart_tx = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 1135624369830152090ull);
    vlSelf->quad_uart_tb__DOT__irq = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 5955863346619581081ull);
    vlSelf->quad_uart_tb__DOT____Vtogcov__pclk = 0;
    vlSelf->quad_uart_tb__DOT____Vtogcov__presetn = 0;
    vlSelf->quad_uart_tb__DOT____Vtogcov__psel = 0;
    vlSelf->quad_uart_tb__DOT____Vtogcov__penable = 0;
    vlSelf->quad_uart_tb__DOT____Vtogcov__pwrite = 0;
    vlSelf->quad_uart_tb__DOT____Vtogcov__paddr = 0;
    vlSelf->quad_uart_tb__DOT____Vtogcov__pwdata = 0;
    vlSelf->quad_uart_tb__DOT____Vtogcov__uart_rx = 0;
    vlSelf->quad_uart_tb__DOT____Vtogcov__prdata = 0;
    vlSelf->quad_uart_tb__DOT____Vtogcov__pready = 0;
    vlSelf->quad_uart_tb__DOT____Vtogcov__pslverr = 0;
    vlSelf->quad_uart_tb__DOT____Vtogcov__uart_tx = 0;
    vlSelf->quad_uart_tb__DOT____Vtogcov__irq = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT__ch_cfg0 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 13651349147996586907ull);
    vlSelf->quad_uart_tb__DOT__dut__DOT__ch_cfg1 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 4684383978072019262ull);
    vlSelf->quad_uart_tb__DOT__dut__DOT__ch_cfg2 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 3091801644377703451ull);
    vlSelf->quad_uart_tb__DOT__dut__DOT__ch_cfg3 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 3809261730125033107ull);
    vlSelf->quad_uart_tb__DOT__dut__DOT__ch_tx0 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 14278126778835273064ull);
    vlSelf->quad_uart_tb__DOT__dut__DOT__ch_tx1 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 406346468269406721ull);
    vlSelf->quad_uart_tb__DOT__dut__DOT__ch_tx2 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 14277605685823095528ull);
    vlSelf->quad_uart_tb__DOT__dut__DOT__ch_tx3 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 6579147911367089433ull);
    vlSelf->quad_uart_tb__DOT__dut__DOT__tx_fire = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 12158371574624100939ull);
    vlSelf->quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch0__irq = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch0__uart_tx = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch1__irq = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch1__uart_tx = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch2__irq = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch2__uart_tx = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch3__irq = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch3__uart_tx = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_cfg0 = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_cfg1 = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_cfg2 = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_cfg3 = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_tx0 = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_tx1 = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_tx2 = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_tx3 = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT____Vtogcov__tx_fire = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_wr = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 11658157647166443110ull);
    vlSelf->quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_rd = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 11978152071675580355ull);
    vlSelf->quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__pready = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__pslverr = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__apb_access = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__apb_wr = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__apb_rd = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT__rx_d = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 16255502266256957420ull);
    vlSelf->quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__tx_fire = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__uart_rx = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__uart_tx = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__irq = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__rx_d = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT__rx_d = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 4047524716274604291ull);
    vlSelf->quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__tx_fire = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__uart_rx = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__uart_tx = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__irq = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__rx_d = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT__rx_d = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 17500886869794186026ull);
    vlSelf->quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__tx_fire = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__uart_rx = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__uart_tx = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__irq = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__rx_d = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT__rx_d = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 6523139259776965587ull);
    vlSelf->quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__tx_fire = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__uart_rx = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__uart_tx = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__irq = 0;
    vlSelf->quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__rx_d = 0;
    for (int __Vi0 = 0; __Vi0 < 1; ++__Vi0) {
        vlSelf->__VstlTriggered[__Vi0] = 0;
    }
    for (int __Vi0 = 0; __Vi0 < 1; ++__Vi0) {
        vlSelf->__VactTriggered[__Vi0] = 0;
    }
    for (int __Vi0 = 0; __Vi0 < 1; ++__Vi0) {
        vlSelf->__VactTriggeredAcc[__Vi0] = 0;
    }
    vlSelf->__Vtrigprevexpr___TOP__quad_uart_tb__DOT__pclk__0 = 0;
    vlSelf->__Vtrigprevexpr___TOP__quad_uart_tb__DOT__presetn__0 = 0;
    for (int __Vi0 = 0; __Vi0 < 1; ++__Vi0) {
        vlSelf->__VnbaTriggered[__Vi0] = 0;
    }
    vlSelf->__Vi = 0;
}

VL_ATTR_COLD void Vquad_uart_tb___024root___configure_coverage(Vquad_uart_tb___024root* vlSelf, bool first) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquad_uart_tb___024root___configure_coverage\n"); );
    Vquad_uart_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    (void)first;  // Prevent unused variable warning
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[0]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 4, 9, ".quad_uart_tb", "v_toggle/quad_uart_tb", "pclk");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[2]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 5, 9, ".quad_uart_tb", "v_toggle/quad_uart_tb", "presetn");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[4]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 6, 9, ".quad_uart_tb", "v_toggle/quad_uart_tb", "psel");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[6]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 7, 9, ".quad_uart_tb", "v_toggle/quad_uart_tb", "penable");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[8]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 8, 9, ".quad_uart_tb", "v_toggle/quad_uart_tb", "pwrite");
    vlSelf->__vlCoverToggleInsert(0, 11, 1, &(vlSymsp->__Vcoverage[10]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 9, 16, ".quad_uart_tb", "v_toggle/quad_uart_tb", "paddr");
    vlSelf->__vlCoverToggleInsert(0, 31, 1, &(vlSymsp->__Vcoverage[34]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 10, 16, ".quad_uart_tb", "v_toggle/quad_uart_tb", "pwdata");
    vlSelf->__vlCoverToggleInsert(0, 3, 1, &(vlSymsp->__Vcoverage[98]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 11, 15, ".quad_uart_tb", "v_toggle/quad_uart_tb", "uart_rx");
    vlSelf->__vlCoverToggleInsert(0, 31, 1, &(vlSymsp->__Vcoverage[106]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 12, 15, ".quad_uart_tb", "v_toggle/quad_uart_tb", "prdata");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[170]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 13, 8, ".quad_uart_tb", "v_toggle/quad_uart_tb", "pready");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[172]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 14, 8, ".quad_uart_tb", "v_toggle/quad_uart_tb", "pslverr");
    vlSelf->__vlCoverToggleInsert(0, 3, 1, &(vlSymsp->__Vcoverage[174]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 15, 14, ".quad_uart_tb", "v_toggle/quad_uart_tb", "uart_tx");
    vlSelf->__vlCoverToggleInsert(0, 3, 1, &(vlSymsp->__Vcoverage[182]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 16, 14, ".quad_uart_tb", "v_toggle/quad_uart_tb", "irq");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[190]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 34, 20, ".quad_uart_tb", "v_expr/quad_uart_tb", "(pclk==0) => 1", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[191]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 34, 20, ".quad_uart_tb", "v_expr/quad_uart_tb", "(pclk==1) => 0", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[192]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 34, 3, ".quad_uart_tb", "v_line/quad_uart_tb", "block", "34");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[193]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 38, 8, ".quad_uart_tb", "v_line/quad_uart_tb", "case", "38");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[194]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 39, 8, ".quad_uart_tb", "v_line/quad_uart_tb", "case", "39");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[195]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 40, 8, ".quad_uart_tb", "v_line/quad_uart_tb", "case", "40");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[196]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 41, 7, ".quad_uart_tb", "v_line/quad_uart_tb", "case", "41");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[197]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 36, 29, ".quad_uart_tb", "v_line/quad_uart_tb", "block", "36-37");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[198]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 47, 8, ".quad_uart_tb", "v_line/quad_uart_tb", "case", "47");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[199]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 48, 8, ".quad_uart_tb", "v_line/quad_uart_tb", "case", "48");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[200]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 49, 8, ".quad_uart_tb", "v_line/quad_uart_tb", "case", "49");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[201]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 50, 7, ".quad_uart_tb", "v_line/quad_uart_tb", "case", "50");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[202]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 45, 29, ".quad_uart_tb", "v_line/quad_uart_tb", "block", "45-46");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[203]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 115, 5, ".quad_uart_tb", "v_line/quad_uart_tb", "block", "115");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[204]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 113, 18, ".quad_uart_tb", "v_line/quad_uart_tb", "block", "113-116");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[205]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 130, 5, ".quad_uart_tb", "v_line/quad_uart_tb", "block", "130");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[206]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 136, 36, ".quad_uart_tb", "v_expr/quad_uart_tb", "(((i % 32'sh2) == 32'sh0)==1) => 1", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[207]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 136, 36, ".quad_uart_tb", "v_expr/quad_uart_tb", "(((i % 32'sh2) == 32'sh0)==0) => 0", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[208]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 134, 5, ".quad_uart_tb", "v_line/quad_uart_tb", "block", "134-137");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[209]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 188, 5, ".quad_uart_tb", "v_line/quad_uart_tb", "block", "188");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[0]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/quad_uart_top.v", 2, 16, ".quad_uart_tb.dut", "v_toggle/quad_uart_top", "pclk");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[2]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/quad_uart_top.v", 3, 16, ".quad_uart_tb.dut", "v_toggle/quad_uart_top", "presetn");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[4]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/quad_uart_top.v", 4, 16, ".quad_uart_tb.dut", "v_toggle/quad_uart_top", "psel");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[6]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/quad_uart_top.v", 5, 16, ".quad_uart_tb.dut", "v_toggle/quad_uart_top", "penable");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[8]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/quad_uart_top.v", 6, 16, ".quad_uart_tb.dut", "v_toggle/quad_uart_top", "pwrite");
    vlSelf->__vlCoverToggleInsert(0, 11, 1, &(vlSymsp->__Vcoverage[10]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/quad_uart_top.v", 7, 16, ".quad_uart_tb.dut", "v_toggle/quad_uart_top", "paddr");
    vlSelf->__vlCoverToggleInsert(0, 31, 1, &(vlSymsp->__Vcoverage[34]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/quad_uart_top.v", 8, 16, ".quad_uart_tb.dut", "v_toggle/quad_uart_top", "pwdata");
    vlSelf->__vlCoverToggleInsert(0, 31, 1, &(vlSymsp->__Vcoverage[106]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/quad_uart_top.v", 9, 17, ".quad_uart_tb.dut", "v_toggle/quad_uart_top", "prdata");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[170]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/quad_uart_top.v", 10, 16, ".quad_uart_tb.dut", "v_toggle/quad_uart_top", "pready");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[172]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/quad_uart_top.v", 11, 16, ".quad_uart_tb.dut", "v_toggle/quad_uart_top", "pslverr");
    vlSelf->__vlCoverToggleInsert(0, 3, 1, &(vlSymsp->__Vcoverage[98]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/quad_uart_top.v", 12, 16, ".quad_uart_tb.dut", "v_toggle/quad_uart_top", "uart_rx");
    vlSelf->__vlCoverToggleInsert(0, 3, 1, &(vlSymsp->__Vcoverage[174]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/quad_uart_top.v", 13, 16, ".quad_uart_tb.dut", "v_toggle/quad_uart_top", "uart_tx");
    vlSelf->__vlCoverToggleInsert(0, 3, 1, &(vlSymsp->__Vcoverage[182]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/quad_uart_top.v", 14, 16, ".quad_uart_tb.dut", "v_toggle/quad_uart_top", "irq");
    vlSelf->__vlCoverToggleInsert(0, 31, 1, &(vlSymsp->__Vcoverage[210]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/quad_uart_top.v", 17, 15, ".quad_uart_tb.dut", "v_toggle/quad_uart_top", "ch_cfg0");
    vlSelf->__vlCoverToggleInsert(0, 31, 1, &(vlSymsp->__Vcoverage[274]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/quad_uart_top.v", 17, 24, ".quad_uart_tb.dut", "v_toggle/quad_uart_top", "ch_cfg1");
    vlSelf->__vlCoverToggleInsert(0, 31, 1, &(vlSymsp->__Vcoverage[338]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/quad_uart_top.v", 17, 33, ".quad_uart_tb.dut", "v_toggle/quad_uart_top", "ch_cfg2");
    vlSelf->__vlCoverToggleInsert(0, 31, 1, &(vlSymsp->__Vcoverage[402]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/quad_uart_top.v", 17, 42, ".quad_uart_tb.dut", "v_toggle/quad_uart_top", "ch_cfg3");
    vlSelf->__vlCoverToggleInsert(0, 31, 1, &(vlSymsp->__Vcoverage[466]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/quad_uart_top.v", 18, 15, ".quad_uart_tb.dut", "v_toggle/quad_uart_top", "ch_tx0");
    vlSelf->__vlCoverToggleInsert(0, 31, 1, &(vlSymsp->__Vcoverage[530]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/quad_uart_top.v", 18, 23, ".quad_uart_tb.dut", "v_toggle/quad_uart_top", "ch_tx1");
    vlSelf->__vlCoverToggleInsert(0, 31, 1, &(vlSymsp->__Vcoverage[594]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/quad_uart_top.v", 18, 31, ".quad_uart_tb.dut", "v_toggle/quad_uart_top", "ch_tx2");
    vlSelf->__vlCoverToggleInsert(0, 31, 1, &(vlSymsp->__Vcoverage[658]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/quad_uart_top.v", 18, 39, ".quad_uart_tb.dut", "v_toggle/quad_uart_top", "ch_tx3");
    vlSelf->__vlCoverToggleInsert(0, 3, 1, &(vlSymsp->__Vcoverage[722]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/quad_uart_top.v", 19, 14, ".quad_uart_tb.dut", "v_toggle/quad_uart_top", "tx_fire");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[0]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 2, 16, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_toggle/apb_uart_ctrl", "pclk");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[2]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 3, 16, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_toggle/apb_uart_ctrl", "presetn");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[4]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 4, 16, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_toggle/apb_uart_ctrl", "psel");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[6]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 5, 16, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_toggle/apb_uart_ctrl", "penable");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[8]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 6, 16, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_toggle/apb_uart_ctrl", "pwrite");
    vlSelf->__vlCoverToggleInsert(0, 11, 1, &(vlSymsp->__Vcoverage[10]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 8, 16, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_toggle/apb_uart_ctrl", "paddr");
    vlSelf->__vlCoverToggleInsert(0, 31, 1, &(vlSymsp->__Vcoverage[34]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 10, 16, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_toggle/apb_uart_ctrl", "pwdata");
    vlSelf->__vlCoverToggleInsert(0, 3, 1, &(vlSymsp->__Vcoverage[182]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 11, 16, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_toggle/apb_uart_ctrl", "irq");
    vlSelf->__vlCoverToggleInsert(0, 31, 1, &(vlSymsp->__Vcoverage[210]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 12, 21, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_toggle/apb_uart_ctrl", "ch_cfg0");
    vlSelf->__vlCoverToggleInsert(0, 31, 1, &(vlSymsp->__Vcoverage[274]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 13, 21, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_toggle/apb_uart_ctrl", "ch_cfg1");
    vlSelf->__vlCoverToggleInsert(0, 31, 1, &(vlSymsp->__Vcoverage[338]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 14, 21, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_toggle/apb_uart_ctrl", "ch_cfg2");
    vlSelf->__vlCoverToggleInsert(0, 31, 1, &(vlSymsp->__Vcoverage[402]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 15, 21, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_toggle/apb_uart_ctrl", "ch_cfg3");
    vlSelf->__vlCoverToggleInsert(0, 31, 1, &(vlSymsp->__Vcoverage[466]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 16, 21, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_toggle/apb_uart_ctrl", "ch_tx0");
    vlSelf->__vlCoverToggleInsert(0, 31, 1, &(vlSymsp->__Vcoverage[530]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 17, 21, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_toggle/apb_uart_ctrl", "ch_tx1");
    vlSelf->__vlCoverToggleInsert(0, 31, 1, &(vlSymsp->__Vcoverage[594]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 18, 21, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_toggle/apb_uart_ctrl", "ch_tx2");
    vlSelf->__vlCoverToggleInsert(0, 31, 1, &(vlSymsp->__Vcoverage[658]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 19, 21, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_toggle/apb_uart_ctrl", "ch_tx3");
    vlSelf->__vlCoverToggleInsert(0, 3, 1, &(vlSymsp->__Vcoverage[722]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 20, 20, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_toggle/apb_uart_ctrl", "tx_fire");
    vlSelf->__vlCoverToggleInsert(0, 31, 1, &(vlSymsp->__Vcoverage[106]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 21, 21, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_toggle/apb_uart_ctrl", "prdata");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[730]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 22, 16, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_toggle/apb_uart_ctrl", "pready");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[732]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 23, 16, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_toggle/apb_uart_ctrl", "pslverr");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[734]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 28, 8, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_toggle/apb_uart_ctrl", "apb_access");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[736]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 29, 8, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_toggle/apb_uart_ctrl", "apb_wr");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[738]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 30, 8, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_toggle/apb_uart_ctrl", "apb_rd");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[740]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 41, 16, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_line/apb_uart_ctrl", "case", "41");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[741]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 42, 16, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_line/apb_uart_ctrl", "case", "42");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[742]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 43, 16, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_line/apb_uart_ctrl", "case", "43");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[743]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 44, 16, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_line/apb_uart_ctrl", "case", "44");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[744]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 45, 16, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_line/apb_uart_ctrl", "case", "45");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[745]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 46, 16, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_line/apb_uart_ctrl", "case", "46");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[746]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 47, 16, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_line/apb_uart_ctrl", "case", "47");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[747]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 48, 16, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_line/apb_uart_ctrl", "case", "48");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[748]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 49, 11, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_line/apb_uart_ctrl", "case", "49");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[749]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 39, 7, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_branch/apb_uart_ctrl", "if", "39-40");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[750]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 39, 8, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_branch/apb_uart_ctrl", "else", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[751]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 33, 5, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_branch/apb_uart_ctrl", "if", "33-36");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[752]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 33, 6, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_branch/apb_uart_ctrl", "else", "37-38");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[753]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 33, 9, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_expr/apb_uart_ctrl", "(presetn==0) => 1", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[754]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 33, 9, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_expr/apb_uart_ctrl", "(presetn==1) => 0", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[755]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 32, 3, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_line/apb_uart_ctrl", "block", "32");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[756]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 60, 14, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_line/apb_uart_ctrl", "case", "60");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[757]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 61, 14, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_line/apb_uart_ctrl", "case", "61");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[758]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 62, 14, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_line/apb_uart_ctrl", "case", "62");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[759]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 63, 14, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_line/apb_uart_ctrl", "case", "63");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[760]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 64, 14, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_line/apb_uart_ctrl", "case", "64");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[761]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 65, 14, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_line/apb_uart_ctrl", "case", "65");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[762]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 66, 14, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_line/apb_uart_ctrl", "case", "66");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[763]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 67, 14, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_line/apb_uart_ctrl", "case", "67");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[764]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 68, 14, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_line/apb_uart_ctrl", "case", "68");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[765]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 69, 9, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_line/apb_uart_ctrl", "case", "69");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[766]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 58, 14, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_branch/apb_uart_ctrl", "if", "58-59");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[767]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 58, 15, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_branch/apb_uart_ctrl", "else", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[768]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 56, 5, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_line/apb_uart_ctrl", "elsif", "56-57");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[769]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 56, 9, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_expr/apb_uart_ctrl", "(presetn==0) => 1", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[770]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 56, 9, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_expr/apb_uart_ctrl", "(presetn==1) => 0", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[771]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/apb_uart_ctrl.v", 55, 3, ".quad_uart_tb.dut.u_apb_uart_ctrl", "v_line/apb_uart_ctrl", "block", "55");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[0]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 2, 16, ".quad_uart_tb.dut.u_uart_ch0", "v_toggle/uart_channel", "pclk");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[2]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 3, 16, ".quad_uart_tb.dut.u_uart_ch0", "v_toggle/uart_channel", "presetn");
    vlSelf->__vlCoverToggleInsert(0, 31, 1, &(vlSymsp->__Vcoverage[210]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 5, 16, ".quad_uart_tb.dut.u_uart_ch0", "v_toggle/uart_channel", "cfg");
    vlSelf->__vlCoverToggleInsert(0, 31, 1, &(vlSymsp->__Vcoverage[466]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 6, 16, ".quad_uart_tb.dut.u_uart_ch0", "v_toggle/uart_channel", "tx_data");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[772]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 8, 16, ".quad_uart_tb.dut.u_uart_ch0", "v_toggle/uart_channel", "tx_fire");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[774]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 9, 16, ".quad_uart_tb.dut.u_uart_ch0", "v_toggle/uart_channel", "uart_rx");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[776]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 10, 16, ".quad_uart_tb.dut.u_uart_ch0", "v_toggle/uart_channel", "uart_tx");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[778]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 11, 16, ".quad_uart_tb.dut.u_uart_ch0", "v_toggle/uart_channel", "irq");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[780]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 13, 7, ".quad_uart_tb.dut.u_uart_ch0", "v_toggle/uart_channel", "rx_d");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[782]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 27, 16, ".quad_uart_tb.dut.u_uart_ch0", "v_branch/uart_channel", "if", "27-28");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[783]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 27, 17, ".quad_uart_tb.dut.u_uart_ch0", "v_branch/uart_channel", "else", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[784]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 25, 16, ".quad_uart_tb.dut.u_uart_ch0", "v_line/uart_channel", "elsif", "25-26");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[785]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 22, 7, ".quad_uart_tb.dut.u_uart_ch0", "v_line/uart_channel", "elsif", "22-24");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[786]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 16, 5, ".quad_uart_tb.dut.u_uart_ch0", "v_branch/uart_channel", "if", "16-19");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[787]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 16, 6, ".quad_uart_tb.dut.u_uart_ch0", "v_branch/uart_channel", "else", "20-21");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[788]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 16, 9, ".quad_uart_tb.dut.u_uart_ch0", "v_expr/uart_channel", "(presetn==0) => 1", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[789]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 16, 9, ".quad_uart_tb.dut.u_uart_ch0", "v_expr/uart_channel", "(presetn==1) => 0", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[790]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 15, 3, ".quad_uart_tb.dut.u_uart_ch0", "v_line/uart_channel", "block", "15");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[0]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 2, 16, ".quad_uart_tb.dut.u_uart_ch1", "v_toggle/uart_channel", "pclk");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[2]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 3, 16, ".quad_uart_tb.dut.u_uart_ch1", "v_toggle/uart_channel", "presetn");
    vlSelf->__vlCoverToggleInsert(0, 31, 1, &(vlSymsp->__Vcoverage[274]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 5, 16, ".quad_uart_tb.dut.u_uart_ch1", "v_toggle/uart_channel", "cfg");
    vlSelf->__vlCoverToggleInsert(0, 31, 1, &(vlSymsp->__Vcoverage[530]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 6, 16, ".quad_uart_tb.dut.u_uart_ch1", "v_toggle/uart_channel", "tx_data");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[791]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 8, 16, ".quad_uart_tb.dut.u_uart_ch1", "v_toggle/uart_channel", "tx_fire");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[793]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 9, 16, ".quad_uart_tb.dut.u_uart_ch1", "v_toggle/uart_channel", "uart_rx");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[795]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 10, 16, ".quad_uart_tb.dut.u_uart_ch1", "v_toggle/uart_channel", "uart_tx");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[797]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 11, 16, ".quad_uart_tb.dut.u_uart_ch1", "v_toggle/uart_channel", "irq");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[799]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 13, 7, ".quad_uart_tb.dut.u_uart_ch1", "v_toggle/uart_channel", "rx_d");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[801]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 27, 16, ".quad_uart_tb.dut.u_uart_ch1", "v_branch/uart_channel", "if", "27-28");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[802]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 27, 17, ".quad_uart_tb.dut.u_uart_ch1", "v_branch/uart_channel", "else", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[803]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 25, 16, ".quad_uart_tb.dut.u_uart_ch1", "v_line/uart_channel", "elsif", "25-26");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[804]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 22, 7, ".quad_uart_tb.dut.u_uart_ch1", "v_line/uart_channel", "elsif", "22-24");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[805]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 16, 5, ".quad_uart_tb.dut.u_uart_ch1", "v_branch/uart_channel", "if", "16-19");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[806]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 16, 6, ".quad_uart_tb.dut.u_uart_ch1", "v_branch/uart_channel", "else", "20-21");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[807]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 16, 9, ".quad_uart_tb.dut.u_uart_ch1", "v_expr/uart_channel", "(presetn==0) => 1", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[808]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 16, 9, ".quad_uart_tb.dut.u_uart_ch1", "v_expr/uart_channel", "(presetn==1) => 0", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[809]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 15, 3, ".quad_uart_tb.dut.u_uart_ch1", "v_line/uart_channel", "block", "15");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[0]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 2, 16, ".quad_uart_tb.dut.u_uart_ch2", "v_toggle/uart_channel", "pclk");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[2]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 3, 16, ".quad_uart_tb.dut.u_uart_ch2", "v_toggle/uart_channel", "presetn");
    vlSelf->__vlCoverToggleInsert(0, 31, 1, &(vlSymsp->__Vcoverage[338]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 5, 16, ".quad_uart_tb.dut.u_uart_ch2", "v_toggle/uart_channel", "cfg");
    vlSelf->__vlCoverToggleInsert(0, 31, 1, &(vlSymsp->__Vcoverage[594]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 6, 16, ".quad_uart_tb.dut.u_uart_ch2", "v_toggle/uart_channel", "tx_data");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[810]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 8, 16, ".quad_uart_tb.dut.u_uart_ch2", "v_toggle/uart_channel", "tx_fire");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[812]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 9, 16, ".quad_uart_tb.dut.u_uart_ch2", "v_toggle/uart_channel", "uart_rx");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[814]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 10, 16, ".quad_uart_tb.dut.u_uart_ch2", "v_toggle/uart_channel", "uart_tx");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[816]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 11, 16, ".quad_uart_tb.dut.u_uart_ch2", "v_toggle/uart_channel", "irq");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[818]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 13, 7, ".quad_uart_tb.dut.u_uart_ch2", "v_toggle/uart_channel", "rx_d");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[820]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 27, 16, ".quad_uart_tb.dut.u_uart_ch2", "v_branch/uart_channel", "if", "27-28");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[821]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 27, 17, ".quad_uart_tb.dut.u_uart_ch2", "v_branch/uart_channel", "else", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[822]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 25, 16, ".quad_uart_tb.dut.u_uart_ch2", "v_line/uart_channel", "elsif", "25-26");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[823]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 22, 7, ".quad_uart_tb.dut.u_uart_ch2", "v_line/uart_channel", "elsif", "22-24");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[824]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 16, 5, ".quad_uart_tb.dut.u_uart_ch2", "v_branch/uart_channel", "if", "16-19");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[825]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 16, 6, ".quad_uart_tb.dut.u_uart_ch2", "v_branch/uart_channel", "else", "20-21");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[826]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 16, 9, ".quad_uart_tb.dut.u_uart_ch2", "v_expr/uart_channel", "(presetn==0) => 1", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[827]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 16, 9, ".quad_uart_tb.dut.u_uart_ch2", "v_expr/uart_channel", "(presetn==1) => 0", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[828]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 15, 3, ".quad_uart_tb.dut.u_uart_ch2", "v_line/uart_channel", "block", "15");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[0]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 2, 16, ".quad_uart_tb.dut.u_uart_ch3", "v_toggle/uart_channel", "pclk");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[2]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 3, 16, ".quad_uart_tb.dut.u_uart_ch3", "v_toggle/uart_channel", "presetn");
    vlSelf->__vlCoverToggleInsert(0, 31, 1, &(vlSymsp->__Vcoverage[402]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 5, 16, ".quad_uart_tb.dut.u_uart_ch3", "v_toggle/uart_channel", "cfg");
    vlSelf->__vlCoverToggleInsert(0, 31, 1, &(vlSymsp->__Vcoverage[658]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 6, 16, ".quad_uart_tb.dut.u_uart_ch3", "v_toggle/uart_channel", "tx_data");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[829]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 8, 16, ".quad_uart_tb.dut.u_uart_ch3", "v_toggle/uart_channel", "tx_fire");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[831]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 9, 16, ".quad_uart_tb.dut.u_uart_ch3", "v_toggle/uart_channel", "uart_rx");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[833]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 10, 16, ".quad_uart_tb.dut.u_uart_ch3", "v_toggle/uart_channel", "uart_tx");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[835]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 11, 16, ".quad_uart_tb.dut.u_uart_ch3", "v_toggle/uart_channel", "irq");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[837]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 13, 7, ".quad_uart_tb.dut.u_uart_ch3", "v_toggle/uart_channel", "rx_d");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[839]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 27, 16, ".quad_uart_tb.dut.u_uart_ch3", "v_branch/uart_channel", "if", "27-28");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[840]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 27, 17, ".quad_uart_tb.dut.u_uart_ch3", "v_branch/uart_channel", "else", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[841]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 25, 16, ".quad_uart_tb.dut.u_uart_ch3", "v_line/uart_channel", "elsif", "25-26");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[842]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 22, 7, ".quad_uart_tb.dut.u_uart_ch3", "v_line/uart_channel", "elsif", "22-24");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[843]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 16, 5, ".quad_uart_tb.dut.u_uart_ch3", "v_branch/uart_channel", "if", "16-19");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[844]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 16, 6, ".quad_uart_tb.dut.u_uart_ch3", "v_branch/uart_channel", "else", "20-21");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[845]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 16, 9, ".quad_uart_tb.dut.u_uart_ch3", "v_expr/uart_channel", "(presetn==0) => 1", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[846]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 16, 9, ".quad_uart_tb.dut.u_uart_ch3", "v_expr/uart_channel", "(presetn==1) => 0", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[847]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/design/rtl/uart_channel.v", 15, 3, ".quad_uart_tb.dut.u_uart_ch3", "v_line/uart_channel", "block", "15");
}
