// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vquad_uart_tb.h for the primary calling header

#include "Vquad_uart_tb__pch.h"

VlCoroutine Vquad_uart_tb___024root___eval_initial__TOP__Vtiming__0(Vquad_uart_tb___024root* vlSelf);
VlCoroutine Vquad_uart_tb___024root___eval_initial__TOP__Vtiming__1(Vquad_uart_tb___024root* vlSelf);
VlCoroutine Vquad_uart_tb___024root___eval_initial__TOP__Vtiming__2(Vquad_uart_tb___024root* vlSelf);

void Vquad_uart_tb___024root___eval_initial(Vquad_uart_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquad_uart_tb___024root___eval_initial\n"); );
    Vquad_uart_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1U & (~ (IData)(vlSelfRef.quad_uart_tb__DOT____Vtogcov__pready)))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 170, 1U, vlSelfRef.quad_uart_tb__DOT____Vtogcov__pready);
        vlSelfRef.quad_uart_tb__DOT____Vtogcov__pready = 1U;
    }
    if (vlSelfRef.quad_uart_tb__DOT____Vtogcov__pslverr) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 172, 0U, vlSelfRef.quad_uart_tb__DOT____Vtogcov__pslverr);
        vlSelfRef.quad_uart_tb__DOT____Vtogcov__pslverr = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__pready)))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 730, 1U, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__pready);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__pready = 1U;
    }
    if (vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__pslverr) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 732, 0U, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__pslverr);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__pslverr = 0U;
    }
    Vquad_uart_tb___024root___eval_initial__TOP__Vtiming__0(vlSelf);
    Vquad_uart_tb___024root___eval_initial__TOP__Vtiming__1(vlSelf);
    Vquad_uart_tb___024root___eval_initial__TOP__Vtiming__2(vlSelf);
}

void Vquad_uart_tb___024root____VbeforeTrig_hecc72097__0(Vquad_uart_tb___024root* vlSelf, const char* __VeventDescription);
void Vquad_uart_tb___024root____VbeforeTrig_hecc7213b__0(Vquad_uart_tb___024root* vlSelf, const char* __VeventDescription);

VlCoroutine Vquad_uart_tb___024root___eval_initial__TOP__Vtiming__0(Vquad_uart_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquad_uart_tb___024root___eval_initial__TOP__Vtiming__0\n"); );
    Vquad_uart_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    IData/*31:0*/ quad_uart_tb__DOT__unnamedblk1_2__DOT____Vrepeat1;
    quad_uart_tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0;
    IData/*31:0*/ quad_uart_tb__DOT__unnamedblk1__DOT__i;
    quad_uart_tb__DOT__unnamedblk1__DOT__i = 0;
    IData/*31:0*/ quad_uart_tb__DOT__unnamedblk2__DOT__i;
    quad_uart_tb__DOT__unnamedblk2__DOT__i = 0;
    IData/*31:0*/ __Vtask_quad_uart_tb__DOT__settle__0__cycles;
    __Vtask_quad_uart_tb__DOT__settle__0__cycles = 0;
    IData/*31:0*/ __Vtask_quad_uart_tb__DOT__settle__0__quad_uart_tb__DOT__unnamedblk1_1__DOT____Vrepeat0;
    __Vtask_quad_uart_tb__DOT__settle__0__quad_uart_tb__DOT__unnamedblk1_1__DOT____Vrepeat0 = 0;
    IData/*31:0*/ __Vfunc_quad_uart_tb__DOT__cfg_addr__1__idx;
    __Vfunc_quad_uart_tb__DOT__cfg_addr__1__idx = 0;
    SData/*11:0*/ __Vtask_quad_uart_tb__DOT__apb_write__2__addr;
    __Vtask_quad_uart_tb__DOT__apb_write__2__addr = 0;
    IData/*31:0*/ __Vtask_quad_uart_tb__DOT__apb_write__2__data;
    __Vtask_quad_uart_tb__DOT__apb_write__2__data = 0;
    IData/*31:0*/ __Vfunc_quad_uart_tb__DOT__tx_addr__3__idx;
    __Vfunc_quad_uart_tb__DOT__tx_addr__3__idx = 0;
    SData/*11:0*/ __Vtask_quad_uart_tb__DOT__apb_write__4__addr;
    __Vtask_quad_uart_tb__DOT__apb_write__4__addr = 0;
    IData/*31:0*/ __Vtask_quad_uart_tb__DOT__apb_write__4__data;
    __Vtask_quad_uart_tb__DOT__apb_write__4__data = 0;
    IData/*31:0*/ __Vtask_quad_uart_tb__DOT__settle__5__cycles;
    __Vtask_quad_uart_tb__DOT__settle__5__cycles = 0;
    IData/*31:0*/ __Vtask_quad_uart_tb__DOT__settle__5__quad_uart_tb__DOT__unnamedblk1_1__DOT____Vrepeat0;
    __Vtask_quad_uart_tb__DOT__settle__5__quad_uart_tb__DOT__unnamedblk1_1__DOT____Vrepeat0 = 0;
    IData/*31:0*/ __Vtask_quad_uart_tb__DOT__settle__6__cycles;
    __Vtask_quad_uart_tb__DOT__settle__6__cycles = 0;
    IData/*31:0*/ __Vtask_quad_uart_tb__DOT__settle__6__quad_uart_tb__DOT__unnamedblk1_1__DOT____Vrepeat0;
    __Vtask_quad_uart_tb__DOT__settle__6__quad_uart_tb__DOT__unnamedblk1_1__DOT____Vrepeat0 = 0;
    IData/*31:0*/ __Vtask_quad_uart_tb__DOT__settle__7__cycles;
    __Vtask_quad_uart_tb__DOT__settle__7__cycles = 0;
    IData/*31:0*/ __Vtask_quad_uart_tb__DOT__settle__7__quad_uart_tb__DOT__unnamedblk1_1__DOT____Vrepeat0;
    __Vtask_quad_uart_tb__DOT__settle__7__quad_uart_tb__DOT__unnamedblk1_1__DOT____Vrepeat0 = 0;
    IData/*31:0*/ __Vfunc_quad_uart_tb__DOT__cfg_addr__8__idx;
    __Vfunc_quad_uart_tb__DOT__cfg_addr__8__idx = 0;
    SData/*11:0*/ __Vtask_quad_uart_tb__DOT__apb_read__9__addr;
    __Vtask_quad_uart_tb__DOT__apb_read__9__addr = 0;
    IData/*31:0*/ __Vtask_quad_uart_tb__DOT__apb_read__9__data;
    __Vtask_quad_uart_tb__DOT__apb_read__9__data = 0;
    IData/*31:0*/ __Vfunc_quad_uart_tb__DOT__tx_addr__10__idx;
    __Vfunc_quad_uart_tb__DOT__tx_addr__10__idx = 0;
    SData/*11:0*/ __Vtask_quad_uart_tb__DOT__apb_read__11__addr;
    __Vtask_quad_uart_tb__DOT__apb_read__11__addr = 0;
    IData/*31:0*/ __Vtask_quad_uart_tb__DOT__apb_read__11__data;
    __Vtask_quad_uart_tb__DOT__apb_read__11__data = 0;
    // Body
    vlSelfRef.quad_uart_tb__DOT__pclk = 0U;
    vlSelfRef.quad_uart_tb__DOT__presetn = 0U;
    vlSelfRef.quad_uart_tb__DOT__psel = 0U;
    vlSelfRef.quad_uart_tb__DOT__penable = 0U;
    vlSelfRef.quad_uart_tb__DOT__pwrite = 0U;
    vlSelfRef.quad_uart_tb__DOT__paddr = 0U;
    vlSelfRef.quad_uart_tb__DOT__pwdata = 0U;
    vlSelfRef.quad_uart_tb__DOT__uart_rx = 0x0fU;
    quad_uart_tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 4U;
    while (VL_LTS_III(32, 0U, quad_uart_tb__DOT__unnamedblk1_2__DOT____Vrepeat1)) {
        Vquad_uart_tb___024root____VbeforeTrig_hecc72097__0(vlSelf, 
                                                            "@(posedge quad_uart_tb.pclk)");
        co_await vlSelfRef.__VtrigSched_hecc72097__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge quad_uart_tb.pclk)", 
                                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 
                                                             130);
        quad_uart_tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
            = (quad_uart_tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
               - (IData)(1U));
        ++(vlSymsp->__Vcoverage[205]);
    }
    vlSelfRef.quad_uart_tb__DOT__presetn = 1U;
    __Vtask_quad_uart_tb__DOT__settle__0__cycles = 2U;
    __Vtask_quad_uart_tb__DOT__settle__0__quad_uart_tb__DOT__unnamedblk1_1__DOT____Vrepeat0 = 0;
    __Vtask_quad_uart_tb__DOT__settle__0__quad_uart_tb__DOT__unnamedblk1_1__DOT____Vrepeat0 
        = __Vtask_quad_uart_tb__DOT__settle__0__cycles;
    while (VL_LTS_III(32, 0U, __Vtask_quad_uart_tb__DOT__settle__0__quad_uart_tb__DOT__unnamedblk1_1__DOT____Vrepeat0)) {
        Vquad_uart_tb___024root____VbeforeTrig_hecc72097__0(vlSelf, 
                                                            "@(posedge quad_uart_tb.pclk)");
        co_await vlSelfRef.__VtrigSched_hecc72097__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge quad_uart_tb.pclk)", 
                                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 
                                                             115);
        __Vtask_quad_uart_tb__DOT__settle__0__quad_uart_tb__DOT__unnamedblk1_1__DOT____Vrepeat0 
            = (__Vtask_quad_uart_tb__DOT__settle__0__quad_uart_tb__DOT__unnamedblk1_1__DOT____Vrepeat0 
               - (IData)(1U));
        ++(vlSymsp->__Vcoverage[203]);
    }
    co_await vlSelfRef.__VdlySched.delay(0x00000000000003e8ULL, 
                                         nullptr, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 
                                         116);
    ++(vlSymsp->__Vcoverage[204]);
    quad_uart_tb__DOT__unnamedblk1__DOT__i = 0U;
    while (VL_GTS_III(32, 4U, quad_uart_tb__DOT__unnamedblk1__DOT__i)) {
        __Vfunc_quad_uart_tb__DOT__cfg_addr__1__idx 
            = quad_uart_tb__DOT__unnamedblk1__DOT__i;
        vlSelf->quad_uart_tb__DOT____VlemCall_0__cfg_addr = 0;
        if ((0U == __Vfunc_quad_uart_tb__DOT__cfg_addr__1__idx)) {
            vlSelfRef.quad_uart_tb__DOT____VlemCall_0__cfg_addr = 0U;
            ++(vlSymsp->__Vcoverage[193]);
        } else if ((1U == __Vfunc_quad_uart_tb__DOT__cfg_addr__1__idx)) {
            vlSelfRef.quad_uart_tb__DOT____VlemCall_0__cfg_addr = 0x0010U;
            ++(vlSymsp->__Vcoverage[194]);
        } else if ((2U == __Vfunc_quad_uart_tb__DOT__cfg_addr__1__idx)) {
            vlSelfRef.quad_uart_tb__DOT____VlemCall_0__cfg_addr = 0x0020U;
            ++(vlSymsp->__Vcoverage[195]);
        } else {
            vlSelfRef.quad_uart_tb__DOT____VlemCall_0__cfg_addr = 0x0030U;
            ++(vlSymsp->__Vcoverage[196]);
        }
        ++(vlSymsp->__Vcoverage[197]);
        __Vtask_quad_uart_tb__DOT__apb_write__2__data = 1U;
        __Vtask_quad_uart_tb__DOT__apb_write__2__addr 
            = vlSelfRef.quad_uart_tb__DOT____VlemCall_0__cfg_addr;
        Vquad_uart_tb___024root____VbeforeTrig_hecc7213b__0(vlSelf, 
                                                            "@(negedge quad_uart_tb.pclk)");
        co_await vlSelfRef.__VtrigSched_hecc7213b__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(negedge quad_uart_tb.pclk)", 
                                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 
                                                             56);
        vlSelfRef.quad_uart_tb__DOT__psel = 1U;
        vlSelfRef.quad_uart_tb__DOT__penable = 0U;
        vlSelfRef.quad_uart_tb__DOT__pwrite = 1U;
        vlSelfRef.quad_uart_tb__DOT__paddr = __Vtask_quad_uart_tb__DOT__apb_write__2__addr;
        vlSelfRef.quad_uart_tb__DOT__pwdata = __Vtask_quad_uart_tb__DOT__apb_write__2__data;
        Vquad_uart_tb___024root____VbeforeTrig_hecc7213b__0(vlSelf, 
                                                            "@(negedge quad_uart_tb.pclk)");
        co_await vlSelfRef.__VtrigSched_hecc7213b__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(negedge quad_uart_tb.pclk)", 
                                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 
                                                             62);
        vlSelfRef.quad_uart_tb__DOT__penable = 1U;
        Vquad_uart_tb___024root____VbeforeTrig_hecc72097__0(vlSelf, 
                                                            "@(posedge quad_uart_tb.pclk)");
        co_await vlSelfRef.__VtrigSched_hecc72097__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge quad_uart_tb.pclk)", 
                                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 
                                                             64);
        co_await vlSelfRef.__VdlySched.delay(0x00000000000003e8ULL, 
                                             nullptr, 
                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 
                                             65);
        Vquad_uart_tb___024root____VbeforeTrig_hecc7213b__0(vlSelf, 
                                                            "@(negedge quad_uart_tb.pclk)");
        co_await vlSelfRef.__VtrigSched_hecc7213b__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(negedge quad_uart_tb.pclk)", 
                                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 
                                                             76);
        vlSelfRef.quad_uart_tb__DOT__psel = 0U;
        vlSelfRef.quad_uart_tb__DOT__penable = 0U;
        vlSelfRef.quad_uart_tb__DOT__pwrite = 0U;
        __Vfunc_quad_uart_tb__DOT__tx_addr__3__idx 
            = quad_uart_tb__DOT__unnamedblk1__DOT__i;
        vlSelf->quad_uart_tb__DOT____VlemCall_1__tx_addr = 0;
        if ((0U == __Vfunc_quad_uart_tb__DOT__tx_addr__3__idx)) {
            vlSelfRef.quad_uart_tb__DOT____VlemCall_1__tx_addr = 4U;
            ++(vlSymsp->__Vcoverage[198]);
        } else if ((1U == __Vfunc_quad_uart_tb__DOT__tx_addr__3__idx)) {
            vlSelfRef.quad_uart_tb__DOT____VlemCall_1__tx_addr = 0x0014U;
            ++(vlSymsp->__Vcoverage[199]);
        } else if ((2U == __Vfunc_quad_uart_tb__DOT__tx_addr__3__idx)) {
            vlSelfRef.quad_uart_tb__DOT____VlemCall_1__tx_addr = 0x0024U;
            ++(vlSymsp->__Vcoverage[200]);
        } else {
            vlSelfRef.quad_uart_tb__DOT____VlemCall_1__tx_addr = 0x0034U;
            ++(vlSymsp->__Vcoverage[201]);
        }
        ++(vlSymsp->__Vcoverage[202]);
        __Vtask_quad_uart_tb__DOT__apb_write__4__data 
            = ((0U == VL_MODDIVS_III(32, quad_uart_tb__DOT__unnamedblk1__DOT__i, (IData)(2U)))
                ? 0U : 1U);
        __Vtask_quad_uart_tb__DOT__apb_write__4__addr 
            = vlSelfRef.quad_uart_tb__DOT____VlemCall_1__tx_addr;
        Vquad_uart_tb___024root____VbeforeTrig_hecc7213b__0(vlSelf, 
                                                            "@(negedge quad_uart_tb.pclk)");
        co_await vlSelfRef.__VtrigSched_hecc7213b__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(negedge quad_uart_tb.pclk)", 
                                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 
                                                             56);
        vlSelfRef.quad_uart_tb__DOT__psel = 1U;
        vlSelfRef.quad_uart_tb__DOT__penable = 0U;
        vlSelfRef.quad_uart_tb__DOT__pwrite = 1U;
        vlSelfRef.quad_uart_tb__DOT__paddr = __Vtask_quad_uart_tb__DOT__apb_write__4__addr;
        vlSelfRef.quad_uart_tb__DOT__pwdata = __Vtask_quad_uart_tb__DOT__apb_write__4__data;
        Vquad_uart_tb___024root____VbeforeTrig_hecc7213b__0(vlSelf, 
                                                            "@(negedge quad_uart_tb.pclk)");
        co_await vlSelfRef.__VtrigSched_hecc7213b__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(negedge quad_uart_tb.pclk)", 
                                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 
                                                             62);
        vlSelfRef.quad_uart_tb__DOT__penable = 1U;
        Vquad_uart_tb___024root____VbeforeTrig_hecc72097__0(vlSelf, 
                                                            "@(posedge quad_uart_tb.pclk)");
        co_await vlSelfRef.__VtrigSched_hecc72097__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge quad_uart_tb.pclk)", 
                                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 
                                                             64);
        co_await vlSelfRef.__VdlySched.delay(0x00000000000003e8ULL, 
                                             nullptr, 
                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 
                                             65);
        Vquad_uart_tb___024root____VbeforeTrig_hecc7213b__0(vlSelf, 
                                                            "@(negedge quad_uart_tb.pclk)");
        co_await vlSelfRef.__VtrigSched_hecc7213b__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(negedge quad_uart_tb.pclk)", 
                                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 
                                                             76);
        vlSelfRef.quad_uart_tb__DOT__psel = 0U;
        vlSelfRef.quad_uart_tb__DOT__penable = 0U;
        vlSelfRef.quad_uart_tb__DOT__pwrite = 0U;
        __Vtask_quad_uart_tb__DOT__settle__5__cycles = 1U;
        __Vtask_quad_uart_tb__DOT__settle__5__quad_uart_tb__DOT__unnamedblk1_1__DOT____Vrepeat0 = 0;
        __Vtask_quad_uart_tb__DOT__settle__5__quad_uart_tb__DOT__unnamedblk1_1__DOT____Vrepeat0 
            = __Vtask_quad_uart_tb__DOT__settle__5__cycles;
        while (VL_LTS_III(32, 0U, __Vtask_quad_uart_tb__DOT__settle__5__quad_uart_tb__DOT__unnamedblk1_1__DOT____Vrepeat0)) {
            Vquad_uart_tb___024root____VbeforeTrig_hecc72097__0(vlSelf, 
                                                                "@(posedge quad_uart_tb.pclk)");
            co_await vlSelfRef.__VtrigSched_hecc72097__0.trigger(0U, 
                                                                 nullptr, 
                                                                 "@(posedge quad_uart_tb.pclk)", 
                                                                 "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 
                                                                 115);
            __Vtask_quad_uart_tb__DOT__settle__5__quad_uart_tb__DOT__unnamedblk1_1__DOT____Vrepeat0 
                = (__Vtask_quad_uart_tb__DOT__settle__5__quad_uart_tb__DOT__unnamedblk1_1__DOT____Vrepeat0 
                   - (IData)(1U));
            ++(vlSymsp->__Vcoverage[203]);
        }
        co_await vlSelfRef.__VdlySched.delay(0x00000000000003e8ULL, 
                                             nullptr, 
                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 
                                             116);
        ++(vlSymsp->__Vcoverage[204]);
        quad_uart_tb__DOT__unnamedblk1__DOT__i = ((IData)(1U) 
                                                  + quad_uart_tb__DOT__unnamedblk1__DOT__i);
        ++(vlSymsp->__Vcoverage[208]);
    }
    vlSelfRef.quad_uart_tb__DOT__uart_rx = 0x0eU;
    __Vtask_quad_uart_tb__DOT__settle__6__cycles = 2U;
    __Vtask_quad_uart_tb__DOT__settle__6__quad_uart_tb__DOT__unnamedblk1_1__DOT____Vrepeat0 = 0;
    __Vtask_quad_uart_tb__DOT__settle__6__quad_uart_tb__DOT__unnamedblk1_1__DOT____Vrepeat0 
        = __Vtask_quad_uart_tb__DOT__settle__6__cycles;
    while (VL_LTS_III(32, 0U, __Vtask_quad_uart_tb__DOT__settle__6__quad_uart_tb__DOT__unnamedblk1_1__DOT____Vrepeat0)) {
        Vquad_uart_tb___024root____VbeforeTrig_hecc72097__0(vlSelf, 
                                                            "@(posedge quad_uart_tb.pclk)");
        co_await vlSelfRef.__VtrigSched_hecc72097__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge quad_uart_tb.pclk)", 
                                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 
                                                             115);
        __Vtask_quad_uart_tb__DOT__settle__6__quad_uart_tb__DOT__unnamedblk1_1__DOT____Vrepeat0 
            = (__Vtask_quad_uart_tb__DOT__settle__6__quad_uart_tb__DOT__unnamedblk1_1__DOT____Vrepeat0 
               - (IData)(1U));
        ++(vlSymsp->__Vcoverage[203]);
    }
    co_await vlSelfRef.__VdlySched.delay(0x00000000000003e8ULL, 
                                         nullptr, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 
                                         116);
    ++(vlSymsp->__Vcoverage[204]);
    vlSelfRef.quad_uart_tb__DOT__uart_rx = 0x0fU;
    __Vtask_quad_uart_tb__DOT__settle__7__cycles = 2U;
    __Vtask_quad_uart_tb__DOT__settle__7__quad_uart_tb__DOT__unnamedblk1_1__DOT____Vrepeat0 = 0;
    __Vtask_quad_uart_tb__DOT__settle__7__quad_uart_tb__DOT__unnamedblk1_1__DOT____Vrepeat0 
        = __Vtask_quad_uart_tb__DOT__settle__7__cycles;
    while (VL_LTS_III(32, 0U, __Vtask_quad_uart_tb__DOT__settle__7__quad_uart_tb__DOT__unnamedblk1_1__DOT____Vrepeat0)) {
        Vquad_uart_tb___024root____VbeforeTrig_hecc72097__0(vlSelf, 
                                                            "@(posedge quad_uart_tb.pclk)");
        co_await vlSelfRef.__VtrigSched_hecc72097__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge quad_uart_tb.pclk)", 
                                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 
                                                             115);
        __Vtask_quad_uart_tb__DOT__settle__7__quad_uart_tb__DOT__unnamedblk1_1__DOT____Vrepeat0 
            = (__Vtask_quad_uart_tb__DOT__settle__7__quad_uart_tb__DOT__unnamedblk1_1__DOT____Vrepeat0 
               - (IData)(1U));
        ++(vlSymsp->__Vcoverage[203]);
    }
    co_await vlSelfRef.__VdlySched.delay(0x00000000000003e8ULL, 
                                         nullptr, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 
                                         116);
    ++(vlSymsp->__Vcoverage[204]);
    quad_uart_tb__DOT__unnamedblk2__DOT__i = 0U;
    while (VL_GTS_III(32, 4U, quad_uart_tb__DOT__unnamedblk2__DOT__i)) {
        __Vfunc_quad_uart_tb__DOT__cfg_addr__8__idx 
            = quad_uart_tb__DOT__unnamedblk2__DOT__i;
        vlSelf->quad_uart_tb__DOT____VlemCall_2__cfg_addr = 0;
        if ((0U == __Vfunc_quad_uart_tb__DOT__cfg_addr__8__idx)) {
            vlSelfRef.quad_uart_tb__DOT____VlemCall_2__cfg_addr = 0U;
            ++(vlSymsp->__Vcoverage[193]);
        } else if ((1U == __Vfunc_quad_uart_tb__DOT__cfg_addr__8__idx)) {
            vlSelfRef.quad_uart_tb__DOT____VlemCall_2__cfg_addr = 0x0010U;
            ++(vlSymsp->__Vcoverage[194]);
        } else if ((2U == __Vfunc_quad_uart_tb__DOT__cfg_addr__8__idx)) {
            vlSelfRef.quad_uart_tb__DOT____VlemCall_2__cfg_addr = 0x0020U;
            ++(vlSymsp->__Vcoverage[195]);
        } else {
            vlSelfRef.quad_uart_tb__DOT____VlemCall_2__cfg_addr = 0x0030U;
            ++(vlSymsp->__Vcoverage[196]);
        }
        ++(vlSymsp->__Vcoverage[197]);
        __Vtask_quad_uart_tb__DOT__apb_read__9__addr 
            = vlSelfRef.quad_uart_tb__DOT____VlemCall_2__cfg_addr;
        __Vtask_quad_uart_tb__DOT__apb_read__9__data = 0;
        Vquad_uart_tb___024root____VbeforeTrig_hecc7213b__0(vlSelf, 
                                                            "@(negedge quad_uart_tb.pclk)");
        co_await vlSelfRef.__VtrigSched_hecc7213b__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(negedge quad_uart_tb.pclk)", 
                                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 
                                                             85);
        vlSelfRef.quad_uart_tb__DOT__psel = 1U;
        vlSelfRef.quad_uart_tb__DOT__penable = 0U;
        vlSelfRef.quad_uart_tb__DOT__pwrite = 0U;
        vlSelfRef.quad_uart_tb__DOT__paddr = __Vtask_quad_uart_tb__DOT__apb_read__9__addr;
        vlSelfRef.quad_uart_tb__DOT__pwdata = 0U;
        Vquad_uart_tb___024root____VbeforeTrig_hecc7213b__0(vlSelf, 
                                                            "@(negedge quad_uart_tb.pclk)");
        co_await vlSelfRef.__VtrigSched_hecc7213b__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(negedge quad_uart_tb.pclk)", 
                                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 
                                                             91);
        vlSelfRef.quad_uart_tb__DOT__penable = 1U;
        Vquad_uart_tb___024root____VbeforeTrig_hecc72097__0(vlSelf, 
                                                            "@(posedge quad_uart_tb.pclk)");
        co_await vlSelfRef.__VtrigSched_hecc72097__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge quad_uart_tb.pclk)", 
                                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 
                                                             93);
        co_await vlSelfRef.__VdlySched.delay(0x00000000000003e8ULL, 
                                             nullptr, 
                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 
                                             94);
        __Vtask_quad_uart_tb__DOT__apb_read__9__data 
            = vlSelfRef.quad_uart_tb__DOT__prdata;
        Vquad_uart_tb___024root____VbeforeTrig_hecc7213b__0(vlSelf, 
                                                            "@(negedge quad_uart_tb.pclk)");
        co_await vlSelfRef.__VtrigSched_hecc7213b__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(negedge quad_uart_tb.pclk)", 
                                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 
                                                             106);
        vlSelfRef.quad_uart_tb__DOT__psel = 0U;
        vlSelfRef.quad_uart_tb__DOT__penable = 0U;
        vlSelfRef.quad_uart_tb__DOT__pwrite = 0U;
        vlSelfRef.quad_uart_tb__DOT__unnamedblk2__DOT__unnamedblk3__DOT__read_back 
            = __Vtask_quad_uart_tb__DOT__apb_read__9__data;
        __Vfunc_quad_uart_tb__DOT__tx_addr__10__idx 
            = quad_uart_tb__DOT__unnamedblk2__DOT__i;
        vlSelf->quad_uart_tb__DOT____VlemCall_3__tx_addr = 0;
        if (vlSymsp->_vm_contextp__->assertOnGet(2, 1)) {
            if (VL_UNLIKELY(((1U & (~ vlSelfRef.quad_uart_tb__DOT__unnamedblk2__DOT__unnamedblk3__DOT__read_back))))) {
                VL_WRITEF_NX("QUAD_UART_ASSERT_FAIL cfg[%0d] readback mismatch: %08h\n[%0t] %%Fatal: quad_uart_tb.sv:151: Assertion failed in %m\n",5, 'M',vlSymsp->name(),"quad_uart_tb.unnamedblk2.unnamedblk3", 'T',-9
                             , '~',32,quad_uart_tb__DOT__unnamedblk2__DOT__i
                             , '#',32,vlSelfRef.quad_uart_tb__DOT__unnamedblk2__DOT__unnamedblk3__DOT__read_back
                             , '#',64,VL_TIME_UNITED_Q(1000));
                VL_STOP_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 151, "", false);
            }
        }
        if ((0U == __Vfunc_quad_uart_tb__DOT__tx_addr__10__idx)) {
            vlSelfRef.quad_uart_tb__DOT____VlemCall_3__tx_addr = 4U;
            ++(vlSymsp->__Vcoverage[198]);
        } else if ((1U == __Vfunc_quad_uart_tb__DOT__tx_addr__10__idx)) {
            vlSelfRef.quad_uart_tb__DOT____VlemCall_3__tx_addr = 0x0014U;
            ++(vlSymsp->__Vcoverage[199]);
        } else if ((2U == __Vfunc_quad_uart_tb__DOT__tx_addr__10__idx)) {
            vlSelfRef.quad_uart_tb__DOT____VlemCall_3__tx_addr = 0x0024U;
            ++(vlSymsp->__Vcoverage[200]);
        } else {
            vlSelfRef.quad_uart_tb__DOT____VlemCall_3__tx_addr = 0x0034U;
            ++(vlSymsp->__Vcoverage[201]);
        }
        ++(vlSymsp->__Vcoverage[202]);
        __Vtask_quad_uart_tb__DOT__apb_read__11__addr 
            = vlSelfRef.quad_uart_tb__DOT____VlemCall_3__tx_addr;
        __Vtask_quad_uart_tb__DOT__apb_read__11__data = 0;
        Vquad_uart_tb___024root____VbeforeTrig_hecc7213b__0(vlSelf, 
                                                            "@(negedge quad_uart_tb.pclk)");
        co_await vlSelfRef.__VtrigSched_hecc7213b__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(negedge quad_uart_tb.pclk)", 
                                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 
                                                             85);
        vlSelfRef.quad_uart_tb__DOT__psel = 1U;
        vlSelfRef.quad_uart_tb__DOT__penable = 0U;
        vlSelfRef.quad_uart_tb__DOT__pwrite = 0U;
        vlSelfRef.quad_uart_tb__DOT__paddr = __Vtask_quad_uart_tb__DOT__apb_read__11__addr;
        vlSelfRef.quad_uart_tb__DOT__pwdata = 0U;
        Vquad_uart_tb___024root____VbeforeTrig_hecc7213b__0(vlSelf, 
                                                            "@(negedge quad_uart_tb.pclk)");
        co_await vlSelfRef.__VtrigSched_hecc7213b__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(negedge quad_uart_tb.pclk)", 
                                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 
                                                             91);
        vlSelfRef.quad_uart_tb__DOT__penable = 1U;
        Vquad_uart_tb___024root____VbeforeTrig_hecc72097__0(vlSelf, 
                                                            "@(posedge quad_uart_tb.pclk)");
        co_await vlSelfRef.__VtrigSched_hecc72097__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge quad_uart_tb.pclk)", 
                                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 
                                                             93);
        co_await vlSelfRef.__VdlySched.delay(0x00000000000003e8ULL, 
                                             nullptr, 
                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 
                                             94);
        __Vtask_quad_uart_tb__DOT__apb_read__11__data 
            = vlSelfRef.quad_uart_tb__DOT__prdata;
        Vquad_uart_tb___024root____VbeforeTrig_hecc7213b__0(vlSelf, 
                                                            "@(negedge quad_uart_tb.pclk)");
        co_await vlSelfRef.__VtrigSched_hecc7213b__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(negedge quad_uart_tb.pclk)", 
                                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 
                                                             106);
        vlSelfRef.quad_uart_tb__DOT__psel = 0U;
        vlSelfRef.quad_uart_tb__DOT__penable = 0U;
        vlSelfRef.quad_uart_tb__DOT__pwrite = 0U;
        vlSelfRef.quad_uart_tb__DOT__unnamedblk2__DOT__unnamedblk3__DOT__read_back 
            = __Vtask_quad_uart_tb__DOT__apb_read__11__data;
        if (vlSymsp->_vm_contextp__->assertOnGet(2, 1)) {
            if (VL_UNLIKELY((((1U & vlSelfRef.quad_uart_tb__DOT__unnamedblk2__DOT__unnamedblk3__DOT__read_back) 
                              != (0U != VL_MODDIVS_III(32, quad_uart_tb__DOT__unnamedblk2__DOT__i, (IData)(2U))))))) {
                VL_WRITEF_NX("QUAD_UART_ASSERT_FAIL tx[%0d] readback mismatch: %08h\n[%0t] %%Fatal: quad_uart_tb.sv:157: Assertion failed in %m\n",5, 'M',vlSymsp->name(),"quad_uart_tb.unnamedblk2.unnamedblk3", 'T',-9
                             , '~',32,quad_uart_tb__DOT__unnamedblk2__DOT__i
                             , '#',32,vlSelfRef.quad_uart_tb__DOT__unnamedblk2__DOT__unnamedblk3__DOT__read_back
                             , '#',64,VL_TIME_UNITED_Q(1000));
                VL_STOP_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 157, "", false);
            }
        }
        quad_uart_tb__DOT__unnamedblk2__DOT__i = ((IData)(1U) 
                                                  + quad_uart_tb__DOT__unnamedblk2__DOT__i);
    }
    if (vlSymsp->_vm_contextp__->assertOnGet(2, 1)) {
        if (VL_UNLIKELY(((1U & (IData)(vlSelfRef.quad_uart_tb__DOT__uart_tx))))) {
            VL_WRITEF_NX("QUAD_UART_ASSERT_FAIL uart_tx[0] expected 0 got=%b\n[%0t] %%Fatal: quad_uart_tb.sv:164: Assertion failed in %m\n",4, 'M',vlSymsp->name(),"quad_uart_tb", 'T',-9
                         , '#',1,(1U & (IData)(vlSelfRef.quad_uart_tb__DOT__uart_tx))
                         , '#',64,VL_TIME_UNITED_Q(1000));
            VL_STOP_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 164, "", false);
        }
        if (VL_UNLIKELY(((1U & (~ ((IData)(vlSelfRef.quad_uart_tb__DOT__uart_tx) 
                                   >> 1U)))))) {
            VL_WRITEF_NX("QUAD_UART_ASSERT_FAIL uart_tx[1] expected 1 got=%b\n[%0t] %%Fatal: quad_uart_tb.sv:169: Assertion failed in %m\n",4, 'M',vlSymsp->name(),"quad_uart_tb", 'T',-9
                         , '#',1,(1U & ((IData)(vlSelfRef.quad_uart_tb__DOT__uart_tx) 
                                        >> 1U)), '#',64,VL_TIME_UNITED_Q(1000));
            VL_STOP_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 169, "", false);
        }
        if (VL_UNLIKELY(((1U & (IData)(vlSelfRef.quad_uart_tb__DOT__irq))))) {
            VL_WRITEF_NX("QUAD_UART_ASSERT_FAIL irq[0] expected 0 got=%b\n[%0t] %%Fatal: quad_uart_tb.sv:174: Assertion failed in %m\n",4, 'M',vlSymsp->name(),"quad_uart_tb", 'T',-9
                         , '#',1,(1U & (IData)(vlSelfRef.quad_uart_tb__DOT__irq))
                         , '#',64,VL_TIME_UNITED_Q(1000));
            VL_STOP_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 174, "", false);
        }
        if (VL_UNLIKELY(((2U & (IData)(vlSelfRef.quad_uart_tb__DOT__irq))))) {
            VL_WRITEF_NX("QUAD_UART_ASSERT_FAIL irq[1] expected 0 got=%b\n[%0t] %%Fatal: quad_uart_tb.sv:179: Assertion failed in %m\n",4, 'M',vlSymsp->name(),"quad_uart_tb", 'T',-9
                         , '#',1,(1U & ((IData)(vlSelfRef.quad_uart_tb__DOT__irq) 
                                        >> 1U)), '#',64,VL_TIME_UNITED_Q(1000));
            VL_STOP_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 179, "", false);
        }
    }
    VL_WRITEF_NX("Comparison Passed: quad_uart smoke\nQUAD_UART_SIM_PASS\n",0);
    VL_FINISH_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 184, "");
    if ((0U == VL_MODDIVS_III(32, quad_uart_tb__DOT__unnamedblk1__DOT__i, (IData)(2U)))) {
        ++(vlSymsp->__Vcoverage[206]);
    }
    if ((0U != VL_MODDIVS_III(32, quad_uart_tb__DOT__unnamedblk1__DOT__i, (IData)(2U)))) {
        ++(vlSymsp->__Vcoverage[207]);
    }
    co_return;
}

VlCoroutine Vquad_uart_tb___024root___eval_initial__TOP__Vtiming__1(Vquad_uart_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquad_uart_tb___024root___eval_initial__TOP__Vtiming__1\n"); );
    Vquad_uart_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    IData/*31:0*/ quad_uart_tb__DOT__unnamedblk1_3__DOT____Vrepeat2;
    quad_uart_tb__DOT__unnamedblk1_3__DOT____Vrepeat2 = 0;
    // Body
    quad_uart_tb__DOT__unnamedblk1_3__DOT____Vrepeat2 = 0x00000190U;
    while (VL_LTS_III(32, 0U, quad_uart_tb__DOT__unnamedblk1_3__DOT____Vrepeat2)) {
        Vquad_uart_tb___024root____VbeforeTrig_hecc72097__0(vlSelf, 
                                                            "@(posedge quad_uart_tb.pclk)");
        co_await vlSelfRef.__VtrigSched_hecc72097__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge quad_uart_tb.pclk)", 
                                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 
                                                             188);
        quad_uart_tb__DOT__unnamedblk1_3__DOT____Vrepeat2 
            = (quad_uart_tb__DOT__unnamedblk1_3__DOT____Vrepeat2 
               - (IData)(1U));
        ++(vlSymsp->__Vcoverage[209]);
    }
    VL_WRITEF_NX("QUAD_UART_SIM_TIMEOUT\n[%0t] %%Fatal: quad_uart_tb.sv:190: Assertion failed in %m\n",3, 'M',vlSymsp->name(),"quad_uart_tb", 'T',-9
                 , '#',64,VL_TIME_UNITED_Q(1000));
    VL_STOP_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 190, "", false);
    co_return;
}

VlCoroutine Vquad_uart_tb___024root___eval_initial__TOP__Vtiming__2(Vquad_uart_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquad_uart_tb___024root___eval_initial__TOP__Vtiming__2\n"); );
    Vquad_uart_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    while (VL_LIKELY(!vlSymsp->_vm_contextp__->gotFinish())) {
        co_await vlSelfRef.__VdlySched.delay(0x0000000000001388ULL, 
                                             nullptr, 
                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 
                                             34);
        vlSelfRef.quad_uart_tb__DOT__pclk = (1U & (~ (IData)(vlSelfRef.quad_uart_tb__DOT__pclk)));
        if ((1U & (~ (IData)(vlSelfRef.quad_uart_tb__DOT__pclk)))) {
            ++(vlSymsp->__Vcoverage[190]);
        }
        if (vlSelfRef.quad_uart_tb__DOT__pclk) {
            ++(vlSymsp->__Vcoverage[191]);
        }
        ++(vlSymsp->__Vcoverage[192]);
    }
    co_return;
}

void Vquad_uart_tb___024root___eval_triggers_vec__act(Vquad_uart_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquad_uart_tb___024root___eval_triggers_vec__act\n"); );
    Vquad_uart_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__VactTriggered[0U] = (QData)((IData)(
                                                    (((((~ (IData)(vlSelfRef.quad_uart_tb__DOT__pclk)) 
                                                        & (IData)(vlSelfRef.__Vtrigprevexpr___TOP__quad_uart_tb__DOT__pclk__0)) 
                                                       << 3U) 
                                                      | (vlSelfRef.__VdlySched.awaitingCurrentTime() 
                                                         << 2U)) 
                                                     | ((((~ (IData)(vlSelfRef.quad_uart_tb__DOT__presetn)) 
                                                          & (IData)(vlSelfRef.__Vtrigprevexpr___TOP__quad_uart_tb__DOT__presetn__0)) 
                                                         << 1U) 
                                                        | ((IData)(vlSelfRef.quad_uart_tb__DOT__pclk) 
                                                           & (~ (IData)(vlSelfRef.__Vtrigprevexpr___TOP__quad_uart_tb__DOT__pclk__0)))))));
    vlSelfRef.__Vtrigprevexpr___TOP__quad_uart_tb__DOT__pclk__0 
        = vlSelfRef.quad_uart_tb__DOT__pclk;
    vlSelfRef.__Vtrigprevexpr___TOP__quad_uart_tb__DOT__presetn__0 
        = vlSelfRef.quad_uart_tb__DOT__presetn;
}

bool Vquad_uart_tb___024root___trigger_anySet__act(const VlUnpacked<QData/*63:0*/, 1> &in) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquad_uart_tb___024root___trigger_anySet__act\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        if (in[n]) {
            return (1U);
        }
        n = ((IData)(1U) + n);
    } while ((1U > n));
    return (0U);
}

void Vquad_uart_tb___024root___act_comb__TOP__0(Vquad_uart_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquad_uart_tb___024root___act_comb__TOP__0\n"); );
    Vquad_uart_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_access;
    quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_access = 0;
    // Body
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__pclk) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT____Vtogcov__pclk))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 0, vlSelfRef.quad_uart_tb__DOT__pclk, vlSelfRef.quad_uart_tb__DOT____Vtogcov__pclk);
        vlSelfRef.quad_uart_tb__DOT____Vtogcov__pclk 
            = vlSelfRef.quad_uart_tb__DOT__pclk;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__presetn) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT____Vtogcov__presetn))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2, vlSelfRef.quad_uart_tb__DOT__presetn, vlSelfRef.quad_uart_tb__DOT____Vtogcov__presetn);
        vlSelfRef.quad_uart_tb__DOT____Vtogcov__presetn 
            = vlSelfRef.quad_uart_tb__DOT__presetn;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__psel) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT____Vtogcov__psel))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 4, vlSelfRef.quad_uart_tb__DOT__psel, vlSelfRef.quad_uart_tb__DOT____Vtogcov__psel);
        vlSelfRef.quad_uart_tb__DOT____Vtogcov__psel 
            = vlSelfRef.quad_uart_tb__DOT__psel;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__penable) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT____Vtogcov__penable))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 6, vlSelfRef.quad_uart_tb__DOT__penable, vlSelfRef.quad_uart_tb__DOT____Vtogcov__penable);
        vlSelfRef.quad_uart_tb__DOT____Vtogcov__penable 
            = vlSelfRef.quad_uart_tb__DOT__penable;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__pwrite) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT____Vtogcov__pwrite))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 8, vlSelfRef.quad_uart_tb__DOT__pwrite, vlSelfRef.quad_uart_tb__DOT____Vtogcov__pwrite);
        vlSelfRef.quad_uart_tb__DOT____Vtogcov__pwrite 
            = vlSelfRef.quad_uart_tb__DOT__pwrite;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__paddr) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT____Vtogcov__paddr))) {
        VL_COV_TOGGLE_CHG_ST_I(12, vlSymsp->__Vcoverage + 10, vlSelfRef.quad_uart_tb__DOT__paddr, vlSelfRef.quad_uart_tb__DOT____Vtogcov__paddr);
        vlSelfRef.quad_uart_tb__DOT____Vtogcov__paddr 
            = vlSelfRef.quad_uart_tb__DOT__paddr;
    }
    if ((vlSelfRef.quad_uart_tb__DOT__pwdata ^ vlSelfRef.quad_uart_tb__DOT____Vtogcov__pwdata)) {
        VL_COV_TOGGLE_CHG_ST_I(32, vlSymsp->__Vcoverage + 34, vlSelfRef.quad_uart_tb__DOT__pwdata, vlSelfRef.quad_uart_tb__DOT____Vtogcov__pwdata);
        vlSelfRef.quad_uart_tb__DOT____Vtogcov__pwdata 
            = vlSelfRef.quad_uart_tb__DOT__pwdata;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT____Vtogcov__uart_rx))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 98, vlSelfRef.quad_uart_tb__DOT__uart_rx, vlSelfRef.quad_uart_tb__DOT____Vtogcov__uart_rx);
        vlSelfRef.quad_uart_tb__DOT____Vtogcov__uart_rx 
            = vlSelfRef.quad_uart_tb__DOT__uart_rx;
    }
    if ((1U & ((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
               ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__uart_rx)))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 774, vlSelfRef.quad_uart_tb__DOT__uart_rx, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__uart_rx);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__uart_rx 
            = (1U & (IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx));
    }
    if ((1U & (((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
                >> 1U) ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__uart_rx)))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 793, 
                               ((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
                                >> 1U), vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__uart_rx);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__uart_rx 
            = (1U & ((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
                     >> 1U));
    }
    if ((1U & (((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
                >> 2U) ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__uart_rx)))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 812, 
                               ((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
                                >> 2U), vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__uart_rx);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__uart_rx 
            = (1U & ((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
                     >> 2U));
    }
    if ((IData)((((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
                  >> 3U) ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__uart_rx)))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 831, 
                               ((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
                                >> 3U), vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__uart_rx);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__uart_rx 
            = (1U & ((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
                     >> 3U));
    }
    quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_access 
        = ((IData)(vlSelfRef.quad_uart_tb__DOT__psel) 
           & (IData)(vlSelfRef.quad_uart_tb__DOT__penable));
    if (((IData)(quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_access) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__apb_access))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 734, quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_access, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__apb_access);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__apb_access 
            = quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_access;
    }
    vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_wr 
        = ((IData)(vlSelfRef.quad_uart_tb__DOT__pwrite) 
           & (IData)(quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_access));
    vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_rd 
        = ((~ (IData)(vlSelfRef.quad_uart_tb__DOT__pwrite)) 
           & (IData)(quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_access));
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_wr) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__apb_wr))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 736, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_wr, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__apb_wr);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__apb_wr 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_wr;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_rd) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__apb_rd))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 738, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_rd, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__apb_rd);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__apb_rd 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_rd;
    }
}

void Vquad_uart_tb___024root___eval_act(Vquad_uart_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquad_uart_tb___024root___eval_act\n"); );
    Vquad_uart_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((0x000000000000000dULL & vlSelfRef.__VactTriggered[0U])) {
        Vquad_uart_tb___024root___act_comb__TOP__0(vlSelf);
    }
}

void Vquad_uart_tb___024root___nba_sequent__TOP__0(Vquad_uart_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquad_uart_tb___024root___nba_sequent__TOP__0\n"); );
    Vquad_uart_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.quad_uart_tb__DOT__presetn) {
        if ((1U & (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire))) {
            ++(vlSymsp->__Vcoverage[785]);
            vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch0__uart_tx 
                = (1U & vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx0);
            vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch0__irq = 1U;
        } else if (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT__rx_d) 
                    != (1U & (IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx)))) {
            ++(vlSymsp->__Vcoverage[784]);
            vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch0__irq = 1U;
        } else if ((1U & vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg0)) {
            ++(vlSymsp->__Vcoverage[782]);
            vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch0__irq = 0U;
        } else {
            ++(vlSymsp->__Vcoverage[783]);
        }
        ++(vlSymsp->__Vcoverage[787]);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT__rx_d 
            = (1U & (IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx));
    } else {
        ++(vlSymsp->__Vcoverage[786]);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT__rx_d = 1U;
        vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch0__uart_tx = 1U;
        vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch0__irq = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.quad_uart_tb__DOT__presetn)))) {
        ++(vlSymsp->__Vcoverage[788]);
    }
    if (vlSelfRef.quad_uart_tb__DOT__presetn) {
        ++(vlSymsp->__Vcoverage[789]);
    }
    ++(vlSymsp->__Vcoverage[790]);
    if (vlSelfRef.quad_uart_tb__DOT__presetn) {
        if ((2U & (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire))) {
            ++(vlSymsp->__Vcoverage[804]);
            vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch1__uart_tx 
                = (1U & vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx1);
            vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch1__irq = 1U;
        } else if (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT__rx_d) 
                    != (1U & ((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
                              >> 1U)))) {
            ++(vlSymsp->__Vcoverage[803]);
            vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch1__irq = 1U;
        } else if ((1U & vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg1)) {
            ++(vlSymsp->__Vcoverage[801]);
            vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch1__irq = 0U;
        } else {
            ++(vlSymsp->__Vcoverage[802]);
        }
        ++(vlSymsp->__Vcoverage[806]);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT__rx_d 
            = (1U & ((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
                     >> 1U));
    } else {
        ++(vlSymsp->__Vcoverage[805]);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT__rx_d = 1U;
        vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch1__uart_tx = 1U;
        vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch1__irq = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.quad_uart_tb__DOT__presetn)))) {
        ++(vlSymsp->__Vcoverage[807]);
    }
    if (vlSelfRef.quad_uart_tb__DOT__presetn) {
        ++(vlSymsp->__Vcoverage[808]);
    }
    ++(vlSymsp->__Vcoverage[809]);
    if (vlSelfRef.quad_uart_tb__DOT__presetn) {
        if ((4U & (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire))) {
            ++(vlSymsp->__Vcoverage[823]);
            vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch2__uart_tx 
                = (1U & vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx2);
            vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch2__irq = 1U;
        } else if (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT__rx_d) 
                    != (1U & ((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
                              >> 2U)))) {
            ++(vlSymsp->__Vcoverage[822]);
            vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch2__irq = 1U;
        } else if ((1U & vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg2)) {
            ++(vlSymsp->__Vcoverage[820]);
            vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch2__irq = 0U;
        } else {
            ++(vlSymsp->__Vcoverage[821]);
        }
        ++(vlSymsp->__Vcoverage[825]);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT__rx_d 
            = (1U & ((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
                     >> 2U));
    } else {
        ++(vlSymsp->__Vcoverage[824]);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT__rx_d = 1U;
        vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch2__uart_tx = 1U;
        vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch2__irq = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.quad_uart_tb__DOT__presetn)))) {
        ++(vlSymsp->__Vcoverage[826]);
    }
    if (vlSelfRef.quad_uart_tb__DOT__presetn) {
        ++(vlSymsp->__Vcoverage[827]);
    }
    ++(vlSymsp->__Vcoverage[828]);
    if (vlSelfRef.quad_uart_tb__DOT__presetn) {
        if ((8U & (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire))) {
            ++(vlSymsp->__Vcoverage[842]);
            vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch3__uart_tx 
                = (1U & vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx3);
            vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch3__irq = 1U;
        } else if (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT__rx_d) 
                    != (1U & ((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
                              >> 3U)))) {
            ++(vlSymsp->__Vcoverage[841]);
            vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch3__irq = 1U;
        } else if ((1U & vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg3)) {
            ++(vlSymsp->__Vcoverage[839]);
            vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch3__irq = 0U;
        } else {
            ++(vlSymsp->__Vcoverage[840]);
        }
        ++(vlSymsp->__Vcoverage[844]);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT__rx_d 
            = (1U & ((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
                     >> 3U));
    } else {
        ++(vlSymsp->__Vcoverage[843]);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT__rx_d = 1U;
        vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch3__uart_tx = 1U;
        vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch3__irq = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.quad_uart_tb__DOT__presetn)))) {
        ++(vlSymsp->__Vcoverage[845]);
    }
    if (vlSelfRef.quad_uart_tb__DOT__presetn) {
        ++(vlSymsp->__Vcoverage[846]);
    }
    ++(vlSymsp->__Vcoverage[847]);
    if (vlSelfRef.quad_uart_tb__DOT__presetn) {
        if (vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_rd) {
            if ((0x00000080U & (IData)(vlSelfRef.quad_uart_tb__DOT__paddr))) {
                ++(vlSymsp->__Vcoverage[765]);
                vlSelfRef.quad_uart_tb__DOT__prdata = 0U;
            } else if ((0x00000040U & (IData)(vlSelfRef.quad_uart_tb__DOT__paddr))) {
                if ((0x00000020U & (IData)(vlSelfRef.quad_uart_tb__DOT__paddr))) {
                    ++(vlSymsp->__Vcoverage[765]);
                    vlSelfRef.quad_uart_tb__DOT__prdata = 0U;
                } else if ((0x00000010U & (IData)(vlSelfRef.quad_uart_tb__DOT__paddr))) {
                    ++(vlSymsp->__Vcoverage[765]);
                    vlSelfRef.quad_uart_tb__DOT__prdata = 0U;
                } else if ((8U & (IData)(vlSelfRef.quad_uart_tb__DOT__paddr))) {
                    ++(vlSymsp->__Vcoverage[765]);
                    vlSelfRef.quad_uart_tb__DOT__prdata = 0U;
                } else if ((4U & (IData)(vlSelfRef.quad_uart_tb__DOT__paddr))) {
                    ++(vlSymsp->__Vcoverage[765]);
                    vlSelfRef.quad_uart_tb__DOT__prdata = 0U;
                } else {
                    ++(vlSymsp->__Vcoverage[764]);
                    vlSelfRef.quad_uart_tb__DOT__prdata 
                        = vlSelfRef.quad_uart_tb__DOT__irq;
                }
            } else if ((0x00000020U & (IData)(vlSelfRef.quad_uart_tb__DOT__paddr))) {
                if ((0x00000010U & (IData)(vlSelfRef.quad_uart_tb__DOT__paddr))) {
                    if ((8U & (IData)(vlSelfRef.quad_uart_tb__DOT__paddr))) {
                        ++(vlSymsp->__Vcoverage[765]);
                        vlSelfRef.quad_uart_tb__DOT__prdata = 0U;
                    } else if ((4U & (IData)(vlSelfRef.quad_uart_tb__DOT__paddr))) {
                        ++(vlSymsp->__Vcoverage[763]);
                        vlSelfRef.quad_uart_tb__DOT__prdata 
                            = vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx3;
                    } else {
                        ++(vlSymsp->__Vcoverage[762]);
                        vlSelfRef.quad_uart_tb__DOT__prdata 
                            = vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg3;
                    }
                } else if ((8U & (IData)(vlSelfRef.quad_uart_tb__DOT__paddr))) {
                    ++(vlSymsp->__Vcoverage[765]);
                    vlSelfRef.quad_uart_tb__DOT__prdata = 0U;
                } else if ((4U & (IData)(vlSelfRef.quad_uart_tb__DOT__paddr))) {
                    ++(vlSymsp->__Vcoverage[761]);
                    vlSelfRef.quad_uart_tb__DOT__prdata 
                        = vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx2;
                } else {
                    ++(vlSymsp->__Vcoverage[760]);
                    vlSelfRef.quad_uart_tb__DOT__prdata 
                        = vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg2;
                }
            } else if ((0x00000010U & (IData)(vlSelfRef.quad_uart_tb__DOT__paddr))) {
                if ((8U & (IData)(vlSelfRef.quad_uart_tb__DOT__paddr))) {
                    ++(vlSymsp->__Vcoverage[765]);
                    vlSelfRef.quad_uart_tb__DOT__prdata = 0U;
                } else if ((4U & (IData)(vlSelfRef.quad_uart_tb__DOT__paddr))) {
                    ++(vlSymsp->__Vcoverage[759]);
                    vlSelfRef.quad_uart_tb__DOT__prdata 
                        = vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx1;
                } else {
                    ++(vlSymsp->__Vcoverage[758]);
                    vlSelfRef.quad_uart_tb__DOT__prdata 
                        = vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg1;
                }
            } else if ((8U & (IData)(vlSelfRef.quad_uart_tb__DOT__paddr))) {
                ++(vlSymsp->__Vcoverage[765]);
                vlSelfRef.quad_uart_tb__DOT__prdata = 0U;
            } else if ((4U & (IData)(vlSelfRef.quad_uart_tb__DOT__paddr))) {
                ++(vlSymsp->__Vcoverage[757]);
                vlSelfRef.quad_uart_tb__DOT__prdata 
                    = vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx0;
            } else {
                ++(vlSymsp->__Vcoverage[756]);
                vlSelfRef.quad_uart_tb__DOT__prdata 
                    = vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg0;
            }
            ++(vlSymsp->__Vcoverage[766]);
        } else {
            ++(vlSymsp->__Vcoverage[767]);
        }
    } else {
        ++(vlSymsp->__Vcoverage[768]);
        vlSelfRef.quad_uart_tb__DOT__prdata = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.quad_uart_tb__DOT__presetn)))) {
        ++(vlSymsp->__Vcoverage[769]);
    }
    if (vlSelfRef.quad_uart_tb__DOT__presetn) {
        ++(vlSymsp->__Vcoverage[770]);
    }
    ++(vlSymsp->__Vcoverage[771]);
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT__rx_d) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__rx_d))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 780, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT__rx_d, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__rx_d);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__rx_d 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT__rx_d;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch0__uart_tx) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__uart_tx))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 776, vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch0__uart_tx, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__uart_tx);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__uart_tx 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch0__uart_tx;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch0__irq) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__irq))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 778, vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch0__irq, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__irq);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__irq 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch0__irq;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT__rx_d) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__rx_d))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 799, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT__rx_d, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__rx_d);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__rx_d 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT__rx_d;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch1__uart_tx) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__uart_tx))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 795, vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch1__uart_tx, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__uart_tx);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__uart_tx 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch1__uart_tx;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch1__irq) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__irq))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 797, vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch1__irq, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__irq);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__irq 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch1__irq;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT__rx_d) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__rx_d))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 818, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT__rx_d, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__rx_d);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__rx_d 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT__rx_d;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch2__uart_tx) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__uart_tx))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 814, vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch2__uart_tx, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__uart_tx);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__uart_tx 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch2__uart_tx;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch2__irq) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__irq))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 816, vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch2__irq, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__irq);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__irq 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch2__irq;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT__rx_d) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__rx_d))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 837, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT__rx_d, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__rx_d);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__rx_d 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT__rx_d;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch3__uart_tx) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__uart_tx))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 833, vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch3__uart_tx, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__uart_tx);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__uart_tx 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch3__uart_tx;
    }
    vlSelfRef.quad_uart_tb__DOT__uart_tx = ((((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch3__uart_tx) 
                                              << 3U) 
                                             | ((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch2__uart_tx) 
                                                << 2U)) 
                                            | (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch1__uart_tx) 
                                                << 1U) 
                                               | (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch0__uart_tx)));
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch3__irq) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__irq))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 835, vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch3__irq, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__irq);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__irq 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch3__irq;
    }
    vlSelfRef.quad_uart_tb__DOT__irq = ((((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch3__irq) 
                                          << 3U) | 
                                         ((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch2__irq) 
                                          << 2U)) | 
                                        (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch1__irq) 
                                          << 1U) | (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch0__irq)));
    if ((vlSelfRef.quad_uart_tb__DOT__prdata ^ vlSelfRef.quad_uart_tb__DOT____Vtogcov__prdata)) {
        VL_COV_TOGGLE_CHG_ST_I(32, vlSymsp->__Vcoverage + 106, vlSelfRef.quad_uart_tb__DOT__prdata, vlSelfRef.quad_uart_tb__DOT____Vtogcov__prdata);
        vlSelfRef.quad_uart_tb__DOT____Vtogcov__prdata 
            = vlSelfRef.quad_uart_tb__DOT__prdata;
    }
    if (vlSelfRef.quad_uart_tb__DOT__presetn) {
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire = 0U;
        if (vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_wr) {
            if ((0x00000080U & (IData)(vlSelfRef.quad_uart_tb__DOT__paddr))) {
                ++(vlSymsp->__Vcoverage[748]);
            } else if ((0x00000040U & (IData)(vlSelfRef.quad_uart_tb__DOT__paddr))) {
                ++(vlSymsp->__Vcoverage[748]);
            } else if ((0x00000020U & (IData)(vlSelfRef.quad_uart_tb__DOT__paddr))) {
                if ((0x00000010U & (IData)(vlSelfRef.quad_uart_tb__DOT__paddr))) {
                    if ((8U & (IData)(vlSelfRef.quad_uart_tb__DOT__paddr))) {
                        ++(vlSymsp->__Vcoverage[748]);
                    } else if ((4U & (IData)(vlSelfRef.quad_uart_tb__DOT__paddr))) {
                        ++(vlSymsp->__Vcoverage[747]);
                        vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx3 
                            = vlSelfRef.quad_uart_tb__DOT__pwdata;
                        vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire 
                            = (8U | (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire));
                    } else {
                        ++(vlSymsp->__Vcoverage[746]);
                        vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg3 
                            = vlSelfRef.quad_uart_tb__DOT__pwdata;
                    }
                } else if ((8U & (IData)(vlSelfRef.quad_uart_tb__DOT__paddr))) {
                    ++(vlSymsp->__Vcoverage[748]);
                } else if ((4U & (IData)(vlSelfRef.quad_uart_tb__DOT__paddr))) {
                    ++(vlSymsp->__Vcoverage[745]);
                    vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx2 
                        = vlSelfRef.quad_uart_tb__DOT__pwdata;
                    vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire 
                        = (4U | (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire));
                } else {
                    ++(vlSymsp->__Vcoverage[744]);
                    vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg2 
                        = vlSelfRef.quad_uart_tb__DOT__pwdata;
                }
            } else if ((0x00000010U & (IData)(vlSelfRef.quad_uart_tb__DOT__paddr))) {
                if ((8U & (IData)(vlSelfRef.quad_uart_tb__DOT__paddr))) {
                    ++(vlSymsp->__Vcoverage[748]);
                } else if ((4U & (IData)(vlSelfRef.quad_uart_tb__DOT__paddr))) {
                    ++(vlSymsp->__Vcoverage[743]);
                    vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx1 
                        = vlSelfRef.quad_uart_tb__DOT__pwdata;
                    vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire 
                        = (2U | (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire));
                } else {
                    ++(vlSymsp->__Vcoverage[742]);
                    vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg1 
                        = vlSelfRef.quad_uart_tb__DOT__pwdata;
                }
            } else if ((8U & (IData)(vlSelfRef.quad_uart_tb__DOT__paddr))) {
                ++(vlSymsp->__Vcoverage[748]);
            } else if ((4U & (IData)(vlSelfRef.quad_uart_tb__DOT__paddr))) {
                ++(vlSymsp->__Vcoverage[741]);
                vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx0 
                    = vlSelfRef.quad_uart_tb__DOT__pwdata;
                vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire 
                    = (1U | (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire));
            } else {
                ++(vlSymsp->__Vcoverage[740]);
                vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg0 
                    = vlSelfRef.quad_uart_tb__DOT__pwdata;
            }
            ++(vlSymsp->__Vcoverage[749]);
        } else {
            ++(vlSymsp->__Vcoverage[750]);
        }
        ++(vlSymsp->__Vcoverage[752]);
    } else {
        ++(vlSymsp->__Vcoverage[751]);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg0 = 0U;
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg1 = 0U;
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg2 = 0U;
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg3 = 0U;
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx0 = 0U;
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx1 = 0U;
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx2 = 0U;
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx3 = 0U;
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.quad_uart_tb__DOT__presetn)))) {
        ++(vlSymsp->__Vcoverage[753]);
    }
    if (vlSelfRef.quad_uart_tb__DOT__presetn) {
        ++(vlSymsp->__Vcoverage[754]);
    }
    ++(vlSymsp->__Vcoverage[755]);
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__uart_tx) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT____Vtogcov__uart_tx))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 174, vlSelfRef.quad_uart_tb__DOT__uart_tx, vlSelfRef.quad_uart_tb__DOT____Vtogcov__uart_tx);
        vlSelfRef.quad_uart_tb__DOT____Vtogcov__uart_tx 
            = vlSelfRef.quad_uart_tb__DOT__uart_tx;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__irq) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT____Vtogcov__irq))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 182, vlSelfRef.quad_uart_tb__DOT__irq, vlSelfRef.quad_uart_tb__DOT____Vtogcov__irq);
        vlSelfRef.quad_uart_tb__DOT____Vtogcov__irq 
            = vlSelfRef.quad_uart_tb__DOT__irq;
    }
    if ((vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx3 
         ^ vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_tx3)) {
        VL_COV_TOGGLE_CHG_ST_I(32, vlSymsp->__Vcoverage + 658, vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx3, vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_tx3);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_tx3 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx3;
    }
    if ((vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg3 
         ^ vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_cfg3)) {
        VL_COV_TOGGLE_CHG_ST_I(32, vlSymsp->__Vcoverage + 402, vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg3, vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_cfg3);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_cfg3 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg3;
    }
    if ((vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx2 
         ^ vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_tx2)) {
        VL_COV_TOGGLE_CHG_ST_I(32, vlSymsp->__Vcoverage + 594, vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx2, vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_tx2);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_tx2 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx2;
    }
    if ((vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg2 
         ^ vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_cfg2)) {
        VL_COV_TOGGLE_CHG_ST_I(32, vlSymsp->__Vcoverage + 338, vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg2, vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_cfg2);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_cfg2 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg2;
    }
    if ((vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx1 
         ^ vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_tx1)) {
        VL_COV_TOGGLE_CHG_ST_I(32, vlSymsp->__Vcoverage + 530, vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx1, vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_tx1);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_tx1 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx1;
    }
    if ((vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg1 
         ^ vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_cfg1)) {
        VL_COV_TOGGLE_CHG_ST_I(32, vlSymsp->__Vcoverage + 274, vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg1, vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_cfg1);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_cfg1 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg1;
    }
    if ((vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx0 
         ^ vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_tx0)) {
        VL_COV_TOGGLE_CHG_ST_I(32, vlSymsp->__Vcoverage + 466, vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx0, vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_tx0);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_tx0 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_tx0;
    }
    if ((vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg0 
         ^ vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_cfg0)) {
        VL_COV_TOGGLE_CHG_ST_I(32, vlSymsp->__Vcoverage + 210, vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg0, vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_cfg0);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_cfg0 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT__ch_cfg0;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__tx_fire))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 722, vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire, vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__tx_fire);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT____Vtogcov__tx_fire 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire;
    }
    if ((1U & ((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire) 
               ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__tx_fire)))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 772, vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__tx_fire);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__tx_fire 
            = (1U & (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire));
    }
    if ((1U & (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire) 
                >> 1U) ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__tx_fire)))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 791, 
                               ((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire) 
                                >> 1U), vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__tx_fire);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__tx_fire 
            = (1U & ((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire) 
                     >> 1U));
    }
    if ((1U & (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire) 
                >> 2U) ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__tx_fire)))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 810, 
                               ((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire) 
                                >> 2U), vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__tx_fire);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__tx_fire 
            = (1U & ((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire) 
                     >> 2U));
    }
    if ((IData)((((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire) 
                  >> 3U) ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__tx_fire)))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 829, 
                               ((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire) 
                                >> 3U), vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__tx_fire);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__tx_fire 
            = (1U & ((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__tx_fire) 
                     >> 3U));
    }
}

void Vquad_uart_tb___024root___nba_comb__TOP__0(Vquad_uart_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquad_uart_tb___024root___nba_comb__TOP__0\n"); );
    Vquad_uart_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_access;
    quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_access = 0;
    // Body
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__pclk) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT____Vtogcov__pclk))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 0, vlSelfRef.quad_uart_tb__DOT__pclk, vlSelfRef.quad_uart_tb__DOT____Vtogcov__pclk);
        vlSelfRef.quad_uart_tb__DOT____Vtogcov__pclk 
            = vlSelfRef.quad_uart_tb__DOT__pclk;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__presetn) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT____Vtogcov__presetn))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2, vlSelfRef.quad_uart_tb__DOT__presetn, vlSelfRef.quad_uart_tb__DOT____Vtogcov__presetn);
        vlSelfRef.quad_uart_tb__DOT____Vtogcov__presetn 
            = vlSelfRef.quad_uart_tb__DOT__presetn;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__psel) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT____Vtogcov__psel))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 4, vlSelfRef.quad_uart_tb__DOT__psel, vlSelfRef.quad_uart_tb__DOT____Vtogcov__psel);
        vlSelfRef.quad_uart_tb__DOT____Vtogcov__psel 
            = vlSelfRef.quad_uart_tb__DOT__psel;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__penable) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT____Vtogcov__penable))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 6, vlSelfRef.quad_uart_tb__DOT__penable, vlSelfRef.quad_uart_tb__DOT____Vtogcov__penable);
        vlSelfRef.quad_uart_tb__DOT____Vtogcov__penable 
            = vlSelfRef.quad_uart_tb__DOT__penable;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__pwrite) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT____Vtogcov__pwrite))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 8, vlSelfRef.quad_uart_tb__DOT__pwrite, vlSelfRef.quad_uart_tb__DOT____Vtogcov__pwrite);
        vlSelfRef.quad_uart_tb__DOT____Vtogcov__pwrite 
            = vlSelfRef.quad_uart_tb__DOT__pwrite;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__paddr) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT____Vtogcov__paddr))) {
        VL_COV_TOGGLE_CHG_ST_I(12, vlSymsp->__Vcoverage + 10, vlSelfRef.quad_uart_tb__DOT__paddr, vlSelfRef.quad_uart_tb__DOT____Vtogcov__paddr);
        vlSelfRef.quad_uart_tb__DOT____Vtogcov__paddr 
            = vlSelfRef.quad_uart_tb__DOT__paddr;
    }
    if ((vlSelfRef.quad_uart_tb__DOT__pwdata ^ vlSelfRef.quad_uart_tb__DOT____Vtogcov__pwdata)) {
        VL_COV_TOGGLE_CHG_ST_I(32, vlSymsp->__Vcoverage + 34, vlSelfRef.quad_uart_tb__DOT__pwdata, vlSelfRef.quad_uart_tb__DOT____Vtogcov__pwdata);
        vlSelfRef.quad_uart_tb__DOT____Vtogcov__pwdata 
            = vlSelfRef.quad_uart_tb__DOT__pwdata;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT____Vtogcov__uart_rx))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 98, vlSelfRef.quad_uart_tb__DOT__uart_rx, vlSelfRef.quad_uart_tb__DOT____Vtogcov__uart_rx);
        vlSelfRef.quad_uart_tb__DOT____Vtogcov__uart_rx 
            = vlSelfRef.quad_uart_tb__DOT__uart_rx;
    }
    if ((1U & ((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
               ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__uart_rx)))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 774, vlSelfRef.quad_uart_tb__DOT__uart_rx, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__uart_rx);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__uart_rx 
            = (1U & (IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx));
    }
    if ((1U & (((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
                >> 1U) ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__uart_rx)))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 793, 
                               ((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
                                >> 1U), vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__uart_rx);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__uart_rx 
            = (1U & ((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
                     >> 1U));
    }
    if ((1U & (((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
                >> 2U) ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__uart_rx)))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 812, 
                               ((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
                                >> 2U), vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__uart_rx);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__uart_rx 
            = (1U & ((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
                     >> 2U));
    }
    if ((IData)((((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
                  >> 3U) ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__uart_rx)))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 831, 
                               ((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
                                >> 3U), vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__uart_rx);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__uart_rx 
            = (1U & ((IData)(vlSelfRef.quad_uart_tb__DOT__uart_rx) 
                     >> 3U));
    }
    quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_access 
        = ((IData)(vlSelfRef.quad_uart_tb__DOT__psel) 
           & (IData)(vlSelfRef.quad_uart_tb__DOT__penable));
    if (((IData)(quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_access) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__apb_access))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 734, quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_access, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__apb_access);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__apb_access 
            = quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_access;
    }
    vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_rd 
        = ((~ (IData)(vlSelfRef.quad_uart_tb__DOT__pwrite)) 
           & (IData)(quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_access));
    vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_wr 
        = ((IData)(vlSelfRef.quad_uart_tb__DOT__pwrite) 
           & (IData)(quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_access));
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_rd) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__apb_rd))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 738, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_rd, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__apb_rd);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__apb_rd 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_rd;
    }
    if (((IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_wr) 
         ^ (IData)(vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__apb_wr))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 736, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_wr, vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__apb_wr);
        vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__apb_wr 
            = vlSelfRef.quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_wr;
    }
}

void Vquad_uart_tb___024root___eval_nba(Vquad_uart_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquad_uart_tb___024root___eval_nba\n"); );
    Vquad_uart_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((3ULL & vlSelfRef.__VnbaTriggered[0U])) {
        Vquad_uart_tb___024root___nba_sequent__TOP__0(vlSelf);
    }
    if ((0x000000000000000dULL & vlSelfRef.__VnbaTriggered[0U])) {
        Vquad_uart_tb___024root___nba_comb__TOP__0(vlSelf);
    }
}

void Vquad_uart_tb___024root___timing_ready(Vquad_uart_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquad_uart_tb___024root___timing_ready\n"); );
    Vquad_uart_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1ULL & vlSelfRef.__VactTriggered[0U])) {
        vlSelfRef.__VtrigSched_hecc72097__0.ready("@(posedge quad_uart_tb.pclk)");
    }
    if ((8ULL & vlSelfRef.__VactTriggered[0U])) {
        vlSelfRef.__VtrigSched_hecc7213b__0.ready("@(negedge quad_uart_tb.pclk)");
    }
}

void Vquad_uart_tb___024root___timing_resume(Vquad_uart_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquad_uart_tb___024root___timing_resume\n"); );
    Vquad_uart_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__VtrigSched_hecc72097__0.moveToResumeQueue(
                                                          "@(posedge quad_uart_tb.pclk)");
    vlSelfRef.__VtrigSched_hecc7213b__0.moveToResumeQueue(
                                                          "@(negedge quad_uart_tb.pclk)");
    vlSelfRef.__VtrigSched_hecc72097__0.resume("@(posedge quad_uart_tb.pclk)");
    vlSelfRef.__VtrigSched_hecc7213b__0.resume("@(negedge quad_uart_tb.pclk)");
    if ((4ULL & vlSelfRef.__VactTriggered[0U])) {
        vlSelfRef.__VdlySched.resume();
    }
}

void Vquad_uart_tb___024root___trigger_orInto__act_vec_vec(VlUnpacked<QData/*63:0*/, 1> &out, const VlUnpacked<QData/*63:0*/, 1> &in) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquad_uart_tb___024root___trigger_orInto__act_vec_vec\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        out[n] = (out[n] | in[n]);
        n = ((IData)(1U) + n);
    } while ((0U >= n));
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vquad_uart_tb___024root___dump_triggers__act(const VlUnpacked<QData/*63:0*/, 1> &triggers, const std::string &tag);
#endif  // VL_DEBUG

bool Vquad_uart_tb___024root___eval_phase__act(Vquad_uart_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquad_uart_tb___024root___eval_phase__act\n"); );
    Vquad_uart_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ __VactExecute;
    // Body
    Vquad_uart_tb___024root___eval_triggers_vec__act(vlSelf);
    Vquad_uart_tb___024root___timing_ready(vlSelf);
    Vquad_uart_tb___024root___trigger_orInto__act_vec_vec(vlSelfRef.__VactTriggered, vlSelfRef.__VactTriggeredAcc);
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        Vquad_uart_tb___024root___dump_triggers__act(vlSelfRef.__VactTriggered, "act"s);
    }
#endif
    Vquad_uart_tb___024root___trigger_orInto__act_vec_vec(vlSelfRef.__VnbaTriggered, vlSelfRef.__VactTriggered);
    __VactExecute = Vquad_uart_tb___024root___trigger_anySet__act(vlSelfRef.__VactTriggered);
    if (__VactExecute) {
        vlSelfRef.__VactTriggeredAcc.fill(0ULL);
        Vquad_uart_tb___024root___timing_resume(vlSelf);
        Vquad_uart_tb___024root___eval_act(vlSelf);
    }
    return (__VactExecute);
}

bool Vquad_uart_tb___024root___eval_phase__inact(Vquad_uart_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquad_uart_tb___024root___eval_phase__inact\n"); );
    Vquad_uart_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ __VinactExecute;
    // Body
    __VinactExecute = vlSelfRef.__VdlySched.awaitingZeroDelay();
    if (__VinactExecute) {
        VL_FATAL_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 3, "", "ZERODLY: Design Verilated with '--no-sched-zero-delay', but #0 delay executed at runtime");
    }
    return (__VinactExecute);
}

void Vquad_uart_tb___024root___trigger_clear__act(VlUnpacked<QData/*63:0*/, 1> &out) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquad_uart_tb___024root___trigger_clear__act\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        out[n] = 0ULL;
        n = ((IData)(1U) + n);
    } while ((1U > n));
}

bool Vquad_uart_tb___024root___eval_phase__nba(Vquad_uart_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquad_uart_tb___024root___eval_phase__nba\n"); );
    Vquad_uart_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ __VnbaExecute;
    // Body
    __VnbaExecute = Vquad_uart_tb___024root___trigger_anySet__act(vlSelfRef.__VnbaTriggered);
    if (__VnbaExecute) {
        Vquad_uart_tb___024root___eval_nba(vlSelf);
        Vquad_uart_tb___024root___trigger_clear__act(vlSelfRef.__VnbaTriggered);
    }
    return (__VnbaExecute);
}

void Vquad_uart_tb___024root___eval(Vquad_uart_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquad_uart_tb___024root___eval\n"); );
    Vquad_uart_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    IData/*31:0*/ __VnbaIterCount;
    // Body
    __VnbaIterCount = 0U;
    do {
        if (VL_UNLIKELY(((0x00002710U < __VnbaIterCount)))) {
#ifdef VL_DEBUG
            Vquad_uart_tb___024root___dump_triggers__act(vlSelfRef.__VnbaTriggered, "nba"s);
#endif
            VL_FATAL_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 3, "", "DIDNOTCONVERGE: NBA region did not converge after '--converge-limit' of 10000 tries");
        }
        __VnbaIterCount = ((IData)(1U) + __VnbaIterCount);
        vlSelfRef.__VinactIterCount = 0U;
        do {
            if (VL_UNLIKELY(((0x00002710U < vlSelfRef.__VinactIterCount)))) {
                VL_FATAL_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 3, "", "DIDNOTCONVERGE: Inactive region did not converge after '--converge-limit' of 10000 tries");
            }
            vlSelfRef.__VinactIterCount = ((IData)(1U) 
                                           + vlSelfRef.__VinactIterCount);
            vlSelfRef.__VactIterCount = 0U;
            do {
                if (VL_UNLIKELY(((0x00002710U < vlSelfRef.__VactIterCount)))) {
#ifdef VL_DEBUG
                    Vquad_uart_tb___024root___dump_triggers__act(vlSelfRef.__VactTriggered, "act"s);
#endif
                    VL_FATAL_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/inputs/verification/tb/quad_uart_tb.sv", 3, "", "DIDNOTCONVERGE: Active region did not converge after '--converge-limit' of 10000 tries");
                }
                vlSelfRef.__VactIterCount = ((IData)(1U) 
                                             + vlSelfRef.__VactIterCount);
                vlSelfRef.__VactPhaseResult = Vquad_uart_tb___024root___eval_phase__act(vlSelf);
            } while (vlSelfRef.__VactPhaseResult);
            vlSelfRef.__VinactPhaseResult = Vquad_uart_tb___024root___eval_phase__inact(vlSelf);
        } while (vlSelfRef.__VinactPhaseResult);
        vlSelfRef.__VnbaPhaseResult = Vquad_uart_tb___024root___eval_phase__nba(vlSelf);
    } while (vlSelfRef.__VnbaPhaseResult);
}

void Vquad_uart_tb___024root____VbeforeTrig_hecc72097__0(Vquad_uart_tb___024root* vlSelf, const char* __VeventDescription) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquad_uart_tb___024root____VbeforeTrig_hecc72097__0\n"); );
    Vquad_uart_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    VlUnpacked<QData/*63:0*/, 1> __VTmp;
    // Body
    __VTmp[0U] = (QData)((IData)(((((~ (IData)(vlSelfRef.quad_uart_tb__DOT__pclk)) 
                                    & (IData)(vlSelfRef.__Vtrigprevexpr___TOP__quad_uart_tb__DOT__pclk__0)) 
                                   << 3U) | ((IData)(vlSelfRef.quad_uart_tb__DOT__pclk) 
                                             & (~ (IData)(vlSelfRef.__Vtrigprevexpr___TOP__quad_uart_tb__DOT__pclk__0))))));
    vlSelfRef.__Vtrigprevexpr___TOP__quad_uart_tb__DOT__pclk__0 
        = vlSelfRef.quad_uart_tb__DOT__pclk;
    if ((1ULL & __VTmp[0U])) {
        vlSelfRef.__VtrigSched_hecc72097__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc72097__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc72097__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc72097__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc72097__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc72097__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc72097__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc72097__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc72097__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc72097__0.ready(__VeventDescription);
    }
    if ((8ULL & __VTmp[0U])) {
        vlSelfRef.__VtrigSched_hecc7213b__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc7213b__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc7213b__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc7213b__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc7213b__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc7213b__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc7213b__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc7213b__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc7213b__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc7213b__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc7213b__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc7213b__0.ready(__VeventDescription);
    }
    vlSelfRef.__VactTriggeredAcc[0U] = (vlSelfRef.__VactTriggeredAcc[0U] 
                                        | __VTmp[0U]);
}

void Vquad_uart_tb___024root____VbeforeTrig_hecc7213b__0(Vquad_uart_tb___024root* vlSelf, const char* __VeventDescription) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquad_uart_tb___024root____VbeforeTrig_hecc7213b__0\n"); );
    Vquad_uart_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    VlUnpacked<QData/*63:0*/, 1> __VTmp;
    // Body
    __VTmp[0U] = (QData)((IData)(((((~ (IData)(vlSelfRef.quad_uart_tb__DOT__pclk)) 
                                    & (IData)(vlSelfRef.__Vtrigprevexpr___TOP__quad_uart_tb__DOT__pclk__0)) 
                                   << 3U) | ((IData)(vlSelfRef.quad_uart_tb__DOT__pclk) 
                                             & (~ (IData)(vlSelfRef.__Vtrigprevexpr___TOP__quad_uart_tb__DOT__pclk__0))))));
    vlSelfRef.__Vtrigprevexpr___TOP__quad_uart_tb__DOT__pclk__0 
        = vlSelfRef.quad_uart_tb__DOT__pclk;
    if ((1ULL & __VTmp[0U])) {
        vlSelfRef.__VtrigSched_hecc72097__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc72097__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc72097__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc72097__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc72097__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc72097__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc72097__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc72097__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc72097__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc72097__0.ready(__VeventDescription);
    }
    if ((8ULL & __VTmp[0U])) {
        vlSelfRef.__VtrigSched_hecc7213b__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc7213b__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc7213b__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc7213b__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc7213b__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc7213b__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc7213b__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc7213b__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc7213b__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc7213b__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc7213b__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hecc7213b__0.ready(__VeventDescription);
    }
    vlSelfRef.__VactTriggeredAcc[0U] = (vlSelfRef.__VactTriggeredAcc[0U] 
                                        | __VTmp[0U]);
}

#ifdef VL_DEBUG
void Vquad_uart_tb___024root___eval_debug_assertions(Vquad_uart_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquad_uart_tb___024root___eval_debug_assertions\n"); );
    Vquad_uart_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}
#endif  // VL_DEBUG
