# Silicon Feedback Closure Report v1.15

- chip_id: `quad_uart`
- run_id: `T-QUAD-UART`
- execution: `20260523-083747`
- report_family: `silicon_feedback_report`
- report_version: `v1.15`
- generated_at: `2026-05-23T08:38:09.860668+08:00`

## Summary

- verdict: `BLOCKED`
- rows_total: `3`
- pass: `0`
- warn: `0`
- blocked: `1`
- not_available: `2`

## Section Status

| section | row_id | status | notes | evidence_count |
|---|---|---|---|---|
| bringup | v115_power_on_record | NOT_AVAILABLE | power-on verdict | 1 |
| bringup | v115_functional_bringup_result | NOT_AVAILABLE | functional bring-up verdict | 1 |
| silicon_claim | v115_silicon_proven_claim_record | BLOCKED | bounded silicon claim verdict | 1 |

## Action Items

- action_item_count: `1`

Canonical truth remains governed JSON objects and evidence references.
