Vquad_uart_tb__ALL.o: Vquad_uart_tb__ALL.cpp Vquad_uart_tb.cpp \
  Vquad_uart_tb__pch.h /usr/local/share/verilator/include/verilated.h \
  /usr/local/share/verilator/include/verilated_config.h \
  /usr/local/share/verilator/include/verilatedos.h \
  /usr/local/share/verilator/include/verilated_types.h \
  /usr/local/share/verilator/include/verilated_funcs.h \
  Vquad_uart_tb__Syms.h Vquad_uart_tb.h \
  /usr/local/share/verilator/include/verilated_cov.h \
  Vquad_uart_tb___024root.h \
  /usr/local/share/verilator/include/verilated_timing.h \
  Vquad_uart_tb___024root__0.cpp Vquad_uart_tb__main.cpp \
  Vquad_uart_tb___024root__Slow.cpp Vquad_uart_tb___024root__0__Slow.cpp \
  Vquad_uart_tb__Syms__Slow.cpp
