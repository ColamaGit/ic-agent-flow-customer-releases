# Tapeout Package Readiness Report v1.14

- chip_id: `quad_uart`
- run_id: `T-QUAD-UART`
- execution: `20260523-083747`
- report_family: `tapeout_package_report`
- report_version: `v1.14`
- generated_at: `2026-05-23T08:38:09.859367+08:00`

## Summary

- verdict: `PASS`
- rows_total: `5`
- pass: `1`
- warn: `0`
- blocked: `0`
- not_available: `4`

## Section Status

| section | row_id | status | notes | evidence_count |
|---|---|---|---|---|
| package_status | tapeout_package_manifest | PACKAGE_READY | package assembly verdict | 1 |
| package_status | package_integrity_manifest | NOT_AVAILABLE | package integrity verdict | 1 |
| handoff_chain | handoff_authority_record | NOT_AVAILABLE | authority chain status | 1 |
| handoff_chain | handoff_transfer_record | PENDING | transfer chain status | 1 |
| handoff_chain | handoff_receipt_record | PENDING | receipt chain status | 1 |

## Action Items

- action_item_count: `0`

Canonical truth remains governed JSON objects and evidence references.
