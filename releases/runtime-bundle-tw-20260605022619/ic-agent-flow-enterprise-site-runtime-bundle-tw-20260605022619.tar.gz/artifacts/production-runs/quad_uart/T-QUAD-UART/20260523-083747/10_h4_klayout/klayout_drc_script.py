import json
import re
import os
import sys
import xml.etree.ElementTree as ET
from pathlib import Path
try:
    import klayout.db as kdb
except ImportError as e:
    print('KLAYOUT_IMPORT_FAILED:', e)
    sys.exit(1)

def _parse_def(def_path):
    text = Path(def_path).read_text(encoding='utf-8', errors='ignore')
    design_match = re.search(r'^DESIGN\s+(\S+)\s+;$', text, re.MULTILINE)
    die_match = re.search(r'^DIEAREA\s+\(\s*(-?\d+)\s+(-?\d+)\s*\)\s+\(\s*(-?\d+)\s+(-?\d+)\s*\)\s*;$', text, re.MULTILINE)
    dbu_match = re.search(r'^UNITS DISTANCE MICRONS\s+(\d+)\s+;$', text, re.MULTILINE)
    component_match = re.search(r'^COMPONENTS\s+(\d+)\s+;$', text, re.MULTILINE)
    pins = []
    current = None
    in_pins = False
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if line.startswith('PINS '):
            in_pins = True
            continue
        if line == 'END PINS':
            in_pins = False
            continue
        if not in_pins:
            continue
        if line.startswith('- '):
            parts = line.split()
            current = {'name': parts[1]}
            pins.append(current)
            continue
        if current is None:
            continue
        layer_match = re.search(r'\+ LAYER\s+(\S+)\s+\(\s*(-?\d+)\s+(-?\d+)\s*\)\s+\(\s*(-?\d+)\s+(-?\d+)\s*\)', line)
        if layer_match:
            current['layer'] = layer_match.group(1)
            current['rect'] = [int(layer_match.group(i)) for i in range(2, 6)]
            continue
        placed_match = re.search(r'\+ (?:PLACED|FIXED)\s+\(\s*(-?\d+)\s+(-?\d+)\s*\)\s+(\S+)', line)
        if placed_match:
            current['origin'] = [int(placed_match.group(1)), int(placed_match.group(2))]
            current['orient'] = placed_match.group(3)
    return {
        'design': design_match.group(1) if design_match else 'TOP',
        'dbu': int(dbu_match.group(1)) if dbu_match else 1000,
        'die_area': [int(die_match.group(i)) for i in range(1, 5)] if die_match else None,
        'components_total': int(component_match.group(1)) if component_match else 0,
        'pins': pins,
    }

def _insert_box(cell, layer_index, box):
    x1, y1, x2, y2 = box
    cell.shapes(layer_index).insert(kdb.Box(min(x1, x2), min(y1, y2), max(x1, x2), max(y1, y2)))

def _build_layout_from_def(parsed, output_gds):
    layout = kdb.Layout()
    layout.dbu = 1.0 / parsed['dbu']
    top = layout.create_cell(parsed['design'])
    outline_layer = layout.layer(kdb.LayerInfo(900, 0))
    if parsed.get('die_area'):
        _insert_box(top, outline_layer, parsed['die_area'])
    layer_map = {}
    next_layer = 1
    for pin in parsed['pins']:
        if 'layer' not in pin or 'rect' not in pin or 'origin' not in pin:
            continue
        layer_name = pin['layer']
        if layer_name not in layer_map:
            layer_map[layer_name] = layout.layer(kdb.LayerInfo(next_layer, 0))
            next_layer += 1
        ox, oy = pin['origin']
        x1, y1, x2, y2 = pin['rect']
        _insert_box(top, layer_map[layer_name], [ox + x1, oy + y1, ox + x2, oy + y2])
    layout.write(output_gds)
    return layout

def _load_layout_from_gds(gds_path, output_gds):
    layout = kdb.Layout()
    layout.read(gds_path)
    if Path(gds_path).resolve() != Path(output_gds).resolve():
        layout.write(output_gds)
    return layout

def _count_shapes(cell, layer_count):
    total = 0
    for layer_index in range(layer_count):
        for _shape in cell.shapes(layer_index).each():
            total += 1
    return total

def _run_checks(layout, parsed=None):
    violations = []
    top_cells = list(layout.top_cells())
    if not top_cells:
        violations.append('No top cell present in realized layout')
        return violations
    top = top_cells[0]
    shape_count = _count_shapes(top, layout.layers())
    if shape_count == 0:
        violations.append('No layout shapes realized for H4 DRC')
    if parsed and parsed.get('die_area'):
        dx1, dy1, dx2, dy2 = parsed['die_area']
        pin_boxes_by_layer = {}
        for pin in parsed['pins']:
            if 'layer' not in pin or 'rect' not in pin or 'origin' not in pin:
                continue
            ox, oy = pin['origin']
            x1, y1, x2, y2 = pin['rect']
            box = [min(ox + x1, ox + x2), min(oy + y1, oy + y2), max(ox + x1, ox + x2), max(oy + y1, oy + y2)]
            if box[0] < dx1 or box[1] < dy1 or box[2] > dx2 or box[3] > dy2:
                violations.append(f"Pin {pin['name']} extends outside DIEAREA")
            existing = pin_boxes_by_layer.setdefault(pin['layer'], [])
            for other_name, other_box in existing:
                overlap = not (box[2] <= other_box[0] or box[0] >= other_box[2] or box[3] <= other_box[1] or box[1] >= other_box[3])
                if overlap:
                    violations.append(f"Pin overlap on {pin['layer']}: {other_name} vs {pin['name']}")
            existing.append((pin['name'], box))
    return violations

def _write_xml_report(report_path, violations):
    root = ET.Element('report')
    for violation in violations:
        item = ET.SubElement(root, 'item')
        item.text = violation
    tree = ET.ElementTree(root)
    tree.write(report_path, encoding='utf-8', xml_declaration=True)

print(f'KLAYOUT_VERSION: {kdb.__version__}')
gds_input = None
def_input = '/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/h2_openroad/openroad-8e14f700374c/top.def'
report_path = '/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/h4_klayout/klayout-3419620077b9/klayout_drc.xml'
realized_gds_path = '/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/h4_klayout/klayout-3419620077b9/top.h4.gds'
summary_path = '/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/quad_uart/T-QUAD-UART/20260523-083747/h4_klayout/klayout-3419620077b9/klayout.summary.json'
parsed = None
if gds_input:
    layout = _load_layout_from_gds(gds_input, realized_gds_path)
    source_kind = 'gds'
else:
    parsed = _parse_def(def_input)
    layout = _build_layout_from_def(parsed, realized_gds_path)
    source_kind = 'def'
violations = _run_checks(layout, parsed)
_write_xml_report(report_path, violations)
summary = {
    'tool': 'klayout',
    'tool_version': kdb.__version__,
    'source_kind': source_kind,
    'violations_total': len(violations),
    'status': 'PASS' if not violations else 'FAIL',
    'report_ref': report_path,
    'gds_ref': realized_gds_path,
}
Path(summary_path).write_text(json.dumps(summary, indent=2), encoding='utf-8')
print('KLAYOUT_H4_REAL_RUN_PASS')
sys.exit(0)
