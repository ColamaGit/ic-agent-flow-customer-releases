// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vquad_uart_tb.h for the primary calling header

#ifndef VERILATED_VQUAD_UART_TB___024ROOT_H_
#define VERILATED_VQUAD_UART_TB___024ROOT_H_  // guard

#include "verilated.h"
#include "verilated_cov.h"
#include "verilated_timing.h"


class Vquad_uart_tb__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vquad_uart_tb___024root final {
  public:

    // DESIGN SPECIFIC STATE
    // Anonymous structures to workaround compiler member-count bugs
    struct {
        CData/*0:0*/ quad_uart_tb__DOT__pclk;
        CData/*0:0*/ quad_uart_tb__DOT__presetn;
        CData/*0:0*/ quad_uart_tb__DOT__psel;
        CData/*0:0*/ quad_uart_tb__DOT__penable;
        CData/*0:0*/ quad_uart_tb__DOT__pwrite;
        CData/*3:0*/ quad_uart_tb__DOT__uart_rx;
        CData/*3:0*/ quad_uart_tb__DOT__uart_tx;
        CData/*3:0*/ quad_uart_tb__DOT__irq;
        CData/*0:0*/ quad_uart_tb__DOT____Vtogcov__pclk;
        CData/*0:0*/ quad_uart_tb__DOT____Vtogcov__presetn;
        CData/*0:0*/ quad_uart_tb__DOT____Vtogcov__psel;
        CData/*0:0*/ quad_uart_tb__DOT____Vtogcov__penable;
        CData/*0:0*/ quad_uart_tb__DOT____Vtogcov__pwrite;
        CData/*3:0*/ quad_uart_tb__DOT____Vtogcov__uart_rx;
        CData/*0:0*/ quad_uart_tb__DOT____Vtogcov__pready;
        CData/*0:0*/ quad_uart_tb__DOT____Vtogcov__pslverr;
        CData/*3:0*/ quad_uart_tb__DOT____Vtogcov__uart_tx;
        CData/*3:0*/ quad_uart_tb__DOT____Vtogcov__irq;
        CData/*3:0*/ quad_uart_tb__DOT__dut__DOT__tx_fire;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch0__irq;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch0__uart_tx;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch1__irq;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch1__uart_tx;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch2__irq;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch2__uart_tx;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch3__irq;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT____Vcellout__u_uart_ch3__uart_tx;
        CData/*3:0*/ quad_uart_tb__DOT__dut__DOT____Vtogcov__tx_fire;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_wr;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT__apb_rd;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__pready;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__pslverr;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__apb_access;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__apb_wr;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT__u_apb_uart_ctrl__DOT____Vtogcov__apb_rd;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT__rx_d;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__tx_fire;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__uart_rx;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__uart_tx;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__irq;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT__u_uart_ch0__DOT____Vtogcov__rx_d;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT__rx_d;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__tx_fire;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__uart_rx;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__uart_tx;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__irq;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT__u_uart_ch1__DOT____Vtogcov__rx_d;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT__rx_d;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__tx_fire;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__uart_rx;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__uart_tx;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__irq;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT__u_uart_ch2__DOT____Vtogcov__rx_d;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT__rx_d;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__tx_fire;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__uart_rx;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__uart_tx;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__irq;
        CData/*0:0*/ quad_uart_tb__DOT__dut__DOT__u_uart_ch3__DOT____Vtogcov__rx_d;
        CData/*0:0*/ __VstlFirstIteration;
        CData/*0:0*/ __VstlPhaseResult;
        CData/*0:0*/ __Vtrigprevexpr___TOP__quad_uart_tb__DOT__pclk__0;
        CData/*0:0*/ __Vtrigprevexpr___TOP__quad_uart_tb__DOT__presetn__0;
        CData/*0:0*/ __VactPhaseResult;
    };
    struct {
        CData/*0:0*/ __VinactPhaseResult;
        CData/*0:0*/ __VnbaPhaseResult;
        SData/*11:0*/ quad_uart_tb__DOT____VlemCall_3__tx_addr;
        SData/*11:0*/ quad_uart_tb__DOT____VlemCall_2__cfg_addr;
        SData/*11:0*/ quad_uart_tb__DOT____VlemCall_1__tx_addr;
        SData/*11:0*/ quad_uart_tb__DOT____VlemCall_0__cfg_addr;
        SData/*11:0*/ quad_uart_tb__DOT__paddr;
        SData/*11:0*/ quad_uart_tb__DOT____Vtogcov__paddr;
        IData/*31:0*/ quad_uart_tb__DOT__pwdata;
        IData/*31:0*/ quad_uart_tb__DOT__prdata;
        IData/*31:0*/ quad_uart_tb__DOT____Vtogcov__pwdata;
        IData/*31:0*/ quad_uart_tb__DOT____Vtogcov__prdata;
        IData/*31:0*/ quad_uart_tb__DOT__unnamedblk2__DOT__unnamedblk3__DOT__read_back;
        IData/*31:0*/ quad_uart_tb__DOT__dut__DOT__ch_cfg0;
        IData/*31:0*/ quad_uart_tb__DOT__dut__DOT__ch_cfg1;
        IData/*31:0*/ quad_uart_tb__DOT__dut__DOT__ch_cfg2;
        IData/*31:0*/ quad_uart_tb__DOT__dut__DOT__ch_cfg3;
        IData/*31:0*/ quad_uart_tb__DOT__dut__DOT__ch_tx0;
        IData/*31:0*/ quad_uart_tb__DOT__dut__DOT__ch_tx1;
        IData/*31:0*/ quad_uart_tb__DOT__dut__DOT__ch_tx2;
        IData/*31:0*/ quad_uart_tb__DOT__dut__DOT__ch_tx3;
        IData/*31:0*/ quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_cfg0;
        IData/*31:0*/ quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_cfg1;
        IData/*31:0*/ quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_cfg2;
        IData/*31:0*/ quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_cfg3;
        IData/*31:0*/ quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_tx0;
        IData/*31:0*/ quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_tx1;
        IData/*31:0*/ quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_tx2;
        IData/*31:0*/ quad_uart_tb__DOT__dut__DOT____Vtogcov__ch_tx3;
        IData/*31:0*/ __VactIterCount;
        IData/*31:0*/ __VinactIterCount;
        IData/*31:0*/ __Vi;
        VlUnpacked<QData/*63:0*/, 1> __VstlTriggered;
        VlUnpacked<QData/*63:0*/, 1> __VactTriggered;
        VlUnpacked<QData/*63:0*/, 1> __VactTriggeredAcc;
        VlUnpacked<QData/*63:0*/, 1> __VnbaTriggered;
    };
    VlDelayScheduler __VdlySched;
    VlTriggerScheduler __VtrigSched_hecc72097__0;
    VlTriggerScheduler __VtrigSched_hecc7213b__0;

    // INTERNAL VARIABLES
    Vquad_uart_tb__Syms* vlSymsp;
    const char* vlNamep;

    // CONSTRUCTORS
    Vquad_uart_tb___024root(Vquad_uart_tb__Syms* symsp, const char* namep);
    ~Vquad_uart_tb___024root();
    VL_UNCOPYABLE(Vquad_uart_tb___024root);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
    void __vlCoverInsert(uint32_t* countp, bool enable, const char* filenamep, int lineno, int column,
        const char* hierp, const char* pagep, const char* commentp, const char* linescovp);
    void __vlCoverToggleInsert(int begin, int end, bool ranged, uint32_t* countp, bool enable, const char* filenamep, int lineno, int column,
        const char* hierp, const char* pagep, const char* commentp);
};


#endif  // guard
