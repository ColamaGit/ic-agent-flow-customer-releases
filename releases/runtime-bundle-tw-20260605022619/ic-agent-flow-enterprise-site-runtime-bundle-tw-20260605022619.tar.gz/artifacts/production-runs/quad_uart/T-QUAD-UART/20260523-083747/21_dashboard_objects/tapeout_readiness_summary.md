# Tapeout Package Summary

- chip_id: `quad_uart`
- run_id: `T-QUAD-UART`
- execution: `20260523-083747`

## Package Verdict

- status: `PACKAGE_READY`
- handoff_profile: `MPW_SHUTTLE`
- artifact_count: `294`
- integrity_verdict: `PASS`

## Handoff Chain

- authority_decision: `PENDING`
- transfer_status: `PENDING`
- receipt_status: `PENDING`

## External Path Leak

- findings_count: `0`
