read_lef "/customer-home/imac/eda/openroad-cxx17/test/Nangate45/Nangate45_tech.lef"
read_lef "/customer-home/imac/eda/openroad-cxx17/test/Nangate45/Nangate45_stdcell.lef"
read_liberty "/customer-home/imac/eda/openroad-cxx17/test/Nangate45/Nangate45_typ.lib"
read_verilog "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/test-chip-02/T-SN2025-01/20260523-095157/h1_yosys/yosys-8efe1c5352fe/top.synth.v"
link_design top
read_sdc "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/test-chip-02/T-SN2025-01/20260523-095157/inputs/design/constraints/base.sdc"
initialize_floorplan -site FreePDK45_38x28_10R_NP_162NW_34O -die_area {0 0 200 200} -core_area {20 20 180 180}
source "/customer-home/imac/eda/openroad-cxx17/test/Nangate45/Nangate45.tracks"
place_pins -hor_layers metal3 -ver_layers metal2
repair_design -pre_placement
set_wire_rc -signal -layer metal3
set_wire_rc -clock -layer metal6
estimate_parasitics -placement
report_checks -path_delay min -fields {slew capacitance}
exit
