# Signoff Closure Report v1.13

- chip_id: `test-chip-02`
- run_id: `T-SN2025-01`
- execution: `20260523-095157`
- report_family: `signoff_report`
- report_version: `v1.13`
- generated_at: `2026-05-23T09:52:16.954112+08:00`

## Summary

- verdict: `PASS`
- rows_total: `1`
- pass: `1`
- warn: `0`
- blocked: `0`
- not_available: `0`

## Section Status

| section | row_id | status | notes | evidence_count |
|---|---|---|---|---|
| final_adjudication | final_tapeout_readiness_record | READY_FOR_TAPEOUT_PACKAGE_ASSEMBLY | final adjudicated readiness | 1 |

## Action Items

- action_item_count: `0`

Canonical truth remains governed JSON objects and evidence references.
