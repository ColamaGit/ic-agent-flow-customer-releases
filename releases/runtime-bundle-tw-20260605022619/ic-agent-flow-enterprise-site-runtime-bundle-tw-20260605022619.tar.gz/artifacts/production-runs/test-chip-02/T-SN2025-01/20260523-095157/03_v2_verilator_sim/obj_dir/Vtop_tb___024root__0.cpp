// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vtop_tb.h for the primary calling header

#include "Vtop_tb__pch.h"

VlCoroutine Vtop_tb___024root___eval_initial__TOP__Vtiming__0(Vtop_tb___024root* vlSelf);
VlCoroutine Vtop_tb___024root___eval_initial__TOP__Vtiming__1(Vtop_tb___024root* vlSelf);
VlCoroutine Vtop_tb___024root___eval_initial__TOP__Vtiming__2(Vtop_tb___024root* vlSelf);

void Vtop_tb___024root___eval_initial(Vtop_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop_tb___024root___eval_initial\n"); );
    Vtop_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    Vtop_tb___024root___eval_initial__TOP__Vtiming__0(vlSelf);
    Vtop_tb___024root___eval_initial__TOP__Vtiming__1(vlSelf);
    Vtop_tb___024root___eval_initial__TOP__Vtiming__2(vlSelf);
}

VlCoroutine Vtop_tb___024root___eval_initial__TOP__Vtiming__0(Vtop_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop_tb___024root___eval_initial__TOP__Vtiming__0\n"); );
    Vtop_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.top_tb__DOT__clk = 0U;
    vlSelfRef.top_tb__DOT__rst_n = 0U;
    vlSelfRef.top_tb__DOT__data_in = 0U;
    co_await vlSelfRef.__VdlySched.delay(0x0000000000002ee0ULL, 
                                         nullptr, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/test-chip-02/T-SN2025-01/20260523-095157/inputs/design/rtl/top_tb.v", 
                                         23);
    vlSelfRef.top_tb__DOT__rst_n = 1U;
    vlSelfRef.top_tb__DOT__data_in = 0xa5U;
    co_await vlSelfRef.__VdlySched.delay(0x0000000000002710ULL, 
                                         nullptr, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/test-chip-02/T-SN2025-01/20260523-095157/inputs/design/rtl/top_tb.v", 
                                         27);
    if (vlSymsp->_vm_contextp__->assertOnGet(2, 1)) {
        if (VL_UNLIKELY(((0xa5U != (IData)(vlSelfRef.top_tb__DOT__data_out))))) {
            VL_WRITEF_NX("SN2025_ASSERT_FAIL expected=A5 got=%02h\n[%0t] %%Fatal: top_tb.v:31: Assertion failed in %m\n",4, 'M',vlSymsp->name(),"top_tb", 'T',-9
                         , '#',8,vlSelfRef.top_tb__DOT__data_out
                         , '#',64,VL_TIME_UNITED_Q(1000));
            VL_STOP_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/test-chip-02/T-SN2025-01/20260523-095157/inputs/design/rtl/top_tb.v", 31, "", false);
        }
    }
    if (VL_UNLIKELY(((0xa5U != (IData)(vlSelfRef.top_tb__DOT__data_out))))) {
        VL_WRITEF_NX("SN2025_SIM_FAIL expected=A5 got=%02h\n[%0t] %%Fatal: top_tb.v:35: Assertion failed in %m\n",4, 'M',vlSymsp->name(),"top_tb", 'T',-9
                     , '#',8,vlSelfRef.top_tb__DOT__data_out
                     , '#',64,VL_TIME_UNITED_Q(1000));
        VL_STOP_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/test-chip-02/T-SN2025-01/20260523-095157/inputs/design/rtl/top_tb.v", 35, "", false);
    }
    VL_WRITEF_NX("SN2025_SIM_PASS\n",0);
    VL_FINISH_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/test-chip-02/T-SN2025-01/20260523-095157/inputs/design/rtl/top_tb.v", 39, "");
    co_return;
}

VlCoroutine Vtop_tb___024root___eval_initial__TOP__Vtiming__1(Vtop_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop_tb___024root___eval_initial__TOP__Vtiming__1\n"); );
    Vtop_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    co_await vlSelfRef.__VdlySched.delay(0x00000000000186a0ULL, 
                                         nullptr, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/test-chip-02/T-SN2025-01/20260523-095157/inputs/design/rtl/top_tb.v", 
                                         43);
    VL_WRITEF_NX("SN2025_SIM_TIMEOUT\n[%0t] %%Fatal: top_tb.v:45: Assertion failed in %m\n",3, 'M',vlSymsp->name(),"top_tb", 'T',-9
                 , '#',64,VL_TIME_UNITED_Q(1000));
    VL_STOP_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/test-chip-02/T-SN2025-01/20260523-095157/inputs/design/rtl/top_tb.v", 45, "", false);
    co_return;
}

VlCoroutine Vtop_tb___024root___eval_initial__TOP__Vtiming__2(Vtop_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop_tb___024root___eval_initial__TOP__Vtiming__2\n"); );
    Vtop_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    while (VL_LIKELY(!vlSymsp->_vm_contextp__->gotFinish())) {
        co_await vlSelfRef.__VdlySched.delay(0x0000000000001388ULL, 
                                             nullptr, 
                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/test-chip-02/T-SN2025-01/20260523-095157/inputs/design/rtl/top_tb.v", 
                                             16);
        vlSelfRef.top_tb__DOT__clk = (1U & (~ (IData)(vlSelfRef.top_tb__DOT__clk)));
        if ((1U & (~ (IData)(vlSelfRef.top_tb__DOT__clk)))) {
            ++(vlSymsp->__Vcoverage[36]);
        }
        if (vlSelfRef.top_tb__DOT__clk) {
            ++(vlSymsp->__Vcoverage[37]);
        }
        ++(vlSymsp->__Vcoverage[38]);
    }
    co_return;
}

void Vtop_tb___024root___eval_triggers_vec__act(Vtop_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop_tb___024root___eval_triggers_vec__act\n"); );
    Vtop_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__VactTriggered[0U] = (QData)((IData)(
                                                    ((vlSelfRef.__VdlySched.awaitingCurrentTime() 
                                                      << 2U) 
                                                     | ((((~ (IData)(vlSelfRef.top_tb__DOT__rst_n)) 
                                                          & (IData)(vlSelfRef.__Vtrigprevexpr___TOP__top_tb__DOT__rst_n__0)) 
                                                         << 1U) 
                                                        | ((IData)(vlSelfRef.top_tb__DOT__clk) 
                                                           & (~ (IData)(vlSelfRef.__Vtrigprevexpr___TOP__top_tb__DOT__clk__0)))))));
    vlSelfRef.__Vtrigprevexpr___TOP__top_tb__DOT__clk__0 
        = vlSelfRef.top_tb__DOT__clk;
    vlSelfRef.__Vtrigprevexpr___TOP__top_tb__DOT__rst_n__0 
        = vlSelfRef.top_tb__DOT__rst_n;
}

bool Vtop_tb___024root___trigger_anySet__act(const VlUnpacked<QData/*63:0*/, 1> &in) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop_tb___024root___trigger_anySet__act\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        if (in[n]) {
            return (1U);
        }
        n = ((IData)(1U) + n);
    } while ((1U > n));
    return (0U);
}

void Vtop_tb___024root___act_sequent__TOP__0(Vtop_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop_tb___024root___act_sequent__TOP__0\n"); );
    Vtop_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (((IData)(vlSelfRef.top_tb__DOT__clk) ^ (IData)(vlSelfRef.top_tb__DOT____Vtogcov__clk))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 0, vlSelfRef.top_tb__DOT__clk, vlSelfRef.top_tb__DOT____Vtogcov__clk);
        vlSelfRef.top_tb__DOT____Vtogcov__clk = vlSelfRef.top_tb__DOT__clk;
    }
    if (((IData)(vlSelfRef.top_tb__DOT__rst_n) ^ (IData)(vlSelfRef.top_tb__DOT____Vtogcov__rst_n))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2, vlSelfRef.top_tb__DOT__rst_n, vlSelfRef.top_tb__DOT____Vtogcov__rst_n);
        vlSelfRef.top_tb__DOT____Vtogcov__rst_n = vlSelfRef.top_tb__DOT__rst_n;
    }
    if (((IData)(vlSelfRef.top_tb__DOT__data_in) ^ (IData)(vlSelfRef.top_tb__DOT____Vtogcov__data_in))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 4, vlSelfRef.top_tb__DOT__data_in, vlSelfRef.top_tb__DOT____Vtogcov__data_in);
        vlSelfRef.top_tb__DOT____Vtogcov__data_in = vlSelfRef.top_tb__DOT__data_in;
    }
}

void Vtop_tb___024root___eval_act(Vtop_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop_tb___024root___eval_act\n"); );
    Vtop_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((4ULL & vlSelfRef.__VactTriggered[0U])) {
        if (((IData)(vlSelfRef.top_tb__DOT__clk) ^ (IData)(vlSelfRef.top_tb__DOT____Vtogcov__clk))) {
            VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 0, vlSelfRef.top_tb__DOT__clk, vlSelfRef.top_tb__DOT____Vtogcov__clk);
            vlSelfRef.top_tb__DOT____Vtogcov__clk = vlSelfRef.top_tb__DOT__clk;
        }
        if (((IData)(vlSelfRef.top_tb__DOT__rst_n) 
             ^ (IData)(vlSelfRef.top_tb__DOT____Vtogcov__rst_n))) {
            VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2, vlSelfRef.top_tb__DOT__rst_n, vlSelfRef.top_tb__DOT____Vtogcov__rst_n);
            vlSelfRef.top_tb__DOT____Vtogcov__rst_n 
                = vlSelfRef.top_tb__DOT__rst_n;
        }
        if (((IData)(vlSelfRef.top_tb__DOT__data_in) 
             ^ (IData)(vlSelfRef.top_tb__DOT____Vtogcov__data_in))) {
            VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 4, vlSelfRef.top_tb__DOT__data_in, vlSelfRef.top_tb__DOT____Vtogcov__data_in);
            vlSelfRef.top_tb__DOT____Vtogcov__data_in 
                = vlSelfRef.top_tb__DOT__data_in;
        }
    }
}

void Vtop_tb___024root___nba_sequent__TOP__1(Vtop_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop_tb___024root___nba_sequent__TOP__1\n"); );
    Vtop_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.top_tb__DOT__rst_n) {
        ++(vlSymsp->__Vcoverage[40]);
        vlSelfRef.top_tb__DOT__data_out = vlSelfRef.top_tb__DOT__data_in;
    } else {
        ++(vlSymsp->__Vcoverage[39]);
        vlSelfRef.top_tb__DOT__data_out = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.top_tb__DOT__rst_n)))) {
        ++(vlSymsp->__Vcoverage[41]);
    }
    if (vlSelfRef.top_tb__DOT__rst_n) {
        ++(vlSymsp->__Vcoverage[42]);
    }
    ++(vlSymsp->__Vcoverage[43]);
    if (((IData)(vlSelfRef.top_tb__DOT__data_out) ^ (IData)(vlSelfRef.top_tb__DOT____Vtogcov__data_out))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 20, vlSelfRef.top_tb__DOT__data_out, vlSelfRef.top_tb__DOT____Vtogcov__data_out);
        vlSelfRef.top_tb__DOT____Vtogcov__data_out 
            = vlSelfRef.top_tb__DOT__data_out;
    }
}

void Vtop_tb___024root___eval_nba(Vtop_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop_tb___024root___eval_nba\n"); );
    Vtop_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((4ULL & vlSelfRef.__VnbaTriggered[0U])) {
        if (((IData)(vlSelfRef.top_tb__DOT__clk) ^ (IData)(vlSelfRef.top_tb__DOT____Vtogcov__clk))) {
            VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 0, vlSelfRef.top_tb__DOT__clk, vlSelfRef.top_tb__DOT____Vtogcov__clk);
            vlSelfRef.top_tb__DOT____Vtogcov__clk = vlSelfRef.top_tb__DOT__clk;
        }
        if (((IData)(vlSelfRef.top_tb__DOT__rst_n) 
             ^ (IData)(vlSelfRef.top_tb__DOT____Vtogcov__rst_n))) {
            VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2, vlSelfRef.top_tb__DOT__rst_n, vlSelfRef.top_tb__DOT____Vtogcov__rst_n);
            vlSelfRef.top_tb__DOT____Vtogcov__rst_n 
                = vlSelfRef.top_tb__DOT__rst_n;
        }
        if (((IData)(vlSelfRef.top_tb__DOT__data_in) 
             ^ (IData)(vlSelfRef.top_tb__DOT____Vtogcov__data_in))) {
            VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 4, vlSelfRef.top_tb__DOT__data_in, vlSelfRef.top_tb__DOT____Vtogcov__data_in);
            vlSelfRef.top_tb__DOT____Vtogcov__data_in 
                = vlSelfRef.top_tb__DOT__data_in;
        }
    }
    if ((3ULL & vlSelfRef.__VnbaTriggered[0U])) {
        if (vlSelfRef.top_tb__DOT__rst_n) {
            ++(vlSymsp->__Vcoverage[40]);
            vlSelfRef.top_tb__DOT__data_out = vlSelfRef.top_tb__DOT__data_in;
        } else {
            ++(vlSymsp->__Vcoverage[39]);
            vlSelfRef.top_tb__DOT__data_out = 0U;
        }
        if ((1U & (~ (IData)(vlSelfRef.top_tb__DOT__rst_n)))) {
            ++(vlSymsp->__Vcoverage[41]);
        }
        if (vlSelfRef.top_tb__DOT__rst_n) {
            ++(vlSymsp->__Vcoverage[42]);
        }
        ++(vlSymsp->__Vcoverage[43]);
        if (((IData)(vlSelfRef.top_tb__DOT__data_out) 
             ^ (IData)(vlSelfRef.top_tb__DOT____Vtogcov__data_out))) {
            VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 20, vlSelfRef.top_tb__DOT__data_out, vlSelfRef.top_tb__DOT____Vtogcov__data_out);
            vlSelfRef.top_tb__DOT____Vtogcov__data_out 
                = vlSelfRef.top_tb__DOT__data_out;
        }
    }
}

void Vtop_tb___024root___timing_resume(Vtop_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop_tb___024root___timing_resume\n"); );
    Vtop_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((4ULL & vlSelfRef.__VactTriggered[0U])) {
        vlSelfRef.__VdlySched.resume();
    }
}

void Vtop_tb___024root___trigger_orInto__act_vec_vec(VlUnpacked<QData/*63:0*/, 1> &out, const VlUnpacked<QData/*63:0*/, 1> &in) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop_tb___024root___trigger_orInto__act_vec_vec\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        out[n] = (out[n] | in[n]);
        n = ((IData)(1U) + n);
    } while ((0U >= n));
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vtop_tb___024root___dump_triggers__act(const VlUnpacked<QData/*63:0*/, 1> &triggers, const std::string &tag);
#endif  // VL_DEBUG

bool Vtop_tb___024root___eval_phase__act(Vtop_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop_tb___024root___eval_phase__act\n"); );
    Vtop_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ __VactExecute;
    // Body
    Vtop_tb___024root___eval_triggers_vec__act(vlSelf);
    Vtop_tb___024root___trigger_orInto__act_vec_vec(vlSelfRef.__VactTriggered, vlSelfRef.__VactTriggeredAcc);
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        Vtop_tb___024root___dump_triggers__act(vlSelfRef.__VactTriggered, "act"s);
    }
#endif
    Vtop_tb___024root___trigger_orInto__act_vec_vec(vlSelfRef.__VnbaTriggered, vlSelfRef.__VactTriggered);
    __VactExecute = Vtop_tb___024root___trigger_anySet__act(vlSelfRef.__VactTriggered);
    if (__VactExecute) {
        vlSelfRef.__VactTriggeredAcc.fill(0ULL);
        Vtop_tb___024root___timing_resume(vlSelf);
        Vtop_tb___024root___eval_act(vlSelf);
    }
    return (__VactExecute);
}

bool Vtop_tb___024root___eval_phase__inact(Vtop_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop_tb___024root___eval_phase__inact\n"); );
    Vtop_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ __VinactExecute;
    // Body
    __VinactExecute = vlSelfRef.__VdlySched.awaitingZeroDelay();
    if (__VinactExecute) {
        VL_FATAL_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/test-chip-02/T-SN2025-01/20260523-095157/inputs/design/rtl/top_tb.v", 3, "", "ZERODLY: Design Verilated with '--no-sched-zero-delay', but #0 delay executed at runtime");
    }
    return (__VinactExecute);
}

void Vtop_tb___024root___trigger_clear__act(VlUnpacked<QData/*63:0*/, 1> &out) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop_tb___024root___trigger_clear__act\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        out[n] = 0ULL;
        n = ((IData)(1U) + n);
    } while ((1U > n));
}

bool Vtop_tb___024root___eval_phase__nba(Vtop_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop_tb___024root___eval_phase__nba\n"); );
    Vtop_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ __VnbaExecute;
    // Body
    __VnbaExecute = Vtop_tb___024root___trigger_anySet__act(vlSelfRef.__VnbaTriggered);
    if (__VnbaExecute) {
        Vtop_tb___024root___eval_nba(vlSelf);
        Vtop_tb___024root___trigger_clear__act(vlSelfRef.__VnbaTriggered);
    }
    return (__VnbaExecute);
}

void Vtop_tb___024root___eval(Vtop_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop_tb___024root___eval\n"); );
    Vtop_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    IData/*31:0*/ __VnbaIterCount;
    // Body
    __VnbaIterCount = 0U;
    do {
        if (VL_UNLIKELY(((0x00002710U < __VnbaIterCount)))) {
#ifdef VL_DEBUG
            Vtop_tb___024root___dump_triggers__act(vlSelfRef.__VnbaTriggered, "nba"s);
#endif
            VL_FATAL_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/test-chip-02/T-SN2025-01/20260523-095157/inputs/design/rtl/top_tb.v", 3, "", "DIDNOTCONVERGE: NBA region did not converge after '--converge-limit' of 10000 tries");
        }
        __VnbaIterCount = ((IData)(1U) + __VnbaIterCount);
        vlSelfRef.__VinactIterCount = 0U;
        do {
            if (VL_UNLIKELY(((0x00002710U < vlSelfRef.__VinactIterCount)))) {
                VL_FATAL_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/test-chip-02/T-SN2025-01/20260523-095157/inputs/design/rtl/top_tb.v", 3, "", "DIDNOTCONVERGE: Inactive region did not converge after '--converge-limit' of 10000 tries");
            }
            vlSelfRef.__VinactIterCount = ((IData)(1U) 
                                           + vlSelfRef.__VinactIterCount);
            vlSelfRef.__VactIterCount = 0U;
            do {
                if (VL_UNLIKELY(((0x00002710U < vlSelfRef.__VactIterCount)))) {
#ifdef VL_DEBUG
                    Vtop_tb___024root___dump_triggers__act(vlSelfRef.__VactTriggered, "act"s);
#endif
                    VL_FATAL_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/test-chip-02/T-SN2025-01/20260523-095157/inputs/design/rtl/top_tb.v", 3, "", "DIDNOTCONVERGE: Active region did not converge after '--converge-limit' of 10000 tries");
                }
                vlSelfRef.__VactIterCount = ((IData)(1U) 
                                             + vlSelfRef.__VactIterCount);
                vlSelfRef.__VactPhaseResult = Vtop_tb___024root___eval_phase__act(vlSelf);
            } while (vlSelfRef.__VactPhaseResult);
            vlSelfRef.__VinactPhaseResult = Vtop_tb___024root___eval_phase__inact(vlSelf);
        } while (vlSelfRef.__VinactPhaseResult);
        vlSelfRef.__VnbaPhaseResult = Vtop_tb___024root___eval_phase__nba(vlSelf);
    } while (vlSelfRef.__VnbaPhaseResult);
}

#ifdef VL_DEBUG
void Vtop_tb___024root___eval_debug_assertions(Vtop_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop_tb___024root___eval_debug_assertions\n"); );
    Vtop_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}
#endif  // VL_DEBUG
