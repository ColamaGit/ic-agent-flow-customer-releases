# Skill Usage Summary

- chip_id: `test-chip-02`
- task_id: `T-SN2025-01`
- run_dir: `/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/test-chip-02/T-SN2025-01/20260523-095157`

## Flow Node to Skill Mapping

| Flow Node | Skill | Type | Verdict | Evidence Path |
|---|---|---|---|---|
| v1_verilator_lint | skill.verilator_lint.v0.1@v0.1 | execution_skill | PASS | v1_verilator_lint |
| v2_verilator_sim | skill.verilator_sim.v0.1@v0.1 | execution_skill | PASS | v2_verilator_sim |
| v3_cdc_rdc | skill.cdc_rdc_structural.v0.1@v0.1 | execution_skill | PASS | v3_cdc_rdc<br>v3_cdc_rdc/normalized.rdc_review.meta.json |
| v3b_cdc_signoff_lite | skill.cdc_signoff_lite.v0.1@v0.1 | execution_skill | PASS | v3b_cdc_signoff_lite |
| h1_yosys | skill.yosys_synth_compile.v0.1@v0.1 | execution_skill | PASS | h1_yosys |
| v4_yosys_lec | skill.yosys_lec.v0.1@v0.1 | execution_skill | PASS | v4_yosys_lec |
| h2_openroad | skill.openroad_drc.v0.1@v0.1 | execution_skill | PASS | h2_openroad |
| h4_klayout | skill.klayout_drc.v0.1@v0.1 | execution_skill | PASS | h4_klayout |
| h3_netgen | skill.netgen_lvs.v0.1@v0.1 | execution_skill | PASS | h3_netgen |
| route_b_b0_contract_materialization | skill.route_b_decision_tree.v1.9@v1.9 | decision_tree_skill | DONE | subject_binding<br>subject_binding/decision_package.v0.1.json<br>subject_binding/re_entry_record.v0.1.json |
| v1_0_upstream_truth_chain | skill.v1_0_upstream_truth_chain.v1.0@v1.0 | governance_skill | DONE | inputs/spec/requirement_item.json<br>inputs/spec/design_spec.json<br>inputs/spec/spec_completeness_report.json<br>inputs/spec/requirement_freeze_record.json<br>inputs/graph/architecture_graph.json<br>inputs/graph/graph_validation_result.json<br>inputs/graph/graph_freeze_record.json<br>inputs/graph/graph_to_generation_plan.json<br>inputs/graph/route_a_openai_e2e_report.json |
| v1_3_subject_binding_chain | skill.v1_3_subject_binding_binder.v1.0@v1.0 | governance_skill | DONE | subject_binding/manifest_binding_record.json<br>subject_binding/scope_resolution_record.json<br>subject_binding/execution_subject_envelope.json<br>subject_binding/decision_package.v0.1.json<br>subject_binding/re_entry_record.v0.1.json<br>subject_binding/capability_contract_index.v0.1.json<br>subject_binding/upstream_admission_manifest.json |
| v1_9_skill_usage_traceability | skill.v1_9_traceability_projection.v1.9@v1.9 | decision_tree_skill | DONE | skill_usage/routing_decision_record.json<br>skill_usage/skill_invocation_record.jsonl<br>skill_usage/fallback_execution_record.json |
| v1_1_v1_2_readiness_compile_chain | skill.v1_1_v1_2_readiness_compiler.v0.2@v0.2 | governance_skill | DONE | 22_reports/readiness_report.v0.2.md<br>22_reports/readiness_report_manifest.v0.2.json<br>22_reports/readiness_report_mapping.v0.2.json<br>22_reports/readiness_report_statistics.v0.2.json<br>22_reports/readiness_report_action_items.v0.2.json<br>22_reports/readiness_report_generation_log.v0.2.json |

## Routing Decision

- selected_route: `route_b_governed_chain`
- verdict: `ROUTE_SELECTED`
- policy: `policy.route_b_default.v0.1@v0.1`

## Fallback

- fallback_result: `NOT_TRIGGERED`
- fallback_trigger_count: `0`
