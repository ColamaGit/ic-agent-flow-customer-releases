# Tapeout Package Summary

- chip_id: `test-chip-02`
- run_id: `T-SN2025-01`
- execution: `20260523-095157`

## Package Verdict

- status: `PACKAGE_READY`
- handoff_profile: `MPW_SHUTTLE`
- artifact_count: `284`
- integrity_verdict: `PASS`

## Handoff Chain

- authority_decision: `PENDING`
- transfer_status: `PENDING`
- receipt_status: `PENDING`

## External Path Leak

- findings_count: `0`
