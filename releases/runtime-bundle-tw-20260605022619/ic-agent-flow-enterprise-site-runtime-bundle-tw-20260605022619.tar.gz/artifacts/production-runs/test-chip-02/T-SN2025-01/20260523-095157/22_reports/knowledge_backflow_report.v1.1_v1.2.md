# Knowledge Backflow Report v1.1_v1.2

- chip_id: `test-chip-02`
- run_id: `T-SN2025-01`
- execution: `20260523-095157`
- report_family: `knowledge_backflow_report`
- report_version: `v1.1_v1.2`
- generated_at: `2026-05-23T09:52:16.963628+08:00`

## Summary

- verdict: `PASS`
- rows_total: `3`
- pass: `1`
- warn: `0`
- blocked: `0`
- not_available: `2`

## Section Status

| section | row_id | status | notes | evidence_count |
|---|---|---|---|---|
| knowledge_backflow | v115_knowledge_backflow_record | CANDIDATE | post-silicon knowledge capture | 1 |
| knowledge_backflow | v115_skill_backflow_record | CANDIDATE | post-silicon skill backflow capture | 1 |
| readiness_report_contract | readiness_report_manifest_v0_2 | PASS | v0.2 report manifest availability | 1 |

## Action Items

- action_item_count: `0`

Canonical truth remains governed JSON objects and evidence references.
