# Signoff Readiness Summary

- chip_id: `test-chip-02`
- run_id: `T-SN2025-01`
- execution: `20260523-095157`

## Final Adjudication

- final_readiness: `READY_FOR_TAPEOUT_PACKAGE_ASSEMBLY`
- silicon_contract_binding: `BOUND_PASS`
- signoff_gap_status: `PASS`
- authority_chain_status: `PASS`

## Per-Domain Status

| Domain | Status | Missing Required Evidence | Owner Role | Claim Class Allowed |
| --- | --- | --- | --- | --- |
| STA | PASS | 0 | TIMING_SIGNOFF_OWNER | BOUNDED_SIGNOFF_ASSIST |
| DRC | PASS | 0 | PHYSICAL_SIGNOFF_OWNER | BOUNDED_SIGNOFF_ASSIST |
| CDC_LITE | PASS | 0 | CDC_SIGNOFF_OWNER | NON_SIGNOFF_CDC_LITE |

## Notes

- This markdown is a derived human-readable summary.
- Canonical truth remains in governed JSON artifacts under `dashboard_objects/.`
