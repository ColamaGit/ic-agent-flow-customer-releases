# Knowledge Backflow Alignment

> Run-local derived companion surface. JSON is the machine-readable contract; Markdown is rendered from JSON only.

- schema_version: `knowledge-backflow-alignment.v0.1`
- chip_id: `test-chip-02`
- run_id: `T-SN2025-01`
- execution: `20260523-095157`
- aligned_report_ref: `artifacts/production-runs/test-chip-02/T-SN2025-01/20260523-095157/22_reports/knowledge_backflow_report.v1.1_v1.2.md`
- aligned_report_manifest_ref: `artifacts/production-runs/test-chip-02/T-SN2025-01/20260523-095157/22_reports/knowledge_backflow_report_manifest.v1.1_v1.2.json`
- readiness_report_manifest_ref: `artifacts/production-runs/test-chip-02/T-SN2025-01/20260523-095157/22_reports/readiness_report_manifest.v0.2.json`
- alignment_status: `PASS`
- execution_handoff_status: `RUN_LOCAL_DERIVED_SURFACE_READY`
- canonical_registry_count: `4`
- asset_row_count: `20`
- action_item_count: `20`
- non_canonical_notice: `True`

## Canonical Registry Refs

- `package_ws/docs/governance/closeout/v1.1/opensta_netgen_compatibility/candidate_asset_registry.opensta_netgen_compatibility.json`
- `package_ws/docs/governance/closeout/v1.1/package_qa_p0_p1_p3_flywheel_candidates/candidate_asset_registry.package_qa_p0_p1_p3_flywheel.json`
- `package_ws/docs/governance/closeout/v1.1/package_qa_phase7_flywheel_candidates/candidate_asset_registry.package_qa_phase7_flywheel.json`
- `package_ws/docs/governance/closeout/v1.1/quad_uart_flywheel_candidates/candidate_asset_registry.quad_uart_flywheel.json`

## Asset Rows

| registry_id | asset_id | asset_family | flow_scope | origin | priority | recommendation | chip evidence | notes |
|---|---|---|---|---|---|---|---|---|
| opensta_netgen_compatibility_20260523 | knowledge_asset_candidate.opensta_netgen_compatibility_20260523 | toolchain_compatibility_pattern | NOT_FLOW_BOUND | FLOW_EVENT_DERIVED | UNCLASSIFIED | REVIEW | 5 | Governed v0.9 reruns uncovered a reusable toolchain-compatibility pattern: OpenSTA timing stages must be fed by a LEF-first runtime setup and supported report_check_types syntax, while parameterized chips must prefer the flat gate-level netlist as the H3 netgen compare anchor. |
| package_qa_p0_p1_p3_flywheel_candidates_20260526 | knowledge_asset_candidate.package_qa.skill_pack_build_time_enforcement_20260526 | build_time_enforcement_pattern | PLATFORM_LINE | BUILD_PIPELINE_DERIVED | P0 | REVIEW | 5 | Policy must be enforced in the build pipeline, not only documented in a resolver or policy file. |
| package_qa_p0_p1_p3_flywheel_candidates_20260526 | knowledge_asset_candidate.package_qa.current_truth_snapshot_boundary_20260526 | snapshot_current_truth_boundary_pattern | CROSS_LINE | DOCUMENT_GOVERNANCE_DERIVED | P0 | REVIEW | 7 | README status, historical snapshot, and current truth must be separated so bootstraps do not read stale state as live truth. |
| package_qa_p0_p1_p3_flywheel_candidates_20260526 | knowledge_asset_candidate.package_qa.evidence_anchored_phase_rollup_20260526 | evidence_anchored_rollup_pattern | CROSS_LINE, RELEASE_LINE | CONSOLE_EVIDENCE_DERIVED | P0 | REVIEW | 4 | A green closure summary must carry commit SHA or verification evidence, otherwise it is only a declaration. |
| package_qa_p0_p1_p3_flywheel_candidates_20260526 | knowledge_asset_candidate.package_qa.artifact_uri_publication_contract_20260526 | artifact_publication_contract_pattern | RELEASE_LINE | RELEASE_QA_DERIVED | P1 | REVIEW | 5 | QA completion must publish evidence into a console-visible index and bind release claims to a stable artifact URI. |
| package_qa_p0_p1_p3_flywheel_candidates_20260526 | knowledge_asset_candidate.package_qa.single_source_action_plan_matrix_20260526 | single_source_action_plan_pattern | CROSS_LINE | DOCUMENT_GOVERNANCE_DERIVED | P3 | REVIEW | 4 | The matrix itself should be the action plan; do not create parallel appendices that split truth. |
| package_qa_p0_p1_p3_flywheel_candidates_20260526 | knowledge_asset_candidate.package_qa.inventory_cache_content_refresh_20260526 | inventory_cache_invalidation_pattern | PLATFORM_LINE | CONSOLE_EVIDENCE_DERIVED | P2 | REVIEW | 6 | Directory mtime cache is not enough when file contents change; the derived inventory must be force-refreshed or hashed before trust. |
| package_qa_phase7_flywheel_candidates_20260525 | knowledge_asset_candidate.package_qa.console_index_publish_contract_20260525 | package_build_evidence_visibility_pattern | NOT_FLOW_BOUND | FLOW_EVENT_DERIVED | UNCLASSIFIED | REVIEW | 8 | Package QA completion must publish package-build evidence into the console-visible package-build index; raw build artifacts alone do not make the package visible in /package-builds. |
| package_qa_phase7_flywheel_candidates_20260525 | knowledge_asset_candidate.package_qa.catalog_required_docs_payload_inclusion_20260525 | reference_catalog_package_payload_pattern | NOT_FLOW_BOUND | FLOW_EVENT_DERIVED | UNCLASSIFIED | REVIEW | 6 | Reference catalog required docs must be materialized into every customer package payload, including docs sourced from package_ws/docs/deployment, not only pre-existing product/deployment package paths. |
| package_qa_phase7_flywheel_candidates_20260525 | knowledge_asset_candidate.package_qa.report_prefix_resolver_20260525 | run_report_prefix_resolver_pattern | NOT_FLOW_BOUND | FLOW_EVENT_DERIVED | UNCLASSIFIED | REVIEW | 6 | Customer readiness entrypoints must discover the active *_reports folder dynamically instead of assuming 22_reports. |
| package_qa_phase7_flywheel_candidates_20260525 | knowledge_asset_candidate.package_qa.simulated_provenance_fixture_binding_20260525 | simulated_toolchain_provenance_fixture_pattern | NOT_FLOW_BOUND | FLOW_EVENT_DERIVED | UNCLASSIFIED | REVIEW | 5 | Simulated package QA still needs explicit EDA binary and collateral provenance fixtures so readiness gates fail for real contract gaps rather than unresolved local environment paths. |
| package_qa_phase7_flywheel_candidates_20260525 | knowledge_asset_candidate.package_qa.route_a_upstream_truth_ordering_20260525 | route_a_upstream_truth_materialization_order_pattern | NOT_FLOW_BOUND | FLOW_EVENT_DERIVED | UNCLASSIFIED | REVIEW | 5 | Route A OpenAI graph E2E evidence must run after v1.0 upstream truth objects and adjudication records are materialized, and repo-baseline venvs must install the schema dependencies needed by that path. |
| package_qa_phase7_flywheel_candidates_20260525 | knowledge_asset_candidate.package_qa.sanitized_payload_leak_scan_20260525 | customer_safe_payload_leak_scan_pattern | SECURITY_IP_LINE | SECURITY_SCAN_DERIVED | P1 | REVIEW | 8 | Package path-leak reports must scan the same sanitized bytes written to the customer tarball; scanning raw virtual files can produce false BLOCKED console records. |
| quad_uart_flywheel_candidates_20260523 | knowledge_asset_candidate.quad_uart.verification_lane_materialization_20260523 | verification_lane_materialization_pattern | NOT_FLOW_BOUND | FLOW_EVENT_DERIVED | UNCLASSIFIED | REVIEW | 3 | Verification/tb is a formal upstream source lane that must be snapshot-materialized into 01_inputs and surfaced consistently in Upstream Truth Flow and Run Detail. |
| quad_uart_flywheel_candidates_20260523 | knowledge_asset_candidate.quad_uart.downstream_freeze_surface_normalization_20260523 | freeze_surface_normalization_pattern | NOT_FLOW_BOUND | FLOW_EVENT_DERIVED | UNCLASSIFIED | REVIEW | 1 | The downstream gate should accept both architecture and governance freeze surfaces for the same logical freeze record, and FROZEN_WITH_CONDITIONS is valid when the freeze-to-plan chain is complete. |
| quad_uart_flywheel_candidates_20260523 | knowledge_asset_candidate.quad_uart.route_b_reentry_materialization_20260523 | route_b_reentry_materialization_pattern | NOT_FLOW_BOUND | FLOW_EVENT_DERIVED | UNCLASSIFIED | REVIEW | 10 | Blocking capability rows should materialize REENTRY_REQUESTED rather than leaving the pipeline in an ambiguous NO_REENTRY state. |
| quad_uart_flywheel_candidates_20260523 | knowledge_asset_candidate.quad_uart.pre_spec_estimation_and_lint_noise_management_20260523 | pre_spec_estimation_and_lint_noise_management_pattern | NOT_FLOW_BOUND | FLOW_EVENT_DERIVED | UNCLASSIFIED | REVIEW | 9 | Materialize the architecture_estimation source lane and suppress intentional reserved-bit Verilator warnings so readiness reports reflect genuine gaps rather than intentional noise. |
| quad_uart_flywheel_candidates_20260523 | knowledge_asset_candidate.quad_uart.openroad_preplacement_repair_ordering_20260523 | openroad_preplacement_repair_ordering_pattern | NOT_FLOW_BOUND | FLOW_EVENT_DERIVED | UNCLASSIFIED | REVIEW | 5 | For max-cap closure, execute repair_design -pre_placement before estimate_parasitics -placement; the ordering matters and belongs in both shared-runtime and deployment/runtime helpers. |
| quad_uart_flywheel_candidates_20260523 | knowledge_asset_candidate.quad_uart.execution_provenance_binding_and_customer_filing_20260523 | execution_provenance_binding_pattern | NOT_FLOW_BOUND | FLOW_EVENT_DERIVED | UNCLASSIFIED | REVIEW | 7 | Repo-side validation should run under .venv and explicit deployment profiles; customer packages must expose filing surfaces so future agents can act without code-trace access. |
| quad_uart_flywheel_candidates_20260523 | knowledge_asset_candidate.quad_uart.run_topology_and_derived_surface_compatibility_20260523 | run_topology_derived_surface_compatibility_pattern | NOT_FLOW_BOUND | FLOW_EVENT_DERIVED | UNCLASSIFIED | REVIEW | 7 | Current governed runs use 21_dashboard_objects as the canonical derived surface; 21_assertions is legacy compatibility only, and prefix ordering remains topology-dependent. |

## Action Items

- action_item_count: `20`

Canonical truth remains in governance closeout registries; this report only routes derived references.
