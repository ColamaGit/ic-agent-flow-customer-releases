// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vtop_tb.h for the primary calling header

#include "Vtop_tb__pch.h"

VL_ATTR_COLD void Vtop_tb___024root___eval_static(Vtop_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop_tb___024root___eval_static\n"); );
    Vtop_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__Vtrigprevexpr___TOP__top_tb__DOT__clk__0 
        = vlSelfRef.top_tb__DOT__clk;
    vlSelfRef.__Vtrigprevexpr___TOP__top_tb__DOT__rst_n__0 
        = vlSelfRef.top_tb__DOT__rst_n;
    do {
        vlSelfRef.__VactTriggeredAcc[vlSelfRef.__Vi] 
            = vlSelfRef.__VactTriggered[vlSelfRef.__Vi];
        vlSelfRef.__Vi = ((IData)(1U) + vlSelfRef.__Vi);
    } while ((0U >= vlSelfRef.__Vi));
}

VL_ATTR_COLD void Vtop_tb___024root___eval_final(Vtop_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop_tb___024root___eval_final\n"); );
    Vtop_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vtop_tb___024root___dump_triggers__stl(const VlUnpacked<QData/*63:0*/, 1> &triggers, const std::string &tag);
#endif  // VL_DEBUG
VL_ATTR_COLD bool Vtop_tb___024root___eval_phase__stl(Vtop_tb___024root* vlSelf);

VL_ATTR_COLD void Vtop_tb___024root___eval_settle(Vtop_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop_tb___024root___eval_settle\n"); );
    Vtop_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    IData/*31:0*/ __VstlIterCount;
    // Body
    __VstlIterCount = 0U;
    vlSelfRef.__VstlFirstIteration = 1U;
    do {
        if (VL_UNLIKELY(((0x00002710U < __VstlIterCount)))) {
#ifdef VL_DEBUG
            Vtop_tb___024root___dump_triggers__stl(vlSelfRef.__VstlTriggered, "stl"s);
#endif
            VL_FATAL_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/test-chip-02/T-SN2025-01/20260523-095157/inputs/design/rtl/top_tb.v", 3, "", "DIDNOTCONVERGE: Settle region did not converge after '--converge-limit' of 10000 tries");
        }
        __VstlIterCount = ((IData)(1U) + __VstlIterCount);
        vlSelfRef.__VstlPhaseResult = Vtop_tb___024root___eval_phase__stl(vlSelf);
        vlSelfRef.__VstlFirstIteration = 0U;
    } while (vlSelfRef.__VstlPhaseResult);
}

VL_ATTR_COLD void Vtop_tb___024root___eval_triggers_vec__stl(Vtop_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop_tb___024root___eval_triggers_vec__stl\n"); );
    Vtop_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__VstlTriggered[0U] = ((0xfffffffffffffffeULL 
                                      & vlSelfRef.__VstlTriggered[0U]) 
                                     | (IData)((IData)(vlSelfRef.__VstlFirstIteration)));
}

VL_ATTR_COLD bool Vtop_tb___024root___trigger_anySet__stl(const VlUnpacked<QData/*63:0*/, 1> &in);

#ifdef VL_DEBUG
VL_ATTR_COLD void Vtop_tb___024root___dump_triggers__stl(const VlUnpacked<QData/*63:0*/, 1> &triggers, const std::string &tag) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop_tb___024root___dump_triggers__stl\n"); );
    // Body
    if ((1U & (~ (IData)(Vtop_tb___024root___trigger_anySet__stl(triggers))))) {
        VL_DBG_MSGS("         No '" + tag + "' region triggers active\n");
    }
    if ((1U & (IData)(triggers[0U]))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 0 is active: Internal 'stl' trigger - first iteration\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD bool Vtop_tb___024root___trigger_anySet__stl(const VlUnpacked<QData/*63:0*/, 1> &in) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop_tb___024root___trigger_anySet__stl\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        if (in[n]) {
            return (1U);
        }
        n = ((IData)(1U) + n);
    } while ((1U > n));
    return (0U);
}

VL_ATTR_COLD void Vtop_tb___024root___stl_sequent__TOP__0(Vtop_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop_tb___024root___stl_sequent__TOP__0\n"); );
    Vtop_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (((IData)(vlSelfRef.top_tb__DOT__clk) ^ (IData)(vlSelfRef.top_tb__DOT____Vtogcov__clk))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 0, vlSelfRef.top_tb__DOT__clk, vlSelfRef.top_tb__DOT____Vtogcov__clk);
        vlSelfRef.top_tb__DOT____Vtogcov__clk = vlSelfRef.top_tb__DOT__clk;
    }
    if (((IData)(vlSelfRef.top_tb__DOT__rst_n) ^ (IData)(vlSelfRef.top_tb__DOT____Vtogcov__rst_n))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2, vlSelfRef.top_tb__DOT__rst_n, vlSelfRef.top_tb__DOT____Vtogcov__rst_n);
        vlSelfRef.top_tb__DOT____Vtogcov__rst_n = vlSelfRef.top_tb__DOT__rst_n;
    }
    if (((IData)(vlSelfRef.top_tb__DOT__data_in) ^ (IData)(vlSelfRef.top_tb__DOT____Vtogcov__data_in))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 4, vlSelfRef.top_tb__DOT__data_in, vlSelfRef.top_tb__DOT____Vtogcov__data_in);
        vlSelfRef.top_tb__DOT____Vtogcov__data_in = vlSelfRef.top_tb__DOT__data_in;
    }
    if (((IData)(vlSelfRef.top_tb__DOT__data_out) ^ (IData)(vlSelfRef.top_tb__DOT____Vtogcov__data_out))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 20, vlSelfRef.top_tb__DOT__data_out, vlSelfRef.top_tb__DOT____Vtogcov__data_out);
        vlSelfRef.top_tb__DOT____Vtogcov__data_out 
            = vlSelfRef.top_tb__DOT__data_out;
    }
}

VL_ATTR_COLD void Vtop_tb___024root___eval_stl(Vtop_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop_tb___024root___eval_stl\n"); );
    Vtop_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1ULL & vlSelfRef.__VstlTriggered[0U])) {
        if (((IData)(vlSelfRef.top_tb__DOT__clk) ^ (IData)(vlSelfRef.top_tb__DOT____Vtogcov__clk))) {
            VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 0, vlSelfRef.top_tb__DOT__clk, vlSelfRef.top_tb__DOT____Vtogcov__clk);
            vlSelfRef.top_tb__DOT____Vtogcov__clk = vlSelfRef.top_tb__DOT__clk;
        }
        if (((IData)(vlSelfRef.top_tb__DOT__rst_n) 
             ^ (IData)(vlSelfRef.top_tb__DOT____Vtogcov__rst_n))) {
            VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 2, vlSelfRef.top_tb__DOT__rst_n, vlSelfRef.top_tb__DOT____Vtogcov__rst_n);
            vlSelfRef.top_tb__DOT____Vtogcov__rst_n 
                = vlSelfRef.top_tb__DOT__rst_n;
        }
        if (((IData)(vlSelfRef.top_tb__DOT__data_in) 
             ^ (IData)(vlSelfRef.top_tb__DOT____Vtogcov__data_in))) {
            VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 4, vlSelfRef.top_tb__DOT__data_in, vlSelfRef.top_tb__DOT____Vtogcov__data_in);
            vlSelfRef.top_tb__DOT____Vtogcov__data_in 
                = vlSelfRef.top_tb__DOT__data_in;
        }
        if (((IData)(vlSelfRef.top_tb__DOT__data_out) 
             ^ (IData)(vlSelfRef.top_tb__DOT____Vtogcov__data_out))) {
            VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 20, vlSelfRef.top_tb__DOT__data_out, vlSelfRef.top_tb__DOT____Vtogcov__data_out);
            vlSelfRef.top_tb__DOT____Vtogcov__data_out 
                = vlSelfRef.top_tb__DOT__data_out;
        }
    }
}

VL_ATTR_COLD bool Vtop_tb___024root___eval_phase__stl(Vtop_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop_tb___024root___eval_phase__stl\n"); );
    Vtop_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ __VstlExecute;
    // Body
    Vtop_tb___024root___eval_triggers_vec__stl(vlSelf);
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        Vtop_tb___024root___dump_triggers__stl(vlSelfRef.__VstlTriggered, "stl"s);
    }
#endif
    __VstlExecute = Vtop_tb___024root___trigger_anySet__stl(vlSelfRef.__VstlTriggered);
    if (__VstlExecute) {
        Vtop_tb___024root___eval_stl(vlSelf);
    }
    return (__VstlExecute);
}

bool Vtop_tb___024root___trigger_anySet__act(const VlUnpacked<QData/*63:0*/, 1> &in);

#ifdef VL_DEBUG
VL_ATTR_COLD void Vtop_tb___024root___dump_triggers__act(const VlUnpacked<QData/*63:0*/, 1> &triggers, const std::string &tag) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop_tb___024root___dump_triggers__act\n"); );
    // Body
    if ((1U & (~ (IData)(Vtop_tb___024root___trigger_anySet__act(triggers))))) {
        VL_DBG_MSGS("         No '" + tag + "' region triggers active\n");
    }
    if ((1U & (IData)(triggers[0U]))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 0 is active: @(posedge top_tb.clk)\n");
    }
    if ((1U & (IData)((triggers[0U] >> 1U)))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 1 is active: @(negedge top_tb.rst_n)\n");
    }
    if ((1U & (IData)((triggers[0U] >> 2U)))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 2 is active: @([true] __VdlySched.awaitingCurrentTime())\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD void Vtop_tb___024root___ctor_var_reset(Vtop_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop_tb___024root___ctor_var_reset\n"); );
    Vtop_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    const uint64_t __VscopeHash = VL_MURMUR64_HASH(vlSelf->vlNamep);
    vlSelf->top_tb__DOT__clk = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 17209044258522412720ull);
    vlSelf->top_tb__DOT__rst_n = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 3840276549173128374ull);
    vlSelf->top_tb__DOT__data_in = VL_SCOPED_RAND_RESET_I(8, __VscopeHash, 10849112497203043025ull);
    vlSelf->top_tb__DOT__data_out = VL_SCOPED_RAND_RESET_I(8, __VscopeHash, 7033385867616151982ull);
    vlSelf->top_tb__DOT____Vtogcov__clk = 0;
    vlSelf->top_tb__DOT____Vtogcov__rst_n = 0;
    vlSelf->top_tb__DOT____Vtogcov__data_in = 0;
    vlSelf->top_tb__DOT____Vtogcov__data_out = 0;
    for (int __Vi0 = 0; __Vi0 < 1; ++__Vi0) {
        vlSelf->__VstlTriggered[__Vi0] = 0;
    }
    for (int __Vi0 = 0; __Vi0 < 1; ++__Vi0) {
        vlSelf->__VactTriggered[__Vi0] = 0;
    }
    for (int __Vi0 = 0; __Vi0 < 1; ++__Vi0) {
        vlSelf->__VactTriggeredAcc[__Vi0] = 0;
    }
    vlSelf->__Vtrigprevexpr___TOP__top_tb__DOT__clk__0 = 0;
    vlSelf->__Vtrigprevexpr___TOP__top_tb__DOT__rst_n__0 = 0;
    for (int __Vi0 = 0; __Vi0 < 1; ++__Vi0) {
        vlSelf->__VnbaTriggered[__Vi0] = 0;
    }
    vlSelf->__Vi = 0;
}

VL_ATTR_COLD void Vtop_tb___024root___configure_coverage(Vtop_tb___024root* vlSelf, bool first) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop_tb___024root___configure_coverage\n"); );
    Vtop_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    (void)first;  // Prevent unused variable warning
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[0]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/test-chip-02/T-SN2025-01/20260523-095157/inputs/design/rtl/top_tb.v", 4, 9, ".top_tb", "v_toggle/top_tb", "clk");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[2]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/test-chip-02/T-SN2025-01/20260523-095157/inputs/design/rtl/top_tb.v", 5, 9, ".top_tb", "v_toggle/top_tb", "rst_n");
    vlSelf->__vlCoverToggleInsert(0, 7, 1, &(vlSymsp->__Vcoverage[4]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/test-chip-02/T-SN2025-01/20260523-095157/inputs/design/rtl/top_tb.v", 6, 15, ".top_tb", "v_toggle/top_tb", "data_in");
    vlSelf->__vlCoverToggleInsert(0, 7, 1, &(vlSymsp->__Vcoverage[20]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/test-chip-02/T-SN2025-01/20260523-095157/inputs/design/rtl/top_tb.v", 7, 16, ".top_tb", "v_toggle/top_tb", "data_out");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[36]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/test-chip-02/T-SN2025-01/20260523-095157/inputs/design/rtl/top_tb.v", 16, 21, ".top_tb", "v_expr/top_tb", "(clk==0) => 1", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[37]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/test-chip-02/T-SN2025-01/20260523-095157/inputs/design/rtl/top_tb.v", 16, 21, ".top_tb", "v_expr/top_tb", "(clk==1) => 0", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[38]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/test-chip-02/T-SN2025-01/20260523-095157/inputs/design/rtl/top_tb.v", 16, 5, ".top_tb", "v_line/top_tb", "block", "16");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[0]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/test-chip-02/T-SN2025-01/20260523-095157/inputs/design/rtl/top.v", 2, 16, ".top_tb.dut", "v_toggle/top", "clk");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[2]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/test-chip-02/T-SN2025-01/20260523-095157/inputs/design/rtl/top.v", 3, 16, ".top_tb.dut", "v_toggle/top", "rst_n");
    vlSelf->__vlCoverToggleInsert(0, 7, 1, &(vlSymsp->__Vcoverage[4]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/test-chip-02/T-SN2025-01/20260523-095157/inputs/design/rtl/top.v", 4, 22, ".top_tb.dut", "v_toggle/top", "data_in");
    vlSelf->__vlCoverToggleInsert(0, 7, 1, &(vlSymsp->__Vcoverage[20]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/test-chip-02/T-SN2025-01/20260523-095157/inputs/design/rtl/top.v", 5, 22, ".top_tb.dut", "v_toggle/top", "data_out");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[39]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/test-chip-02/T-SN2025-01/20260523-095157/inputs/design/rtl/top.v", 9, 9, ".top_tb.dut", "v_branch/top", "if", "9-10");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[40]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/test-chip-02/T-SN2025-01/20260523-095157/inputs/design/rtl/top.v", 9, 10, ".top_tb.dut", "v_branch/top", "else", "11-12");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[41]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/test-chip-02/T-SN2025-01/20260523-095157/inputs/design/rtl/top.v", 9, 13, ".top_tb.dut", "v_expr/top", "(rst_n==0) => 1", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[42]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/test-chip-02/T-SN2025-01/20260523-095157/inputs/design/rtl/top.v", 9, 13, ".top_tb.dut", "v_expr/top", "(rst_n==1) => 0", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[43]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/test-chip-02/T-SN2025-01/20260523-095157/inputs/design/rtl/top.v", 8, 5, ".top_tb.dut", "v_line/top", "block", "8");
}
