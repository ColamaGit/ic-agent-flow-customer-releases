// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See VUART_Top_tb.h for the primary calling header

#ifndef VERILATED_VUART_TOP_TB___024ROOT_H_
#define VERILATED_VUART_TOP_TB___024ROOT_H_  // guard

#include "verilated.h"
#include "verilated_cov.h"
#include "verilated_timing.h"


class VUART_Top_tb__Syms;

class alignas(VL_CACHE_LINE_BYTES) VUART_Top_tb___024root final {
  public:

    // DESIGN SPECIFIC STATE
    // Anonymous structures to workaround compiler member-count bugs
    struct {
        CData/*1:0*/ UART_Top_tb__DOT__sel;
        CData/*0:0*/ UART_Top_tb__DOT__TX_start;
        CData/*7:0*/ UART_Top_tb__DOT__TX_DATA;
        CData/*0:0*/ UART_Top_tb__DOT__clk;
        CData/*0:0*/ UART_Top_tb__DOT__reset;
        CData/*0:0*/ UART_Top_tb__DOT__stop_error;
        CData/*0:0*/ UART_Top_tb__DOT__parity_error;
        CData/*7:0*/ UART_Top_tb__DOT__RX_dataout;
        CData/*1:0*/ UART_Top_tb__DOT____Vtogcov__sel;
        CData/*0:0*/ UART_Top_tb__DOT____Vtogcov__TX_start;
        CData/*7:0*/ UART_Top_tb__DOT____Vtogcov__TX_DATA;
        CData/*0:0*/ UART_Top_tb__DOT____Vtogcov__clk;
        CData/*0:0*/ UART_Top_tb__DOT____Vtogcov__reset;
        CData/*0:0*/ UART_Top_tb__DOT____Vtogcov__stop_error;
        CData/*0:0*/ UART_Top_tb__DOT____Vtogcov__parity_error;
        CData/*7:0*/ UART_Top_tb__DOT____Vtogcov__RX_dataout;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT__TX_dataout;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT__clock_out;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT____Vtogcov__TX_dataout;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT____Vtogcov__clock_out;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT__r1__DOT__s0;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT__r1__DOT__s1;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT__r1__DOT__shift;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT__r1__DOT__load_data;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT__r1__DOT__DATA_BIT;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT__r1__DOT__PARITY_BIT;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__s0;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__s1;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__shift;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__load_data;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__DATA_BIT;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__PARITY_BIT;
        CData/*2:0*/ UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____VlemCond_4;
        CData/*2:0*/ UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____VlemCond_3;
        CData/*2:0*/ UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____VlemCond_2;
        CData/*2:0*/ UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____VlemCond_1;
        CData/*2:0*/ UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____VlemCond_0;
        CData/*2:0*/ UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__state;
        CData/*2:0*/ UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__next_state;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__flag1;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__flag2;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp1;
        CData/*3:0*/ UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__x1;
        CData/*4:0*/ UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__x2;
        CData/*2:0*/ UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__state;
        CData/*2:0*/ UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__next_state;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__flag1;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__flag2;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__temp;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__temp1;
        CData/*3:0*/ UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__x1;
        CData/*4:0*/ UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__x2;
        CData/*7:0*/ UART_Top_tb__DOT__uut__DOT__r1__DOT__t2__DOT__temp;
        CData/*7:0*/ UART_Top_tb__DOT__uut__DOT__r1__DOT__t2__DOT____Vtogcov__temp;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT__r3__DOT__shift;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT__r3__DOT__parity_load;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT__r3__DOT__check_stop;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT__r3__DOT__de_strtbit;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT__r3__DOT____Vtogcov__shift;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT__r3__DOT____Vtogcov__parity_load;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT__r3__DOT____Vtogcov__check_stop;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT__r3__DOT____Vtogcov__de_strtbit;
        CData/*7:0*/ UART_Top_tb__DOT__uut__DOT__r3__DOT____Vtogcov__RX_DATA;
    };
    struct {
        CData/*3:0*/ UART_Top_tb__DOT__uut__DOT__r3__DOT__t1__DOT__count;
        CData/*3:0*/ UART_Top_tb__DOT__uut__DOT__r3__DOT__t1__DOT____Vtogcov__count;
        CData/*2:0*/ UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____VlemCond_3;
        CData/*2:0*/ UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____VlemCond_2;
        CData/*2:0*/ UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____VlemCond_1;
        CData/*2:0*/ UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____VlemCond_0;
        CData/*2:0*/ UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__state;
        CData/*2:0*/ UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__next_state;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__flag1;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__flag2;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__temp;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__temp1;
        CData/*3:0*/ UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__x1;
        CData/*3:0*/ UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__x2;
        CData/*2:0*/ UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____Vtogcov__state;
        CData/*2:0*/ UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____Vtogcov__next_state;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____Vtogcov__flag1;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____Vtogcov__flag2;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____Vtogcov__temp;
        CData/*0:0*/ UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____Vtogcov__temp1;
        CData/*3:0*/ UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____Vtogcov__x1;
        CData/*3:0*/ UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____Vtogcov__x2;
        CData/*7:0*/ UART_Top_tb__DOT__uut__DOT__r3__DOT__t3__DOT__temp;
        CData/*3:0*/ UART_Top_tb__DOT__uut__DOT__r3__DOT__t5__DOT__count;
        CData/*3:0*/ UART_Top_tb__DOT__uut__DOT__r3__DOT__t5__DOT____Vtogcov__count;
        CData/*0:0*/ __Vtrigprevexpr___TOP__UART_Top_tb__DOT__uut__DOT__r3__DOT__parity_load__0;
        CData/*0:0*/ __VstlDidInit;
        CData/*0:0*/ __VstlFirstIteration;
        CData/*0:0*/ __VstlPhaseResult;
        CData/*0:0*/ __Vtrigprevexpr___TOP__UART_Top_tb__DOT__uut__DOT__clock_out__0;
        CData/*0:0*/ __Vtrigprevexpr___TOP__UART_Top_tb__DOT__reset__0;
        CData/*0:0*/ __Vtrigprevexpr___TOP__UART_Top_tb__DOT__clk__0;
        CData/*0:0*/ __VactPhaseResult;
        CData/*0:0*/ __VinactPhaseResult;
        CData/*0:0*/ __VnbaPhaseResult;
        SData/*11:0*/ UART_Top_tb__DOT__uut__DOT__r2__DOT__temp;
        SData/*11:0*/ UART_Top_tb__DOT__uut__DOT__r2__DOT__count;
        SData/*11:0*/ UART_Top_tb__DOT__uut__DOT__r2__DOT____Vtogcov__temp;
        SData/*11:0*/ UART_Top_tb__DOT__uut__DOT__r2__DOT____Vtogcov__count;
        IData/*31:0*/ __VactIterCount;
        IData/*31:0*/ __VinactIterCount;
        IData/*31:0*/ __Vi;
        VlUnpacked<QData/*63:0*/, 2> __VstlTriggered;
        VlUnpacked<QData/*63:0*/, 1> __VactTriggered;
        VlUnpacked<QData/*63:0*/, 1> __VactTriggeredAcc;
        VlUnpacked<QData/*63:0*/, 1> __VnbaTriggered;
    };
    VlTriggerScheduler __VtrigSched_h62ac6386__0;
    VlDelayScheduler __VdlySched;

    // INTERNAL VARIABLES
    VUART_Top_tb__Syms* vlSymsp;
    const char* vlNamep;

    // CONSTRUCTORS
    VUART_Top_tb___024root(VUART_Top_tb__Syms* symsp, const char* namep);
    ~VUART_Top_tb___024root();
    VL_UNCOPYABLE(VUART_Top_tb___024root);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
    void __vlCoverInsert(uint32_t* countp, bool enable, const char* filenamep, int lineno, int column,
        const char* hierp, const char* pagep, const char* commentp, const char* linescovp);
    void __vlCoverToggleInsert(int begin, int end, bool ranged, uint32_t* countp, bool enable, const char* filenamep, int lineno, int column,
        const char* hierp, const char* pagep, const char* commentp);
};


#endif  // guard
