# RUN_STRUCTURE_EXPLAINED

- chip_id: `uart-controller-v0.1`
- task_id: `T-UART-001`
- run_dir: `/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/uart-controller-v0.1/T-UART-001/20260523-095157`
- route_a_used: `true`
- route_b_used: `true`

## Top-Level Meaning

- `inputs/spec/`: PRD v1.0 requirement/spec completeness truth objects.
- `inputs/graph/`: PRD v1.0 graph/validation/freeze/plan objects; Route-A artifacts appear here when enabled.
- `inputs/architecture_estimation/`: pre-spec estimation companions (bandwidth/power/area proxies).
- `inputs/hierarchy/`: hierarchy manifest/interface/partition companions for top+subsystem integration context.
- `v1/v2/v3/v4` and `h1...h10`: PRD v0.9 execution stages and normalized evidence planes.
- `subject_binding/`: decision package / capability contract / re-entry chain for governed consumption.
- `toolchain_resolution/`: environment fingerprint + adjudication + normalized toolchain selection truth.
- `production_intent/`: production-depth intent evidence normalized into readiness surface.
- `skill_usage/`: per-flow-node skill invocation, routing decision, and fallback usage records.
- `22_reports/`: canonical formal report families (`readiness` + `signoff` + `tapeout` + `skill/knowledge backflow` + `silicon feedback`).
- `readiness_report*.json|md` (run root): backward-compatible legacy location for v0.2 report family.

## Governed Full Flow Sequence

- `PRD v1.0 Routine-A` (intake/spec -> graph -> freeze/plan)
- `PRD v0.9 Routine-B` (governed EDA execution and evidence materialization)
- `PRD v1.3` (subject binding + decision package + re-entry binding)
- `PRD v1.13` (signoff evidence closure + tapeout readiness adjudication)
- `PRD v1.14` (tapeout package assembly + foundry handoff governance chain)
- `PRD v1.15` (post-tapeout bring-up + silicon feedback closure)
- `PRD v1.9 + v1.1/v1.2 lanes` (skill/knowledge backflow and report-compile ecosystem lanes)

## Silicon Lifecycle Mainline (PRD v1.0 -> v0.9 -> v1.3 -> v1.13 -> v1.14 -> v1.15)

- `Full mainline chain (expanded)`
- `PRD v1.0 Routine-A`: `inputs/spec -> inputs/graph(route_a_openai_e2e_report.json, graph_freeze_record.json, graph_to_generation_plan.json)`
- `PRD v0.9 Routine-B`: `v1_verilator_lint -> v2_verilator_sim -> v3_cdc_rdc -> v3b_cdc_signoff_lite -> v4_yosys_lec -> h1_yosys -> h2_openroad -> h5_opensta -> h4_klayout -> h3_netgen -> h9_power_ir_static -> h10_power_ir_dynamic -> h6_dft_scan -> h7_esd_review -> h8_io_pad_ring`
- `PRD v1.3`: `subject_binding(capability_contract_index, decision_package, silicon_contract, reentry_history)`
- `PRD v1.13`: `signoff(signoff_domain_matrix, signoff_evidence_manifest, signoff_gap_record, waiver/risk/owner chain, final_tapeout_readiness_record)`
- `PRD v1.14`: `tapeout_package(tapeout_package_manifest, package_integrity_manifest, handoff_authority/transfer/receipt, foundry_handoff_manifest)`
- `PRD v1.15`: `silicon_feedback(v115_sample/lab/bringup, v115_mismatch/errata/eco, v115_backflow, v115_post_tapeout_audit_bundle)`

## Cross-cutting / Backflow Lanes

- `PRD v1.9`: `skill_usage(routing_decision_record, skill_invocation_record, fallback_execution_record, skill_usage_summary)`
- `PRD v1.1/v1.2`: `readiness_report.v0.2.md -> readiness_report_manifest/mapping/statistics/action_items/generation_log`

## Stage Execution Snapshot

- `v1_verilator_lint/`: executed
- `v2_verilator_sim/`: executed
- `v3_cdc_rdc/`: executed
- `v3b_cdc_signoff_lite/`: executed
- `v4_yosys_lec/`: executed
- `h1_yosys/`: executed
- `h2_openroad/`: executed
- `h5_opensta/`: executed
- `h4_klayout/`: executed
- `h3_netgen/`: executed
- `h9_power_ir_static/`: executed
- `h10_power_ir_dynamic/`: executed
- `h6_dft_scan/`: executed
- `h7_esd_review/`: executed
- `h8_io_pad_ring/`: executed

## Legacy Fallback Stage Paths (if present)

- none

## Actual Run Directories (scanned from this run)

- `01_inputs/`
- `02_v1_verilator_lint/`
- `03_v2_verilator_sim/`
- `04_v3_cdc_rdc/`
- `05_v3b_cdc_signoff_lite/`
- `06_v4_yosys_lec/`
- `07_h1_yosys/`
- `08_h2_openroad/`
- `09_h5_opensta/`
- `10_h4_klayout/`
- `11_h3_netgen/`
- `12_h9_power_ir_static/`
- `13_h10_power_ir_dynamic/`
- `14_h6_dft_scan/`
- `15_h7_esd_review/`
- `16_h8_io_pad_ring/`
- `17_production_intent/`
- `18_toolchain_resolution/`
- `19_subject_binding/`
- `20_skill_usage/`
- `21_dashboard_objects/`
- `22_reports/`

## Key Files (What They Mean)

- `22_reports/readiness_report.v0.2.md`: human-readable readiness summary and gate output.
- `22_reports/readiness_report_manifest.v0.2.json`: machine-readable report references and bindings.
- `22_reports/readiness_report_mapping.v0.2.json`: row-to-evidence mapping truth (direct vs non-direct).
- `22_reports/readiness_report_generation_log.v0.2.json`: generator gate outcomes and diagnostics.
- `pipeline_assembly_log.json`: pipeline assembly chain before report generation.
- `skill_usage/skill_usage_summary.md`: human-readable summary table (flow node → skill → verdict → evidence path).
- `skill_usage/skill_invocation_record.jsonl`: flow-node to skill invocation ledger (execution + decision-tree skills).
- `skill_usage/routing_decision_record.json`: governed route selection record for this run.
- `skill_usage/fallback_execution_record.json`: fallback trigger/result record (or explicit not-triggered).
- `enterprise_certification_manifest.v0.1.json`: RG-V18-001 enterprise certification baseline/status record for this run.

## `21_dashboard_objects/` Key Families (Derived Surfaces, Not Canonical Truth)

- `run_detail_manifest.json`, `readiness_manifest.json`: run-detail/readiness page bindings for console rendering.
- `architecture_model_view_manifest.json`, `scenario_requirement_matrix.json`, `architecture_candidate_scorecard*.json`: architecture exploration board inputs/drill-downs.
- `signoff_*` + `final_tapeout_readiness_record.json`: v1.13 signoff closure and final readiness adjudication objects.
- `tapeout_*`, `package_*`, `handoff_*`, `foundry_*`: v1.14 tapeout package, integrity, and handoff governance chain objects.
- `v115_*`: v1.15 post-tapeout bring-up, mismatch/errata/eco, backflow, and silicon feedback objects.
- `*_decision_inbox.json`: human-governed action queues (pending/completed) for signoff/tapeout/silicon-feedback flows.
- `*_summary.md`: human-readable companion summaries; canonical truth remains JSON governance objects and evidence refs.

## Terminology Clarification

- `h4_klayout` is the primary DRC evidence lane in this flow (`DRC (KLayout)`).
- `h3_netgen` is LVS only (`LVS (Netgen)`), not DRC.
- `h6_dft_scan` is a production signoff-evidence gate/review node in Routine-B, not the canonical location that defines DFT insertion timing in a full industrial flow.
- `inputs/architecture_estimation` and `inputs/hierarchy` are upstream companion artifacts; missing files are surfaced as soft-gate warnings in v1.0 alignment/readiness.

## Route Policy Notes

- Route-A OpenAI graph builder artifacts are present under `inputs/graph/`.
- Route-B capability/decision/re-entry binding artifacts are present under `subject_binding/`.

## Note

This file is auto-generated per production run and should be read together with the report-family and stage evidence files.
