# Tapeout Package Summary

- chip_id: `uart-controller-v0.1`
- run_id: `T-UART-001`
- execution: `20260523-095157`

## Package Verdict

- status: `PACKAGE_READY`
- handoff_profile: `MPW_SHUTTLE`
- artifact_count: `297`
- integrity_verdict: `PASS`

## Handoff Chain

- authority_decision: `PENDING`
- transfer_status: `PENDING`
- receipt_status: `PENDING`

## External Path Leak

- findings_count: `0`
