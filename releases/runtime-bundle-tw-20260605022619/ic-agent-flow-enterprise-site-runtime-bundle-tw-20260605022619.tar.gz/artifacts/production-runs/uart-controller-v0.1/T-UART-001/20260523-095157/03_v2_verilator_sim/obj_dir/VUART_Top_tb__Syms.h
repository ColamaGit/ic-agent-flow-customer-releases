// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Symbol table internal header
//
// Internal details; most calling programs do not need this header,
// unless using verilator public meta comments.

#ifndef VERILATED_VUART_TOP_TB__SYMS_H_
#define VERILATED_VUART_TOP_TB__SYMS_H_  // guard

#include "verilated.h"

// INCLUDE MODEL CLASS

#include "VUART_Top_tb.h"

// INCLUDE MODULE CLASSES
#include "VUART_Top_tb___024root.h"

// SYMS CLASS (contains all model state)
class alignas(VL_CACHE_LINE_BYTES) VUART_Top_tb__Syms final : public VerilatedSyms {
  public:
    // INTERNAL STATE
    VUART_Top_tb* const __Vm_modelp;
    VlDeleter __Vm_deleter;
    bool __Vm_didInit = false;

    // MODULE INSTANCE STATE
    VUART_Top_tb___024root         TOP;

    // COVERAGE
    uint32_t __Vcoverage[385];

    // CONSTRUCTORS
    VUART_Top_tb__Syms(VerilatedContext* contextp, const char* namep, VUART_Top_tb* modelp);
    ~VUART_Top_tb__Syms();

    // METHODS
    const char* name() const { return TOP.vlNamep; }
};

#endif  // guard
