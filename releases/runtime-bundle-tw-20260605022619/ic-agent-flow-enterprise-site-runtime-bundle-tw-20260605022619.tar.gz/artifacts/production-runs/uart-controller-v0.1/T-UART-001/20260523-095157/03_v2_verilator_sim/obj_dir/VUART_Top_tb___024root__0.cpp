// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See VUART_Top_tb.h for the primary calling header

#include "VUART_Top_tb__pch.h"

VlCoroutine VUART_Top_tb___024root___eval_initial__TOP__Vtiming__0(VUART_Top_tb___024root* vlSelf);
VlCoroutine VUART_Top_tb___024root___eval_initial__TOP__Vtiming__1(VUART_Top_tb___024root* vlSelf);
VlCoroutine VUART_Top_tb___024root___eval_initial__TOP__Vtiming__2(VUART_Top_tb___024root* vlSelf);

void VUART_Top_tb___024root___eval_initial(VUART_Top_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VUART_Top_tb___024root___eval_initial\n"); );
    VUART_Top_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    VUART_Top_tb___024root___eval_initial__TOP__Vtiming__0(vlSelf);
    VUART_Top_tb___024root___eval_initial__TOP__Vtiming__1(vlSelf);
    VUART_Top_tb___024root___eval_initial__TOP__Vtiming__2(vlSelf);
}

void VUART_Top_tb___024root____VbeforeTrig_h62ac6386__0(VUART_Top_tb___024root* vlSelf, const char* __VeventDescription);

VlCoroutine VUART_Top_tb___024root___eval_initial__TOP__Vtiming__0(VUART_Top_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VUART_Top_tb___024root___eval_initial__TOP__Vtiming__0\n"); );
    VUART_Top_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    IData/*31:0*/ UART_Top_tb__DOT__i;
    UART_Top_tb__DOT__i = 0;
    IData/*31:0*/ UART_Top_tb__DOT__unnamedblk1_3__DOT____Vrepeat2;
    UART_Top_tb__DOT__unnamedblk1_3__DOT____Vrepeat2 = 0;
    IData/*31:0*/ UART_Top_tb__DOT__unnamedblk1_4__DOT____Vrepeat3;
    UART_Top_tb__DOT__unnamedblk1_4__DOT____Vrepeat3 = 0;
    CData/*1:0*/ __Vtask_UART_Top_tb__DOT__run_uart_case__0__sel_i;
    __Vtask_UART_Top_tb__DOT__run_uart_case__0__sel_i = 0;
    CData/*7:0*/ __Vtask_UART_Top_tb__DOT__run_uart_case__0__tx_i;
    __Vtask_UART_Top_tb__DOT__run_uart_case__0__tx_i = 0;
    IData/*31:0*/ __Vtask_UART_Top_tb__DOT__run_uart_case__0__UART_Top_tb__DOT__unnamedblk1_1__DOT____Vrepeat0;
    __Vtask_UART_Top_tb__DOT__run_uart_case__0__UART_Top_tb__DOT__unnamedblk1_1__DOT____Vrepeat0 = 0;
    IData/*31:0*/ __Vtask_UART_Top_tb__DOT__run_uart_case__0__UART_Top_tb__DOT__unnamedblk1_2__DOT____Vrepeat1;
    __Vtask_UART_Top_tb__DOT__run_uart_case__0__UART_Top_tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0;
    CData/*1:0*/ __Vtask_UART_Top_tb__DOT__run_uart_case__1__sel_i;
    __Vtask_UART_Top_tb__DOT__run_uart_case__1__sel_i = 0;
    CData/*7:0*/ __Vtask_UART_Top_tb__DOT__run_uart_case__1__tx_i;
    __Vtask_UART_Top_tb__DOT__run_uart_case__1__tx_i = 0;
    IData/*31:0*/ __Vtask_UART_Top_tb__DOT__run_uart_case__1__UART_Top_tb__DOT__unnamedblk1_1__DOT____Vrepeat0;
    __Vtask_UART_Top_tb__DOT__run_uart_case__1__UART_Top_tb__DOT__unnamedblk1_1__DOT____Vrepeat0 = 0;
    IData/*31:0*/ __Vtask_UART_Top_tb__DOT__run_uart_case__1__UART_Top_tb__DOT__unnamedblk1_2__DOT____Vrepeat1;
    __Vtask_UART_Top_tb__DOT__run_uart_case__1__UART_Top_tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0;
    // Body
    vlSelfRef.UART_Top_tb__DOT__clk = 0U;
    vlSelfRef.UART_Top_tb__DOT__sel = 2U;
    vlSelfRef.UART_Top_tb__DOT__TX_start = 0U;
    vlSelfRef.UART_Top_tb__DOT__TX_DATA = 0U;
    vlSelfRef.UART_Top_tb__DOT__reset = 0U;
    UART_Top_tb__DOT__unnamedblk1_3__DOT____Vrepeat2 = 4U;
    while (VL_LTS_III(32, 0U, UART_Top_tb__DOT__unnamedblk1_3__DOT____Vrepeat2)) {
        VUART_Top_tb___024root____VbeforeTrig_h62ac6386__0(vlSelf, 
                                                           "@(posedge UART_Top_tb.clk)");
        co_await vlSelfRef.__VtrigSched_h62ac6386__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge UART_Top_tb.clk)", 
                                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/uart-controller-v0.1/T-UART-001/20260523-095157/inputs/design/rtl/UART_Top_tb.v", 
                                                             71);
        UART_Top_tb__DOT__unnamedblk1_3__DOT____Vrepeat2 
            = (UART_Top_tb__DOT__unnamedblk1_3__DOT____Vrepeat2 
               - (IData)(1U));
        ++(vlSymsp->__Vcoverage[49]);
    }
    vlSelfRef.UART_Top_tb__DOT__reset = 1U;
    UART_Top_tb__DOT__unnamedblk1_4__DOT____Vrepeat3 = 4U;
    while (VL_LTS_III(32, 0U, UART_Top_tb__DOT__unnamedblk1_4__DOT____Vrepeat3)) {
        VUART_Top_tb___024root____VbeforeTrig_h62ac6386__0(vlSelf, 
                                                           "@(posedge UART_Top_tb.clk)");
        co_await vlSelfRef.__VtrigSched_h62ac6386__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge UART_Top_tb.clk)", 
                                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/uart-controller-v0.1/T-UART-001/20260523-095157/inputs/design/rtl/UART_Top_tb.v", 
                                                             73);
        UART_Top_tb__DOT__unnamedblk1_4__DOT____Vrepeat3 
            = (UART_Top_tb__DOT__unnamedblk1_4__DOT____Vrepeat3 
               - (IData)(1U));
        ++(vlSymsp->__Vcoverage[50]);
    }
    __Vtask_UART_Top_tb__DOT__run_uart_case__0__tx_i = 0U;
    __Vtask_UART_Top_tb__DOT__run_uart_case__0__sel_i = 2U;
    __Vtask_UART_Top_tb__DOT__run_uart_case__0__UART_Top_tb__DOT__unnamedblk1_1__DOT____Vrepeat0 = 0;
    __Vtask_UART_Top_tb__DOT__run_uart_case__0__UART_Top_tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0;
    vlSelfRef.UART_Top_tb__DOT__sel = __Vtask_UART_Top_tb__DOT__run_uart_case__0__sel_i;
    vlSelfRef.UART_Top_tb__DOT__TX_DATA = __Vtask_UART_Top_tb__DOT__run_uart_case__0__tx_i;
    __Vtask_UART_Top_tb__DOT__run_uart_case__0__UART_Top_tb__DOT__unnamedblk1_1__DOT____Vrepeat0 = 8U;
    while (VL_LTS_III(32, 0U, __Vtask_UART_Top_tb__DOT__run_uart_case__0__UART_Top_tb__DOT__unnamedblk1_1__DOT____Vrepeat0)) {
        VUART_Top_tb___024root____VbeforeTrig_h62ac6386__0(vlSelf, 
                                                           "@(posedge UART_Top_tb.clk)");
        co_await vlSelfRef.__VtrigSched_h62ac6386__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge UART_Top_tb.clk)", 
                                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/uart-controller-v0.1/T-UART-001/20260523-095157/inputs/design/rtl/UART_Top_tb.v", 
                                                             56);
        __Vtask_UART_Top_tb__DOT__run_uart_case__0__UART_Top_tb__DOT__unnamedblk1_1__DOT____Vrepeat0 
            = (__Vtask_UART_Top_tb__DOT__run_uart_case__0__UART_Top_tb__DOT__unnamedblk1_1__DOT____Vrepeat0 
               - (IData)(1U));
        ++(vlSymsp->__Vcoverage[46]);
    }
    vlSelfRef.UART_Top_tb__DOT__TX_start = 1U;
    VUART_Top_tb___024root____VbeforeTrig_h62ac6386__0(vlSelf, 
                                                       "@(posedge UART_Top_tb.clk)");
    co_await vlSelfRef.__VtrigSched_h62ac6386__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge UART_Top_tb.clk)", 
                                                         "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/uart-controller-v0.1/T-UART-001/20260523-095157/inputs/design/rtl/UART_Top_tb.v", 
                                                         58);
    vlSelfRef.UART_Top_tb__DOT__TX_start = 0U;
    __Vtask_UART_Top_tb__DOT__run_uart_case__0__UART_Top_tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0x00000384U;
    while (VL_LTS_III(32, 0U, __Vtask_UART_Top_tb__DOT__run_uart_case__0__UART_Top_tb__DOT__unnamedblk1_2__DOT____Vrepeat1)) {
        VUART_Top_tb___024root____VbeforeTrig_h62ac6386__0(vlSelf, 
                                                           "@(posedge UART_Top_tb.clk)");
        co_await vlSelfRef.__VtrigSched_h62ac6386__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge UART_Top_tb.clk)", 
                                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/uart-controller-v0.1/T-UART-001/20260523-095157/inputs/design/rtl/UART_Top_tb.v", 
                                                             60);
        __Vtask_UART_Top_tb__DOT__run_uart_case__0__UART_Top_tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
            = (__Vtask_UART_Top_tb__DOT__run_uart_case__0__UART_Top_tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
               - (IData)(1U));
        ++(vlSymsp->__Vcoverage[47]);
    }
    ++(vlSymsp->__Vcoverage[48]);
    if (vlSymsp->_vm_contextp__->assertOnGet(2, 1)) {
        if (VL_UNLIKELY(((1U & (~ ((((IData)(vlSelfRef.UART_Top_tb__DOT__RX_dataout) 
                                     == (IData)(vlSelfRef.UART_Top_tb__DOT__TX_DATA)) 
                                    & (~ (IData)(vlSelfRef.UART_Top_tb__DOT__stop_error))) 
                                   & (~ (IData)(vlSelfRef.UART_Top_tb__DOT__parity_error)))))))) {
            VL_WRITEF_NX("[%0t] %%Error: UART_Top_tb.v:78: Assertion failed in %m: UART assertion failed: expected=%h actual=%h stop_error=%b parity_error=%b\n",7, 'M',vlSymsp->name(),"UART_Top_tb", 'T',-9
                         , '#',64,VL_TIME_UNITED_Q(1000)
                         , '#',8,(IData)(vlSelfRef.UART_Top_tb__DOT__TX_DATA)
                         , '#',8,vlSelfRef.UART_Top_tb__DOT__RX_dataout
                         , '#',1,(IData)(vlSelfRef.UART_Top_tb__DOT__stop_error)
                         , '#',1,vlSelfRef.UART_Top_tb__DOT__parity_error);
            VL_STOP_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/uart-controller-v0.1/T-UART-001/20260523-095157/inputs/design/rtl/UART_Top_tb.v", 78, "");
        }
    }
    UART_Top_tb__DOT__i = 0U;
    while (VL_GTS_III(32, 0x0000000cU, UART_Top_tb__DOT__i)) {
        __Vtask_UART_Top_tb__DOT__run_uart_case__1__tx_i 
            = (0x000000ffU & (0xc3U ^ ((IData)(0x11U) 
                                       * (0x000000ffU 
                                          & UART_Top_tb__DOT__i))));
        __Vtask_UART_Top_tb__DOT__run_uart_case__1__sel_i = 2U;
        __Vtask_UART_Top_tb__DOT__run_uart_case__1__UART_Top_tb__DOT__unnamedblk1_1__DOT____Vrepeat0 = 0;
        __Vtask_UART_Top_tb__DOT__run_uart_case__1__UART_Top_tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0;
        vlSelfRef.UART_Top_tb__DOT__sel = __Vtask_UART_Top_tb__DOT__run_uart_case__1__sel_i;
        vlSelfRef.UART_Top_tb__DOT__TX_DATA = __Vtask_UART_Top_tb__DOT__run_uart_case__1__tx_i;
        __Vtask_UART_Top_tb__DOT__run_uart_case__1__UART_Top_tb__DOT__unnamedblk1_1__DOT____Vrepeat0 = 8U;
        while (VL_LTS_III(32, 0U, __Vtask_UART_Top_tb__DOT__run_uart_case__1__UART_Top_tb__DOT__unnamedblk1_1__DOT____Vrepeat0)) {
            VUART_Top_tb___024root____VbeforeTrig_h62ac6386__0(vlSelf, 
                                                               "@(posedge UART_Top_tb.clk)");
            co_await vlSelfRef.__VtrigSched_h62ac6386__0.trigger(0U, 
                                                                 nullptr, 
                                                                 "@(posedge UART_Top_tb.clk)", 
                                                                 "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/uart-controller-v0.1/T-UART-001/20260523-095157/inputs/design/rtl/UART_Top_tb.v", 
                                                                 56);
            __Vtask_UART_Top_tb__DOT__run_uart_case__1__UART_Top_tb__DOT__unnamedblk1_1__DOT____Vrepeat0 
                = (__Vtask_UART_Top_tb__DOT__run_uart_case__1__UART_Top_tb__DOT__unnamedblk1_1__DOT____Vrepeat0 
                   - (IData)(1U));
            ++(vlSymsp->__Vcoverage[46]);
        }
        vlSelfRef.UART_Top_tb__DOT__TX_start = 1U;
        VUART_Top_tb___024root____VbeforeTrig_h62ac6386__0(vlSelf, 
                                                           "@(posedge UART_Top_tb.clk)");
        co_await vlSelfRef.__VtrigSched_h62ac6386__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge UART_Top_tb.clk)", 
                                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/uart-controller-v0.1/T-UART-001/20260523-095157/inputs/design/rtl/UART_Top_tb.v", 
                                                             58);
        vlSelfRef.UART_Top_tb__DOT__TX_start = 0U;
        __Vtask_UART_Top_tb__DOT__run_uart_case__1__UART_Top_tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0x00000384U;
        while (VL_LTS_III(32, 0U, __Vtask_UART_Top_tb__DOT__run_uart_case__1__UART_Top_tb__DOT__unnamedblk1_2__DOT____Vrepeat1)) {
            VUART_Top_tb___024root____VbeforeTrig_h62ac6386__0(vlSelf, 
                                                               "@(posedge UART_Top_tb.clk)");
            co_await vlSelfRef.__VtrigSched_h62ac6386__0.trigger(0U, 
                                                                 nullptr, 
                                                                 "@(posedge UART_Top_tb.clk)", 
                                                                 "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/uart-controller-v0.1/T-UART-001/20260523-095157/inputs/design/rtl/UART_Top_tb.v", 
                                                                 60);
            __Vtask_UART_Top_tb__DOT__run_uart_case__1__UART_Top_tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
                = (__Vtask_UART_Top_tb__DOT__run_uart_case__1__UART_Top_tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
                   - (IData)(1U));
            ++(vlSymsp->__Vcoverage[47]);
        }
        ++(vlSymsp->__Vcoverage[48]);
        if (VL_UNLIKELY((((((IData)(vlSelfRef.UART_Top_tb__DOT__RX_dataout) 
                            != (IData)(vlSelfRef.UART_Top_tb__DOT__TX_DATA)) 
                           | (IData)(vlSelfRef.UART_Top_tb__DOT__stop_error)) 
                          | (IData)(vlSelfRef.UART_Top_tb__DOT__parity_error))))) {
            VL_WRITEF_NX("UART_COV_WARN: sel=%b expected=%h actual=%h stop_error=%b parity_error=%b\n",5
                         , '#',2,vlSelfRef.UART_Top_tb__DOT__sel
                         , '#',8,(IData)(vlSelfRef.UART_Top_tb__DOT__TX_DATA)
                         , '#',8,vlSelfRef.UART_Top_tb__DOT__RX_dataout
                         , '#',1,(IData)(vlSelfRef.UART_Top_tb__DOT__stop_error)
                         , '#',1,vlSelfRef.UART_Top_tb__DOT__parity_error);
            ++(vlSymsp->__Vcoverage[55]);
        } else {
            ++(vlSymsp->__Vcoverage[56]);
        }
        UART_Top_tb__DOT__i = ((IData)(1U) + UART_Top_tb__DOT__i);
        ++(vlSymsp->__Vcoverage[61]);
    }
    VL_WRITEF_NX("UART_SIM_PASS\n",0);
    VL_FINISH_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/uart-controller-v0.1/T-UART-001/20260523-095157/inputs/design/rtl/UART_Top_tb.v", 92, "");
    if (((((IData)(vlSelfRef.UART_Top_tb__DOT__RX_dataout) 
           == (IData)(vlSelfRef.UART_Top_tb__DOT__TX_DATA)) 
          & (~ (IData)(vlSelfRef.UART_Top_tb__DOT__stop_error))) 
         & (~ (IData)(vlSelfRef.UART_Top_tb__DOT__parity_error)))) {
        ++(vlSymsp->__Vcoverage[51]);
    }
    if (vlSelfRef.UART_Top_tb__DOT__parity_error) {
        ++(vlSymsp->__Vcoverage[52]);
    }
    if (vlSelfRef.UART_Top_tb__DOT__stop_error) {
        ++(vlSymsp->__Vcoverage[53]);
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__RX_dataout) 
         != (IData)(vlSelfRef.UART_Top_tb__DOT__TX_DATA))) {
        ++(vlSymsp->__Vcoverage[54]);
    }
    if (vlSelfRef.UART_Top_tb__DOT__parity_error) {
        ++(vlSymsp->__Vcoverage[57]);
    }
    if (vlSelfRef.UART_Top_tb__DOT__stop_error) {
        ++(vlSymsp->__Vcoverage[58]);
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__RX_dataout) 
         != (IData)(vlSelfRef.UART_Top_tb__DOT__TX_DATA))) {
        ++(vlSymsp->__Vcoverage[59]);
    }
    if (((((IData)(vlSelfRef.UART_Top_tb__DOT__RX_dataout) 
           == (IData)(vlSelfRef.UART_Top_tb__DOT__TX_DATA)) 
          & (~ (IData)(vlSelfRef.UART_Top_tb__DOT__stop_error))) 
         & (~ (IData)(vlSelfRef.UART_Top_tb__DOT__parity_error)))) {
        ++(vlSymsp->__Vcoverage[60]);
    }
    co_return;
}

VlCoroutine VUART_Top_tb___024root___eval_initial__TOP__Vtiming__1(VUART_Top_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VUART_Top_tb___024root___eval_initial__TOP__Vtiming__1\n"); );
    VUART_Top_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    IData/*31:0*/ UART_Top_tb__DOT__unnamedblk1_5__DOT____Vrepeat4;
    UART_Top_tb__DOT__unnamedblk1_5__DOT____Vrepeat4 = 0;
    // Body
    UART_Top_tb__DOT__unnamedblk1_5__DOT____Vrepeat4 = 0x000036b0U;
    while (VL_LTS_III(32, 0U, UART_Top_tb__DOT__unnamedblk1_5__DOT____Vrepeat4)) {
        VUART_Top_tb___024root____VbeforeTrig_h62ac6386__0(vlSelf, 
                                                           "@(posedge UART_Top_tb.clk)");
        co_await vlSelfRef.__VtrigSched_h62ac6386__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge UART_Top_tb.clk)", 
                                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/uart-controller-v0.1/T-UART-001/20260523-095157/inputs/design/rtl/UART_Top_tb.v", 
                                                             96);
        UART_Top_tb__DOT__unnamedblk1_5__DOT____Vrepeat4 
            = (UART_Top_tb__DOT__unnamedblk1_5__DOT____Vrepeat4 
               - (IData)(1U));
        ++(vlSymsp->__Vcoverage[62]);
    }
    VL_WRITEF_NX("[%0t] %%Error: UART_Top_tb.v:97: Assertion failed in %m: UART simulation watchdog timeout\n",3, 'M',vlSymsp->name(),"UART_Top_tb", 'T',-9
                 , '#',64,VL_TIME_UNITED_Q(1000));
    VL_STOP_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/uart-controller-v0.1/T-UART-001/20260523-095157/inputs/design/rtl/UART_Top_tb.v", 97, "");
    VL_FINISH_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/uart-controller-v0.1/T-UART-001/20260523-095157/inputs/design/rtl/UART_Top_tb.v", 98, "");
    co_return;
}

VlCoroutine VUART_Top_tb___024root___eval_initial__TOP__Vtiming__2(VUART_Top_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VUART_Top_tb___024root___eval_initial__TOP__Vtiming__2\n"); );
    VUART_Top_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    while (VL_LIKELY(!vlSymsp->_vm_contextp__->gotFinish())) {
        co_await vlSelfRef.__VdlySched.delay(0x0000000000002710ULL, 
                                             nullptr, 
                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/uart-controller-v0.1/T-UART-001/20260523-095157/inputs/design/rtl/UART_Top_tb.v", 
                                             101);
        vlSelfRef.UART_Top_tb__DOT__clk = (1U & (~ (IData)(vlSelfRef.UART_Top_tb__DOT__clk)));
        if ((1U & (~ (IData)(vlSelfRef.UART_Top_tb__DOT__clk)))) {
            ++(vlSymsp->__Vcoverage[63]);
        }
        if (vlSelfRef.UART_Top_tb__DOT__clk) {
            ++(vlSymsp->__Vcoverage[64]);
        }
        ++(vlSymsp->__Vcoverage[65]);
    }
    co_return;
}

void VUART_Top_tb___024root___eval_triggers_vec__act(VUART_Top_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VUART_Top_tb___024root___eval_triggers_vec__act\n"); );
    VUART_Top_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__VactTriggered[0U] = (QData)((IData)(
                                                    ((vlSelfRef.__VdlySched.awaitingCurrentTime() 
                                                      << 4U) 
                                                     | (((((IData)(vlSelfRef.UART_Top_tb__DOT__clk) 
                                                           & (~ (IData)(vlSelfRef.__Vtrigprevexpr___TOP__UART_Top_tb__DOT__clk__0))) 
                                                          << 3U) 
                                                         | (((~ (IData)(vlSelfRef.UART_Top_tb__DOT__reset)) 
                                                             & (IData)(vlSelfRef.__Vtrigprevexpr___TOP__UART_Top_tb__DOT__reset__0)) 
                                                            << 2U)) 
                                                        | ((((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__clock_out) 
                                                             & (~ (IData)(vlSelfRef.__Vtrigprevexpr___TOP__UART_Top_tb__DOT__uut__DOT__clock_out__0))) 
                                                            << 1U) 
                                                           | ((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__parity_load) 
                                                              != (IData)(vlSelfRef.__Vtrigprevexpr___TOP__UART_Top_tb__DOT__uut__DOT__r3__DOT__parity_load__0)))))));
    vlSelfRef.__Vtrigprevexpr___TOP__UART_Top_tb__DOT__uut__DOT__r3__DOT__parity_load__0 
        = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__parity_load;
    vlSelfRef.__Vtrigprevexpr___TOP__UART_Top_tb__DOT__uut__DOT__clock_out__0 
        = vlSelfRef.UART_Top_tb__DOT__uut__DOT__clock_out;
    vlSelfRef.__Vtrigprevexpr___TOP__UART_Top_tb__DOT__reset__0 
        = vlSelfRef.UART_Top_tb__DOT__reset;
    vlSelfRef.__Vtrigprevexpr___TOP__UART_Top_tb__DOT__clk__0 
        = vlSelfRef.UART_Top_tb__DOT__clk;
}

bool VUART_Top_tb___024root___trigger_anySet__act(const VlUnpacked<QData/*63:0*/, 1> &in) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VUART_Top_tb___024root___trigger_anySet__act\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        if (in[n]) {
            return (1U);
        }
        n = ((IData)(1U) + n);
    } while ((1U > n));
    return (0U);
}

void VUART_Top_tb___024root___act_sequent__TOP__0(VUART_Top_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VUART_Top_tb___024root___act_sequent__TOP__0\n"); );
    VUART_Top_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__sel) ^ (IData)(vlSelfRef.UART_Top_tb__DOT____Vtogcov__sel))) {
        VL_COV_TOGGLE_CHG_ST_I(2, vlSymsp->__Vcoverage + 0, vlSelfRef.UART_Top_tb__DOT__sel, vlSelfRef.UART_Top_tb__DOT____Vtogcov__sel);
        vlSelfRef.UART_Top_tb__DOT____Vtogcov__sel 
            = vlSelfRef.UART_Top_tb__DOT__sel;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__TX_start) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT____Vtogcov__TX_start))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 4, vlSelfRef.UART_Top_tb__DOT__TX_start, vlSelfRef.UART_Top_tb__DOT____Vtogcov__TX_start);
        vlSelfRef.UART_Top_tb__DOT____Vtogcov__TX_start 
            = vlSelfRef.UART_Top_tb__DOT__TX_start;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__TX_DATA) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT____Vtogcov__TX_DATA))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 6, vlSelfRef.UART_Top_tb__DOT__TX_DATA, vlSelfRef.UART_Top_tb__DOT____Vtogcov__TX_DATA);
        vlSelfRef.UART_Top_tb__DOT____Vtogcov__TX_DATA 
            = vlSelfRef.UART_Top_tb__DOT__TX_DATA;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__reset) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT____Vtogcov__reset))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 24, vlSelfRef.UART_Top_tb__DOT__reset, vlSelfRef.UART_Top_tb__DOT____Vtogcov__reset);
        vlSelfRef.UART_Top_tb__DOT____Vtogcov__reset 
            = vlSelfRef.UART_Top_tb__DOT__reset;
    }
    if ((2U & (IData)(vlSelfRef.UART_Top_tb__DOT__sel))) {
        if ((1U & (IData)(vlSelfRef.UART_Top_tb__DOT__sel))) {
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT__temp = 0x0145U;
            ++(vlSymsp->__Vcoverage[239]);
        } else {
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT__temp = 0x00a2U;
            ++(vlSymsp->__Vcoverage[238]);
        }
    } else if ((1U & (IData)(vlSelfRef.UART_Top_tb__DOT__sel))) {
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT__temp = 0x0145U;
        ++(vlSymsp->__Vcoverage[237]);
    } else {
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT__temp = 0x0517U;
        ++(vlSymsp->__Vcoverage[236]);
    }
    ++(vlSymsp->__Vcoverage[240]);
    if ((4U & (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__state))) {
        if ((2U & (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__state))) {
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__next_state = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__load_data = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__shift = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s0 = 1U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s1 = 1U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp1 = 0U;
            ++(vlSymsp->__Vcoverage[145]);
        } else if ((1U & (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__state))) {
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__next_state = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__load_data = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__shift = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s0 = 1U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s1 = 1U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp1 = 0U;
            ++(vlSymsp->__Vcoverage[145]);
        } else {
            if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__flag1) {
                ++(vlSymsp->__Vcoverage[142]);
                vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____VlemCond_4 = 0U;
            } else {
                ++(vlSymsp->__Vcoverage[143]);
                vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____VlemCond_4 = 4U;
            }
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__load_data = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__shift = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s0 = 1U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s1 = 1U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp1 = 1U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__next_state 
                = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____VlemCond_4;
            ++(vlSymsp->__Vcoverage[144]);
        }
    } else if ((2U & (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__state))) {
        if ((1U & (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__state))) {
            if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__flag1) {
                ++(vlSymsp->__Vcoverage[137]);
                vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____VlemCond_3 = 4U;
            } else {
                ++(vlSymsp->__Vcoverage[138]);
                vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____VlemCond_3 = 3U;
            }
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__load_data = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__shift = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s0 = 1U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s1 = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp1 = 1U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__next_state 
                = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____VlemCond_3;
            ++(vlSymsp->__Vcoverage[139]);
        } else {
            if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__flag2) {
                ++(vlSymsp->__Vcoverage[132]);
                vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____VlemCond_2 = 3U;
            } else {
                ++(vlSymsp->__Vcoverage[133]);
                vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____VlemCond_2 = 2U;
            }
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__load_data = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__shift = 1U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s0 = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s1 = 1U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp = 1U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp1 = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__next_state 
                = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____VlemCond_2;
            ++(vlSymsp->__Vcoverage[134]);
        }
    } else if ((1U & (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__state))) {
        if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__flag1) {
            ++(vlSymsp->__Vcoverage[127]);
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____VlemCond_1 = 2U;
        } else {
            ++(vlSymsp->__Vcoverage[128]);
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____VlemCond_1 = 1U;
        }
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__load_data = 1U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__shift = 0U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s0 = 0U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s1 = 0U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp = 0U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp1 = 1U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__next_state 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____VlemCond_1;
        ++(vlSymsp->__Vcoverage[129]);
    } else {
        if (vlSelfRef.UART_Top_tb__DOT__TX_start) {
            ++(vlSymsp->__Vcoverage[122]);
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____VlemCond_0 = 1U;
        } else {
            ++(vlSymsp->__Vcoverage[123]);
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____VlemCond_0 = 0U;
        }
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__load_data = 0U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__shift = 0U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s0 = 1U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s1 = 1U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp = 0U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp1 = 0U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__next_state 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____VlemCond_0;
        ++(vlSymsp->__Vcoverage[124]);
    }
    if (vlSelfRef.UART_Top_tb__DOT__TX_start) {
        ++(vlSymsp->__Vcoverage[120]);
    }
    if ((1U & (~ (IData)(vlSelfRef.UART_Top_tb__DOT__TX_start)))) {
        ++(vlSymsp->__Vcoverage[121]);
    }
    if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__flag1) {
        ++(vlSymsp->__Vcoverage[125]);
    }
    if ((1U & (~ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__flag1)))) {
        ++(vlSymsp->__Vcoverage[126]);
    }
    if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__flag2) {
        ++(vlSymsp->__Vcoverage[130]);
    }
    if ((1U & (~ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__flag2)))) {
        ++(vlSymsp->__Vcoverage[131]);
    }
    if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__flag1) {
        ++(vlSymsp->__Vcoverage[135]);
    }
    if ((1U & (~ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__flag1)))) {
        ++(vlSymsp->__Vcoverage[136]);
    }
    if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__flag1) {
        ++(vlSymsp->__Vcoverage[140]);
    }
    if ((1U & (~ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__flag1)))) {
        ++(vlSymsp->__Vcoverage[141]);
    }
    ++(vlSymsp->__Vcoverage[146]);
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT__temp) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT____Vtogcov__temp))) {
        VL_COV_TOGGLE_CHG_ST_I(12, vlSymsp->__Vcoverage + 188, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT__temp, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT____Vtogcov__temp);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT____Vtogcov__temp 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT__temp;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__next_state) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__next_state))) {
        VL_COV_TOGGLE_CHG_ST_I(3, vlSymsp->__Vcoverage + 88, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__next_state, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__next_state);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__next_state 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__next_state;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__shift) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__shift))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 74, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__shift, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__shift);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__shift 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__shift;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__temp))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 98, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__temp);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__temp 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp1) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__temp1))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 100, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp1, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__temp1);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__temp1 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp1;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s0) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__s0))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 70, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s0, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__s0);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__s0 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s0;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s1) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__s1))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 72, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s1, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__s1);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__s1 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s1;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__load_data) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__load_data))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 76, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__load_data, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__load_data);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__load_data 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__load_data;
    }
    if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__load_data) {
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__PARITY_BIT 
            = (1U & VL_REDXOR_8(vlSelfRef.UART_Top_tb__DOT__TX_DATA));
        ++(vlSymsp->__Vcoverage[185]);
    } else {
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__PARITY_BIT = 0U;
        ++(vlSymsp->__Vcoverage[186]);
    }
    ++(vlSymsp->__Vcoverage[187]);
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__PARITY_BIT) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__PARITY_BIT))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 80, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__PARITY_BIT, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__PARITY_BIT);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__PARITY_BIT 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__PARITY_BIT;
    }
    vlSelfRef.UART_Top_tb__DOT__uut__DOT__TX_dataout 
        = (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s0) 
            & ((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s1) 
               | (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__PARITY_BIT))) 
           | ((~ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s0)) 
              & ((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s1) 
                 & (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__DATA_BIT))));
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__TX_dataout) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT____Vtogcov__TX_dataout))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 66, vlSelfRef.UART_Top_tb__DOT__uut__DOT__TX_dataout, vlSelfRef.UART_Top_tb__DOT__uut__DOT____Vtogcov__TX_dataout);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT____Vtogcov__TX_dataout 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__TX_dataout;
    }
}

void VUART_Top_tb___024root___act_comb__TOP__0(VUART_Top_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VUART_Top_tb___024root___act_comb__TOP__0\n"); );
    VUART_Top_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__clk) ^ (IData)(vlSelfRef.UART_Top_tb__DOT____Vtogcov__clk))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 22, vlSelfRef.UART_Top_tb__DOT__clk, vlSelfRef.UART_Top_tb__DOT____Vtogcov__clk);
        vlSelfRef.UART_Top_tb__DOT____Vtogcov__clk 
            = vlSelfRef.UART_Top_tb__DOT__clk;
    }
}

void VUART_Top_tb___024root___act_comb__TOP__1(VUART_Top_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VUART_Top_tb___024root___act_comb__TOP__1\n"); );
    VUART_Top_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__parity_load) {
        if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__TX_dataout) 
             == (1U & VL_REDXOR_8(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t3__DOT__temp)))) {
            vlSelfRef.UART_Top_tb__DOT__parity_error = 0U;
            ++(vlSymsp->__Vcoverage[365]);
        } else {
            vlSelfRef.UART_Top_tb__DOT__parity_error = 1U;
            ++(vlSymsp->__Vcoverage[366]);
        }
        ++(vlSymsp->__Vcoverage[367]);
    } else {
        vlSelfRef.UART_Top_tb__DOT__parity_error = 0U;
        ++(vlSymsp->__Vcoverage[368]);
    }
    ++(vlSymsp->__Vcoverage[369]);
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__parity_error) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT____Vtogcov__parity_error))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 28, vlSelfRef.UART_Top_tb__DOT__parity_error, vlSelfRef.UART_Top_tb__DOT____Vtogcov__parity_error);
        vlSelfRef.UART_Top_tb__DOT____Vtogcov__parity_error 
            = vlSelfRef.UART_Top_tb__DOT__parity_error;
    }
    if ((4U & (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__state))) {
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__next_state = 0U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__shift = 0U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__parity_load = 0U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__check_stop = 0U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__temp = 0U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__temp1 = 0U;
        ++(vlSymsp->__Vcoverage[344]);
    } else if ((2U & (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__state))) {
        if ((1U & (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__state))) {
            if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__flag2) {
                ++(vlSymsp->__Vcoverage[341]);
                vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____VlemCond_3 = 0U;
            } else {
                ++(vlSymsp->__Vcoverage[342]);
                vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____VlemCond_3 = 3U;
            }
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__shift = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__parity_load = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__check_stop = 1U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__temp = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__temp1 = 1U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__next_state 
                = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____VlemCond_3;
            ++(vlSymsp->__Vcoverage[343]);
        } else {
            if (vlSelfRef.UART_Top_tb__DOT__parity_error) {
                ++(vlSymsp->__Vcoverage[334]);
                vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____VlemCond_2 = 0U;
            } else {
                ++(vlSymsp->__Vcoverage[337]);
                if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__flag2) {
                    ++(vlSymsp->__Vcoverage[335]);
                    vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____VlemCond_2 = 3U;
                } else {
                    ++(vlSymsp->__Vcoverage[336]);
                    vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____VlemCond_2 = 2U;
                }
            }
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__shift = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__parity_load = 1U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__check_stop = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__temp = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__temp1 = 1U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__next_state 
                = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____VlemCond_2;
            ++(vlSymsp->__Vcoverage[338]);
        }
    } else if ((1U & (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__state))) {
        if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__flag1) {
            ++(vlSymsp->__Vcoverage[329]);
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____VlemCond_1 = 2U;
        } else {
            ++(vlSymsp->__Vcoverage[330]);
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____VlemCond_1 = 1U;
        }
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__shift = 1U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__parity_load = 0U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__check_stop = 0U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__temp = 1U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__temp1 = 0U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__next_state 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____VlemCond_1;
        ++(vlSymsp->__Vcoverage[331]);
    } else {
        if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__de_strtbit) {
            ++(vlSymsp->__Vcoverage[324]);
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____VlemCond_0 = 1U;
        } else {
            ++(vlSymsp->__Vcoverage[325]);
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____VlemCond_0 = 0U;
        }
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__shift = 0U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__parity_load = 0U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__check_stop = 0U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__temp = 0U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__temp1 = 0U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__next_state 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____VlemCond_0;
        ++(vlSymsp->__Vcoverage[326]);
    }
    if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__de_strtbit) {
        ++(vlSymsp->__Vcoverage[322]);
    }
    if ((1U & (~ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__de_strtbit)))) {
        ++(vlSymsp->__Vcoverage[323]);
    }
    if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__flag1) {
        ++(vlSymsp->__Vcoverage[327]);
    }
    if ((1U & (~ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__flag1)))) {
        ++(vlSymsp->__Vcoverage[328]);
    }
    if (vlSelfRef.UART_Top_tb__DOT__parity_error) {
        ++(vlSymsp->__Vcoverage[332]);
    }
    if ((1U & (~ (IData)(vlSelfRef.UART_Top_tb__DOT__parity_error)))) {
        ++(vlSymsp->__Vcoverage[333]);
    }
    if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__flag2) {
        ++(vlSymsp->__Vcoverage[339]);
    }
    if ((1U & (~ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__flag2)))) {
        ++(vlSymsp->__Vcoverage[340]);
    }
    ++(vlSymsp->__Vcoverage[345]);
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__next_state) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____Vtogcov__next_state))) {
        VL_COV_TOGGLE_CHG_ST_I(3, vlSymsp->__Vcoverage + 292, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__next_state, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____Vtogcov__next_state);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____Vtogcov__next_state 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__next_state;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__shift) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT____Vtogcov__shift))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 249, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__shift, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT____Vtogcov__shift);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT____Vtogcov__shift 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__shift;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__parity_load) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT____Vtogcov__parity_load))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 251, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__parity_load, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT____Vtogcov__parity_load);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT____Vtogcov__parity_load 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__parity_load;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__check_stop) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT____Vtogcov__check_stop))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 253, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__check_stop, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT____Vtogcov__check_stop);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT____Vtogcov__check_stop 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__check_stop;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__temp) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____Vtogcov__temp))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 302, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__temp, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____Vtogcov__temp);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____Vtogcov__temp 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__temp;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__temp1) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____Vtogcov__temp1))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 304, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__temp1, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____Vtogcov__temp1);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____Vtogcov__temp1 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__temp1;
    }
}

void VUART_Top_tb___024root___eval_act(VUART_Top_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VUART_Top_tb___024root___eval_act\n"); );
    VUART_Top_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((8ULL & vlSelfRef.__VactTriggered[0U])) {
        VUART_Top_tb___024root___act_sequent__TOP__0(vlSelf);
    }
    if ((0x0000000000000018ULL & vlSelfRef.__VactTriggered[0U])) {
        if (((IData)(vlSelfRef.UART_Top_tb__DOT__clk) 
             ^ (IData)(vlSelfRef.UART_Top_tb__DOT____Vtogcov__clk))) {
            VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 22, vlSelfRef.UART_Top_tb__DOT__clk, vlSelfRef.UART_Top_tb__DOT____Vtogcov__clk);
            vlSelfRef.UART_Top_tb__DOT____Vtogcov__clk 
                = vlSelfRef.UART_Top_tb__DOT__clk;
        }
    }
    if ((9ULL & vlSelfRef.__VactTriggered[0U])) {
        VUART_Top_tb___024root___act_comb__TOP__1(vlSelf);
    }
}

void VUART_Top_tb___024root___nba_sequent__TOP__0(VUART_Top_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VUART_Top_tb___024root___nba_sequent__TOP__0\n"); );
    VUART_Top_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ __Vdly__UART_Top_tb__DOT__uut__DOT__clock_out;
    __Vdly__UART_Top_tb__DOT__uut__DOT__clock_out = 0;
    SData/*11:0*/ __Vdly__UART_Top_tb__DOT__uut__DOT__r2__DOT__count;
    __Vdly__UART_Top_tb__DOT__uut__DOT__r2__DOT__count = 0;
    // Body
    __Vdly__UART_Top_tb__DOT__uut__DOT__clock_out = vlSelfRef.UART_Top_tb__DOT__uut__DOT__clock_out;
    __Vdly__UART_Top_tb__DOT__uut__DOT__r2__DOT__count 
        = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT__count;
    if (vlSelfRef.UART_Top_tb__DOT__reset) {
        if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT__count) 
             == (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT__temp))) {
            __Vdly__UART_Top_tb__DOT__uut__DOT__clock_out 
                = (1U & (~ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__clock_out)));
            if ((1U & (~ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__clock_out)))) {
                ++(vlSymsp->__Vcoverage[241]);
            }
            __Vdly__UART_Top_tb__DOT__uut__DOT__r2__DOT__count = 0U;
            if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__clock_out) {
                ++(vlSymsp->__Vcoverage[242]);
            }
            ++(vlSymsp->__Vcoverage[243]);
        } else {
            __Vdly__UART_Top_tb__DOT__uut__DOT__r2__DOT__count 
                = (0x00000fffU & ((IData)(1U) + (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT__count)));
            __Vdly__UART_Top_tb__DOT__uut__DOT__clock_out 
                = vlSelfRef.UART_Top_tb__DOT__uut__DOT__clock_out;
            ++(vlSymsp->__Vcoverage[244]);
        }
    } else {
        ++(vlSymsp->__Vcoverage[245]);
        __Vdly__UART_Top_tb__DOT__uut__DOT__clock_out = 0U;
        __Vdly__UART_Top_tb__DOT__uut__DOT__r2__DOT__count = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.UART_Top_tb__DOT__reset)))) {
        ++(vlSymsp->__Vcoverage[246]);
    }
    if (vlSelfRef.UART_Top_tb__DOT__reset) {
        ++(vlSymsp->__Vcoverage[247]);
    }
    ++(vlSymsp->__Vcoverage[248]);
    vlSelfRef.UART_Top_tb__DOT__uut__DOT__clock_out 
        = __Vdly__UART_Top_tb__DOT__uut__DOT__clock_out;
    vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT__count 
        = __Vdly__UART_Top_tb__DOT__uut__DOT__r2__DOT__count;
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__clock_out) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT____Vtogcov__clock_out))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 68, vlSelfRef.UART_Top_tb__DOT__uut__DOT__clock_out, vlSelfRef.UART_Top_tb__DOT__uut__DOT____Vtogcov__clock_out);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT____Vtogcov__clock_out 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__clock_out;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT__count) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT____Vtogcov__count))) {
        VL_COV_TOGGLE_CHG_ST_I(12, vlSymsp->__Vcoverage + 212, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT__count, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT____Vtogcov__count);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT____Vtogcov__count 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT__count;
    }
}

void VUART_Top_tb___024root___nba_sequent__TOP__1(VUART_Top_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VUART_Top_tb___024root___nba_sequent__TOP__1\n"); );
    VUART_Top_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*3:0*/ __Vdly__UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__x1;
    __Vdly__UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__x1 = 0;
    CData/*4:0*/ __Vdly__UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__x2;
    __Vdly__UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__x2 = 0;
    CData/*3:0*/ __Vdly__UART_Top_tb__DOT__uut__DOT__r3__DOT__t1__DOT__count;
    __Vdly__UART_Top_tb__DOT__uut__DOT__r3__DOT__t1__DOT__count = 0;
    CData/*3:0*/ __Vdly__UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__x1;
    __Vdly__UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__x1 = 0;
    CData/*3:0*/ __Vdly__UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__x2;
    __Vdly__UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__x2 = 0;
    CData/*3:0*/ __Vdly__UART_Top_tb__DOT__uut__DOT__r3__DOT__t5__DOT__count;
    __Vdly__UART_Top_tb__DOT__uut__DOT__r3__DOT__t5__DOT__count = 0;
    // Body
    __Vdly__UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__x1 
        = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__x1;
    __Vdly__UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__x2 
        = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__x2;
    __Vdly__UART_Top_tb__DOT__uut__DOT__r3__DOT__t1__DOT__count 
        = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t1__DOT__count;
    __Vdly__UART_Top_tb__DOT__uut__DOT__r3__DOT__t5__DOT__count 
        = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t5__DOT__count;
    __Vdly__UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__x1 
        = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__x1;
    __Vdly__UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__x2 
        = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__x2;
    if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__temp) {
        if ((6U == (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__x1))) {
            ++(vlSymsp->__Vcoverage[351]);
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__flag1 = 1U;
            __Vdly__UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__x1 = 0U;
        } else {
            __Vdly__UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__x1 
                = (0x0000000fU & ((IData)(1U) + (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__x1)));
            ++(vlSymsp->__Vcoverage[352]);
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__flag1 = 0U;
        }
        ++(vlSymsp->__Vcoverage[353]);
    } else {
        __Vdly__UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__x1 = 0U;
        ++(vlSymsp->__Vcoverage[354]);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__flag1 = 0U;
    }
    ++(vlSymsp->__Vcoverage[355]);
    if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__temp1) {
        if ((0x0fU == (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__x2))) {
            ++(vlSymsp->__Vcoverage[356]);
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__flag2 = 1U;
            __Vdly__UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__x2 = 0U;
        } else {
            __Vdly__UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__x2 
                = (0x0000000fU & ((IData)(1U) + (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__x2)));
            ++(vlSymsp->__Vcoverage[357]);
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__flag2 = 0U;
        }
        ++(vlSymsp->__Vcoverage[358]);
    } else {
        __Vdly__UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__x2 = 0U;
        ++(vlSymsp->__Vcoverage[359]);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__flag2 = 0U;
    }
    ++(vlSymsp->__Vcoverage[360]);
    if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__TX_dataout) {
        ++(vlSymsp->__Vcoverage[284]);
        __Vdly__UART_Top_tb__DOT__uut__DOT__r3__DOT__t1__DOT__count = 0U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__de_strtbit = 0U;
    } else {
        if ((0x0cU == (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t1__DOT__count))) {
            ++(vlSymsp->__Vcoverage[281]);
            __Vdly__UART_Top_tb__DOT__uut__DOT__r3__DOT__t1__DOT__count = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__de_strtbit = 1U;
        } else {
            __Vdly__UART_Top_tb__DOT__uut__DOT__r3__DOT__t1__DOT__count 
                = (0x0000000fU & ((IData)(1U) + (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t1__DOT__count)));
            ++(vlSymsp->__Vcoverage[282]);
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__de_strtbit = 0U;
        }
        ++(vlSymsp->__Vcoverage[283]);
    }
    ++(vlSymsp->__Vcoverage[285]);
    if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__check_stop) {
        if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__TX_dataout) {
            if ((0x0fU == (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t5__DOT__count))) {
                ++(vlSymsp->__Vcoverage[378]);
                __Vdly__UART_Top_tb__DOT__uut__DOT__r3__DOT__t5__DOT__count = 0U;
                vlSelfRef.UART_Top_tb__DOT__stop_error = 0U;
                vlSelfRef.UART_Top_tb__DOT__RX_dataout 
                    = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t3__DOT__temp;
            } else {
                __Vdly__UART_Top_tb__DOT__uut__DOT__r3__DOT__t5__DOT__count 
                    = (0x0000000fU & ((IData)(1U) + (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t5__DOT__count)));
                ++(vlSymsp->__Vcoverage[379]);
                vlSelfRef.UART_Top_tb__DOT__stop_error = 0U;
                vlSelfRef.UART_Top_tb__DOT__RX_dataout 
                    = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t3__DOT__temp;
            }
            ++(vlSymsp->__Vcoverage[380]);
        } else {
            ++(vlSymsp->__Vcoverage[381]);
            vlSelfRef.UART_Top_tb__DOT__stop_error = 1U;
            vlSelfRef.UART_Top_tb__DOT__RX_dataout = 0U;
        }
        ++(vlSymsp->__Vcoverage[382]);
    } else {
        ++(vlSymsp->__Vcoverage[383]);
        vlSelfRef.UART_Top_tb__DOT__stop_error = 0U;
        vlSelfRef.UART_Top_tb__DOT__RX_dataout = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t3__DOT__temp;
    }
    ++(vlSymsp->__Vcoverage[384]);
    if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp) {
        if ((8U == (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__x1))) {
            ++(vlSymsp->__Vcoverage[147]);
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__flag2 = 1U;
            __Vdly__UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__x1 = 0U;
        } else {
            __Vdly__UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__x1 
                = (0x0000000fU & ((IData)(1U) + (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__x1)));
            ++(vlSymsp->__Vcoverage[148]);
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__flag2 = 0U;
        }
        ++(vlSymsp->__Vcoverage[149]);
    } else {
        __Vdly__UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__x1 = 0U;
        ++(vlSymsp->__Vcoverage[150]);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__flag2 = 0U;
    }
    ++(vlSymsp->__Vcoverage[151]);
    if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp1) {
        if ((0x0fU == (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__x2))) {
            ++(vlSymsp->__Vcoverage[152]);
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__flag1 = 1U;
            __Vdly__UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__x2 = 0U;
        } else {
            __Vdly__UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__x2 
                = (0x0000001fU & ((IData)(1U) + (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__x2)));
            ++(vlSymsp->__Vcoverage[153]);
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__flag1 = 0U;
        }
        ++(vlSymsp->__Vcoverage[154]);
    } else {
        __Vdly__UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__x2 = 0U;
        ++(vlSymsp->__Vcoverage[155]);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__flag1 = 0U;
    }
    ++(vlSymsp->__Vcoverage[156]);
    vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__x1 
        = __Vdly__UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__x1;
    vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__x2 
        = __Vdly__UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__x2;
    vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t1__DOT__count 
        = __Vdly__UART_Top_tb__DOT__uut__DOT__r3__DOT__t1__DOT__count;
    vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t5__DOT__count 
        = __Vdly__UART_Top_tb__DOT__uut__DOT__r3__DOT__t5__DOT__count;
    vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__x1 
        = __Vdly__UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__x1;
    vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__x2 
        = __Vdly__UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__x2;
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__x1) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____Vtogcov__x1))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 306, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__x1, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____Vtogcov__x1);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____Vtogcov__x1 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__x1;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__flag1) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____Vtogcov__flag1))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 298, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__flag1, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____Vtogcov__flag1);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____Vtogcov__flag1 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__flag1;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__x2) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____Vtogcov__x2))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 314, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__x2, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____Vtogcov__x2);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____Vtogcov__x2 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__x2;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__flag2) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____Vtogcov__flag2))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 300, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__flag2, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____Vtogcov__flag2);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____Vtogcov__flag2 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__flag2;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t1__DOT__count) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t1__DOT____Vtogcov__count))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 273, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t1__DOT__count, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t1__DOT____Vtogcov__count);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t1__DOT____Vtogcov__count 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t1__DOT__count;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__de_strtbit) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT____Vtogcov__de_strtbit))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 255, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__de_strtbit, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT____Vtogcov__de_strtbit);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT____Vtogcov__de_strtbit 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__de_strtbit;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t5__DOT__count) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t5__DOT____Vtogcov__count))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 370, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t5__DOT__count, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t5__DOT____Vtogcov__count);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t5__DOT____Vtogcov__count 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t5__DOT__count;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__stop_error) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT____Vtogcov__stop_error))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 26, vlSelfRef.UART_Top_tb__DOT__stop_error, vlSelfRef.UART_Top_tb__DOT____Vtogcov__stop_error);
        vlSelfRef.UART_Top_tb__DOT____Vtogcov__stop_error 
            = vlSelfRef.UART_Top_tb__DOT__stop_error;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__RX_dataout) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT____Vtogcov__RX_dataout))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 30, vlSelfRef.UART_Top_tb__DOT__RX_dataout, vlSelfRef.UART_Top_tb__DOT____Vtogcov__RX_dataout);
        vlSelfRef.UART_Top_tb__DOT____Vtogcov__RX_dataout 
            = vlSelfRef.UART_Top_tb__DOT__RX_dataout;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__x1) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__x1))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 102, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__x1, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__x1);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__x1 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__x1;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__flag2) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__flag2))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 96, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__flag2, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__flag2);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__flag2 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__flag2;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__x2) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__x2))) {
        VL_COV_TOGGLE_CHG_ST_I(5, vlSymsp->__Vcoverage + 110, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__x2, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__x2);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__x2 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__x2;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__flag1) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__flag1))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 94, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__flag1, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__flag1);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__flag1 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__flag1;
    }
}

void VUART_Top_tb___024root___nba_sequent__TOP__2(VUART_Top_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VUART_Top_tb___024root___nba_sequent__TOP__2\n"); );
    VUART_Top_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*7:0*/ __Vdly__UART_Top_tb__DOT__uut__DOT__r1__DOT__t2__DOT__temp;
    __Vdly__UART_Top_tb__DOT__uut__DOT__r1__DOT__t2__DOT__temp = 0;
    // Body
    __Vdly__UART_Top_tb__DOT__uut__DOT__r1__DOT__t2__DOT__temp 
        = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t2__DOT__temp;
    if (vlSelfRef.UART_Top_tb__DOT__reset) {
        if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__shift) {
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t3__DOT__temp 
                = (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__TX_dataout) 
                    << 7U) | (0x0000007fU & ((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t3__DOT__temp) 
                                             >> 1U)));
            ++(vlSymsp->__Vcoverage[361]);
        } else {
            ++(vlSymsp->__Vcoverage[362]);
        }
    } else {
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t3__DOT__temp = 0U;
        ++(vlSymsp->__Vcoverage[363]);
    }
    ++(vlSymsp->__Vcoverage[364]);
    if (vlSelfRef.UART_Top_tb__DOT__reset) {
        ++(vlSymsp->__Vcoverage[347]);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__state 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__next_state;
    } else {
        ++(vlSymsp->__Vcoverage[346]);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__state = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.UART_Top_tb__DOT__reset)))) {
        ++(vlSymsp->__Vcoverage[348]);
    }
    if (vlSelfRef.UART_Top_tb__DOT__reset) {
        ++(vlSymsp->__Vcoverage[349]);
    }
    ++(vlSymsp->__Vcoverage[350]);
    if (vlSelfRef.UART_Top_tb__DOT__reset) {
        if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__load_data) {
            ++(vlSymsp->__Vcoverage[180]);
            __Vdly__UART_Top_tb__DOT__uut__DOT__r1__DOT__t2__DOT__temp 
                = vlSelfRef.UART_Top_tb__DOT__TX_DATA;
        } else if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__shift) {
            ++(vlSymsp->__Vcoverage[178]);
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__DATA_BIT 
                = (1U & (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t2__DOT__temp));
            __Vdly__UART_Top_tb__DOT__uut__DOT__r1__DOT__t2__DOT__temp 
                = VL_SHIFTR_III(8,8,32, (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t2__DOT__temp), 1U);
        } else {
            ++(vlSymsp->__Vcoverage[179]);
        }
    } else {
        ++(vlSymsp->__Vcoverage[181]);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__DATA_BIT = 0U;
        __Vdly__UART_Top_tb__DOT__uut__DOT__r1__DOT__t2__DOT__temp = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.UART_Top_tb__DOT__reset)))) {
        ++(vlSymsp->__Vcoverage[182]);
    }
    if (vlSelfRef.UART_Top_tb__DOT__reset) {
        ++(vlSymsp->__Vcoverage[183]);
    }
    ++(vlSymsp->__Vcoverage[184]);
    if (vlSelfRef.UART_Top_tb__DOT__reset) {
        ++(vlSymsp->__Vcoverage[158]);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__state 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__next_state;
    } else {
        ++(vlSymsp->__Vcoverage[157]);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__state = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.UART_Top_tb__DOT__reset)))) {
        ++(vlSymsp->__Vcoverage[159]);
    }
    if (vlSelfRef.UART_Top_tb__DOT__reset) {
        ++(vlSymsp->__Vcoverage[160]);
    }
    ++(vlSymsp->__Vcoverage[161]);
    vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t2__DOT__temp 
        = __Vdly__UART_Top_tb__DOT__uut__DOT__r1__DOT__t2__DOT__temp;
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t3__DOT__temp) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT____Vtogcov__RX_DATA))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 257, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t3__DOT__temp, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT____Vtogcov__RX_DATA);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT____Vtogcov__RX_DATA 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t3__DOT__temp;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__state) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____Vtogcov__state))) {
        VL_COV_TOGGLE_CHG_ST_I(3, vlSymsp->__Vcoverage + 286, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__state, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____Vtogcov__state);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____Vtogcov__state 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__state;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t2__DOT__temp) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t2__DOT____Vtogcov__temp))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 162, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t2__DOT__temp, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t2__DOT____Vtogcov__temp);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t2__DOT____Vtogcov__temp 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t2__DOT__temp;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__DATA_BIT) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__DATA_BIT))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 78, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__DATA_BIT, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__DATA_BIT);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__DATA_BIT 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__DATA_BIT;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__state) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__state))) {
        VL_COV_TOGGLE_CHG_ST_I(3, vlSymsp->__Vcoverage + 82, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__state, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__state);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__state 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__state;
    }
}

void VUART_Top_tb___024root___nba_sequent__TOP__3(VUART_Top_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VUART_Top_tb___024root___nba_sequent__TOP__3\n"); );
    VUART_Top_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__sel) ^ (IData)(vlSelfRef.UART_Top_tb__DOT____Vtogcov__sel))) {
        VL_COV_TOGGLE_CHG_ST_I(2, vlSymsp->__Vcoverage + 0, vlSelfRef.UART_Top_tb__DOT__sel, vlSelfRef.UART_Top_tb__DOT____Vtogcov__sel);
        vlSelfRef.UART_Top_tb__DOT____Vtogcov__sel 
            = vlSelfRef.UART_Top_tb__DOT__sel;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__TX_start) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT____Vtogcov__TX_start))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 4, vlSelfRef.UART_Top_tb__DOT__TX_start, vlSelfRef.UART_Top_tb__DOT____Vtogcov__TX_start);
        vlSelfRef.UART_Top_tb__DOT____Vtogcov__TX_start 
            = vlSelfRef.UART_Top_tb__DOT__TX_start;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__TX_DATA) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT____Vtogcov__TX_DATA))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 6, vlSelfRef.UART_Top_tb__DOT__TX_DATA, vlSelfRef.UART_Top_tb__DOT____Vtogcov__TX_DATA);
        vlSelfRef.UART_Top_tb__DOT____Vtogcov__TX_DATA 
            = vlSelfRef.UART_Top_tb__DOT__TX_DATA;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__reset) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT____Vtogcov__reset))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 24, vlSelfRef.UART_Top_tb__DOT__reset, vlSelfRef.UART_Top_tb__DOT____Vtogcov__reset);
        vlSelfRef.UART_Top_tb__DOT____Vtogcov__reset 
            = vlSelfRef.UART_Top_tb__DOT__reset;
    }
    if ((2U & (IData)(vlSelfRef.UART_Top_tb__DOT__sel))) {
        if ((1U & (IData)(vlSelfRef.UART_Top_tb__DOT__sel))) {
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT__temp = 0x0145U;
            ++(vlSymsp->__Vcoverage[239]);
        } else {
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT__temp = 0x00a2U;
            ++(vlSymsp->__Vcoverage[238]);
        }
    } else if ((1U & (IData)(vlSelfRef.UART_Top_tb__DOT__sel))) {
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT__temp = 0x0145U;
        ++(vlSymsp->__Vcoverage[237]);
    } else {
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT__temp = 0x0517U;
        ++(vlSymsp->__Vcoverage[236]);
    }
    ++(vlSymsp->__Vcoverage[240]);
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT__temp) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT____Vtogcov__temp))) {
        VL_COV_TOGGLE_CHG_ST_I(12, vlSymsp->__Vcoverage + 188, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT__temp, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT____Vtogcov__temp);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT____Vtogcov__temp 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT__temp;
    }
}

void VUART_Top_tb___024root___nba_comb__TOP__1(VUART_Top_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VUART_Top_tb___024root___nba_comb__TOP__1\n"); );
    VUART_Top_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((4U & (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__state))) {
        if ((2U & (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__state))) {
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__next_state = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__load_data = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__shift = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s0 = 1U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s1 = 1U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp1 = 0U;
            ++(vlSymsp->__Vcoverage[145]);
        } else if ((1U & (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__state))) {
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__next_state = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__load_data = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__shift = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s0 = 1U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s1 = 1U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp1 = 0U;
            ++(vlSymsp->__Vcoverage[145]);
        } else {
            if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__flag1) {
                ++(vlSymsp->__Vcoverage[142]);
                vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____VlemCond_4 = 0U;
            } else {
                ++(vlSymsp->__Vcoverage[143]);
                vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____VlemCond_4 = 4U;
            }
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__load_data = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__shift = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s0 = 1U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s1 = 1U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp1 = 1U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__next_state 
                = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____VlemCond_4;
            ++(vlSymsp->__Vcoverage[144]);
        }
    } else if ((2U & (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__state))) {
        if ((1U & (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__state))) {
            if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__flag1) {
                ++(vlSymsp->__Vcoverage[137]);
                vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____VlemCond_3 = 4U;
            } else {
                ++(vlSymsp->__Vcoverage[138]);
                vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____VlemCond_3 = 3U;
            }
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__load_data = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__shift = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s0 = 1U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s1 = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp1 = 1U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__next_state 
                = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____VlemCond_3;
            ++(vlSymsp->__Vcoverage[139]);
        } else {
            if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__flag2) {
                ++(vlSymsp->__Vcoverage[132]);
                vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____VlemCond_2 = 3U;
            } else {
                ++(vlSymsp->__Vcoverage[133]);
                vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____VlemCond_2 = 2U;
            }
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__load_data = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__shift = 1U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s0 = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s1 = 1U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp = 1U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp1 = 0U;
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__next_state 
                = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____VlemCond_2;
            ++(vlSymsp->__Vcoverage[134]);
        }
    } else if ((1U & (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__state))) {
        if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__flag1) {
            ++(vlSymsp->__Vcoverage[127]);
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____VlemCond_1 = 2U;
        } else {
            ++(vlSymsp->__Vcoverage[128]);
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____VlemCond_1 = 1U;
        }
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__load_data = 1U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__shift = 0U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s0 = 0U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s1 = 0U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp = 0U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp1 = 1U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__next_state 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____VlemCond_1;
        ++(vlSymsp->__Vcoverage[129]);
    } else {
        if (vlSelfRef.UART_Top_tb__DOT__TX_start) {
            ++(vlSymsp->__Vcoverage[122]);
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____VlemCond_0 = 1U;
        } else {
            ++(vlSymsp->__Vcoverage[123]);
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____VlemCond_0 = 0U;
        }
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__load_data = 0U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__shift = 0U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s0 = 1U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s1 = 1U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp = 0U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp1 = 0U;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__next_state 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____VlemCond_0;
        ++(vlSymsp->__Vcoverage[124]);
    }
    if (vlSelfRef.UART_Top_tb__DOT__TX_start) {
        ++(vlSymsp->__Vcoverage[120]);
    }
    if ((1U & (~ (IData)(vlSelfRef.UART_Top_tb__DOT__TX_start)))) {
        ++(vlSymsp->__Vcoverage[121]);
    }
    if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__flag1) {
        ++(vlSymsp->__Vcoverage[125]);
    }
    if ((1U & (~ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__flag1)))) {
        ++(vlSymsp->__Vcoverage[126]);
    }
    if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__flag2) {
        ++(vlSymsp->__Vcoverage[130]);
    }
    if ((1U & (~ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__flag2)))) {
        ++(vlSymsp->__Vcoverage[131]);
    }
    if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__flag1) {
        ++(vlSymsp->__Vcoverage[135]);
    }
    if ((1U & (~ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__flag1)))) {
        ++(vlSymsp->__Vcoverage[136]);
    }
    if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__flag1) {
        ++(vlSymsp->__Vcoverage[140]);
    }
    if ((1U & (~ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__flag1)))) {
        ++(vlSymsp->__Vcoverage[141]);
    }
    ++(vlSymsp->__Vcoverage[146]);
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__next_state) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__next_state))) {
        VL_COV_TOGGLE_CHG_ST_I(3, vlSymsp->__Vcoverage + 88, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__next_state, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__next_state);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__next_state 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__next_state;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__shift) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__shift))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 74, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__shift, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__shift);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__shift 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__shift;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__temp))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 98, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__temp);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__temp 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp1) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__temp1))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 100, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp1, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__temp1);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__temp1 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__temp1;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s0) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__s0))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 70, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s0, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__s0);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__s0 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s0;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s1) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__s1))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 72, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s1, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__s1);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__s1 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s1;
    }
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__load_data) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__load_data))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 76, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__load_data, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__load_data);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__load_data 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__load_data;
    }
    if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__load_data) {
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__PARITY_BIT 
            = (1U & VL_REDXOR_8(vlSelfRef.UART_Top_tb__DOT__TX_DATA));
        ++(vlSymsp->__Vcoverage[185]);
    } else {
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__PARITY_BIT = 0U;
        ++(vlSymsp->__Vcoverage[186]);
    }
    ++(vlSymsp->__Vcoverage[187]);
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__PARITY_BIT) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__PARITY_BIT))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 80, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__PARITY_BIT, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__PARITY_BIT);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__PARITY_BIT 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__PARITY_BIT;
    }
    vlSelfRef.UART_Top_tb__DOT__uut__DOT__TX_dataout 
        = (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s0) 
            & ((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s1) 
               | (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__PARITY_BIT))) 
           | ((~ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s0)) 
              & ((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__s1) 
                 & (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__DATA_BIT))));
    if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__TX_dataout) 
         ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT____Vtogcov__TX_dataout))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 66, vlSelfRef.UART_Top_tb__DOT__uut__DOT__TX_dataout, vlSelfRef.UART_Top_tb__DOT__uut__DOT____Vtogcov__TX_dataout);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT____Vtogcov__TX_dataout 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__TX_dataout;
    }
}

void VUART_Top_tb___024root___eval_nba(VUART_Top_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VUART_Top_tb___024root___eval_nba\n"); );
    VUART_Top_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ __Vinline__nba_sequent__TOP__0___Vdly__UART_Top_tb__DOT__uut__DOT__clock_out;
    __Vinline__nba_sequent__TOP__0___Vdly__UART_Top_tb__DOT__uut__DOT__clock_out = 0;
    SData/*11:0*/ __Vinline__nba_sequent__TOP__0___Vdly__UART_Top_tb__DOT__uut__DOT__r2__DOT__count;
    __Vinline__nba_sequent__TOP__0___Vdly__UART_Top_tb__DOT__uut__DOT__r2__DOT__count = 0;
    CData/*7:0*/ __Vinline__nba_sequent__TOP__2___Vdly__UART_Top_tb__DOT__uut__DOT__r1__DOT__t2__DOT__temp;
    __Vinline__nba_sequent__TOP__2___Vdly__UART_Top_tb__DOT__uut__DOT__r1__DOT__t2__DOT__temp = 0;
    // Body
    if ((0x000000000000000cULL & vlSelfRef.__VnbaTriggered[0U])) {
        __Vinline__nba_sequent__TOP__0___Vdly__UART_Top_tb__DOT__uut__DOT__clock_out 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__clock_out;
        __Vinline__nba_sequent__TOP__0___Vdly__UART_Top_tb__DOT__uut__DOT__r2__DOT__count 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT__count;
        if (vlSelfRef.UART_Top_tb__DOT__reset) {
            if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT__count) 
                 == (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT__temp))) {
                __Vinline__nba_sequent__TOP__0___Vdly__UART_Top_tb__DOT__uut__DOT__clock_out 
                    = (1U & (~ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__clock_out)));
                if ((1U & (~ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__clock_out)))) {
                    ++(vlSymsp->__Vcoverage[241]);
                }
                __Vinline__nba_sequent__TOP__0___Vdly__UART_Top_tb__DOT__uut__DOT__r2__DOT__count = 0U;
                if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__clock_out) {
                    ++(vlSymsp->__Vcoverage[242]);
                }
                ++(vlSymsp->__Vcoverage[243]);
            } else {
                __Vinline__nba_sequent__TOP__0___Vdly__UART_Top_tb__DOT__uut__DOT__r2__DOT__count 
                    = (0x00000fffU & ((IData)(1U) + (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT__count)));
                __Vinline__nba_sequent__TOP__0___Vdly__UART_Top_tb__DOT__uut__DOT__clock_out 
                    = vlSelfRef.UART_Top_tb__DOT__uut__DOT__clock_out;
                ++(vlSymsp->__Vcoverage[244]);
            }
        } else {
            ++(vlSymsp->__Vcoverage[245]);
            __Vinline__nba_sequent__TOP__0___Vdly__UART_Top_tb__DOT__uut__DOT__clock_out = 0U;
            __Vinline__nba_sequent__TOP__0___Vdly__UART_Top_tb__DOT__uut__DOT__r2__DOT__count = 0U;
        }
        if ((1U & (~ (IData)(vlSelfRef.UART_Top_tb__DOT__reset)))) {
            ++(vlSymsp->__Vcoverage[246]);
        }
        if (vlSelfRef.UART_Top_tb__DOT__reset) {
            ++(vlSymsp->__Vcoverage[247]);
        }
        ++(vlSymsp->__Vcoverage[248]);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__clock_out 
            = __Vinline__nba_sequent__TOP__0___Vdly__UART_Top_tb__DOT__uut__DOT__clock_out;
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT__count 
            = __Vinline__nba_sequent__TOP__0___Vdly__UART_Top_tb__DOT__uut__DOT__r2__DOT__count;
        if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__clock_out) 
             ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT____Vtogcov__clock_out))) {
            VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 68, vlSelfRef.UART_Top_tb__DOT__uut__DOT__clock_out, vlSelfRef.UART_Top_tb__DOT__uut__DOT____Vtogcov__clock_out);
            vlSelfRef.UART_Top_tb__DOT__uut__DOT____Vtogcov__clock_out 
                = vlSelfRef.UART_Top_tb__DOT__uut__DOT__clock_out;
        }
        if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT__count) 
             ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT____Vtogcov__count))) {
            VL_COV_TOGGLE_CHG_ST_I(12, vlSymsp->__Vcoverage + 212, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT__count, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT____Vtogcov__count);
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT____Vtogcov__count 
                = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT__count;
        }
    }
    if ((2ULL & vlSelfRef.__VnbaTriggered[0U])) {
        VUART_Top_tb___024root___nba_sequent__TOP__1(vlSelf);
    }
    if ((6ULL & vlSelfRef.__VnbaTriggered[0U])) {
        __Vinline__nba_sequent__TOP__2___Vdly__UART_Top_tb__DOT__uut__DOT__r1__DOT__t2__DOT__temp 
            = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t2__DOT__temp;
        if (vlSelfRef.UART_Top_tb__DOT__reset) {
            if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__shift) {
                vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t3__DOT__temp 
                    = (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__TX_dataout) 
                        << 7U) | (0x0000007fU & ((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t3__DOT__temp) 
                                                 >> 1U)));
                ++(vlSymsp->__Vcoverage[361]);
            } else {
                ++(vlSymsp->__Vcoverage[362]);
            }
        } else {
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t3__DOT__temp = 0U;
            ++(vlSymsp->__Vcoverage[363]);
        }
        ++(vlSymsp->__Vcoverage[364]);
        if (vlSelfRef.UART_Top_tb__DOT__reset) {
            ++(vlSymsp->__Vcoverage[347]);
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__state 
                = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__next_state;
        } else {
            ++(vlSymsp->__Vcoverage[346]);
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__state = 0U;
        }
        if ((1U & (~ (IData)(vlSelfRef.UART_Top_tb__DOT__reset)))) {
            ++(vlSymsp->__Vcoverage[348]);
        }
        if (vlSelfRef.UART_Top_tb__DOT__reset) {
            ++(vlSymsp->__Vcoverage[349]);
        }
        ++(vlSymsp->__Vcoverage[350]);
        if (vlSelfRef.UART_Top_tb__DOT__reset) {
            if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__load_data) {
                ++(vlSymsp->__Vcoverage[180]);
                __Vinline__nba_sequent__TOP__2___Vdly__UART_Top_tb__DOT__uut__DOT__r1__DOT__t2__DOT__temp 
                    = vlSelfRef.UART_Top_tb__DOT__TX_DATA;
            } else if (vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__shift) {
                ++(vlSymsp->__Vcoverage[178]);
                vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__DATA_BIT 
                    = (1U & (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t2__DOT__temp));
                __Vinline__nba_sequent__TOP__2___Vdly__UART_Top_tb__DOT__uut__DOT__r1__DOT__t2__DOT__temp 
                    = VL_SHIFTR_III(8,8,32, (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t2__DOT__temp), 1U);
            } else {
                ++(vlSymsp->__Vcoverage[179]);
            }
        } else {
            ++(vlSymsp->__Vcoverage[181]);
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__DATA_BIT = 0U;
            __Vinline__nba_sequent__TOP__2___Vdly__UART_Top_tb__DOT__uut__DOT__r1__DOT__t2__DOT__temp = 0U;
        }
        if ((1U & (~ (IData)(vlSelfRef.UART_Top_tb__DOT__reset)))) {
            ++(vlSymsp->__Vcoverage[182]);
        }
        if (vlSelfRef.UART_Top_tb__DOT__reset) {
            ++(vlSymsp->__Vcoverage[183]);
        }
        ++(vlSymsp->__Vcoverage[184]);
        if (vlSelfRef.UART_Top_tb__DOT__reset) {
            ++(vlSymsp->__Vcoverage[158]);
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__state 
                = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__next_state;
        } else {
            ++(vlSymsp->__Vcoverage[157]);
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__state = 0U;
        }
        if ((1U & (~ (IData)(vlSelfRef.UART_Top_tb__DOT__reset)))) {
            ++(vlSymsp->__Vcoverage[159]);
        }
        if (vlSelfRef.UART_Top_tb__DOT__reset) {
            ++(vlSymsp->__Vcoverage[160]);
        }
        ++(vlSymsp->__Vcoverage[161]);
        vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t2__DOT__temp 
            = __Vinline__nba_sequent__TOP__2___Vdly__UART_Top_tb__DOT__uut__DOT__r1__DOT__t2__DOT__temp;
        if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t3__DOT__temp) 
             ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT____Vtogcov__RX_DATA))) {
            VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 257, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t3__DOT__temp, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT____Vtogcov__RX_DATA);
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT____Vtogcov__RX_DATA 
                = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t3__DOT__temp;
        }
        if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__state) 
             ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____Vtogcov__state))) {
            VL_COV_TOGGLE_CHG_ST_I(3, vlSymsp->__Vcoverage + 286, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__state, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____Vtogcov__state);
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT____Vtogcov__state 
                = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r3__DOT__t2__DOT__state;
        }
        if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t2__DOT__temp) 
             ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t2__DOT____Vtogcov__temp))) {
            VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 162, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t2__DOT__temp, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t2__DOT____Vtogcov__temp);
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t2__DOT____Vtogcov__temp 
                = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t2__DOT__temp;
        }
        if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__DATA_BIT) 
             ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__DATA_BIT))) {
            VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 78, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__DATA_BIT, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__DATA_BIT);
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT____Vtogcov__DATA_BIT 
                = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__DATA_BIT;
        }
        if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__state) 
             ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__state))) {
            VL_COV_TOGGLE_CHG_ST_I(3, vlSymsp->__Vcoverage + 82, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__state, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__state);
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT____Vtogcov__state 
                = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r1__DOT__t1__DOT__state;
        }
    }
    if ((8ULL & vlSelfRef.__VnbaTriggered[0U])) {
        if (((IData)(vlSelfRef.UART_Top_tb__DOT__sel) 
             ^ (IData)(vlSelfRef.UART_Top_tb__DOT____Vtogcov__sel))) {
            VL_COV_TOGGLE_CHG_ST_I(2, vlSymsp->__Vcoverage + 0, vlSelfRef.UART_Top_tb__DOT__sel, vlSelfRef.UART_Top_tb__DOT____Vtogcov__sel);
            vlSelfRef.UART_Top_tb__DOT____Vtogcov__sel 
                = vlSelfRef.UART_Top_tb__DOT__sel;
        }
        if (((IData)(vlSelfRef.UART_Top_tb__DOT__TX_start) 
             ^ (IData)(vlSelfRef.UART_Top_tb__DOT____Vtogcov__TX_start))) {
            VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 4, vlSelfRef.UART_Top_tb__DOT__TX_start, vlSelfRef.UART_Top_tb__DOT____Vtogcov__TX_start);
            vlSelfRef.UART_Top_tb__DOT____Vtogcov__TX_start 
                = vlSelfRef.UART_Top_tb__DOT__TX_start;
        }
        if (((IData)(vlSelfRef.UART_Top_tb__DOT__TX_DATA) 
             ^ (IData)(vlSelfRef.UART_Top_tb__DOT____Vtogcov__TX_DATA))) {
            VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 6, vlSelfRef.UART_Top_tb__DOT__TX_DATA, vlSelfRef.UART_Top_tb__DOT____Vtogcov__TX_DATA);
            vlSelfRef.UART_Top_tb__DOT____Vtogcov__TX_DATA 
                = vlSelfRef.UART_Top_tb__DOT__TX_DATA;
        }
        if (((IData)(vlSelfRef.UART_Top_tb__DOT__reset) 
             ^ (IData)(vlSelfRef.UART_Top_tb__DOT____Vtogcov__reset))) {
            VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 24, vlSelfRef.UART_Top_tb__DOT__reset, vlSelfRef.UART_Top_tb__DOT____Vtogcov__reset);
            vlSelfRef.UART_Top_tb__DOT____Vtogcov__reset 
                = vlSelfRef.UART_Top_tb__DOT__reset;
        }
        if ((2U & (IData)(vlSelfRef.UART_Top_tb__DOT__sel))) {
            if ((1U & (IData)(vlSelfRef.UART_Top_tb__DOT__sel))) {
                vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT__temp = 0x0145U;
                ++(vlSymsp->__Vcoverage[239]);
            } else {
                vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT__temp = 0x00a2U;
                ++(vlSymsp->__Vcoverage[238]);
            }
        } else if ((1U & (IData)(vlSelfRef.UART_Top_tb__DOT__sel))) {
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT__temp = 0x0145U;
            ++(vlSymsp->__Vcoverage[237]);
        } else {
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT__temp = 0x0517U;
            ++(vlSymsp->__Vcoverage[236]);
        }
        ++(vlSymsp->__Vcoverage[240]);
        if (((IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT__temp) 
             ^ (IData)(vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT____Vtogcov__temp))) {
            VL_COV_TOGGLE_CHG_ST_I(12, vlSymsp->__Vcoverage + 188, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT__temp, vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT____Vtogcov__temp);
            vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT____Vtogcov__temp 
                = vlSelfRef.UART_Top_tb__DOT__uut__DOT__r2__DOT__temp;
        }
    }
    if ((0x0000000000000018ULL & vlSelfRef.__VnbaTriggered[0U])) {
        if (((IData)(vlSelfRef.UART_Top_tb__DOT__clk) 
             ^ (IData)(vlSelfRef.UART_Top_tb__DOT____Vtogcov__clk))) {
            VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 22, vlSelfRef.UART_Top_tb__DOT__clk, vlSelfRef.UART_Top_tb__DOT____Vtogcov__clk);
            vlSelfRef.UART_Top_tb__DOT____Vtogcov__clk 
                = vlSelfRef.UART_Top_tb__DOT__clk;
        }
    }
    if ((0x000000000000000eULL & vlSelfRef.__VnbaTriggered[0U])) {
        VUART_Top_tb___024root___nba_comb__TOP__1(vlSelf);
    }
    if ((0x000000000000000fULL & vlSelfRef.__VnbaTriggered[0U])) {
        VUART_Top_tb___024root___act_comb__TOP__1(vlSelf);
    }
}

void VUART_Top_tb___024root___timing_ready(VUART_Top_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VUART_Top_tb___024root___timing_ready\n"); );
    VUART_Top_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((8ULL & vlSelfRef.__VactTriggered[0U])) {
        vlSelfRef.__VtrigSched_h62ac6386__0.ready("@(posedge UART_Top_tb.clk)");
    }
}

void VUART_Top_tb___024root___timing_resume(VUART_Top_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VUART_Top_tb___024root___timing_resume\n"); );
    VUART_Top_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__VtrigSched_h62ac6386__0.moveToResumeQueue(
                                                          "@(posedge UART_Top_tb.clk)");
    vlSelfRef.__VtrigSched_h62ac6386__0.resume("@(posedge UART_Top_tb.clk)");
    if ((0x0000000000000010ULL & vlSelfRef.__VactTriggered[0U])) {
        vlSelfRef.__VdlySched.resume();
    }
}

void VUART_Top_tb___024root___trigger_orInto__act_vec_vec(VlUnpacked<QData/*63:0*/, 1> &out, const VlUnpacked<QData/*63:0*/, 1> &in) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VUART_Top_tb___024root___trigger_orInto__act_vec_vec\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        out[n] = (out[n] | in[n]);
        n = ((IData)(1U) + n);
    } while ((0U >= n));
}

#ifdef VL_DEBUG
VL_ATTR_COLD void VUART_Top_tb___024root___dump_triggers__act(const VlUnpacked<QData/*63:0*/, 1> &triggers, const std::string &tag);
#endif  // VL_DEBUG

bool VUART_Top_tb___024root___eval_phase__act(VUART_Top_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VUART_Top_tb___024root___eval_phase__act\n"); );
    VUART_Top_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ __VactExecute;
    // Body
    VUART_Top_tb___024root___eval_triggers_vec__act(vlSelf);
    VUART_Top_tb___024root___timing_ready(vlSelf);
    VUART_Top_tb___024root___trigger_orInto__act_vec_vec(vlSelfRef.__VactTriggered, vlSelfRef.__VactTriggeredAcc);
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        VUART_Top_tb___024root___dump_triggers__act(vlSelfRef.__VactTriggered, "act"s);
    }
#endif
    VUART_Top_tb___024root___trigger_orInto__act_vec_vec(vlSelfRef.__VnbaTriggered, vlSelfRef.__VactTriggered);
    __VactExecute = VUART_Top_tb___024root___trigger_anySet__act(vlSelfRef.__VactTriggered);
    if (__VactExecute) {
        vlSelfRef.__VactTriggeredAcc.fill(0ULL);
        VUART_Top_tb___024root___timing_resume(vlSelf);
        VUART_Top_tb___024root___eval_act(vlSelf);
    }
    return (__VactExecute);
}

bool VUART_Top_tb___024root___eval_phase__inact(VUART_Top_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VUART_Top_tb___024root___eval_phase__inact\n"); );
    VUART_Top_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ __VinactExecute;
    // Body
    __VinactExecute = vlSelfRef.__VdlySched.awaitingZeroDelay();
    if (__VinactExecute) {
        VL_FATAL_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/uart-controller-v0.1/T-UART-001/20260523-095157/inputs/design/rtl/UART_Top_tb.v", 25, "", "ZERODLY: Design Verilated with '--no-sched-zero-delay', but #0 delay executed at runtime");
    }
    return (__VinactExecute);
}

void VUART_Top_tb___024root___trigger_clear__act(VlUnpacked<QData/*63:0*/, 1> &out) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VUART_Top_tb___024root___trigger_clear__act\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        out[n] = 0ULL;
        n = ((IData)(1U) + n);
    } while ((1U > n));
}

bool VUART_Top_tb___024root___eval_phase__nba(VUART_Top_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VUART_Top_tb___024root___eval_phase__nba\n"); );
    VUART_Top_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ __VnbaExecute;
    // Body
    __VnbaExecute = VUART_Top_tb___024root___trigger_anySet__act(vlSelfRef.__VnbaTriggered);
    if (__VnbaExecute) {
        VUART_Top_tb___024root___eval_nba(vlSelf);
        VUART_Top_tb___024root___trigger_clear__act(vlSelfRef.__VnbaTriggered);
    }
    return (__VnbaExecute);
}

void VUART_Top_tb___024root___eval(VUART_Top_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VUART_Top_tb___024root___eval\n"); );
    VUART_Top_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    IData/*31:0*/ __VnbaIterCount;
    // Body
    __VnbaIterCount = 0U;
    do {
        if (VL_UNLIKELY(((0x00002710U < __VnbaIterCount)))) {
#ifdef VL_DEBUG
            VUART_Top_tb___024root___dump_triggers__act(vlSelfRef.__VnbaTriggered, "nba"s);
#endif
            VL_FATAL_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/uart-controller-v0.1/T-UART-001/20260523-095157/inputs/design/rtl/UART_Top_tb.v", 25, "", "DIDNOTCONVERGE: NBA region did not converge after '--converge-limit' of 10000 tries");
        }
        __VnbaIterCount = ((IData)(1U) + __VnbaIterCount);
        vlSelfRef.__VinactIterCount = 0U;
        do {
            if (VL_UNLIKELY(((0x00002710U < vlSelfRef.__VinactIterCount)))) {
                VL_FATAL_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/uart-controller-v0.1/T-UART-001/20260523-095157/inputs/design/rtl/UART_Top_tb.v", 25, "", "DIDNOTCONVERGE: Inactive region did not converge after '--converge-limit' of 10000 tries");
            }
            vlSelfRef.__VinactIterCount = ((IData)(1U) 
                                           + vlSelfRef.__VinactIterCount);
            vlSelfRef.__VactIterCount = 0U;
            do {
                if (VL_UNLIKELY(((0x00002710U < vlSelfRef.__VactIterCount)))) {
#ifdef VL_DEBUG
                    VUART_Top_tb___024root___dump_triggers__act(vlSelfRef.__VactTriggered, "act"s);
#endif
                    VL_FATAL_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/uart-controller-v0.1/T-UART-001/20260523-095157/inputs/design/rtl/UART_Top_tb.v", 25, "", "DIDNOTCONVERGE: Active region did not converge after '--converge-limit' of 10000 tries");
                }
                vlSelfRef.__VactIterCount = ((IData)(1U) 
                                             + vlSelfRef.__VactIterCount);
                vlSelfRef.__VactPhaseResult = VUART_Top_tb___024root___eval_phase__act(vlSelf);
            } while (vlSelfRef.__VactPhaseResult);
            vlSelfRef.__VinactPhaseResult = VUART_Top_tb___024root___eval_phase__inact(vlSelf);
        } while (vlSelfRef.__VinactPhaseResult);
        vlSelfRef.__VnbaPhaseResult = VUART_Top_tb___024root___eval_phase__nba(vlSelf);
    } while (vlSelfRef.__VnbaPhaseResult);
}

void VUART_Top_tb___024root____VbeforeTrig_h62ac6386__0(VUART_Top_tb___024root* vlSelf, const char* __VeventDescription) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VUART_Top_tb___024root____VbeforeTrig_h62ac6386__0\n"); );
    VUART_Top_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    VlUnpacked<QData/*63:0*/, 1> __VTmp;
    // Body
    __VTmp[0U] = (QData)((IData)((((IData)(vlSelfRef.UART_Top_tb__DOT__clk) 
                                   & (~ (IData)(vlSelfRef.__Vtrigprevexpr___TOP__UART_Top_tb__DOT__clk__0))) 
                                  << 3U)));
    vlSelfRef.__Vtrigprevexpr___TOP__UART_Top_tb__DOT__clk__0 
        = vlSelfRef.UART_Top_tb__DOT__clk;
    if ((8ULL & __VTmp[0U])) {
        vlSelfRef.__VtrigSched_h62ac6386__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_h62ac6386__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_h62ac6386__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_h62ac6386__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_h62ac6386__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_h62ac6386__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_h62ac6386__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_h62ac6386__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_h62ac6386__0.ready(__VeventDescription);
    }
    vlSelfRef.__VactTriggeredAcc[0U] = (vlSelfRef.__VactTriggeredAcc[0U] 
                                        | __VTmp[0U]);
}

#ifdef VL_DEBUG
void VUART_Top_tb___024root___eval_debug_assertions(VUART_Top_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VUART_Top_tb___024root___eval_debug_assertions\n"); );
    VUART_Top_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}
#endif  // VL_DEBUG
