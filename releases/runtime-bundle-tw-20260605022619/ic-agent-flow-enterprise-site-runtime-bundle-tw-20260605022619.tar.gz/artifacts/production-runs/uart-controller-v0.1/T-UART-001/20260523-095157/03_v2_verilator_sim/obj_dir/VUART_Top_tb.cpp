// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Model implementation (design independent parts)

#include "VUART_Top_tb__pch.h"

//============================================================
// Constructors

VUART_Top_tb::VUART_Top_tb(VerilatedContext* _vcontextp__, const char* _vcname__)
    : VerilatedModel{*_vcontextp__}
    , vlSymsp{new VUART_Top_tb__Syms(contextp(), _vcname__, this)}
    , rootp{&(vlSymsp->TOP)}
{
    // Register model with the context
    contextp()->addModel(this);
}

VUART_Top_tb::VUART_Top_tb(const char* _vcname__)
    : VUART_Top_tb(Verilated::threadContextp(), _vcname__)
{
}

//============================================================
// Destructor

VUART_Top_tb::~VUART_Top_tb() {
    delete vlSymsp;
}

//============================================================
// Evaluation function

#ifdef VL_DEBUG
void VUART_Top_tb___024root___eval_debug_assertions(VUART_Top_tb___024root* vlSelf);
#endif  // VL_DEBUG
void VUART_Top_tb___024root___eval_static(VUART_Top_tb___024root* vlSelf);
void VUART_Top_tb___024root___eval_initial(VUART_Top_tb___024root* vlSelf);
void VUART_Top_tb___024root___eval_settle(VUART_Top_tb___024root* vlSelf);
void VUART_Top_tb___024root___eval(VUART_Top_tb___024root* vlSelf);

void VUART_Top_tb::eval_step() {
    VL_DEBUG_IF(VL_DBG_MSGF("+++++TOP Evaluate VUART_Top_tb::eval_step\n"); );
#ifdef VL_DEBUG
    // Debug assertions
    VUART_Top_tb___024root___eval_debug_assertions(&(vlSymsp->TOP));
#endif  // VL_DEBUG
    vlSymsp->__Vm_deleter.deleteAll();
    if (VL_UNLIKELY(!vlSymsp->__Vm_didInit)) {
        VL_DEBUG_IF(VL_DBG_MSGF("+ Initial\n"););
        VUART_Top_tb___024root___eval_static(&(vlSymsp->TOP));
        VUART_Top_tb___024root___eval_initial(&(vlSymsp->TOP));
        VUART_Top_tb___024root___eval_settle(&(vlSymsp->TOP));
        vlSymsp->__Vm_didInit = true;
    }
    VL_DEBUG_IF(VL_DBG_MSGF("+ Eval\n"););
    VUART_Top_tb___024root___eval(&(vlSymsp->TOP));
    // Evaluate cleanup
    Verilated::endOfEval(vlSymsp->__Vm_evalMsgQp);
}

//============================================================
// Events and timing
bool VUART_Top_tb::eventsPending() { return !vlSymsp->TOP.__VdlySched.empty() && !contextp()->gotFinish(); }

uint64_t VUART_Top_tb::nextTimeSlot() { return vlSymsp->TOP.__VdlySched.nextTimeSlot(); }

//============================================================
// Utilities

const char* VUART_Top_tb::name() const {
    return vlSymsp->name();
}

//============================================================
// Invoke final blocks

void VUART_Top_tb___024root___eval_final(VUART_Top_tb___024root* vlSelf);

VL_ATTR_COLD void VUART_Top_tb::final() {
    contextp()->executingFinal(true);
    VUART_Top_tb___024root___eval_final(&(vlSymsp->TOP));
    contextp()->executingFinal(false);
}

//============================================================
// Implementations of abstract methods from VerilatedModel

const char* VUART_Top_tb::hierName() const { return vlSymsp->name(); }
const char* VUART_Top_tb::modelName() const { return "VUART_Top_tb"; }
unsigned VUART_Top_tb::threads() const { return 1; }
void VUART_Top_tb::prepareClone() const { contextp()->prepareClone(); }
void VUART_Top_tb::atClone() const {
    contextp()->threadPoolpOnClone();
}
