// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Symbol table internal header
//
// Internal details; most calling programs do not need this header,
// unless using verilator public meta comments.

#ifndef VERILATED_VASYNCHRONOUS_FIFO_TB__SYMS_H_
#define VERILATED_VASYNCHRONOUS_FIFO_TB__SYMS_H_  // guard

#include "verilated.h"

// INCLUDE MODEL CLASS

#include "Vasynchronous_fifo_tb.h"

// INCLUDE MODULE CLASSES
#include "Vasynchronous_fifo_tb___024root.h"

// SYMS CLASS (contains all model state)
class alignas(VL_CACHE_LINE_BYTES) Vasynchronous_fifo_tb__Syms final : public VerilatedSyms {
  public:
    // INTERNAL STATE
    Vasynchronous_fifo_tb* const __Vm_modelp;
    VlDeleter __Vm_deleter;
    bool __Vm_didInit = false;

    // MODULE INSTANCE STATE
    Vasynchronous_fifo_tb___024root TOP;

    // COVERAGE
    uint32_t __Vcoverage[360];

    // CONSTRUCTORS
    Vasynchronous_fifo_tb__Syms(VerilatedContext* contextp, const char* namep, Vasynchronous_fifo_tb* modelp);
    ~Vasynchronous_fifo_tb__Syms();

    // METHODS
    const char* name() const { return TOP.vlNamep; }
};

#endif  // guard
