# Flow Report Index

- chip_id: `async-fifo-v0.1`
- run_id: `T-FIFO-001`
- execution: `20260523-095620`
- completeness_status: `PASS`
- generated_at: `2026-05-23T09:56:41.391508+08:00`

## Mainline

- PRD v1.0 -> PRD v0.9 -> PRD v1.4 -> PRD v1.3 -> PRD v1.13 -> PRD v1.14 -> PRD v1.15

## Cross-cutting / Backflow Lanes

- PRD v1.9 -> PRD v1.1/v1.2

## Report Family Status

| family | version | phase | required | status | missing_count |
|---|---|---|---|---|---|
| readiness_report | v0.2 | PRD v0.9 | True | PRESENT | 0 |
| signoff_report | v1.13 | PRD v1.13 | True | PRESENT | 0 |
| tapeout_package_report | v1.14 | PRD v1.14 | True | PRESENT | 0 |
| silicon_feedback_report | v1.15 | PRD v1.15 | True | PRESENT | 0 |
| skill_backflow_report | v1.9 | PRD v1.9 | False | PRESENT | 0 |
| knowledge_backflow_report | v1.1_v1.2 | PRD v1.1/v1.2 | False | PRESENT | 0 |

Canonical truth remains governed JSON objects and evidence refs. This index is a derived-only registry surface.
