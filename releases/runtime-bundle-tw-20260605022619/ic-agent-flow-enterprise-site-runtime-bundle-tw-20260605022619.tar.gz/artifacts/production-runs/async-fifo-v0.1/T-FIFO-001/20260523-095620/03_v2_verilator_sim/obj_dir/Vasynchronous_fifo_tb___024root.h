// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vasynchronous_fifo_tb.h for the primary calling header

#ifndef VERILATED_VASYNCHRONOUS_FIFO_TB___024ROOT_H_
#define VERILATED_VASYNCHRONOUS_FIFO_TB___024ROOT_H_  // guard

#include "verilated.h"
#include "verilated_cov.h"
#include "verilated_timing.h"


class Vasynchronous_fifo_tb__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vasynchronous_fifo_tb___024root final {
  public:

    // DESIGN SPECIFIC STATE
    // Anonymous structures to workaround compiler member-count bugs
    struct {
        CData/*0:0*/ asynchronous_fifo_tb__DOT__full;
        CData/*0:0*/ asynchronous_fifo_tb__DOT__empty;
        CData/*7:0*/ asynchronous_fifo_tb__DOT__data_in;
        CData/*0:0*/ asynchronous_fifo_tb__DOT__w_en;
        CData/*0:0*/ asynchronous_fifo_tb__DOT__wclock;
        CData/*0:0*/ asynchronous_fifo_tb__DOT__wreset;
        CData/*0:0*/ asynchronous_fifo_tb__DOT__r_en;
        CData/*0:0*/ asynchronous_fifo_tb__DOT__rclock;
        CData/*0:0*/ asynchronous_fifo_tb__DOT__rreset;
        CData/*7:0*/ asynchronous_fifo_tb__DOT__expected_data;
        CData/*7:0*/ asynchronous_fifo_tb__DOT____Vtogcov__data_out;
        CData/*0:0*/ asynchronous_fifo_tb__DOT____Vtogcov__full;
        CData/*0:0*/ asynchronous_fifo_tb__DOT____Vtogcov__empty;
        CData/*7:0*/ asynchronous_fifo_tb__DOT____Vtogcov__data_in;
        CData/*0:0*/ asynchronous_fifo_tb__DOT____Vtogcov__w_en;
        CData/*0:0*/ asynchronous_fifo_tb__DOT____Vtogcov__wclock;
        CData/*0:0*/ asynchronous_fifo_tb__DOT____Vtogcov__wreset;
        CData/*0:0*/ asynchronous_fifo_tb__DOT____Vtogcov__r_en;
        CData/*0:0*/ asynchronous_fifo_tb__DOT____Vtogcov__rclock;
        CData/*0:0*/ asynchronous_fifo_tb__DOT____Vtogcov__rreset;
        CData/*7:0*/ asynchronous_fifo_tb__DOT____Vtogcov__expected_data;
        CData/*3:0*/ asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_wptr_sync;
        CData/*3:0*/ asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr_sync;
        CData/*3:0*/ asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_wptr;
        CData/*3:0*/ asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr;
        CData/*3:0*/ asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_wptr;
        CData/*3:0*/ asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr;
        CData/*3:0*/ asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_wptr_sync;
        CData/*3:0*/ asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_rptr_sync;
        CData/*3:0*/ asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__bin_wptr;
        CData/*3:0*/ asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__bin_rptr;
        CData/*3:0*/ asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_wptr;
        CData/*3:0*/ asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_rptr;
        CData/*3:0*/ asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_wptr__DOT__q1;
        CData/*3:0*/ asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_wptr__DOT____Vtogcov__q1;
        CData/*3:0*/ asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_rptr__DOT__q1;
        CData/*3:0*/ asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_rptr__DOT____Vtogcov__q1;
        CData/*3:0*/ asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__bin_wptr_next;
        CData/*3:0*/ asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__gray_wptr_next;
        CData/*0:0*/ asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__wfull;
        CData/*3:0*/ asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__bin_wptr_next;
        CData/*3:0*/ asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__gray_wptr_next;
        CData/*0:0*/ asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__wfull;
        CData/*3:0*/ asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__bin_rptr_next;
        CData/*3:0*/ asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__gray_rptr_next;
        CData/*0:0*/ asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__rempty;
        CData/*3:0*/ asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__bin_rptr_next;
        CData/*3:0*/ asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__gray_rptr_next;
        CData/*0:0*/ asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__rempty;
        CData/*2:0*/ asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__bin_wptr;
        CData/*2:0*/ asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__bin_rptr;
        CData/*0:0*/ __VstlFirstIteration;
        CData/*0:0*/ __VstlPhaseResult;
        CData/*0:0*/ __Vtrigprevexpr___TOP__asynchronous_fifo_tb__DOT__rclock__0;
        CData/*0:0*/ __Vtrigprevexpr___TOP__asynchronous_fifo_tb__DOT__rreset__0;
        CData/*0:0*/ __Vtrigprevexpr___TOP__asynchronous_fifo_tb__DOT__wclock__0;
        CData/*0:0*/ __Vtrigprevexpr___TOP__asynchronous_fifo_tb__DOT__wreset__0;
        CData/*0:0*/ __Vtrigprevexpr_h6bda5152__1;
        CData/*0:0*/ __VactPhaseResult;
        CData/*0:0*/ __VinactPhaseResult;
        CData/*0:0*/ __VnbaPhaseResult;
        IData/*31:0*/ __VactIterCount;
        IData/*31:0*/ __VinactIterCount;
        IData/*31:0*/ __Vi;
    };
    struct {
        VlUnpacked<CData/*7:0*/, 8> asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo;
        VlUnpacked<CData/*7:0*/, 8> asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo;
        VlUnpacked<QData/*63:0*/, 1> __VstlTriggered;
        VlUnpacked<QData/*63:0*/, 1> __VactTriggered;
        VlUnpacked<QData/*63:0*/, 1> __VactTriggeredAcc;
        VlUnpacked<QData/*63:0*/, 1> __VnbaTriggered;
    };
    VlQueue<CData/*7:0*/> asynchronous_fifo_tb__DOT__expected_q;
    VlDelayScheduler __VdlySched;
    VlTriggerScheduler __VtrigSched_h0e3b6fae__0;
    VlTriggerScheduler __VtrigSched_hd0cd284b__0;
    VlTriggerScheduler __VtrigSched_hfbed39bb__0;

    // INTERNAL VARIABLES
    Vasynchronous_fifo_tb__Syms* vlSymsp;
    const char* vlNamep;

    // CONSTRUCTORS
    Vasynchronous_fifo_tb___024root(Vasynchronous_fifo_tb__Syms* symsp, const char* namep);
    ~Vasynchronous_fifo_tb___024root();
    VL_UNCOPYABLE(Vasynchronous_fifo_tb___024root);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
    void __vlCoverInsert(uint32_t* countp, bool enable, const char* filenamep, int lineno, int column,
        const char* hierp, const char* pagep, const char* commentp, const char* linescovp);
    void __vlCoverToggleInsert(int begin, int end, bool ranged, uint32_t* countp, bool enable, const char* filenamep, int lineno, int column,
        const char* hierp, const char* pagep, const char* commentp);
};


#endif  // guard
