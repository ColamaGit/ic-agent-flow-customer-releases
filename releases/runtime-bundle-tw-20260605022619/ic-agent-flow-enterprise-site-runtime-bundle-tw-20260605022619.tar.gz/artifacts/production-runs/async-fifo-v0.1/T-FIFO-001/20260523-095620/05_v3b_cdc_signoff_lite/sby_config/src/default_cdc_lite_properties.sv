// v1.11 CDC signoff-lite default property pack (non-signoff).
// Intentionally minimal and chip-agnostic. Project-specific packs should supersede this file.

`default_nettype none

module cdc_signoff_lite_default_props;
  // Placeholder guard property so the lane is machine-executable.
  // This does not represent signoff-grade CDC proof.
  always @(*) begin
    assert (1'b1);
  end
endmodule

`default_nettype wire
