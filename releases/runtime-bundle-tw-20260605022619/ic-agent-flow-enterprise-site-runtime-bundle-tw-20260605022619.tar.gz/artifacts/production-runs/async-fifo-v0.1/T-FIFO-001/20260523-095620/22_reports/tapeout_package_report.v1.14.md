# Tapeout Package Readiness Report v1.14

- chip_id: `async-fifo-v0.1`
- run_id: `T-FIFO-001`
- execution: `20260523-095620`
- report_family: `tapeout_package_report`
- report_version: `v1.14`
- generated_at: `2026-05-23T09:56:41.377513+08:00`

## Summary

- verdict: `PASS`
- rows_total: `5`
- pass: `1`
- warn: `0`
- blocked: `0`
- not_available: `4`

## Section Status

| section | row_id | status | notes | evidence_count |
|---|---|---|---|---|
| package_status | tapeout_package_manifest | PACKAGE_READY | package assembly verdict | 1 |
| package_status | package_integrity_manifest | NOT_AVAILABLE | package integrity verdict | 1 |
| handoff_chain | handoff_authority_record | NOT_AVAILABLE | authority chain status | 1 |
| handoff_chain | handoff_transfer_record | PENDING | transfer chain status | 1 |
| handoff_chain | handoff_receipt_record | PENDING | receipt chain status | 1 |

## Action Items

- action_item_count: `0`

Canonical truth remains governed JSON objects and evidence references.
