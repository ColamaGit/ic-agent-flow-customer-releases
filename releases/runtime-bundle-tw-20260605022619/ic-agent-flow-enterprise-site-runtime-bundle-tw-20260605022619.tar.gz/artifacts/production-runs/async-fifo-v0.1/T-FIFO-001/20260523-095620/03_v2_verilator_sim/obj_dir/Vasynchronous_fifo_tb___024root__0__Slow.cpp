// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vasynchronous_fifo_tb.h for the primary calling header

#include "Vasynchronous_fifo_tb__pch.h"

void Vasynchronous_fifo_tb___024root___timing_ready(Vasynchronous_fifo_tb___024root* vlSelf);

VL_ATTR_COLD void Vasynchronous_fifo_tb___024root___eval_static(Vasynchronous_fifo_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___eval_static\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__VactTriggered[0U] = (0x0000000000000010ULL 
                                     | vlSelfRef.__VactTriggered[0U]);
    vlSelfRef.__Vtrigprevexpr___TOP__asynchronous_fifo_tb__DOT__rclock__0 
        = vlSelfRef.asynchronous_fifo_tb__DOT__rclock;
    vlSelfRef.__Vtrigprevexpr___TOP__asynchronous_fifo_tb__DOT__rreset__0 
        = vlSelfRef.asynchronous_fifo_tb__DOT__rreset;
    vlSelfRef.__Vtrigprevexpr___TOP__asynchronous_fifo_tb__DOT__wclock__0 
        = vlSelfRef.asynchronous_fifo_tb__DOT__wclock;
    vlSelfRef.__Vtrigprevexpr___TOP__asynchronous_fifo_tb__DOT__wreset__0 
        = vlSelfRef.asynchronous_fifo_tb__DOT__wreset;
    vlSelfRef.__Vtrigprevexpr_h6bda5152__1 = (1U & 
                                              (~ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__empty)));
    Vasynchronous_fifo_tb___024root___timing_ready(vlSelf);
    do {
        vlSelfRef.__VactTriggeredAcc[vlSelfRef.__Vi] 
            = vlSelfRef.__VactTriggered[vlSelfRef.__Vi];
        vlSelfRef.__Vi = ((IData)(1U) + vlSelfRef.__Vi);
    } while ((0U >= vlSelfRef.__Vi));
}

VL_ATTR_COLD void Vasynchronous_fifo_tb___024root___eval_initial__TOP(Vasynchronous_fifo_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___eval_initial__TOP\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSymsp->_vm_contextp__->dumpfile("dump.vcd"s);
    VL_PRINTF_MT("-Info: /customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv:83: $dumpvar ignored, as Verilated without --trace\n");
    ++(vlSymsp->__Vcoverage[83]);
}

VL_ATTR_COLD void Vasynchronous_fifo_tb___024root___eval_final(Vasynchronous_fifo_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___eval_final\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vasynchronous_fifo_tb___024root___dump_triggers__stl(const VlUnpacked<QData/*63:0*/, 1> &triggers, const std::string &tag);
#endif  // VL_DEBUG
VL_ATTR_COLD bool Vasynchronous_fifo_tb___024root___eval_phase__stl(Vasynchronous_fifo_tb___024root* vlSelf);

VL_ATTR_COLD void Vasynchronous_fifo_tb___024root___eval_settle(Vasynchronous_fifo_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___eval_settle\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    IData/*31:0*/ __VstlIterCount;
    // Body
    __VstlIterCount = 0U;
    vlSelfRef.__VstlFirstIteration = 1U;
    do {
        if (VL_UNLIKELY(((0x00002710U < __VstlIterCount)))) {
#ifdef VL_DEBUG
            Vasynchronous_fifo_tb___024root___dump_triggers__stl(vlSelfRef.__VstlTriggered, "stl"s);
#endif
            VL_FATAL_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 3, "", "DIDNOTCONVERGE: Settle region did not converge after '--converge-limit' of 10000 tries");
        }
        __VstlIterCount = ((IData)(1U) + __VstlIterCount);
        vlSelfRef.__VstlPhaseResult = Vasynchronous_fifo_tb___024root___eval_phase__stl(vlSelf);
        vlSelfRef.__VstlFirstIteration = 0U;
    } while (vlSelfRef.__VstlPhaseResult);
}

VL_ATTR_COLD void Vasynchronous_fifo_tb___024root___eval_triggers_vec__stl(Vasynchronous_fifo_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___eval_triggers_vec__stl\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__VstlTriggered[0U] = ((0xfffffffffffffffeULL 
                                      & vlSelfRef.__VstlTriggered[0U]) 
                                     | (IData)((IData)(vlSelfRef.__VstlFirstIteration)));
}

VL_ATTR_COLD bool Vasynchronous_fifo_tb___024root___trigger_anySet__stl(const VlUnpacked<QData/*63:0*/, 1> &in);

#ifdef VL_DEBUG
VL_ATTR_COLD void Vasynchronous_fifo_tb___024root___dump_triggers__stl(const VlUnpacked<QData/*63:0*/, 1> &triggers, const std::string &tag) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___dump_triggers__stl\n"); );
    // Body
    if ((1U & (~ (IData)(Vasynchronous_fifo_tb___024root___trigger_anySet__stl(triggers))))) {
        VL_DBG_MSGS("         No '" + tag + "' region triggers active\n");
    }
    if ((1U & (IData)(triggers[0U]))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 0 is active: Internal 'stl' trigger - first iteration\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD bool Vasynchronous_fifo_tb___024root___trigger_anySet__stl(const VlUnpacked<QData/*63:0*/, 1> &in) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___trigger_anySet__stl\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        if (in[n]) {
            return (1U);
        }
        n = ((IData)(1U) + n);
    } while ((1U > n));
    return (0U);
}

VL_ATTR_COLD void Vasynchronous_fifo_tb___024root___stl_sequent__TOP__0(Vasynchronous_fifo_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___stl_sequent__TOP__0\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__full) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__full))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 16, vlSelfRef.asynchronous_fifo_tb__DOT__full, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__full);
        vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__full 
            = vlSelfRef.asynchronous_fifo_tb__DOT__full;
    }
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__empty) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__empty))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 18, vlSelfRef.asynchronous_fifo_tb__DOT__empty, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__empty);
        vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__empty 
            = vlSelfRef.asynchronous_fifo_tb__DOT__empty;
    }
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__data_in) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__data_in))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 20, vlSelfRef.asynchronous_fifo_tb__DOT__data_in, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__data_in);
        vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__data_in 
            = vlSelfRef.asynchronous_fifo_tb__DOT__data_in;
    }
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__w_en) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__w_en))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 36, vlSelfRef.asynchronous_fifo_tb__DOT__w_en, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__w_en);
        vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__w_en 
            = vlSelfRef.asynchronous_fifo_tb__DOT__w_en;
    }
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__wclock) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__wclock))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 38, vlSelfRef.asynchronous_fifo_tb__DOT__wclock, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__wclock);
        vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__wclock 
            = vlSelfRef.asynchronous_fifo_tb__DOT__wclock;
    }
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__wreset) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__wreset))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 40, vlSelfRef.asynchronous_fifo_tb__DOT__wreset, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__wreset);
        vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__wreset 
            = vlSelfRef.asynchronous_fifo_tb__DOT__wreset;
    }
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__r_en) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__r_en))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 42, vlSelfRef.asynchronous_fifo_tb__DOT__r_en, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__r_en);
        vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__r_en 
            = vlSelfRef.asynchronous_fifo_tb__DOT__r_en;
    }
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__rclock) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__rclock))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 44, vlSelfRef.asynchronous_fifo_tb__DOT__rclock, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__rclock);
        vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__rclock 
            = vlSelfRef.asynchronous_fifo_tb__DOT__rclock;
    }
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__rreset) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__rreset))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 46, vlSelfRef.asynchronous_fifo_tb__DOT__rreset, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__rreset);
        vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__rreset 
            = vlSelfRef.asynchronous_fifo_tb__DOT__rreset;
    }
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__expected_data) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__expected_data))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 48, vlSelfRef.asynchronous_fifo_tb__DOT__expected_data, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__expected_data);
        vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__expected_data 
            = vlSelfRef.asynchronous_fifo_tb__DOT__expected_data;
    }
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_wptr_sync) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_wptr_sync))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 84, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_wptr_sync, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_wptr_sync);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_wptr_sync 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_wptr_sync;
    }
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr_sync) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_rptr_sync))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 92, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr_sync, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_rptr_sync);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_rptr_sync 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr_sync;
    }
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_wptr) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__bin_wptr))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 100, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_wptr, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__bin_wptr);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__bin_wptr 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_wptr;
    }
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__bin_rptr))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 108, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__bin_rptr);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__bin_rptr 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr;
    }
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_wptr) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_wptr))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 116, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_wptr, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_wptr);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_wptr 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_wptr;
    }
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_rptr))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 124, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_rptr);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_rptr 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr;
    }
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_wptr__DOT__q1) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_wptr__DOT____Vtogcov__q1))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 132, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_wptr__DOT__q1, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_wptr__DOT____Vtogcov__q1);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_wptr__DOT____Vtogcov__q1 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_wptr__DOT__q1;
    }
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_rptr__DOT__q1) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_rptr__DOT____Vtogcov__q1))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 145, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_rptr__DOT__q1, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_rptr__DOT____Vtogcov__q1);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_rptr__DOT____Vtogcov__q1 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_rptr__DOT__q1;
    }
    if ((7U & ((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_wptr) 
               ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__bin_wptr)))) {
        VL_COV_TOGGLE_CHG_ST_I(3, vlSymsp->__Vcoverage + 214, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_wptr, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__bin_wptr);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__bin_wptr 
            = (7U & (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_wptr));
    }
    if ((7U & ((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr) 
               ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__bin_rptr)))) {
        VL_COV_TOGGLE_CHG_ST_I(3, vlSymsp->__Vcoverage + 220, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__bin_rptr);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__bin_rptr 
            = (7U & (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr));
    }
    if ((vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo
         [(7U & (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr))] 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__data_out))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 0, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo
                               [(7U & (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr))], vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__data_out);
        vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__data_out 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo
            [(7U & (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr))];
    }
    if ((vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[0U] 
         ^ vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[0U])) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 226, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[0U], vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[0U]);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[0U] 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[0U];
    }
    if ((vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[1U] 
         ^ vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[1U])) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 242, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[1U], vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[1U]);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[1U] 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[1U];
    }
    if ((vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[2U] 
         ^ vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[2U])) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 258, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[2U], vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[2U]);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[2U] 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[2U];
    }
    if ((vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[3U] 
         ^ vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[3U])) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 274, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[3U], vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[3U]);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[3U] 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[3U];
    }
    if ((vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[4U] 
         ^ vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[4U])) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 290, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[4U], vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[4U]);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[4U] 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[4U];
    }
    if ((vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[5U] 
         ^ vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[5U])) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 306, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[5U], vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[5U]);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[5U] 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[5U];
    }
    if ((vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[6U] 
         ^ vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[6U])) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 322, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[6U], vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[6U]);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[6U] 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[6U];
    }
    if ((vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[7U] 
         ^ vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[7U])) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 338, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[7U], vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[7U]);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[7U] 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[7U];
    }
    vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__bin_wptr_next 
        = (0x0000000fU & ((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_wptr) 
                          + ((~ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__full)) 
                             & (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__w_en))));
    vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__bin_rptr_next 
        = (0x0000000fU & ((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr) 
                          + ((~ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__empty)) 
                             & (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__r_en))));
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__bin_wptr_next) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__bin_wptr_next))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 158, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__bin_wptr_next, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__bin_wptr_next);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__bin_wptr_next 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__bin_wptr_next;
    }
    vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__gray_wptr_next 
        = ((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__bin_wptr_next) 
           ^ VL_SHIFTR_III(4,4,32, (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__bin_wptr_next), 1U));
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__bin_rptr_next) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__bin_rptr_next))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 186, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__bin_rptr_next, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__bin_rptr_next);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__bin_rptr_next 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__bin_rptr_next;
    }
    vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__gray_rptr_next 
        = ((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__bin_rptr_next) 
           ^ VL_SHIFTR_III(4,4,32, (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__bin_rptr_next), 1U));
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__gray_wptr_next) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__gray_wptr_next))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 166, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__gray_wptr_next, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__gray_wptr_next);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__gray_wptr_next 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__gray_wptr_next;
    }
    vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__wfull 
        = (((0x0000000cU & ((~ ((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr_sync) 
                                >> 2U)) << 2U)) | (3U 
                                                   & (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr_sync))) 
           == (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__gray_wptr_next));
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__gray_rptr_next) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__gray_rptr_next))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 194, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__gray_rptr_next, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__gray_rptr_next);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__gray_rptr_next 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__gray_rptr_next;
    }
    vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__rempty 
        = ((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_wptr_sync) 
           == (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__gray_rptr_next));
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__wfull) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__wfull))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 174, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__wfull, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__wfull);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__wfull 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__wfull;
    }
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__rempty) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__rempty))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 202, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__rempty, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__rempty);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__rempty 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__rempty;
    }
}

VL_ATTR_COLD void Vasynchronous_fifo_tb___024root___eval_stl(Vasynchronous_fifo_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___eval_stl\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1ULL & vlSelfRef.__VstlTriggered[0U])) {
        Vasynchronous_fifo_tb___024root___stl_sequent__TOP__0(vlSelf);
    }
}

VL_ATTR_COLD bool Vasynchronous_fifo_tb___024root___eval_phase__stl(Vasynchronous_fifo_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___eval_phase__stl\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ __VstlExecute;
    // Body
    Vasynchronous_fifo_tb___024root___eval_triggers_vec__stl(vlSelf);
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        Vasynchronous_fifo_tb___024root___dump_triggers__stl(vlSelfRef.__VstlTriggered, "stl"s);
    }
#endif
    __VstlExecute = Vasynchronous_fifo_tb___024root___trigger_anySet__stl(vlSelfRef.__VstlTriggered);
    if (__VstlExecute) {
        Vasynchronous_fifo_tb___024root___eval_stl(vlSelf);
    }
    return (__VstlExecute);
}

bool Vasynchronous_fifo_tb___024root___trigger_anySet__act(const VlUnpacked<QData/*63:0*/, 1> &in);

#ifdef VL_DEBUG
VL_ATTR_COLD void Vasynchronous_fifo_tb___024root___dump_triggers__act(const VlUnpacked<QData/*63:0*/, 1> &triggers, const std::string &tag) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___dump_triggers__act\n"); );
    // Body
    if ((1U & (~ (IData)(Vasynchronous_fifo_tb___024root___trigger_anySet__act(triggers))))) {
        VL_DBG_MSGS("         No '" + tag + "' region triggers active\n");
    }
    if ((1U & (IData)(triggers[0U]))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 0 is active: @(posedge asynchronous_fifo_tb.rclock)\n");
    }
    if ((1U & (IData)((triggers[0U] >> 1U)))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 1 is active: @(negedge asynchronous_fifo_tb.rreset)\n");
    }
    if ((1U & (IData)((triggers[0U] >> 2U)))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 2 is active: @(posedge asynchronous_fifo_tb.wclock)\n");
    }
    if ((1U & (IData)((triggers[0U] >> 3U)))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 3 is active: @(negedge asynchronous_fifo_tb.wreset)\n");
    }
    if ((1U & (IData)((triggers[0U] >> 4U)))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 4 is active: @( (~ asynchronous_fifo_tb.empty))\n");
    }
    if ((1U & (IData)((triggers[0U] >> 5U)))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 5 is active: @([true] __VdlySched.awaitingCurrentTime())\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD void Vasynchronous_fifo_tb___024root___ctor_var_reset(Vasynchronous_fifo_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___ctor_var_reset\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    const uint64_t __VscopeHash = VL_MURMUR64_HASH(vlSelf->vlNamep);
    vlSelf->asynchronous_fifo_tb__DOT__full = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 5093167874126769477ull);
    vlSelf->asynchronous_fifo_tb__DOT__empty = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 5430192815635301582ull);
    vlSelf->asynchronous_fifo_tb__DOT__data_in = VL_SCOPED_RAND_RESET_I(8, __VscopeHash, 3729524305660295963ull);
    vlSelf->asynchronous_fifo_tb__DOT__w_en = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 6191454132272834790ull);
    vlSelf->asynchronous_fifo_tb__DOT__wclock = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 15833586580369450285ull);
    vlSelf->asynchronous_fifo_tb__DOT__wreset = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 138338609183702857ull);
    vlSelf->asynchronous_fifo_tb__DOT__r_en = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 8204092549695654621ull);
    vlSelf->asynchronous_fifo_tb__DOT__rclock = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 6378118165697119336ull);
    vlSelf->asynchronous_fifo_tb__DOT__rreset = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 18386116555805565445ull);
    vlSelf->asynchronous_fifo_tb__DOT__expected_q.atDefault() = VL_SCOPED_RAND_RESET_I(8, __VscopeHash, 17400699370520368730ull);
    vlSelf->asynchronous_fifo_tb__DOT__expected_data = VL_SCOPED_RAND_RESET_I(8, __VscopeHash, 5203351900815954889ull);
    vlSelf->asynchronous_fifo_tb__DOT____Vtogcov__data_out = 0;
    vlSelf->asynchronous_fifo_tb__DOT____Vtogcov__full = 0;
    vlSelf->asynchronous_fifo_tb__DOT____Vtogcov__empty = 0;
    vlSelf->asynchronous_fifo_tb__DOT____Vtogcov__data_in = 0;
    vlSelf->asynchronous_fifo_tb__DOT____Vtogcov__w_en = 0;
    vlSelf->asynchronous_fifo_tb__DOT____Vtogcov__wclock = 0;
    vlSelf->asynchronous_fifo_tb__DOT____Vtogcov__wreset = 0;
    vlSelf->asynchronous_fifo_tb__DOT____Vtogcov__r_en = 0;
    vlSelf->asynchronous_fifo_tb__DOT____Vtogcov__rclock = 0;
    vlSelf->asynchronous_fifo_tb__DOT____Vtogcov__rreset = 0;
    vlSelf->asynchronous_fifo_tb__DOT____Vtogcov__expected_data = 0;
    vlSelf->asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_wptr_sync = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 17207543474924689495ull);
    vlSelf->asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr_sync = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 2613639579264014823ull);
    vlSelf->asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_wptr = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 7194292977394154248ull);
    vlSelf->asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 154448244840847510ull);
    vlSelf->asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_wptr = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 2629839047578994969ull);
    vlSelf->asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 9453268076542408810ull);
    vlSelf->asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_wptr_sync = 0;
    vlSelf->asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_rptr_sync = 0;
    vlSelf->asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__bin_wptr = 0;
    vlSelf->asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__bin_rptr = 0;
    vlSelf->asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_wptr = 0;
    vlSelf->asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_rptr = 0;
    vlSelf->asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_wptr__DOT__q1 = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 6798377152547422295ull);
    vlSelf->asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_wptr__DOT____Vtogcov__q1 = 0;
    vlSelf->asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_rptr__DOT__q1 = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 3461664041823984864ull);
    vlSelf->asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_rptr__DOT____Vtogcov__q1 = 0;
    vlSelf->asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__bin_wptr_next = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 16984969455351266368ull);
    vlSelf->asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__gray_wptr_next = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 15935536748927255559ull);
    vlSelf->asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__wfull = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 8404399641662665407ull);
    vlSelf->asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__bin_wptr_next = 0;
    vlSelf->asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__gray_wptr_next = 0;
    vlSelf->asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__wfull = 0;
    vlSelf->asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__bin_rptr_next = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 7251730906831422835ull);
    vlSelf->asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__gray_rptr_next = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 11341923939334730640ull);
    vlSelf->asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__rempty = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 8426108005489991220ull);
    vlSelf->asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__bin_rptr_next = 0;
    vlSelf->asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__gray_rptr_next = 0;
    vlSelf->asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__rempty = 0;
    for (int __Vi0 = 0; __Vi0 < 8; ++__Vi0) {
        vlSelf->asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[__Vi0] = VL_SCOPED_RAND_RESET_I(8, __VscopeHash, 3704573951270041189ull);
    }
    vlSelf->asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__bin_wptr = 0;
    vlSelf->asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__bin_rptr = 0;
    for (int __Vi0 = 0; __Vi0 < 8; ++__Vi0) {
        vlSelf->asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[__Vi0] = 0;
    }
    for (int __Vi0 = 0; __Vi0 < 1; ++__Vi0) {
        vlSelf->__VstlTriggered[__Vi0] = 0;
    }
    for (int __Vi0 = 0; __Vi0 < 1; ++__Vi0) {
        vlSelf->__VactTriggered[__Vi0] = 0;
    }
    for (int __Vi0 = 0; __Vi0 < 1; ++__Vi0) {
        vlSelf->__VactTriggeredAcc[__Vi0] = 0;
    }
    vlSelf->__Vtrigprevexpr___TOP__asynchronous_fifo_tb__DOT__rclock__0 = 0;
    vlSelf->__Vtrigprevexpr___TOP__asynchronous_fifo_tb__DOT__rreset__0 = 0;
    vlSelf->__Vtrigprevexpr___TOP__asynchronous_fifo_tb__DOT__wclock__0 = 0;
    vlSelf->__Vtrigprevexpr___TOP__asynchronous_fifo_tb__DOT__wreset__0 = 0;
    vlSelf->__Vtrigprevexpr_h6bda5152__1 = 0;
    for (int __Vi0 = 0; __Vi0 < 1; ++__Vi0) {
        vlSelf->__VnbaTriggered[__Vi0] = 0;
    }
    vlSelf->__Vi = 0;
}

VL_ATTR_COLD void Vasynchronous_fifo_tb___024root___configure_coverage(Vasynchronous_fifo_tb___024root* vlSelf, bool first) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___configure_coverage\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    (void)first;  // Prevent unused variable warning
    vlSelf->__vlCoverToggleInsert(0, 7, 1, &(vlSymsp->__Vcoverage[0]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 7, 25, ".asynchronous_fifo_tb", "v_toggle/asynchronous_fifo_tb", "data_out");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[16]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 8, 8, ".asynchronous_fifo_tb", "v_toggle/asynchronous_fifo_tb", "full");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[18]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 9, 8, ".asynchronous_fifo_tb", "v_toggle/asynchronous_fifo_tb", "empty");
    vlSelf->__vlCoverToggleInsert(0, 7, 1, &(vlSymsp->__Vcoverage[20]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 10, 24, ".asynchronous_fifo_tb", "v_toggle/asynchronous_fifo_tb", "data_in");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[36]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 11, 7, ".asynchronous_fifo_tb", "v_toggle/asynchronous_fifo_tb", "w_en");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[38]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 11, 13, ".asynchronous_fifo_tb", "v_toggle/asynchronous_fifo_tb", "wclock");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[40]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 11, 21, ".asynchronous_fifo_tb", "v_toggle/asynchronous_fifo_tb", "wreset");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[42]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 12, 7, ".asynchronous_fifo_tb", "v_toggle/asynchronous_fifo_tb", "r_en");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[44]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 12, 13, ".asynchronous_fifo_tb", "v_toggle/asynchronous_fifo_tb", "rclock");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[46]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 12, 21, ".asynchronous_fifo_tb", "v_toggle/asynchronous_fifo_tb", "rreset");
    vlSelf->__vlCoverToggleInsert(0, 7, 1, &(vlSymsp->__Vcoverage[48]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 16, 24, ".asynchronous_fifo_tb", "v_toggle/asynchronous_fifo_tb", "expected_data");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[64]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 19, 23, ".asynchronous_fifo_tb", "v_expr/asynchronous_fifo_tb", "(wclock==0) => 1", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[65]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 19, 23, ".asynchronous_fifo_tb", "v_expr/asynchronous_fifo_tb", "(wclock==1) => 0", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[66]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 19, 3, ".asynchronous_fifo_tb", "v_line/asynchronous_fifo_tb", "block", "19");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[67]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 20, 23, ".asynchronous_fifo_tb", "v_expr/asynchronous_fifo_tb", "(rclock==0) => 1", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[68]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 20, 23, ".asynchronous_fifo_tb", "v_expr/asynchronous_fifo_tb", "(rclock==1) => 0", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[69]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 20, 3, ".asynchronous_fifo_tb", "v_line/asynchronous_fifo_tb", "block", "20");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[70]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 26, 5, ".asynchronous_fifo_tb", "v_line/asynchronous_fifo_tb", "block", "26");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[71]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 33, 10, ".asynchronous_fifo_tb", "v_line/asynchronous_fifo_tb", "case", "33");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[72]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 34, 10, ".asynchronous_fifo_tb", "v_line/asynchronous_fifo_tb", "case", "34");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[73]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 35, 10, ".asynchronous_fifo_tb", "v_line/asynchronous_fifo_tb", "case", "35");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[74]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 36, 9, ".asynchronous_fifo_tb", "v_line/asynchronous_fifo_tb", "case", "36");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[75]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 29, 5, ".asynchronous_fifo_tb", "v_line/asynchronous_fifo_tb", "block", "29-32,38");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[76]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 22, 3, ".asynchronous_fifo_tb", "v_line/asynchronous_fifo_tb", "block", "22-27,29,40-41");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[77]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 49, 5, ".asynchronous_fifo_tb", "v_line/asynchronous_fifo_tb", "block", "49");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[78]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 51, 5, ".asynchronous_fifo_tb", "v_line/asynchronous_fifo_tb", "block", "51");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[79]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 54, 13, ".asynchronous_fifo_tb", "v_expr/asynchronous_fifo_tb", "(empty==0) => 1", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[80]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 54, 13, ".asynchronous_fifo_tb", "v_expr/asynchronous_fifo_tb", "(empty==1) => 0", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[81]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 44, 3, ".asynchronous_fifo_tb", "v_line/asynchronous_fifo_tb", "block", "44-47,49-51,53,71-72");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[82]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 76, 5, ".asynchronous_fifo_tb", "v_line/asynchronous_fifo_tb", "block", "76");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[83]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 81, 3, ".asynchronous_fifo_tb", "v_line/asynchronous_fifo_tb", "block", "81-83");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[38]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/asynchronous_fifo.sv", 5, 9, ".asynchronous_fifo_tb.as_fifo", "v_toggle/asynchronous_fifo", "wclock");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[40]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/asynchronous_fifo.sv", 5, 17, ".asynchronous_fifo_tb.as_fifo", "v_toggle/asynchronous_fifo", "wreset");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[44]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/asynchronous_fifo.sv", 6, 9, ".asynchronous_fifo_tb.as_fifo", "v_toggle/asynchronous_fifo", "rclock");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[46]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/asynchronous_fifo.sv", 6, 17, ".asynchronous_fifo_tb.as_fifo", "v_toggle/asynchronous_fifo", "rreset");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[36]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/asynchronous_fifo.sv", 7, 9, ".asynchronous_fifo_tb.as_fifo", "v_toggle/asynchronous_fifo", "w_en");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[42]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/asynchronous_fifo.sv", 7, 15, ".asynchronous_fifo_tb.as_fifo", "v_toggle/asynchronous_fifo", "r_en");
    vlSelf->__vlCoverToggleInsert(0, 7, 1, &(vlSymsp->__Vcoverage[20]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/asynchronous_fifo.sv", 8, 26, ".asynchronous_fifo_tb.as_fifo", "v_toggle/asynchronous_fifo", "data_in");
    vlSelf->__vlCoverToggleInsert(0, 7, 1, &(vlSymsp->__Vcoverage[0]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/asynchronous_fifo.sv", 9, 31, ".asynchronous_fifo_tb.as_fifo", "v_toggle/asynchronous_fifo", "data_out");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[16]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/asynchronous_fifo.sv", 10, 14, ".asynchronous_fifo_tb.as_fifo", "v_toggle/asynchronous_fifo", "full");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[18]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/asynchronous_fifo.sv", 10, 20, ".asynchronous_fifo_tb.as_fifo", "v_toggle/asynchronous_fifo", "empty");
    vlSelf->__vlCoverToggleInsert(0, 3, 1, &(vlSymsp->__Vcoverage[84]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/asynchronous_fifo.sv", 15, 21, ".asynchronous_fifo_tb.as_fifo", "v_toggle/asynchronous_fifo", "gray_wptr_sync");
    vlSelf->__vlCoverToggleInsert(0, 3, 1, &(vlSymsp->__Vcoverage[92]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/asynchronous_fifo.sv", 15, 37, ".asynchronous_fifo_tb.as_fifo", "v_toggle/asynchronous_fifo", "gray_rptr_sync");
    vlSelf->__vlCoverToggleInsert(0, 3, 1, &(vlSymsp->__Vcoverage[100]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/asynchronous_fifo.sv", 17, 21, ".asynchronous_fifo_tb.as_fifo", "v_toggle/asynchronous_fifo", "bin_wptr");
    vlSelf->__vlCoverToggleInsert(0, 3, 1, &(vlSymsp->__Vcoverage[108]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/asynchronous_fifo.sv", 17, 31, ".asynchronous_fifo_tb.as_fifo", "v_toggle/asynchronous_fifo", "bin_rptr");
    vlSelf->__vlCoverToggleInsert(0, 3, 1, &(vlSymsp->__Vcoverage[116]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/asynchronous_fifo.sv", 19, 21, ".asynchronous_fifo_tb.as_fifo", "v_toggle/asynchronous_fifo", "gray_wptr");
    vlSelf->__vlCoverToggleInsert(0, 3, 1, &(vlSymsp->__Vcoverage[124]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/asynchronous_fifo.sv", 19, 32, ".asynchronous_fifo_tb.as_fifo", "v_toggle/asynchronous_fifo", "gray_rptr");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[44]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/synchronizer.v", 1, 49, ".asynchronous_fifo_tb.as_fifo.sync_wptr", "v_toggle/synchronizer", "clock");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[46]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/synchronizer.v", 1, 56, ".asynchronous_fifo_tb.as_fifo.sync_wptr", "v_toggle/synchronizer", "reset");
    vlSelf->__vlCoverToggleInsert(0, 3, 1, &(vlSymsp->__Vcoverage[116]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/synchronizer.v", 1, 79, ".asynchronous_fifo_tb.as_fifo.sync_wptr", "v_toggle/synchronizer", "data_in");
    vlSelf->__vlCoverToggleInsert(0, 3, 1, &(vlSymsp->__Vcoverage[84]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/synchronizer.v", 1, 109, ".asynchronous_fifo_tb.as_fifo.sync_wptr", "v_toggle/synchronizer", "data_out");
    vlSelf->__vlCoverToggleInsert(0, 3, 1, &(vlSymsp->__Vcoverage[132]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/synchronizer.v", 2, 17, ".asynchronous_fifo_tb.as_fifo.sync_wptr", "v_toggle/synchronizer", "q1");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[140]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/synchronizer.v", 4, 5, ".asynchronous_fifo_tb.as_fifo.sync_wptr", "v_branch/synchronizer", "if", "4-6");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[141]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/synchronizer.v", 4, 6, ".asynchronous_fifo_tb.as_fifo.sync_wptr", "v_branch/synchronizer", "else", "8-10");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[142]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/synchronizer.v", 4, 8, ".asynchronous_fifo_tb.as_fifo.sync_wptr", "v_expr/synchronizer", "(reset==0) => 1", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[143]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/synchronizer.v", 4, 8, ".asynchronous_fifo_tb.as_fifo.sync_wptr", "v_expr/synchronizer", "(reset==1) => 0", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[144]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/synchronizer.v", 3, 3, ".asynchronous_fifo_tb.as_fifo.sync_wptr", "v_line/synchronizer", "block", "3");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[38]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/synchronizer.v", 1, 49, ".asynchronous_fifo_tb.as_fifo.sync_rptr", "v_toggle/synchronizer", "clock");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[40]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/synchronizer.v", 1, 56, ".asynchronous_fifo_tb.as_fifo.sync_rptr", "v_toggle/synchronizer", "reset");
    vlSelf->__vlCoverToggleInsert(0, 3, 1, &(vlSymsp->__Vcoverage[124]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/synchronizer.v", 1, 79, ".asynchronous_fifo_tb.as_fifo.sync_rptr", "v_toggle/synchronizer", "data_in");
    vlSelf->__vlCoverToggleInsert(0, 3, 1, &(vlSymsp->__Vcoverage[92]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/synchronizer.v", 1, 109, ".asynchronous_fifo_tb.as_fifo.sync_rptr", "v_toggle/synchronizer", "data_out");
    vlSelf->__vlCoverToggleInsert(0, 3, 1, &(vlSymsp->__Vcoverage[145]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/synchronizer.v", 2, 17, ".asynchronous_fifo_tb.as_fifo.sync_rptr", "v_toggle/synchronizer", "q1");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[153]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/synchronizer.v", 4, 5, ".asynchronous_fifo_tb.as_fifo.sync_rptr", "v_branch/synchronizer", "if", "4-6");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[154]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/synchronizer.v", 4, 6, ".asynchronous_fifo_tb.as_fifo.sync_rptr", "v_branch/synchronizer", "else", "8-10");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[155]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/synchronizer.v", 4, 8, ".asynchronous_fifo_tb.as_fifo.sync_rptr", "v_expr/synchronizer", "(reset==0) => 1", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[156]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/synchronizer.v", 4, 8, ".asynchronous_fifo_tb.as_fifo.sync_rptr", "v_expr/synchronizer", "(reset==1) => 0", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[157]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/synchronizer.v", 3, 3, ".asynchronous_fifo_tb.as_fifo.sync_rptr", "v_line/synchronizer", "block", "3");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[38]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/write_pointer.v", 2, 9, ".asynchronous_fifo_tb.as_fifo.wptr_h", "v_toggle/write_pointer", "wclock");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[40]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/write_pointer.v", 2, 17, ".asynchronous_fifo_tb.as_fifo.wptr_h", "v_toggle/write_pointer", "wreset");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[36]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/write_pointer.v", 2, 25, ".asynchronous_fifo_tb.as_fifo.wptr_h", "v_toggle/write_pointer", "w_en");
    vlSelf->__vlCoverToggleInsert(0, 3, 1, &(vlSymsp->__Vcoverage[92]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/write_pointer.v", 3, 23, ".asynchronous_fifo_tb.as_fifo.wptr_h", "v_toggle/write_pointer", "gray_rptr_sync");
    vlSelf->__vlCoverToggleInsert(0, 3, 1, &(vlSymsp->__Vcoverage[100]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/write_pointer.v", 4, 28, ".asynchronous_fifo_tb.as_fifo.wptr_h", "v_toggle/write_pointer", "bin_wptr");
    vlSelf->__vlCoverToggleInsert(0, 3, 1, &(vlSymsp->__Vcoverage[116]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/write_pointer.v", 4, 38, ".asynchronous_fifo_tb.as_fifo.wptr_h", "v_toggle/write_pointer", "gray_wptr");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[16]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/write_pointer.v", 5, 14, ".asynchronous_fifo_tb.as_fifo.wptr_h", "v_toggle/write_pointer", "full");
    vlSelf->__vlCoverToggleInsert(0, 3, 1, &(vlSymsp->__Vcoverage[158]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/write_pointer.v", 8, 21, ".asynchronous_fifo_tb.as_fifo.wptr_h", "v_toggle/write_pointer", "bin_wptr_next");
    vlSelf->__vlCoverToggleInsert(0, 3, 1, &(vlSymsp->__Vcoverage[166]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/write_pointer.v", 9, 21, ".asynchronous_fifo_tb.as_fifo.wptr_h", "v_toggle/write_pointer", "gray_wptr_next");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[174]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/write_pointer.v", 11, 8, ".asynchronous_fifo_tb.as_fifo.wptr_h", "v_toggle/write_pointer", "wfull");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[176]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/write_pointer.v", 17, 5, ".asynchronous_fifo_tb.as_fifo.wptr_h", "v_branch/write_pointer", "if", "17-19");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[177]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/write_pointer.v", 17, 6, ".asynchronous_fifo_tb.as_fifo.wptr_h", "v_branch/write_pointer", "else", "21-23");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[178]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/write_pointer.v", 17, 8, ".asynchronous_fifo_tb.as_fifo.wptr_h", "v_expr/write_pointer", "(wreset==0) => 1", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[179]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/write_pointer.v", 17, 8, ".asynchronous_fifo_tb.as_fifo.wptr_h", "v_expr/write_pointer", "(wreset==1) => 0", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[180]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/write_pointer.v", 16, 3, ".asynchronous_fifo_tb.as_fifo.wptr_h", "v_line/write_pointer", "block", "16");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[181]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/write_pointer.v", 28, 5, ".asynchronous_fifo_tb.as_fifo.wptr_h", "v_branch/write_pointer", "if", "28");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[182]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/write_pointer.v", 28, 6, ".asynchronous_fifo_tb.as_fifo.wptr_h", "v_branch/write_pointer", "else", "29");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[183]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/write_pointer.v", 28, 8, ".asynchronous_fifo_tb.as_fifo.wptr_h", "v_expr/write_pointer", "(wreset==0) => 1", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[184]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/write_pointer.v", 28, 8, ".asynchronous_fifo_tb.as_fifo.wptr_h", "v_expr/write_pointer", "(wreset==1) => 0", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[185]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/write_pointer.v", 27, 3, ".asynchronous_fifo_tb.as_fifo.wptr_h", "v_line/write_pointer", "block", "27");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[44]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/read_pointer.v", 2, 9, ".asynchronous_fifo_tb.as_fifo.rptr_h", "v_toggle/read_pointer", "rclock");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[46]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/read_pointer.v", 2, 17, ".asynchronous_fifo_tb.as_fifo.rptr_h", "v_toggle/read_pointer", "rreset");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[42]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/read_pointer.v", 2, 25, ".asynchronous_fifo_tb.as_fifo.rptr_h", "v_toggle/read_pointer", "r_en");
    vlSelf->__vlCoverToggleInsert(0, 3, 1, &(vlSymsp->__Vcoverage[84]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/read_pointer.v", 3, 23, ".asynchronous_fifo_tb.as_fifo.rptr_h", "v_toggle/read_pointer", "gray_wptr_sync");
    vlSelf->__vlCoverToggleInsert(0, 3, 1, &(vlSymsp->__Vcoverage[108]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/read_pointer.v", 4, 28, ".asynchronous_fifo_tb.as_fifo.rptr_h", "v_toggle/read_pointer", "bin_rptr");
    vlSelf->__vlCoverToggleInsert(0, 3, 1, &(vlSymsp->__Vcoverage[124]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/read_pointer.v", 4, 38, ".asynchronous_fifo_tb.as_fifo.rptr_h", "v_toggle/read_pointer", "gray_rptr");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[18]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/read_pointer.v", 5, 14, ".asynchronous_fifo_tb.as_fifo.rptr_h", "v_toggle/read_pointer", "empty");
    vlSelf->__vlCoverToggleInsert(0, 3, 1, &(vlSymsp->__Vcoverage[186]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/read_pointer.v", 8, 21, ".asynchronous_fifo_tb.as_fifo.rptr_h", "v_toggle/read_pointer", "bin_rptr_next");
    vlSelf->__vlCoverToggleInsert(0, 3, 1, &(vlSymsp->__Vcoverage[194]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/read_pointer.v", 9, 21, ".asynchronous_fifo_tb.as_fifo.rptr_h", "v_toggle/read_pointer", "gray_rptr_next");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[202]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/read_pointer.v", 10, 8, ".asynchronous_fifo_tb.as_fifo.rptr_h", "v_toggle/read_pointer", "rempty");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[204]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/read_pointer.v", 17, 5, ".asynchronous_fifo_tb.as_fifo.rptr_h", "v_branch/read_pointer", "if", "17-19");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[205]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/read_pointer.v", 17, 6, ".asynchronous_fifo_tb.as_fifo.rptr_h", "v_branch/read_pointer", "else", "21-23");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[206]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/read_pointer.v", 17, 8, ".asynchronous_fifo_tb.as_fifo.rptr_h", "v_expr/read_pointer", "(rreset==0) => 1", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[207]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/read_pointer.v", 17, 8, ".asynchronous_fifo_tb.as_fifo.rptr_h", "v_expr/read_pointer", "(rreset==1) => 0", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[208]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/read_pointer.v", 16, 3, ".asynchronous_fifo_tb.as_fifo.rptr_h", "v_line/read_pointer", "block", "16");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[209]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/read_pointer.v", 28, 5, ".asynchronous_fifo_tb.as_fifo.rptr_h", "v_branch/read_pointer", "if", "28");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[210]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/read_pointer.v", 28, 6, ".asynchronous_fifo_tb.as_fifo.rptr_h", "v_branch/read_pointer", "else", "29");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[211]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/read_pointer.v", 28, 8, ".asynchronous_fifo_tb.as_fifo.rptr_h", "v_expr/read_pointer", "(rreset==0) => 1", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[212]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/read_pointer.v", 28, 8, ".asynchronous_fifo_tb.as_fifo.rptr_h", "v_expr/read_pointer", "(rreset==1) => 0", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[213]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/read_pointer.v", 27, 3, ".asynchronous_fifo_tb.as_fifo.rptr_h", "v_line/read_pointer", "block", "27");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[38]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/fifo_mem.v", 2, 9, ".asynchronous_fifo_tb.as_fifo.fifom", "v_toggle/fifo_mem", "wclock");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[36]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/fifo_mem.v", 2, 17, ".asynchronous_fifo_tb.as_fifo.fifom", "v_toggle/fifo_mem", "w_en");
    vlSelf->__vlCoverToggleInsert(0, 2, 1, &(vlSymsp->__Vcoverage[214]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/fifo_mem.v", 3, 25, ".asynchronous_fifo_tb.as_fifo.fifom", "v_toggle/fifo_mem", "bin_wptr");
    vlSelf->__vlCoverToggleInsert(0, 2, 1, &(vlSymsp->__Vcoverage[220]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/fifo_mem.v", 3, 35, ".asynchronous_fifo_tb.as_fifo.fifom", "v_toggle/fifo_mem", "bin_rptr");
    vlSelf->__vlCoverToggleInsert(0, 7, 1, &(vlSymsp->__Vcoverage[20]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/fifo_mem.v", 4, 26, ".asynchronous_fifo_tb.as_fifo.fifom", "v_toggle/fifo_mem", "data_in");
    vlSelf->__vlCoverToggleInsert(0, 0, 0, &(vlSymsp->__Vcoverage[16]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/fifo_mem.v", 5, 9, ".asynchronous_fifo_tb.as_fifo.fifom", "v_toggle/fifo_mem", "full");
    vlSelf->__vlCoverToggleInsert(0, 7, 1, &(vlSymsp->__Vcoverage[0]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/fifo_mem.v", 6, 27, ".asynchronous_fifo_tb.as_fifo.fifom", "v_toggle/fifo_mem", "data_out");
    vlSelf->__vlCoverToggleInsert(0, 7, 1, &(vlSymsp->__Vcoverage[226]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/fifo_mem.v", 8, 24, ".asynchronous_fifo_tb.as_fifo.fifom", "v_toggle/fifo_mem", "fifo[0]");
    vlSelf->__vlCoverToggleInsert(0, 7, 1, &(vlSymsp->__Vcoverage[242]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/fifo_mem.v", 8, 24, ".asynchronous_fifo_tb.as_fifo.fifom", "v_toggle/fifo_mem", "fifo[1]");
    vlSelf->__vlCoverToggleInsert(0, 7, 1, &(vlSymsp->__Vcoverage[258]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/fifo_mem.v", 8, 24, ".asynchronous_fifo_tb.as_fifo.fifom", "v_toggle/fifo_mem", "fifo[2]");
    vlSelf->__vlCoverToggleInsert(0, 7, 1, &(vlSymsp->__Vcoverage[274]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/fifo_mem.v", 8, 24, ".asynchronous_fifo_tb.as_fifo.fifom", "v_toggle/fifo_mem", "fifo[3]");
    vlSelf->__vlCoverToggleInsert(0, 7, 1, &(vlSymsp->__Vcoverage[290]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/fifo_mem.v", 8, 24, ".asynchronous_fifo_tb.as_fifo.fifom", "v_toggle/fifo_mem", "fifo[4]");
    vlSelf->__vlCoverToggleInsert(0, 7, 1, &(vlSymsp->__Vcoverage[306]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/fifo_mem.v", 8, 24, ".asynchronous_fifo_tb.as_fifo.fifom", "v_toggle/fifo_mem", "fifo[5]");
    vlSelf->__vlCoverToggleInsert(0, 7, 1, &(vlSymsp->__Vcoverage[322]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/fifo_mem.v", 8, 24, ".asynchronous_fifo_tb.as_fifo.fifom", "v_toggle/fifo_mem", "fifo[6]");
    vlSelf->__vlCoverToggleInsert(0, 7, 1, &(vlSymsp->__Vcoverage[338]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/fifo_mem.v", 8, 24, ".asynchronous_fifo_tb.as_fifo.fifom", "v_toggle/fifo_mem", "fifo[7]");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[354]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/fifo_mem.v", 11, 5, ".asynchronous_fifo_tb.as_fifo.fifom", "v_branch/fifo_mem", "if", "11-12");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[355]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/fifo_mem.v", 11, 6, ".asynchronous_fifo_tb.as_fifo.fifom", "v_branch/fifo_mem", "else", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[356]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/fifo_mem.v", 11, 13, ".asynchronous_fifo_tb.as_fifo.fifom", "v_expr/fifo_mem", "(w_en==1 && full==0) => 1", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[357]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/fifo_mem.v", 11, 13, ".asynchronous_fifo_tb.as_fifo.fifom", "v_expr/fifo_mem", "(full==1) => 0", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[358]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/fifo_mem.v", 11, 13, ".asynchronous_fifo_tb.as_fifo.fifom", "v_expr/fifo_mem", "(w_en==0) => 0", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[359]), first, "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/fifo_mem.v", 10, 3, ".asynchronous_fifo_tb.as_fifo.fifom", "v_line/fifo_mem", "block", "10");
}
