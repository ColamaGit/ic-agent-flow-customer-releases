// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Model implementation (design independent parts)

#include "Vasynchronous_fifo_tb__pch.h"

//============================================================
// Constructors

Vasynchronous_fifo_tb::Vasynchronous_fifo_tb(VerilatedContext* _vcontextp__, const char* _vcname__)
    : VerilatedModel{*_vcontextp__}
    , vlSymsp{new Vasynchronous_fifo_tb__Syms(contextp(), _vcname__, this)}
    , rootp{&(vlSymsp->TOP)}
{
    // Register model with the context
    contextp()->addModel(this);
}

Vasynchronous_fifo_tb::Vasynchronous_fifo_tb(const char* _vcname__)
    : Vasynchronous_fifo_tb(Verilated::threadContextp(), _vcname__)
{
}

//============================================================
// Destructor

Vasynchronous_fifo_tb::~Vasynchronous_fifo_tb() {
    delete vlSymsp;
}

//============================================================
// Evaluation function

#ifdef VL_DEBUG
void Vasynchronous_fifo_tb___024root___eval_debug_assertions(Vasynchronous_fifo_tb___024root* vlSelf);
#endif  // VL_DEBUG
void Vasynchronous_fifo_tb___024root___eval_static(Vasynchronous_fifo_tb___024root* vlSelf);
void Vasynchronous_fifo_tb___024root___eval_initial(Vasynchronous_fifo_tb___024root* vlSelf);
void Vasynchronous_fifo_tb___024root___eval_settle(Vasynchronous_fifo_tb___024root* vlSelf);
void Vasynchronous_fifo_tb___024root___eval(Vasynchronous_fifo_tb___024root* vlSelf);

void Vasynchronous_fifo_tb::eval_step() {
    VL_DEBUG_IF(VL_DBG_MSGF("+++++TOP Evaluate Vasynchronous_fifo_tb::eval_step\n"); );
#ifdef VL_DEBUG
    // Debug assertions
    Vasynchronous_fifo_tb___024root___eval_debug_assertions(&(vlSymsp->TOP));
#endif  // VL_DEBUG
    vlSymsp->__Vm_deleter.deleteAll();
    if (VL_UNLIKELY(!vlSymsp->__Vm_didInit)) {
        VL_DEBUG_IF(VL_DBG_MSGF("+ Initial\n"););
        Vasynchronous_fifo_tb___024root___eval_static(&(vlSymsp->TOP));
        Vasynchronous_fifo_tb___024root___eval_initial(&(vlSymsp->TOP));
        Vasynchronous_fifo_tb___024root___eval_settle(&(vlSymsp->TOP));
        vlSymsp->__Vm_didInit = true;
    }
    VL_DEBUG_IF(VL_DBG_MSGF("+ Eval\n"););
    Vasynchronous_fifo_tb___024root___eval(&(vlSymsp->TOP));
    // Evaluate cleanup
    Verilated::endOfEval(vlSymsp->__Vm_evalMsgQp);
}

//============================================================
// Events and timing
bool Vasynchronous_fifo_tb::eventsPending() { return !vlSymsp->TOP.__VdlySched.empty() && !contextp()->gotFinish(); }

uint64_t Vasynchronous_fifo_tb::nextTimeSlot() { return vlSymsp->TOP.__VdlySched.nextTimeSlot(); }

//============================================================
// Utilities

const char* Vasynchronous_fifo_tb::name() const {
    return vlSymsp->name();
}

//============================================================
// Invoke final blocks

void Vasynchronous_fifo_tb___024root___eval_final(Vasynchronous_fifo_tb___024root* vlSelf);

VL_ATTR_COLD void Vasynchronous_fifo_tb::final() {
    contextp()->executingFinal(true);
    Vasynchronous_fifo_tb___024root___eval_final(&(vlSymsp->TOP));
    contextp()->executingFinal(false);
}

//============================================================
// Implementations of abstract methods from VerilatedModel

const char* Vasynchronous_fifo_tb::hierName() const { return vlSymsp->name(); }
const char* Vasynchronous_fifo_tb::modelName() const { return "Vasynchronous_fifo_tb"; }
unsigned Vasynchronous_fifo_tb::threads() const { return 1; }
void Vasynchronous_fifo_tb::prepareClone() const { contextp()->prepareClone(); }
void Vasynchronous_fifo_tb::atClone() const {
    contextp()->threadPoolpOnClone();
}
