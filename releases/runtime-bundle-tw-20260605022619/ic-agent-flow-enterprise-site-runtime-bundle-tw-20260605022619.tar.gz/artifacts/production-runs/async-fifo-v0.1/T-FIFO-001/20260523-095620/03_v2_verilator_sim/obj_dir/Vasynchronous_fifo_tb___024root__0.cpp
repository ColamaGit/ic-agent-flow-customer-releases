// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vasynchronous_fifo_tb.h for the primary calling header

#include "Vasynchronous_fifo_tb__pch.h"

VlCoroutine Vasynchronous_fifo_tb___024root___eval_initial__TOP__Vtiming__0(Vasynchronous_fifo_tb___024root* vlSelf);
VlCoroutine Vasynchronous_fifo_tb___024root___eval_initial__TOP__Vtiming__1(Vasynchronous_fifo_tb___024root* vlSelf);
VlCoroutine Vasynchronous_fifo_tb___024root___eval_initial__TOP__Vtiming__2(Vasynchronous_fifo_tb___024root* vlSelf);
VlCoroutine Vasynchronous_fifo_tb___024root___eval_initial__TOP__Vtiming__3(Vasynchronous_fifo_tb___024root* vlSelf);
VlCoroutine Vasynchronous_fifo_tb___024root___eval_initial__TOP__Vtiming__4(Vasynchronous_fifo_tb___024root* vlSelf);

void Vasynchronous_fifo_tb___024root___eval_initial(Vasynchronous_fifo_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___eval_initial\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSymsp->_vm_contextp__->dumpfile("dump.vcd"s);
    VL_PRINTF_MT("-Info: /customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv:83: $dumpvar ignored, as Verilated without --trace\n");
    ++(vlSymsp->__Vcoverage[83]);
    Vasynchronous_fifo_tb___024root___eval_initial__TOP__Vtiming__0(vlSelf);
    Vasynchronous_fifo_tb___024root___eval_initial__TOP__Vtiming__1(vlSelf);
    Vasynchronous_fifo_tb___024root___eval_initial__TOP__Vtiming__2(vlSelf);
    Vasynchronous_fifo_tb___024root___eval_initial__TOP__Vtiming__3(vlSelf);
    Vasynchronous_fifo_tb___024root___eval_initial__TOP__Vtiming__4(vlSelf);
}

void Vasynchronous_fifo_tb___024root____VbeforeTrig_h0e3b6fae__0(Vasynchronous_fifo_tb___024root* vlSelf, const char* __VeventDescription);

VlCoroutine Vasynchronous_fifo_tb___024root___eval_initial__TOP__Vtiming__0(Vasynchronous_fifo_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___eval_initial__TOP__Vtiming__0\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    IData/*31:0*/ asynchronous_fifo_tb__DOT__unnamedblk1_1__DOT____Vrepeat0;
    asynchronous_fifo_tb__DOT__unnamedblk1_1__DOT____Vrepeat0 = 0;
    IData/*31:0*/ asynchronous_fifo_tb__DOT__unnamedblk1__DOT__idx;
    asynchronous_fifo_tb__DOT__unnamedblk1__DOT__idx = 0;
    // Body
    vlSelfRef.asynchronous_fifo_tb__DOT__wclock = 0U;
    vlSelfRef.asynchronous_fifo_tb__DOT__wreset = 0U;
    vlSelfRef.asynchronous_fifo_tb__DOT__w_en = 0U;
    vlSelfRef.asynchronous_fifo_tb__DOT__data_in = 0U;
    asynchronous_fifo_tb__DOT__unnamedblk1_1__DOT____Vrepeat0 = 4U;
    while (VL_LTS_III(32, 0U, asynchronous_fifo_tb__DOT__unnamedblk1_1__DOT____Vrepeat0)) {
        Vasynchronous_fifo_tb___024root____VbeforeTrig_h0e3b6fae__0(vlSelf, 
                                                                    "@(posedge asynchronous_fifo_tb.wclock)");
        co_await vlSelfRef.__VtrigSched_h0e3b6fae__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge asynchronous_fifo_tb.wclock)", 
                                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 
                                                             26);
        asynchronous_fifo_tb__DOT__unnamedblk1_1__DOT____Vrepeat0 
            = (asynchronous_fifo_tb__DOT__unnamedblk1_1__DOT____Vrepeat0 
               - (IData)(1U));
        ++(vlSymsp->__Vcoverage[70]);
    }
    vlSelfRef.asynchronous_fifo_tb__DOT__wreset = 1U;
    asynchronous_fifo_tb__DOT__unnamedblk1__DOT__idx = 0U;
    while (VL_GTS_III(32, 4U, asynchronous_fifo_tb__DOT__unnamedblk1__DOT__idx)) {
        Vasynchronous_fifo_tb___024root____VbeforeTrig_h0e3b6fae__0(vlSelf, 
                                                                    "@(posedge asynchronous_fifo_tb.wclock)");
        co_await vlSelfRef.__VtrigSched_h0e3b6fae__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge asynchronous_fifo_tb.wclock)", 
                                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 
                                                             30);
        vlSelfRef.asynchronous_fifo_tb__DOT__w_en = 1U;
        if ((0U == asynchronous_fifo_tb__DOT__unnamedblk1__DOT__idx)) {
            vlSelfRef.asynchronous_fifo_tb__DOT__data_in = 0x11U;
            ++(vlSymsp->__Vcoverage[71]);
        } else if ((1U == asynchronous_fifo_tb__DOT__unnamedblk1__DOT__idx)) {
            vlSelfRef.asynchronous_fifo_tb__DOT__data_in = 0x22U;
            ++(vlSymsp->__Vcoverage[72]);
        } else if ((2U == asynchronous_fifo_tb__DOT__unnamedblk1__DOT__idx)) {
            vlSelfRef.asynchronous_fifo_tb__DOT__data_in = 0x33U;
            ++(vlSymsp->__Vcoverage[73]);
        } else {
            vlSelfRef.asynchronous_fifo_tb__DOT__data_in = 0x44U;
            ++(vlSymsp->__Vcoverage[74]);
        }
        vlSelfRef.asynchronous_fifo_tb__DOT__expected_q.push_back(vlSelfRef.asynchronous_fifo_tb__DOT__data_in);
        asynchronous_fifo_tb__DOT__unnamedblk1__DOT__idx 
            = ((IData)(1U) + asynchronous_fifo_tb__DOT__unnamedblk1__DOT__idx);
        ++(vlSymsp->__Vcoverage[75]);
    }
    Vasynchronous_fifo_tb___024root____VbeforeTrig_h0e3b6fae__0(vlSelf, 
                                                                "@(posedge asynchronous_fifo_tb.wclock)");
    co_await vlSelfRef.__VtrigSched_h0e3b6fae__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge asynchronous_fifo_tb.wclock)", 
                                                         "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 
                                                         40);
    vlSelfRef.asynchronous_fifo_tb__DOT__w_en = 0U;
    ++(vlSymsp->__Vcoverage[76]);
    co_return;
}

void Vasynchronous_fifo_tb___024root____VbeforeTrig_hd0cd284b__0(Vasynchronous_fifo_tb___024root* vlSelf, const char* __VeventDescription);
void Vasynchronous_fifo_tb___024root____VbeforeTrig_hfbed39bb__0(Vasynchronous_fifo_tb___024root* vlSelf, const char* __VeventDescription);

VlCoroutine Vasynchronous_fifo_tb___024root___eval_initial__TOP__Vtiming__1(Vasynchronous_fifo_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___eval_initial__TOP__Vtiming__1\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    IData/*31:0*/ asynchronous_fifo_tb__DOT__unnamedblk1_2__DOT____Vrepeat1;
    asynchronous_fifo_tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0;
    IData/*31:0*/ asynchronous_fifo_tb__DOT__unnamedblk1_3__DOT____Vrepeat2;
    asynchronous_fifo_tb__DOT__unnamedblk1_3__DOT____Vrepeat2 = 0;
    IData/*31:0*/ asynchronous_fifo_tb__DOT__unnamedblk1_4__DOT____Vrepeat3;
    asynchronous_fifo_tb__DOT__unnamedblk1_4__DOT____Vrepeat3 = 0;
    // Body
    vlSelfRef.asynchronous_fifo_tb__DOT__rclock = 0U;
    vlSelfRef.asynchronous_fifo_tb__DOT__rreset = 0U;
    vlSelfRef.asynchronous_fifo_tb__DOT__r_en = 0U;
    asynchronous_fifo_tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 4U;
    while (VL_LTS_III(32, 0U, asynchronous_fifo_tb__DOT__unnamedblk1_2__DOT____Vrepeat1)) {
        Vasynchronous_fifo_tb___024root____VbeforeTrig_hd0cd284b__0(vlSelf, 
                                                                    "@(posedge asynchronous_fifo_tb.rclock)");
        co_await vlSelfRef.__VtrigSched_hd0cd284b__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge asynchronous_fifo_tb.rclock)", 
                                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 
                                                             49);
        asynchronous_fifo_tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
            = (asynchronous_fifo_tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
               - (IData)(1U));
        ++(vlSymsp->__Vcoverage[77]);
    }
    vlSelfRef.asynchronous_fifo_tb__DOT__rreset = 1U;
    asynchronous_fifo_tb__DOT__unnamedblk1_3__DOT____Vrepeat2 = 8U;
    while (VL_LTS_III(32, 0U, asynchronous_fifo_tb__DOT__unnamedblk1_3__DOT____Vrepeat2)) {
        Vasynchronous_fifo_tb___024root____VbeforeTrig_hd0cd284b__0(vlSelf, 
                                                                    "@(posedge asynchronous_fifo_tb.rclock)");
        co_await vlSelfRef.__VtrigSched_hd0cd284b__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge asynchronous_fifo_tb.rclock)", 
                                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 
                                                             51);
        asynchronous_fifo_tb__DOT__unnamedblk1_3__DOT____Vrepeat2 
            = (asynchronous_fifo_tb__DOT__unnamedblk1_3__DOT____Vrepeat2 
               - (IData)(1U));
        ++(vlSymsp->__Vcoverage[78]);
    }
    asynchronous_fifo_tb__DOT__unnamedblk1_4__DOT____Vrepeat3 = 4U;
    while (VL_LTS_III(32, 0U, asynchronous_fifo_tb__DOT__unnamedblk1_4__DOT____Vrepeat3)) {
        while (vlSelfRef.asynchronous_fifo_tb__DOT__empty) {
            Vasynchronous_fifo_tb___024root____VbeforeTrig_hfbed39bb__0(vlSelf, 
                                                                        "@( (~ asynchronous_fifo_tb.empty))");
            co_await vlSelfRef.__VtrigSched_hfbed39bb__0.trigger(1U, 
                                                                 nullptr, 
                                                                 "@( (~ asynchronous_fifo_tb.empty))", 
                                                                 "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 
                                                                 54);
        }
        vlSelfRef.asynchronous_fifo_tb__DOT__expected_data 
            = vlSelfRef.asynchronous_fifo_tb__DOT__expected_q.pop_front();
        co_await vlSelfRef.__VdlySched.delay(1ULL, 
                                             nullptr, 
                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 
                                             56);
        if (vlSymsp->_vm_contextp__->assertOnGet(2, 1)) {
            if (VL_UNLIKELY(((vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo
                              [(7U & (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr))] 
                              != (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__expected_data))))) {
                VL_WRITEF_NX("[%0t] %%Error: testbench.sv:58: Assertion failed in %m: ASYNC_FIFO_ASSERT_FAIL expected=%h got=%h\n",5, 'M',vlSymsp->name(),"asynchronous_fifo_tb.unnamedblk1_4", 'T',-12
                             , '#',64,VL_TIME_UNITED_Q(1)
                             , '#',8,(IData)(vlSelfRef.asynchronous_fifo_tb__DOT__expected_data)
                             , '#',8,vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo
                             [(7U & (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr))]);
                VL_STOP_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 58, "");
            }
        }
        if (VL_UNLIKELY(((vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo
                          [(7U & (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr))] 
                          != (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__expected_data))))) {
            VL_WRITEF_NX("[%0t] %%Error: testbench.sv:60: Assertion failed in %m: Time = %0t: Comparison Failed: expected wr_data = %h, rd_data = %h\n",6, 'M',vlSymsp->name(),"asynchronous_fifo_tb.unnamedblk1_4", 'T',-12
                         , '#',64,VL_TIME_UNITED_Q(1)
                         , '#',64,VL_TIME_UNITED_Q(1)
                         , '#',8,(IData)(vlSelfRef.asynchronous_fifo_tb__DOT__expected_data)
                         , '#',8,vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo
                         [(7U & (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr))]);
            VL_STOP_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 60, "");
        } else {
            VL_WRITEF_NX("Time = %0t: Comparison Passed: wr_data = %h and rd_data = %h\n",4, 'T',-12
                         , '#',64,VL_TIME_UNITED_Q(1)
                         , '#',8,(IData)(vlSelfRef.asynchronous_fifo_tb__DOT__expected_data)
                         , '#',8,vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo
                         [(7U & (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr))]);
        }
        Vasynchronous_fifo_tb___024root____VbeforeTrig_hd0cd284b__0(vlSelf, 
                                                                    "@(posedge asynchronous_fifo_tb.rclock)");
        co_await vlSelfRef.__VtrigSched_hd0cd284b__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge asynchronous_fifo_tb.rclock)", 
                                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 
                                                             65);
        vlSelfRef.asynchronous_fifo_tb__DOT__r_en = 1U;
        Vasynchronous_fifo_tb___024root____VbeforeTrig_hd0cd284b__0(vlSelf, 
                                                                    "@(posedge asynchronous_fifo_tb.rclock)");
        co_await vlSelfRef.__VtrigSched_hd0cd284b__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge asynchronous_fifo_tb.rclock)", 
                                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 
                                                             67);
        vlSelfRef.asynchronous_fifo_tb__DOT__r_en = 0U;
        asynchronous_fifo_tb__DOT__unnamedblk1_4__DOT____Vrepeat3 
            = (asynchronous_fifo_tb__DOT__unnamedblk1_4__DOT____Vrepeat3 
               - (IData)(1U));
    }
    VL_WRITEF_NX("ASYNC_FIFO_SIM_PASS\n",0);
    VL_FINISH_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 72, "");
    if ((1U & (~ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__empty)))) {
        ++(vlSymsp->__Vcoverage[79]);
    }
    if (vlSelfRef.asynchronous_fifo_tb__DOT__empty) {
        ++(vlSymsp->__Vcoverage[80]);
    }
    ++(vlSymsp->__Vcoverage[81]);
    co_return;
}

VlCoroutine Vasynchronous_fifo_tb___024root___eval_initial__TOP__Vtiming__2(Vasynchronous_fifo_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___eval_initial__TOP__Vtiming__2\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    IData/*31:0*/ asynchronous_fifo_tb__DOT__unnamedblk1_5__DOT____Vrepeat4;
    asynchronous_fifo_tb__DOT__unnamedblk1_5__DOT____Vrepeat4 = 0;
    // Body
    asynchronous_fifo_tb__DOT__unnamedblk1_5__DOT____Vrepeat4 = 0x00000078U;
    while (VL_LTS_III(32, 0U, asynchronous_fifo_tb__DOT__unnamedblk1_5__DOT____Vrepeat4)) {
        Vasynchronous_fifo_tb___024root____VbeforeTrig_h0e3b6fae__0(vlSelf, 
                                                                    "@(posedge asynchronous_fifo_tb.wclock)");
        co_await vlSelfRef.__VtrigSched_h0e3b6fae__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge asynchronous_fifo_tb.wclock)", 
                                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 
                                                             76);
        asynchronous_fifo_tb__DOT__unnamedblk1_5__DOT____Vrepeat4 
            = (asynchronous_fifo_tb__DOT__unnamedblk1_5__DOT____Vrepeat4 
               - (IData)(1U));
        ++(vlSymsp->__Vcoverage[82]);
    }
    VL_WRITEF_NX("[%0t] %%Error: testbench.sv:77: Assertion failed in %m: ASYNC FIFO simulation watchdog timeout\n",3, 'M',vlSymsp->name(),"asynchronous_fifo_tb", 'T',-12
                 , '#',64,VL_TIME_UNITED_Q(1));
    VL_STOP_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 77, "");
    VL_FINISH_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 78, "");
    co_return;
}

VlCoroutine Vasynchronous_fifo_tb___024root___eval_initial__TOP__Vtiming__3(Vasynchronous_fifo_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___eval_initial__TOP__Vtiming__3\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    while (VL_LIKELY(!vlSymsp->_vm_contextp__->gotFinish())) {
        co_await vlSelfRef.__VdlySched.delay(0x0000000000000023ULL, 
                                             nullptr, 
                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 
                                             20);
        vlSelfRef.asynchronous_fifo_tb__DOT__rclock 
            = (1U & (~ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__rclock)));
        if ((1U & (~ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__rclock)))) {
            ++(vlSymsp->__Vcoverage[67]);
        }
        if (vlSelfRef.asynchronous_fifo_tb__DOT__rclock) {
            ++(vlSymsp->__Vcoverage[68]);
        }
        ++(vlSymsp->__Vcoverage[69]);
    }
    co_return;
}

VlCoroutine Vasynchronous_fifo_tb___024root___eval_initial__TOP__Vtiming__4(Vasynchronous_fifo_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___eval_initial__TOP__Vtiming__4\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    while (VL_LIKELY(!vlSymsp->_vm_contextp__->gotFinish())) {
        co_await vlSelfRef.__VdlySched.delay(0x000000000000000aULL, 
                                             nullptr, 
                                             "/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 
                                             19);
        vlSelfRef.asynchronous_fifo_tb__DOT__wclock 
            = (1U & (~ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__wclock)));
        if ((1U & (~ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__wclock)))) {
            ++(vlSymsp->__Vcoverage[64]);
        }
        if (vlSelfRef.asynchronous_fifo_tb__DOT__wclock) {
            ++(vlSymsp->__Vcoverage[65]);
        }
        ++(vlSymsp->__Vcoverage[66]);
    }
    co_return;
}

void Vasynchronous_fifo_tb___024root___eval_triggers_vec__act(Vasynchronous_fifo_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___eval_triggers_vec__act\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ __Vtrigprevexpr_h6bda5152__0;
    __Vtrigprevexpr_h6bda5152__0 = 0;
    // Body
    __Vtrigprevexpr_h6bda5152__0 = (1U & (~ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__empty)));
    vlSelfRef.__VactTriggered[0U] = (QData)((IData)(
                                                    (((vlSelfRef.__VdlySched.awaitingCurrentTime() 
                                                       << 5U) 
                                                      | (((IData)(__Vtrigprevexpr_h6bda5152__0) 
                                                          != (IData)(vlSelfRef.__Vtrigprevexpr_h6bda5152__1)) 
                                                         << 4U)) 
                                                     | (((((~ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__wreset)) 
                                                           & (IData)(vlSelfRef.__Vtrigprevexpr___TOP__asynchronous_fifo_tb__DOT__wreset__0)) 
                                                          << 3U) 
                                                         | (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__wclock) 
                                                             & (~ (IData)(vlSelfRef.__Vtrigprevexpr___TOP__asynchronous_fifo_tb__DOT__wclock__0))) 
                                                            << 2U)) 
                                                        | ((((~ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__rreset)) 
                                                             & (IData)(vlSelfRef.__Vtrigprevexpr___TOP__asynchronous_fifo_tb__DOT__rreset__0)) 
                                                            << 1U) 
                                                           | ((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__rclock) 
                                                              & (~ (IData)(vlSelfRef.__Vtrigprevexpr___TOP__asynchronous_fifo_tb__DOT__rclock__0))))))));
    vlSelfRef.__Vtrigprevexpr___TOP__asynchronous_fifo_tb__DOT__rclock__0 
        = vlSelfRef.asynchronous_fifo_tb__DOT__rclock;
    vlSelfRef.__Vtrigprevexpr___TOP__asynchronous_fifo_tb__DOT__rreset__0 
        = vlSelfRef.asynchronous_fifo_tb__DOT__rreset;
    vlSelfRef.__Vtrigprevexpr___TOP__asynchronous_fifo_tb__DOT__wclock__0 
        = vlSelfRef.asynchronous_fifo_tb__DOT__wclock;
    vlSelfRef.__Vtrigprevexpr___TOP__asynchronous_fifo_tb__DOT__wreset__0 
        = vlSelfRef.asynchronous_fifo_tb__DOT__wreset;
    vlSelfRef.__Vtrigprevexpr_h6bda5152__1 = __Vtrigprevexpr_h6bda5152__0;
}

bool Vasynchronous_fifo_tb___024root___trigger_anySet__act(const VlUnpacked<QData/*63:0*/, 1> &in) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___trigger_anySet__act\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        if (in[n]) {
            return (1U);
        }
        n = ((IData)(1U) + n);
    } while ((1U > n));
    return (0U);
}

void Vasynchronous_fifo_tb___024root___act_sequent__TOP__0(Vasynchronous_fifo_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___act_sequent__TOP__0\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__data_in) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__data_in))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 20, vlSelfRef.asynchronous_fifo_tb__DOT__data_in, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__data_in);
        vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__data_in 
            = vlSelfRef.asynchronous_fifo_tb__DOT__data_in;
    }
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__w_en) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__w_en))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 36, vlSelfRef.asynchronous_fifo_tb__DOT__w_en, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__w_en);
        vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__w_en 
            = vlSelfRef.asynchronous_fifo_tb__DOT__w_en;
    }
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__wreset) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__wreset))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 40, vlSelfRef.asynchronous_fifo_tb__DOT__wreset, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__wreset);
        vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__wreset 
            = vlSelfRef.asynchronous_fifo_tb__DOT__wreset;
    }
    vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__bin_wptr_next 
        = (0x0000000fU & ((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_wptr) 
                          + ((~ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__full)) 
                             & (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__w_en))));
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__bin_wptr_next) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__bin_wptr_next))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 158, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__bin_wptr_next, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__bin_wptr_next);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__bin_wptr_next 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__bin_wptr_next;
    }
    vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__gray_wptr_next 
        = ((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__bin_wptr_next) 
           ^ VL_SHIFTR_III(4,4,32, (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__bin_wptr_next), 1U));
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__gray_wptr_next) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__gray_wptr_next))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 166, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__gray_wptr_next, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__gray_wptr_next);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__gray_wptr_next 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__gray_wptr_next;
    }
    vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__wfull 
        = (((0x0000000cU & ((~ ((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr_sync) 
                                >> 2U)) << 2U)) | (3U 
                                                   & (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr_sync))) 
           == (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__gray_wptr_next));
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__wfull) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__wfull))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 174, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__wfull, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__wfull);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__wfull 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__wfull;
    }
}

void Vasynchronous_fifo_tb___024root___act_comb__TOP__0(Vasynchronous_fifo_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___act_comb__TOP__0\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__wclock) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__wclock))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 38, vlSelfRef.asynchronous_fifo_tb__DOT__wclock, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__wclock);
        vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__wclock 
            = vlSelfRef.asynchronous_fifo_tb__DOT__wclock;
    }
}

void Vasynchronous_fifo_tb___024root___act_comb__TOP__1(Vasynchronous_fifo_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___act_comb__TOP__1\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__r_en) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__r_en))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 42, vlSelfRef.asynchronous_fifo_tb__DOT__r_en, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__r_en);
        vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__r_en 
            = vlSelfRef.asynchronous_fifo_tb__DOT__r_en;
    }
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__rclock) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__rclock))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 44, vlSelfRef.asynchronous_fifo_tb__DOT__rclock, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__rclock);
        vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__rclock 
            = vlSelfRef.asynchronous_fifo_tb__DOT__rclock;
    }
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__rreset) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__rreset))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 46, vlSelfRef.asynchronous_fifo_tb__DOT__rreset, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__rreset);
        vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__rreset 
            = vlSelfRef.asynchronous_fifo_tb__DOT__rreset;
    }
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__expected_data) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__expected_data))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 48, vlSelfRef.asynchronous_fifo_tb__DOT__expected_data, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__expected_data);
        vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__expected_data 
            = vlSelfRef.asynchronous_fifo_tb__DOT__expected_data;
    }
    vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__bin_rptr_next 
        = (0x0000000fU & ((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr) 
                          + ((~ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__empty)) 
                             & (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__r_en))));
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__bin_rptr_next) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__bin_rptr_next))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 186, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__bin_rptr_next, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__bin_rptr_next);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__bin_rptr_next 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__bin_rptr_next;
    }
    vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__gray_rptr_next 
        = ((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__bin_rptr_next) 
           ^ VL_SHIFTR_III(4,4,32, (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__bin_rptr_next), 1U));
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__gray_rptr_next) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__gray_rptr_next))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 194, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__gray_rptr_next, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__gray_rptr_next);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__gray_rptr_next 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__gray_rptr_next;
    }
    vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__rempty 
        = ((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_wptr_sync) 
           == (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__gray_rptr_next));
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__rempty) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__rempty))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 202, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__rempty, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__rempty);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__rempty 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__rempty;
    }
}

void Vasynchronous_fifo_tb___024root___eval_act(Vasynchronous_fifo_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___eval_act\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((4ULL & vlSelfRef.__VactTriggered[0U])) {
        if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__data_in) 
             ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__data_in))) {
            VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 20, vlSelfRef.asynchronous_fifo_tb__DOT__data_in, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__data_in);
            vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__data_in 
                = vlSelfRef.asynchronous_fifo_tb__DOT__data_in;
        }
        if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__w_en) 
             ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__w_en))) {
            VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 36, vlSelfRef.asynchronous_fifo_tb__DOT__w_en, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__w_en);
            vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__w_en 
                = vlSelfRef.asynchronous_fifo_tb__DOT__w_en;
        }
        if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__wreset) 
             ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__wreset))) {
            VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 40, vlSelfRef.asynchronous_fifo_tb__DOT__wreset, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__wreset);
            vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__wreset 
                = vlSelfRef.asynchronous_fifo_tb__DOT__wreset;
        }
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__bin_wptr_next 
            = (0x0000000fU & ((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_wptr) 
                              + ((~ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__full)) 
                                 & (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__w_en))));
        if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__bin_wptr_next) 
             ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__bin_wptr_next))) {
            VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 158, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__bin_wptr_next, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__bin_wptr_next);
            vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__bin_wptr_next 
                = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__bin_wptr_next;
        }
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__gray_wptr_next 
            = ((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__bin_wptr_next) 
               ^ VL_SHIFTR_III(4,4,32, (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__bin_wptr_next), 1U));
        if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__gray_wptr_next) 
             ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__gray_wptr_next))) {
            VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 166, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__gray_wptr_next, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__gray_wptr_next);
            vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__gray_wptr_next 
                = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__gray_wptr_next;
        }
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__wfull 
            = (((0x0000000cU & ((~ ((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr_sync) 
                                    >> 2U)) << 2U)) 
                | (3U & (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr_sync))) 
               == (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__gray_wptr_next));
        if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__wfull) 
             ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__wfull))) {
            VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 174, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__wfull, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__wfull);
            vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__wfull 
                = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__wfull;
        }
    }
    if ((0x0000000000000024ULL & vlSelfRef.__VactTriggered[0U])) {
        if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__wclock) 
             ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__wclock))) {
            VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 38, vlSelfRef.asynchronous_fifo_tb__DOT__wclock, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__wclock);
            vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__wclock 
                = vlSelfRef.asynchronous_fifo_tb__DOT__wclock;
        }
    }
    if ((0x0000000000000031ULL & vlSelfRef.__VactTriggered[0U])) {
        if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__r_en) 
             ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__r_en))) {
            VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 42, vlSelfRef.asynchronous_fifo_tb__DOT__r_en, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__r_en);
            vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__r_en 
                = vlSelfRef.asynchronous_fifo_tb__DOT__r_en;
        }
        if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__rclock) 
             ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__rclock))) {
            VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 44, vlSelfRef.asynchronous_fifo_tb__DOT__rclock, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__rclock);
            vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__rclock 
                = vlSelfRef.asynchronous_fifo_tb__DOT__rclock;
        }
        if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__rreset) 
             ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__rreset))) {
            VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 46, vlSelfRef.asynchronous_fifo_tb__DOT__rreset, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__rreset);
            vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__rreset 
                = vlSelfRef.asynchronous_fifo_tb__DOT__rreset;
        }
        if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__expected_data) 
             ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__expected_data))) {
            VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 48, vlSelfRef.asynchronous_fifo_tb__DOT__expected_data, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__expected_data);
            vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__expected_data 
                = vlSelfRef.asynchronous_fifo_tb__DOT__expected_data;
        }
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__bin_rptr_next 
            = (0x0000000fU & ((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr) 
                              + ((~ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__empty)) 
                                 & (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__r_en))));
        if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__bin_rptr_next) 
             ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__bin_rptr_next))) {
            VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 186, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__bin_rptr_next, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__bin_rptr_next);
            vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__bin_rptr_next 
                = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__bin_rptr_next;
        }
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__gray_rptr_next 
            = ((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__bin_rptr_next) 
               ^ VL_SHIFTR_III(4,4,32, (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__bin_rptr_next), 1U));
        if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__gray_rptr_next) 
             ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__gray_rptr_next))) {
            VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 194, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__gray_rptr_next, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__gray_rptr_next);
            vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__gray_rptr_next 
                = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__gray_rptr_next;
        }
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__rempty 
            = ((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_wptr_sync) 
               == (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__gray_rptr_next));
        if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__rempty) 
             ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__rempty))) {
            VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 202, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__rempty, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__rempty);
            vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__rempty 
                = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__rempty;
        }
    }
}

void Vasynchronous_fifo_tb___024root___nba_sequent__TOP__0(Vasynchronous_fifo_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___nba_sequent__TOP__0\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.asynchronous_fifo_tb__DOT__rreset) {
        ++(vlSymsp->__Vcoverage[210]);
        vlSelfRef.asynchronous_fifo_tb__DOT__empty 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__rempty;
    } else {
        ++(vlSymsp->__Vcoverage[209]);
        vlSelfRef.asynchronous_fifo_tb__DOT__empty = 1U;
    }
    if ((1U & (~ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__rreset)))) {
        ++(vlSymsp->__Vcoverage[211]);
    }
    if (vlSelfRef.asynchronous_fifo_tb__DOT__rreset) {
        ++(vlSymsp->__Vcoverage[212]);
    }
    ++(vlSymsp->__Vcoverage[213]);
    if (vlSelfRef.asynchronous_fifo_tb__DOT__rreset) {
        ++(vlSymsp->__Vcoverage[141]);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_wptr_sync 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_wptr__DOT__q1;
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_wptr__DOT__q1 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_wptr;
    } else {
        ++(vlSymsp->__Vcoverage[140]);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_wptr__DOT__q1 = 0U;
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_wptr_sync = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__rreset)))) {
        ++(vlSymsp->__Vcoverage[142]);
    }
    if (vlSelfRef.asynchronous_fifo_tb__DOT__rreset) {
        ++(vlSymsp->__Vcoverage[143]);
    }
    ++(vlSymsp->__Vcoverage[144]);
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__empty) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__empty))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 18, vlSelfRef.asynchronous_fifo_tb__DOT__empty, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__empty);
        vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__empty 
            = vlSelfRef.asynchronous_fifo_tb__DOT__empty;
    }
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_wptr__DOT__q1) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_wptr__DOT____Vtogcov__q1))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 132, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_wptr__DOT__q1, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_wptr__DOT____Vtogcov__q1);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_wptr__DOT____Vtogcov__q1 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_wptr__DOT__q1;
    }
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_wptr_sync) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_wptr_sync))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 84, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_wptr_sync, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_wptr_sync);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_wptr_sync 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_wptr_sync;
    }
}

void Vasynchronous_fifo_tb___024root___nba_sequent__TOP__1(Vasynchronous_fifo_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___nba_sequent__TOP__1\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.asynchronous_fifo_tb__DOT__wreset) {
        ++(vlSymsp->__Vcoverage[154]);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr_sync 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_rptr__DOT__q1;
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_rptr__DOT__q1 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr;
    } else {
        ++(vlSymsp->__Vcoverage[153]);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_rptr__DOT__q1 = 0U;
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr_sync = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__wreset)))) {
        ++(vlSymsp->__Vcoverage[155]);
    }
    if (vlSelfRef.asynchronous_fifo_tb__DOT__wreset) {
        ++(vlSymsp->__Vcoverage[156]);
    }
    ++(vlSymsp->__Vcoverage[157]);
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_rptr__DOT__q1) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_rptr__DOT____Vtogcov__q1))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 145, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_rptr__DOT__q1, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_rptr__DOT____Vtogcov__q1);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_rptr__DOT____Vtogcov__q1 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_rptr__DOT__q1;
    }
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr_sync) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_rptr_sync))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 92, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr_sync, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_rptr_sync);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_rptr_sync 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr_sync;
    }
}

void Vasynchronous_fifo_tb___024root___nba_sequent__TOP__2(Vasynchronous_fifo_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___nba_sequent__TOP__2\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*7:0*/ __VdlyVal__asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo__v0;
    __VdlyVal__asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo__v0 = 0;
    CData/*2:0*/ __VdlyDim0__asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo__v0;
    __VdlyDim0__asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo__v0 = 0;
    CData/*0:0*/ __VdlySet__asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo__v0;
    __VdlySet__asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo__v0 = 0;
    // Body
    __VdlySet__asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo__v0 = 0U;
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__data_in) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__data_in))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 20, vlSelfRef.asynchronous_fifo_tb__DOT__data_in, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__data_in);
        vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__data_in 
            = vlSelfRef.asynchronous_fifo_tb__DOT__data_in;
    }
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__w_en) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__w_en))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 36, vlSelfRef.asynchronous_fifo_tb__DOT__w_en, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__w_en);
        vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__w_en 
            = vlSelfRef.asynchronous_fifo_tb__DOT__w_en;
    }
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__wreset) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__wreset))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 40, vlSelfRef.asynchronous_fifo_tb__DOT__wreset, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__wreset);
        vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__wreset 
            = vlSelfRef.asynchronous_fifo_tb__DOT__wreset;
    }
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__w_en) 
         & (~ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__full)))) {
        ++(vlSymsp->__Vcoverage[354]);
        __VdlyVal__asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo__v0 
            = vlSelfRef.asynchronous_fifo_tb__DOT__data_in;
        __VdlyDim0__asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo__v0 
            = (7U & (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_wptr));
        __VdlySet__asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo__v0 = 1U;
    } else {
        ++(vlSymsp->__Vcoverage[355]);
    }
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__w_en) 
         & (~ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__full)))) {
        ++(vlSymsp->__Vcoverage[356]);
    }
    if (vlSelfRef.asynchronous_fifo_tb__DOT__full) {
        ++(vlSymsp->__Vcoverage[357]);
    }
    if ((1U & (~ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__w_en)))) {
        ++(vlSymsp->__Vcoverage[358]);
    }
    ++(vlSymsp->__Vcoverage[359]);
    if (__VdlySet__asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo__v0) {
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[__VdlyDim0__asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo__v0] 
            = __VdlyVal__asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo__v0;
    }
    if ((vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[0U] 
         ^ vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[0U])) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 226, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[0U], vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[0U]);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[0U] 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[0U];
    }
    if ((vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[1U] 
         ^ vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[1U])) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 242, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[1U], vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[1U]);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[1U] 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[1U];
    }
    if ((vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[2U] 
         ^ vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[2U])) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 258, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[2U], vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[2U]);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[2U] 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[2U];
    }
    if ((vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[3U] 
         ^ vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[3U])) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 274, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[3U], vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[3U]);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[3U] 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[3U];
    }
    if ((vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[4U] 
         ^ vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[4U])) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 290, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[4U], vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[4U]);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[4U] 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[4U];
    }
    if ((vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[5U] 
         ^ vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[5U])) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 306, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[5U], vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[5U]);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[5U] 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[5U];
    }
    if ((vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[6U] 
         ^ vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[6U])) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 322, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[6U], vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[6U]);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[6U] 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[6U];
    }
    if ((vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[7U] 
         ^ vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[7U])) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 338, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[7U], vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[7U]);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__fifo[7U] 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo[7U];
    }
}

void Vasynchronous_fifo_tb___024root___nba_comb__TOP__1(Vasynchronous_fifo_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___nba_comb__TOP__1\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__r_en) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__r_en))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 42, vlSelfRef.asynchronous_fifo_tb__DOT__r_en, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__r_en);
        vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__r_en 
            = vlSelfRef.asynchronous_fifo_tb__DOT__r_en;
    }
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__rclock) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__rclock))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 44, vlSelfRef.asynchronous_fifo_tb__DOT__rclock, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__rclock);
        vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__rclock 
            = vlSelfRef.asynchronous_fifo_tb__DOT__rclock;
    }
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__rreset) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__rreset))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 46, vlSelfRef.asynchronous_fifo_tb__DOT__rreset, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__rreset);
        vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__rreset 
            = vlSelfRef.asynchronous_fifo_tb__DOT__rreset;
    }
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__expected_data) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__expected_data))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 48, vlSelfRef.asynchronous_fifo_tb__DOT__expected_data, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__expected_data);
        vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__expected_data 
            = vlSelfRef.asynchronous_fifo_tb__DOT__expected_data;
    }
}

void Vasynchronous_fifo_tb___024root___nba_sequent__TOP__3(Vasynchronous_fifo_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___nba_sequent__TOP__3\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.asynchronous_fifo_tb__DOT__rreset) {
        ++(vlSymsp->__Vcoverage[205]);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__bin_rptr_next;
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__gray_rptr_next;
    } else {
        ++(vlSymsp->__Vcoverage[204]);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr = 0U;
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__rreset)))) {
        ++(vlSymsp->__Vcoverage[206]);
    }
    if (vlSelfRef.asynchronous_fifo_tb__DOT__rreset) {
        ++(vlSymsp->__Vcoverage[207]);
    }
    ++(vlSymsp->__Vcoverage[208]);
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_rptr))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 124, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_rptr);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_rptr 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr;
    }
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__bin_rptr))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 108, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__bin_rptr);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__bin_rptr 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr;
    }
    if ((7U & ((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr) 
               ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__bin_rptr)))) {
        VL_COV_TOGGLE_CHG_ST_I(3, vlSymsp->__Vcoverage + 220, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__bin_rptr);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__bin_rptr 
            = (7U & (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr));
    }
}

void Vasynchronous_fifo_tb___024root___nba_sequent__TOP__4(Vasynchronous_fifo_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___nba_sequent__TOP__4\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.asynchronous_fifo_tb__DOT__wreset) {
        ++(vlSymsp->__Vcoverage[182]);
        vlSelfRef.asynchronous_fifo_tb__DOT__full = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__wfull;
    } else {
        ++(vlSymsp->__Vcoverage[181]);
        vlSelfRef.asynchronous_fifo_tb__DOT__full = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__wreset)))) {
        ++(vlSymsp->__Vcoverage[183]);
    }
    if (vlSelfRef.asynchronous_fifo_tb__DOT__wreset) {
        ++(vlSymsp->__Vcoverage[184]);
    }
    ++(vlSymsp->__Vcoverage[185]);
    if (vlSelfRef.asynchronous_fifo_tb__DOT__wreset) {
        ++(vlSymsp->__Vcoverage[177]);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_wptr 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__bin_wptr_next;
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_wptr 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__gray_wptr_next;
    } else {
        ++(vlSymsp->__Vcoverage[176]);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_wptr = 0U;
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_wptr = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__wreset)))) {
        ++(vlSymsp->__Vcoverage[178]);
    }
    if (vlSelfRef.asynchronous_fifo_tb__DOT__wreset) {
        ++(vlSymsp->__Vcoverage[179]);
    }
    ++(vlSymsp->__Vcoverage[180]);
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__full) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__full))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 16, vlSelfRef.asynchronous_fifo_tb__DOT__full, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__full);
        vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__full 
            = vlSelfRef.asynchronous_fifo_tb__DOT__full;
    }
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_wptr) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_wptr))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 116, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_wptr, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_wptr);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_wptr 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_wptr;
    }
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_wptr) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__bin_wptr))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 100, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_wptr, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__bin_wptr);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__bin_wptr 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_wptr;
    }
    if ((7U & ((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_wptr) 
               ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__bin_wptr)))) {
        VL_COV_TOGGLE_CHG_ST_I(3, vlSymsp->__Vcoverage + 214, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_wptr, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__bin_wptr);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__bin_wptr 
            = (7U & (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_wptr));
    }
}

void Vasynchronous_fifo_tb___024root___nba_comb__TOP__2(Vasynchronous_fifo_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___nba_comb__TOP__2\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo
         [(7U & (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr))] 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__data_out))) {
        VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 0, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo
                               [(7U & (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr))], vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__data_out);
        vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__data_out 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo
            [(7U & (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr))];
    }
}

void Vasynchronous_fifo_tb___024root___nba_comb__TOP__3(Vasynchronous_fifo_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___nba_comb__TOP__3\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__bin_rptr_next 
        = (0x0000000fU & ((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr) 
                          + ((~ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__empty)) 
                             & (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__r_en))));
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__bin_rptr_next) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__bin_rptr_next))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 186, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__bin_rptr_next, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__bin_rptr_next);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__bin_rptr_next 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__bin_rptr_next;
    }
    vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__gray_rptr_next 
        = ((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__bin_rptr_next) 
           ^ VL_SHIFTR_III(4,4,32, (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__bin_rptr_next), 1U));
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__gray_rptr_next) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__gray_rptr_next))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 194, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__gray_rptr_next, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__gray_rptr_next);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__gray_rptr_next 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__gray_rptr_next;
    }
    vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__rempty 
        = ((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_wptr_sync) 
           == (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__gray_rptr_next));
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__rempty) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__rempty))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 202, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__rempty, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__rempty);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__rempty 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__rempty;
    }
}

void Vasynchronous_fifo_tb___024root___nba_comb__TOP__4(Vasynchronous_fifo_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___nba_comb__TOP__4\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__bin_wptr_next 
        = (0x0000000fU & ((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_wptr) 
                          + ((~ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__full)) 
                             & (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__w_en))));
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__bin_wptr_next) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__bin_wptr_next))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 158, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__bin_wptr_next, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__bin_wptr_next);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__bin_wptr_next 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__bin_wptr_next;
    }
    vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__gray_wptr_next 
        = ((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__bin_wptr_next) 
           ^ VL_SHIFTR_III(4,4,32, (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__bin_wptr_next), 1U));
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__gray_wptr_next) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__gray_wptr_next))) {
        VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 166, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__gray_wptr_next, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__gray_wptr_next);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__gray_wptr_next 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__gray_wptr_next;
    }
    vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__wfull 
        = (((0x0000000cU & ((~ ((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr_sync) 
                                >> 2U)) << 2U)) | (3U 
                                                   & (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr_sync))) 
           == (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__gray_wptr_next));
    if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__wfull) 
         ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__wfull))) {
        VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 174, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__wfull, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__wfull);
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__wfull 
            = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__wfull;
    }
}

void Vasynchronous_fifo_tb___024root___eval_nba(Vasynchronous_fifo_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___eval_nba\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((3ULL & vlSelfRef.__VnbaTriggered[0U])) {
        if (vlSelfRef.asynchronous_fifo_tb__DOT__rreset) {
            ++(vlSymsp->__Vcoverage[210]);
            vlSelfRef.asynchronous_fifo_tb__DOT__empty 
                = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__rempty;
        } else {
            ++(vlSymsp->__Vcoverage[209]);
            vlSelfRef.asynchronous_fifo_tb__DOT__empty = 1U;
        }
        if ((1U & (~ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__rreset)))) {
            ++(vlSymsp->__Vcoverage[211]);
        }
        if (vlSelfRef.asynchronous_fifo_tb__DOT__rreset) {
            ++(vlSymsp->__Vcoverage[212]);
        }
        ++(vlSymsp->__Vcoverage[213]);
        if (vlSelfRef.asynchronous_fifo_tb__DOT__rreset) {
            ++(vlSymsp->__Vcoverage[141]);
            vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_wptr_sync 
                = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_wptr__DOT__q1;
            vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_wptr__DOT__q1 
                = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_wptr;
        } else {
            ++(vlSymsp->__Vcoverage[140]);
            vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_wptr__DOT__q1 = 0U;
            vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_wptr_sync = 0U;
        }
        if ((1U & (~ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__rreset)))) {
            ++(vlSymsp->__Vcoverage[142]);
        }
        if (vlSelfRef.asynchronous_fifo_tb__DOT__rreset) {
            ++(vlSymsp->__Vcoverage[143]);
        }
        ++(vlSymsp->__Vcoverage[144]);
        if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__empty) 
             ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__empty))) {
            VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 18, vlSelfRef.asynchronous_fifo_tb__DOT__empty, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__empty);
            vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__empty 
                = vlSelfRef.asynchronous_fifo_tb__DOT__empty;
        }
        if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_wptr__DOT__q1) 
             ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_wptr__DOT____Vtogcov__q1))) {
            VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 132, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_wptr__DOT__q1, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_wptr__DOT____Vtogcov__q1);
            vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_wptr__DOT____Vtogcov__q1 
                = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_wptr__DOT__q1;
        }
        if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_wptr_sync) 
             ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_wptr_sync))) {
            VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 84, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_wptr_sync, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_wptr_sync);
            vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_wptr_sync 
                = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_wptr_sync;
        }
    }
    if ((0x000000000000000cULL & vlSelfRef.__VnbaTriggered[0U])) {
        if (vlSelfRef.asynchronous_fifo_tb__DOT__wreset) {
            ++(vlSymsp->__Vcoverage[154]);
            vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr_sync 
                = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_rptr__DOT__q1;
            vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_rptr__DOT__q1 
                = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr;
        } else {
            ++(vlSymsp->__Vcoverage[153]);
            vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_rptr__DOT__q1 = 0U;
            vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr_sync = 0U;
        }
        if ((1U & (~ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__wreset)))) {
            ++(vlSymsp->__Vcoverage[155]);
        }
        if (vlSelfRef.asynchronous_fifo_tb__DOT__wreset) {
            ++(vlSymsp->__Vcoverage[156]);
        }
        ++(vlSymsp->__Vcoverage[157]);
        if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_rptr__DOT__q1) 
             ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_rptr__DOT____Vtogcov__q1))) {
            VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 145, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_rptr__DOT__q1, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_rptr__DOT____Vtogcov__q1);
            vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_rptr__DOT____Vtogcov__q1 
                = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__sync_rptr__DOT__q1;
        }
        if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr_sync) 
             ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_rptr_sync))) {
            VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 92, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr_sync, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_rptr_sync);
            vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_rptr_sync 
                = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr_sync;
        }
    }
    if ((4ULL & vlSelfRef.__VnbaTriggered[0U])) {
        Vasynchronous_fifo_tb___024root___nba_sequent__TOP__2(vlSelf);
    }
    if ((0x0000000000000024ULL & vlSelfRef.__VnbaTriggered[0U])) {
        if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__wclock) 
             ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__wclock))) {
            VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 38, vlSelfRef.asynchronous_fifo_tb__DOT__wclock, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__wclock);
            vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__wclock 
                = vlSelfRef.asynchronous_fifo_tb__DOT__wclock;
        }
    }
    if ((0x0000000000000031ULL & vlSelfRef.__VnbaTriggered[0U])) {
        if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__r_en) 
             ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__r_en))) {
            VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 42, vlSelfRef.asynchronous_fifo_tb__DOT__r_en, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__r_en);
            vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__r_en 
                = vlSelfRef.asynchronous_fifo_tb__DOT__r_en;
        }
        if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__rclock) 
             ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__rclock))) {
            VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 44, vlSelfRef.asynchronous_fifo_tb__DOT__rclock, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__rclock);
            vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__rclock 
                = vlSelfRef.asynchronous_fifo_tb__DOT__rclock;
        }
        if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__rreset) 
             ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__rreset))) {
            VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 46, vlSelfRef.asynchronous_fifo_tb__DOT__rreset, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__rreset);
            vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__rreset 
                = vlSelfRef.asynchronous_fifo_tb__DOT__rreset;
        }
        if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__expected_data) 
             ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__expected_data))) {
            VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 48, vlSelfRef.asynchronous_fifo_tb__DOT__expected_data, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__expected_data);
            vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__expected_data 
                = vlSelfRef.asynchronous_fifo_tb__DOT__expected_data;
        }
    }
    if ((3ULL & vlSelfRef.__VnbaTriggered[0U])) {
        if (vlSelfRef.asynchronous_fifo_tb__DOT__rreset) {
            ++(vlSymsp->__Vcoverage[205]);
            vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr 
                = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__bin_rptr_next;
            vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr 
                = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__gray_rptr_next;
        } else {
            ++(vlSymsp->__Vcoverage[204]);
            vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr = 0U;
            vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr = 0U;
        }
        if ((1U & (~ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__rreset)))) {
            ++(vlSymsp->__Vcoverage[206]);
        }
        if (vlSelfRef.asynchronous_fifo_tb__DOT__rreset) {
            ++(vlSymsp->__Vcoverage[207]);
        }
        ++(vlSymsp->__Vcoverage[208]);
        if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr) 
             ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_rptr))) {
            VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 124, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_rptr);
            vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_rptr 
                = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr;
        }
        if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr) 
             ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__bin_rptr))) {
            VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 108, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__bin_rptr);
            vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__bin_rptr 
                = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr;
        }
        if ((7U & ((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr) 
                   ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__bin_rptr)))) {
            VL_COV_TOGGLE_CHG_ST_I(3, vlSymsp->__Vcoverage + 220, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__bin_rptr);
            vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__bin_rptr 
                = (7U & (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr));
        }
    }
    if ((0x000000000000000cULL & vlSelfRef.__VnbaTriggered[0U])) {
        if (vlSelfRef.asynchronous_fifo_tb__DOT__wreset) {
            ++(vlSymsp->__Vcoverage[182]);
            vlSelfRef.asynchronous_fifo_tb__DOT__full 
                = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__wfull;
        } else {
            ++(vlSymsp->__Vcoverage[181]);
            vlSelfRef.asynchronous_fifo_tb__DOT__full = 0U;
        }
        if ((1U & (~ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__wreset)))) {
            ++(vlSymsp->__Vcoverage[183]);
        }
        if (vlSelfRef.asynchronous_fifo_tb__DOT__wreset) {
            ++(vlSymsp->__Vcoverage[184]);
        }
        ++(vlSymsp->__Vcoverage[185]);
        if (vlSelfRef.asynchronous_fifo_tb__DOT__wreset) {
            ++(vlSymsp->__Vcoverage[177]);
            vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_wptr 
                = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__bin_wptr_next;
            vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_wptr 
                = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__gray_wptr_next;
        } else {
            ++(vlSymsp->__Vcoverage[176]);
            vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_wptr = 0U;
            vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_wptr = 0U;
        }
        if ((1U & (~ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__wreset)))) {
            ++(vlSymsp->__Vcoverage[178]);
        }
        if (vlSelfRef.asynchronous_fifo_tb__DOT__wreset) {
            ++(vlSymsp->__Vcoverage[179]);
        }
        ++(vlSymsp->__Vcoverage[180]);
        if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__full) 
             ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__full))) {
            VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 16, vlSelfRef.asynchronous_fifo_tb__DOT__full, vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__full);
            vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__full 
                = vlSelfRef.asynchronous_fifo_tb__DOT__full;
        }
        if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_wptr) 
             ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_wptr))) {
            VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 116, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_wptr, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_wptr);
            vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__gray_wptr 
                = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_wptr;
        }
        if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_wptr) 
             ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__bin_wptr))) {
            VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 100, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_wptr, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__bin_wptr);
            vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT____Vtogcov__bin_wptr 
                = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_wptr;
        }
        if ((7U & ((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_wptr) 
                   ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__bin_wptr)))) {
            VL_COV_TOGGLE_CHG_ST_I(3, vlSymsp->__Vcoverage + 214, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_wptr, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__bin_wptr);
            vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT____Vtogcov__bin_wptr 
                = (7U & (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_wptr));
        }
    }
    if ((7ULL & vlSelfRef.__VnbaTriggered[0U])) {
        if ((vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo
             [(7U & (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr))] 
             ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__data_out))) {
            VL_COV_TOGGLE_CHG_ST_I(8, vlSymsp->__Vcoverage + 0, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo
                                   [(7U & (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr))], vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__data_out);
            vlSelfRef.asynchronous_fifo_tb__DOT____Vtogcov__data_out 
                = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__fifom__DOT__fifo
                [(7U & (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr))];
        }
    }
    if ((0x0000000000000033ULL & vlSelfRef.__VnbaTriggered[0U])) {
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__bin_rptr_next 
            = (0x0000000fU & ((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_rptr) 
                              + ((~ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__empty)) 
                                 & (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__r_en))));
        if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__bin_rptr_next) 
             ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__bin_rptr_next))) {
            VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 186, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__bin_rptr_next, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__bin_rptr_next);
            vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__bin_rptr_next 
                = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__bin_rptr_next;
        }
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__gray_rptr_next 
            = ((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__bin_rptr_next) 
               ^ VL_SHIFTR_III(4,4,32, (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__bin_rptr_next), 1U));
        if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__gray_rptr_next) 
             ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__gray_rptr_next))) {
            VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 194, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__gray_rptr_next, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__gray_rptr_next);
            vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__gray_rptr_next 
                = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__gray_rptr_next;
        }
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__rempty 
            = ((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_wptr_sync) 
               == (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__gray_rptr_next));
        if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__rempty) 
             ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__rempty))) {
            VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 202, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__rempty, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__rempty);
            vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT____Vtogcov__rempty 
                = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__rptr_h__DOT__rempty;
        }
    }
    if ((0x000000000000000cULL & vlSelfRef.__VnbaTriggered[0U])) {
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__bin_wptr_next 
            = (0x0000000fU & ((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__bin_wptr) 
                              + ((~ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__full)) 
                                 & (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__w_en))));
        if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__bin_wptr_next) 
             ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__bin_wptr_next))) {
            VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 158, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__bin_wptr_next, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__bin_wptr_next);
            vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__bin_wptr_next 
                = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__bin_wptr_next;
        }
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__gray_wptr_next 
            = ((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__bin_wptr_next) 
               ^ VL_SHIFTR_III(4,4,32, (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__bin_wptr_next), 1U));
        if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__gray_wptr_next) 
             ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__gray_wptr_next))) {
            VL_COV_TOGGLE_CHG_ST_I(4, vlSymsp->__Vcoverage + 166, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__gray_wptr_next, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__gray_wptr_next);
            vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__gray_wptr_next 
                = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__gray_wptr_next;
        }
        vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__wfull 
            = (((0x0000000cU & ((~ ((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr_sync) 
                                    >> 2U)) << 2U)) 
                | (3U & (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__gray_rptr_sync))) 
               == (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__gray_wptr_next));
        if (((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__wfull) 
             ^ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__wfull))) {
            VL_COV_TOGGLE_CHG_ST_I(1, vlSymsp->__Vcoverage + 174, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__wfull, vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__wfull);
            vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT____Vtogcov__wfull 
                = vlSelfRef.asynchronous_fifo_tb__DOT__as_fifo__DOT__wptr_h__DOT__wfull;
        }
    }
}

void Vasynchronous_fifo_tb___024root___timing_ready(Vasynchronous_fifo_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___timing_ready\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((4ULL & vlSelfRef.__VactTriggered[0U])) {
        vlSelfRef.__VtrigSched_h0e3b6fae__0.ready("@(posedge asynchronous_fifo_tb.wclock)");
    }
    if ((1ULL & vlSelfRef.__VactTriggered[0U])) {
        vlSelfRef.__VtrigSched_hd0cd284b__0.ready("@(posedge asynchronous_fifo_tb.rclock)");
    }
    if ((0x0000000000000010ULL & vlSelfRef.__VactTriggered[0U])) {
        vlSelfRef.__VtrigSched_hfbed39bb__0.ready("@( (~ asynchronous_fifo_tb.empty))");
    }
}

void Vasynchronous_fifo_tb___024root___timing_resume(Vasynchronous_fifo_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___timing_resume\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__VtrigSched_h0e3b6fae__0.moveToResumeQueue(
                                                          "@(posedge asynchronous_fifo_tb.wclock)");
    vlSelfRef.__VtrigSched_hd0cd284b__0.moveToResumeQueue(
                                                          "@(posedge asynchronous_fifo_tb.rclock)");
    vlSelfRef.__VtrigSched_hfbed39bb__0.moveToResumeQueue(
                                                          "@( (~ asynchronous_fifo_tb.empty))");
    vlSelfRef.__VtrigSched_h0e3b6fae__0.resume("@(posedge asynchronous_fifo_tb.wclock)");
    vlSelfRef.__VtrigSched_hd0cd284b__0.resume("@(posedge asynchronous_fifo_tb.rclock)");
    vlSelfRef.__VtrigSched_hfbed39bb__0.resume("@( (~ asynchronous_fifo_tb.empty))");
    if ((0x0000000000000020ULL & vlSelfRef.__VactTriggered[0U])) {
        vlSelfRef.__VdlySched.resume();
    }
}

void Vasynchronous_fifo_tb___024root___trigger_orInto__act_vec_vec(VlUnpacked<QData/*63:0*/, 1> &out, const VlUnpacked<QData/*63:0*/, 1> &in) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___trigger_orInto__act_vec_vec\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        out[n] = (out[n] | in[n]);
        n = ((IData)(1U) + n);
    } while ((0U >= n));
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vasynchronous_fifo_tb___024root___dump_triggers__act(const VlUnpacked<QData/*63:0*/, 1> &triggers, const std::string &tag);
#endif  // VL_DEBUG

bool Vasynchronous_fifo_tb___024root___eval_phase__act(Vasynchronous_fifo_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___eval_phase__act\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ __VactExecute;
    // Body
    Vasynchronous_fifo_tb___024root___eval_triggers_vec__act(vlSelf);
    Vasynchronous_fifo_tb___024root___timing_ready(vlSelf);
    Vasynchronous_fifo_tb___024root___trigger_orInto__act_vec_vec(vlSelfRef.__VactTriggered, vlSelfRef.__VactTriggeredAcc);
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        Vasynchronous_fifo_tb___024root___dump_triggers__act(vlSelfRef.__VactTriggered, "act"s);
    }
#endif
    Vasynchronous_fifo_tb___024root___trigger_orInto__act_vec_vec(vlSelfRef.__VnbaTriggered, vlSelfRef.__VactTriggered);
    __VactExecute = Vasynchronous_fifo_tb___024root___trigger_anySet__act(vlSelfRef.__VactTriggered);
    if (__VactExecute) {
        vlSelfRef.__VactTriggeredAcc.fill(0ULL);
        Vasynchronous_fifo_tb___024root___timing_resume(vlSelf);
        Vasynchronous_fifo_tb___024root___eval_act(vlSelf);
    }
    return (__VactExecute);
}

bool Vasynchronous_fifo_tb___024root___eval_phase__inact(Vasynchronous_fifo_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___eval_phase__inact\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ __VinactExecute;
    // Body
    __VinactExecute = vlSelfRef.__VdlySched.awaitingZeroDelay();
    if (__VinactExecute) {
        VL_FATAL_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 3, "", "ZERODLY: Design Verilated with '--no-sched-zero-delay', but #0 delay executed at runtime");
    }
    return (__VinactExecute);
}

void Vasynchronous_fifo_tb___024root___trigger_clear__act(VlUnpacked<QData/*63:0*/, 1> &out) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___trigger_clear__act\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        out[n] = 0ULL;
        n = ((IData)(1U) + n);
    } while ((1U > n));
}

bool Vasynchronous_fifo_tb___024root___eval_phase__nba(Vasynchronous_fifo_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___eval_phase__nba\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ __VnbaExecute;
    // Body
    __VnbaExecute = Vasynchronous_fifo_tb___024root___trigger_anySet__act(vlSelfRef.__VnbaTriggered);
    if (__VnbaExecute) {
        Vasynchronous_fifo_tb___024root___eval_nba(vlSelf);
        Vasynchronous_fifo_tb___024root___trigger_clear__act(vlSelfRef.__VnbaTriggered);
    }
    return (__VnbaExecute);
}

void Vasynchronous_fifo_tb___024root___eval(Vasynchronous_fifo_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___eval\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    IData/*31:0*/ __VnbaIterCount;
    // Body
    __VnbaIterCount = 0U;
    do {
        if (VL_UNLIKELY(((0x00002710U < __VnbaIterCount)))) {
#ifdef VL_DEBUG
            Vasynchronous_fifo_tb___024root___dump_triggers__act(vlSelfRef.__VnbaTriggered, "nba"s);
#endif
            VL_FATAL_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 3, "", "DIDNOTCONVERGE: NBA region did not converge after '--converge-limit' of 10000 tries");
        }
        __VnbaIterCount = ((IData)(1U) + __VnbaIterCount);
        vlSelfRef.__VinactIterCount = 0U;
        do {
            if (VL_UNLIKELY(((0x00002710U < vlSelfRef.__VinactIterCount)))) {
                VL_FATAL_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 3, "", "DIDNOTCONVERGE: Inactive region did not converge after '--converge-limit' of 10000 tries");
            }
            vlSelfRef.__VinactIterCount = ((IData)(1U) 
                                           + vlSelfRef.__VinactIterCount);
            vlSelfRef.__VactIterCount = 0U;
            do {
                if (VL_UNLIKELY(((0x00002710U < vlSelfRef.__VactIterCount)))) {
#ifdef VL_DEBUG
                    Vasynchronous_fifo_tb___024root___dump_triggers__act(vlSelfRef.__VactTriggered, "act"s);
#endif
                    VL_FATAL_MT("/customer-home/imac/Documents/Code/ic-agent-flow/artifacts/production-runs/async-fifo-v0.1/T-FIFO-001/20260523-095620/inputs/design/rtl/testbench.sv", 3, "", "DIDNOTCONVERGE: Active region did not converge after '--converge-limit' of 10000 tries");
                }
                vlSelfRef.__VactIterCount = ((IData)(1U) 
                                             + vlSelfRef.__VactIterCount);
                vlSelfRef.__VactPhaseResult = Vasynchronous_fifo_tb___024root___eval_phase__act(vlSelf);
            } while (vlSelfRef.__VactPhaseResult);
            vlSelfRef.__VinactPhaseResult = Vasynchronous_fifo_tb___024root___eval_phase__inact(vlSelf);
        } while (vlSelfRef.__VinactPhaseResult);
        vlSelfRef.__VnbaPhaseResult = Vasynchronous_fifo_tb___024root___eval_phase__nba(vlSelf);
    } while (vlSelfRef.__VnbaPhaseResult);
}

void Vasynchronous_fifo_tb___024root____VbeforeTrig_h0e3b6fae__0(Vasynchronous_fifo_tb___024root* vlSelf, const char* __VeventDescription) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root____VbeforeTrig_h0e3b6fae__0\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    VlUnpacked<QData/*63:0*/, 1> __VTmp;
    // Body
    __VTmp[0U] = (QData)((IData)((((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__wclock) 
                                   & (~ (IData)(vlSelfRef.__Vtrigprevexpr___TOP__asynchronous_fifo_tb__DOT__wclock__0))) 
                                  << 2U)));
    vlSelfRef.__Vtrigprevexpr___TOP__asynchronous_fifo_tb__DOT__wclock__0 
        = vlSelfRef.asynchronous_fifo_tb__DOT__wclock;
    if ((4ULL & __VTmp[0U])) {
        vlSelfRef.__VtrigSched_h0e3b6fae__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_h0e3b6fae__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_h0e3b6fae__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_h0e3b6fae__0.ready(__VeventDescription);
    }
    vlSelfRef.__VactTriggeredAcc[0U] = (vlSelfRef.__VactTriggeredAcc[0U] 
                                        | __VTmp[0U]);
}

void Vasynchronous_fifo_tb___024root____VbeforeTrig_hd0cd284b__0(Vasynchronous_fifo_tb___024root* vlSelf, const char* __VeventDescription) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root____VbeforeTrig_hd0cd284b__0\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    VlUnpacked<QData/*63:0*/, 1> __VTmp;
    // Body
    __VTmp[0U] = (QData)((IData)(((IData)(vlSelfRef.asynchronous_fifo_tb__DOT__rclock) 
                                  & (~ (IData)(vlSelfRef.__Vtrigprevexpr___TOP__asynchronous_fifo_tb__DOT__rclock__0)))));
    vlSelfRef.__Vtrigprevexpr___TOP__asynchronous_fifo_tb__DOT__rclock__0 
        = vlSelfRef.asynchronous_fifo_tb__DOT__rclock;
    if ((1ULL & __VTmp[0U])) {
        vlSelfRef.__VtrigSched_hd0cd284b__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hd0cd284b__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hd0cd284b__0.ready(__VeventDescription);
        vlSelfRef.__VtrigSched_hd0cd284b__0.ready(__VeventDescription);
    }
    vlSelfRef.__VactTriggeredAcc[0U] = (vlSelfRef.__VactTriggeredAcc[0U] 
                                        | __VTmp[0U]);
}

void Vasynchronous_fifo_tb___024root____VbeforeTrig_hfbed39bb__0(Vasynchronous_fifo_tb___024root* vlSelf, const char* __VeventDescription) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root____VbeforeTrig_hfbed39bb__0\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    VlUnpacked<QData/*63:0*/, 1> __VTmp;
    CData/*0:0*/ __Vtrigprevexpr_h6bda5152__0;
    __Vtrigprevexpr_h6bda5152__0 = 0;
    // Body
    __Vtrigprevexpr_h6bda5152__0 = (1U & (~ (IData)(vlSelfRef.asynchronous_fifo_tb__DOT__empty)));
    __VTmp[0U] = (QData)((IData)((((IData)(__Vtrigprevexpr_h6bda5152__0) 
                                   != (IData)(vlSelfRef.__Vtrigprevexpr_h6bda5152__1)) 
                                  << 4U)));
    vlSelfRef.__Vtrigprevexpr_h6bda5152__1 = __Vtrigprevexpr_h6bda5152__0;
    if ((0x0000000000000010ULL & __VTmp[0U])) {
        vlSelfRef.__VtrigSched_hfbed39bb__0.ready(__VeventDescription);
    }
    vlSelfRef.__VactTriggeredAcc[0U] = (vlSelfRef.__VactTriggeredAcc[0U] 
                                        | __VTmp[0U]);
}

#ifdef VL_DEBUG
void Vasynchronous_fifo_tb___024root___eval_debug_assertions(Vasynchronous_fifo_tb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vasynchronous_fifo_tb___024root___eval_debug_assertions\n"); );
    Vasynchronous_fifo_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}
#endif  // VL_DEBUG
