# Human Adjudication Guide

> Derived human-readable companion. The authority record is `requirement_item_adjudication_record.json`.

- chip_id: `route_a_uart_01`
- scope_type: `CHIP_UPSTREAM`
- adjudication_status: `PENDING_DECISION`
- decision_outcome: `None`
- authority_signer: `None`
- generated_at: `2026-05-26T01:21:48.414448+08:00`

## Decision Options

- `approve`: requirement/spec review is sufficient to continue.
- `approve_with_conditions`: continue, but keep explicit conditions attached.
- `request_more_evidence`: stop and ask local AI/repo agent to fill missing evidence.
- `reject`: stop this upstream path.

## Suggested Conditions

- Close ambiguity for baud/frame/FIFO-threshold/CDC/throughput-latency/error-handling.
- Ensure requirement_item acceptance criteria are machine-checkable.
- Keep builder handoff status aligned with adjudication outcome.

## Authority Boundary

- Writing adjudication records requirements/spec judgment only.
- It must not create `run_id`, `artifacts/production-runs`, graph validation, freeze, generation plan, RTL generation, or tapeout/readiness claims.
