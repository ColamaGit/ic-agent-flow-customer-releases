# chips/ Workspace Contract

`chips/<chip_id>/` is the canonical chip-scoped upstream truth workspace for instantiated chip programs.
It is package-friendly documentation: when a release package includes `chips/`, this file should travel with the chip workspaces so operators can understand the folder contract without opening PRDs first.

## Scope Boundary

| Scope | Directory | Meaning |
| --- | --- | --- |
| `CHIP_UPSTREAM` | `chips/<chip_id>/` | Mutable but governed upstream truth for one chip. It stores intake, drafts, review packages, adjudication, validation, freeze, and generation-plan objects before runner execution. |
| `RUN_EXECUTION` | `artifacts/production-runs/<chip_id>/<run_id>/<execution>/` | Immutable run evidence snapshot produced only after runner execution starts. It must not become upstream truth without adjudicated promotion. |

`Requirement Intake`, `Requirement Adjudication`, and `Upstream Truth Flow` all read/write `CHIP_UPSTREAM` objects under this folder. They must not create `run_id` or `artifacts/production-runs/...`.

## Expected Chip Root

```text
chips/<chip_id>/
  chip_program_manifest.yaml
  production_intent.json
  specs/
  architecture/
  governance/
  generation/
  rtl/
  ops/
```

| Path | Meaning |
| --- | --- |
| `chip_program_manifest.yaml` | Program-level chip manifest used to identify the chip workspace and its governed inputs. |
| `production_intent.json` | Production intent / target-context declaration for the chip. It is not run evidence. |
| `specs/` | Requirement intake, requirement items, design spec drafts/freeze records, review package, and adjudication records. |
| `architecture/` | Architecture graph drafts, graph issues, handoff records, validation artifacts, and compatibility mirrors from older chip workspaces. |
| `architecture/validation/` | Canonical location for graph validation result and validator run record. |
| `governance/freeze/` | Canonical authority-bearing freeze records for requirement and graph freeze. |
| `generation/` | Canonical graph-to-generation-plan handoff before RTL generation and PRD v0.9 runner execution. |
| `rtl/` | Bounded RTL candidate generation request, generation record, and generated RTL candidate files before PRD v0.9 Routine-B. |
| `ops/` | Chip-local operational notes. |

## Requirement Intake Session Files

```text
chips/<chip_id>/specs/intake/<intake_session_id>/
  intake_session_record.json
  template_resolution_record.json
  prompt.txt
  attachment_manifest.json          # optional
  intake_materialization_record.json # optional/current materialization path
```

| File | Meaning |
| --- | --- |
| `intake_session_record.json` | Canonical record of the operator's intake request and normalized chip/session metadata. |
| `template_resolution_record.json` | Records whether a template was selected, auto-resolved, deferred, or blocked. Legacy compatibility sessions may use `TEMPLATE_DEFERRED` / `LEGACY_COMPATIBILITY`. |
| `prompt.txt` | Human-readable prompt captured for the session. |
| `attachment_manifest.json` | Attachment index if the intake included files/images. |
| `intake_materialization_record.json` | Materialization evidence for current Execute Intake flows when present. |

## Requirement Adjudication Files

```text
chips/<chip_id>/specs/
  requirement_item.json
  requirement_item_review_package.json
  requirement_item_review_package.md
  requirement_item_adjudication_record.template.json
  requirement_item_adjudication_guide.md
  requirement_item_adjudication_record.json # only after human decision
```

| File | Meaning |
| --- | --- |
| `requirement_item.json` | AUTO_DRAFT or reviewed requirement item pack for the chip. |
| `requirement_item_review_package.json` | Review package shown in Requirement Adjudication. It tracks status such as `PENDING_HUMAN_ADJUDICATION`, `ADJUDICATED_APPROVED`, or `ADJUDICATED_REQUEST_MORE_EVIDENCE`. |
| `requirement_item_review_package.md` | Human-readable companion for operators. It summarizes what to judge and points back to JSON truth; it is not canonical authority. |
| `requirement_item_adjudication_record.template.json` | Pre-filled decision template. It is not approval. |
| `requirement_item_adjudication_guide.md` | Human-readable decision guide. It summarizes decision options, suggested conditions, current recorded state, and non-claims; it is regenerated from JSON state. |
| `requirement_item_adjudication_record.json` | Machine-readable human decision record. Agents may resume only after this exists and target refs/authorization are valid. |

`Write Adjudication Record` only writes the adjudication record and updates review package / builder handoff status. It must not create validation, freeze, generation-plan, run-id, or production-run evidence.

## Architecture And Generation Files

| File | Meaning |
| --- | --- |
| `architecture/builder_validation_handoff.json` | Handoff state from requirement/spec adjudication toward graph generation/validation. `PENDING_VALIDATION` is not freeze approval. |
| `architecture/builder_validation_handoff.md` | Human-readable companion that explains current handoff status and next local AI/repo agent action. It does not replace `builder_validation_handoff.json`. |
| `architecture/architecture_graph.draft.json` | Intake scaffold / draft checkpoint. It is not the real canonical graph and is not frozen graph truth. |
| `architecture/architecture_graph.json` | Real architecture graph candidate generated or refined after requirement/spec adjudication by the bounded graph builder. It still requires validation and freeze before PRD v0.9 execution. |
| `architecture/graph_issue.json` | Graph issue / blocker list when present. |
| `architecture/validation/graph_validation_result.json` | Canonical validation verdict for the graph. |
| `architecture/validation/validator_run_record.json` | Canonical validator execution record for graph validation. |
| `governance/freeze/requirement_freeze_record.json` | Authority-bearing requirement freeze record. |
| `governance/freeze/graph_freeze_record.json` | Authority-bearing graph freeze record. |
| `generation/graph_to_generation_plan.json` | Bounded downstream generation plan consumed before PRD v0.9 runner execution. |
| `rtl/rtl_generation_request.json` | Bounded request for RTL candidate generation from approved v1.0 upstream truth. |
| `rtl/rtl_generation_record.json` | Machine-readable RTL generation result/audit record. |
| `rtl/*.v`, `rtl/*.sv` | Generated or approved RTL candidate files. These are candidates until downstream evidence and human review close. |

Some legacy chip workspaces still contain older paths such as `architecture/graph_validation_result.json`, `architecture/validator_run_record.json`, `architecture/graph_freeze_record.json`, `architecture/graph_to_generation_plan.json`, or `specs/requirement_freeze_record.json`. Current APIs may mirror those into canonical locations for compatibility, but new work should use the canonical paths above.

## Console Page Mapping

| Console Page | Source | Writes |
| --- | --- | --- |
| `Requirement Intake Session` | `chips/<chip_id>/specs/intake/<session>/` plus `templates/` resolution metadata | Creates/loads intake session, template resolution, AUTO_DRAFT requirement item, review package, and draft handoff. |
| `Requirement Adjudication` | `chips/<chip_id>/specs/` and `chips/<chip_id>/architecture/builder_validation_handoff.json` | Writes human adjudication record and updates review/handoff status only. |
| `Upstream Truth Flow` | `chips/<chip_id>/...` | Displays remaining PRD v1.0 nodes, upstream file-family preview, and local AI handoff prompt for real graph generation/refinement, validation, freeze, generation-plan, and RTL candidate preparation. Page render does not create missing artifacts. |
| `Run Detail` | `artifacts/production-runs/...` | Reads run evidence only after runner execution exists. |

`Requirement Adjudication`, `Upstream Truth Flow`, and `Run Detail` use the same console file-family explorer pattern: left file tree, right preview, and a metadata block with `Path`, `Size`, `Meaning`, and `Usage`.

The metadata meaning is intentionally operational:

- `Meaning` answers what the file is in PRD v1.0 / PRD v0.9 terms.
- `Usage` answers where the file is consumed next, and whether it is upstream truth, candidate input, or run-local evidence.

## Current Workspace Alignment Note

The current `chips/` folder may contain chips at different upstream stages. Do not manually create missing downstream files just to make all chip folders look identical.

Observed current pattern:

| Chip | Current state | Expected missing items |
| --- | --- | --- |
| `quad_uart` | New upstream intake/adjudication workspace. It has manifest, production intent, requirement/review/adjudication template, graph draft, and builder handoff. | Human adjudication record, real graph, validation, freeze, generation plan, and RTL candidate files remain intentionally missing until their gates run. |
| `async-fifo-v0.1` | Legacy-compatible chip with real graph, validation, freeze, and generation plan mirrored into current canonical locations. | Human adjudication record and RTL generation candidate sidecars may be missing if not produced by the current upstream lane. |
| `test-chip-02` | Legacy-compatible chip with real graph, validation, freeze, and generation plan mirrored into current canonical locations. | Human adjudication record and RTL generation candidate sidecars may be missing if not produced by the current upstream lane. |
| `uart-controller-v0.1` | Legacy-compatible chip with real graph, validation, freeze, and generation plan mirrored into current canonical locations. | Human adjudication record and RTL generation candidate sidecars may be missing if not produced by the current upstream lane. |

Alignment rule:

1. Missing files should be shown as `NOT_CREATED` / `HUMAN_REVIEW_REQUIRED` / next action in console, not patched by hand.
2. Compatibility mirrors may normalize legacy source paths into current canonical locations only when source evidence already exists.
3. `requirement_item_adjudication_record.json`, freeze records, generation plan, and RTL candidate records must be created by their proper authority/generation steps, not by folder-shape cleanup.

## Runner Input Snapshot Mapping

Before PRD v0.9 runner execution, `chips/<chip_id>/` remains the upstream truth workspace. When the runner starts, it snapshots the governed upstream outputs into run-local inputs:

| Source under `chips/<chip_id>/` | Snapshot under run folder |
| --- | --- |
| `specs/...` | `inputs/spec/...` |
| `architecture/architecture_graph.draft.json` | `inputs/graph/architecture_graph.draft.json` |
| `architecture/builder_validation_handoff.json` | `inputs/graph/builder_validation_handoff.json` |
| `architecture/architecture_graph.json` | `inputs/graph/architecture_graph.json` |
| `architecture/validation/graph_validation_result.json` | `inputs/graph/graph_validation_result.json` |
| `architecture/validation/validator_run_record.json` | `inputs/graph/validator_run_record.json` |
| `governance/freeze/requirement_freeze_record.json` | `inputs/graph/requirement_freeze_record.json` |
| `governance/freeze/graph_freeze_record.json` | `inputs/graph/graph_freeze_record.json` |
| `generation/graph_to_generation_plan.json` | `inputs/graph/graph_to_generation_plan.json` |
| `rtl/` | `inputs/design/rtl/` plus `inputs/rtl` read-compat alias |

After dynamic run-folder sequence prefixing, the physical folder may be named `01_inputs/` or another ordered `*_inputs` prefix. The logical contract remains `inputs/spec` and `inputs/graph`.

## Packaging Note

If a package includes chip workspaces, include this `chips/README.md` together with `chips/<chip_id>/...`. This keeps folder meaning available in customer or extracted package environments where the full repo PRDs may not be opened first.
