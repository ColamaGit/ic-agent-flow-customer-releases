# SN2025 Production-Depth Notes v0.1

## DFT / Scan
- Current scope: bounded DFT planning only.
- Planned scan hooks: `scan_in`, `scan_out`, `scan_enable`, `test_mode`.
- Next step: integrate scan insertion flow and emit scan-chain report.

## Bringup
- Bringup sequence: power rails check, reset release, clock presence, UART smoke loop.
- Lab checklist owner: design owner + validation owner.

## Pad Ring
- Pad direction: digital pad ring around bare-core macro boundary.
- Expected first-wave pads: clock/reset/UART/power-ground exposure.

## ESD
- ESD strategy: pad-adjacent ESD clamp/diode mapping defined as integration intent.
- Signoff note: full ESD topology must be validated after pad-ring instantiation.
