# test-chip-02 Architecture Graph Summary

Canonical source: architecture_graph.json
