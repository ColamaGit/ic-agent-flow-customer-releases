> Companion Hash Guard
- schema_version: `upstream-markdown-companion-hash-guard.v1.0`
- companion_kind: `builder_validation_handoff`
- source_hash_algo: `sha256(stable_json)`
- source_hash_bundle: `0ba14f53322ead796240b40117fff6fab41eecf6113c1104cf328aacc3a012dc`
- generated_at: `2026-05-21T05:03:14.018044+08:00`
- source_ref_hash `/customer-home/imac/Documents/Code/ic-agent-flow/chips/test-chip-02/architecture/builder_validation_handoff.json`: `d5dca7823ec7a37c878867a6735b85ddf2dd7e946c1d3885a7456f282177fdce`
- source_ref_hash `/customer-home/imac/Documents/Code/ic-agent-flow/chips/test-chip-02/specs/requirement_item_review_package.json`: `02eff1386e54aac908135f7204fbb1b69dfb6a2a551c4d482d585cf6a4570300`

# Builder Validation Handoff — Human Companion

> Derived human-readable companion. Canonical handoff state remains in `builder_validation_handoff.json`.

- chip_id: `test-chip-02`
- scope_type: `CHIP_UPSTREAM`
- handoff_status: `PENDING_VALIDATION`
- graph_draft_ref: `chips/test-chip-02/architecture/architecture_graph.draft.json`
- requirement_item_ref: `chips/test-chip-02/specs/requirement_item.json`
- adjudication_record_ref: `/customer-home/imac/Documents/Code/ic-agent-flow/chips/test-chip-02/specs/requirement_item_adjudication_record.json`

## Authority Boundary

- builder_may_freeze: False
- builder_may_declare_canonical: False
- validator_may_declare_freeze: False
- human_decision_required: True

## Next Agent Handoff

- Local AI/repo agent may resume only after a valid machine-readable decision record exists.
- If `handoff_status` is `PENDING_VALIDATION`, proceed to bounded graph generation/refinement and graph validation.
- If `handoff_status` is `REQUEST_MORE_EVIDENCE`, collect missing evidence and return to human adjudication.
- If `handoff_status` is `REJECTED`, do not continue this PRD v1.0 path.
- This handoff remains `CHIP_UPSTREAM`; production-run evidence starts only after freeze and generation-plan/RTL handoff are ready.
