# architecture_graph Companion View - test-chip-02

- Companion role: review-assist artifact
- Authority: NON-CANONICAL
- Canonical source of truth: chips/test-chip-02/architecture/architecture_graph.json
- Source canonical graph ref: chips/test-chip-02/architecture/architecture_graph.json
- Derived-from JSON schema_version: architecture-graph.v1.0
- Derived-from JSON SHA-256 digest: f519a6db6572af21633a8c994eb7de945b23617619c8cacc7314b15d259d46d6
- Conflict rule: if this view conflicts with canonical JSON, canonical JSON prevails.

## Human-Readable Summary

- Module hierarchy: single module top
- Interface set: clk, rst_n, data_in[7:0], data_out[7:0]
- Dependency edges:
  - data_in[7:0] -> data_out[7:0] (posedge clk when rst_n=1)
  - rst_n -> data_out[7:0] (negedge reset override)
- Clock/reset discipline: single clock domain (clk) and single reset domain (rst_n)

## Mermaid Source

flowchart LR
  CLK[clk] --> TOP[top]
  RST[rst_n] --> TOP
  IN[data_in[7:0]] --> TOP
  TOP --> OUT[data_out[7:0]]

  note1[[posedge clk and rst_n=1 : data_out<=data_in]]
  note2[[negedge rst_n : data_out<=0x00]]

  CLK -. timing .-> note1
  RST -. reset .-> note2
  IN -. payload .-> note1
  note1 -. update .-> OUT
  note2 -. override .-> OUT

## Review Checklist (Human)

- [ ] Interface names in view match canonical JSON
- [ ] Dependency conditions match canonical JSON
- [ ] No extra edges/modules beyond canonical JSON
- [ ] If mismatch found, update view or JSON via governed process
