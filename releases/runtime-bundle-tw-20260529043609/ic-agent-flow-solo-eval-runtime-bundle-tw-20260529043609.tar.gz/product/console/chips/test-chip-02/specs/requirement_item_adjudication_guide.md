> Companion Hash Guard
- schema_version: `upstream-markdown-companion-hash-guard.v1.0`
- companion_kind: `requirement_item_adjudication_guide`
- source_hash_algo: `sha256(stable_json)`
- source_hash_bundle: `3b668493e6e5f5d78f35239218c54c0f2e428fdc30d59f73c3651b05ec0f957d`
- generated_at: `2026-05-21T05:03:13.766270+08:00`
- source_ref_hash `/customer-home/imac/Documents/Code/ic-agent-flow/chips/test-chip-02/specs/requirement_item_adjudication_record.template.json`: `62fd2d065e494ddf83742ee402eba86d9c8467802ec7378ae900fedd7f60e6f1`
- source_ref_hash `/customer-home/imac/Documents/Code/ic-agent-flow/chips/test-chip-02/specs/requirement_item_adjudication_record.json`: `c8104542b145f94bda85bbffec22133c9d993c8b8af17f3af69754183db9e64d`
- source_ref_hash `/customer-home/imac/Documents/Code/ic-agent-flow/chips/test-chip-02/specs/requirement_item_review_package.json`: `02eff1386e54aac908135f7204fbb1b69dfb6a2a551c4d482d585cf6a4570300`

# Human Adjudication Guide

> Derived human-readable companion. The authority record is `requirement_item_adjudication_record.json`.

- chip_id: `test-chip-02`
- scope_type: `CHIP_UPSTREAM`
- adjudication_status: `DECISION_RECORDED`
- decision_outcome: `approve_with_conditions`
- authority_signer: `legacy-backfill-authority`
- needs_reentry: `False`

## Decision Options

- `approve`: requirement/spec review is sufficient to continue.
- `approve_with_conditions`: continue, but keep explicit conditions attached.
- `request_more_evidence`: stop and ask local AI/repo agent to fill missing evidence.
- `reject`: stop this upstream path.

## Suggested Conditions

- Review legacy upstream truth before continuing PRD v1.0 gates.
- Confirm graph validation, freeze, and generation plan evidence are still applicable.
- Preserve CHIP_UPSTREAM scope and do not create run evidence from this adjudication action.

## Recorded Conditions

- Bounded readiness scope shall remain explicit in downstream communication.
- Any claim beyond bounded readiness requires a new adjudication cycle.

## Authority Boundary

- Writing adjudication records requirements/spec judgment only.
- It must not create `run_id`, `artifacts/production-runs`, graph validation, freeze, generation plan, RTL generation, or tapeout/readiness claims.
