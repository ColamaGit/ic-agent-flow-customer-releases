> Companion Hash Guard
- schema_version: `upstream-markdown-companion-hash-guard.v1.0`
- companion_kind: `requirement_item_review_package`
- source_hash_algo: `sha256(stable_json)`
- source_hash_bundle: `8b8c7343218898e2b87834383dae186da9ab42a36c9b5a762c23bc27111c8fa3`
- generated_at: `2026-05-21T05:03:13.607156+08:00`
- source_ref_hash `/customer-home/imac/Documents/Code/ic-agent-flow/chips/test-chip-02/specs/requirement_item.json`: `da8eba1fec078859a9320ac849115df3b513e77c49d44848dbfcd8d09cba40a7`
- source_ref_hash `/customer-home/imac/Documents/Code/ic-agent-flow/chips/test-chip-02/specs/requirement_item_review_package.json`: `02eff1386e54aac908135f7204fbb1b69dfb6a2a551c4d482d585cf6a4570300`

# Human Review Companion — Requirement Item

> Derived human-readable companion. Canonical machine truth remains in JSON files.

- chip_id: `test-chip-02`
- scope_type: `CHIP_UPSTREAM`
- review_status: `ADJUDICATED_APPROVED_WITH_CONDITIONS`
- intake_session_id: `INTAKE-test-chip-02-legacy`
- requirement_item_ref: `/customer-home/imac/Documents/Code/ic-agent-flow/chips/test-chip-02/specs/requirement_item.json`
- builder_handoff_ref: `/customer-home/imac/Documents/Code/ic-agent-flow/chips/test-chip-02/architecture/builder_validation_handoff.json`

## What Human Should Judge

- Are the requirement items specific enough to be verified?
- Are ambiguity, missing evidence, and acceptance criteria still open?
- Should the decision be approve, approve_with_conditions, request_more_evidence, or reject?
- This review does not create graph validation, freeze, generation plan, RTL, or production-run evidence.

## Requirement Items

- `REQ-SN2025-001` — Synchronous transfer behavior (`RESOLVED`)
- `REQ-SN2025-002` — Asynchronous reset behavior (`RESOLVED`)
- `REQ-SN2025-003` — Bounded smoke-test observability (`RESOLVED`)
- `REQ-SN2025-004` — Open-source EDA baseline compatibility (`PARTIAL`)

## Candidate Decisions

- approve
- approve_with_conditions
- request_more_evidence
- reject

## Next Step

- Use the Requirement Adjudication page to write `requirement_item_adjudication_record.json`.
- After adjudication, continue in Upstream Truth Flow for graph validation, freeze, generation plan, and RTL generation handoff.
