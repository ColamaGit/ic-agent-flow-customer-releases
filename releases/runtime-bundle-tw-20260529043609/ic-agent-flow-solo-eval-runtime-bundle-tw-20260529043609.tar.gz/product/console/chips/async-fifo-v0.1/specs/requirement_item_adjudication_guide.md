> Companion Hash Guard
- schema_version: `upstream-markdown-companion-hash-guard.v1.0`
- companion_kind: `requirement_item_adjudication_guide`
- source_hash_algo: `sha256(stable_json)`
- source_hash_bundle: `05b7358a2cd7e10755f58e71ffb19e43484ed29f318280e702f777fd0e3cfc58`
- generated_at: `2026-05-21T05:03:12.294181+08:00`
- source_ref_hash `/customer-home/imac/Documents/Code/ic-agent-flow/chips/async-fifo-v0.1/specs/requirement_item_adjudication_record.template.json`: `3b6f555b182a7fcd270f64c342e1f5c7a5c2ca02fbfc1eebe4767a5e6f23e6cd`
- source_ref_hash `/customer-home/imac/Documents/Code/ic-agent-flow/chips/async-fifo-v0.1/specs/requirement_item_adjudication_record.json`: `fc88663b5ceef6199baf265c97c51f30deaf118a1fd06110bea4de1c1052d93c`
- source_ref_hash `/customer-home/imac/Documents/Code/ic-agent-flow/chips/async-fifo-v0.1/specs/requirement_item_review_package.json`: `717f758ebed937f6e24e99d2a94540e94c01239d2642e680f0ddba15ebbcf538`

# Human Adjudication Guide

> Derived human-readable companion. The authority record is `requirement_item_adjudication_record.json`.

- chip_id: `async-fifo-v0.1`
- scope_type: `CHIP_UPSTREAM`
- adjudication_status: `DECISION_RECORDED`
- decision_outcome: `approve`
- authority_signer: `legacy-backfill-authority`
- needs_reentry: `False`

## Decision Options

- `approve`: requirement/spec review is sufficient to continue.
- `approve_with_conditions`: continue, but keep explicit conditions attached.
- `request_more_evidence`: stop and ask local AI/repo agent to fill missing evidence.
- `reject`: stop this upstream path.

## Suggested Conditions

- Review legacy upstream truth before continuing PRD v1.0 gates.
- Confirm graph validation, freeze, and generation plan evidence are still applicable.
- Preserve CHIP_UPSTREAM scope and do not create run evidence from this adjudication action.

## Recorded Conditions

- none

## Authority Boundary

- Writing adjudication records requirements/spec judgment only.
- It must not create `run_id`, `artifacts/production-runs`, graph validation, freeze, generation plan, RTL generation, or tapeout/readiness claims.
