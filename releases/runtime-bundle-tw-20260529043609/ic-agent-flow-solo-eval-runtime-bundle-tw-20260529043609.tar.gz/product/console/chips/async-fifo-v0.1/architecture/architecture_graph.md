# async-fifo-v0.1 Architecture Graph Summary

Canonical source: architecture_graph.json
