# Architecture Graph View

Source canonical graph ref: chips/async-fifo-v0.1/architecture/architecture_graph.json
Derived-from JSON SHA-256 digest: synthetic-for-validation
