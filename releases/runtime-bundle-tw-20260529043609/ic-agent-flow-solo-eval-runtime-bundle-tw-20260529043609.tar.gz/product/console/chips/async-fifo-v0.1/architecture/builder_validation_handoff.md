> Companion Hash Guard
- schema_version: `upstream-markdown-companion-hash-guard.v1.0`
- companion_kind: `builder_validation_handoff`
- source_hash_algo: `sha256(stable_json)`
- source_hash_bundle: `e71ace217564796eaef8a78c908ce47e963d255e39fb5bd96486e83467733328`
- generated_at: `2026-05-21T05:03:12.732648+08:00`
- source_ref_hash `/customer-home/imac/Documents/Code/ic-agent-flow/chips/async-fifo-v0.1/architecture/builder_validation_handoff.json`: `6a399d6e0bee51265e6347f5b4a1e8a2bdf5700cc21536c1eb978c3f5e94414c`
- source_ref_hash `/customer-home/imac/Documents/Code/ic-agent-flow/chips/async-fifo-v0.1/specs/requirement_item_review_package.json`: `717f758ebed937f6e24e99d2a94540e94c01239d2642e680f0ddba15ebbcf538`

# Builder Validation Handoff — Human Companion

> Derived human-readable companion. Canonical handoff state remains in `builder_validation_handoff.json`.

- chip_id: `async-fifo-v0.1`
- scope_type: `CHIP_UPSTREAM`
- handoff_status: `PENDING_VALIDATION`
- graph_draft_ref: `chips/async-fifo-v0.1/architecture/architecture_graph.draft.json`
- requirement_item_ref: `chips/async-fifo-v0.1/specs/requirement_item.json`
- adjudication_record_ref: `/customer-home/imac/Documents/Code/ic-agent-flow/chips/async-fifo-v0.1/specs/requirement_item_adjudication_record.json`

## Authority Boundary

- builder_may_freeze: False
- builder_may_declare_canonical: False
- validator_may_declare_freeze: False
- human_decision_required: True

## Next Agent Handoff

- Local AI/repo agent may resume only after a valid machine-readable decision record exists.
- If `handoff_status` is `PENDING_VALIDATION`, proceed to bounded graph generation/refinement and graph validation.
- If `handoff_status` is `REQUEST_MORE_EVIDENCE`, collect missing evidence and return to human adjudication.
- If `handoff_status` is `REJECTED`, do not continue this PRD v1.0 path.
- This handoff remains `CHIP_UPSTREAM`; production-run evidence starts only after freeze and generation-plan/RTL handoff are ready.
