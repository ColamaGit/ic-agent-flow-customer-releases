# Async FIFO Production-Depth Notes v0.1

## DFT / Scan
- Current scope: bounded DFT planning with future scan insertion path.
- Special note: dual-clock structure requires scan strategy review for clocking assumptions.

## Bringup
- Bringup sequence: power-up, dual reset observation, write/read clock exercise, FIFO flags check.
- Lab note: include asynchronous clock ratio sweeps during smoke tests.

## Pad Ring
- Pad-ring integration is pending; both clock domains and reset/power pins must be exposed.
- Pad assignment and ESD-compatible pad choice will be closed before package handoff.

## ESD
- ESD protection strategy documented for dual-clock IO boundary.
- Full ESD topology verification remains after physical pad-ring integration.
