# Builder Validation Handoff — Human Companion

> Derived human-readable companion. Canonical handoff state remains in `builder_validation_handoff.json`.

- chip_id: `match_uart_01`
- scope_type: `CHIP_UPSTREAM`
- handoff_status: `PENDING_HUMAN_ADJUDICATION`
- requirement_item_ref: `/customer-home/imac/Documents/Code/ic-agent-flow/chips/match_uart_01/specs/requirement_item.json`
- review_package_ref: `/customer-home/imac/Documents/Code/ic-agent-flow/chips/match_uart_01/specs/requirement_item_review_package.json`
- adjudication_template_ref: `/customer-home/imac/Documents/Code/ic-agent-flow/chips/match_uart_01/specs/requirement_item_adjudication_record.template.json`
- generated_at: `2026-05-26T01:21:48.427368+08:00`

## Next Agent Handoff

- Local AI/repo agent may resume only after a valid machine-readable decision record exists.
- If `handoff_status` becomes `PENDING_VALIDATION`, proceed to bounded graph generation/refinement and graph validation.
- If `handoff_status` becomes `REQUEST_MORE_EVIDENCE`, collect missing evidence and return to human adjudication.
- This handoff remains `CHIP_UPSTREAM`; production-run evidence starts only after freeze and generation-plan/RTL handoff are ready.
