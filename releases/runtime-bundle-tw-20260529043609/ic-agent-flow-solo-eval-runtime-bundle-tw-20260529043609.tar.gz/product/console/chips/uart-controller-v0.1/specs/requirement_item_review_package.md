> Companion Hash Guard
- schema_version: `upstream-markdown-companion-hash-guard.v1.0`
- companion_kind: `requirement_item_review_package`
- source_hash_algo: `sha256(stable_json)`
- source_hash_bundle: `573604b7d0da33b35a34db023b5909a458f4e6b047b69461c86c9dbfa318f6b8`
- generated_at: `2026-05-21T05:03:14.863671+08:00`
- source_ref_hash `/customer-home/imac/Documents/Code/ic-agent-flow/chips/uart-controller-v0.1/specs/requirement_item.json`: `0138edbb9a567be7af3a984f41322e5c9315f7291e4a710c761b7053adc2f955`
- source_ref_hash `/customer-home/imac/Documents/Code/ic-agent-flow/chips/uart-controller-v0.1/specs/requirement_item_review_package.json`: `43a1c69f87c9884f58bddf9d53e481fb8342ef6a3775e3508d736381250c9275`

# Human Review Companion — Requirement Item

> Derived human-readable companion. Canonical machine truth remains in JSON files.

- chip_id: `uart-controller-v0.1`
- scope_type: `CHIP_UPSTREAM`
- review_status: `ADJUDICATED_APPROVED_WITH_CONDITIONS`
- intake_session_id: `INTAKE-uart-controller-v0.1-legacy`
- requirement_item_ref: `/customer-home/imac/Documents/Code/ic-agent-flow/chips/uart-controller-v0.1/specs/requirement_item.json`
- builder_handoff_ref: `/customer-home/imac/Documents/Code/ic-agent-flow/chips/uart-controller-v0.1/architecture/builder_validation_handoff.json`

## What Human Should Judge

- Are the requirement items specific enough to be verified?
- Are ambiguity, missing evidence, and acceptance criteria still open?
- Should the decision be approve, approve_with_conditions, request_more_evidence, or reject?
- This review does not create graph validation, freeze, generation plan, RTL, or production-run evidence.

## Requirement Items

- `REQ-UART-001` — UART top-level interface contract (`RESOLVED`)
- `REQ-UART-002` — Bounded simulation pass marker (`RESOLVED`)
- `REQ-UART-003` — Single clock/reset bounded discipline (`PARTIAL`)
- `REQ-UART-004` — Compatibility with governed open-source flow (`PARTIAL`)

## Candidate Decisions

- approve
- approve_with_conditions
- request_more_evidence
- reject

## Next Step

- Use the Requirement Adjudication page to write `requirement_item_adjudication_record.json`.
- After adjudication, continue in Upstream Truth Flow for graph validation, freeze, generation plan, and RTL generation handoff.
