> Companion Hash Guard
- schema_version: `upstream-markdown-companion-hash-guard.v1.0`
- companion_kind: `requirement_item_adjudication_guide`
- source_hash_algo: `sha256(stable_json)`
- source_hash_bundle: `c70cea5bd9033302cff708c18e38159a02a6b63f011a4a71531ca33e189db754`
- generated_at: `2026-05-21T05:03:14.864631+08:00`
- source_ref_hash `/customer-home/imac/Documents/Code/ic-agent-flow/chips/uart-controller-v0.1/specs/requirement_item_adjudication_record.template.json`: `d81ee92f2a9ad8490b606f6bf6a1da84ee6fefdf09026166c7419e9d7eb39ff3`
- source_ref_hash `/customer-home/imac/Documents/Code/ic-agent-flow/chips/uart-controller-v0.1/specs/requirement_item_adjudication_record.json`: `f2b95c909e83f3a2b1320689d67b00ea24ea1ab9cb959a31d00375bffe4825c5`
- source_ref_hash `/customer-home/imac/Documents/Code/ic-agent-flow/chips/uart-controller-v0.1/specs/requirement_item_review_package.json`: `43a1c69f87c9884f58bddf9d53e481fb8342ef6a3775e3508d736381250c9275`

# Human Adjudication Guide

> Derived human-readable companion. The authority record is `requirement_item_adjudication_record.json`.

- chip_id: `uart-controller-v0.1`
- scope_type: `CHIP_UPSTREAM`
- adjudication_status: `DECISION_RECORDED`
- decision_outcome: `approve_with_conditions`
- authority_signer: `legacy-backfill-authority`
- needs_reentry: `False`

## Decision Options

- `approve`: requirement/spec review is sufficient to continue.
- `approve_with_conditions`: continue, but keep explicit conditions attached.
- `request_more_evidence`: stop and ask local AI/repo agent to fill missing evidence.
- `reject`: stop this upstream path.

## Suggested Conditions

- Review legacy upstream truth before continuing PRD v1.0 gates.
- Confirm graph validation, freeze, and generation plan evidence are still applicable.
- Preserve CHIP_UPSTREAM scope and do not create run evidence from this adjudication action.

## Recorded Conditions

- Lint-warning backlog must remain explicit as bounded-scope condition.
- RDC bounded acceptance must not be over-claimed as dedicated signoff closure.
- No implicit escalation to full physical or production sign-off.

## Authority Boundary

- Writing adjudication records requirements/spec judgment only.
- It must not create `run_id`, `artifacts/production-runs`, graph validation, freeze, generation plan, RTL generation, or tapeout/readiness claims.
