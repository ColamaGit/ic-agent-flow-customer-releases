# uart-controller-v0.1 v1.0 Pilot Decision Log (P0-P6 Mini)

## P0 Scope Freeze
- Locked pilot chip: `uart-controller-v0.1`
- Locked source evidence run: `20260421-134805`
- Locked objective: validate upstream chain only, no downstream authority claim.

## P1 Requirement Intake
- Requirement objects created in `chips/uart-controller-v0.1/specs/requirement_item.json`.
- Ambiguity detected: RDC bounded acceptance and lint-warning backlog require authority-conditioned wording.

## P2 Spec Completion
- `design_spec` and `spec_completeness_report` created.
- `requirement_freeze_record` created as `CONDITIONAL_FREEZE`.
- Authority action required: `approve_with_conditions` or `request_more_evidence`.

## P3 Architecture Graph
- `architecture_graph` and `interface_binding_record` created from UART top/module boundaries.
- Companion view created for human validation; canonical truth remains JSON.

## P4 Validation
- Raw validator outputs stay in `artifacts/...` evidence plane.
- Canonical `graph_validation_result` references raw outputs and issue pack.
- Verdict: `PASS_WITH_WARNINGS` (non-blocking issues tracked).

## P5 Freeze
- `graph_freeze_record` created as `FROZEN_WITH_CONDITIONS`.
- Freeze eligibility checklist recorded; no automatic freeze from REVALIDATED/ADJUDICATED state.

## P6 Generation Plan
- Machine-consumable `graph_to_generation_plan` created with generation order/constraints/assumptions/obligations/stop conditions.

## Authority/Adjudication Required Steps (Cannot Be Skipped)
1. Requirement conditional freeze decision (`requirement_freeze_record`).
2. Validation warning and issue adjudication (`graph_validation_result` + `graph_issue`).
3. Freeze authority-bearing decision (`graph_freeze_record`) before generation plan eligibility.
4. Promotion/adoption adjudication for run-evidence to canonical-truth movement (`promotion_adjudication_record`).

## No-Code Gap Handling Rule
- Any gap found in this pilot is first routed to documentation/contract correction.
- No runtime/tooling implementation change is used to mask missing governance object semantics.
