# UART Controller Production-Depth Notes v0.1

## DFT / Scan
- Current scope: bounded DFT intent; no inserted scan chain yet.
- Required scan plan: scan enable path, scan IO boundary, ATPG compatibility notes.

## Bringup
- Bringup sequence: power-up, reset deassertion, UART TX/RX loopback, baud sanity.
- Bench requirement: stable clock source and UART capture script.

## Pad Ring
- Pad-ring integration remains pending; UART IO pads and power pads are planned.
- Pad assignment will be finalized before full package signoff.

## ESD
- ESD protection intent documented for UART IO and power pads.
- Full ESD clamp/diode instantiation remains a later physical-integration step.
