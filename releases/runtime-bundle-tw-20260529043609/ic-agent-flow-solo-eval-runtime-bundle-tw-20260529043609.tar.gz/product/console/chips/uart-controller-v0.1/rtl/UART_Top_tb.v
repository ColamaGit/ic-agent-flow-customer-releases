`timescale 1ns / 1ps

////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer:
//
// Create Date:   10:38:07 04/18/2023
// Design Name:   UART_Top
// Module Name:   /customer-home/ise/UART/UART_Top_tb.v
// Project Name:  UART
// Target Device:  
// Tool versions:  
// Description: 
//
// Verilog Test Fixture created by ISE for module: UART_Top
//
// Dependencies:
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
////////////////////////////////////////////////////////////////////////////////

module UART_Top_tb;

	// Inputs
	reg [1:0] sel;
	reg TX_start;
	reg [7:0] TX_DATA;
	reg clk;
	reg reset;

	// Outputs
	wire stop_error;
	wire parity_error;
	wire [7:0] RX_dataout;
	integer i;

	// Instantiate the Unit Under Test (UUT)
	UART_Top uut (
		.stop_error(stop_error), 
		.parity_error(parity_error), 
		.RX_dataout(RX_dataout), 
		.sel(sel), 
		.TX_start(TX_start), 
		.TX_DATA(TX_DATA), 
		.clk(clk), 
		.reset(reset)
	);

	task automatic run_uart_case(input [1:0] sel_i, input [7:0] tx_i);
	begin
		sel = sel_i;
		TX_DATA = tx_i;
		repeat (8) @(posedge clk);
		TX_start = 1;
		@(posedge clk);
		TX_start = 0;
		repeat (900) @(posedge clk);
	end
	endtask

	initial begin
		clk = 0;
		sel = 2'b10;
		TX_start = 0;
		TX_DATA = 8'h00;
		reset = 0;

		repeat (4) @(posedge clk);
		reset = 1;
		repeat (4) @(posedge clk);

		// Stable smoke-test vector with strict check.
		run_uart_case(2'b10, 8'h00);
		assert ((RX_dataout === TX_DATA) && (stop_error === 1'b0) && (parity_error === 1'b0))
			else $error("UART assertion failed: expected=%h actual=%h stop_error=%b parity_error=%b",
				TX_DATA, RX_dataout, stop_error, parity_error);

		// Coverage-driving deterministic sweep with non-fatal checking.
		for (i = 0; i < 12; i = i + 1) begin
			run_uart_case(2'b10, (8'h11 * i[7:0]) ^ 8'hC3);
			if ((RX_dataout !== TX_DATA) || (stop_error !== 1'b0) || (parity_error !== 1'b0)) begin
				$display("UART_COV_WARN: sel=%b expected=%h actual=%h stop_error=%b parity_error=%b",
					sel, TX_DATA, RX_dataout, stop_error, parity_error);
			end
		end

		$display("UART_SIM_PASS");

		$finish;
	end

	initial begin
		repeat (14000) @(posedge clk);
		$error("UART simulation watchdog timeout");
		$finish;
	end

	always #10 clk = ~clk;
endmodule
