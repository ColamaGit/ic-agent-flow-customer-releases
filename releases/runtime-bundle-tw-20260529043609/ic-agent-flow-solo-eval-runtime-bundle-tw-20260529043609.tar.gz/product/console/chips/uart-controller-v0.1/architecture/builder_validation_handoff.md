> Companion Hash Guard
- schema_version: `upstream-markdown-companion-hash-guard.v1.0`
- companion_kind: `builder_validation_handoff`
- source_hash_algo: `sha256(stable_json)`
- source_hash_bundle: `67ffe03a303b458b082e3831d523f198a1487aac3e21aa5a3da3f4afe310e3ef`
- generated_at: `2026-05-21T05:03:14.865458+08:00`
- source_ref_hash `/customer-home/imac/Documents/Code/ic-agent-flow/chips/uart-controller-v0.1/architecture/builder_validation_handoff.json`: `ea34917bd2223735c8eeed65cdce61c72490b4334e406d2ced1c5cb1fcc5c8bf`
- source_ref_hash `/customer-home/imac/Documents/Code/ic-agent-flow/chips/uart-controller-v0.1/specs/requirement_item_review_package.json`: `43a1c69f87c9884f58bddf9d53e481fb8342ef6a3775e3508d736381250c9275`

# Builder Validation Handoff — Human Companion

> Derived human-readable companion. Canonical handoff state remains in `builder_validation_handoff.json`.

- chip_id: `uart-controller-v0.1`
- scope_type: `CHIP_UPSTREAM`
- handoff_status: `PENDING_VALIDATION`
- graph_draft_ref: `chips/uart-controller-v0.1/architecture/architecture_graph.draft.json`
- requirement_item_ref: `chips/uart-controller-v0.1/specs/requirement_item.json`
- adjudication_record_ref: `/customer-home/imac/Documents/Code/ic-agent-flow/chips/uart-controller-v0.1/specs/requirement_item_adjudication_record.json`

## Authority Boundary

- builder_may_freeze: False
- builder_may_declare_canonical: False
- validator_may_declare_freeze: False
- human_decision_required: True

## Next Agent Handoff

- Local AI/repo agent may resume only after a valid machine-readable decision record exists.
- If `handoff_status` is `PENDING_VALIDATION`, proceed to bounded graph generation/refinement and graph validation.
- If `handoff_status` is `REQUEST_MORE_EVIDENCE`, collect missing evidence and return to human adjudication.
- If `handoff_status` is `REJECTED`, do not continue this PRD v1.0 path.
- This handoff remains `CHIP_UPSTREAM`; production-run evidence starts only after freeze and generation-plan/RTL handoff are ready.
