# UART Controller Architecture Graph Companion View

- Source canonical graph ref: `chips/uart-controller-v0.1/architecture/architecture_graph.json`
- Derived-from JSON schema_version: `architecture-graph.v1.0`
- Derived-from JSON SHA-256: `0d4d7c6a1c9b2fc9ce59eebd626bef7a29e565bf157bf2c932b9cdc13bb6ec85`

## Hierarchy

- `UART_Top` (top module)
- `Transmitter` (submodule)
- `Receiver` (submodule)
- `Baud_rate_generator` (submodule)

## Interface Summary

- Outputs: `stop_error`, `parity_error`, `RX_dataout[7:0]`
- Inputs: `TX_start`, `TX_DATA[7:0]`, `sel[1:0]`, `clk`, `reset`

## Dependency Summary

- `sel` configures baud-rate generation
- TX path participates in bounded loopback smoke path
- `reset` fans out to UART submodules

## Review-Assist Only

This file is a review-assist companion artifact. Canonical authority remains with `architecture_graph.json`.
