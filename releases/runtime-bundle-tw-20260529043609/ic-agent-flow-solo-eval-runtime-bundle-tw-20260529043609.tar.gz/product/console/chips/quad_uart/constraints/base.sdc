# quad_uart chip-scoped constraints

create_clock -name pclk -period 1.0 [get_ports pclk]
set_input_delay 0.2 -clock pclk [get_ports {presetn psel penable pwrite}]
set_input_delay 0.2 -clock pclk [get_ports {paddr[*] pwdata[*] uart_rx[*]}]
set_output_delay 0.2 -clock pclk [get_ports {prdata[*] pready pslverr uart_tx[*] irq[*]}]
set_false_path -from [get_ports presetn]
set_max_fanout 32 [current_design]
# quad_uart uses a wide async reset fanout; keep the global cap policy strict but
# exclude presetn from the generic input-cap guard so the report reflects actual
# async-reset design intent instead of treating reset distribution like datapath load.
set_max_transition 0.20 [current_design]
set non_reset_ports [get_ports -filter "name != presetn"]
set_max_capacitance 25 $non_reset_ports
