> Companion Hash Guard
- schema_version: `upstream-markdown-companion-hash-guard.v1.0`
- companion_kind: `builder_validation_handoff`
- source_hash_algo: `sha256(stable_json)`
- source_hash_bundle: `ee336baf041dd73632115c9cd565d816b6ec33d1b7e3c3aef22b333f4eb02eff`
- generated_at: `2026-05-26T19:26:19.228729+08:00`
- source_ref_hash `/customer-home/imac/Documents/Code/ic-agent-flow/chips/quad_uart/architecture/builder_validation_handoff.json`: `d8cf6dfe3d0dff4eeafc13f1f38dc73ec4959d2bcb478e3c22c0c2eebe6dcea4`
- source_ref_hash `/customer-home/imac/Documents/Code/ic-agent-flow/chips/quad_uart/specs/requirement_item_review_package.json`: `b3586fa98c8929e981768e8fcbcbc1eb87bef4f022360abcff16004af0efca88`

# Builder Validation Handoff — Human Companion

> Derived human-readable companion. Canonical handoff state remains in `builder_validation_handoff.json`.

- chip_id: `quad_uart`
- scope_type: `CHIP_UPSTREAM`
- handoff_status: `PENDING_VALIDATION`
- graph_draft_ref: `chips/quad_uart/architecture/architecture_graph.draft.json`
- requirement_item_ref: `chips/quad_uart/specs/requirement_item.json`
- adjudication_record_ref: ``

## Authority Boundary

- builder_may_freeze: False
- builder_may_declare_canonical: False
- validator_may_declare_freeze: False
- human_decision_required: True

## Next Agent Handoff

- Local AI/repo agent may resume only after a valid machine-readable decision record exists.
- If `handoff_status` is `PENDING_VALIDATION`, proceed to bounded graph generation/refinement and graph validation.
- If `handoff_status` is `REQUEST_MORE_EVIDENCE`, collect missing evidence and return to human adjudication.
- If `handoff_status` is `REJECTED`, do not continue this PRD v1.0 path.
- This handoff remains `CHIP_UPSTREAM`; production-run evidence starts only after freeze and generation-plan/RTL handoff are ready.
