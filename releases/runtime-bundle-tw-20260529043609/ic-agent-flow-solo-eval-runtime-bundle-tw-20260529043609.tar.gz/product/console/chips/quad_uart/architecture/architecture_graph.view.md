# Architecture Graph View

- chip_id: quad_uart
- scope: CHIP_UPSTREAM
- source: architecture_graph.json

## Modules
- QuadUartTop
- UartChannel0..3
- ApbControl
- IrqAggregator

## Boundary
This view is a human companion and does not override canonical JSON authority.
