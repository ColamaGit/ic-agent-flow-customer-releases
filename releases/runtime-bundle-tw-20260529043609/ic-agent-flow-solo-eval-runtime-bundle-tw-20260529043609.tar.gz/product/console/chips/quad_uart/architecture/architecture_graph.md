# Quad UART Architecture Graph Summary

- chip_id: `quad_uart`
- graph_id: `AG-QUAD-UART-v1.0-upstream`
- status: `CANONICAL_GRAPH_READY`
- scope_type: `CHIP_UPSTREAM`

## Top Module
- `QuadUartTop`

## Submodules
- `UartChannel0`
- `UartChannel1`
- `UartChannel2`
- `UartChannel3`
- `ApbControl`
- `IrqAggregator`

## Key Interfaces
- APB: `pclk`, `presetn`, `psel`, `penable`, `pwrite`, `paddr[11:0]`, `pwdata[31:0]`, `prdata[31:0]`, `pready`, `pslverr`
- UART lanes: `uart_rx[3:0]`, `uart_tx[3:0]`
- IRQ: `irq[3:0]`

## Claim Boundary
This companion summary is human-readable only. Canonical authority remains `architecture_graph.json`.
