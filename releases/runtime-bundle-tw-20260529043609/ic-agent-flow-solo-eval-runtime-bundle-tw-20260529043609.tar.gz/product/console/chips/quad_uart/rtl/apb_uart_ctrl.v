module apb_uart_ctrl (
  input        pclk,
  input        presetn,
  input        psel,
  input        penable,
  input        pwrite,
  /* verilator lint_off UNUSEDSIGNAL */
  input [11:0] paddr,
  /* verilator lint_on UNUSEDSIGNAL */
  input [31:0] pwdata,
  input  [3:0] irq,
  output reg [31:0] ch_cfg0,
  output reg [31:0] ch_cfg1,
  output reg [31:0] ch_cfg2,
  output reg [31:0] ch_cfg3,
  output reg [31:0] ch_tx0,
  output reg [31:0] ch_tx1,
  output reg [31:0] ch_tx2,
  output reg [31:0] ch_tx3,
  output reg [3:0] tx_fire,
  output reg [31:0] prdata,
  output       pready,
  output       pslverr
);
  assign pready = 1'b1;
  assign pslverr = 1'b0;

  wire apb_access = psel && penable;
  wire apb_wr = apb_access && pwrite;
  wire apb_rd = apb_access && !pwrite;

  always @(posedge pclk or negedge presetn) begin
    if (!presetn) begin
      ch_cfg0 <= 32'h0; ch_cfg1 <= 32'h0; ch_cfg2 <= 32'h0; ch_cfg3 <= 32'h0;
      ch_tx0 <= 32'h0; ch_tx1 <= 32'h0; ch_tx2 <= 32'h0; ch_tx3 <= 32'h0;
      tx_fire <= 4'b0000;
    end else begin
      tx_fire <= 4'b0000;
      if (apb_wr) begin
        case (paddr[7:2])
          6'h00: ch_cfg0 <= pwdata;
          6'h01: begin ch_tx0 <= pwdata; tx_fire[0] <= 1'b1; end
          6'h04: ch_cfg1 <= pwdata;
          6'h05: begin ch_tx1 <= pwdata; tx_fire[1] <= 1'b1; end
          6'h08: ch_cfg2 <= pwdata;
          6'h09: begin ch_tx2 <= pwdata; tx_fire[2] <= 1'b1; end
          6'h0c: ch_cfg3 <= pwdata;
          6'h0d: begin ch_tx3 <= pwdata; tx_fire[3] <= 1'b1; end
          default: begin end
        endcase
      end
    end
  end

  always @(posedge pclk or negedge presetn) begin
    if (!presetn) begin
      prdata <= 32'h0;
    end else if (apb_rd) begin
      case (paddr[7:2])
        6'h00: prdata <= ch_cfg0;
        6'h01: prdata <= ch_tx0;
        6'h04: prdata <= ch_cfg1;
        6'h05: prdata <= ch_tx1;
        6'h08: prdata <= ch_cfg2;
        6'h09: prdata <= ch_tx2;
        6'h0c: prdata <= ch_cfg3;
        6'h0d: prdata <= ch_tx3;
        6'h10: prdata <= {28'h0, irq};
        default: prdata <= 32'h0;
      endcase
    end
  end

endmodule
