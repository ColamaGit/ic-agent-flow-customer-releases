module quad_uart_top (
  input        pclk,
  input        presetn,
  input        psel,
  input        penable,
  input        pwrite,
  input [11:0] paddr,
  input [31:0] pwdata,
  output [31:0] prdata,
  output       pready,
  output       pslverr,
  input  [3:0] uart_rx,
  output [3:0] uart_tx,
  output [3:0] irq
);

  wire [31:0] ch_cfg0, ch_cfg1, ch_cfg2, ch_cfg3;
  wire [31:0] ch_tx0, ch_tx1, ch_tx2, ch_tx3;
  wire [3:0] tx_fire;

  apb_uart_ctrl u_apb_uart_ctrl (
    .pclk(pclk),
    .presetn(presetn),
    .psel(psel),
    .penable(penable),
    .pwrite(pwrite),
    .paddr(paddr),
    .pwdata(pwdata),
    .irq(irq),
    .ch_cfg0(ch_cfg0), .ch_cfg1(ch_cfg1), .ch_cfg2(ch_cfg2), .ch_cfg3(ch_cfg3),
    .ch_tx0(ch_tx0), .ch_tx1(ch_tx1), .ch_tx2(ch_tx2), .ch_tx3(ch_tx3),
    .tx_fire(tx_fire),
    .prdata(prdata),
    .pready(pready),
    .pslverr(pslverr)
  );

  uart_channel u_uart_ch0 (
    .pclk(pclk), .presetn(presetn), .cfg(ch_cfg0), .tx_data(ch_tx0), .tx_fire(tx_fire[0]), .uart_rx(uart_rx[0]), .uart_tx(uart_tx[0]), .irq(irq[0])
  );
  uart_channel u_uart_ch1 (
    .pclk(pclk), .presetn(presetn), .cfg(ch_cfg1), .tx_data(ch_tx1), .tx_fire(tx_fire[1]), .uart_rx(uart_rx[1]), .uart_tx(uart_tx[1]), .irq(irq[1])
  );
  uart_channel u_uart_ch2 (
    .pclk(pclk), .presetn(presetn), .cfg(ch_cfg2), .tx_data(ch_tx2), .tx_fire(tx_fire[2]), .uart_rx(uart_rx[2]), .uart_tx(uart_tx[2]), .irq(irq[2])
  );
  uart_channel u_uart_ch3 (
    .pclk(pclk), .presetn(presetn), .cfg(ch_cfg3), .tx_data(ch_tx3), .tx_fire(tx_fire[3]), .uart_rx(uart_rx[3]), .uart_tx(uart_tx[3]), .irq(irq[3])
  );

endmodule
