module irq_aggregator (
  input  [3:0] ch_irq,
  output [3:0] irq
);
  assign irq = ch_irq;
endmodule
