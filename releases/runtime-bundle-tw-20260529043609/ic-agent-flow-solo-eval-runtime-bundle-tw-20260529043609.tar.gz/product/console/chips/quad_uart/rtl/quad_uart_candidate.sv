module quad_uart_candidate (
  input  logic        pclk,
  input  logic        presetn,
  input  logic        psel,
  input  logic        penable,
  input  logic        pwrite,
  input  logic [11:0] paddr,
  input  logic [31:0] pwdata,
  output logic [31:0] prdata,
  output logic        pready,
  output logic        pslverr,
  input  logic [3:0]  uart_rx,
  output logic [3:0]  uart_tx,
  output logic [3:0]  irq
);

  logic [31:0] channel_cfg [4];
  logic [31:0] tx_data [4];
  logic [3:0]  tx_enable;
  logic [3:0]  rx_sync;

  assign pready = 1'b1;
  assign pslverr = 1'b0;

  always_ff @(posedge pclk or negedge presetn) begin
    if (!presetn) begin
      for (int i = 0; i < 4; i++) begin
        channel_cfg[i] <= 32'h0;
        tx_data[i] <= 32'h0;
      end
      tx_enable <= 4'h0;
      prdata <= 32'h0;
    end else begin
      tx_enable <= 4'h0;
      if (psel && penable && pwrite) begin
        unique case (paddr[7:2])
          6'h00: channel_cfg[0] <= pwdata;
          6'h01: tx_data[0] <= pwdata;
          6'h04: channel_cfg[1] <= pwdata;
          6'h05: tx_data[1] <= pwdata;
          6'h08: channel_cfg[2] <= pwdata;
          6'h09: tx_data[2] <= pwdata;
          6'h0c: channel_cfg[3] <= pwdata;
          6'h0d: tx_data[3] <= pwdata;
          default: begin end
        endcase
        if (paddr[3:2] == 2'b01) begin
          tx_enable[paddr[5:4]] <= 1'b1;
        end
      end

      if (psel && penable && !pwrite) begin
        unique case (paddr[7:2])
          6'h00: prdata <= channel_cfg[0];
          6'h01: prdata <= tx_data[0];
          6'h04: prdata <= channel_cfg[1];
          6'h05: prdata <= tx_data[1];
          6'h08: prdata <= channel_cfg[2];
          6'h09: prdata <= tx_data[2];
          6'h0c: prdata <= channel_cfg[3];
          6'h0d: prdata <= tx_data[3];
          6'h10: prdata <= {28'h0, irq};
          default: prdata <= 32'h0;
        endcase
      end
    end
  end

  always_ff @(posedge pclk or negedge presetn) begin
    if (!presetn) begin
      rx_sync <= 4'hf;
      uart_tx <= 4'hf;
      irq <= 4'h0;
    end else begin
      rx_sync <= uart_rx;
      for (int i = 0; i < 4; i++) begin
        if (tx_enable[i]) begin
          uart_tx[i] <= tx_data[i][0];
          irq[i] <= 1'b1;
        end else if (rx_sync[i] != uart_rx[i]) begin
          irq[i] <= 1'b1;
        end
      end
    end
  end

endmodule
