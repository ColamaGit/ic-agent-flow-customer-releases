module uart_channel (
  input        pclk,
  input        presetn,
  /* verilator lint_off UNUSEDSIGNAL */
  input [31:0] cfg,
  input [31:0] tx_data,
  /* verilator lint_on UNUSEDSIGNAL */
  input        tx_fire,
  input        uart_rx,
  output reg   uart_tx,
  output reg   irq
);
  reg rx_d;

  always @(posedge pclk or negedge presetn) begin
    if (!presetn) begin
      rx_d <= 1'b1;
      uart_tx <= 1'b1;
      irq <= 1'b0;
    end else begin
      rx_d <= uart_rx;
      if (tx_fire) begin
        uart_tx <= tx_data[0];
        irq <= 1'b1;
      end else if (rx_d != uart_rx) begin
        irq <= 1'b1;
      end else if (cfg[0]) begin
        irq <= 1'b0;
      end
    end
  end

endmodule
