`timescale 1ns/1ps

module quad_uart_tb;
  logic pclk;
  logic presetn;
  logic psel;
  logic penable;
  logic pwrite;
  logic [11:0] paddr;
  logic [31:0] pwdata;
  logic [3:0] uart_rx;
  wire [31:0] prdata;
  wire pready;
  wire pslverr;
  wire [3:0] uart_tx;
  wire [3:0] irq;

  quad_uart_top dut (
    .pclk(pclk),
    .presetn(presetn),
    .psel(psel),
    .penable(penable),
    .pwrite(pwrite),
    .paddr(paddr),
    .pwdata(pwdata),
    .prdata(prdata),
    .pready(pready),
    .pslverr(pslverr),
    .uart_rx(uart_rx),
    .uart_tx(uart_tx),
    .irq(irq)
  );

  always #5 pclk = ~pclk;

  function automatic [11:0] cfg_addr(input int idx);
    case (idx)
      0: cfg_addr = 12'h000;
      1: cfg_addr = 12'h010;
      2: cfg_addr = 12'h020;
      default: cfg_addr = 12'h030;
    endcase
  endfunction

  function automatic [11:0] tx_addr(input int idx);
    case (idx)
      0: tx_addr = 12'h004;
      1: tx_addr = 12'h014;
      2: tx_addr = 12'h024;
      default: tx_addr = 12'h034;
    endcase
  endfunction

  task automatic apb_write(input [11:0] addr, input [31:0] data);
  begin
    @(negedge pclk);
    psel = 1'b1;
    penable = 1'b0;
    pwrite = 1'b1;
    paddr = addr;
    pwdata = data;
    @(negedge pclk);
    penable = 1'b1;
    @(posedge pclk);
    #1;
    assert (pready === 1'b1)
      else begin
        $display("QUAD_UART_ASSERT_FAIL pready low on write addr=%03h", addr);
        $fatal(1);
      end
    assert (pslverr === 1'b0)
      else begin
        $display("QUAD_UART_ASSERT_FAIL pslverr high on write addr=%03h", addr);
        $fatal(1);
      end
    @(negedge pclk);
    psel = 1'b0;
    penable = 1'b0;
    pwrite = 1'b0;
  end
  endtask

  task automatic apb_read(input [11:0] addr, output [31:0] data);
  begin
    @(negedge pclk);
    psel = 1'b1;
    penable = 1'b0;
    pwrite = 1'b0;
    paddr = addr;
    pwdata = 32'h0;
    @(negedge pclk);
    penable = 1'b1;
    @(posedge pclk);
    #1;
    data = prdata;
    assert (pready === 1'b1)
      else begin
        $display("QUAD_UART_ASSERT_FAIL pready low on read addr=%03h", addr);
        $fatal(1);
      end
    assert (pslverr === 1'b0)
      else begin
        $display("QUAD_UART_ASSERT_FAIL pslverr high on read addr=%03h", addr);
        $fatal(1);
      end
    @(negedge pclk);
    psel = 1'b0;
    penable = 1'b0;
    pwrite = 1'b0;
  end
  endtask

  task automatic settle(input int cycles = 1);
  begin
    repeat (cycles) @(posedge pclk);
    #1;
  end
  endtask

  initial begin
    pclk = 1'b0;
    presetn = 1'b0;
    psel = 1'b0;
    penable = 1'b0;
    pwrite = 1'b0;
    paddr = '0;
    pwdata = '0;
    uart_rx = 4'hF;

    repeat (4) @(posedge pclk);
    presetn = 1'b1;
    settle(2);

    for (int i = 0; i < 4; i++) begin
      apb_write(cfg_addr(i), 32'h0000_0001);
      apb_write(tx_addr(i), (i % 2 == 0) ? 32'h0000_0000 : 32'h0000_0001);
      settle(1);
    end

    uart_rx = 4'b1110;
    settle(2);
    uart_rx = 4'b1111;
    settle(2);

    for (int i = 0; i < 4; i++) begin
      logic [31:0] read_back;
      apb_read(cfg_addr(i), read_back);
      assert (read_back[0] === 1'b1)
        else begin
          $display("QUAD_UART_ASSERT_FAIL cfg[%0d] readback mismatch: %08h", i, read_back);
          $fatal(1);
        end
      apb_read(tx_addr(i), read_back);
      assert (read_back[0] === ((i % 2 == 0) ? 1'b0 : 1'b1))
        else begin
          $display("QUAD_UART_ASSERT_FAIL tx[%0d] readback mismatch: %08h", i, read_back);
          $fatal(1);
        end
    end

    assert (uart_tx[0] === 1'b0)
      else begin
        $display("QUAD_UART_ASSERT_FAIL uart_tx[0] expected 0 got=%b", uart_tx[0]);
        $fatal(1);
      end
    assert (uart_tx[1] === 1'b1)
      else begin
        $display("QUAD_UART_ASSERT_FAIL uart_tx[1] expected 1 got=%b", uart_tx[1]);
        $fatal(1);
      end
    assert (irq[0] === 1'b1)
      else begin
        $display("QUAD_UART_ASSERT_FAIL irq[0] expected 1 got=%b", irq[0]);
        $fatal(1);
      end
    assert (irq[1] === 1'b1)
      else begin
        $display("QUAD_UART_ASSERT_FAIL irq[1] expected 1 got=%b", irq[1]);
        $fatal(1);
      end

    $display("Comparison Passed: quad_uart smoke");
    $display("QUAD_UART_SIM_PASS");
    $finish;
  end

  initial begin
    repeat (400) @(posedge pclk);
    $display("QUAD_UART_SIM_TIMEOUT");
    $fatal(1);
  end
endmodule
