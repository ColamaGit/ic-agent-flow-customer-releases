#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path
from typing import Any

from ic_agent_flow.domain.objects.deployment_packaging_objects import (
    AuthorityClass,
    DeploymentProfile,
    ObjectStatus,
    ProductManifest,
    RuntimeDistributionBundle,
    SignatureBlock,
    SitePolicyOverlay,
    SupportAuditBundle,
)
from ic_agent_flow.domain.objects.v15_customer_site_activation_objects import (
    ActivationDecisionRecord,
    BootstrapRunRecord,
    SiteActivationRequest,
    SitePreflightReport,
    SiteReadinessReport,
    SiteSmokeRunRecord,
)
from ic_agent_flow.governance.customer_package_verifier import RuntimeBundleVerifier
from ic_agent_flow.governance.customer_org_model import (
    CustomerOrgManifest,
    validate_activation_roles,
)
from ic_agent_flow.governance.customer_site_activation import SiteActivationEngine
from ic_agent_flow.governance.toolchain_profile_resolver import (
    resolve_toolchain_profile,
    write_toolchain_resolution_artifact,
)


def _read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _write_json(path: Path, payload: dict[str, Any]) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return str(path)


def _profile_ref(profile_id: str) -> str:
    if profile_id == "airgap-local":
        return "profile://airgap_local"
    if profile_id == "customer-vpc":
        return "profile://customer_managed_vpc"
    if profile_id == "managed-sandbox":
        return "profile://managed_sandbox"
    return f"profile://{profile_id.replace('-', '_')}"


def _build_profile(profile_id: str) -> DeploymentProfile:
    network_policy = {
        "airgap-local": "local-only",
        "customer-vpc": "customer-vpc",
        "managed-sandbox": "managed-sandbox",
    }.get(profile_id, profile_id)
    return DeploymentProfile(
        version="0.2",
        status=ObjectStatus.ACTIVE,
        authority_class=AuthorityClass.SYSTEM,
        producer="v15-site-activation-runner@0.1",
        digest=f"sha256:profile:{profile_id}",
        signature=SignatureBlock(
            key_id="key-v15-profile",
            algorithm="ed25519",
            trust_root_ref="trust-root://customer-a",
            verifier_authority="security",
            key_lifecycle="ACTIVE",
        ),
        network_policy=network_policy,
        backend_policy="embedded",
        storage_policy="site-local",
        audit_policy="local-audit",
        capability_set=["bounded-runtime"],
        forbidden_capabilities=[],
        enabled_adapters=["local-filesystem"],
    )


def _build_request(site_manifest: dict[str, Any], bundle: RuntimeDistributionBundle, mode: str) -> SiteActivationRequest:
    return SiteActivationRequest(
        version="0.1",
        status=ObjectStatus.DRAFT,
        authority_class=AuthorityClass.OPERATOR,
        producer="v15-site-activation-runner@0.1",
        digest=f"sha256:activation-request:{bundle.digest}",
        signature=bundle.signature,
        site_id=site_manifest["site_id"],
        bundle_ref=str(bundle.id),
        profile_ref=bundle.profile_ref,
        requested_mode=mode,
        customer_authority_ref=site_manifest["customer_authority_ref"],
    )


def _run_preflight_checks(
    *,
    out_dir: Path,
    site_manifest: dict[str, Any],
    toolchain_record: dict[str, Any],
    support_bundle_path: Path,
    site_policy_overlay_path: Path | None,
) -> dict[str, Any]:
    passed: list[str] = []
    failed: list[str] = []

    if sys.platform:
        passed.append("os_filesystem_permission_check")
    else:
        failed.append("os_filesystem_permission_check")

    if Path(sys.executable).exists():
        passed.append("python_runtime_dependency_check")
    else:
        failed.append("python_runtime_dependency_check")

    try:
        out_dir.mkdir(parents=True, exist_ok=True)
        probe = out_dir / ".write_probe"
        probe.write_text("ok", encoding="utf-8")
        probe.unlink()
        passed.append("local_storage_availability")
    except Exception:
        failed.append("local_storage_availability")

    if toolchain_record.get("deployment_profile", {}).get("profile_id"):
        passed.append("network_policy_conformance")
        passed.append("backend_policy_conformance")
    else:
        failed.append("network_policy_conformance")
        failed.append("backend_policy_conformance")

    audit_dir = Path(site_manifest["audit_log_dir"])
    if audit_dir.exists() and audit_dir.is_dir():
        passed.append("audit_log_path_check")
    else:
        failed.append("audit_log_path_check")

    binaries = toolchain_record.get("binaries", {})
    if all(meta.get("exists", True) for meta in binaries.values()):
        passed.append("required_tool_path_check")
    else:
        failed.append("required_tool_path_check")

    if site_manifest.get("requested_adapters"):
        passed.append("profile_adapter_availability")
    else:
        failed.append("profile_adapter_availability")

    if site_policy_overlay_path is None or site_policy_overlay_path.exists():
        passed.append("site_policy_overlay_validity")
    else:
        failed.append("site_policy_overlay_validity")

    if support_bundle_path.exists() and Path(site_manifest["support_bundle_dir"]).exists():
        passed.append("support_bundle_path_check")
    else:
        failed.append("support_bundle_path_check")

    adjudication = toolchain_record.get("environment_adjudication", {})
    if adjudication.get("fail_closed"):
        failed.append("environment_adjudication_fail_closed")

    return {
        "passed": not failed,
        "checks_passed": passed,
        "checks_failed": failed,
    }


def _run_smoke_checks(*, out_dir: Path, site_manifest: dict[str, Any], dry_run: bool) -> dict[str, Any]:
    passed: list[str] = []
    blocked: list[str] = []

    passed.append("runtime_load")
    passed.append("profile_read")
    passed.append("policy_read")

    schema_paths = [
        Path("package_ws/registries/schema_registry/customer_site_activation.schema.json"),
        Path("package_ws/registries/schema_registry/site_runtime_manifest.schema.json"),
        Path("package_ws/registries/schema_registry/activation_decision_record.schema.json"),
        Path("package_ws/registries/schema_registry/site_readiness_report.schema.json"),
    ]
    if all(path.exists() for path in schema_paths):
        passed.append("object_schema_validation")
    else:
        blocked.append("object_schema_validation_failed")

    try:
        subprocess.run(
            [sys.executable, "-c", "print('v15_smoke_ok')"],
            check=True,
            capture_output=True,
            text=True,
        )
        passed.append("minimal_bounded_command")
    except Exception:
        blocked.append("minimal_bounded_command_failed")

    try:
        audit_note = Path(site_manifest["audit_log_dir"]) / ("dry_run_audit.log" if dry_run else "activation_audit.log")
        audit_note.write_text("v15 audit marker\n", encoding="utf-8")
        passed.append("audit_record_write")
    except Exception:
        blocked.append("audit_record_write_failed")

    try:
        support_note = Path(site_manifest["support_bundle_dir"]) / ("dry_run_support_export.json" if dry_run else "support_export.json")
        support_note.write_text(json.dumps({"status": "DRY_RUN" if dry_run else "REAL_RUN"}, indent=2), encoding="utf-8")
        passed.append("support_bundle_dry_run")
    except Exception:
        blocked.append("support_bundle_dry_run_failed")

    return {
        "passed": not blocked,
        "checks": passed,
        "blocked_reasons": blocked,
    }


def run_site_activation(
    *,
    bundle_path: Path,
    profile_id: str,
    site_manifest_path: Path,
    mode: str,
    dry_run: bool,
    emit_evidence: bool,
) -> dict[str, Any]:
    bundle = RuntimeDistributionBundle.model_validate(_read_json(bundle_path))
    site_manifest = _read_json(site_manifest_path)
    product_manifest = ProductManifest.model_validate(_read_json(Path(site_manifest["product_manifest_path"])))
    support_bundle = SupportAuditBundle.model_validate(_read_json(Path(site_manifest["support_bundle_path"])))
    overlay_path = Path(site_manifest["site_policy_overlay_path"]) if site_manifest.get("site_policy_overlay_path") else None
    overlay = SitePolicyOverlay.model_validate(_read_json(overlay_path)) if overlay_path else None
    decision_record_path = Path(site_manifest["activation_decision_record_path"]) if site_manifest.get("activation_decision_record_path") else None
    decision_record = ActivationDecisionRecord.model_validate(_read_json(decision_record_path)) if decision_record_path and decision_record_path.exists() else None

    customer_org_manifest = None
    org_issues: list[str] = []
    if site_manifest.get("customer_org_manifest_path"):
        customer_org_manifest = CustomerOrgManifest.model_validate(
            _read_json(Path(site_manifest["customer_org_manifest_path"]))
        )
        org_issues = validate_activation_roles(customer_org_manifest, site_id=site_manifest["site_id"])
    run_out_dir = Path(site_manifest["output_dir"]) / ("dry-run" if dry_run else "real-run")

    toolchain_record = resolve_toolchain_profile({"deployment_profile": profile_id})
    if emit_evidence:
        write_toolchain_resolution_artifact(run_out_dir, toolchain_record)

    verifier = RuntimeBundleVerifier()
    verification = verifier.verify_bundle(
        bundle=bundle,
        product_manifest=product_manifest,
        profile=_build_profile(profile_id),
        trust_root_ref=site_manifest["trust_root_ref"],
        requested_adapters=site_manifest.get("requested_adapters", []),
        site_policy_overlay=overlay,
        support_bundle=support_bundle,
        context_ref=f"activation://{site_manifest['site_id']}",
    )

    request = _build_request(site_manifest, bundle, mode)
    preflight = _run_preflight_checks(
        out_dir=run_out_dir,
        site_manifest=site_manifest,
        toolchain_record=toolchain_record,
        support_bundle_path=Path(site_manifest["support_bundle_path"]),
        site_policy_overlay_path=overlay_path,
    )
    smoke = _run_smoke_checks(out_dir=run_out_dir, site_manifest=site_manifest, dry_run=dry_run) if preflight["passed"] else {
        "passed": False,
        "checks": [],
        "blocked_reasons": ["preflight_failed"],
    }

    engine = SiteActivationEngine()
    activation = engine.run_to_review_with_verification(
        request=request,
        verification=verification,
        required_roles_present=bool(site_manifest.get("customer_authority_ref")) and not org_issues,
        preflight_passed=preflight["passed"],
        smoke_passed=smoke["passed"],
        support_boundary_defined=bool(site_manifest.get("support_bundle_dir")),
    )

    if activation.current_state == "READY_FOR_ACTIVATION_REVIEW" and decision_record:
        activation = engine.finalize_activation(
            review_ready=activation,
            decision_record=decision_record,
        )

    bootstrap_run_record = BootstrapRunRecord(
        version="0.1",
        status=ObjectStatus.ACTIVE,
        authority_class=AuthorityClass.SYSTEM,
        producer="v15-site-activation-runner@0.1",
        digest=f"sha256:bootstrap:{bundle.digest}:{'dry' if dry_run else 'real'}",
        signature=bundle.signature,
        site_id=site_manifest["site_id"],
        activation_request_ref=str(request.id),
        mode=mode,
        dry_run=dry_run,
        result=activation.current_state.value,
    )
    preflight_report = SitePreflightReport(
        version="0.1",
        status=ObjectStatus.ACTIVE,
        authority_class=AuthorityClass.SYSTEM,
        producer="v15-site-activation-runner@0.1",
        digest=f"sha256:preflight:{bundle.digest}",
        signature=bundle.signature,
        site_id=site_manifest["site_id"],
        activation_request_ref=str(request.id),
        checks_passed=preflight["checks_passed"],
        checks_failed=preflight["checks_failed"],
        verdict="PASS" if preflight["passed"] else "BLOCKED",
    )
    smoke_record = SiteSmokeRunRecord(
        version="0.1",
        status=ObjectStatus.ACTIVE,
        authority_class=AuthorityClass.SYSTEM,
        producer="v15-site-activation-runner@0.1",
        digest=f"sha256:smoke:{bundle.digest}",
        signature=bundle.signature,
        site_id=site_manifest["site_id"],
        activation_request_ref=str(request.id),
        scenario_id="v15-bootstrap-smoke",
        verdict="PASS" if smoke["passed"] else "BLOCKED",
        evidence_refs=smoke["checks"],
    )
    readiness_report = SiteReadinessReport(
        version="0.1",
        status=ObjectStatus.ACTIVE,
        authority_class=AuthorityClass.SYSTEM,
        producer="v15-site-activation-runner@0.1",
        digest=f"sha256:readiness:{bundle.digest}",
        signature=bundle.signature,
        site_id=site_manifest["site_id"],
        activation_request_ref=str(request.id),
        readiness_verdict="PASS" if activation.current_state.value == "READY_FOR_ACTIVATION_REVIEW" else "BLOCKED",
        blocked_reasons=[reason.value for reason in activation.fail_closed_reasons] + org_issues,
    )

    deliverables = {
        "bootstrap_run_record": _write_json(run_out_dir / "bootstrap_run_record.json", bootstrap_run_record.model_dump(mode="json")),
        "site_environment_fingerprint": _write_json(run_out_dir / "site_environment_fingerprint.json", toolchain_record.get("environment_fingerprint", {})),
        "site_preflight_report": _write_json(run_out_dir / "site_preflight_report.json", preflight_report.model_dump(mode="json")),
        "site_smoke_run_record": _write_json(run_out_dir / "site_smoke_run_record.json", smoke_record.model_dump(mode="json")),
        "site_readiness_report": _write_json(run_out_dir / "site_readiness_report.json", readiness_report.model_dump(mode="json")),
        "package_verification_report": _write_json(
            run_out_dir / "package_verification_report.json",
            {
                "allowed": verification.allowed,
                "blocking_reasons": verification.blocking_reasons,
                "gate_results": [result.model_dump(mode="json") for result in verification.gate_results],
            },
        ),
        "deployment_profile_binding": _write_json(run_out_dir / "deployment_profile_binding.json", verification.profile_binding.model_dump(mode="json")),
        "site_policy_overlay_binding": _write_json(run_out_dir / "site_policy_overlay_binding.json", verification.policy_binding.model_dump(mode="json")),
        "forbidden_capability_check": _write_json(
            run_out_dir / "forbidden_capability_check.json",
            next(
                (result.model_dump(mode="json") for result in verification.gate_results if result.gate_name == "profile_compliance"),
                {},
            ),
        ),
    }
    return {
        "activation_state": activation.current_state.value,
        "blocked_reasons": [reason.value for reason in activation.fail_closed_reasons] + org_issues,
        "org_issues": org_issues,
        "deliverables": deliverables,
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bundle", required=True)
    parser.add_argument("--profile", required=True)
    parser.add_argument("--site-manifest", required=True)
    parser.add_argument("--decision-record", required=False, help="Path to activation_decision_record.json")
    parser.add_argument("--mode", required=True, choices=["solo_eval", "team_project", "enterprise_site"])
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--emit-evidence", action="store_true")
    args = parser.parse_args(argv)

    if args.decision_record:
        manifest_data = _read_json(Path(args.site_manifest))
        manifest_data["activation_decision_record_path"] = args.decision_record
        _write_json(Path(args.site_manifest), manifest_data)

    result = run_site_activation(
        bundle_path=Path(args.bundle),
        profile_id=args.profile,
        site_manifest_path=Path(args.site_manifest),
        mode=args.mode,
        dry_run=args.dry_run,
        emit_evidence=args.emit_evidence,
    )
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
