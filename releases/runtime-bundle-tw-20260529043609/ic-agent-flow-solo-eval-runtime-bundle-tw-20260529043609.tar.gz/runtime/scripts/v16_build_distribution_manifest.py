#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bundle-ref", required=True)
    parser.add_argument("--distribution-mode", default="BINARY_RUNTIME")
    parser.add_argument("--asset", action="append", required=True)
    parser.add_argument("--emit", required=True)
    args = parser.parse_args(argv)

    payload = {
        "manifest_id": f"manifest://{args.bundle_ref}",
        "bundle_ref": args.bundle_ref,
        "distribution_mode": args.distribution_mode,
        "included_assets": args.asset,
        "excluded_assets": ["package_ws/", "internal-redacted/", "tests/"],
        "sbom_ref": f"sbom://{args.bundle_ref}",
        "checksum_set_ref": f"checksum://{args.bundle_ref}",
        "signature": f"sig://{args.bundle_ref}",
    }
    output = Path(args.emit)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
