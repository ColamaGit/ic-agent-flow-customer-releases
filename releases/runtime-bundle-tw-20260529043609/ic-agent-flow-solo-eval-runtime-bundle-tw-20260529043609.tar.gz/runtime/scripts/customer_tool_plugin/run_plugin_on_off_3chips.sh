#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

resolve_root_dir() {
  local d="$SCRIPT_DIR"
  while [[ "$d" != "/" ]]; do
    if [[ -f "$d/runtime/scripts/governance_pipeline_runner.py" ]]; then
      echo "$d"
      return 0
    fi
    if [[ -f "$d/shared-runtime/scripts/governance_pipeline_runner.py" ]]; then
      echo "$d"
      return 0
    fi
    d="$(dirname "$d")"
  done
  return 1
}

ROOT_DIR="$(resolve_root_dir)"
cd "$ROOT_DIR"

PY="./.venv/bin/python"
RUNNER="runtime/scripts/governance_pipeline_runner.py"
VALIDATOR="runtime/scripts/customer_tool_plugin/validate_plugin_flow_3chips.py"
SKILL_BACKFLOW_VALIDATOR="runtime/scripts/validate_latest_3chip_skill_backflow.py"
SCHEMA_GATE="runtime/scripts/validate_schemas.py"
if [[ ! -f "$RUNNER" ]]; then
  RUNNER="shared-runtime/scripts/governance_pipeline_runner.py"
  VALIDATOR="shared-runtime/scripts/customer_tool_plugin/validate_plugin_flow_3chips.py"
  SKILL_BACKFLOW_VALIDATOR="shared-runtime/scripts/validate_latest_3chip_skill_backflow.py"
  SCHEMA_GATE="shared-runtime/scripts/validate_schemas.py"
fi

if [[ ! -x "$PY" ]]; then
  echo "ERROR: .venv python not found: $PY" >&2
  exit 2
fi

echo "[plugin-flow] Step 0: schema gate"
"$PY" "$SCHEMA_GATE"

echo "[plugin-flow] Step 1: plugin ON (real 3-chip pipeline run)"
ICAF_DEPLOYMENT_PROFILE=airgap-local \
ICAF_V116_PLUGIN_ENABLE=1 \
ICAF_V116_PLUGIN_STAGE=new_plugin_eda \
ICAF_V116_PLUGIN_INSERT_BEFORE=h4_klayout \
"$PY" "$RUNNER"

echo "[plugin-flow] Step 2: plugin OFF (real 3-chip pipeline run)"
ICAF_DEPLOYMENT_PROFILE=airgap-local \
ICAF_V116_PLUGIN_ENABLE=0 \
"$PY" "$RUNNER"

echo "[plugin-flow] Step 3: on/off validation"
python3 "$VALIDATOR"

echo "[plugin-flow] Step 4: latest 3-chip skill_backflow validation"
"$PY" "$SKILL_BACKFLOW_VALIDATOR"

echo "[plugin-flow] DONE: real plugin on/off + skill_backflow validation completed"
