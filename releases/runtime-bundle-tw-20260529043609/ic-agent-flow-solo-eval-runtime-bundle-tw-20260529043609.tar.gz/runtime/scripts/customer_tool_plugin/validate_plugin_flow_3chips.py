from __future__ import annotations

import json
import re
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

def _resolve_root() -> Path:
    here = Path(__file__).resolve()
    for parent in [here.parent] + list(here.parents):
        if (parent / "artifacts").exists() and (
            (parent / "runtime" / "scripts").exists()
            or (parent / "workspace" / "shared-runtime" / "scripts").exists()
        ):
            return parent
    return here.parents[3]


ROOT = _resolve_root()

TARGETS = [
    ("test-chip-02", "T-SN2025-01"),
    ("uart-controller-v0.1", "T-UART-001"),
    ("async-fifo-v0.1", "T-FIFO-001"),
]
RUN_RE = re.compile(r"^\d{8}-\d{6}$")


def _now() -> str:
    return datetime.now(ZoneInfo("Asia/Taipei")).isoformat(timespec="seconds")


def _runs(base: Path) -> list[Path]:
    return sorted([p for p in base.iterdir() if p.is_dir() and RUN_RE.match(p.name)], key=lambda p: p.name)


def _stage_dirs(run_dir: Path) -> list[str]:
    return sorted([p.name for p in run_dir.iterdir() if p.is_dir() and re.match(r"^\d{2}_", p.name)])


def _must_find_prefix(stages: list[str], prefix: str) -> str:
    for s in stages:
        if s.endswith(prefix):
            return s
    raise AssertionError(f"missing stage {prefix}")


def main() -> None:
    out_dir = ROOT / "artifacts" / "customer-plugin-validation"
    out_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    for chip, task in TARGETS:
        base = ROOT / "artifacts/production-runs" / chip / task
        rr = _runs(base)
        if len(rr) < 2:
            raise RuntimeError(f"{chip}/{task} needs at least two runs (plugin-on then plugin-off)")
        plugin_on = rr[-2]
        plugin_off = rr[-1]
        s_on = _stage_dirs(plugin_on)
        s_off = _stage_dirs(plugin_off)

        on_plugin = _must_find_prefix(s_on, "new_plugin_eda")
        on_h4 = _must_find_prefix(s_on, "h4_klayout")
        off_h4 = _must_find_prefix(s_off, "h4_klayout")
        off_has_plugin = any(x.endswith("new_plugin_eda") for x in s_off)

        rows.append(
            {
                "chip_id": chip,
                "task_id": task,
                "plugin_on_run": plugin_on.name,
                "plugin_off_run": plugin_off.name,
                "plugin_on_stage": on_plugin,
                "plugin_on_h4_stage": on_h4,
                "plugin_before_h4_when_on": int(on_plugin.split("_", 1)[0]) < int(on_h4.split("_", 1)[0]),
                "plugin_off_has_no_plugin_stage": not off_has_plugin,
                "plugin_off_h4_stage": off_h4,
            }
        )

    ok = all(r["plugin_before_h4_when_on"] and r["plugin_off_has_no_plugin_stage"] for r in rows)
    payload = {
        "schema_version": "customer-plugin-flow-3chips-validation.v1",
        "generated_at": _now(),
        "overall_verdict": "PASS" if ok else "BLOCKED",
        "results": rows,
    }
    jpath = out_dir / "plugin_flow_3chips_validation.json"
    jpath.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    lines = [
        "# Customer Plugin Flow 3-Chip Validation",
        "",
        f"- generated_at: `{payload['generated_at']}`",
        f"- overall_verdict: `{payload['overall_verdict']}`",
        "",
        "| chip | task | plugin-on run | plugin-off run | plugin inserted before h4 | plugin removed when off |",
        "| --- | --- | --- | --- | --- | --- |",
    ]
    for r in rows:
        lines.append(
            f"| `{r['chip_id']}` | `{r['task_id']}` | `{r['plugin_on_run']}` | `{r['plugin_off_run']}` | "
            f"{'PASS' if r['plugin_before_h4_when_on'] else 'FAIL'} | "
            f"{'PASS' if r['plugin_off_has_no_plugin_stage'] else 'FAIL'} |"
        )
        lines.append(f"| stage detail |  | `{r['plugin_on_stage']}` vs `{r['plugin_on_h4_stage']}` | `{r['plugin_off_h4_stage']}` |  |  |")
    (out_dir / "plugin_flow_3chips_validation.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(payload["overall_verdict"])


if __name__ == "__main__":
    main()
