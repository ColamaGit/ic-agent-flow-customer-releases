#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

from ic_agent_flow.governance.controlled_distribution import DistributionMode
from ic_agent_flow.governance.source_escrow_policy import SourceEscrowPolicyValidator, SourceEscrowRecord


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--escrow-record", required=True)
    parser.add_argument("--source", action="append", required=True)
    parser.add_argument("--emit", required=True)
    args = parser.parse_args(argv)

    data = json.loads(Path(args.escrow_record).read_text(encoding="utf-8"))
    data["distribution_mode"] = DistributionMode(data["distribution_mode"])
    record = SourceEscrowRecord(**data)
    report = SourceEscrowPolicyValidator().validate_source_package(
        distribution_mode=DistributionMode.SOURCE_ESCROW,
        included_source_refs=args.source,
        escrow_record=record,
    )
    output = Path(args.emit)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report.audit_report, indent=2), encoding="utf-8")
    return 0 if report.allowed else 2


if __name__ == "__main__":
    raise SystemExit(main())
