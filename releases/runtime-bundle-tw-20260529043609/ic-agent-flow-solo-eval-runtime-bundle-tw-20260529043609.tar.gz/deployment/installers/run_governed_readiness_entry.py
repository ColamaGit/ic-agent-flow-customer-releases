#!/usr/bin/env python3
from __future__ import annotations

import importlib.util
import json
import os
import sys
from contextlib import redirect_stdout
import io
from pathlib import Path


def _candidate_runner_paths(repo_root: Path) -> list[Path]:
    candidates: list[Path] = []
    if os.environ.get("ICAF_GOVERNED_RUNTIME_MODULE"):
        candidates.append(Path(os.environ["ICAF_GOVERNED_RUNTIME_MODULE"]))
    candidates.append(repo_root / "deployment" / "runtime" / "governance_pipeline_runner.py")
    candidates.append(repo_root / "workspace" / "shared-runtime" / "scripts" / "governance_pipeline_runner.py")
    return candidates


def _load_governed_runner(repo_root: Path):
    for candidate in _candidate_runner_paths(repo_root):
        if not candidate.exists():
            continue
        spec = importlib.util.spec_from_file_location("release_bound_governed_runner", candidate)
        module = importlib.util.module_from_spec(spec)
        assert spec.loader is not None
        spec.loader.exec_module(module)
        return module
    raise FileNotFoundError(
        "no release-bound governed runtime entrypoint could be resolved; "
        "expected deployment/runtime or explicitly configured runtime module"
    )


def _resolve_readiness_artifact_paths(run_path: Path) -> tuple[Path, Path]:
    prefixed_reports = sorted(p for p in run_path.iterdir() if p.is_dir() and p.name.endswith("_reports"))
    reports_dir = prefixed_reports[0] if prefixed_reports else run_path / "22_reports"
    primary_report = reports_dir / "readiness_report.v0.2.md"
    primary_manifest = reports_dir / "readiness_report_manifest.v0.2.json"
    if not (primary_report.exists() and primary_manifest.exists()):
        raise FileNotFoundError(
            f"expected canonical readiness artifacts missing under run dir: {reports_dir}"
        )
    return primary_report, primary_manifest


def main(argv: list[str] | None = None) -> int:
    args = argv if argv is not None else sys.argv[1:]
    if len(args) != 1:
        raise SystemExit("usage: run_governed_readiness_entry.py '<json-payload>'")
    payload = json.loads(args[0])
    repo_root = Path(payload["repo_root"]).resolve()
    runner_mod = _load_governed_runner(repo_root)
    os.environ.setdefault("ICAF_KLAYOUT_PYTHON_BIN", sys.executable)
    internal_stdout = io.StringIO()
    with redirect_stdout(internal_stdout):
        run_dir = runner_mod.run_governed_pipeline(
            chip_id=payload["chip_id"],
            task_id=payload["task_id"],
            rtl_src=payload["rtl_src"],
            chip_name=payload["chip_name"],
            rtl_function=payload["rtl_function"],
            technology_context=payload.get("technology_context", "SKY130 / OpenLane baseline"),
        )
    if internal_stdout.getvalue():
        print(internal_stdout.getvalue(), file=sys.stderr, end="")
    run_path = Path(run_dir)
    report_path, manifest_path = _resolve_readiness_artifact_paths(run_path)
    result = {
        "status": "PASS",
        "run_dir": str(run_path),
        "readiness_report": str(report_path),
        "readiness_manifest": str(manifest_path),
    }
    print(json.dumps(result, ensure_ascii=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
