#!/usr/bin/env python3
"""Rerun package-local console validation from an extracted customer package.

The entrypoint is intentionally package-root scoped: it reads only
``product/console`` and ``customer-seed`` under ``--package-root`` and writes
support-friendly evidence JSON under ``--evidence-root``.
"""

from __future__ import annotations

import argparse
import http.server
import json
import socketserver
import sys
import threading
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any


REQUIRED_ROUTES = [
    "/package-builds",
    "/artifacts",
    "/run-detail",
    "/knowledge-assets",
]

OPTIONAL_ROUTES = [
    "/package-readiness",
    "/downstream-decision-control",
    "/signoff-readiness",
    "/tapeout-package",
    "/silicon-feedback",
]

FORBIDDEN_PATTERNS = [
    "/customer-home/",
    "/customer-home/",
    "package_ws/",
    "internal-redacted/",
    "source_ref",
]


@dataclass(frozen=True)
class CheckResult:
    name: str
    status: str
    details: dict[str, Any]


class SpaFallbackHandler(http.server.SimpleHTTPRequestHandler):
    """Serve static console assets and fall back SPA routes to index.html."""

    def log_message(self, format: str, *args: object) -> None:  # noqa: A003
        return

    def send_head(self):  # type: ignore[no-untyped-def]
        path = self.translate_path(self.path)
        if Path(path).is_file() or Path(path).is_dir():
            return super().send_head()
        self.path = "/index.html"
        return super().send_head()


def _read_json(path: Path) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return payload if isinstance(payload, dict) else {}


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def _relative(path: Path, root: Path) -> str:
    try:
        return path.relative_to(root).as_posix()
    except ValueError:
        return path.as_posix()


def _scan_forbidden_text(paths: list[Path], *, package_root: Path) -> dict[str, Any]:
    hits: list[dict[str, str]] = []
    scanned_files = 0
    for path in paths:
        if not path.exists() or not path.is_file():
            continue
        scanned_files += 1
        text = path.read_text(encoding="utf-8", errors="ignore")
        for pattern in FORBIDDEN_PATTERNS:
            if pattern in text:
                hits.append({"path": _relative(path, package_root), "pattern": pattern})
    return {
        "verdict": "PASS" if not hits else "BLOCKED",
        "scanned_files": scanned_files,
        "forbidden_patterns": FORBIDDEN_PATTERNS,
        "hits": hits,
    }


def _start_console_server(console_root: Path) -> tuple[socketserver.TCPServer, str]:
    handler = lambda *args, **kwargs: SpaFallbackHandler(*args, directory=str(console_root), **kwargs)
    server = socketserver.TCPServer(("127.0.0.1", 0), handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    host, port = server.server_address
    return server, f"http://{host}:{port}"


def _fetch_route(base_url: str, route: str) -> dict[str, Any]:
    url = f"{base_url}{route}"
    started = time.time()
    try:
        with urllib.request.urlopen(url, timeout=8) as response:
            body = response.read().decode("utf-8", errors="ignore")
            status_code = int(response.status)
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="ignore")
        status_code = int(exc.code)
    except Exception as exc:  # pragma: no cover - exercised by subprocess tests
        return {
            "route": route,
            "status": "BLOCKED",
            "error": str(exc),
            "duration_ms": int((time.time() - started) * 1000),
        }

    leak_hits = [pattern for pattern in FORBIDDEN_PATTERNS if pattern in body]
    has_app_shell = "<!doctype html" in body.lower() or "<div id=\"root\"" in body
    return {
        "route": route,
        "status": "PASS" if status_code == 200 and has_app_shell and not leak_hits else "BLOCKED",
        "http_status": status_code,
        "app_shell": has_app_shell,
        "body_bytes": len(body.encode("utf-8")),
        "leak_hits": leak_hits,
        "duration_ms": int((time.time() - started) * 1000),
    }


def _seed_content_report(package_root: Path, mode: str) -> dict[str, Any]:
    seed_root = package_root / "customer-seed"
    seed_index = _read_json(seed_root / "customer_seed_console_index.json")
    run_manifest = _read_json(seed_root / "example_run_seed_manifest.json")
    knowledge_rows = _read_json(seed_root / "knowledge-assets" / "customer_safe_knowledge_asset_rows.json")
    skill_rows = _read_json(seed_root / "skills" / "customer_safe_skill_rows.json")

    chips = run_manifest.get("chips", [])
    knowledge = knowledge_rows.get("rows", [])
    skills = skill_rows.get("rows", [])
    checks = [
        CheckResult("seed_index_present", "PASS" if seed_index else "BLOCKED", {"path": "customer-seed/customer_seed_console_index.json"}),
        CheckResult("example_runs_present", "PASS" if isinstance(chips, list) and chips else "BLOCKED", {"count": len(chips) if isinstance(chips, list) else 0}),
        CheckResult("knowledge_assets_present", "PASS" if isinstance(knowledge, list) and knowledge else "BLOCKED", {"count": len(knowledge) if isinstance(knowledge, list) else 0}),
        CheckResult("skill_examples_present", "PASS" if isinstance(skills, list) and skills else "BLOCKED", {"count": len(skills) if isinstance(skills, list) else 0}),
    ]
    return {
        "schema_version": "package-local-playwright-seed-content-report.v1",
        "mode": mode,
        "verdict": "PASS" if all(item.status == "PASS" for item in checks) else "BLOCKED",
        "checks": [{"name": item.name, "status": item.status, **item.details} for item in checks],
        "default_selection": seed_index.get("default_selection", {}),
        "available_pages": seed_index.get("available_pages", []),
    }


def run_validation(package_root: Path, evidence_root: Path, mode: str) -> int:
    package_root = package_root.resolve()
    evidence_root = evidence_root.resolve()
    console_root = package_root / "product" / "console"
    seed_root = package_root / "customer-seed"
    evidence_root.mkdir(parents=True, exist_ok=True)

    errors: list[str] = []
    if not package_root.exists():
        errors.append(f"missing package root: {package_root}")
    if not (console_root / "index.html").exists():
        errors.append("missing product/console/index.html")
    if not seed_root.exists():
        errors.append("missing customer-seed/")

    route_rows: list[dict[str, Any]] = []
    base_url = ""
    server: socketserver.TCPServer | None = None
    if not errors:
        server, base_url = _start_console_server(console_root)
        try:
            for route in [*REQUIRED_ROUTES, *OPTIONAL_ROUTES]:
                route_rows.append(_fetch_route(base_url, route))
        finally:
            server.shutdown()
            server.server_close()

    route_matrix = {
        "schema_version": "package-local-playwright-route-matrix.v1",
        "package_root": str(package_root),
        "mode": mode,
        "base_url": base_url,
        "required_routes": REQUIRED_ROUTES,
        "optional_routes": OPTIONAL_ROUTES,
        "routes": route_rows,
        "verdict": "PASS"
        if not errors and all(row.get("status") == "PASS" for row in route_rows if row.get("route") in REQUIRED_ROUTES)
        else "BLOCKED",
    }

    scan_paths = [
        console_root / "index.html",
        package_root / "product" / "console" / "portfolio" / "summaries" / "production_runs_inventory.json",
        seed_root / "customer_seed_console_index.json",
        seed_root / "example_run_seed_manifest.json",
        seed_root / "knowledge-assets" / "customer_safe_knowledge_asset_rows.json",
        seed_root / "skills" / "customer_safe_skill_rows.json",
    ]
    leak_scan = _scan_forbidden_text(scan_paths, package_root=package_root)
    seed_content = _seed_content_report(package_root, mode)

    error_log = {
        "schema_version": "package-local-playwright-error-log.v1",
        "errors": errors,
        "route_errors": [row for row in route_rows if row.get("status") != "PASS"],
        "verdict": "PASS" if not errors and route_matrix["verdict"] == "PASS" else "BLOCKED",
    }
    screenshot_manifest = {
        "schema_version": "package-local-playwright-screenshot-manifest.v1",
        "screenshots": [],
        "note": "No screenshots captured by the deterministic package-local static validator.",
        "verdict": "PASS",
    }
    overall = {
        "schema_version": "package-local-playwright-rerun-report.v1",
        "package_root": str(package_root),
        "mode": mode,
        "evidence_root": str(evidence_root),
        "checks": {
            "route_matrix": route_matrix["verdict"],
            "seed_content": seed_content["verdict"],
            "leak_scan": leak_scan["verdict"],
            "error_log": error_log["verdict"],
        },
    }
    overall["verdict"] = "PASS" if all(value == "PASS" for value in overall["checks"].values()) else "BLOCKED"

    _write_json(evidence_root / "package_local_playwright_route_matrix.json", route_matrix)
    _write_json(evidence_root / "package_local_playwright_seed_content_report.json", seed_content)
    _write_json(evidence_root / "package_local_playwright_error_log.json", error_log)
    _write_json(evidence_root / "package_local_playwright_screenshot_manifest.json", screenshot_manifest)
    _write_json(evidence_root / "package_local_playwright_rerun_report.json", overall)
    _write_json(evidence_root / "package_local_playwright_leak_scan_report.json", leak_scan)

    return 0 if overall["verdict"] == "PASS" else 1


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package-root", required=True, type=Path)
    parser.add_argument("--mode", default="enterprise_site")
    parser.add_argument("--evidence-root", required=True, type=Path)
    args = parser.parse_args()
    return run_validation(args.package_root, args.evidence_root, args.mode)


if __name__ == "__main__":
    raise SystemExit(main())
