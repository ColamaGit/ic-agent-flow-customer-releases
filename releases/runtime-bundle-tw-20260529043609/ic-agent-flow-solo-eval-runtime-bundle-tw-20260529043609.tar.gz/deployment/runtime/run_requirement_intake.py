from __future__ import annotations

import argparse
import hashlib
import json
import shutil
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from init_chip import init_chip


TZ_TW = timezone(timedelta(hours=8))
SUPPORTED_ATTACHMENT_SUFFIXES = {".txt", ".md", ".pdf", ".jpg", ".jpeg", ".png"}
REPO_ROOT = Path(__file__).resolve().parents[3]


def _tw_now_iso() -> str:
    return datetime.now(TZ_TW).isoformat()


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def _tokens_from_text(text: str) -> set[str]:
    return {
        token.strip("-_.,:;()[]{}")
        for token in text.lower().split()
        if token.strip("-_.,:;()[]{}")
    }


def _normalize_chip_id(raw: str) -> str:
    normalized = "".join(ch.lower() if ch.isalnum() else "_" for ch in raw).strip("_")
    normalized = "_".join(part for part in normalized.split("_") if part)
    return normalized if normalized else "chip"


def _template_keyword_map(template_name: str) -> set[str]:
    mapping = {
        "baseline-digital-soc": {"baseline", "digital", "soc", "chip", "controller"},
        "uart protocol": {"uart", "serial", "baud", "rx", "tx"},
        "asynchronous fifo": {"async", "asynchronous", "fifo", "queue", "cdc"},
        "verliog pattern generation": {"verilog", "pattern", "generator", "generation"},
    }
    key = template_name.lower()
    if key in mapping:
        return mapping[key]
    return _tokens_from_text(template_name.replace("/", " "))


def discover_templates(templates_root: Path | str) -> List[Dict[str, str]]:
    root = Path(templates_root)
    if not root.exists():
        return []

    templates: List[Dict[str, str]] = []
    for path in sorted(root.iterdir()):
        if not path.is_dir():
            continue
        templates.append({"name": path.name, "path": path.as_posix()})
    return templates


def _confidence_from_score(score: int, keyword_count: int) -> float:
    if keyword_count <= 0:
        return 0.0
    ratio = score / keyword_count
    # keep confidence bounded and human-readable for governance reports
    return round(min(1.0, max(0.0, ratio)), 3)


def _build_template_matching_candidates(
    *,
    prompt_text: str,
    attachment_paths: List[Path],
    templates_root: Path | str,
) -> List[Dict[str, object]]:
    templates = discover_templates(templates_root)
    if not templates:
        return []

    corpus = prompt_text
    if attachment_paths:
        corpus += " " + " ".join(path.name for path in attachment_paths)
    corpus_tokens = _tokens_from_text(corpus)

    candidates: List[Dict[str, object]] = []
    for template in templates:
        keywords = _template_keyword_map(template["name"])
        matched_keywords = sorted(corpus_tokens.intersection(keywords))
        score = len(matched_keywords)
        candidates.append(
            {
                "template_name": template["name"],
                "template_path": template["path"],
                "score": score,
                "confidence": _confidence_from_score(score, len(keywords)),
                "matched_keywords": matched_keywords,
            }
        )

    candidates.sort(key=lambda item: (-int(item["score"]), str(item["template_name"]).lower()))
    return candidates


def match_template(
    *,
    prompt_text: str,
    attachment_paths: List[Path],
    templates_root: Path | str,
) -> Tuple[str, Optional[str], Dict[str, object]]:
    candidates = _build_template_matching_candidates(
        prompt_text=prompt_text,
        attachment_paths=attachment_paths,
        templates_root=templates_root,
    )
    if not candidates:
        return "NO_MATCH", None, {
            "algorithm_version": "template_match.v1",
            "result": "NO_MATCH",
            "selected_template_ref": None,
            "candidates": [],
        }

    best = candidates[0]
    if int(best["score"]) <= 0:
        return "NO_MATCH", None, {
            "algorithm_version": "template_match.v1",
            "result": "NO_MATCH",
            "selected_template_ref": None,
            "candidates": candidates,
        }

    selected_ref = str(best["template_path"])
    return "MATCHED", selected_ref, {
        "algorithm_version": "template_match.v1",
        "result": "MATCHED",
        "selected_template_ref": selected_ref,
        "candidates": candidates,
    }


def _materialize_intake_session(
    *,
    chip_id: str,
    intake_session_id: str,
    prompt_text: str,
    attachment_paths: List[Path],
    template_match_result: str,
    template_ref: Optional[str],
    bootstrap_mode: str,
    template_matching: Dict[str, object],
) -> Dict:
    intake_root = REPO_ROOT / "chips" / chip_id / "specs" / "intake"
    session_dir = intake_root / intake_session_id
    attachments_dir = session_dir / "attachments"
    attachments_dir.mkdir(parents=True, exist_ok=True)
    upstream_operation_id = f"UOP-{intake_session_id}"

    prompt_path = session_dir / "prompt.txt"
    prompt_path.write_text(prompt_text, encoding="utf-8")

    attachment_entries: List[Dict[str, str]] = []
    for src in attachment_paths:
        suffix = src.suffix.lower()
        if suffix not in SUPPORTED_ATTACHMENT_SUFFIXES:
            raise ValueError(f"unsupported_attachment_format:{src.name}")
        dest = attachments_dir / src.name
        shutil.copy2(src, dest)
        attachment_entries.append(
            {
                "filename": src.name,
                "format": suffix.lstrip("."),
                "sha256_digest": _sha256_file(dest),
                "uploaded_at": _tw_now_iso(),
            }
        )

    attachment_manifest = {
        "intake_session_id": intake_session_id,
        "attachments": attachment_entries,
        "created_at": _tw_now_iso(),
    }
    (session_dir / "attachment_manifest.json").write_text(
        json.dumps(attachment_manifest, indent=2),
        encoding="utf-8",
    )

    record = {
        "scope_type": "CHIP_UPSTREAM",
        "upstream_operation_id": upstream_operation_id,
        "intake_session_id": intake_session_id,
        "chip_id": chip_id,
        "prompt_text": prompt_text,
        "attachments": attachment_entries,
        "template_match_result": template_match_result,
        "template_ref": template_ref,
        "bootstrap_mode": bootstrap_mode,
        "template_matching": template_matching,
        "created_at": _tw_now_iso(),
    }
    selected_mode = str(template_matching.get("selection_mode", "")).upper()
    if selected_mode == "MANUAL_OVERRIDE":
        template_verdict = "TEMPLATE_SELECTED"
    elif template_match_result == "MATCHED":
        template_verdict = "TEMPLATE_AUTO_RESOLVED"
    else:
        template_verdict = "TEMPLATE_DEFERRED"
    template_resolution_record = {
        "schema_version": "template-resolution-record.v1.0",
        "scope_type": "CHIP_UPSTREAM",
        "upstream_operation_id": upstream_operation_id,
        "intake_session_id": intake_session_id,
        "chip_id": chip_id,
        "verdict": template_verdict,
        "template_ref": template_ref,
        "bootstrap_mode": bootstrap_mode,
        "resolver": template_matching,
        "created_at": _tw_now_iso(),
    }
    template_resolution_path = session_dir / "template_resolution_record.json"
    template_resolution_path.write_text(
        json.dumps(template_resolution_record, indent=2),
        encoding="utf-8",
    )
    record["template_resolution_record_ref"] = template_resolution_path.as_posix()
    (session_dir / "intake_session_record.json").write_text(
        json.dumps(record, indent=2),
        encoding="utf-8",
    )
    image_attachments = [entry for entry in attachment_entries if entry["format"] in {"jpg", "jpeg", "png"}]
    if image_attachments:
        extraction_items = []
        for image in image_attachments:
            name_tokens = _tokens_from_text(image["filename"])
            signals = sorted(
                token
                for token in name_tokens
                if token in {"clock", "reset", "interface", "rx", "tx", "fifo", "uart", "cdc", "timing"}
            )
            extraction_items.append(
                {
                    "filename": image["filename"],
                    "status": "EXTRACTED_HEURISTIC",
                    "confidence": 0.45 if signals else 0.2,
                    "extracted_signals": signals,
                    "requires_human_review": True,
                }
            )
        image_extraction_report = {
            "schema_version": "intake-image-extraction-report.v0.2",
            "intake_session_id": intake_session_id,
            "status": "EXTRACTED_HEURISTIC_PENDING_ADJUDICATION",
            "image_attachments": image_attachments,
            "extraction_items": extraction_items,
            "note": "Heuristic extraction is review-assist only and never authority-bearing.",
            "created_at": _tw_now_iso(),
        }
    else:
        image_extraction_report = {
            "schema_version": "intake-image-extraction-report.v0.2",
            "intake_session_id": intake_session_id,
            "status": "NOT_APPLICABLE_NO_IMAGE_ATTACHMENT",
            "image_attachments": [],
            "extraction_items": [],
            "created_at": _tw_now_iso(),
        }
    (session_dir / "image_extraction_report.json").write_text(
        json.dumps(image_extraction_report, indent=2),
        encoding="utf-8",
    )
    upstream_operation_dir = REPO_ROOT / "chips" / chip_id / "governance" / "upstream_operations"
    upstream_operation_dir.mkdir(parents=True, exist_ok=True)
    upstream_operation_record = {
        "schema_version": "upstream-operation-record.v1.0",
        "upstream_operation_id": upstream_operation_id,
        "chip_id": chip_id,
        "scope_type": "CHIP_UPSTREAM",
        "current_node": "requirement_intake",
        "created_by": "console",
        "human_gate_required": True,
        "status": "DRAFTED",
        "input_refs": [prompt_path.as_posix()],
        "output_refs": [
            (session_dir / "intake_session_record.json").as_posix(),
            template_resolution_path.as_posix(),
            (session_dir / "attachment_manifest.json").as_posix(),
        ],
        "decision_refs": [],
        "next_action": "requirement_adjudication",
        "created_at": _tw_now_iso(),
    }
    upstream_operation_path = upstream_operation_dir / f"{upstream_operation_id}.json"
    upstream_operation_path.write_text(
        json.dumps(upstream_operation_record, indent=2),
        encoding="utf-8",
    )
    record["upstream_operation_record_ref"] = upstream_operation_path.as_posix()
    record["session_dir_ref"] = session_dir.as_posix()
    return record


def _materialize_pending_intake_record(record: Dict) -> str:
    pending_dir = REPO_ROOT / "artifacts" / "intake-sessions" / "pending"
    pending_dir.mkdir(parents=True, exist_ok=True)
    pending_path = pending_dir / f"{record['intake_session_id']}.json"
    pending_path.write_text(json.dumps(record, indent=2), encoding="utf-8")
    return pending_path.as_posix()


def _sentence_candidates(prompt_text: str) -> List[str]:
    chunks = []
    for raw in prompt_text.replace("\n", ". ").split("."):
        sentence = raw.strip()
        if sentence:
            chunks.append(sentence)
    return chunks


def _infer_requirement_group(text: str) -> str:
    lower = text.lower()
    if "reset" in lower:
        return "reset"
    if "clock" in lower or "timing" in lower:
        return "timing"
    if "interface" in lower or "rx" in lower or "tx" in lower or "io" in lower:
        return "interface"
    if "verify" in lower or "test" in lower or "coverage" in lower:
        return "verification"
    return "functional"


def _infer_priority(text: str) -> str:
    lower = text.lower()
    if "must" in lower or "shall" in lower:
        return "MUST"
    if "should" in lower:
        return "SHOULD"
    return "MUST"


def _materialize_requirement_item_auto_draft(
    *,
    chip_id: str,
    prompt_text: str,
    session_dir_ref: str,
    attachment_entries: List[Dict[str, str]],
) -> str:
    specs_dir = REPO_ROOT / "chips" / chip_id / "specs"
    specs_dir.mkdir(parents=True, exist_ok=True)

    prompt_ref = f"{session_dir_ref}/prompt.txt"
    attachment_refs = [f"{session_dir_ref}/attachments/{entry['filename']}" for entry in attachment_entries]
    source_refs = [prompt_ref] + attachment_refs

    requirement_items = []
    for idx, sentence in enumerate(_sentence_candidates(prompt_text), start=1):
        requirement_items.append(
            {
                "requirement_id": f"REQ-{chip_id.upper().replace('-', '_')}-{idx:03d}",
                "title": sentence[:72],
                "priority": _infer_priority(sentence),
                "group": _infer_requirement_group(sentence),
                "description": sentence,
                "ambiguity_status": "OPEN",
                "ambiguity_note": "Auto-drafted from intake prompt; human adjudication required.",
                "source_ref": prompt_ref,
            }
        )

    if not requirement_items:
        requirement_items.append(
            {
                "requirement_id": f"REQ-{chip_id.upper().replace('-', '_')}-001",
                "title": "Intake placeholder requirement",
                "priority": "MUST",
                "group": "functional",
                "description": "Auto draft placeholder. Prompt content was empty.",
                "ambiguity_status": "OPEN",
                "ambiguity_note": "Human refinement required.",
                "source_ref": prompt_ref,
            }
        )

    payload = {
        "schema_version": "requirement-item-pack.v1.0",
        "chip_id": chip_id,
        "draft_status": "AUTO_DRAFT_PENDING_REVIEW",
        "source_refs": source_refs,
        "requirement_items": requirement_items,
        "generated_at": _tw_now_iso(),
    }
    out_path = specs_dir / "requirement_item.json"
    out_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return out_path.as_posix()


def _materialize_requirement_and_image_review_packages(
    *,
    chip_id: str,
    intake_session_id: str,
    session_dir_ref: str,
    requirement_item_ref: str,
    image_extraction_report_ref: str,
    builder_handoff_ref: str,
    prompt_text: str,
    template_matching: Dict[str, object],
) -> Dict[str, str]:
    specs_dir = REPO_ROOT / "chips" / chip_id / "specs"
    specs_dir.mkdir(parents=True, exist_ok=True)

    review_package_path = specs_dir / "requirement_item_review_package.json"
    adjudication_template_path = specs_dir / "requirement_item_adjudication_record.template.json"
    next_steps_prefill_path = specs_dir / "intake_next_steps_prefill.json"

    review_package_payload = {
        "schema_version": "requirement-item-review-package.v1.0",
        "chip_id": chip_id,
        "intake_session_id": intake_session_id,
        "requirement_item_ref": requirement_item_ref,
        "source_session_ref": session_dir_ref,
        "builder_handoff_ref": builder_handoff_ref,
        "candidate_decisions": [
            "approve",
            "approve_with_conditions",
            "request_more_evidence",
            "reject",
        ],
        "authority_required": True,
        "status": "PENDING_HUMAN_ADJUDICATION",
        "created_at": _tw_now_iso(),
    }
    review_package_path.write_text(json.dumps(review_package_payload, indent=2), encoding="utf-8")

    adjudication_template_payload = {
        "schema_version": "requirement-item-adjudication-record.v1.0",
        "chip_id": chip_id,
        "intake_session_id": intake_session_id,
        "review_package_ref": review_package_path.as_posix(),
        "requirement_item_ref": requirement_item_ref,
        "decision_outcome": None,
        "decision_rationale": None,
        "authority_signer": None,
        "conditions": [],
        "conditions_suggested": [
            "Close ambiguity for baud/frame/FIFO-threshold/CDC/throughput-latency/error-handling.",
            "Ensure requirement_item acceptance criteria are machine-checkable.",
            "Keep builder handoff status aligned with adjudication outcome.",
        ],
        "needs_reentry": False,
        "status": "PENDING_DECISION",
        "created_at": _tw_now_iso(),
    }
    adjudication_template_path.write_text(
        json.dumps(adjudication_template_payload, indent=2),
        encoding="utf-8",
    )

    image_review_package_path = Path(session_dir_ref) / "image_extraction_review_package.json"
    image_review_package_payload = {
        "schema_version": "image-extraction-review-package.v1.0",
        "chip_id": chip_id,
        "intake_session_id": intake_session_id,
        "image_extraction_report_ref": image_extraction_report_ref,
        "authority_class": "REVIEW_ASSIST_ONLY",
        "candidate_decisions": [
            "accept_as_hint",
            "request_more_evidence",
            "discard_extraction",
        ],
        "authority_required": True,
        "non_authority_note": "Extraction output is review-assist only and cannot become canonical truth by itself.",
        "status": "PENDING_HUMAN_REVIEW",
        "created_at": _tw_now_iso(),
    }
    image_review_package_path.write_text(
        json.dumps(image_review_package_payload, indent=2),
        encoding="utf-8",
    )

    prompt_tokens = _tokens_from_text(prompt_text)
    selected_template = str(template_matching.get("selected_template_ref") or "").lower()
    uart_fifo_focus = ("uart" in prompt_tokens and "fifo" in prompt_tokens) or ("uart" in selected_template and "fifo" in selected_template)

    next_steps_prefill_payload = {
        "schema_version": "intake-next-steps-prefill.v1.0",
        "chip_id": chip_id,
        "intake_session_id": intake_session_id,
        "status": "AUTO_PREFILL_READY_FOR_HUMAN_REVIEW",
        "review_targets": {
            "requirement_item_ref": requirement_item_ref,
            "review_package_ref": review_package_path.as_posix(),
            "adjudication_template_ref": adjudication_template_path.as_posix(),
            "builder_handoff_ref": builder_handoff_ref,
        },
        "required_followups": [
            "Intake human review",
            "Adjudication decision",
            "Route A builder draft/handoff consistency check",
        ],
        "verification_focus": (
            [
                "UART baud range",
                "frame format (data bits / parity / stop bits)",
                "FIFO depth and almost_full/almost_empty thresholds",
                "CDC boundary (write_clk/read_clk/reset)",
                "throughput / latency / error handling",
            ]
            if uart_fifo_focus
            else [
                "Interface behavior and protocol constraints",
                "clock/reset and CDC boundary",
                "throughput/latency/error handling",
            ]
        ),
        "generated_at": _tw_now_iso(),
    }
    next_steps_prefill_path.write_text(
        json.dumps(next_steps_prefill_payload, indent=2),
        encoding="utf-8",
    )
    _materialize_human_review_markdown_companions(
        chip_id=chip_id,
        intake_session_id=intake_session_id,
        requirement_item_ref=requirement_item_ref,
        review_package_path=review_package_path,
        adjudication_template_path=adjudication_template_path,
        builder_handoff_ref=builder_handoff_ref,
        review_status=review_package_payload["status"],
        candidate_decisions=review_package_payload["candidate_decisions"],
        conditions_suggested=adjudication_template_payload["conditions_suggested"],
    )

    return {
        "requirement_item_review_package_ref": review_package_path.as_posix(),
        "requirement_item_adjudication_template_ref": adjudication_template_path.as_posix(),
        "image_extraction_review_package_ref": image_review_package_path.as_posix(),
        "intake_next_steps_prefill_ref": next_steps_prefill_path.as_posix(),
    }


def _materialize_human_review_markdown_companions(
    *,
    chip_id: str,
    intake_session_id: str,
    requirement_item_ref: str,
    review_package_path: Path,
    adjudication_template_path: Path,
    builder_handoff_ref: str,
    review_status: str,
    candidate_decisions: List[str],
    conditions_suggested: List[str],
) -> None:
    specs_dir = REPO_ROOT / "chips" / chip_id / "specs"
    architecture_dir = REPO_ROOT / "chips" / chip_id / "architecture"
    generated_at = _tw_now_iso()
    decisions = "\n".join(f"- `{item}`" for item in candidate_decisions)
    conditions = "\n".join(f"- {item}" for item in conditions_suggested)

    (specs_dir / "requirement_item_review_package.md").write_text(
        "\n".join(
            [
                "# Human Review Companion — Requirement Item",
                "",
                "> Derived human-readable companion. Canonical machine truth remains in JSON files.",
                "",
                f"- chip_id: `{chip_id}`",
                f"- scope_type: `CHIP_UPSTREAM`",
                f"- review_status: `{review_status}`",
                f"- intake_session_id: `{intake_session_id}`",
                f"- requirement_item_ref: `{requirement_item_ref}`",
                f"- builder_handoff_ref: `{builder_handoff_ref}`",
                f"- generated_at: `{generated_at}`",
                "",
                "## What Human Should Judge",
                "",
                "- Are the requirement items specific enough to be verified?",
                "- Are ambiguity, missing evidence, and acceptance criteria still open?",
                "- Which adjudication decision should be recorded?",
                "- This companion does not create validation, freeze, generation plan, RTL, or run evidence.",
                "",
                "## Candidate Decisions",
                "",
                decisions,
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    (specs_dir / "requirement_item_adjudication_guide.md").write_text(
        "\n".join(
            [
                "# Human Adjudication Guide",
                "",
                "> Derived human-readable companion. The authority record is `requirement_item_adjudication_record.json`.",
                "",
                f"- chip_id: `{chip_id}`",
                f"- scope_type: `CHIP_UPSTREAM`",
                f"- adjudication_status: `PENDING_DECISION`",
                f"- decision_outcome: `None`",
                f"- authority_signer: `None`",
                f"- generated_at: `{generated_at}`",
                "",
                "## Decision Options",
                "",
                "- `approve`: requirement/spec review is sufficient to continue.",
                "- `approve_with_conditions`: continue, but keep explicit conditions attached.",
                "- `request_more_evidence`: stop and ask local AI/repo agent to fill missing evidence.",
                "- `reject`: stop this upstream path.",
                "",
                "## Suggested Conditions",
                "",
                conditions,
                "",
                "## Authority Boundary",
                "",
                "- Writing adjudication records requirements/spec judgment only.",
                "- It must not create `run_id`, `artifacts/production-runs`, graph validation, freeze, generation plan, RTL generation, or tapeout/readiness claims.",
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    (architecture_dir / "builder_validation_handoff.md").write_text(
        "\n".join(
            [
                "# Builder Validation Handoff — Human Companion",
                "",
                "> Derived human-readable companion. Canonical handoff state remains in `builder_validation_handoff.json`.",
                "",
                f"- chip_id: `{chip_id}`",
                f"- scope_type: `CHIP_UPSTREAM`",
                f"- handoff_status: `PENDING_HUMAN_ADJUDICATION`",
                f"- requirement_item_ref: `{requirement_item_ref}`",
                f"- review_package_ref: `{review_package_path.as_posix()}`",
                f"- adjudication_template_ref: `{adjudication_template_path.as_posix()}`",
                f"- generated_at: `{generated_at}`",
                "",
                "## Next Agent Handoff",
                "",
                "- Local AI/repo agent may resume only after a valid machine-readable decision record exists.",
                "- If `handoff_status` becomes `PENDING_VALIDATION`, proceed to bounded graph generation/refinement and graph validation.",
                "- If `handoff_status` becomes `REQUEST_MORE_EVIDENCE`, collect missing evidence and return to human adjudication.",
                "- This handoff remains `CHIP_UPSTREAM`; production-run evidence starts only after freeze and generation-plan/RTL handoff are ready.",
            ]
        )
        + "\n",
        encoding="utf-8",
    )


def _materialize_builder_route_a_draft(
    *,
    chip_id: str,
    requirement_item_ref: str,
    template_matching: Dict[str, object],
) -> Dict[str, str]:
    architecture_dir = REPO_ROOT / "chips" / chip_id / "architecture"
    architecture_dir.mkdir(parents=True, exist_ok=True)

    graph_draft_path = architecture_dir / "architecture_graph.draft.json"
    handoff_path = architecture_dir / "builder_validation_handoff.json"

    graph_draft = {
        "schema_version": "architecture-graph.v1.0.draft",
        "chip_id": chip_id,
        "draft_status": "BUILDER_DRAFT_PENDING_REVIEW",
        "source_requirement_item_ref": requirement_item_ref,
        "template_matching_ref": template_matching.get("selected_template_ref"),
        "nodes": [],
        "edges": [],
        "generated_at": _tw_now_iso(),
    }
    graph_draft_path.write_text(json.dumps(graph_draft, indent=2), encoding="utf-8")

    handoff = {
        "schema_version": "builder-validation-handoff.v0.1",
        "chip_id": chip_id,
        "graph_draft_ref": graph_draft_path.as_posix(),
        "requirement_item_ref": requirement_item_ref,
        "authority_boundary": {
            "builder_may_freeze": False,
            "builder_may_declare_canonical": False,
            "validator_may_declare_freeze": False,
            "human_decision_required": True,
        },
        "handoff_status": "PENDING_HUMAN_ADJUDICATION",
        "created_at": _tw_now_iso(),
    }
    handoff_path.write_text(json.dumps(handoff, indent=2), encoding="utf-8")

    return {
        "graph_draft_ref": graph_draft_path.as_posix(),
        "builder_handoff_ref": handoff_path.as_posix(),
    }


def run_requirement_intake(
    *,
    chip_id: str,
    prompt_text: str,
    attachment_paths: List[str],
    no_match_action: str,
    workspace_manifest_path: str = "package_ws/workspace_manifest.yaml",
    templates_root: str = "templates",
    template_override_ref: Optional[str] = None,
) -> Dict:
    chip_id = _normalize_chip_id(chip_id)
    attachment_path_objs = [Path(path) for path in attachment_paths]
    for path in attachment_path_objs:
        if not path.exists() or not path.is_file():
            raise FileNotFoundError(f"attachment_not_found:{path}")

    intake_session_id = f"INTAKE-{chip_id}-{datetime.now(TZ_TW).strftime('%Y%m%d-%H%M%S')}"
    if template_override_ref:
        override_path = Path(template_override_ref)
        if not override_path.is_absolute():
            override_path = Path(templates_root) / override_path
        if not override_path.exists() or not override_path.is_dir():
            raise FileNotFoundError(f"template_override_not_found:{template_override_ref}")
        template_match_result = "MATCHED"
        template_ref = override_path.as_posix()
        template_matching = {
            "algorithm_version": "template_match.v1",
            "result": "MATCHED",
            "selected_template_ref": template_ref,
            "selection_mode": "MANUAL_OVERRIDE",
            "candidates": [
                {
                    "template_name": override_path.name,
                    "template_path": template_ref,
                    "score": -1,
                    "confidence": 1.0,
                    "matched_keywords": [],
                }
            ],
        }
    else:
        template_match_result, template_ref, template_matching = match_template(
            prompt_text=prompt_text,
            attachment_paths=attachment_path_objs,
            templates_root=templates_root,
        )

    if template_match_result == "MATCHED":
        bootstrap_mode = "TEMPLATE_BASED"
        init_chip(
            chip_id=chip_id,
            template_path=template_ref,
            workspace_path=workspace_manifest_path,
            bootstrap_mode=bootstrap_mode,
        )
        record = _materialize_intake_session(
            chip_id=chip_id,
            intake_session_id=intake_session_id,
            prompt_text=prompt_text,
            attachment_paths=attachment_path_objs,
            template_match_result=template_match_result,
            template_ref=template_ref,
            bootstrap_mode=bootstrap_mode,
            template_matching=template_matching,
        )
        record["requirement_item_ref"] = _materialize_requirement_item_auto_draft(
            chip_id=chip_id,
            prompt_text=prompt_text,
            session_dir_ref=record["session_dir_ref"],
            attachment_entries=record["attachments"],
        )
        builder_materialized = _materialize_builder_route_a_draft(
            chip_id=chip_id,
            requirement_item_ref=record["requirement_item_ref"],
            template_matching=template_matching,
        )
        record.update(builder_materialized)
        record.update(
            _materialize_requirement_and_image_review_packages(
                chip_id=chip_id,
                intake_session_id=intake_session_id,
                session_dir_ref=record["session_dir_ref"],
                requirement_item_ref=record["requirement_item_ref"],
                image_extraction_report_ref=f"{record['session_dir_ref']}/image_extraction_report.json",
                builder_handoff_ref=builder_materialized["builder_handoff_ref"],
                prompt_text=prompt_text,
                template_matching=template_matching,
            )
        )
        return record

    # NO_MATCH
    if no_match_action.upper() == "C":
        upstream_operation_id = f"UOP-{intake_session_id}"
        record = {
            "scope_type": "CHIP_UPSTREAM",
            "upstream_operation_id": upstream_operation_id,
            "intake_session_id": intake_session_id,
            "chip_id": chip_id,
            "prompt_text": prompt_text,
            "attachments": [path.name for path in attachment_path_objs],
            "template_match_result": "NO_MATCH",
            "template_ref": None,
            "bootstrap_mode": "PENDING_TEMPLATE",
            "status": "PENDING_TEMPLATE",
            "template_matching": template_matching,
            "created_at": _tw_now_iso(),
        }
        record["pending_record_ref"] = _materialize_pending_intake_record(record)
        return record

    # Option B: continue with blank scaffold
    bootstrap_mode = "BLANK_SCAFFOLD"
    init_chip(
        chip_id=chip_id,
        template_path=None,
        workspace_path=workspace_manifest_path,
        bootstrap_mode=bootstrap_mode,
        bootstrap_note="No matching template found. Initialized from blank scaffold.",
    )
    record = _materialize_intake_session(
        chip_id=chip_id,
        intake_session_id=intake_session_id,
        prompt_text=prompt_text,
        attachment_paths=attachment_path_objs,
        template_match_result="NO_MATCH",
        template_ref=None,
        bootstrap_mode=bootstrap_mode,
        template_matching=template_matching,
    )
    record["requirement_item_ref"] = _materialize_requirement_item_auto_draft(
        chip_id=chip_id,
        prompt_text=prompt_text,
        session_dir_ref=record["session_dir_ref"],
        attachment_entries=record["attachments"],
    )
    builder_materialized = _materialize_builder_route_a_draft(
        chip_id=chip_id,
        requirement_item_ref=record["requirement_item_ref"],
        template_matching=template_matching,
    )
    record.update(builder_materialized)
    record.update(
        _materialize_requirement_and_image_review_packages(
            chip_id=chip_id,
            intake_session_id=intake_session_id,
            session_dir_ref=record["session_dir_ref"],
            requirement_item_ref=record["requirement_item_ref"],
            image_extraction_report_ref=f"{record['session_dir_ref']}/image_extraction_report.json",
            builder_handoff_ref=builder_materialized["builder_handoff_ref"],
            prompt_text=prompt_text,
            template_matching=template_matching,
        )
    )
    return record


def main() -> None:
    parser = argparse.ArgumentParser(description="Run requirement intake and chip bootstrap.")
    parser.add_argument("--chip-id", required=True)
    parser.add_argument("--prompt-text", required=True)
    parser.add_argument("--attachment", action="append", default=[])
    parser.add_argument("--no-match-action", choices=["B", "C"], default="B")
    parser.add_argument("--workspace-manifest-path", default="package_ws/workspace_manifest.yaml")
    parser.add_argument("--templates-root", default="templates")
    parser.add_argument("--template-override-ref", default=None)
    args = parser.parse_args()

    record = run_requirement_intake(
        chip_id=args.chip_id,
        prompt_text=args.prompt_text,
        attachment_paths=args.attachment,
        no_match_action=args.no_match_action,
        workspace_manifest_path=args.workspace_manifest_path,
        templates_root=args.templates_root,
        template_override_ref=args.template_override_ref,
    )
    print(json.dumps(record, indent=2))


if __name__ == "__main__":
    main()
