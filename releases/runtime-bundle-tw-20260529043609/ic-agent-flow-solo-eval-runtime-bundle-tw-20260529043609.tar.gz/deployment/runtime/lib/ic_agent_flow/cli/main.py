import argparse
import json
from pathlib import Path

from ic_agent_flow.dashboard.architecture_exploration import (
    build_architecture_exploration_objects,
)
from ic_agent_flow.dashboard.artifact_indexer import build_artifact_run_index
from ic_agent_flow.dashboard.artifact_location_profile import build_location_profile
from ic_agent_flow.dashboard.artifact_resolver import resolve_artifact_uri
from ic_agent_flow.dashboard.decision_inbox import build_decision_inbox
from ic_agent_flow.dashboard.flow_registry import build_flow_registry
from ic_agent_flow.dashboard.i18n.i18n_validator import validate_i18n_resources
from ic_agent_flow.dashboard.node_io_manifest import build_node_io_manifest
from ic_agent_flow.dashboard.package_readiness_panel import build_package_readiness_board
from ic_agent_flow.dashboard.run_detail_manifest import (
    build_readiness_manifest,
    build_run_detail_manifest,
)
from ic_agent_flow.dashboard.static_dashboard import build_static_dashboard
from ic_agent_flow.dashboard.ui_ux_review_gate import run_ui_ux_review
from ic_agent_flow.dashboard.i18n.translation_registry import (
    REQUIRED_DASHBOARD_TRANSLATION_KEYS,
)


def _run_dashboard_i18n_check(args: argparse.Namespace) -> int:
    report = validate_i18n_resources(
        resource_root=Path(args.resource_root),
        locales=args.locale,
        required_keys=REQUIRED_DASHBOARD_TRANSLATION_KEYS,
    )
    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"dashboard_i18n_coverage_report: {out_path}")
    return 0 if report["overall_verdict"] == "pass" else 1


def _run_dashboard_build_flow_registry(args: argparse.Namespace) -> int:
    registry = build_flow_registry(
        chip_id=args.chip_id,
        package_mode=args.package_mode,
        dashboard_version=args.dashboard_version,
    )
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "dashboard_flow_registry.json").write_text(
        json.dumps(registry, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (out_dir / "flow_dashboard_nodes.json").write_text(
        json.dumps({"nodes": registry["nodes"]}, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (out_dir / "flow_dashboard_edges.json").write_text(
        json.dumps({"edges": registry["edges"]}, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    print(f"dashboard_flow_registry: {out_dir / 'dashboard_flow_registry.json'}")
    return 0


def _run_dashboard_build_node_io(args: argparse.Namespace) -> int:
    flow_registry = json.loads(Path(args.flow_registry).read_text(encoding="utf-8"))
    manifest = build_node_io_manifest(
        flow_registry=flow_registry,
        artifact_root=Path(args.artifact_root),
    )
    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"flow_node_io_manifest: {out_path}")
    return 0 if manifest["overall_verdict"] != "blocked" else 1


def _run_artifacts_index(args: argparse.Namespace) -> int:
    index = build_artifact_run_index(context=args.context, root=Path(args.root))
    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(index, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"artifact_run_index: {out_path}")
    return 0


def _run_artifacts_resolve(args: argparse.Namespace) -> int:
    profile = build_location_profile(
        context=args.context,
        root=Path(args.root),
        package_mode=getattr(args, "package_mode", None) or args.profile.removeprefix("package_extract_"),
        dashboard_version=getattr(args, "dashboard_version", "v1_7"),
    )
    record = resolve_artifact_uri(uri=args.uri, profile=profile)
    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(record, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"artifact_resolved_path_record: {out_path}")
    return 0 if record["resolution_status"] == "resolved" else 1


def _run_dashboard_build_package_readiness(args: argparse.Namespace) -> int:
    board = build_package_readiness_board(
        input_root=Path(args.input_root),
        dashboard_version=getattr(args, "dashboard_version", "v1_7"),
    )
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "package_readiness_panel.json").write_text(
        json.dumps(board, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (out_dir / "package_variant_readiness_record.json").write_text(
        json.dumps({"records": board["panels"]}, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    print(f"package_readiness_panel: {out_dir / 'package_readiness_panel.json'}")
    return 0 if board["overall_verdict"] == "ready" else 1


def _run_dashboard_build_decision_inbox(args: argparse.Namespace) -> int:
    inbox = build_decision_inbox(
        input_root=Path(args.input_root),
        dashboard_version=getattr(args, "dashboard_version", "v1_7"),
    )
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "human_decision_queue.json").write_text(
        json.dumps(inbox, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (out_dir / "dashboard_action_records.json").write_text(
        json.dumps({"records": []}, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    print(f"human_decision_queue: {out_dir / 'human_decision_queue.json'}")
    return 0


def _run_dashboard_build_static(args: argparse.Namespace) -> int:
    manifest = build_static_dashboard(
        out_dir=Path(args.out),
        context=args.context,
        resolved_artifact_path=args.resolved_artifact_path,
        dashboard_version=getattr(args, "dashboard_version", "v1_7"),
    )
    print(f"static_dashboard_manifest: {manifest['manifest_id']} -> {args.out}")
    return 0


def _run_dashboard_build_architecture_exploration(args: argparse.Namespace) -> int:
    objects = build_architecture_exploration_objects(
        chip_id=args.chip_id,
        run_id=args.run_id,
        date_time=args.date_time,
        input_root=Path(args.input_root),
    )
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "architecture_model_view_manifest.json").write_text(
        json.dumps(objects["architecture_model_view_manifest"], indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (out_dir / "scenario_requirement_matrix.json").write_text(
        json.dumps(objects["scenario_requirement_matrix"], indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    candidate_payload = {"records": objects["architecture_candidate_scorecards"]}
    (out_dir / "architecture_candidate_scorecard.json").write_text(
        json.dumps(candidate_payload, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (out_dir / "architecture_candidate_scorecards.json").write_text(
        json.dumps(candidate_payload, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    run_detail_manifest = build_run_detail_manifest(
        chip_id=args.chip_id,
        run_id=args.run_id,
        date_time=args.date_time,
        dashboard_version="v1_8",
        input_root=Path(args.input_root),
    )
    readiness_manifest = build_readiness_manifest(
        chip_id=args.chip_id,
        run_id=args.run_id,
        date_time=args.date_time,
        dashboard_version="v1_8",
    )
    (out_dir / "run_detail_manifest.json").write_text(
        json.dumps(run_detail_manifest, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    (out_dir / "readiness_manifest.json").write_text(
        json.dumps(readiness_manifest, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    print(f"architecture_exploration_objects: {out_dir}")
    return 0


def _run_dashboard_ui_ux_review(args: argparse.Namespace) -> int:
    report = run_ui_ux_review(
        out_dir=Path(args.out),
        dashboard_surface=args.surface,
        customer_visible_text=args.customer_visible_text,
        dashboard_version=getattr(args, "dashboard_version", "v1_7"),
    )
    print(f"ui_ux_max_pro_acceptance_matrix: {Path(args.out) / 'ui_ux_max_pro_acceptance_matrix.json'}")
    return 0 if report["overall_verdict"] in {"PASS", "PASS_WITH_WARNINGS"} else 1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="icaf")
    subparsers = parser.add_subparsers(dest="command")

    dashboard = subparsers.add_parser("dashboard")
    dashboard_subparsers = dashboard.add_subparsers(dest="dashboard_command")

    i18n_check = dashboard_subparsers.add_parser("i18n-check")
    i18n_check.add_argument("--locale", action="append", required=True)
    i18n_check.add_argument("--resource-root", required=True)
    i18n_check.add_argument("--out", required=True)
    i18n_check.set_defaults(func=_run_dashboard_i18n_check)

    flow_registry = dashboard_subparsers.add_parser("build-flow-registry")
    flow_registry.add_argument("--chip-id", required=True)
    flow_registry.add_argument(
        "--dashboard-version",
        choices=["v1_7", "v1_8"],
        default="v1_7",
    )
    flow_registry.add_argument(
        "--package-mode",
        choices=["solo_eval", "team_project", "enterprise_site", "internal_dev"],
        required=True,
    )
    flow_registry.add_argument("--out", required=True)
    flow_registry.set_defaults(func=_run_dashboard_build_flow_registry)

    node_io = dashboard_subparsers.add_parser("build-node-io")
    node_io.add_argument("--flow-registry", required=True)
    node_io.add_argument("--artifact-root", required=True)
    node_io.add_argument("--out", required=True)
    node_io.set_defaults(func=_run_dashboard_build_node_io)

    package_readiness = dashboard_subparsers.add_parser("build-package-readiness")
    package_readiness.add_argument("--input-root", required=True)
    package_readiness.add_argument("--dashboard-version", choices=["v1_7", "v1_8"], default="v1_7")
    package_readiness.add_argument("--out", required=True)
    package_readiness.set_defaults(func=_run_dashboard_build_package_readiness)

    decision_inbox = dashboard_subparsers.add_parser("build-decision-inbox")
    decision_inbox.add_argument("--input-root", required=True)
    decision_inbox.add_argument("--dashboard-version", choices=["v1_7", "v1_8"], default="v1_7")
    decision_inbox.add_argument("--out", required=True)
    decision_inbox.set_defaults(func=_run_dashboard_build_decision_inbox)

    static_dashboard = dashboard_subparsers.add_parser("build-static")
    static_dashboard.add_argument("--context", choices=["working_project", "release_package_extract"], required=True)
    static_dashboard.add_argument("--out", required=True)
    static_dashboard.add_argument("--dashboard-version", choices=["v1_7", "v1_8"], default="v1_7")
    static_dashboard.add_argument("--resolved-artifact-path", default="artifacts/production-runs/SN2025/raw/yosys.raw.log")
    static_dashboard.set_defaults(func=_run_dashboard_build_static)

    architecture_exploration = dashboard_subparsers.add_parser("build-architecture-exploration")
    architecture_exploration.add_argument("--chip-id", required=True)
    architecture_exploration.add_argument("--run-id", required=True)
    architecture_exploration.add_argument("--date-time", required=True)
    architecture_exploration.add_argument("--input-root", required=True)
    architecture_exploration.add_argument("--out", required=True)
    architecture_exploration.set_defaults(func=_run_dashboard_build_architecture_exploration)

    ui_ux_review = dashboard_subparsers.add_parser("ui-ux-review")
    ui_ux_review.add_argument("--surface", required=True)
    ui_ux_review.add_argument("--out", required=True)
    ui_ux_review.add_argument("--dashboard-version", choices=["v1_7", "v1_8"], default="v1_7")
    ui_ux_review.add_argument("--customer-visible-text", default="")
    ui_ux_review.set_defaults(func=_run_dashboard_ui_ux_review)

    artifacts = subparsers.add_parser("artifacts")
    artifacts_subparsers = artifacts.add_subparsers(dest="artifacts_command")

    artifacts_index = artifacts_subparsers.add_parser("index")
    artifacts_index.add_argument("--context", choices=["working_project", "release_package_extract"], required=True)
    artifacts_index.add_argument("--root", required=True)
    artifacts_index.add_argument("--package-mode", choices=["solo_eval", "team_project", "enterprise_site", "internal_dev"])
    artifacts_index.add_argument("--dashboard-version", choices=["v1_7", "v1_8"], default="v1_7")
    artifacts_index.add_argument("--out", required=True)
    artifacts_index.set_defaults(func=_run_artifacts_index)

    artifacts_resolve = artifacts_subparsers.add_parser("resolve")
    artifacts_resolve.add_argument("--uri", required=True)
    artifacts_resolve.add_argument("--context", choices=["working_project", "release_package_extract"], required=True)
    artifacts_resolve.add_argument("--profile", required=True)
    artifacts_resolve.add_argument("--root", required=True)
    artifacts_resolve.add_argument("--package-mode", choices=["solo_eval", "team_project", "enterprise_site", "internal_dev"])
    artifacts_resolve.add_argument("--dashboard-version", choices=["v1_7", "v1_8"], default="v1_7")
    artifacts_resolve.add_argument("--out", required=True)
    artifacts_resolve.set_defaults(func=_run_artifacts_resolve)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if not hasattr(args, "func"):
        parser.print_help()
        return 2
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
