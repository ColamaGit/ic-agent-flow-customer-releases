from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any


class UpstreamTruthGateError(ValueError):
    """Raised when required v1.0 upstream truth is missing."""


@dataclass(frozen=True)
class ChainRunResult:
    chain_id: str
    executed_skills: list[str]
    routing_decision_record: dict[str, Any]


def _now_rfc3339() -> str:
    return datetime.now(tz=timezone.utc).isoformat()


def enforce_v10_upstream_truth_gate(context: dict[str, Any]) -> None:
    required = (
        "requirement_freeze_record",
        "graph_validation_result",
        "graph_freeze_record",
        "graph_to_generation_plan",
    )
    missing = [key for key in required if not context.get(key)]
    if missing:
        raise UpstreamTruthGateError(
            "v1.0 upstream truth gate blocked: " + ", ".join(missing)
        )


def emit_routing_decision_record(
    *,
    task_id: str,
    decision_tree_skill_id: str,
    routing_policy_id: str,
    routing_policy_version: str,
    selected_route: str,
    input_refs: list[str],
) -> dict[str, Any]:
    return {
        "record_id": f"routing::{task_id}",
        "task_id": task_id,
        "decision_tree_skill_id": decision_tree_skill_id,
        "routing_policy_id": routing_policy_id,
        "routing_policy_version": routing_policy_version,
        "input_refs": input_refs,
        "selected_route": selected_route,
        "fallback_route": None,
        "sensitive_path_override_triggered": False,
        "sensitive_path_report_ref": None,
        "verdict": "ROUTE_SELECTED",
        "created_at": _now_rfc3339(),
    }


def run_governed_skill_chain(
    *,
    chain_id: str,
    chain_skills: list[str],
    context: dict[str, Any],
    routing_policy_id: str = "routing-policy-default",
    routing_policy_version: str = "0.1.0",
) -> ChainRunResult:
    enforce_v10_upstream_truth_gate(context)

    routing_record = emit_routing_decision_record(
        task_id=context.get("task_id", chain_id),
        decision_tree_skill_id=context.get(
            "decision_tree_skill_id", "skill_chain_selection_decision_tree_skill"
        ),
        routing_policy_id=routing_policy_id,
        routing_policy_version=routing_policy_version,
        selected_route=chain_id,
        input_refs=[
            "task_context",
            "complexity_score_report",
            "tool_availability_report",
        ],
    )

    return ChainRunResult(
        chain_id=chain_id,
        executed_skills=list(chain_skills),
        routing_decision_record=routing_record,
    )
