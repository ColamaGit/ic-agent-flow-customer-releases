from __future__ import annotations

from typing import Any

REQUIRED_SKILL_FIELDS = (
    "skill_id",
    "name",
    "version",
    "type",
    "stage",
    "input_contract",
    "output_contract",
    "allowed_tools",
    "side_effects",
    "evidence_behavior",
    "failure_taxonomy",
    "loop_policy",
    "authority_boundary",
    "qa_gate",
    "ip_classification",
    "status",
)

REQUIRED_SKILL_EVIDENCE_FIELDS = (
    "required_outputs",
)

ALLOWED_EXECUTION_LOCATIONS = (
    "local_runner",
    "openai_agent",
    "customer_toolchain",
    "external_service",
    "managed_service",
)

REQUIRED_ROUTING_POLICY_FIELDS = (
    "policy_id",
    "version",
    "deterministic",
    "routes",
)

ALLOWED_SKILL_TYPES = ("execution_skill", "decision_tree_skill")


class ValidationError(ValueError):
    """Raised when a v1.9 governed skill contract is invalid."""


def _missing_fields(payload: dict[str, Any], required: tuple[str, ...]) -> list[str]:
    return [field for field in required if field not in payload]


def validate_skill_payload(payload: dict[str, Any]) -> None:
    missing = _missing_fields(payload, REQUIRED_SKILL_FIELDS)
    if missing:
        raise ValidationError(f"missing required fields: {', '.join(missing)}")

    skill_type = payload.get("type")
    if skill_type not in ALLOWED_SKILL_TYPES:
        raise ValidationError("type must be execution_skill|decision_tree_skill")

    evidence_behavior = payload.get("evidence_behavior")
    if not isinstance(evidence_behavior, dict):
        raise ValidationError("evidence_behavior must be object")
    evidence_missing = _missing_fields(evidence_behavior, REQUIRED_SKILL_EVIDENCE_FIELDS)
    if evidence_missing:
        raise ValidationError(
            "evidence_behavior missing: " + ", ".join(evidence_missing)
        )
    required_outputs = evidence_behavior.get("required_outputs")
    if not isinstance(required_outputs, list) or not required_outputs:
        raise ValidationError("evidence_behavior required_outputs must be non-empty list")

    authority_boundary = payload.get("authority_boundary")
    if not isinstance(authority_boundary, dict):
        raise ValidationError("authority_boundary must be object")
    execution_location = authority_boundary.get("execution_location")
    if execution_location is not None and execution_location not in ALLOWED_EXECUTION_LOCATIONS:
        allowed = "|".join(ALLOWED_EXECUTION_LOCATIONS)
        raise ValidationError(f"invalid execution_location: expected {allowed}")

    qa_gate = payload.get("qa_gate")
    if not isinstance(qa_gate, dict):
        raise ValidationError("qa_gate must be object")
    if qa_gate.get("claim_bearing") is True:
        required_verdicts = evidence_behavior.get("required_verdicts")
        if not isinstance(required_verdicts, list) or not required_verdicts:
            raise ValidationError("claim-bearing skill requires required_verdicts")

    # Fail-closed against prompt-only skill definitions.
    if payload.get("input_contract") in ({}, None) or payload.get("output_contract") in ({}, None):
        raise ValidationError("prompt-only skill rejected: input/output contract required")

    if skill_type == "decision_tree_skill":
        if "routing_policy_ref" not in payload:
            raise ValidationError("decision_tree_skill requires routing_policy_ref")
        if "routing_policy_version_ref" not in payload:
            raise ValidationError("decision_tree_skill requires routing_policy_version_ref")


def validate_routing_policy(policy: dict[str, Any]) -> None:
    missing = _missing_fields(policy, REQUIRED_ROUTING_POLICY_FIELDS)
    if missing:
        raise ValidationError(f"missing required fields: {', '.join(missing)}")
    if policy.get("deterministic") is not True:
        raise ValidationError("non-deterministic routing policy rejected")
    routes = policy.get("routes")
    if not isinstance(routes, list) or not routes:
        raise ValidationError("routes must be non-empty list")
