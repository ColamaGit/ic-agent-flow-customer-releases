from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def _load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def load_profile_skill_pack_manifests(base_dir: Path) -> dict[str, dict[str, Any]]:
    return {
        "solo_eval": _load_json(base_dir / "solo_eval_skill_pack_manifest.json"),
        "team_project": _load_json(base_dir / "team_project_skill_pack_manifest.json"),
        "enterprise_site": _load_json(base_dir / "enterprise_site_skill_pack_manifest.json"),
    }


def validate_customer_visible_routing_contract(base_dir: Path) -> bool:
    payload = _load_json(base_dir / "customer_visible_routing_contract_manifest.json")
    # contract must exist and avoid exposing internal heuristic implementation details.
    text = json.dumps(payload)
    return "internal_heuristic" not in text
