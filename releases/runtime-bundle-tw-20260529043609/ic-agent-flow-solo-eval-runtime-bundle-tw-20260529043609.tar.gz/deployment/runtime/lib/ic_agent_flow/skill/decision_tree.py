from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class DecisionTreeRoutingResult:
    selected_route: str
    sensitive_path_override_triggered: bool
    sensitive_path_report_ref: str | None
    human_escalation_required: bool


def select_route_with_policy(
    *,
    complexity_score: int,
    default_route: str,
    deep_route: str,
    sensitive_path_report_ref: str | None = None,
    tools_available: bool = True,
) -> DecisionTreeRoutingResult:
    if not tools_available:
        return DecisionTreeRoutingResult(
            selected_route="human_escalation",
            sensitive_path_override_triggered=False,
            sensitive_path_report_ref=None,
            human_escalation_required=True,
        )

    if sensitive_path_report_ref:
        return DecisionTreeRoutingResult(
            selected_route=deep_route,
            sensitive_path_override_triggered=True,
            sensitive_path_report_ref=sensitive_path_report_ref,
            human_escalation_required=False,
        )

    selected = deep_route if complexity_score >= 70 else default_route
    return DecisionTreeRoutingResult(
        selected_route=selected,
        sensitive_path_override_triggered=False,
        sensitive_path_report_ref=None,
        human_escalation_required=False,
    )


def manual_intervention_metric(
    *,
    before_count: int,
    after_count: int,
    measurement_method: str,
) -> dict[str, Any]:
    claim_allowed = before_count > after_count
    return {
        "record_id": "manual-metric-001",
        "measurement_window": {
            "before_start": "2026-01-01T00:00:00+00:00",
            "before_end": "2026-01-31T23:59:59+00:00",
            "after_start": "2026-02-01T00:00:00+00:00",
            "after_end": "2026-02-28T23:59:59+00:00",
        },
        "manual_intervention_count_before": before_count,
        "manual_intervention_count_after": after_count,
        "measurement_method": measurement_method,
        "claim_allowed": claim_allowed,
        "claim_blocked_reason": None if claim_allowed else "no measured reduction",
        "created_at": "2026-05-01T00:00:00+00:00",
    }
