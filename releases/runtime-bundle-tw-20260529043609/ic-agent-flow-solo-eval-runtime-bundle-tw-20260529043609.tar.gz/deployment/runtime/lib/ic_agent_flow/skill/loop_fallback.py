from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any


class SilentFallbackError(ValueError):
    """Raised when fallback is attempted without emitting required records."""


@dataclass(frozen=True)
class FallbackResult:
    iteration_count: int
    fallback_execution_record: dict[str, Any]


def _now_rfc3339() -> str:
    return datetime.now(tz=timezone.utc).isoformat()


def run_bounded_loop_with_fallback(
    *,
    task_id: str,
    primary_route: str,
    fallback_route: str,
    max_iterations: int,
    fail_iteration: int,
    emit_record: bool = True,
) -> FallbackResult:
    if max_iterations <= 0:
        raise ValueError("max_iterations must be > 0")

    iteration_count = min(max_iterations, max(1, fail_iteration))

    if not emit_record:
        raise SilentFallbackError("silent fallback blocked")

    record = {
        "record_id": f"fallback::{task_id}",
        "task_id": task_id,
        "primary_route": primary_route,
        "fallback_route": fallback_route,
        "failure_reason": "EXECUTION_FAILED",
        "fallback_trigger": "bounded_loop_failure",
        "fallback_result": "PASS",
        "artifact_refs": ["delta_evidence://retry-1"],
        "created_at": _now_rfc3339(),
    }

    return FallbackResult(iteration_count=iteration_count, fallback_execution_record=record)
