from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class ClaimAssessment:
    allowed: bool
    reason: str


def build_skill_evaluation_matrix(skill_results: list[dict[str, Any]]) -> dict[str, Any]:
    return {
        "matrix_id": "v1.9-skill-matrix-001",
        "skill_results": skill_results,
        "routing_metrics_included": True,
    }


def build_route_quality_assessment(
    *,
    routing_policy_id: str,
    sample_count: int,
    false_lightweight_route_count: int,
    false_deep_route_count: int,
    human_override_count: int,
    fallback_success_rate: float,
) -> dict[str, Any]:
    total_error = false_lightweight_route_count + false_deep_route_count
    verdict = "PASS" if total_error == 0 else "PASS_WITH_WARNINGS"
    if sample_count <= 0:
        verdict = "BLOCKED"
    return {
        "record_id": "route-quality-001",
        "routing_policy_id": routing_policy_id,
        "sample_count": sample_count,
        "false_lightweight_route_count": false_lightweight_route_count,
        "false_deep_route_count": false_deep_route_count,
        "human_override_count": human_override_count,
        "fallback_success_rate": fallback_success_rate,
        "verdict": verdict,
    }


def qa_trust_claim_gate(*, has_measured_manual_metric: bool, evidence_complete: bool) -> ClaimAssessment:
    if not evidence_complete:
        return ClaimAssessment(False, "insufficient_evidence")
    if not has_measured_manual_metric:
        return ClaimAssessment(False, "manual_intervention_reduction_unverified")
    return ClaimAssessment(True, "proceed")
