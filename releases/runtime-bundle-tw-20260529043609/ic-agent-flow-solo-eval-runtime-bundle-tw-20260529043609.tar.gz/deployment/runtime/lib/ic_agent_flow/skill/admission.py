from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class AdmissionDecision:
    allowed: bool
    verdict: str
    reason: str


def evaluate_external_skill_admission(*, has_adjudication_record: bool) -> AdmissionDecision:
    if not has_adjudication_record:
        return AdmissionDecision(
            allowed=False,
            verdict="BLOCKED",
            reason="external_skill_requires_adjudication",
        )
    return AdmissionDecision(allowed=True, verdict="ALLOW", reason="adjudicated")


def evaluate_external_routing_policy_admission(
    *, has_adjudication_record: bool
) -> AdmissionDecision:
    if not has_adjudication_record:
        return AdmissionDecision(
            allowed=False,
            verdict="BLOCKED",
            reason="external_routing_policy_requires_adjudication",
        )
    return AdmissionDecision(allowed=True, verdict="ALLOW", reason="adjudicated")


def customer_local_default_scope() -> str:
    return "LOCAL_ONLY"
