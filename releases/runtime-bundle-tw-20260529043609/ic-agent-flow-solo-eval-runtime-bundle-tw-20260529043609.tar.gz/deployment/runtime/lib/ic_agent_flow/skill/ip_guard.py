from __future__ import annotations

from pathlib import Path


def scan_manifest_for_ip_leak(path: Path) -> bool:
    text = path.read_text(encoding="utf-8")
    forbidden_tokens = ("PROPRIETARY_SECRET", "internal_prompt_strategy")
    return not any(token in text for token in forbidden_tokens)
