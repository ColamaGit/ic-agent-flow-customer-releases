from __future__ import annotations

import re
from pathlib import Path


FOLDER_RE = re.compile(r"^(?P<idx>\d{2})_(?P<slug>[a-z0-9_]+)$")


def _parse(folder: str) -> tuple[int, str]:
    m = FOLDER_RE.match(folder)
    if not m:
        raise ValueError(f"invalid folder name: {folder}")
    return int(m.group("idx")), m.group("slug")


def simulate_plugin_insert(folder_names: list[str], *, at_index: int, new_slug: str) -> list[str]:
    parsed = sorted([_parse(name) for name in folder_names], key=lambda x: x[0])
    out: list[tuple[int, str]] = []
    inserted = False
    for idx, slug in parsed:
        if idx == at_index and not inserted:
            out.append((at_index, new_slug))
            inserted = True
            out.append((idx + 1, slug))
        elif idx > at_index:
            out.append((idx + 1, slug))
        else:
            out.append((idx, slug))
    if not inserted:
        out.append((at_index, new_slug))
    return [f"{idx:02d}_{slug}" for idx, slug in sorted(out, key=lambda x: x[0])]


def simulate_plugout_remove(folder_names: list[str], *, at_index: int) -> list[str]:
    parsed = sorted([_parse(name) for name in folder_names], key=lambda x: x[0])
    out: list[tuple[int, str]] = []
    for idx, slug in parsed:
        if idx == at_index:
            continue
        if idx > at_index:
            out.append((idx - 1, slug))
        else:
            out.append((idx, slug))
    return [f"{idx:02d}_{slug}" for idx, slug in sorted(out, key=lambda x: x[0])]


def validate_contiguous_prefixes(folder_names: list[str]) -> bool:
    indices = sorted(_parse(name)[0] for name in folder_names)
    if not indices:
        return True
    return indices == list(range(indices[0], indices[0] + len(indices)))


def list_run_stage_folders(run_dir: Path) -> list[str]:
    names = []
    for p in sorted(run_dir.iterdir(), key=lambda x: x.name):
        if p.is_dir() and FOLDER_RE.match(p.name):
            names.append(p.name)
    return names
