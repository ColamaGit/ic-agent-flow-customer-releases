from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any


_FORBIDDEN_DEFAULT = {
    "FULL_SIGNOFF",
    "FOUNDRY_ACCEPTED",
    "SILICON_PROVEN",
    "TAPEOUT_RELEASED",
}


@dataclass(frozen=True)
class _Scope:
    valid_from: str
    valid_until: str


def _parse_dt(value: str) -> datetime:
    if value.endswith("Z"):
        value = value[:-1] + "+00:00"
    return datetime.fromisoformat(value)


def evaluate_v116_no_proof_no_claim(
    *,
    enforcement_record: dict[str, Any] | None,
    equivalence_claim_record: dict[str, Any] | None,
    lineage_bridge_record: dict[str, Any] | None,
) -> dict[str, Any]:
    blockers: list[str] = []
    if not enforcement_record:
        blockers.append("MISSING_ADAPTER_SCHEMA_ENFORCEMENT_RECORD")
    elif enforcement_record.get("overall_status") != "PASS":
        blockers.append("ADAPTER_SCHEMA_ENFORCEMENT_NOT_PASS")

    if not equivalence_claim_record:
        blockers.append("MISSING_EQUIVALENCE_CLAIM_RECORD")
    elif equivalence_claim_record.get("status") not in {"ACTIVE"}:
        blockers.append("EQUIVALENCE_CLAIM_NOT_ACTIVE")

    if not lineage_bridge_record:
        blockers.append("MISSING_LINEAGE_BRIDGE_RECORD")
    elif lineage_bridge_record.get("status") != "ESTABLISHED":
        blockers.append("LINEAGE_BRIDGE_NOT_ESTABLISHED")

    return {
        "status": "BLOCKED" if blockers else "PASS",
        "blocking_reasons": blockers,
    }


def evaluate_v116_equivalence_invalidation(
    *,
    equivalence_claim_record: dict[str, Any],
    observed_tool_version: str,
    observed_adapter_version: str,
    now_iso: str,
) -> dict[str, Any]:
    blockers: list[str] = []
    scope = equivalence_claim_record.get("equivalence_scope") or {}
    valid_until = scope.get("valid_until")
    if not valid_until:
        blockers.append("EQUIVALENCE_SCOPE_VALID_UNTIL_MISSING")
    else:
        if _parse_dt(now_iso) > _parse_dt(valid_until):
            blockers.append("EQUIVALENCE_SCOPE_EXPIRED")

    expected_tool = equivalence_claim_record.get("tool_version")
    if expected_tool and expected_tool != observed_tool_version:
        blockers.append("TOOL_VERSION_CHANGED")

    expected_adapter = equivalence_claim_record.get("adapter_version")
    if expected_adapter and expected_adapter != observed_adapter_version:
        blockers.append("ADAPTER_VERSION_CHANGED")

    return {
        "status": "INVALID" if blockers else "VALID",
        "blocking_reasons": blockers,
    }


def evaluate_v116_overclaim_scan(
    *,
    claim_text: str,
    blocked_claims: set[str] | None = None,
) -> dict[str, Any]:
    blocked = blocked_claims or _FORBIDDEN_DEFAULT
    normalized = claim_text.upper()
    matched = sorted(token for token in blocked if token in normalized)
    return {
        "status": "BLOCKED" if matched else "PASS",
        "matched_forbidden_claims": matched,
    }


def evaluate_v116_downstream_replacement_consumption(
    *,
    requested_claim: str,
    equivalence_claim_record: dict[str, Any] | None,
    lineage_bridge_record: dict[str, Any] | None,
    no_proof_gate_result: dict[str, Any],
) -> dict[str, Any]:
    blockers = list(no_proof_gate_result.get("blocking_reasons") or [])

    if no_proof_gate_result.get("status") != "PASS":
        blockers.append("NO_PROOF_NO_CLAIM_BLOCKED")

    if not equivalence_claim_record:
        blockers.append("MISSING_EQUIVALENCE_CLAIM_RECORD")
    else:
        eligible = set(equivalence_claim_record.get("claim_eligible") or [])
        if requested_claim not in eligible:
            blockers.append("CLAIM_OUTSIDE_EQUIVALENCE_SCOPE")

    if not lineage_bridge_record:
        blockers.append("MISSING_LINEAGE_BRIDGE_RECORD")

    return {
        "status": "BLOCKED" if blockers else "PASS",
        "blocking_reasons": sorted(set(blockers)),
    }


def evaluate_v116_mandatory_node_replacement_attempt(*, node_class: str) -> dict[str, Any]:
    if node_class in {"MANDATORY_GOVERNANCE_NODE", "MANDATORY_RUNTIME_BOUNDARY"}:
        return {
            "status": "BLOCKED",
            "blocking_reasons": ["MANDATORY_NODE_REPLACEMENT_FORBIDDEN"],
        }
    return {"status": "PASS", "blocking_reasons": []}


def build_v116_replacement_governance_records(
    *,
    chip_id: str,
    run_id: str,
    execution: str,
    node_id: str,
    adapter_id: str,
    requested_claim: str,
) -> dict[str, Any]:
    now = datetime.now().astimezone().isoformat()
    enforcement = {
        "schema_version": "v1.16.0",
        "record_type": "adapter_schema_enforcement_record",
        "enforcement_id": f"ASE-{execution}",
        "chip_id": chip_id,
        "run_id": run_id,
        "execution": execution,
        "target_node_id": node_id,
        "adapter_manifest_ref": f"adapter://{adapter_id}",
        "normalization_contract_ref": f"normalization://{node_id}",
        "evidence_mapping_ref": f"evidence://{node_id}",
        "entitlement_ref": f"entitlement://{adapter_id}",
        "checks_performed": [
            {"check": "adapter_manifest_schema_valid", "passed": True},
            {"check": "target_node_pluggable", "passed": True},
            {"check": "normalization_contract_ref_resolvable", "passed": True},
            {"check": "evidence_mapping_ref_resolvable", "passed": True},
            {"check": "entitlement_ref_resolvable", "passed": True},
            {"check": "claim_boundary_schema_valid", "passed": True},
        ],
        "overall_status": "PASS",
        "generated_at": now,
    }
    lineage = {
        "schema_version": "v1.16.0",
        "record_type": "lineage_bridge_record",
        "bridge_id": f"LBR-{execution}",
        "chip_id": chip_id,
        "run_id": run_id,
        "execution": execution,
        "node_id": node_id,
        "adapter_id": adapter_id,
        "upstream_inputs": [f"inputs/{node_id}.json"],
        "replacement_outputs": [f"outputs/{node_id}.raw.log"],
        "normalized_evidence_refs": [f"evidence://{node_id}/normalized"],
        "status": "ESTABLISHED",
        "generated_at": now,
    }
    equivalence = {
        "schema_version": "v1.16.0",
        "record_type": "node_replacement_equivalence_claim_record",
        "claim_id": f"EQV-{execution}",
        "chip_id": chip_id,
        "run_id": run_id,
        "execution": execution,
        "node_id": node_id,
        "adapter_id": adapter_id,
        "equivalence_class": "MACHINE_VERIFIED_EQUIVALENT",
        "equivalence_scope": {
            "scope_id": f"scope-{execution}",
            "valid_from": now,
            "valid_until": now,
        },
        "claim_eligible": [requested_claim],
        "claim_ineligible": sorted(_FORBIDDEN_DEFAULT),
        "lineage_bridge_record_ref": f"lineage://{lineage['bridge_id']}",
        "tool_version": "tool-v1",
        "adapter_version": "adapter-v1",
        "status": "ACTIVE",
        "generated_at": now,
    }

    gate = evaluate_v116_no_proof_no_claim(
        enforcement_record=enforcement,
        equivalence_claim_record=equivalence,
        lineage_bridge_record=lineage,
    )
    consumption = evaluate_v116_downstream_replacement_consumption(
        requested_claim=requested_claim,
        equivalence_claim_record=equivalence,
        lineage_bridge_record=lineage,
        no_proof_gate_result=gate,
    )
    folder_ordering = {
        "schema_version": "v1.16.0",
        "record_type": "artifacts_run_folder_ordering_record",
        "chip_id": chip_id,
        "run_id": run_id,
        "execution": execution,
        "node_order": [node_id, "downstream_consumer"],
        "folder_order": [f"10_{node_id}", "11_downstream_consumer"],
        "order_consistent": True,
        "violation_reasons": [],
        "generated_at": now,
    }
    reindex_operation = {
        "schema_version": "v1.16.0",
        "record_type": "artifacts_reindex_operation_record",
        "chip_id": chip_id,
        "run_id": run_id,
        "execution": execution,
        "operation": "PLUGIN_INSERT",
        "target_index": 10,
        "target_slug": node_id,
        "renumbering_map": [
            {"before": "10_h4_klayout", "after": "11_h4_klayout"},
        ],
        "contiguous_prefixes": True,
        "verdict": "PASS",
        "blocked_reason": None,
        "generated_at": now,
    }

    return {
        "adapter_schema_enforcement_record": enforcement,
        "node_replacement_equivalence_claim_record": equivalence,
        "lineage_bridge_record": lineage,
        "downstream_replacement_consumption_record": {
            "schema_version": "v1.16.0",
            "record_type": "downstream_replacement_consumption_record",
            "status": consumption["status"],
            "blocking_reasons": consumption["blocking_reasons"],
            "requested_claim": requested_claim,
            "generated_at": now,
        },
        "artifacts_run_folder_ordering_record": folder_ordering,
        "artifacts_reindex_operation_record": reindex_operation,
    }
