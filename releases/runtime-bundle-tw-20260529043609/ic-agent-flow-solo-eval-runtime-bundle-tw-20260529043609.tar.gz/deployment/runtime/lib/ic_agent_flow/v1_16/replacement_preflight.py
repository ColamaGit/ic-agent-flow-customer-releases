from __future__ import annotations

from typing import Any

from .adapter_manifest_validator import validate_adapter_manifest
from .pluggability_resolver import resolve_replacement


def run_replacement_preflight(
    *,
    node_entry: dict[str, Any] | None,
    manifest: dict[str, Any],
    has_entitlement: bool,
    profile_allows: bool,
    site_policy_allows: bool,
    overclaim_scan_policy_loaded: bool,
    claim_boundary_resolvable: bool,
) -> dict[str, Any]:
    node_class = (node_entry or {}).get("node_class", "UNKNOWN")
    manifest_result = validate_adapter_manifest(manifest, target_node_class=node_class)
    if manifest_result["status"] != "PASS":
        return {"verdict": "BLOCKED", "blocked_reasons": manifest_result["blocked_reasons"]}

    resolver_result = resolve_replacement(
        node_entry=node_entry,
        has_adapter_manifest=True,
        has_entitlement=has_entitlement,
        profile_allows=profile_allows,
        site_policy_allows=site_policy_allows,
        normalization_contract_present=bool(manifest.get("normalization_contract_ref")),
    )
    blockers = list(resolver_result.get("blocked_reasons") or [])
    if not claim_boundary_resolvable:
        blockers.append("claim_boundary_unresolvable")
    if not overclaim_scan_policy_loaded:
        blockers.append("overclaim_scan_policy_missing")
    if blockers:
        return {"verdict": "BLOCKED", "blocked_reasons": sorted(set(blockers))}
    return {"verdict": "PASS", "blocked_reasons": []}
