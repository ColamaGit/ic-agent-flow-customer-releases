from __future__ import annotations


def select_backend(*, replacement_configured: bool, preflight_verdict: str) -> dict[str, str]:
    if not replacement_configured:
        return {"backend_mode": "DEFAULT_BACKEND", "verdict": "PASS"}
    if preflight_verdict in {"PASS", "PASS_WITH_WARNINGS"}:
        return {"backend_mode": "CUSTOMER_REPLACEMENT", "verdict": "PASS"}
    return {"backend_mode": "BLOCKED_REPLACEMENT", "verdict": "BLOCKED"}
