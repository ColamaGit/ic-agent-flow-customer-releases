from __future__ import annotations

from typing import Any


REQUIRED_FIELDS = {
    "adapter_id",
    "adapter_owner",
    "visibility_class",
    "target_node_ids",
    "tool_family",
    "tool_vendor",
    "tool_name",
    "tool_version_policy",
    "normalization_contract_ref",
    "evidence_mapping_ref",
    "redaction_policy_ref",
    "supportability",
    "created_at",
}


def validate_adapter_manifest(manifest: dict[str, Any], *, target_node_class: str) -> dict[str, Any]:
    missing = sorted(field for field in REQUIRED_FIELDS if field not in manifest)
    if missing:
        return {"status": "BLOCKED", "blocked_reasons": [f"missing_field:{name}" for name in missing]}
    if target_node_class in {"MANDATORY_GOVERNANCE_NODE", "MANDATORY_RUNTIME_BOUNDARY"}:
        return {"status": "BLOCKED", "blocked_reasons": ["adapter_targets_mandatory_node"]}
    if not str(manifest.get("normalization_contract_ref", "")).strip():
        return {"status": "BLOCKED", "blocked_reasons": ["normalization_contract_ref_dead_ref"]}
    if not str(manifest.get("evidence_mapping_ref", "")).strip():
        return {"status": "BLOCKED", "blocked_reasons": ["evidence_mapping_ref_dead_ref"]}
    return {"status": "PASS", "blocked_reasons": []}
