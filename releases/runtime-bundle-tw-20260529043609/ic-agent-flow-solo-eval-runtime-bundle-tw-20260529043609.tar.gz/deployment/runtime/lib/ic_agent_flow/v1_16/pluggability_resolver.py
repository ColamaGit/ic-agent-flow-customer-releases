from __future__ import annotations

from typing import Any


def resolve_replacement(
    *,
    node_entry: dict[str, Any] | None,
    has_adapter_manifest: bool,
    has_entitlement: bool,
    profile_allows: bool,
    site_policy_allows: bool,
    normalization_contract_present: bool,
) -> dict[str, Any]:
    if not node_entry:
        return {"replacement_verdict": "BLOCKED", "blocked_reasons": ["node_id_unknown"]}

    node_class = node_entry.get("node_class")
    if node_class in {"MANDATORY_GOVERNANCE_NODE", "MANDATORY_RUNTIME_BOUNDARY", "MANDATORY_ADAPTER_BOUNDARY"}:
        return {"replacement_verdict": "BLOCKED", "blocked_reasons": ["mandatory_node_replacement_attempted"]}
    if node_class != "PLUGGABLE_TOOL_NODE" and node_class != "OPTIONAL_EXTENSION_NODE":
        return {"replacement_verdict": "NOT_APPLICABLE", "blocked_reasons": ["node_not_pluggable"]}

    missing: list[str] = []
    if not has_adapter_manifest:
        missing.append("missing_adapter_manifest")
    if not has_entitlement:
        missing.append("missing_entitlement")
    if not profile_allows:
        missing.append("profile_disallows_replacement")
    if not site_policy_allows:
        missing.append("site_policy_disallows_replacement")
    if not normalization_contract_present:
        missing.append("normalization_contract_missing")

    if missing:
        return {"replacement_verdict": "BLOCKED", "blocked_reasons": missing}
    return {"replacement_verdict": "ALLOWED", "blocked_reasons": []}
