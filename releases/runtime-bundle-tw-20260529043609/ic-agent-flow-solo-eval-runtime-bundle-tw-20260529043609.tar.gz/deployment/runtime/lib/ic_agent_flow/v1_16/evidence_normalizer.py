from __future__ import annotations

from typing import Any


def normalize_external_output(*, node_id: str, raw_artifact_refs: list[str]) -> dict[str, Any]:
    if not raw_artifact_refs:
        return {"verdict": "BLOCKED", "blocked_reasons": ["missing_raw_artifact"]}
    return {
        "verdict": "PASS",
        "normalized_artifact_refs": [
            f"normalized.{node_id}.timing.meta.json",
            f"normalized.{node_id}.physical.meta.json",
        ],
        "evidence_bundle_ref": f"evidence_bundle:{node_id}",
    }
