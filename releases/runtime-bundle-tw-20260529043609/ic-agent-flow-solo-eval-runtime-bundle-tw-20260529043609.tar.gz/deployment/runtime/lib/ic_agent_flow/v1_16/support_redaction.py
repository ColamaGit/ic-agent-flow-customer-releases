from __future__ import annotations

from typing import Any


SENSITIVE_KEYS = {
    "license_server",
    "internal_script_path",
    "proprietary_tool_config",
    "vendor_private_logic",
}


def redact_support_payload(payload: dict[str, Any]) -> dict[str, Any]:
    redacted = {}
    for key, value in payload.items():
        if key in SENSITIVE_KEYS:
            redacted[key] = "REDACTED"
        else:
            redacted[key] = value
    return redacted
