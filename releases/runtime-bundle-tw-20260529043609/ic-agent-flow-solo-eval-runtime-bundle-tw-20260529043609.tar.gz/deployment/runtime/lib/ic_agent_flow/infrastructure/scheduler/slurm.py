import re
import shutil
import subprocess
from typing import Dict, List, Optional
from uuid import uuid4

from ic_agent_flow.infrastructure.scheduler.base import AbstractScheduler
from ic_agent_flow.infrastructure.job_model import JobRecord, JobStatus

class SlurmJobAdapter(AbstractScheduler):
    """
    Slurm scheduler adapter.
    Uses real sbatch/squeue/scancel when available; otherwise fails closed.
    """

    def __init__(
        self,
        cluster_name: str = "ic_hpc_prod",
        *,
        sbatch_bin: str = "sbatch",
        squeue_bin: str = "squeue",
        scancel_bin: str = "scancel",
    ):
        self.cluster_name = cluster_name
        self.sbatch_bin = sbatch_bin
        self.squeue_bin = squeue_bin
        self.scancel_bin = scancel_bin
        self._jobs: Dict[str, JobRecord] = {}

    async def submit(self, command: List[str], run_id: str, working_dir: str) -> JobRecord:
        job_id = f"slurm_{uuid4().hex[:8]}"
        if not command:
            raise ValueError("slurm_submit_requires_non_empty_command")
        self._require_slurm_bins()
        job = JobRecord(
            job_id=job_id,
            run_id=run_id,
            status=JobStatus.SUBMITTED,
            command=command,
            working_dir=working_dir,
            metadata={
                "cluster": self.cluster_name,
                "scheduler_type": "slurm",
                "sbatch": self.sbatch_bin,
                "squeue": self.squeue_bin,
                "scancel": self.scancel_bin,
            },
        )
        try:
            cmd = [
                self.sbatch_bin,
                "--parsable",
                "--job-name",
                job_id,
                "--chdir",
                working_dir,
                "--wrap",
                " ".join(command),
            ]
            proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
            if proc.returncode != 0:
                stderr = (proc.stderr or "").strip() or "sbatch_failed"
                job.transition_to(JobStatus.FAILED, f"sbatch failed: {stderr}")
                self._jobs[job_id] = job
                return job
            slurm_id = self._parse_slurm_job_id(proc.stdout)
            if not slurm_id:
                job.transition_to(JobStatus.FAILED, "sbatch returned unparseable job id")
                self._jobs[job_id] = job
                return job
            job.pid = int(slurm_id) if slurm_id.isdigit() else None
            job.metadata["slurm_job_id"] = slurm_id
            job.transition_to(JobStatus.QUEUED, f"Job queued by Slurm as {slurm_id}")
        except Exception as exc:
            job.transition_to(JobStatus.FAILED, f"slurm_submit_runtime_error:{exc}")
        self._jobs[job_id] = job
        return job

    async def poll(self, job_id: str) -> JobRecord:
        if job_id not in self._jobs:
            raise ValueError(f"Job {job_id} unknown")

        job = self._jobs[job_id]
        if job.status in [JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED]:
            return job
        slurm_id = str(job.metadata.get("slurm_job_id") or "").strip()
        if not slurm_id:
            job.transition_to(JobStatus.FAILED, "missing_slurm_job_id")
            return job
        self._require_slurm_bins()
        proc = subprocess.run(
            [self.squeue_bin, "-h", "-j", slurm_id, "-o", "%T"],
            capture_output=True,
            text=True,
            check=False,
        )
        if proc.returncode != 0:
            stderr = (proc.stderr or "").strip() or "squeue_failed"
            job.transition_to(JobStatus.FAILED, f"squeue failed: {stderr}")
            return job
        state = (proc.stdout or "").strip().upper()
        if not state:
            job.exit_code = 0
            job.transition_to(JobStatus.COMPLETED, "Slurm job no longer listed; treated as completed")
            return job
        if state in {"PENDING", "CONFIGURING"} and job.status != JobStatus.QUEUED:
            job.transition_to(JobStatus.QUEUED, f"Slurm state={state}")
            return job
        if state in {"RUNNING", "COMPLETING"} and job.status != JobStatus.RUNNING:
            job.transition_to(JobStatus.RUNNING, f"Slurm state={state}")
            return job
        if state in {"COMPLETED"}:
            job.exit_code = 0
            job.transition_to(JobStatus.COMPLETED, "Slurm state=COMPLETED")
            return job
        if state in {"FAILED", "TIMEOUT", "OUT_OF_MEMORY", "NODE_FAIL", "CANCELLED"}:
            job.exit_code = 1
            fail_status = JobStatus.CANCELLED if state == "CANCELLED" else JobStatus.FAILED
            job.transition_to(fail_status, f"Slurm state={state}")
        return job

    async def cancel(self, job_id: str) -> bool:
        if job_id not in self._jobs:
            return False

        job = self._jobs[job_id]
        if job.status in [JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED]:
            return True
        slurm_id = str(job.metadata.get("slurm_job_id") or "").strip()
        if not slurm_id:
            job.transition_to(JobStatus.FAILED, "missing_slurm_job_id")
            return False
        self._require_slurm_bins()
        proc = subprocess.run([self.scancel_bin, slurm_id], capture_output=True, text=True, check=False)
        if proc.returncode != 0:
            return False
        job.transition_to(JobStatus.CANCELLED, f"scancel accepted for {slurm_id}")
        return True

    async def list_jobs(self, run_id: Optional[str] = None) -> List[JobRecord]:
        if run_id:
            return [j for j in self._jobs.values() if j.run_id == run_id]
        return list(self._jobs.values())

    def _require_slurm_bins(self) -> None:
        missing = [b for b in [self.sbatch_bin, self.squeue_bin, self.scancel_bin] if shutil.which(b) is None]
        if missing:
            raise RuntimeError(f"slurm_cli_not_available:{','.join(missing)}")

    @staticmethod
    def _parse_slurm_job_id(output: str) -> str:
        raw = (output or "").strip()
        if not raw:
            return ""
        first = raw.split(";")[0].strip()
        if re.fullmatch(r"\d+", first):
            return first
        match = re.search(r"\b(\d{3,})\b", raw)
        return match.group(1) if match else ""
