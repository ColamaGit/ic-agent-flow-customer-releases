from __future__ import annotations

from pathlib import Path


def resolve_reports_dir_name(run_dir: Path) -> str:
    prefixed = sorted(p.name for p in run_dir.iterdir() if p.is_dir() and p.name.endswith("_reports"))
    if prefixed:
        return prefixed[0]
    if (run_dir / "reports").exists():
        return "reports"
    return "22_reports"


def resolve_report_ref(run_dir: Path, rel_path: str) -> str:
    """
    Dynamic resolver:
    - strict primary: <resolved_reports_dir>/<rel_path>
    - explicit fallback: <rel_path> at run root
    Returns logical relative path.
    """
    canonical = f"{resolve_reports_dir_name(run_dir)}/{rel_path}"
    if (run_dir / canonical).exists():
        return canonical
    if (run_dir / rel_path).exists():
        return rel_path
    return canonical
