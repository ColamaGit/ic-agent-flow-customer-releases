"""
CI-enforceable packaging gates P1-P6 for customer deployment packaging line.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List

from ic_agent_flow.domain.objects.deployment_packaging_objects import (
    DeploymentProfile,
    ExportClass,
    GateEvidenceRefSet,
    GateFailureRecord,
    GateResult,
    GateVerdict,
    RedactionLevel,
    RuntimeDistributionBundle,
    SupportAuditBundle,
)


ALLOWED_ROOTS = ("product/", "deployment/")
DENYLIST_PREFIXES = (
    "package_ws/",
    "internal-redacted/",
    "tests/",
    "progress.md",
    "findings.md",
    ".venv/",
    "node_modules/",
    "chips/",
)


@dataclass
class GateContext:
    subject_ref: str
    run_ref: str


def _prefix_match(path: str, prefixes: Iterable[str]) -> bool:
    return any(path == item or path.startswith(item) for item in prefixes)


def _build_gate_result(
    gate_id: str,
    gate_name: str,
    context: GateContext,
    blocking_reasons: List[str],
    evidence_refs: List[str] | None = None,
) -> tuple[GateResult, GateFailureRecord | None, GateEvidenceRefSet]:
    evidence_refs = evidence_refs or []
    verdict = GateVerdict.FAIL if blocking_reasons else GateVerdict.PASS

    evidence_set = GateEvidenceRefSet(
        gate_id=gate_id,
        evidence_refs=evidence_refs,
        subject_ref=context.subject_ref,
        run_ref=context.run_ref,
    )

    failure_record = None
    if verdict == GateVerdict.FAIL:
        failure_record = GateFailureRecord(
            gate_id=gate_id,
            gate_name=gate_name,
            blocking_reasons=blocking_reasons,
            evidence_refs=evidence_refs,
            subject_ref=context.subject_ref,
            run_ref=context.run_ref,
        )

    result = GateResult(
        gate_id=gate_id,
        gate_name=gate_name,
        verdict=verdict,
        blocking_reasons=blocking_reasons,
        evidence_refs=evidence_refs,
        subject_ref=context.subject_ref,
        run_ref=context.run_ref,
        failure_record_ref=str(failure_record.id) if failure_record else None,
        evidence_ref_set_ref=str(evidence_set.id),
    )
    return result, failure_record, evidence_set


def run_p1_source_boundary_gate(
    bundle: RuntimeDistributionBundle,
    context: GateContext,
) -> tuple[GateResult, GateFailureRecord | None, GateEvidenceRefSet]:
    blocking: List[str] = []
    for source_ref in bundle.source_refs:
        normalized = source_ref.lstrip("./")
        if _prefix_match(normalized, DENYLIST_PREFIXES):
            blocking.append(f"denylisted input path: {source_ref}")
            continue
        if not _prefix_match(normalized, ALLOWED_ROOTS):
            blocking.append(f"path outside allowlist roots: {source_ref}")
    return _build_gate_result("P1", "source_boundary", context, blocking, bundle.source_refs)


def run_p2_semantic_integrity_gate(
    bundle: RuntimeDistributionBundle,
    profile_ref: str,
    product_manifest_ref: str,
    context: GateContext,
) -> tuple[GateResult, GateFailureRecord | None, GateEvidenceRefSet]:
    blocking: List[str] = []
    if not bundle.digest:
        blocking.append("bundle digest missing")
    if not bundle.signature.trust_root_ref:
        blocking.append("signature trust root missing")
    if bundle.profile_ref != profile_ref:
        blocking.append("bundle profile_ref does not match selected profile")
    if bundle.product_manifest_ref != product_manifest_ref:
        blocking.append("bundle product_manifest_ref does not match selected manifest")
    return _build_gate_result("P2", "semantic_integrity", context, blocking, [bundle.profile_ref, bundle.product_manifest_ref])


def run_p3_profile_compliance_gate(
    profile: DeploymentProfile,
    requested_adapters: list[str],
    context: GateContext,
) -> tuple[GateResult, GateFailureRecord | None, GateEvidenceRefSet]:
    blocking: List[str] = []
    forbidden_overlap = sorted(set(profile.forbidden_capabilities) & set(profile.capability_set))
    if forbidden_overlap:
        blocking.append(f"capability_set contains forbidden entries: {forbidden_overlap}")

    non_subset = sorted(set(requested_adapters) - set(profile.enabled_adapters))
    if non_subset:
        blocking.append(f"requested adapters outside enabled set: {non_subset}")
    return _build_gate_result("P3", "profile_compliance", context, blocking, requested_adapters)


def run_p4_installability_gate(
    install_success: bool,
    installation_record_ref: str | None,
    context: GateContext,
) -> tuple[GateResult, GateFailureRecord | None, GateEvidenceRefSet]:
    blocking: List[str] = []
    if not install_success:
        blocking.append("dry install failed")
    if not installation_record_ref:
        blocking.append("installation_record missing")
    evidence = [installation_record_ref] if installation_record_ref else []
    return _build_gate_result("P4", "installability", context, blocking, evidence)


def run_p5_upgrade_rollback_gate(
    upgrade_success: bool,
    rollback_success: bool,
    upgrade_record_ref: str | None,
    rollback_record_ref: str | None,
    context: GateContext,
) -> tuple[GateResult, GateFailureRecord | None, GateEvidenceRefSet]:
    blocking: List[str] = []
    if not upgrade_success:
        blocking.append("upgrade drill failed")
    if not rollback_success:
        blocking.append("rollback drill failed")
    if not upgrade_record_ref:
        blocking.append("upgrade_record missing")
    if not rollback_record_ref:
        blocking.append("rollback_record missing")
    evidence = [ref for ref in [upgrade_record_ref, rollback_record_ref] if ref]
    return _build_gate_result("P5", "upgrade_rollback", context, blocking, evidence)


def run_p6_support_bundle_gate(
    support_bundle: SupportAuditBundle,
    context: GateContext,
) -> tuple[GateResult, GateFailureRecord | None, GateEvidenceRefSet]:
    blocking: List[str] = []
    if support_bundle.export_class not in set(ExportClass):
        blocking.append("invalid export_class")
    if support_bundle.redaction_level not in set(RedactionLevel):
        blocking.append("invalid redaction_level")
    if not support_bundle.included_object_allowlist:
        blocking.append("included_object_allowlist must not be empty")
    if not support_bundle.prohibited_object_denylist:
        blocking.append("prohibited_object_denylist must not be empty")
    overlap = sorted(
        set(support_bundle.included_object_allowlist)
        & set(support_bundle.prohibited_object_denylist)
    )
    if overlap:
        blocking.append(f"allowlist/denylist overlap detected: {overlap}")

    evidence = [f"incident:{support_bundle.incident_id}", f"export_class:{support_bundle.export_class.value}"]
    return _build_gate_result("P6", "support_bundle", context, blocking, evidence)


def check_distribution_provenance(repo_root: Path) -> List[str]:
    """
    Returns a list of integrity errors. Empty list means pass.
    """
    errors: List[str] = []
    distribution_root = repo_root / "distribution"
    provenance = distribution_root / "release-manifests" / "build_provenance.json"
    if not provenance.exists():
        errors.append("distribution/release-manifests/build_provenance.json is missing")

    required_dirs = [
        distribution_root / "runtime-bundles",
        distribution_root / "support-bundles",
        distribution_root / "portable-workspace-bundles",
        distribution_root / "release-manifests",
    ]
    missing = [str(path.relative_to(repo_root)) for path in required_dirs if not path.exists()]
    if missing:
        errors.append(f"distribution required directories missing: {missing}")
    return errors
