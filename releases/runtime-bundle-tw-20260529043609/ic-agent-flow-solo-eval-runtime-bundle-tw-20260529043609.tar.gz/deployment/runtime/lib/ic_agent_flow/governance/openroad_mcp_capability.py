from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List
from uuid import uuid4

from pydantic import BaseModel

from ic_agent_flow.registry.scenario_registry import Disposition


def _extract_worst_slack_from_report_checks_json(payload: object) -> float | None:
    slacks: list[float] = []

    def walk(node: object) -> None:
        if isinstance(node, dict):
            slack = node.get("slack")
            if isinstance(slack, (int, float)):
                slacks.append(float(slack))
            for value in node.values():
                walk(value)
        elif isinstance(node, list):
            for item in node:
                walk(item)

    walk(payload)
    return min(slacks) if slacks else None


def _extract_violation_count_from_check_types_output(text: str) -> int | None:
    import re

    match = re.search(r"(\d+)\s+violations?\.", text, re.IGNORECASE)
    if match:
        return int(match.group(1))
    violated_count = len(re.findall(r"\(VIOLATED\)", text, re.IGNORECASE))
    if violated_count or "(MET)" in text:
        return violated_count
    return None


def _extract_worst_slack_from_text(text: str) -> float | None:
    import re

    slacks = [float(m.group(1)) for m in re.finditer(r"\((?:MET|VIOLATED)\)\s+(-?[\d.]+)", text)]
    slacks.extend(
        float(m.group(1))
        for m in re.finditer(r"(-?[\d.]+)\s+slack\s+\((?:MET|VIOLATED)\)", text)
    )
    return min(slacks) if slacks else None


def _build_openroad_setup_commands(req: "OpenroadMcpCapabilityRequest") -> list[str]:
    tech_lef_path = req.tech_lef_path
    stdcell_lef_path = req.stdcell_lef_path
    lib_path = req.lib_path
    tracks_path = req.tracks_path
    if not all([tech_lef_path, stdcell_lef_path, lib_path, tracks_path]):
        raise ValueError("input_schema_invalid:collateral_unresolved")

    commands = [
        f'read_lef "{tech_lef_path}"',
        f'read_lef "{stdcell_lef_path}"',
        f'read_liberty "{lib_path}"',
        f'read_verilog "{Path(req.netlist_v_path).as_posix()}"',
        f"link_design {req.top_module}",
    ]
    if req.sdc_path and Path(req.sdc_path).exists():
        commands.append(f'read_sdc "{Path(req.sdc_path).as_posix()}"')

    commands.extend([
        "initialize_floorplan -site FreePDK45_38x28_10R_NP_162NW_34O -die_area {0 0 200 200} -core_area {20 20 180 180}",
        f'source "{tracks_path}"',
        "place_pins -hor_layers metal3 -ver_layers metal2",
    ])
    return commands


def _build_openroad_repair_design_command() -> str:
    return "repair_design -pre_placement"


def _build_openroad_main_script(req: "OpenroadMcpCapabilityRequest", def_path: Path) -> list[str]:
    commands = _build_openroad_setup_commands(req)
    commands.extend([
        _build_openroad_repair_design_command(),
        "set_wire_rc -signal -layer metal3",
        "set_wire_rc -clock -layer metal6",
        "estimate_parasitics -placement",
        f'write_def "{def_path.as_posix()}"',
        "report_checks",
        "report_design_area",
        "report_power",
        "puts \"OPENROAD_H2_REAL_RUN_PASS\"",
        "exit",
    ])
    return commands


def _build_extra_report_specs(out_dir: Path) -> list[tuple[str, Path, str]]:
    return [
        (
            "setup_checks_json",
            out_dir / "setup_checks.json",
            "report_checks -path_delay max -format json -fields {slew capacitance}",
        ),
        (
            "hold_checks_json",
            out_dir / "hold_checks.json",
            "report_checks -path_delay min -fields {slew capacitance}",
        ),
        (
            "max_slew_report",
            out_dir / "max_slew.rpt",
            "report_check_types -max_slew",
        ),
        (
            "max_capacitance_report",
            out_dir / "max_capacitance.rpt",
            "report_check_types -max_capacitance",
        ),
    ]


class OpenroadMcpCapabilityRequest(BaseModel):
    workspace_id: str
    chip_id: str
    task_id: str
    decision_context_ref: str
    contract_name: str
    contract_version: str
    top_module: str = "top"
    netlist_v_path: str | None = None
    sdc_path: str | None = None
    tech_lef_path: str | None = None
    stdcell_lef_path: str | None = None
    lib_path: str | None = None
    tracks_path: str | None = None
    timeout_sec: int = 120
    output_root: str = "artifacts/v0.9/openroad"
    openroad_bin: str = "openroad"
    request_schema_version: str = "v0.1"
    run_key: str | None = None


class OpenroadMcpCapabilityResponse(BaseModel):
    disposition: Disposition
    reason: str
    contract_id: str
    request_schema_version: str
    boundary_mode: str
    error_taxonomy: List[str]
    run_id: str | None = None
    execution_run_ref: str | None = None
    tool_version: str | None = None
    artifact_paths: Dict[str, str] = {}
    artifact_refs: Dict[str, str] = {}


OpenroadMcpCapabilityRequest.model_rebuild()
OpenroadMcpCapabilityResponse.model_rebuild()


class OpenroadMcpCapabilityBoundary:
    """
    Formal MCP capability boundary for openroad_drc (local mode).
    """

    CAPABILITY_NAME = "openroad_drc"
    CONTRACT_NAME = "openroad_drc_contract"
    CONTRACT_VERSION = "v0.1"
    BOUNDARY_MODE = "formal_mcp_capability_boundary_local_mode_v0.1"
    ERROR_TAXONOMY = [
        "chip_scope_unresolved",
        "input_schema_invalid",
        "tool_missing",
        "tool_timeout",
        "tool_runtime_error",
        "artifact_missing",
        "output_unparseable",
        "decision_context_mismatch",
    ]

    @staticmethod
    def _sha256_file(path: Path) -> str:
        h = hashlib.sha256()
        with path.open("rb") as f:
            while True:
                chunk = f.read(8192)
                if not chunk:
                    break
                h.update(chunk)
        return h.hexdigest()

    @classmethod
    def _fail(cls, reason: str, req: OpenroadMcpCapabilityRequest) -> OpenroadMcpCapabilityResponse:
        return OpenroadMcpCapabilityResponse(
            disposition=Disposition.FAIL_CLOSED,
            reason=reason,
            contract_id=f"{req.contract_name}@{req.contract_version}",
            request_schema_version=req.request_schema_version,
            boundary_mode=cls.BOUNDARY_MODE,
            error_taxonomy=list(cls.ERROR_TAXONOMY),
        )

    def execute(self, req: OpenroadMcpCapabilityRequest) -> OpenroadMcpCapabilityResponse:
        required_values = [
            req.workspace_id,
            req.chip_id,
            req.task_id,
            req.decision_context_ref,
            req.contract_name,
            req.contract_version,
        ]
        if any(not value for value in required_values):
            return self._fail("input_schema_invalid:envelope_missing", req)

        if req.contract_name != self.CONTRACT_NAME or req.contract_version != self.CONTRACT_VERSION:
            return self._fail("input_schema_invalid:unsupported_contract", req)

        if not req.decision_context_ref.startswith("decision://"):
            return self._fail("decision_context_mismatch:invalid_context", req)

        if shutil.which(req.openroad_bin) is None:
            return self._fail("tool_missing:openroad_not_in_path", req)

        collateral_paths = [
            req.tech_lef_path,
            req.stdcell_lef_path,
            req.lib_path,
            req.tracks_path,
        ]
        if any(not path for path in collateral_paths):
            return self._fail("input_schema_invalid:collateral_unresolved", req)
        if any(not Path(path).exists() for path in collateral_paths):
            return self._fail("input_schema_invalid:collateral_not_found", req)

        run_id = req.run_key or f"openroad-{uuid4().hex[:12]}"
        out_dir = Path(req.output_root) / run_id
        out_dir.mkdir(parents=True, exist_ok=True)

        raw_log_path = out_dir / "openroad.raw.log"
        normalized_metadata_path = out_dir / "normalized.drc.meta.json"
        input_manifest_path = out_dir / "input_manifest.json"
        lineage_path = out_dir / "lineage.json"
        evidence_bundle_path = out_dir / "evidence_bundle.json"
        script_path = out_dir / "openroad_minimal.tcl"
        def_path = out_dir / "top.def"
        extra_report_specs = _build_extra_report_specs(out_dir)
        extra_report_paths = {name: path for name, path, _ in extra_report_specs}
        setup_checks_path = extra_report_paths["setup_checks_json"]
        hold_checks_path = extra_report_paths["hold_checks_json"]
        max_slew_path = extra_report_paths["max_slew_report"]
        max_cap_path = extra_report_paths["max_capacitance_report"]

        # Real-tool invocation with native OpenROAD metrics for PPA.
        if req.netlist_v_path and Path(req.netlist_v_path).exists():
            script_content = _build_openroad_main_script(req, def_path)
        else:
            script_content = [
                "puts \"OPENROAD_H2_MINIMAL_PASS\"",
                "exit",
            ]
        
        script_path.write_text("\n".join(script_content) + "\n", encoding="utf-8")
        metrics_path = out_dir / "ppa.json"
        command_argv = [
            req.openroad_bin, 
            "-exit", 
            "-no_init", 
            "-log", raw_log_path.as_posix(), 
            "-metrics", metrics_path.as_posix(), 
            script_path.as_posix()
        ]

        started_at = datetime.now(timezone.utc)
        try:
            proc = subprocess.run(
                command_argv,
                cwd=str(Path.cwd()),
                capture_output=True,
                text=True,
                timeout=req.timeout_sec,
            )
            finished_at = datetime.now(timezone.utc)
        except subprocess.TimeoutExpired:
            raw_log_path.write_text("tool_timeout: openroad exceeded timeout\n", encoding="utf-8")
            return self._fail("tool_timeout:openroad_execution_timeout", req)

        raw_log_path.write_text((proc.stdout or "") + (proc.stderr or ""), encoding="utf-8")
        if proc.returncode != 0:
            return self._fail("tool_runtime_error:openroad_non_zero_exit", req)

        if req.netlist_v_path and not def_path.exists():
            return self._fail("artifact_missing:def_not_generated", req)
        
        output_text = raw_log_path.read_text(encoding="utf-8")
        if "OPENROAD_H2_REAL_RUN_PASS" not in output_text and "OPENROAD_H2_MINIMAL_PASS" not in output_text:
            return self._fail("output_unparseable:missing_pass_marker", req)

        version_proc = subprocess.run(
            [req.openroad_bin, "-version"],
            capture_output=True,
            text=True,
            timeout=15,
        )
        tool_version = (version_proc.stdout or version_proc.stderr or "").strip().splitlines()[0]
        if not tool_version:
            return self._fail("output_unparseable:openroad_version_unavailable", req)

        if req.netlist_v_path:
            for _, report_path, report_cmd in extra_report_specs:
                report_script_path = out_dir / f"{report_path.stem}.tcl"
                report_script_lines = _build_openroad_setup_commands(req) + [
                    _build_openroad_repair_design_command(),
                    "set_wire_rc -signal -layer metal3",
                    "set_wire_rc -clock -layer metal6",
                    "estimate_parasitics -placement",
                    report_cmd,
                    "exit",
                ]
                report_script_path.write_text("\n".join(report_script_lines) + "\n", encoding="utf-8")
                report_proc = subprocess.run(
                    [
                        req.openroad_bin,
                        "-exit",
                        "-no_init",
                        report_script_path.as_posix(),
                    ],
                    cwd=str(Path.cwd()),
                    capture_output=True,
                    text=True,
                    timeout=req.timeout_sec,
                )
                report_path.write_text((report_proc.stdout or "") + (report_proc.stderr or ""), encoding="utf-8")

        # Parse PPA metrics
        ppa_data = {}
        if req.netlist_v_path:
            try:
                import re
                output_text = raw_log_path.read_text(encoding="utf-8")
                
                # Simple extraction of Area
                area_match = re.search(r"Design area (\d+)", output_text)
                ppa_data["area_um2"] = int(area_match.group(1)) if area_match else 0

                # Simple extraction of Total Power (Watts)
                power_match = re.search(r"Total\s+[\d\.]+\s+[\d\.]+\s+[\d\.]+\s+([\d\.]+e[\d\+\-]+)", output_text)
                ppa_data["total_power_watts"] = float(power_match.group(1)) if power_match else 0.0

                # Timing Slack
                slack_match = re.search(r"slack\s+\((?:MET|VIOLATED)\)\s+([\d\.]+)", output_text)
                ppa_data["worst_slack_ns"] = float(slack_match.group(1)) if slack_match else 0.0

                if hold_checks_path.exists():
                    hold_text = hold_checks_path.read_text(encoding="utf-8")
                    hold_slack = _extract_worst_slack_from_text(hold_text)
                    if hold_slack is not None:
                        ppa_data["worst_hold_slack_ns"] = hold_slack

                if max_slew_path.exists():
                    max_slew_violations = _extract_violation_count_from_check_types_output(
                        max_slew_path.read_text(encoding="utf-8")
                    )
                    if max_slew_violations is not None:
                        ppa_data["max_transition_violations"] = max_slew_violations

                if max_cap_path.exists():
                    max_cap_violations = _extract_violation_count_from_check_types_output(
                        max_cap_path.read_text(encoding="utf-8")
                    )
                    if max_cap_violations is not None:
                        ppa_data["max_capacitance_violations"] = max_cap_violations

            except Exception as e:
                ppa_data["parsing_error"] = str(e)

        input_manifest = {
            "workspace_id": req.workspace_id,
            "chip_id": req.chip_id,
            "task_id": req.task_id,
            "contract_name": req.contract_name,
            "contract_version": req.contract_version,
            "decision_context_ref": req.decision_context_ref,
            "tool": "openroad",
            "tool_version": tool_version,
            "tool_binary_path": req.openroad_bin,
            "tech_lef_path": req.tech_lef_path,
            "stdcell_lef_path": req.stdcell_lef_path,
            "lib_path": req.lib_path,
            "tracks_path": req.tracks_path,
            "command": " ".join(command_argv),
            "cwd": str(Path.cwd()),
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }
        input_manifest_path.write_text(json.dumps(input_manifest, indent=2), encoding="utf-8")

        normalized = {
            "tool": "openroad",
            "tool_version": tool_version,
            "contract_name": req.contract_name,
            "contract_version": req.contract_version,
            "tool_binary_path": req.openroad_bin,
            "tech_lef_path": req.tech_lef_path,
            "stdcell_lef_path": req.stdcell_lef_path,
            "lib_path": req.lib_path,
            "tracks_path": req.tracks_path,
            "status": "PASS",
            "ppa": ppa_data,
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }
        normalized_metadata_path.write_text(json.dumps(normalized, indent=2), encoding="utf-8")

        duration_ms = int((finished_at - started_at).total_seconds() * 1000)
        lineage = {
            "run_id": run_id,
            "started_at": started_at.isoformat(),
            "finished_at": finished_at.isoformat(),
            "exit_code": proc.returncode,
            "duration_ms": duration_ms,
            "command_argv": command_argv,
            "working_dir": str(Path.cwd()),
            "input_manifest_ref": input_manifest_path.as_posix(),
            "output_refs": [raw_log_path.as_posix(), normalized_metadata_path.as_posix(), metrics_path.as_posix()],
            "decision_context_ref": req.decision_context_ref,
            "session_id": "",
            "task_id": req.task_id,
            "workspace_id": req.workspace_id,
            "chip_id": req.chip_id,
        }
        if def_path.exists():
            lineage["output_refs"].append(def_path.as_posix())
        for extra_path in (setup_checks_path, hold_checks_path, max_slew_path, max_cap_path):
            if extra_path.exists():
                lineage["output_refs"].append(extra_path.as_posix())
        lineage_path.write_text(json.dumps(lineage, indent=2), encoding="utf-8")

        raw_refs = [raw_log_path.as_posix(), metrics_path.as_posix()]
        for extra_path in (setup_checks_path, hold_checks_path, max_slew_path, max_cap_path):
            if extra_path.exists():
                raw_refs.append(extra_path.as_posix())

        evidence_bundle = {
            "run_id": run_id,
            "raw_refs": raw_refs,
            "normalized_refs": [normalized_metadata_path.as_posix()],
            "lineage_ref": lineage_path.as_posix(),
            "digests": {
                "raw_log_sha256": self._sha256_file(raw_log_path),
                "normalized_sha256": self._sha256_file(normalized_metadata_path),
                "input_manifest_sha256": self._sha256_file(input_manifest_path),
                "lineage_sha256": self._sha256_file(lineage_path),
            },
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }
        evidence_bundle_path.write_text(json.dumps(evidence_bundle, indent=2), encoding="utf-8")

        return OpenroadMcpCapabilityResponse(
            disposition=Disposition.PASS,
            reason="formal_openroad_mcp_capability_execution_pass",
            contract_id=f"{req.contract_name}@{req.contract_version}",
            request_schema_version=req.request_schema_version,
            boundary_mode=self.BOUNDARY_MODE,
            error_taxonomy=list(self.ERROR_TAXONOMY),
            run_id=run_id,
            execution_run_ref=f"run://{self.CAPABILITY_NAME}/{run_id}",
            tool_version=tool_version,
            artifact_paths={
                "raw_log": raw_log_path.as_posix(),
                "normalized_metadata": normalized_metadata_path.as_posix(),
                "def": def_path.as_posix(),
                "ppa": metrics_path.as_posix(),
                "setup_checks_json": setup_checks_path.as_posix(),
                "hold_checks_json": hold_checks_path.as_posix(),
                "max_slew_report": max_slew_path.as_posix(),
                "max_capacitance_report": max_cap_path.as_posix(),
                "input_manifest": input_manifest_path.as_posix(),
                "lineage": lineage_path.as_posix(),
                "evidence_bundle": evidence_bundle_path.as_posix(),
            },
            artifact_refs={
                "raw_log_ref": f"artifact://openroad/{run_id}/openroad.raw.log",
                "normalized_ref": f"norm://openroad/{run_id}/normalized.drc.meta.json",
                "lineage_ref": f"lineage://openroad/{run_id}/lineage.json",
                "evidence_bundle_ref": f"evidence_bundle://openroad/{run_id}",
            },
        )
