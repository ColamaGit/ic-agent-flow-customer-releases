from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List
from uuid import uuid4

from pydantic import BaseModel

from ic_agent_flow.registry.scenario_registry import Disposition


class YosysMcpCapabilityRequest(BaseModel):
    workspace_id: str
    chip_id: str
    task_id: str
    decision_context_ref: str
    contract_name: str
    contract_version: str
    rtl_path: str
    top_module: str
    timeout_sec: int = 120
    output_root: str = "artifacts/v0.9/yosys"
    yosys_bin: str = "yosys"
    liberty_path: str | None = None
    request_schema_version: str = "v0.1"
    run_key: str | None = None


class YosysMcpCapabilityResponse(BaseModel):
    disposition: Disposition
    reason: str
    contract_id: str
    request_schema_version: str
    boundary_mode: str
    error_taxonomy: List[str]
    run_id: str | None = None
    execution_run_ref: str | None = None
    tool_version: str | None = None
    artifact_paths: Dict[str, str] = {}
    artifact_refs: Dict[str, str] = {}


YosysMcpCapabilityRequest.model_rebuild()
YosysMcpCapabilityResponse.model_rebuild()


class YosysMcpCapabilityBoundary:
    """
    Formal MCP capability boundary for yosys_synth_compile (local mode).
    """

    CAPABILITY_NAME = "yosys_synth_compile"
    CONTRACT_NAME = "yosys_synth_contract"
    CONTRACT_VERSION = "v0.1"
    BOUNDARY_MODE = "formal_mcp_capability_boundary_local_mode_v0.1"
    ERROR_TAXONOMY = [
        "chip_scope_unresolved",
        "input_schema_invalid",
        "tool_missing",
        "tool_timeout",
        "tool_runtime_error",
        "artifact_missing",
        "output_unparseable",
        "decision_context_mismatch",
    ]

    @staticmethod
    def _sha256_file(path: Path) -> str:
        h = hashlib.sha256()
        with path.open("rb") as f:
            while True:
                chunk = f.read(8192)
                if not chunk:
                    break
                h.update(chunk)
        return h.hexdigest()

    @classmethod
    def _fail(cls, reason: str, req: YosysMcpCapabilityRequest) -> YosysMcpCapabilityResponse:
        return YosysMcpCapabilityResponse(
            disposition=Disposition.FAIL_CLOSED,
            reason=reason,
            contract_id=f"{req.contract_name}@{req.contract_version}",
            request_schema_version=req.request_schema_version,
            boundary_mode=cls.BOUNDARY_MODE,
            error_taxonomy=list(cls.ERROR_TAXONOMY),
        )

    def execute(self, req: YosysMcpCapabilityRequest) -> YosysMcpCapabilityResponse:
        required_values = [
            req.workspace_id,
            req.chip_id,
            req.task_id,
            req.decision_context_ref,
            req.contract_name,
            req.contract_version,
            req.rtl_path,
            req.top_module,
        ]
        if any(not value for value in required_values):
            return self._fail("input_schema_invalid:envelope_missing", req)

        if req.contract_name != self.CONTRACT_NAME or req.contract_version != self.CONTRACT_VERSION:
            return self._fail("input_schema_invalid:unsupported_contract", req)

        if not req.decision_context_ref.startswith("decision://"):
            return self._fail("decision_context_mismatch:invalid_context", req)

        rtl_path = Path(req.rtl_path)
        if not rtl_path.exists():
            return self._fail("input_schema_invalid:rtl_not_found", req)

        if shutil.which(req.yosys_bin) is None:
            return self._fail("tool_missing:yosys_not_in_path", req)

        lib_path: Path | None = Path(req.liberty_path) if req.liberty_path else None
        allow_no_liberty_mode = "templates/baseline-digital-soc/" in rtl_path.as_posix()
        if lib_path is None and not allow_no_liberty_mode:
            return self._fail("input_schema_invalid:liberty_path_unresolved", req)
        if lib_path is not None and not lib_path.exists():
            return self._fail("input_schema_invalid:liberty_not_found", req)

        run_id = req.run_key or f"yosys-{uuid4().hex[:12]}"
        out_dir = Path(req.output_root) / run_id
        out_dir.mkdir(parents=True, exist_ok=True)

        raw_log_path = out_dir / "yosys.raw.log"
        netlist_path = out_dir / "top.synth.json"
        netlist_v_path = out_dir / "top.synth.v"
        flat_netlist_v_path = out_dir / "top.synth.flat.v"
        normalized_metadata_path = out_dir / "normalized.netlist.meta.json"
        input_manifest_path = out_dir / "input_manifest.json"
        lineage_path = out_dir / "lineage.json"
        evidence_bundle_path = out_dir / "evidence_bundle.json"

        # Support directory or file for RTL loading
        rtl_inputs = []
        if rtl_path.is_dir():
            v_files = list(rtl_path.glob("*.v")) + list(rtl_path.glob("*.sv"))
            v_files = [f for f in v_files if "testbench" not in f.name.lower() and "tb.v" not in f.name.lower() and "tb.sv" not in f.name.lower()]
            read_v_cmd = " ".join([f'read_verilog -sv -overwrite "{f.as_posix()}";' for f in v_files])
            rtl_inputs = [{"path": f.as_posix(), "sha256": self._sha256_file(f)} for f in v_files]
        else:
            read_v_cmd = f'read_verilog -sv "{rtl_path.as_posix()}";'
            rtl_inputs = [{"path": rtl_path.as_posix(), "sha256": self._sha256_file(rtl_path)}]
        
        if lib_path is not None:
            script = (
                f"{read_v_cmd} "
                f"hierarchy -top {req.top_module}; "
                f'read_liberty -ignore_miss_func "{lib_path.as_posix()}"; '
                f"synth -top {req.top_module}; "
                f'dfflibmap -liberty "{lib_path.as_posix()}"; '
                f'abc -liberty "{lib_path.as_posix()}"; '
                "clean; "
                f'write_json "{netlist_path.as_posix()}"; '
                f'write_verilog -noattr "{netlist_v_path.as_posix()}"; '
                "flatten; "
                "clean; "
                f'write_verilog -noattr "{flat_netlist_v_path.as_posix()}"'
            )
        else:
            script = (
                f"{read_v_cmd} "
                f"hierarchy -top {req.top_module}; "
                f"synth -top {req.top_module}; "
                "clean; "
                f'write_json "{netlist_path.as_posix()}"; '
                f'write_verilog -noattr "{netlist_v_path.as_posix()}"; '
                "flatten; "
                "clean; "
                f'write_verilog -noattr "{flat_netlist_v_path.as_posix()}"'
            )
        command_argv = [req.yosys_bin, "-p", script]
        started_at = datetime.now(timezone.utc)
        try:
            proc = subprocess.run(
                command_argv,
                cwd=str(Path.cwd()),
                capture_output=True,
                text=True,
                timeout=req.timeout_sec,
            )
            finished_at = datetime.now(timezone.utc)
        except subprocess.TimeoutExpired:
            raw_log_path.write_text("tool_timeout: yosys exceeded timeout\n", encoding="utf-8")
            return self._fail("tool_timeout:yosys_execution_timeout", req)

        raw_log_path.write_text((proc.stdout or "") + (proc.stderr or ""), encoding="utf-8")
        if proc.returncode != 0:
            return self._fail("tool_runtime_error:yosys_non_zero_exit", req)
        if not netlist_path.exists() or not netlist_v_path.exists() or not flat_netlist_v_path.exists():
            return self._fail("artifact_missing:netlist_not_generated", req)

        version_proc = subprocess.run(
            [req.yosys_bin, "-V"],
            capture_output=True,
            text=True,
            timeout=15,
        )
        tool_version = (version_proc.stdout or version_proc.stderr or "").strip().splitlines()[0]
        if not tool_version:
            return self._fail("output_unparseable:yosys_version_unavailable", req)

        input_manifest = {
            "workspace_id": req.workspace_id,
            "chip_id": req.chip_id,
            "task_id": req.task_id,
            "contract_name": req.contract_name,
            "contract_version": req.contract_version,
            "decision_context_ref": req.decision_context_ref,
            "tool": "yosys",
            "tool_version": tool_version,
            "tool_binary_path": req.yosys_bin,
            "liberty_path": lib_path.as_posix() if lib_path is not None else None,
            "command": " ".join(command_argv),
            "cwd": str(Path.cwd()),
            "env_fingerprint": {"PATH_present": bool(shutil.which(req.yosys_bin))},
            "rtl_inputs": rtl_inputs,
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }
        input_manifest_path.write_text(json.dumps(input_manifest, indent=2), encoding="utf-8")

        normalized = {
            "tool": "yosys",
            "tool_version": tool_version,
            "contract_name": req.contract_name,
            "contract_version": req.contract_version,
            "rtl_path": rtl_path.as_posix(),
            "top_module": req.top_module,
            "tool_binary_path": req.yosys_bin,
            "liberty_path": lib_path.as_posix() if lib_path is not None else None,
            "status": "PASS",
            "output_refs": [netlist_path.as_posix(), netlist_v_path.as_posix(), flat_netlist_v_path.as_posix()],
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }
        normalized_metadata_path.write_text(json.dumps(normalized, indent=2), encoding="utf-8")

        duration_ms = int((finished_at - started_at).total_seconds() * 1000)
        lineage = {
            "run_id": run_id,
            "started_at": started_at.isoformat(),
            "finished_at": finished_at.isoformat(),
            "exit_code": proc.returncode,
            "duration_ms": duration_ms,
            "command_argv": command_argv,
            "working_dir": str(Path.cwd()),
            "input_manifest_ref": input_manifest_path.as_posix(),
            "output_refs": [
                raw_log_path.as_posix(),
                netlist_path.as_posix(),
                netlist_v_path.as_posix(),
                flat_netlist_v_path.as_posix(),
                normalized_metadata_path.as_posix(),
            ],
            "decision_context_ref": req.decision_context_ref,
            "session_id": "",
            "task_id": req.task_id,
            "workspace_id": req.workspace_id,
            "chip_id": req.chip_id,
        }
        lineage_path.write_text(json.dumps(lineage, indent=2), encoding="utf-8")

        evidence_bundle = {
            "run_id": run_id,
            "raw_refs": [raw_log_path.as_posix()],
            "normalized_refs": [normalized_metadata_path.as_posix()],
            "lineage_ref": lineage_path.as_posix(),
            "digests": {
                "raw_log_sha256": self._sha256_file(raw_log_path),
                "netlist_json_sha256": self._sha256_file(netlist_path),
                "netlist_verilog_sha256": self._sha256_file(netlist_v_path),
                "flat_netlist_verilog_sha256": self._sha256_file(flat_netlist_v_path),
                "normalized_sha256": self._sha256_file(normalized_metadata_path),
                "input_manifest_sha256": self._sha256_file(input_manifest_path),
                "lineage_sha256": self._sha256_file(lineage_path),
            },
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }
        evidence_bundle_path.write_text(json.dumps(evidence_bundle, indent=2), encoding="utf-8")

        return YosysMcpCapabilityResponse(
            disposition=Disposition.PASS,
            reason="formal_yosys_mcp_capability_execution_pass",
            contract_id=f"{req.contract_name}@{req.contract_version}",
            request_schema_version=req.request_schema_version,
            boundary_mode=self.BOUNDARY_MODE,
            error_taxonomy=list(self.ERROR_TAXONOMY),
            run_id=run_id,
            execution_run_ref=f"run://{self.CAPABILITY_NAME}/{run_id}",
            tool_version=tool_version,
            artifact_paths={
                "raw_log": raw_log_path.as_posix(),
                "netlist": netlist_path.as_posix(),
                "netlist_v": netlist_v_path.as_posix(),
                "flat_netlist_v": flat_netlist_v_path.as_posix(),
                "normalized_metadata": normalized_metadata_path.as_posix(),
                "input_manifest": input_manifest_path.as_posix(),
                "lineage": lineage_path.as_posix(),
                "evidence_bundle": evidence_bundle_path.as_posix(),
            },
            artifact_refs={
                "raw_log_ref": f"artifact://yosys/{run_id}/yosys.raw.log",
                "normalized_ref": f"norm://yosys/{run_id}/normalized.netlist.meta.json",
                "lineage_ref": f"lineage://yosys/{run_id}/lineage.json",
                "evidence_bundle_ref": f"evidence_bundle://yosys/{run_id}",
            },
        )
