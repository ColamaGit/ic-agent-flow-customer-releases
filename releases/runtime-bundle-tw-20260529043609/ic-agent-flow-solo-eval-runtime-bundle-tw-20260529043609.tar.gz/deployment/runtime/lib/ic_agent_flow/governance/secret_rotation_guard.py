from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any


REQUIRED_FIELDS = (
    "schema_version",
    "rotation_id",
    "trigger",
    "secret_scope",
    "old_secret_revoked",
    "new_secret_issued",
    "local_validation",
    "executed_by",
    "executed_at",
)


class SecretRotationValidationError(ValueError):
    pass


@dataclass(frozen=True)
class SecretRotationValidationResult:
    valid: bool
    blocked_reason: str | None = None


def _parse_iso8601(ts: str) -> datetime:
    normalized = ts.replace("Z", "+00:00")
    return datetime.fromisoformat(normalized)


def validate_rotation_event(payload: dict[str, Any], *, now: datetime | None = None) -> SecretRotationValidationResult:
    for key in REQUIRED_FIELDS:
        if key not in payload:
            return SecretRotationValidationResult(False, f"missing_required_field:{key}")

    if payload["schema_version"] != "secret-rotation-evidence.v1":
        return SecretRotationValidationResult(False, "invalid_schema_version")

    if payload["old_secret_revoked"] is not True:
        return SecretRotationValidationResult(False, "old_secret_not_revoked")
    if payload["new_secret_issued"] is not True:
        return SecretRotationValidationResult(False, "new_secret_not_issued")

    validation = payload.get("local_validation")
    if not isinstance(validation, dict):
        return SecretRotationValidationResult(False, "invalid_local_validation")
    if validation.get("validate_security_boundary") != "PASS":
        return SecretRotationValidationResult(False, "security_boundary_gate_not_pass")
    if validation.get("validate_ops_retention_omm") != "PASS":
        return SecretRotationValidationResult(False, "ops_retention_omm_gate_not_pass")

    current = now or datetime.now(timezone.utc)
    try:
        executed_at = _parse_iso8601(str(payload["executed_at"]))
    except Exception:
        return SecretRotationValidationResult(False, "invalid_executed_at")

    if executed_at.tzinfo is None:
        return SecretRotationValidationResult(False, "executed_at_without_timezone")
    if executed_at > current + timedelta(minutes=5):
        return SecretRotationValidationResult(False, "executed_at_in_future")

    return SecretRotationValidationResult(True, None)


def append_rotation_event(log_path: Path, payload: dict[str, Any], *, now: datetime | None = None) -> None:
    result = validate_rotation_event(payload, now=now)
    if not result.valid:
        raise SecretRotationValidationError(result.blocked_reason or "invalid_rotation_event")

    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(payload, ensure_ascii=False) + "\n")
