from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List

from pydantic import BaseModel

from ic_agent_flow.governance.v09_phase_gate_orchestrator import (
    PhaseGateInput,
    PhaseGateOutcome,
    V09PhaseGateOrchestrator,
)
from ic_agent_flow.governance.v09_sequencing_law import Step, V09SequencingLaw
from ic_agent_flow.registry.scenario_registry import CanonicalCommandRegistry, Disposition


class PhaseGateConvergenceItem(BaseModel):
    command_id: str
    phase: str
    allowed: bool
    disposition: Disposition
    reason: str


class PhaseGateConvergenceReport(BaseModel):
    items: List[PhaseGateConvergenceItem]
    total_commands: int
    failed_commands: int
    aggregate_disposition: Disposition


def _required_flags_for_step(step: Step) -> Dict[str, bool]:
    required = V09SequencingLaw.REQUIRED_CONDITIONS[step]
    return {name: True for name in required}


def build_phase_gate_convergence_report(registry_path: str | Path) -> PhaseGateConvergenceReport:
    registry = CanonicalCommandRegistry.load_json(registry_path)
    orchestrator = V09PhaseGateOrchestrator(registry)

    items: List[PhaseGateConvergenceItem] = []
    failed = 0
    for entry in registry.entries.values():
        try:
            step = Step(entry.phase)
        except ValueError:
            outcome = PhaseGateOutcome(
                allowed=True,
                disposition=Disposition.PASS,
                reason="non_v09_phase_exempt",
            )
        else:
            outcome = orchestrator.evaluate(
                PhaseGateInput(
                    step=step,
                    command_id=entry.command_id,
                    evidence_flags=_required_flags_for_step(step),
                )
            )

        if not outcome.allowed:
            failed += 1

        items.append(
            PhaseGateConvergenceItem(
                command_id=entry.command_id,
                phase=entry.phase,
                allowed=outcome.allowed,
                disposition=outcome.disposition,
                reason=outcome.reason,
            )
        )

    aggregate = Disposition.PASS if failed == 0 else Disposition.FAIL_CLOSED
    return PhaseGateConvergenceReport(
        items=items,
        total_commands=len(items),
        failed_commands=failed,
        aggregate_disposition=aggregate,
    )


def write_phase_gate_convergence_report(
    report: PhaseGateConvergenceReport,
    json_path: str | Path,
    markdown_path: str | Path,
) -> None:
    json_output = Path(json_path)
    md_output = Path(markdown_path)
    json_output.parent.mkdir(parents=True, exist_ok=True)
    md_output.parent.mkdir(parents=True, exist_ok=True)

    json_output.write_text(
        json.dumps(report.model_dump(mode="json"), indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    lines = [
        "# v0.9 Phase Gate Convergence Report",
        "",
        f"- Aggregate Disposition: {report.aggregate_disposition.value}",
        f"- Total Commands: {report.total_commands}",
        f"- Failed Commands: {report.failed_commands}",
        "",
        "| Command ID | Phase | Allowed | Disposition | Reason |",
        "|---|---|---|---|---|",
    ]
    for item in report.items:
        allowed = "YES" if item.allowed else "NO"
        lines.append(f"| {item.command_id} | {item.phase} | {allowed} | {item.disposition.value} | {item.reason} |")
    md_output.write_text("\n".join(lines) + "\n", encoding="utf-8")
