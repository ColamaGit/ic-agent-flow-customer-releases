"""
PRD v1.3 — Phase 4: Release Package Semantics & Delivery Classification

Governing laws:
  - Law 7: Delivery boundary must be explicit
  - Law 9: Contract must not create a second truth universe
  - PRD Section 10: Delivery and Packaging Boundary
"""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple

from ic_agent_flow.domain.objects.v13_silicon_contract_objects import (
    ChipExportSnapshot,
    ChipPortableWorkspaceBundle,
    ChipReleasePackage,
    DeliveryClass,
    EvidenceRef,
    SiliconContract,
    SiliconReleasePackage,
    V13_DELIVERY_BOUNDARY_MAP,
)


# ---------------------------------------------------------------------------
# Delivery Classification Validation
# ---------------------------------------------------------------------------

def classify_delivery(
    content_type: str,
    recipient_class: str,
) -> Tuple[bool, str]:
    """
    Validate that the given content_type is allowed for the delivery recipient class.
    Returns (is_allowed, reason).
    """
    allowed_classes = V13_DELIVERY_BOUNDARY_MAP.get(content_type)

    if allowed_classes is None:
        return False, f"Unknown content type '{content_type}'"

    allowed_values = [dc.value for dc in allowed_classes]
    if recipient_class not in allowed_values:
        return False, (
            f"Content type '{content_type}' is NOT permitted for "
            f"delivery class '{recipient_class}'. "
            f"Allowed: {allowed_values}"
        )

    return True, "OK"


# ---------------------------------------------------------------------------
# Internal-Only Boundary Enforcement
# ---------------------------------------------------------------------------

# Paths/domains that must never appear in external packages
V13_PROHIBITED_EXTERNAL_PATHS = [
    "package_ws/",
    ".env",
    ".git/",
    "package_ws/shared-runtime/lib/",
    "package_ws/console/",
]


def enforce_internal_only_boundary(package_refs: List[EvidenceRef]) -> Tuple[bool, List[str]]:
    """
    Fail-closed: detect any package_ref URI that exposes internal-only paths.
    Returns (is_clean, list_of_violations).
    """
    violations: List[str] = []

    for ref in package_refs:
        for prohibited_path in V13_PROHIBITED_EXTERNAL_PATHS:
            if prohibited_path in ref.uri:
                violations.append(
                    f"Package ref '{ref.ref_id}' exposes prohibited path "
                    f"'{prohibited_path}' in uri '{ref.uri}'"
                )
                break  # one violation per ref is enough

    return (len(violations) == 0, violations)


# ---------------------------------------------------------------------------
# Package Intent Matrix
# ---------------------------------------------------------------------------

def get_package_intent_matrix() -> Dict[str, Dict]:
    """
    Return the canonical package intent matrix for PRD v1.3 release objects.
    """
    return {
        "silicon_contract": {
            "purpose": "Governance truth binder — defines what release IS",
            "is_delivery_artifact": False,
            "permitted_delivery_classes": [DeliveryClass.INTERNAL_ONLY, DeliveryClass.AUDIT_ONLY],
        },
        "chip_release_package": {
            "purpose": "Release-ready content assembly",
            "is_delivery_artifact": True,
            "permitted_delivery_classes": [
                DeliveryClass.INTERNAL_ONLY,
                DeliveryClass.CUSTOMER_REVIEWABLE,
                DeliveryClass.AUDIT_ONLY,
            ],
        },
        "silicon_release_package": {
            "purpose": "External delivery bundle to customer/foundry",
            "is_delivery_artifact": True,
            "permitted_delivery_classes": [
                DeliveryClass.CUSTOMER_REVIEWABLE,
                DeliveryClass.FOUNDRY_DELIVERABLE,
            ],
        },
        "chip_export_snapshot": {
            "purpose": "Point-in-time snapshot for audit or handoff",
            "is_delivery_artifact": True,
            "permitted_delivery_classes": [
                DeliveryClass.AUDIT_ONLY,
                DeliveryClass.ARCHIVE_ONLY,
                DeliveryClass.CUSTOMER_REVIEWABLE,
                DeliveryClass.FOUNDRY_DELIVERABLE,
            ],
        },
        "chip_portable_workspace_bundle": {
            "purpose": "Portable subset for transfer/reproduction",
            "is_delivery_artifact": True,
            "permitted_delivery_classes": [
                DeliveryClass.INTERNAL_ONLY,
                DeliveryClass.AUDIT_ONLY,
            ],
        },
    }


# ---------------------------------------------------------------------------
# Contract-to-Package Binding
# ---------------------------------------------------------------------------

def validate_contract_package_binding(
    contract: SiliconContract,
    package: ChipReleasePackage,
) -> Tuple[bool, List[str]]:
    """
    Validate that a ChipReleasePackage is correctly bound to its governing SiliconContract.
    Returns (is_valid, list_of_issues).
    """
    issues: List[str] = []

    # contract_ref must match contract_id
    if package.contract_ref != contract.contract_id:
        issues.append(
            f"Package '{package.package_id}' contract_ref '{package.contract_ref}' "
            f"does not match contract '{contract.contract_id}'"
        )

    # chip_id must match
    if package.chip_id != contract.chip_id:
        issues.append(
            f"Package chip_id '{package.chip_id}' != contract chip_id '{contract.chip_id}'"
        )

    # Delivery class must be permitted for chip_release_package
    matrix = get_package_intent_matrix()
    permitted = matrix["chip_release_package"]["permitted_delivery_classes"]
    if package.delivery_classification not in permitted:
        issues.append(
            f"Package delivery_classification '{package.delivery_classification}' "
            f"is not permitted for chip_release_package. Permitted: {permitted}"
        )

    # Internal boundary check
    clean, violations = enforce_internal_only_boundary(package.contents)
    if not clean:
        issues.extend(violations)

    return (len(issues) == 0, issues)
