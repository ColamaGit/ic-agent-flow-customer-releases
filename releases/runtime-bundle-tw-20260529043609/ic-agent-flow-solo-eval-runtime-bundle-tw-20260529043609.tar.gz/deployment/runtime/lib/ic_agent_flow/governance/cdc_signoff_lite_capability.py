from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional
from uuid import uuid4

from pydantic import BaseModel

from ic_agent_flow.registry.scenario_registry import Disposition


def _collect_rtl_files(rtl_path: Path) -> List[Path]:
    if rtl_path.is_file():
        n = rtl_path.name.lower()
        if "testbench" in n or n.endswith("_tb.v") or n.endswith("_tb.sv"):
            return []
        return [rtl_path]
    if rtl_path.is_dir():
        files = sorted(list(rtl_path.glob("*.v")) + list(rtl_path.glob("*.sv")))
        return [
            p
            for p in files
            if "testbench" not in p.name.lower()
            and not p.name.lower().endswith("_tb.v")
            and not p.name.lower().endswith("_tb.sv")
        ]
    return []


class CdcSignoffLiteRequest(BaseModel):
    workspace_id: str
    chip_id: str
    task_id: str
    decision_context_ref: str
    contract_name: str
    contract_version: str
    rtl_path: str
    top_module: str
    property_pack_path: str
    output_root: str = "artifacts/v1.11/cdc_signoff_lite"
    request_schema_version: str = "v0.1"
    run_key: Optional[str] = None
    sby_bin: Optional[str] = None
    engine: str = "smtbmc"


class CdcSignoffLiteResponse(BaseModel):
    disposition: Disposition
    reason: str
    contract_id: str
    request_schema_version: str
    boundary_mode: str
    error_taxonomy: List[str]
    run_id: Optional[str] = None
    execution_run_ref: Optional[str] = None
    artifact_paths: Dict[str, str] = {}
    artifact_refs: Dict[str, str] = {}


CdcSignoffLiteRequest.model_rebuild()
CdcSignoffLiteResponse.model_rebuild()


class CdcSignoffLiteCapabilityBoundary:
    CAPABILITY_NAME = "cdc_signoff_lite"
    CONTRACT_NAME = "cdc_signoff_lite_contract"
    CONTRACT_VERSION = "v0.1"
    BOUNDARY_MODE = "formal_mcp_capability_boundary_local_mode_v0.1"
    ERROR_TAXONOMY = [
        "chip_scope_unresolved",
        "input_schema_invalid",
        "artifact_missing",
        "tool_unavailable",
        "output_unparseable",
        "decision_context_mismatch",
    ]

    @staticmethod
    def _sha256_file(path: Path) -> str:
        h = hashlib.sha256()
        with path.open("rb") as f:
            while True:
                chunk = f.read(8192)
                if not chunk:
                    break
                h.update(chunk)
        return h.hexdigest()

    @staticmethod
    def _resolve_solver_name() -> Optional[str]:
        if shutil.which("z3"):
            return "z3"
        if shutil.which("yices-smt2"):
            return "yices"
        if shutil.which("boolector"):
            return "boolector"
        return None

    @classmethod
    def _fail(cls, reason: str, req: CdcSignoffLiteRequest) -> CdcSignoffLiteResponse:
        return CdcSignoffLiteResponse(
            disposition=Disposition.FAIL_CLOSED,
            reason=reason,
            contract_id=f"{req.contract_name}@{req.contract_version}",
            request_schema_version=req.request_schema_version,
            boundary_mode=cls.BOUNDARY_MODE,
            error_taxonomy=list(cls.ERROR_TAXONOMY),
        )

    def execute(self, req: CdcSignoffLiteRequest) -> CdcSignoffLiteResponse:
        required = [
            req.workspace_id,
            req.chip_id,
            req.task_id,
            req.decision_context_ref,
            req.contract_name,
            req.contract_version,
            req.rtl_path,
            req.top_module,
            req.property_pack_path,
        ]
        if any(not value for value in required):
            return self._fail("input_schema_invalid:envelope_missing", req)
        if req.contract_name != self.CONTRACT_NAME or req.contract_version != self.CONTRACT_VERSION:
            return self._fail("input_schema_invalid:unsupported_contract", req)
        if not req.decision_context_ref.startswith("decision://"):
            return self._fail("decision_context_mismatch:invalid_context", req)

        rtl_path = Path(req.rtl_path)
        rtl_files = _collect_rtl_files(rtl_path)
        if not rtl_files:
            return self._fail("artifact_missing:rtl_sources_not_found", req)

        property_pack = Path(req.property_pack_path)
        if not property_pack.exists():
            return self._fail("artifact_missing:property_pack_missing", req)

        run_id = req.run_key or f"csl-{uuid4().hex[:12]}"
        out_dir = Path(req.output_root) / run_id
        out_dir.mkdir(parents=True, exist_ok=True)

        normalized_path = out_dir / "normalized.cdc_signoff_lite.meta.json"
        lineage_path = out_dir / "lineage.json"
        evidence_bundle_path = out_dir / "cdc_signoff_lite_evidence_bundle.json"
        sby_config_path = out_dir / "sby_config.sby"
        raw_log_path = out_dir / "sby.raw.log"

        started_at = datetime.now(timezone.utc)
        sby_bin = req.sby_bin or shutil.which("sby")
        proof_scope = "bounded_cdc_lite"
        claim_class = "NON_SIGNOFF_CDC_LITE"

        solver_name = self._resolve_solver_name()
        engine_line = f"{req.engine} {solver_name}" if solver_name else req.engine

        if not sby_bin:
            rtl_reads = "\n".join(f"read -formal {p.as_posix()}" for p in rtl_files)
            sby_cfg = f"""[options]
mode prove
depth 20

[engines]
{engine_line}

[script]
{rtl_reads}
read -formal {property_pack.as_posix()}
prep -top {req.top_module}

[files]
{property_pack.as_posix()}
"""
            sby_config_path.write_text(sby_cfg, encoding="utf-8")
            raw_log_path.write_text("sby not found; skipped execution.\n", encoding="utf-8")
            normalized = {
                "tool": "symbiyosys",
                "status": "NOT_CHECKED",
                "claim_class": claim_class,
                "proof_scope": proof_scope,
                "clock_domain_count": None,
                "property_pack_ref": property_pack.as_posix(),
                "engine": req.engine,
                "engine_version": None,
                "proved_count": 0,
                "failed_count": 0,
                "unknown_count": 0,
                "timeout_count": 0,
                "waiver_count": 0,
                "notes": "sby binary not available; cdc signoff-lite not executed.",
                "generated_at": datetime.now(timezone.utc).isoformat(),
            }
            normalized_path.write_text(json.dumps(normalized, indent=2), encoding="utf-8")
            finished_at = datetime.now(timezone.utc)
            lineage = {
                "run_id": run_id,
                "started_at": started_at.isoformat(),
                "finished_at": finished_at.isoformat(),
                "duration_ms": int((finished_at - started_at).total_seconds() * 1000),
                "input_refs": [p.as_posix() for p in rtl_files] + [property_pack.as_posix()],
                "output_refs": [raw_log_path.as_posix(), normalized_path.as_posix()],
                "decision_context_ref": req.decision_context_ref,
                "task_id": req.task_id,
                "workspace_id": req.workspace_id,
                "chip_id": req.chip_id,
            }
            lineage_path.write_text(json.dumps(lineage, indent=2), encoding="utf-8")
            evidence_bundle = {
                "lineage_ref": "v3b_cdc_signoff_lite/lineage.json",
                "raw_refs": [
                    "v3b_cdc_signoff_lite/sby.raw.log",
                    "v3b_cdc_signoff_lite/sby_config.sby",
                ],
                "normalized_refs": ["v3b_cdc_signoff_lite/normalized.cdc_signoff_lite.meta.json"],
                "digests": {
                    "raw_log_sha256": self._sha256_file(raw_log_path),
                    "normalized_sha256": self._sha256_file(normalized_path),
                    "sby_config_sha256": self._sha256_file(sby_config_path),
                },
                "generated_at": datetime.now(timezone.utc).isoformat(),
            }
            evidence_bundle_path.write_text(json.dumps(evidence_bundle, indent=2), encoding="utf-8")
            return CdcSignoffLiteResponse(
                disposition=Disposition.FAIL_CLOSED,
                reason="tool_unavailable:sby_not_found",
                contract_id=f"{req.contract_name}@{req.contract_version}",
                request_schema_version=req.request_schema_version,
                boundary_mode=self.BOUNDARY_MODE,
                error_taxonomy=list(self.ERROR_TAXONOMY),
                run_id=run_id,
                execution_run_ref=f"run://cdc_signoff_lite/{run_id}",
                artifact_paths={
                    "normalized": normalized_path.as_posix(),
                    "lineage": lineage_path.as_posix(),
                    "evidence_bundle": evidence_bundle_path.as_posix(),
                },
                artifact_refs={
                    "normalized_ref": f"norm://cdc_signoff_lite/{run_id}/normalized.cdc_signoff_lite.meta.json",
                    "lineage_ref": f"lineage://cdc_signoff_lite/{run_id}/lineage.json",
                    "evidence_bundle_ref": f"evidence_bundle://cdc_signoff_lite/{run_id}",
                },
            )

        rtl_reads = "\n".join(f"read -formal {p.as_posix()}" for p in rtl_files)
        sby_cfg = f"""[options]
mode prove
depth 20

[engines]
{engine_line}

[script]
{rtl_reads}
read -formal {property_pack.as_posix()}
prep -top {req.top_module}

[files]
{property_pack.as_posix()}
"""
        sby_config_path.write_text(sby_cfg, encoding="utf-8")

        proc = subprocess.run(
            [sby_bin, str(sby_config_path)],
            cwd=out_dir.as_posix(),
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=180,
        )
        raw_log = proc.stdout or ""
        raw_log_path.write_text(raw_log, encoding="utf-8")

        passed = proc.returncode == 0
        normalized = {
            "tool": "symbiyosys",
            "status": "PASS" if passed else "PARTIAL",
            "claim_class": claim_class,
            "proof_scope": proof_scope,
            "clock_domain_count": None,
            "property_pack_ref": property_pack.as_posix(),
            "engine": req.engine,
            "engine_version": solver_name,
            "proved_count": 1 if passed else 0,
            "failed_count": 0 if passed else 1,
            "unknown_count": 0,
            "timeout_count": 0,
            "waiver_count": 0,
            "notes": "SymbiYosys cdc signoff-lite execution completed." if passed else "SymbiYosys execution incomplete; inspect raw log.",
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }
        normalized_path.write_text(json.dumps(normalized, indent=2), encoding="utf-8")

        finished_at = datetime.now(timezone.utc)
        lineage = {
            "run_id": run_id,
            "started_at": started_at.isoformat(),
            "finished_at": finished_at.isoformat(),
            "duration_ms": int((finished_at - started_at).total_seconds() * 1000),
            "input_refs": [p.as_posix() for p in rtl_files] + [property_pack.as_posix()],
            "output_refs": [sby_config_path.as_posix(), raw_log_path.as_posix(), normalized_path.as_posix()],
            "decision_context_ref": req.decision_context_ref,
            "task_id": req.task_id,
            "workspace_id": req.workspace_id,
            "chip_id": req.chip_id,
        }
        lineage_path.write_text(json.dumps(lineage, indent=2), encoding="utf-8")

        evidence_bundle = {
            "lineage_ref": "v3b_cdc_signoff_lite/lineage.json",
            "raw_refs": [
                "v3b_cdc_signoff_lite/sby.raw.log",
                "v3b_cdc_signoff_lite/sby_config.sby",
            ],
            "normalized_refs": ["v3b_cdc_signoff_lite/normalized.cdc_signoff_lite.meta.json"],
            "digests": {
                "raw_log_sha256": self._sha256_file(raw_log_path),
                "normalized_sha256": self._sha256_file(normalized_path),
                "sby_config_sha256": self._sha256_file(sby_config_path),
            },
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }
        evidence_bundle_path.write_text(json.dumps(evidence_bundle, indent=2), encoding="utf-8")

        return CdcSignoffLiteResponse(
            disposition=Disposition.PASS if passed else Disposition.FAIL_CLOSED,
            reason="cdc_signoff_lite_completed" if passed else "cdc_signoff_lite_not_proved",
            contract_id=f"{req.contract_name}@{req.contract_version}",
            request_schema_version=req.request_schema_version,
            boundary_mode=self.BOUNDARY_MODE,
            error_taxonomy=list(self.ERROR_TAXONOMY),
            run_id=run_id,
            execution_run_ref=f"run://cdc_signoff_lite/{run_id}",
            artifact_paths={
                "normalized": normalized_path.as_posix(),
                "lineage": lineage_path.as_posix(),
                "evidence_bundle": evidence_bundle_path.as_posix(),
                "raw_log": raw_log_path.as_posix(),
                "config": sby_config_path.as_posix(),
            },
            artifact_refs={
                "normalized_ref": f"norm://cdc_signoff_lite/{run_id}/normalized.cdc_signoff_lite.meta.json",
                "lineage_ref": f"lineage://cdc_signoff_lite/{run_id}/lineage.json",
                "evidence_bundle_ref": f"evidence_bundle://cdc_signoff_lite/{run_id}",
            },
        )
