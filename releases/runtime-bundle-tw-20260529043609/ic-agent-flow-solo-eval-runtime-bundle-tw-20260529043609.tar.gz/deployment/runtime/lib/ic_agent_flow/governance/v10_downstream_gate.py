from __future__ import annotations

import json
from enum import Enum
from pathlib import Path
from typing import List, Optional

from pydantic import BaseModel, Field

from ic_agent_flow.governance.v10_freeze_to_plan import (
    assess_freeze_to_plan,
    assess_freeze_to_plan_with_paths,
)
from ic_agent_flow.governance.v10_graph_validation import assess_graph_validation_chain
from ic_agent_flow.governance.v10_spec_completion import assess_spec_completion_chain


class DownstreamAdmissionStatus(str, Enum):
    ALLOWED = "ALLOWED"
    BLOCKED = "BLOCKED"


class DownstreamAdmission(BaseModel):
    status: DownstreamAdmissionStatus
    h1_plus_allowed: bool
    blocking_reasons: List[str] = Field(default_factory=list)


def _load_json(path: Path) -> dict:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def _requirement_adjudication_blocking_reason(specs_dir: Path) -> str | None:
    record_path = specs_dir / "requirement_item_adjudication_record.json"
    record = _load_json(record_path)
    if not record_path.exists():
        return "requirement_adjudication_decision_missing"

    status = str(record.get("status", "")).upper()
    outcome = str(record.get("decision_outcome", "")).lower()

    if status != "DECISION_RECORDED":
        return "requirement_adjudication_decision_not_recorded"
    if outcome == "reject":
        return "requirement_adjudication_rejected"
    if outcome == "request_more_evidence":
        return "requirement_adjudication_requires_more_evidence"
    if outcome not in {"approve", "approve_with_conditions"}:
        return "requirement_adjudication_decision_invalid"

    review_package = _load_json(specs_dir / "requirement_item_review_package.json")
    review_status = str(review_package.get("status", "")).upper()
    if review_status in {"ADJUDICATED_REJECTED", "REJECTED"}:
        return "requirement_adjudication_rejected"
    if review_status in {"ADJUDICATED_REQUEST_MORE_EVIDENCE", "REQUEST_MORE_EVIDENCE"}:
        return "requirement_adjudication_requires_more_evidence"

    return None


def _first_existing(paths: List[Path]) -> Optional[Path]:
    for path in paths:
        if path.exists():
            return path
    return None


def _load_json_strict(path: Optional[Path]) -> tuple[dict, bool]:
    if path is None or not path.exists():
        return {}, False
    try:
        return json.loads(path.read_text(encoding="utf-8")), True
    except (OSError, json.JSONDecodeError):
        return {}, False


def _freeze_record_ref_matches(freeze_ref: str, chip_dir: Path) -> bool:
    normalized_ref = freeze_ref.replace("\\", "/").strip()
    if not normalized_ref:
        return False
    chip_rel_root = Path("chips") / chip_dir.name
    allowed_refs = {
        f"{chip_rel_root.as_posix()}/architecture/graph_freeze_record.json",
        f"{chip_rel_root.as_posix()}/governance/freeze/graph_freeze_record.json",
    }
    return any(
        normalized_ref == allowed_ref or normalized_ref.endswith(allowed_ref)
        for allowed_ref in allowed_refs
    )


def derive_downstream_admission(chip_dir: Path | str) -> DownstreamAdmission:
    chip_dir = Path(chip_dir)
    spec = assess_spec_completion_chain(chip_dir / "specs")
    graph_validation_dir = (
        chip_dir / "architecture" / "validation"
        if (chip_dir / "architecture" / "validation" / "graph_validation_result.json").exists()
        else chip_dir / "architecture"
    )
    graph = assess_graph_validation_chain(graph_validation_dir)

    freeze_dir = (
        chip_dir / "governance" / "freeze"
        if (chip_dir / "governance" / "freeze" / "graph_freeze_record.json").exists()
        else chip_dir / "architecture"
    )
    plan_dir = (
        chip_dir / "generation"
        if (chip_dir / "generation" / "graph_to_generation_plan.json").exists()
        else chip_dir / "architecture"
    )
    freeze_record_path = _first_existing(
        [
            chip_dir / "governance" / "freeze" / "graph_freeze_record.json",
            chip_dir / "architecture" / "graph_freeze_record.json",
        ]
    )
    generation_plan_path = _first_existing(
        [
            chip_dir / "generation" / "graph_to_generation_plan.json",
            chip_dir / "architecture" / "graph_to_generation_plan.json",
        ]
    )
    if freeze_record_path and generation_plan_path:
        freeze_to_plan = assess_freeze_to_plan_with_paths(
            freeze_record_path=freeze_record_path,
            generation_plan_path=generation_plan_path,
        )
    else:
        freeze_to_plan = assess_freeze_to_plan(chip_dir / "architecture")

    blocking_reasons: List[str] = []
    if not spec.chain_complete:
        blocking_reasons.append("spec_completion_chain_incomplete")

    if not graph.verdict:
        blocking_reasons.append("graph_validation_verdict_missing")
    elif graph.verdict not in {"PASS", "PASS_WITH_WARNINGS"}:
        blocking_reasons.append(f"graph_validation_verdict_{graph.verdict.lower()}")
    if graph.freeze_blocked or not graph.validation_chain_complete:
        blocking_reasons.append("graph_validation_not_ready")

    freeze_record, freeze_json_valid = _load_json_strict(freeze_record_path)
    if not freeze_record_path:
        blocking_reasons.append("graph_freeze_record_missing")
    elif not freeze_json_valid:
        blocking_reasons.append("graph_freeze_record_invalid_json")
    elif str(freeze_record.get("freeze_state", "")).upper() not in {
        "FROZEN",
        "FROZEN_WITH_CONDITIONS",
        "CONDITIONAL_FREEZE",
    }:
        blocking_reasons.append("graph_freeze_state_not_frozen")

    generation_plan, plan_json_valid = _load_json_strict(generation_plan_path)
    if not generation_plan_path:
        blocking_reasons.append("generation_plan_missing")
    elif not plan_json_valid:
        blocking_reasons.append("generation_plan_invalid_json")
    else:
        freeze_ref = str(generation_plan.get("graph_freeze_record_ref", "")).strip()
        if not freeze_ref:
            blocking_reasons.append("generation_plan_missing_graph_freeze_ref")
        if generation_plan.get("machine_consumable") is not True:
            blocking_reasons.append("generation_plan_not_machine_consumable")

    if freeze_record_path and generation_plan_path and plan_json_valid:
        freeze_ref = str(generation_plan.get("graph_freeze_record_ref", "")).replace("\\", "/")
        if freeze_ref and not _freeze_record_ref_matches(freeze_ref, chip_dir):
            blocking_reasons.append("generation_plan_freeze_ref_mismatch")

    if not freeze_to_plan.freeze_eligible:
        blocking_reasons.append("freeze_eligibility_not_ready")
    if not freeze_to_plan.plan_ready:
        blocking_reasons.append("freeze_to_plan_not_ready")
    if not (plan_dir / "graph_to_generation_plan.json").exists() and not (chip_dir / "architecture" / "graph_to_generation_plan.json").exists():
        blocking_reasons.append("generation_plan_not_ready")

    adjudication_block = _requirement_adjudication_blocking_reason(chip_dir / "specs")
    if adjudication_block:
        blocking_reasons.append(adjudication_block)

    h1_plus_allowed = not blocking_reasons
    return DownstreamAdmission(
        status=DownstreamAdmissionStatus.ALLOWED if h1_plus_allowed else DownstreamAdmissionStatus.BLOCKED,
        h1_plus_allowed=h1_plus_allowed,
        blocking_reasons=blocking_reasons,
    )
