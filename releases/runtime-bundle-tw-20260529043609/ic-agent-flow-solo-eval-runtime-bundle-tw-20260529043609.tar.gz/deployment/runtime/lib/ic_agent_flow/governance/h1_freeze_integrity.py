from __future__ import annotations

import json
from pathlib import Path
from typing import List

from pydantic import BaseModel

from ic_agent_flow.registry.scenario_registry import Disposition


class H1FreezeIntegrityResult(BaseModel):
    disposition: Disposition
    reason: str
    missing_paths: List[str]
    missing_in_note: List[str]
    checked_paths: List[str]


DEFAULT_REQUIRED_PATHS = [
    "package_ws/docs/governance/closeout/v0.9/mcp_capability_single_e2e_validator.v0.2.json",
    "package_ws/docs/governance/closeout/v0.9/phase6_mcp_single_cap_e2e_report.v0.2.md",
    "package_ws/docs/governance/closeout/v0.9/canonical_command_registry.v0.1.json",
    "package_ws/docs/governance/closeout/v0.9/closeout_evidence_index.v0.1.json",
    "package_ws/docs/governance/closeout/v0.9/phase_gate_convergence_report.v0.1.json",
]


def validate_h1_freeze_integrity(
    note_path: str | Path,
    required_paths: List[str] | None = None,
) -> H1FreezeIntegrityResult:
    required = required_paths or list(DEFAULT_REQUIRED_PATHS)
    note_file = Path(note_path)
    if not note_file.exists():
        return H1FreezeIntegrityResult(
            disposition=Disposition.FAIL_CLOSED,
            reason="h1_freeze_note_missing",
            missing_paths=[str(note_file)],
            missing_in_note=[],
            checked_paths=required,
        )

    note_text = note_file.read_text(encoding="utf-8")
    missing_paths = [path for path in required if not Path(path).exists()]
    missing_in_note = [path for path in required if path not in note_text]
    if missing_paths:
        return H1FreezeIntegrityResult(
            disposition=Disposition.HOLD,
            reason="freeze_anchor_path_missing",
            missing_paths=missing_paths,
            missing_in_note=missing_in_note,
            checked_paths=required,
        )
    if missing_in_note:
        return H1FreezeIntegrityResult(
            disposition=Disposition.HOLD,
            reason="freeze_anchor_not_declared_in_note",
            missing_paths=[],
            missing_in_note=missing_in_note,
            checked_paths=required,
        )
    return H1FreezeIntegrityResult(
        disposition=Disposition.PASS,
        reason="h1_freeze_integrity_pass",
        missing_paths=[],
        missing_in_note=[],
        checked_paths=required,
    )


def write_h1_freeze_integrity_report(
    result: H1FreezeIntegrityResult,
    json_path: str | Path,
    markdown_path: str | Path,
) -> None:
    json_output = Path(json_path)
    md_output = Path(markdown_path)
    json_output.parent.mkdir(parents=True, exist_ok=True)
    md_output.parent.mkdir(parents=True, exist_ok=True)
    json_output.write_text(json.dumps(result.model_dump(mode="json"), indent=2, ensure_ascii=False), encoding="utf-8")
    lines = [
        "# H1 Freeze Integrity Report v0.1",
        "",
        f"- Disposition: `{result.disposition.value}`",
        f"- Reason: `{result.reason}`",
        "",
        "## Checked Paths",
    ]
    lines.extend([f"- `{p}`" for p in result.checked_paths])
    if result.missing_paths:
        lines.extend(["", "## Missing Paths"])
        lines.extend([f"- `{p}`" for p in result.missing_paths])
    if result.missing_in_note:
        lines.extend(["", "## Missing In Note"])
        lines.extend([f"- `{p}`" for p in result.missing_in_note])
    md_output.write_text("\n".join(lines) + "\n", encoding="utf-8")
