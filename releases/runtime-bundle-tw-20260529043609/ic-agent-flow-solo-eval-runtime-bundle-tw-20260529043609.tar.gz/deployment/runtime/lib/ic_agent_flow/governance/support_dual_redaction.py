from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class DualRedactionPolicy:
    customer_ip_redaction: bool
    vendor_ip_redaction: bool
    vendor_internal_object_denylist: list[str] | None = None


@dataclass(frozen=True)
class SupportExportCandidate:
    incident_id: str
    included_objects: list[str]
    logs: list[str]
    export_recipient_scope: str
    support_operator_authority: str

    def __post_init__(self) -> None:
        if not self.support_operator_authority:
            raise ValueError("support_operator_authority_required")


@dataclass(frozen=True)
class SupportDualRedactionReport:
    allowed: bool
    blocking_reasons: list[str]
    audit_record: dict[str, object]


class SupportDualRedactionValidator:
    source_prefixes = ["package_ws/", "internal-redacted/", "tests/"]
    vendor_trace_markers = ["prompt_trace", "context assembly", "vendor proprietary internals"]

    def validate(
        self,
        candidate: SupportExportCandidate,
        *,
        policy: DualRedactionPolicy,
    ) -> SupportDualRedactionReport:
        blocking_reasons: list[str] = []
        if not policy.customer_ip_redaction:
            blocking_reasons.append("customer_ip_redaction_required")
        if not policy.vendor_ip_redaction:
            blocking_reasons.append("vendor_ip_redaction_required")

        denylist = list(policy.vendor_internal_object_denylist or [])
        for included_object in candidate.included_objects:
            if any(included_object.startswith(prefix) for prefix in self.source_prefixes):
                blocking_reasons.append(f"source_tree_object:{included_object}")
            if any(denied in included_object for denied in denylist):
                blocking_reasons.append(f"vendor_internal_object:{included_object}")

        joined_logs = "\n".join(candidate.logs).lower()
        if any(marker in joined_logs for marker in self.vendor_trace_markers):
            blocking_reasons.append("vendor_prompt_trace_present")

        audit_record = {
            "incident_id": candidate.incident_id,
            "export_recipient_scope": candidate.export_recipient_scope,
            "support_operator_authority": candidate.support_operator_authority,
            "customer_ip_redaction": policy.customer_ip_redaction,
            "vendor_ip_redaction": policy.vendor_ip_redaction,
            "allowed": not blocking_reasons,
            "blocking_reasons": blocking_reasons,
        }
        return SupportDualRedactionReport(
            allowed=not blocking_reasons,
            blocking_reasons=blocking_reasons,
            audit_record=audit_record,
        )
