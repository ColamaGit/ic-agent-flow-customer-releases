from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class MCPCapabilityBase(ABC):
    """
    Minimal compatibility base for legacy MCP capability classes.
    """

    contract_id: str

    @abstractmethod
    def execute(self, *args: Any, **kwargs: Any) -> Any:
        raise NotImplementedError
