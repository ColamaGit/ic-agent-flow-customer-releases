from __future__ import annotations

import math
import re
from dataclasses import dataclass
from enum import Enum


class LeakSeverity(str, Enum):
    INFO = "INFO"
    WARNING = "WARNING"
    BLOCKING = "BLOCKING"
    CRITICAL = "CRITICAL"


@dataclass(frozen=True)
class VendorIPLeakFinding:
    rule_id: str
    asset_path: str
    severity: LeakSeverity
    message: str
    remediation: str


@dataclass(frozen=True)
class VendorIPLeakScanReport:
    scan_id: str
    bundle_ref: str
    findings: list[VendorIPLeakFinding]
    severity_summary: dict[str, int]
    blocked: bool
    scanner_version: str


class VendorIPLeakScanner:
    semantic_patterns = (
        re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b"),
        re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
        re.compile(r"\bghp_[A-Za-z0-9]{20,}\b"),
        re.compile(r"\bsk-[A-Za-z0-9]{16,}\b"),
    )
    entropy_token = re.compile(r"[A-Za-z0-9_\\-]{20,}")
    entropy_threshold = 4.5
    rules = {
        "internal_prompt_or_context": {
            "patterns": ["prompt_trace", "context assembly", "context_assembly", "internal prompt"],
            "severity": LeakSeverity.BLOCKING,
            "remediation": "remove prompt/context trace or replace with redacted support summary",
        },
        "absolute_internal_path": {
            "patterns": ["/users/", "/customer-home/", "c:\\users\\", "/package_ws/", "file://"],
            "severity": LeakSeverity.BLOCKING,
            "remediation": "remove internal absolute path and replace with canonical logical artifact ref",
        },
        "secret_token": {
            "patterns": ["OPENAI_API_KEY=", "sk-", "SECRET_KEY=", "TOKEN="],
            "severity": LeakSeverity.CRITICAL,
            "remediation": "remove secret and rotate credential",
        },
        "internal_roadmap": {
            "patterns": ["unreleased roadmap", "internal closeout reasoning"],
            "severity": LeakSeverity.BLOCKING,
            "remediation": "remove internal governance artifact from package",
        },
        "private_validator": {
            "patterns": ["private validator", "validator_internal"],
            "severity": LeakSeverity.BLOCKING,
            "remediation": "expose only public contract result",
        },
    }

    @staticmethod
    def _shannon_entropy(token: str) -> float:
        if not token:
            return 0.0
        freq = {}
        for ch in token:
            freq[ch] = freq.get(ch, 0) + 1
        length = len(token)
        return -sum((count / length) * math.log2(count / length) for count in freq.values())

    def scan_text_assets(self, *, bundle_ref: str, assets: dict[str, str]) -> VendorIPLeakScanReport:
        findings: list[VendorIPLeakFinding] = []
        for asset_path, content in assets.items():
            normalized = content.lower()
            for rule_id, rule in self.rules.items():
                if any(pattern.lower() in normalized for pattern in rule["patterns"]):
                    findings.append(
                        VendorIPLeakFinding(
                            rule_id=rule_id,
                            asset_path=asset_path,
                            severity=rule["severity"],
                            message=f"{rule_id} detected in {asset_path}",
                            remediation=rule["remediation"],
                        )
                    )
                    break
            else:
                semantic_hit = next(
                    (pattern.search(content) for pattern in self.semantic_patterns if pattern.search(content)),
                    None,
                )
                if semantic_hit:
                    findings.append(
                        VendorIPLeakFinding(
                            rule_id="semantic_leak_pattern",
                            asset_path=asset_path,
                            severity=LeakSeverity.BLOCKING,
                            message=f"semantic_leak_pattern detected in {asset_path}",
                            remediation="remove semantic secret/path/IP pattern or replace with redacted exemplar",
                        )
                    )
                    continue
                for token in self.entropy_token.findall(content):
                    if self._shannon_entropy(token) > self.entropy_threshold:
                        findings.append(
                            VendorIPLeakFinding(
                                rule_id="high_entropy_token",
                                asset_path=asset_path,
                                severity=LeakSeverity.WARNING,
                                message=f"high_entropy_token detected in {asset_path}",
                                remediation="review token and redact if it is credential-like or internal secret",
                            )
                        )
                        break

        severity_summary = {severity.value: 0 for severity in LeakSeverity}
        for finding in findings:
            severity_summary[finding.severity.value] += 1

        return VendorIPLeakScanReport(
            scan_id=f"leak-scan://{bundle_ref}",
            bundle_ref=bundle_ref,
            findings=findings,
            severity_summary=severity_summary,
            blocked=any(f.severity in {LeakSeverity.BLOCKING, LeakSeverity.CRITICAL} for f in findings),
            scanner_version="v1.6.0",
        )
