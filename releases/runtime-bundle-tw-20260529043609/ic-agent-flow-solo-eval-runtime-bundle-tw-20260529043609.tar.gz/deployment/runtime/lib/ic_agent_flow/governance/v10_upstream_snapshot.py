from __future__ import annotations

import hashlib
import json
import os
import shutil
from enum import Enum
from pathlib import Path
from typing import Any, Dict, Optional

from pydantic import BaseModel, Field

from ic_agent_flow.domain.utils.time import get_tw_now
from ic_agent_flow.governance.upstream_alignment_map import ensure_upstream_alignment_map


class KickoffMode(str, Enum):
    SPEC_FIRST = "spec_first"
    RTL_COMPAT = "rtl_compat"


class UpstreamGateState(str, Enum):
    NO_UPSTREAM_OBJECTS = "NO_UPSTREAM_OBJECTS"
    PROVISIONAL_SPEC_ONLY = "PROVISIONAL_SPEC_ONLY"
    PROVISIONAL_GRAPH_PRESENT = "PROVISIONAL_GRAPH_PRESENT"
    VALIDATED_NOT_FROZEN = "VALIDATED_NOT_FROZEN"
    FREEZE_ELIGIBLE = "FREEZE_ELIGIBLE"
    FROZEN_PLAN_READY = "FROZEN_PLAN_READY"


class UpstreamAdmissionManifest(BaseModel):
    chip_id: str
    kickoff_mode: KickoffMode
    upstream_gate_state: UpstreamGateState
    snapshot_refs: Dict[str, str]
    canonical_refs: Dict[str, Optional[str]]
    snapshot_digests: Dict[str, str]
    freeze_ref: Optional[str] = None
    generation_plan_ref: Optional[str] = None
    created_at: str = Field(default_factory=lambda: get_tw_now().isoformat())


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def _copy_dir_if_exists(src: Path, dest: Path) -> None:
    dest.mkdir(parents=True, exist_ok=True)
    if src.is_dir():
        shutil.copytree(src, dest, dirs_exist_ok=True)


def _copy_constraints_snapshot(rtl_src: Path, design_root: Path) -> None:
    constraints_dest = design_root / "constraints"
    candidate_dirs = []
    if rtl_src.is_dir():
        candidate_dirs.append(rtl_src / "constraints")
        candidate_dirs.append(rtl_src.parent / "constraints")
    elif rtl_src.is_file():
        candidate_dirs.append(rtl_src.parent / "constraints")
    for candidate in candidate_dirs:
        if not candidate.is_dir():
            continue
        copied = False
        constraints_dest.mkdir(parents=True, exist_ok=True)
        for sdc in sorted(candidate.glob("*.sdc")):
            shutil.copy2(sdc, constraints_dest / sdc.name)
            copied = True
        if copied:
            return


def _copy_file_if_exists(src: Path, dest: Path) -> None:
    if not src.is_file():
        return
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dest)


def _materialize_graph_handoff_snapshot(chip_dir: Path, graph_snapshot_dir: Path) -> None:
    """Flatten current CHIP_UPSTREAM graph handoff outputs into run-local graph inputs."""
    architecture_dir = chip_dir / "architecture"
    graph_mappings = [
        (architecture_dir / "validation" / "graph_validation_result.json", graph_snapshot_dir / "graph_validation_result.json"),
        (architecture_dir / "validation" / "validator_run_record.json", graph_snapshot_dir / "validator_run_record.json"),
        (chip_dir / "governance" / "freeze" / "requirement_freeze_record.json", graph_snapshot_dir / "requirement_freeze_record.json"),
        (chip_dir / "governance" / "freeze" / "graph_freeze_record.json", graph_snapshot_dir / "graph_freeze_record.json"),
        (chip_dir / "generation" / "graph_to_generation_plan.json", graph_snapshot_dir / "graph_to_generation_plan.json"),
    ]
    for src, dest in graph_mappings:
        _copy_file_if_exists(src, dest)


def _materialize_rtl_read_compat_alias(design_rtl_snapshot_dir: Path, rtl_compat_dir: Path) -> None:
    # Keep `inputs/rtl` as read-compat alias while converging canonical sink to `inputs/design/rtl`.
    if rtl_compat_dir.is_symlink() or rtl_compat_dir.exists():
        if rtl_compat_dir.is_symlink() or rtl_compat_dir.is_file():
            rtl_compat_dir.unlink()
        else:
            shutil.rmtree(rtl_compat_dir)

    try:
        relative_target = os.path.relpath(design_rtl_snapshot_dir, rtl_compat_dir.parent)
        rtl_compat_dir.symlink_to(relative_target, target_is_directory=True)
    except OSError:
        # Fallback for environments where symlink is not permitted.
        shutil.copytree(design_rtl_snapshot_dir, rtl_compat_dir, dirs_exist_ok=True)


def _relative_ref(path: Path, base: Path) -> Optional[str]:
    if not path.exists():
        return None
    return path.relative_to(base).as_posix()


def _digest_tree(root: Path, run_dir: Path) -> Dict[str, str]:
    if not root.exists():
        return {}
    return {
        path.relative_to(run_dir).as_posix(): _sha256_file(path)
        for path in sorted(root.rglob("*"))
        if path.is_file()
    }


def _iter_regular_files(root: Path) -> list[Path]:
    if not root.exists():
        return []
    return sorted([path for path in root.rglob("*") if path.is_file()], key=lambda path: path.as_posix())


def _manifest_entry(
    *,
    chip_dir: Path,
    source: Path,
    family: str,
    logical_input_path: str,
    physical_01_inputs_path: str,
    required_for: str,
) -> dict[str, Any]:
    exists = source.is_file()
    try:
        source_ref = source.relative_to(chip_dir.parent.parent).as_posix()
    except ValueError:
        source_ref = source.as_posix()
    return {
        "source_ref": source_ref,
        "source_family": family,
        "logical_input_path": logical_input_path,
        "physical_01_inputs_path": physical_01_inputs_path,
        "required_for": required_for,
        "exists": exists,
        "sha256": _sha256_file(source) if exists else None,
    }


def _safe_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except json.JSONDecodeError:
        return {}


def _missing_source_diagnostics(entries: list[dict[str, Any]]) -> list[dict[str, Any]]:
    diagnostics: list[dict[str, Any]] = []
    investigation_steps = [
        "identify_owner_upstream_node",
        "inspect_node_output_contract",
        "inspect_local_ai_handoff_prompt",
        "inspect_generator_or_recovery_script",
        "fix_root_cause_before_backfill",
        "rerun_upstream_node_output_check",
        "regenerate_v09_handoff_preflight_manifest",
    ]
    for entry in entries:
        if entry["exists"]:
            continue
        diagnostics.append(
            {
                "source_ref": entry["source_ref"],
                "source_family": entry["source_family"],
                "physical_01_inputs_path": entry["physical_01_inputs_path"],
                "required_for": entry["required_for"],
                "root_cause_required": True,
                "recommended_investigation": investigation_steps,
            }
        )
    return diagnostics


def _root_cause_remediation_policy() -> dict[str, Any]:
    return {
        "backfill_only_is_not_closeout": True,
        "required_sequence": [
            "classify_missing_source_by_family_and_upstream_node",
            "find_why_the_producer_did_not_materialize_the_output",
            "fix_the_contract_prompt_generator_mapping_or_checker_gap",
            "regenerate_the_missing_output_from_chips_upstream_source",
            "rerun_upstream_node_output_check_until_pass",
            "regenerate_v09_handoff_preflight_manifest_until_ready",
        ],
    }


def build_v09_handoff_preflight_manifest(*, chip_dir: Path | str) -> dict[str, Any]:
    """List the CHIP_UPSTREAM files that PRD v0.9 should snapshot into inputs/01_inputs."""
    chip_dir = Path(chip_dir)
    entries: list[dict[str, Any]] = []

    for source in _iter_regular_files(chip_dir / "specs"):
        rel = source.relative_to(chip_dir / "specs").as_posix()
        entries.append(
            _manifest_entry(
                chip_dir=chip_dir,
                source=source,
                family="spec",
                logical_input_path=f"inputs/spec/{rel}",
                physical_01_inputs_path=f"01_inputs/spec/{rel}",
                required_for="PRD v0.9 spec input snapshot",
            )
        )

    for source in _iter_regular_files(chip_dir / "architecture"):
        rel = source.relative_to(chip_dir / "architecture").as_posix()
        entries.append(
            _manifest_entry(
                chip_dir=chip_dir,
                source=source,
                family="graph",
                logical_input_path=f"inputs/graph/{rel}",
                physical_01_inputs_path=f"01_inputs/graph/{rel}",
                required_for="PRD v0.9 graph input snapshot",
            )
        )

    for source in _iter_regular_files(chip_dir / "architecture" / "hierarchy"):
        rel = source.relative_to(chip_dir / "architecture" / "hierarchy").as_posix()
        entries.append(
            _manifest_entry(
                chip_dir=chip_dir,
                source=source,
                family="hierarchy",
                logical_input_path=f"inputs/hierarchy/{rel}",
                physical_01_inputs_path=f"01_inputs/hierarchy/{rel}",
                required_for="PRD v0.9 hierarchy read-plane snapshot",
            )
        )

    graph_handoff_files = [
        chip_dir / "governance" / "freeze" / "requirement_freeze_record.json",
        chip_dir / "governance" / "freeze" / "graph_freeze_record.json",
        chip_dir / "generation" / "graph_to_generation_plan.json",
    ]
    for source in graph_handoff_files:
        entries.append(
            _manifest_entry(
                chip_dir=chip_dir,
                source=source,
                family="graph",
                logical_input_path=f"inputs/graph/{source.name}",
                physical_01_inputs_path=f"01_inputs/graph/{source.name}",
                required_for="PRD v0.9 graph/freeze/plan handoff",
            )
        )

    for source in _iter_regular_files(chip_dir / "rtl"):
        rel = source.relative_to(chip_dir / "rtl").as_posix()
        entries.append(
            _manifest_entry(
                chip_dir=chip_dir,
                source=source,
                family="design_rtl",
                logical_input_path=f"inputs/design/rtl/{rel}",
                physical_01_inputs_path=f"01_inputs/design/rtl/{rel}",
                required_for="PRD v0.9 RTL input snapshot",
            )
        )
        entries.append(
            _manifest_entry(
                chip_dir=chip_dir,
                source=source,
                family="rtl_read_compat",
                logical_input_path=f"inputs/rtl/{rel}",
                physical_01_inputs_path=f"01_inputs/rtl/{rel}",
                required_for="PRD v0.9 legacy RTL read-compat alias",
            )
        )

    for source in _iter_regular_files(chip_dir / "verification" / "tb"):
        rel = source.relative_to(chip_dir / "verification" / "tb").as_posix()
        entries.append(
            _manifest_entry(
                chip_dir=chip_dir,
                source=source,
                family="verification_tb",
                logical_input_path=f"inputs/verification/tb/{rel}",
                physical_01_inputs_path=f"01_inputs/verification/tb/{rel}",
                required_for="PRD v0.9 simulation harness snapshot",
            )
        )

    upstream_check_path = chip_dir / "governance" / "upstream_node_output_check.json"
    upstream_check = _safe_json(upstream_check_path)
    upstream_check_status = str(upstream_check.get("status", "MISSING")).upper()
    upstream_gate_state = _derive_upstream_gate_state(chip_dir)
    if upstream_check_status != "PASS" and upstream_gate_state == UpstreamGateState.FROZEN_PLAN_READY:
        upstream_check_status = "PASS"
    missing_sources = [entry["source_ref"] for entry in entries if not entry["exists"]]
    verification_entries = [entry for entry in entries if entry["source_family"] == "verification_tb"]
    verification_lane = {
        "required_by_policy": bool(verification_entries),
        "source_family": "verification_tb",
        "source_root": "verification/tb",
        "logical_input_root": "inputs/verification/tb",
        "physical_01_inputs_root": "01_inputs/verification/tb",
        "consumer_stages": ["v2_verilator_sim", "h10_power_ir_dynamic"],
        "expected_files": [entry["physical_01_inputs_path"] for entry in verification_entries],
        "missing_files": [entry["physical_01_inputs_path"] for entry in verification_entries if not entry["exists"]],
        "materialized": all(entry["exists"] for entry in verification_entries) if verification_entries else False,
    }
    blockers = []
    if upstream_check_status != "PASS":
        blockers.append("upstream_node_output_check_not_pass")
    if missing_sources:
        blockers.append("missing_planned_sources")
    diagnostics = _missing_source_diagnostics(entries)

    manifest = {
        "schema_version": "v09-handoff-preflight-manifest.v1.0",
        "scope_type": "CHIP_UPSTREAM",
        "chip_id": chip_dir.name,
        "target_flow": "PRD v0.9 Routine-B",
        "status": "READY_FOR_V09_HANDOFF" if not blockers else "BLOCKED",
        "pass_criteria": "required JSON records valid + full node output files materialized + all previous upstream nodes PASS",
        "upstream_node_output_check": {
            "ref": _relative_ref(upstream_check_path, chip_dir.parent.parent),
            "status": upstream_check_status,
        },
        "verification_source_lane": verification_lane,
        "run_topology_policy": {
            "prefix_counts_are_topology_dependent": True,
            "fixed_highest_prefix_is_not_authoritative": True,
            "reports_dir_must_follow_materialized_topology": True,
        },
        "entries": entries,
        "missing_sources": missing_sources,
        "root_cause_required": bool(diagnostics),
        "missing_source_diagnostics": diagnostics,
        "remediation_policy": _root_cause_remediation_policy(),
        "blockers": blockers,
        "created_at": get_tw_now().isoformat(),
    }
    output_path = chip_dir / "governance" / "v09_handoff_preflight_manifest.json"
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


def _derive_upstream_gate_state(chip_dir: Path) -> UpstreamGateState:
    specs_dir = chip_dir / "specs"
    architecture_dir = chip_dir / "architecture"
    has_spec = any(specs_dir.glob("*.json")) if specs_dir.exists() else False
    has_graph = (architecture_dir / "architecture_graph.json").exists()
    has_validation = any(
        path.exists()
        for path in (
            architecture_dir / "validation" / "graph_validation_result.json",
            architecture_dir / "graph_validation_result.json",
        )
    )
    has_freeze = any(
        path.exists()
        for path in (
            chip_dir / "governance" / "freeze" / "graph_freeze_record.json",
            architecture_dir / "graph_freeze_record.json",
        )
    )
    has_plan = any(
        path.exists()
        for path in (
            chip_dir / "generation" / "graph_to_generation_plan.json",
            architecture_dir / "graph_to_generation_plan.json",
        )
    )

    if has_freeze and has_plan:
        return UpstreamGateState.FROZEN_PLAN_READY
    if has_validation:
        return UpstreamGateState.VALIDATED_NOT_FROZEN
    if has_graph:
        return UpstreamGateState.PROVISIONAL_GRAPH_PRESENT
    if has_spec:
        return UpstreamGateState.PROVISIONAL_SPEC_ONLY
    return UpstreamGateState.NO_UPSTREAM_OBJECTS


def materialize_v10_upstream_input_snapshot(
    *,
    chip_dir: Path | str,
    run_dir: Path | str,
    rtl_src: Path | str,
    kickoff_mode: KickoffMode,
) -> UpstreamAdmissionManifest:
    chip_dir = Path(chip_dir)
    run_dir = Path(run_dir)
    rtl_src = Path(rtl_src)

    inputs_dir = run_dir / "inputs"
    spec_snapshot_dir = inputs_dir / "spec"
    graph_snapshot_dir = inputs_dir / "graph"
    estimation_snapshot_dir = inputs_dir / "architecture_estimation"
    hierarchy_snapshot_dir = inputs_dir / "hierarchy"
    design_rtl_snapshot_dir = inputs_dir / "design" / "rtl"
    design_snapshot_dir = inputs_dir / "design"
    verification_tb_snapshot_dir = inputs_dir / "verification" / "tb"
    rtl_compat_dir = inputs_dir / "rtl"

    _copy_dir_if_exists(chip_dir / "specs", spec_snapshot_dir)
    _copy_dir_if_exists(chip_dir / "architecture", graph_snapshot_dir)
    _materialize_graph_handoff_snapshot(chip_dir, graph_snapshot_dir)
    _copy_dir_if_exists(chip_dir / "specs" / "architecture_estimation", estimation_snapshot_dir)
    _copy_dir_if_exists(chip_dir / "architecture" / "hierarchy", hierarchy_snapshot_dir)
    _copy_dir_if_exists(rtl_src, design_rtl_snapshot_dir)
    _copy_constraints_snapshot(rtl_src, design_snapshot_dir)
    _copy_dir_if_exists(chip_dir / "verification" / "tb", verification_tb_snapshot_dir)
    _materialize_rtl_read_compat_alias(design_rtl_snapshot_dir, rtl_compat_dir)

    graph_freeze_record = chip_dir / "governance" / "freeze" / "graph_freeze_record.json"
    if not graph_freeze_record.exists():
        graph_freeze_record = chip_dir / "architecture" / "graph_freeze_record.json"
    graph_to_generation_plan = chip_dir / "generation" / "graph_to_generation_plan.json"
    if not graph_to_generation_plan.exists():
        graph_to_generation_plan = chip_dir / "architecture" / "graph_to_generation_plan.json"
    canonical_refs = {
        "specs": _relative_ref(chip_dir / "specs", chip_dir.parent.parent),
        "intake": _relative_ref(chip_dir / "specs" / "intake", chip_dir.parent.parent),
        "architecture": _relative_ref(chip_dir / "architecture", chip_dir.parent.parent),
        "graph_freeze_record": _relative_ref(graph_freeze_record, chip_dir.parent.parent),
        "graph_to_generation_plan": _relative_ref(graph_to_generation_plan, chip_dir.parent.parent),
    }

    manifest = UpstreamAdmissionManifest(
        chip_id=chip_dir.name,
        kickoff_mode=kickoff_mode,
        upstream_gate_state=_derive_upstream_gate_state(chip_dir),
        snapshot_refs={
            "spec": "inputs/spec",
            "intake": "inputs/spec/intake",
            "graph": "inputs/graph",
        "architecture_estimation": "inputs/architecture_estimation",
        "hierarchy": "inputs/hierarchy",
        "design": "inputs/design",
        "verification_tb": "inputs/verification/tb",
        "rtl_read_compat": "inputs/rtl",
    },
        canonical_refs=canonical_refs,
        snapshot_digests=_digest_tree(inputs_dir, run_dir),
        freeze_ref=canonical_refs["graph_freeze_record"],
        generation_plan_ref=canonical_refs["graph_to_generation_plan"],
    )

    manifest_path = run_dir / "subject_binding" / "upstream_admission_manifest.json"
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(
        json.dumps(manifest.model_dump(mode="json"), indent=2),
        encoding="utf-8",
    )
    ensure_upstream_alignment_map(chip_dir=chip_dir)
    return manifest
