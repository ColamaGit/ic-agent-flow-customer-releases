from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from ic_agent_flow.domain.utils.time import get_tw_now


ALIGNMENT_SCHEMA_VERSION = "knowledge-backflow-alignment.v0.1"
DEFAULT_CANONICAL_NOTICE = True


def _repo_root_from_run_dir(run_dir: Path) -> Path:
    return run_dir.resolve().parents[4]


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _sha256_json(payload: Any) -> str:
    return _sha256_bytes(json.dumps(payload, sort_keys=True, ensure_ascii=False).encode("utf-8"))


def _read_json(path: Path) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return payload if isinstance(payload, dict) else {}


def _latest_reports_dir(run_dir: Path) -> Path | None:
    candidates = sorted(
        [p for p in run_dir.iterdir() if p.is_dir() and p.name.endswith("_reports")],
        key=lambda path: path.name,
    )
    if candidates:
        return candidates[-1]
    legacy = run_dir / "reports"
    return legacy if legacy.exists() else None


def _registry_paths(repo_root: Path) -> list[Path]:
    root = repo_root / "workspace" / "docs" / "governance" / "closeout" / "v1.1"
    if not root.exists():
        return []
    paths = [p for p in root.rglob("candidate_asset_registry*.json") if p.is_file()]
    return sorted(paths, key=lambda p: p.as_posix())


def _registry_assets(registry: dict[str, Any]) -> list[dict[str, Any]]:
    assets: list[dict[str, Any]] = []
    if isinstance(registry.get("asset"), dict):
        assets.append(registry["asset"])
    if isinstance(registry.get("assets"), list):
        assets.extend([a for a in registry["assets"] if isinstance(a, dict)])
    return assets


def _string_list(value: Any) -> list[str]:
    if isinstance(value, list):
        return [str(item) for item in value if str(item).strip()]
    if isinstance(value, str) and value.strip():
        return [value.strip()]
    return []


def _string_field(value: Any, default: str = "") -> str:
    if isinstance(value, list):
        return ", ".join(str(item) for item in value if str(item).strip()) or default
    text = str(value or "").strip()
    return text or default


def _relevant_refs(refs: list[str], chip_id: str, run_id: str, execution: str) -> list[str]:
    tokens = [
        f"/{chip_id}/",
        f"chips/{chip_id}/",
        f"artifacts/production-runs/{chip_id}/",
        f"/{run_id}/",
        execution,
    ]
    filtered = [ref for ref in refs if any(token in ref for token in tokens)]
    return filtered or list(refs)


def _asset_rows_for_chip(
    *,
    repo_root: Path,
    chip_id: str,
    run_dir: Path,
) -> tuple[list[dict[str, Any]], list[str]]:
    rows: list[dict[str, Any]] = []
    registry_refs: list[str] = []
    for registry_path in _registry_paths(repo_root):
        registry = _read_json(registry_path)
        registry_id = str(registry.get("registry_id") or registry_path.stem)
        registry_ref = registry_path.relative_to(repo_root).as_posix()
        registry_chip_set = {
            str(item)
            for item in (registry.get("chip_set") or [])
            if isinstance(item, str)
        }
        for asset in _registry_assets(registry):
            asset_id = str(asset.get("asset_id") or "")
            if not asset_id:
                continue
            source_refs = [str(ref) for ref in (asset.get("source_event_refs") or []) if isinstance(ref, str)]
            evidence_refs = [str(ref) for ref in (asset.get("evidence_refs") or []) if isinstance(ref, str)]
            chip_refs = _relevant_refs(source_refs + evidence_refs, chip_id, run_dir.name, run_dir.name)
            if chip_id not in registry_chip_set and not chip_refs:
                continue
            rows.append(
                {
                    "registry_id": registry_id,
                    "registry_ref": registry_ref,
                    "asset_id": asset_id,
                    "asset_type": str(asset.get("asset_type") or "candidate_knowledge_asset"),
                    "asset_family": str(asset.get("asset_family") or "unknown"),
                    "scope_level": str(asset.get("scope_level") or registry.get("line") or "unknown"),
                    "source_event_type": str(asset.get("source_event_type") or "unknown"),
                    "flow_scope": _string_list(asset.get("flow_scope") or registry.get("flow_scope") or "NOT_FLOW_BOUND"),
                    "asset_origin_class": _string_field(
                        asset.get("asset_origin_class") or registry.get("asset_origin_class"),
                        "FLOW_EVENT_DERIVED",
                    ),
                    "priority_class": _string_field(asset.get("priority_class") or registry.get("priority_class"), "UNCLASSIFIED"),
                    "source_fix_ref": _string_field(asset.get("source_fix_ref") or registry.get("source_fix_ref"), ""),
                    "consumption_targets": _string_list(asset.get("consumption_targets") or registry.get("consumption_targets")),
                    "release_eligibility": asset.get("release_eligibility") if isinstance(asset.get("release_eligibility"), dict) else {},
                    "promotion_status": str(asset.get("promotion_status") or asset.get("lifecycle_state") or "candidate"),
                    "promotion_recommendation": str(asset.get("promotion_recommendation") or "REVIEW"),
                    "authority_line": str(registry.get("line") or "PRD v1.1 knowledge flywheel"),
                    "summary": str(asset.get("summary") or ""),
                    "reusable_lesson": [str(item) for item in asset.get("reusable_lesson", []) if isinstance(item, str)],
                    "source_event_refs": source_refs,
                    "evidence_refs": evidence_refs,
                    "chip_evidence_refs": chip_refs,
                    "chip_set": sorted(registry_chip_set) if registry_chip_set else [],
                    "notes": str(asset.get("summary") or "candidate asset aligned to run-local backflow surface"),
                }
            )
            registry_refs.append(registry_ref)
    return rows, sorted(dict.fromkeys(registry_refs))


def build_knowledge_backflow_alignment(*, run_dir: Path | str, generated_at: str | None = None) -> dict[str, Any]:
    run_dir = Path(run_dir).resolve()
    repo_root = _repo_root_from_run_dir(run_dir)
    reports_dir = _latest_reports_dir(run_dir) or (run_dir / "22_reports")
    generated_at = generated_at or get_tw_now().isoformat()

    chip_id = run_dir.parent.parent.name
    run_id = run_dir.parent.name
    execution = run_dir.name

    rows, registry_refs = _asset_rows_for_chip(repo_root=repo_root, chip_id=chip_id, run_dir=run_dir)
    knowledge_backflow_report_ref = reports_dir / "knowledge_backflow_report.v1.1_v1.2.md"
    report_manifest_ref = reports_dir / "knowledge_backflow_report_manifest.v1.1_v1.2.json"
    readiness_manifest_ref = reports_dir / "readiness_report_manifest.v0.2.json"

    evidence_digest = _sha256_json(
        {
            "chip_id": chip_id,
            "run_id": run_id,
            "execution": execution,
            "registry_refs": registry_refs,
            "asset_ids": [row["asset_id"] for row in rows],
        }
    )

    action_items: list[dict[str, Any]] = []
    for row in rows:
        if row["promotion_recommendation"] in {"REVIEW", "HOLD", "NEEDS_ADJUDICATION", "LOCAL_ONLY"}:
            action_items.append(
                {
                    "item_id": f"{row['registry_id']}::{row['asset_id']}",
                    "severity": "REVIEW",
                    "registry_id": row["registry_id"],
                    "asset_id": row["asset_id"],
                    "reason": "candidate asset should be reviewed or routed according to PRD v1.1 flywheel contract",
                    "evidence_refs": row["chip_evidence_refs"] or row["evidence_refs"],
                }
            )

    verdict = "PASS_WITH_ACTIONS" if rows else "BLOCKED"
    payload = {
        "schema_version": ALIGNMENT_SCHEMA_VERSION,
        "type": "knowledge_backflow_alignment_manifest",
        "scope": {
            "chip_id": chip_id,
            "run_id": run_id,
            "execution": execution,
        },
        "aligned_report_ref": knowledge_backflow_report_ref.relative_to(repo_root).as_posix()
        if knowledge_backflow_report_ref.exists()
        else knowledge_backflow_report_ref.as_posix(),
        "aligned_report_manifest_ref": report_manifest_ref.relative_to(repo_root).as_posix()
        if report_manifest_ref.exists()
        else report_manifest_ref.as_posix(),
        "readiness_report_manifest_ref": readiness_manifest_ref.relative_to(repo_root).as_posix()
        if readiness_manifest_ref.exists()
        else readiness_manifest_ref.as_posix(),
        "canonical_registry_refs": registry_refs,
        "asset_rows": rows,
        "asset_row_count": len(rows),
        "generated_at": generated_at,
        "verdict": verdict,
        "alignment_status": "PASS" if rows else "BLOCKED",
        "execution_handoff_status": "RUN_LOCAL_DERIVED_SURFACE_READY" if rows else "RUN_LOCAL_DERIVED_SURFACE_BLOCKED",
        "non_canonical_notice": DEFAULT_CANONICAL_NOTICE,
        "evidence_digest_bundle": evidence_digest,
        "action_items": action_items,
        "action_item_count": len(action_items),
        "governance_line": "PRD v1.1 knowledge flywheel",
        "notes": "Run-local derived companion surface; canonical truth remains in governance closeout registries.",
    }
    payload["validation"] = validate_knowledge_backflow_alignment(payload=payload, run_dir=run_dir)
    return payload


def validate_knowledge_backflow_alignment(*, payload: dict[str, Any], run_dir: Path | str) -> dict[str, Any]:
    run_dir = Path(run_dir).resolve()
    repo_root = _repo_root_from_run_dir(run_dir)
    errors: list[str] = []
    warnings: list[str] = []

    if not isinstance(payload, dict):
        return {"status": "BLOCKED", "errors": ["payload_not_dict"], "warnings": []}

    if str(payload.get("schema_version")) != ALIGNMENT_SCHEMA_VERSION:
        errors.append("schema_version_mismatch")
    scope = payload.get("scope", {})
    if not isinstance(scope, dict):
        errors.append("scope_not_dict")
        scope = {}
    if str(scope.get("chip_id")) != run_dir.parent.parent.name:
        errors.append("chip_id_mismatch")
    if str(scope.get("run_id")) != run_dir.parent.name:
        errors.append("run_id_mismatch")
    if str(scope.get("execution")) != run_dir.name:
        errors.append("execution_mismatch")

    if not bool(payload.get("non_canonical_notice")):
        errors.append("missing_non_canonical_notice")

    aligned_report_ref = str(payload.get("aligned_report_ref") or "").strip()
    if not aligned_report_ref:
        errors.append("missing_aligned_report_ref")
    elif not (repo_root / aligned_report_ref).exists():
        warnings.append("aligned_report_missing")

    canonical_registry_refs = payload.get("canonical_registry_refs", [])
    if not isinstance(canonical_registry_refs, list) or not canonical_registry_refs:
        errors.append("registry_refs_missing")
        canonical_registry_refs = []

    asset_rows = payload.get("asset_rows", [])
    if not isinstance(asset_rows, list) or not asset_rows:
        errors.append("asset_rows_missing")
        asset_rows = []

    seen_assets: set[str] = set()
    for idx, row in enumerate(asset_rows):
        if not isinstance(row, dict):
            errors.append(f"asset_row_{idx}_not_dict")
            continue
        registry_id = str(row.get("registry_id") or "").strip()
        asset_id = str(row.get("asset_id") or "").strip()
        if not registry_id:
            errors.append(f"asset_row_{idx}_missing_registry_id")
        if not asset_id:
            errors.append(f"asset_row_{idx}_missing_asset_id")
        key = f"{registry_id}::{asset_id}"
        if key in seen_assets:
            errors.append(f"duplicate_asset_row:{key}")
        seen_assets.add(key)
        if not isinstance(row.get("chip_evidence_refs", []), list):
            errors.append(f"asset_row_{idx}_chip_evidence_refs_not_list")
        if not isinstance(row.get("evidence_refs", []), list):
            errors.append(f"asset_row_{idx}_evidence_refs_not_list")
        if not isinstance(row.get("flow_scope", []), list):
            errors.append(f"asset_row_{idx}_flow_scope_not_list")
        if not str(row.get("asset_origin_class") or "").strip():
            errors.append(f"asset_row_{idx}_missing_asset_origin_class")
        if not str(row.get("priority_class") or "").strip():
            errors.append(f"asset_row_{idx}_missing_priority_class")
        if not isinstance(row.get("consumption_targets", []), list):
            errors.append(f"asset_row_{idx}_consumption_targets_not_list")
        if not str(row.get("promotion_recommendation") or "").strip():
            errors.append(f"asset_row_{idx}_missing_promotion_recommendation")

    evidence_digest = _sha256_json(
        {
            "chip_id": scope.get("chip_id"),
            "run_id": scope.get("run_id"),
            "execution": scope.get("execution"),
            "registry_refs": canonical_registry_refs,
            "asset_ids": [row.get("asset_id") for row in asset_rows if isinstance(row, dict)],
        }
    )
    if str(payload.get("evidence_digest_bundle") or "") != evidence_digest:
        errors.append("evidence_digest_bundle_mismatch")

    status = "PASS" if not errors else "BLOCKED"
    return {
        "status": status,
        "errors": errors,
        "warnings": warnings,
        "asset_row_count": len(asset_rows),
        "registry_count": len(canonical_registry_refs),
        "evidence_digest_bundle": evidence_digest,
        "alignment_status": payload.get("alignment_status", "UNKNOWN"),
    }


def render_knowledge_backflow_alignment_markdown(payload: dict[str, Any]) -> str:
    scope = payload.get("scope", {})
    rows = payload.get("asset_rows", [])
    canonical_registry_refs = payload.get("canonical_registry_refs", [])
    action_items = payload.get("action_items", [])
    lines = [
        "# Knowledge Backflow Alignment",
        "",
        "> Run-local derived companion surface. JSON is the machine-readable contract; Markdown is rendered from JSON only.",
        "",
        f"- schema_version: `{payload.get('schema_version', ALIGNMENT_SCHEMA_VERSION)}`",
        f"- chip_id: `{scope.get('chip_id', '-')}`",
        f"- run_id: `{scope.get('run_id', '-')}`",
        f"- execution: `{scope.get('execution', '-')}`",
        f"- aligned_report_ref: `{payload.get('aligned_report_ref', '-')}`",
        f"- aligned_report_manifest_ref: `{payload.get('aligned_report_manifest_ref', '-')}`",
        f"- readiness_report_manifest_ref: `{payload.get('readiness_report_manifest_ref', '-')}`",
        f"- alignment_status: `{payload.get('alignment_status', '-')}`",
        f"- execution_handoff_status: `{payload.get('execution_handoff_status', '-')}`",
        f"- canonical_registry_count: `{len(canonical_registry_refs)}`",
        f"- asset_row_count: `{len(rows)}`",
        f"- action_item_count: `{len(action_items)}`",
        f"- non_canonical_notice: `{payload.get('non_canonical_notice', False)}`",
        "",
        "## Canonical Registry Refs",
        "",
    ]
    for ref in canonical_registry_refs:
        lines.append(f"- `{ref}`")
    lines.extend([
        "",
        "## Asset Rows",
        "",
        "| registry_id | asset_id | asset_family | flow_scope | origin | priority | recommendation | chip evidence | notes |",
        "|---|---|---|---|---|---|---|---|---|",
    ])
    for row in rows:
        if not isinstance(row, dict):
            continue
        lines.append(
            "| "
            f"{row.get('registry_id', '-')}"
            " | "
            f"{row.get('asset_id', '-')}"
            " | "
            f"{row.get('asset_family', '-')}"
            " | "
            f"{', '.join(row.get('flow_scope', [])) if isinstance(row.get('flow_scope'), list) else row.get('flow_scope', '-')}"
            " | "
            f"{row.get('asset_origin_class', '-')}"
            " | "
            f"{row.get('priority_class', '-')}"
            " | "
            f"{row.get('promotion_recommendation', '-')}"
            " | "
            f"{len(row.get('chip_evidence_refs', []))}"
            " | "
            f"{row.get('notes', '-')}"
            " |"
        )
    lines.extend(
        [
            "",
            "## Action Items",
            "",
            f"- action_item_count: `{len(action_items)}`",
            "",
            "Canonical truth remains in governance closeout registries; this report only routes derived references.",
        ]
    )
    return "\n".join(lines)


def write_knowledge_backflow_alignment(*, run_dir: Path | str, generated_at: str | None = None) -> dict[str, Any]:
    run_dir = Path(run_dir).resolve()
    reports_dir = _latest_reports_dir(run_dir) or (run_dir / "22_reports")
    reports_dir.mkdir(parents=True, exist_ok=True)
    payload = build_knowledge_backflow_alignment(run_dir=run_dir, generated_at=generated_at)

    base = "knowledge_backflow_alignment.v1.1_v1.2"
    md_path = reports_dir / f"{base}.md"
    manifest_path = reports_dir / "knowledge_backflow_alignment_manifest.v1.1_v1.2.json"
    mapping_path = reports_dir / "knowledge_backflow_alignment_mapping.v1.1_v1.2.json"
    stats_path = reports_dir / "knowledge_backflow_alignment_statistics.v1.1_v1.2.json"
    actions_path = reports_dir / "knowledge_backflow_alignment_action_items.v1.1_v1.2.json"
    genlog_path = reports_dir / "knowledge_backflow_alignment_generation_log.v1.1_v1.2.json"

    md_path.write_text(render_knowledge_backflow_alignment_markdown(payload).rstrip() + "\n", encoding="utf-8")
    manifest_path.write_text(
        json.dumps(
            {
                "schema_version": payload["schema_version"],
                "type": "knowledge_backflow_alignment_manifest",
                "scope": payload["scope"],
                "aligned_report_ref": payload["aligned_report_ref"],
                "aligned_report_manifest_ref": payload["aligned_report_manifest_ref"],
                "readiness_report_manifest_ref": payload["readiness_report_manifest_ref"],
                "canonical_registry_refs": payload["canonical_registry_refs"],
                "non_canonical_notice": payload["non_canonical_notice"],
                "generated_at": payload["generated_at"],
                "verdict": payload["verdict"],
                "alignment_status": payload["alignment_status"],
                "execution_handoff_status": payload["execution_handoff_status"],
                "governance_line": payload["governance_line"],
            },
            indent=2,
            ensure_ascii=False,
        )
        + "\n",
        encoding="utf-8",
    )
    mapping_path.write_text(
        json.dumps(
            {
                "schema_version": payload["schema_version"],
                "type": "knowledge_backflow_alignment_mapping",
                "scope": payload["scope"],
                "rows": payload["asset_rows"],
                "generated_at": payload["generated_at"],
            },
            indent=2,
            ensure_ascii=False,
        )
        + "\n",
        encoding="utf-8",
    )
    stats_path.write_text(
        json.dumps(
            {
                "schema_version": payload["schema_version"],
                "type": "knowledge_backflow_alignment_statistics",
                "scope": payload["scope"],
                "verdict": payload["verdict"],
                "alignment_status": payload["alignment_status"],
                "execution_handoff_status": payload["execution_handoff_status"],
                "asset_row_count": payload["asset_row_count"],
                "registry_count": len(payload["canonical_registry_refs"]),
                "action_item_count": payload["action_item_count"],
                "generated_at": payload["generated_at"],
            },
            indent=2,
            ensure_ascii=False,
        )
        + "\n",
        encoding="utf-8",
    )
    actions_path.write_text(
        json.dumps(
            {
                "schema_version": payload["schema_version"],
                "type": "knowledge_backflow_alignment_action_items",
                "scope": payload["scope"],
                "items": payload["action_items"],
                "total_count": payload["action_item_count"],
                "generated_at": payload["generated_at"],
            },
            indent=2,
            ensure_ascii=False,
        )
        + "\n",
        encoding="utf-8",
    )
    genlog_path.write_text(
        json.dumps(
            {
                "schema_version": payload["schema_version"],
                "type": "knowledge_backflow_alignment_generation_log",
                "scope": payload["scope"],
                "generated_at": payload["generated_at"],
                "status": "PASS" if payload["validation"]["status"] == "PASS" else "BLOCKED",
                "generator": "knowledge_backflow_alignment",
                "source_registry_refs": payload["canonical_registry_refs"],
                "aligned_report_ref": payload["aligned_report_ref"],
            },
            indent=2,
            ensure_ascii=False,
        )
        + "\n",
        encoding="utf-8",
    )
    return {
        "markdown": md_path.as_posix(),
        "manifest": manifest_path.as_posix(),
        "mapping": mapping_path.as_posix(),
        "statistics": stats_path.as_posix(),
        "action_items": actions_path.as_posix(),
        "generation_log": genlog_path.as_posix(),
        "validation": payload["validation"],
    }
