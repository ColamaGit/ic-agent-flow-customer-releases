from __future__ import annotations

import hashlib
import json
import re
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional
from uuid import uuid4

from pydantic import BaseModel

from ic_agent_flow.registry.scenario_registry import Disposition


def _resolve_primary_rtl_source(rtl_path: Path, top_module: str) -> Path | None:
    if rtl_path.is_file():
        return rtl_path
    if not rtl_path.is_dir():
        return None

    candidates = sorted(list(rtl_path.glob("*.v")) + list(rtl_path.glob("*.sv")))
    filtered = [
        path for path in candidates
        if "testbench" not in path.name.lower()
        and not path.name.lower().endswith("_tb.v")
        and not path.name.lower().endswith("_tb.sv")
    ]
    module_pattern = re.compile(rf"\bmodule\s+{re.escape(top_module)}\b")
    for path in filtered:
        text = path.read_text(encoding="utf-8", errors="ignore")
        if module_pattern.search(text):
            return path
    return filtered[0] if filtered else None


def _resolve_sim_sources(rtl_path: Path, top_module: str, testbench_path: Path) -> list[Path]:
    primary = _resolve_primary_rtl_source(rtl_path, top_module)
    if primary is None:
        return [testbench_path]

    primary_text = primary.read_text(encoding="utf-8", errors="ignore")
    has_includes = "`include" in primary_text

    if has_includes:
        return [primary, testbench_path]

    if rtl_path.is_file():
        return [rtl_path, testbench_path]

    rtl_files = sorted(list(rtl_path.glob("*.v")) + list(rtl_path.glob("*.sv")))
    sources = [
        path for path in rtl_files
        if path != testbench_path
        and "testbench" not in path.name.lower()
        and not path.name.lower().endswith("_tb.v")
        and not path.name.lower().endswith("_tb.sv")
    ]
    sources.append(testbench_path)
    return sources


def _parse_sim_output(text: str) -> dict:
    error_count = 0
    warning_count = 0

    error_count += len(re.findall(r"^%Error", text, re.MULTILINE))
    error_count += len(re.findall(r"Comparison Failed", text, re.IGNORECASE))
    warning_count += len(re.findall(r"^%Warning", text, re.MULTILINE))

    pass_markers = (
        "Comparison Passed",
        "SN2025_SIM_PASS",
        "UART_SIM_PASS",
        "ASYNC_FIFO_SIM_PASS",
    )
    matched_marker = next((marker for marker in pass_markers if marker in text), None)
    passed = error_count == 0 and matched_marker is not None

    return {
        "error_count": error_count,
        "warning_count": warning_count,
        "passed": passed,
        "matched_pass_marker": matched_marker,
    }


def _parse_coverage_metrics(text: str) -> dict:
    patterns = {
        "line_pct": [
            r"line(?:_coverage)?\s*[:=]\s*([0-9]+(?:\.[0-9]+)?)\s*%",
            r"line\s+coverage\s*[:=]\s*([0-9]+(?:\.[0-9]+)?)\s*%",
        ],
        "branch_pct": [
            r"branch(?:_coverage)?\s*[:=]\s*([0-9]+(?:\.[0-9]+)?)\s*%",
            r"branch\s+coverage\s*[:=]\s*([0-9]+(?:\.[0-9]+)?)\s*%",
        ],
        "toggle_pct": [
            r"toggle(?:_coverage)?\s*[:=]\s*([0-9]+(?:\.[0-9]+)?)\s*%",
            r"toggle\s+coverage\s*[:=]\s*([0-9]+(?:\.[0-9]+)?)\s*%",
        ],
        "functional_pct": [
            r"functional(?:_coverage)?\s*[:=]\s*([0-9]+(?:\.[0-9]+)?)\s*%",
            r"functional\s+coverage\s*[:=]\s*([0-9]+(?:\.[0-9]+)?)\s*%",
        ],
    }
    metrics: dict = {}
    for key, candidates in patterns.items():
        for pattern in candidates:
            m = re.search(pattern, text, flags=re.IGNORECASE)
            if m:
                metrics[key] = float(m.group(1))
                break
    values = [v for v in metrics.values() if isinstance(v, (int, float))]
    if values:
        metrics["avg_pct"] = round(sum(values) / len(values), 2)
        metrics["status"] = "COLLECTED"
    else:
        metrics["avg_pct"] = None
        metrics["status"] = "NOT_COLLECTED"
    metrics["collector"] = "verilator_log_parser_v0.1"
    return metrics


def _parse_lcov_info(info_path: Path) -> dict:
    line_total = 0
    line_hit = 0
    branch_total = 0
    branch_hit = 0
    for raw in info_path.read_text(encoding="utf-8", errors="ignore").splitlines():
        if raw.startswith("DA:"):
            # DA:<line>,<hits>
            try:
                _, payload = raw.split(":", 1)
                _, hits = payload.split(",", 1)
                line_total += 1
                if int(hits) > 0:
                    line_hit += 1
            except Exception:
                continue
        elif raw.startswith("BRDA:"):
            # BRDA:<line>,<block>,<branch>,<taken>
            try:
                _, payload = raw.split(":", 1)
                parts = payload.split(",")
                if len(parts) != 4:
                    continue
                taken = parts[3]
                if taken == "-":
                    continue
                branch_total += 1
                if int(taken) > 0:
                    branch_hit += 1
            except Exception:
                continue

    line_pct = round((line_hit / line_total) * 100.0, 2) if line_total else None
    branch_pct = round((branch_hit / branch_total) * 100.0, 2) if branch_total else None
    vals = [v for v in (line_pct, branch_pct) if isinstance(v, (int, float))]
    avg_pct = round(sum(vals) / len(vals), 2) if vals else None
    return {
        "line_pct": line_pct,
        "branch_pct": branch_pct,
        "line_points_total": line_total,
        "line_points_hit": line_hit,
        "branch_points_total": branch_total,
        "branch_points_hit": branch_hit,
        "avg_pct": avg_pct,
    }


class VerilatorSimMcpCapabilityRequest(BaseModel):
    workspace_id: str
    chip_id: str
    task_id: str
    decision_context_ref: str
    contract_name: str
    contract_version: str
    rtl_path: str
    top_module: str
    testbench_path: str
    testbench_top: str
    timeout_sec: int = 15
    output_root: str = "artifacts/v0.9/verilator_sim"
    verilator_bin: str = "/usr/local/bin/verilator"
    request_schema_version: str = "v0.1"
    run_key: Optional[str] = None


class VerilatorSimMcpCapabilityResponse(BaseModel):
    disposition: Disposition
    reason: str
    contract_id: str
    request_schema_version: str
    boundary_mode: str
    error_taxonomy: List[str]
    run_id: Optional[str] = None
    execution_run_ref: Optional[str] = None
    tool_version: Optional[str] = None
    warning_count: int = 0
    error_count: int = 0
    artifact_paths: Dict[str, str] = {}
    artifact_refs: Dict[str, str] = {}


VerilatorSimMcpCapabilityRequest.model_rebuild()
VerilatorSimMcpCapabilityResponse.model_rebuild()


class VerilatorSimMcpCapabilityBoundary:
    CAPABILITY_NAME = "verilator_rtl_sim"
    CONTRACT_NAME = "verilator_sim_contract"
    CONTRACT_VERSION = "v0.1"
    BOUNDARY_MODE = "formal_mcp_capability_boundary_local_mode_v0.1"
    ERROR_TAXONOMY = [
        "chip_scope_unresolved",
        "input_schema_invalid",
        "tool_missing",
        "tool_timeout",
        "tool_runtime_error",
        "artifact_missing",
        "output_unparseable",
        "decision_context_mismatch",
    ]

    @staticmethod
    def _sha256_file(path: Path) -> str:
        h = hashlib.sha256()
        with path.open("rb") as f:
            while True:
                chunk = f.read(8192)
                if not chunk:
                    break
                h.update(chunk)
        return h.hexdigest()

    @classmethod
    def _fail(cls, reason: str, req: VerilatorSimMcpCapabilityRequest) -> VerilatorSimMcpCapabilityResponse:
        return VerilatorSimMcpCapabilityResponse(
            disposition=Disposition.FAIL_CLOSED,
            reason=reason,
            contract_id=f"{req.contract_name}@{req.contract_version}",
            request_schema_version=req.request_schema_version,
            boundary_mode=cls.BOUNDARY_MODE,
            error_taxonomy=list(cls.ERROR_TAXONOMY),
        )

    def execute(self, req: VerilatorSimMcpCapabilityRequest) -> VerilatorSimMcpCapabilityResponse:
        required = [
            req.workspace_id,
            req.chip_id,
            req.task_id,
            req.decision_context_ref,
            req.contract_name,
            req.contract_version,
            req.rtl_path,
            req.top_module,
            req.testbench_path,
            req.testbench_top,
        ]
        if any(not value for value in required):
            return self._fail("input_schema_invalid:envelope_missing", req)

        if req.contract_name != self.CONTRACT_NAME or req.contract_version != self.CONTRACT_VERSION:
            return self._fail("input_schema_invalid:unsupported_contract", req)

        if not req.decision_context_ref.startswith("decision://"):
            return self._fail("decision_context_mismatch:invalid_context", req)

        rtl_path = Path(req.rtl_path)
        tb_path = Path(req.testbench_path)
        if not rtl_path.exists() or not tb_path.exists():
            return self._fail("input_schema_invalid:rtl_or_tb_not_found", req)

        if not Path(req.verilator_bin).exists() and shutil.which(req.verilator_bin) is None:
            return self._fail("tool_missing:verilator_not_found", req)

        run_id = req.run_key or f"vsim-{uuid4().hex[:12]}"
        out_dir = Path(req.output_root) / run_id
        out_dir.mkdir(parents=True, exist_ok=True)

        compile_log_path = out_dir / "verilator_compile.raw.log"
        run_log_path = out_dir / "verilator_run.raw.log"
        coverage_log_path = out_dir / "verilator_coverage.raw.log"
        coverage_info_path = out_dir / "coverage.info"
        normalized_path = out_dir / "normalized.sim.meta.json"
        input_manifest_path = out_dir / "input_manifest.json"
        lineage_path = out_dir / "lineage.json"
        evidence_bundle_path = out_dir / "evidence_bundle.json"
        mdir = out_dir / "obj_dir"

        sim_sources = _resolve_sim_sources(rtl_path, req.top_module, tb_path)
        source_refs = [path.as_posix() for path in sim_sources]

        compile_cmd = [
            req.verilator_bin,
            "--binary",
            "--sv",
            "--timing",
            "--coverage",
            "-Wno-fatal",
            "--top-module",
            req.testbench_top,
            "--Mdir",
            mdir.as_posix(),
        ]
        if rtl_path.is_dir():
            compile_cmd.append(f"-I{rtl_path.as_posix()}")
        compile_cmd.extend(source_refs)

        started_at = datetime.now(timezone.utc)
        try:
            compile_proc = subprocess.run(
                compile_cmd,
                cwd=str(out_dir),
                capture_output=True,
                text=True,
                timeout=max(req.timeout_sec * 4, 60),
            )
        except subprocess.TimeoutExpired:
            compile_log_path.write_text("tool_timeout: verilator compile exceeded timeout\n", encoding="utf-8")
            return self._fail("tool_timeout:verilator_compile_timeout", req)

        compile_output = (compile_proc.stdout or "") + (compile_proc.stderr or "")
        compile_log_path.write_text(compile_output, encoding="utf-8")

        binary_path = mdir / f"V{req.testbench_top}"
        status = "FAIL"
        reason = "verilator_sim:compile_failed"
        run_exit_code = None
        parsed = _parse_sim_output(compile_output)

        run_output = ""
        if compile_proc.returncode == 0 and binary_path.exists():
            try:
                run_proc = subprocess.run(
                    [binary_path.as_posix()],
                    cwd=str(out_dir),
                    capture_output=True,
                    text=True,
                    timeout=req.timeout_sec,
                )
                run_exit_code = run_proc.returncode
                run_output = (run_proc.stdout or "") + (run_proc.stderr or "")
                run_log_path.write_text(run_output, encoding="utf-8")
                parsed = _parse_sim_output(compile_output + "\n" + run_output)
                if run_proc.returncode == 0 and parsed["passed"]:
                    status = "PASS"
                    reason = "verilator_sim:pass"
                elif run_proc.returncode == 0:
                    status = "DONE"
                    reason = "verilator_sim:completed_without_explicit_pass_marker"
                else:
                    status = "FAIL"
                    reason = f"verilator_sim:run_failed:exit={run_proc.returncode}"
            except subprocess.TimeoutExpired as exc:
                run_output = (exc.stdout or "") + (exc.stderr or "")
                run_log_path.write_text(run_output + "\nSIM_TIMEOUT\n", encoding="utf-8")
                parsed = _parse_sim_output(compile_output + "\n" + run_output)
                status = "INCOMPLETE"
                reason = "verilator_sim:runtime_timeout"
        else:
            run_log_path.write_text("simulation_run_skipped_due_to_compile_failure\n", encoding="utf-8")

        coverage = {
            "status": "NOT_COLLECTED",
            "collector": "verilator_coverage_lcov_v0.1",
            "reason": "coverage not collected for this run",
            "line_pct": None,
            "branch_pct": None,
            "toggle_pct": None,
            "functional_pct": None,
            "avg_pct": None,
        }
        coverage_data_files = sorted(path for path in out_dir.rglob("coverage.dat") if path.is_file())
        if coverage_data_files:
            coverage_cmd = [
                "verilator_coverage",
                "--write-info",
                coverage_info_path.as_posix(),
            ] + [p.as_posix() for p in coverage_data_files]
            cov_proc = subprocess.run(
                coverage_cmd,
                cwd=str(out_dir),
                capture_output=True,
                text=True,
                timeout=30,
            )
            coverage_output = (cov_proc.stdout or "") + (cov_proc.stderr or "")
            coverage_log_path.write_text(coverage_output, encoding="utf-8")
            if cov_proc.returncode == 0 and coverage_info_path.exists():
                lcov_metrics = _parse_lcov_info(coverage_info_path)
                coverage = {
                    "status": "COLLECTED",
                    "collector": "verilator_coverage_lcov_v0.1",
                    "reason": "collected from coverage.dat using verilator_coverage --write-info",
                    "line_pct": lcov_metrics["line_pct"],
                    "branch_pct": lcov_metrics["branch_pct"],
                    "toggle_pct": None,
                    "functional_pct": None,
                    "avg_pct": lcov_metrics["avg_pct"],
                    "line_points_total": lcov_metrics["line_points_total"],
                    "line_points_hit": lcov_metrics["line_points_hit"],
                    "branch_points_total": lcov_metrics["branch_points_total"],
                    "branch_points_hit": lcov_metrics["branch_points_hit"],
                    "coverage_data_refs": [p.as_posix() for p in coverage_data_files],
                    "coverage_info_ref": coverage_info_path.as_posix(),
                }
            else:
                coverage = {
                    "status": "NOT_COLLECTED",
                    "collector": "verilator_coverage_lcov_v0.1",
                    "reason": f"verilator_coverage failed with exit={cov_proc.returncode}",
                    "line_pct": None,
                    "branch_pct": None,
                    "toggle_pct": None,
                    "functional_pct": None,
                    "avg_pct": None,
                }
        else:
            coverage_log_path.write_text("coverage.dat not found\n", encoding="utf-8")

        finished_at = datetime.now(timezone.utc)
        duration_ms = int((finished_at - started_at).total_seconds() * 1000)

        ver_proc = subprocess.run(
            [req.verilator_bin, "--version"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        tool_version = (ver_proc.stdout or ver_proc.stderr or "").strip().splitlines()[0] if ver_proc.returncode == 0 else "unknown"

        input_manifest = {
            "workspace_id": req.workspace_id,
            "chip_id": req.chip_id,
            "task_id": req.task_id,
            "tool": "verilator",
            "tool_version": tool_version,
            "tool_binary_path": req.verilator_bin,
            "rtl_path": rtl_path.as_posix(),
            "top_module": req.top_module,
            "testbench_path": tb_path.as_posix(),
            "testbench_top": req.testbench_top,
            "sources": source_refs,
            "command": compile_cmd,
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }
        input_manifest_path.write_text(json.dumps(input_manifest, indent=2), encoding="utf-8")

        normalized = {
            "tool": "verilator",
            "tool_version": tool_version,
            "tool_binary_path": req.verilator_bin,
            "contract_name": req.contract_name,
            "contract_version": req.contract_version,
            "status": status,
            "compile_exit_code": compile_proc.returncode,
            "run_exit_code": run_exit_code,
            "warning_count": parsed["warning_count"],
            "error_count": parsed["error_count"],
            "binary_ref": binary_path.as_posix() if binary_path.exists() else None,
            "testbench_ref": tb_path.as_posix(),
            "top_module": req.top_module,
            "testbench_top": req.testbench_top,
            "case_summary": {
                "total": 1,
                "pass": 1 if status == "PASS" else 0,
                "fail": 1 if status == "FAIL" else 0,
                "incomplete": 1 if status == "INCOMPLETE" else 0,
                "done_no_pass": 1 if status == "DONE" else 0,
            },
            "case_results": [
                {
                    "case_id": f"{req.chip_id}.bounded_smoke",
                    "case_name": "bounded_smoke",
                    "result": status,
                    "reason": reason,
                    "pass_marker": parsed.get("matched_pass_marker"),
                    "run_exit_code": run_exit_code,
                    "error_count": parsed["error_count"],
                    "warning_count": parsed["warning_count"],
                }
            ],
            "coverage": coverage,
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }
        normalized_path.write_text(json.dumps(normalized, indent=2), encoding="utf-8")

        lineage = {
            "run_id": run_id,
            "started_at": started_at.isoformat(),
            "finished_at": finished_at.isoformat(),
            "duration_ms": duration_ms,
            "compile_command": compile_cmd,
            "working_dir": str(Path.cwd()),
            "input_manifest_ref": input_manifest_path.as_posix(),
            "output_refs": [
                compile_log_path.as_posix(),
                run_log_path.as_posix(),
                coverage_log_path.as_posix(),
                normalized_path.as_posix(),
            ],
            "decision_context_ref": req.decision_context_ref,
            "task_id": req.task_id,
            "workspace_id": req.workspace_id,
            "chip_id": req.chip_id,
        }
        if binary_path.exists():
            lineage["output_refs"].append(binary_path.as_posix())
        lineage_path.write_text(json.dumps(lineage, indent=2), encoding="utf-8")

        evidence_bundle = {
            "run_id": run_id,
            "raw_refs": [compile_log_path.as_posix(), run_log_path.as_posix(), coverage_log_path.as_posix()],
            "normalized_refs": [normalized_path.as_posix()],
            "lineage_ref": lineage_path.as_posix(),
            "digests": {
                "compile_log_sha256": self._sha256_file(compile_log_path),
                "run_log_sha256": self._sha256_file(run_log_path),
                "coverage_log_sha256": self._sha256_file(coverage_log_path),
                "normalized_sha256": self._sha256_file(normalized_path),
                "input_manifest_sha256": self._sha256_file(input_manifest_path),
                "lineage_sha256": self._sha256_file(lineage_path),
            },
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }
        if coverage_info_path.exists():
            evidence_bundle["normalized_refs"].append(coverage_info_path.as_posix())
            evidence_bundle["digests"]["coverage_info_sha256"] = self._sha256_file(coverage_info_path)
        evidence_bundle_path.write_text(json.dumps(evidence_bundle, indent=2), encoding="utf-8")

        disposition = Disposition.FAIL_CLOSED if status == "FAIL" else Disposition.PASS
        return VerilatorSimMcpCapabilityResponse(
            disposition=disposition,
            reason=reason,
            contract_id=f"{req.contract_name}@{req.contract_version}",
            request_schema_version=req.request_schema_version,
            boundary_mode=self.BOUNDARY_MODE,
            error_taxonomy=list(self.ERROR_TAXONOMY),
            run_id=run_id,
            execution_run_ref=f"run://{self.CAPABILITY_NAME}/{run_id}",
            tool_version=tool_version,
            warning_count=parsed["warning_count"],
            error_count=parsed["error_count"],
            artifact_paths={
                "compile_log": compile_log_path.as_posix(),
                "run_log": run_log_path.as_posix(),
                "normalized_meta": normalized_path.as_posix(),
                "input_manifest": input_manifest_path.as_posix(),
                "lineage": lineage_path.as_posix(),
                "evidence_bundle": evidence_bundle_path.as_posix(),
                "binary": binary_path.as_posix() if binary_path.exists() else "",
                "coverage_log": coverage_log_path.as_posix(),
                "coverage_info": coverage_info_path.as_posix() if coverage_info_path.exists() else "",
            },
            artifact_refs={
                "compile_log_ref": f"artifact://verilator_sim/{run_id}/verilator_compile.raw.log",
                "run_log_ref": f"artifact://verilator_sim/{run_id}/verilator_run.raw.log",
                "normalized_ref": f"norm://verilator_sim/{run_id}/normalized.sim.meta.json",
                "lineage_ref": f"lineage://verilator_sim/{run_id}/lineage.json",
                "evidence_bundle_ref": f"evidence_bundle://verilator_sim/{run_id}",
            },
        )
