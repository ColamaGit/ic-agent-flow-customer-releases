from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable

from ic_agent_flow.domain.utils.time import get_tw_now


ALIGNMENT_MAP_SCHEMA_VERSION = "upstream-alignment-map.v0.1"
CANONICAL_DASHBOARD_OBJECT_SURFACE = "21_dashboard_objects"
LEGACY_DASHBOARD_OBJECT_ALIAS = "21_assertions"
DEFAULT_CONSOLE_SURFACES = ["Requirement Adjudication", "Upstream Truth Flow"]


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _sha256_file(path: Path) -> str:
    return _sha256_bytes(path.read_bytes())


def _sha256_json(payload: Any) -> str:
    return _sha256_bytes(json.dumps(payload, sort_keys=True, ensure_ascii=False).encode("utf-8"))


def _repo_root(chip_dir: Path) -> Path:
    return chip_dir.resolve().parents[1]


def _relative_ref(path: Path, base: Path) -> str | None:
    if not path.exists():
        return None
    try:
        return path.resolve().relative_to(base.resolve()).as_posix()
    except ValueError:
        return path.as_posix()


def _iter_alignment_files(chip_dir: Path) -> list[Path]:
    allowed_roots = [
        chip_dir / "specs",
        chip_dir / "architecture",
        chip_dir / "generation",
        chip_dir / "rtl",
        chip_dir / "verification",
        chip_dir / "governance",
    ]
    files: list[Path] = []
    excluded_suffixes = {
        "upstream_alignment_map.json",
        "upstream_alignment_map.md",
        "upstream_alignment_map.md.hash.json",
    }
    for root in allowed_roots:
        if not root.exists():
            continue
        for path in root.rglob("*"):
            if path.is_symlink() or not path.is_file():
                continue
            if path.name in excluded_suffixes:
                continue
            files.append(path)

    for root_file in ["chip_program_manifest.yaml", "production_intent.json"]:
        candidate = chip_dir / root_file
        if candidate.is_file():
            files.append(candidate)

    return sorted(set(files), key=lambda path: path.relative_to(chip_dir).as_posix())


def _read_json(path: Path) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return payload if isinstance(payload, dict) else {}


def _latest_run_dir(chip_dir: Path) -> Path | None:
    repo_root = _repo_root(chip_dir)
    run_root = repo_root / "artifacts" / "production-runs" / chip_dir.name
    if not run_root.exists():
        return None
    candidates = sorted(
        (path for path in run_root.glob("*/*") if path.is_dir()),
        key=lambda path: path.as_posix(),
    )
    return candidates[-1] if candidates else None


def _latest_run_context(chip_dir: Path) -> dict[str, Any]:
    latest_run_dir = _latest_run_dir(chip_dir)
    if latest_run_dir is None:
        return {
            "latest_run_ref": None,
            "latest_readiness_ref": None,
            "latest_readiness_summary": None,
            "open_blockers": [],
        }

    reports_dir = latest_run_dir / "22_reports"
    readiness_manifest_path = reports_dir / "readiness_report_manifest.v0.2.json"
    readiness_stats_path = reports_dir / "readiness_report_statistics.v0.2.json"
    readiness_action_items_path = reports_dir / "readiness_report_action_items.v0.2.json"
    latest_readiness_ref = readiness_manifest_path if readiness_manifest_path.exists() else None
    if latest_readiness_ref is None and (latest_run_dir / "readiness_report.v0.2.md").exists():
        latest_readiness_ref = latest_run_dir / "readiness_report.v0.2.md"

    latest_summary = None
    if readiness_stats_path.exists():
        latest_summary = _read_json(readiness_stats_path)

    open_blockers: list[str] = []
    if readiness_action_items_path.exists():
        action_items = _read_json(readiness_action_items_path).get("action_items", [])
        if isinstance(action_items, list):
            for item in action_items:
                if not isinstance(item, dict):
                    continue
                if str(item.get("severity", "")).upper() != "BLOCKER":
                    continue
                label = str(item.get("item_name", "")).strip()
                if label:
                    open_blockers.append(label)

    return {
        "latest_run_ref": _relative_ref(latest_run_dir, _repo_root(chip_dir)),
        "latest_readiness_ref": _relative_ref(latest_readiness_ref, _repo_root(chip_dir)) if latest_readiness_ref else None,
        "latest_readiness_summary": latest_summary,
        "open_blockers": sorted(dict.fromkeys(open_blockers)),
    }


def _artifact_family_for(relative_path: str) -> str:
    path = Path(relative_path)
    name = path.name
    if name in {"upstream_alignment_map.json", "upstream_alignment_map.md", "upstream_alignment_map.md.hash.json"}:
        return "agent_routing_map"
    if relative_path.startswith("specs/intake/"):
        return "requirement_intake"
    if name in {"requirement_item.json", "requirement_item_review_package.json", "requirement_item_review_package.md", "requirement_item_adjudication_record.json", "requirement_item_adjudication_record.template.json", "requirement_item_adjudication_guide.md"}:
        return "requirement_adjudication"
    if relative_path.startswith("specs/architecture_estimation/"):
        return "architecture_estimation"
    if relative_path.startswith("architecture/validation/") or name in {"architecture_graph.draft.json", "architecture_graph.json", "builder_validation_handoff.json"}:
        return "graph_validation"
    if relative_path.startswith("architecture/hierarchy/"):
        return "hierarchy"
    if relative_path.startswith("governance/freeze/") or name in {"requirement_freeze_record.json", "graph_freeze_record.json"}:
        return "freeze"
    if relative_path.startswith("generation/") or name == "graph_to_generation_plan.json":
        return "generation_plan"
    if relative_path.startswith("rtl/") and path.suffix.lower() in {".v", ".sv"}:
        return "rtl_candidate"
    if relative_path.startswith("verification/tb/"):
        return "verification_testbench"
    if name in {"v09_handoff_preflight_manifest.json", "upstream_node_output_check.json"}:
        return "handoff_manifest"
    if name in {"chip_program_manifest.yaml", "production_intent.json"}:
        return "chip_bootstrap"
    return "supporting_artifact"


def _source_lane_for(relative_path: str) -> str:
    family = _artifact_family_for(relative_path)
    return {
        "agent_routing_map": "agent_routing_lane",
        "requirement_intake": "intake_source_lane",
        "requirement_adjudication": "requirement_authority_lane",
        "architecture_estimation": "architecture_estimation_lane",
        "graph_validation": "graph_truth_lane",
        "hierarchy": "hierarchy_lane",
        "freeze": "freeze_lane",
        "generation_plan": "generation_plan_lane",
        "rtl_candidate": "rtl_source_lane",
        "verification_testbench": "verification_source_lane",
        "handoff_manifest": "handoff_boundary_lane",
        "chip_bootstrap": "chip_bootstrap_lane",
        "supporting_artifact": "supporting_artifact_lane",
    }[family]


def _upstream_node_for(relative_path: str) -> str:
    path = Path(relative_path)
    name = path.name
    if name in {"upstream_alignment_map.json", "upstream_alignment_map.md", "upstream_alignment_map.md.hash.json"}:
        return "upstream_alignment_map"
    if relative_path.startswith("specs/intake/"):
        return "requirement_intake"
    if name in {"requirement_item.json", "requirement_item_review_package.json", "requirement_item_review_package.md", "requirement_item_adjudication_record.json", "requirement_item_adjudication_record.template.json", "requirement_item_adjudication_guide.md"}:
        return "requirement_adjudication"
    if relative_path.startswith("specs/architecture_estimation/"):
        return "architecture_estimation"
    if relative_path.startswith("architecture/validation/") or name in {"architecture_graph.draft.json", "architecture_graph.json"}:
        return "graph_validation"
    if name == "builder_validation_handoff.json":
        return "graph_draft_check"
    if relative_path.startswith("architecture/hierarchy/"):
        return "hierarchy"
    if relative_path.startswith("governance/freeze/") or name in {"requirement_freeze_record.json", "graph_freeze_record.json"}:
        return "freeze"
    if relative_path.startswith("generation/") or name == "graph_to_generation_plan.json":
        return "generation_plan"
    if relative_path.startswith("rtl/") and path.suffix.lower() in {".v", ".sv"}:
        return "rtl_generation"
    if relative_path.startswith("verification/tb/"):
        return "v2_verilator_sim"
    if name == "v09_handoff_preflight_manifest.json":
        return "v09_handoff_preflight"
    if name == "upstream_node_output_check.json":
        return "upstream_node_output_check"
    if name in {"chip_program_manifest.yaml", "production_intent.json"}:
        return "chip_bootstrap"
    return "supporting_artifact"


def _runner_stage_for(relative_path: str) -> str:
    node = _upstream_node_for(relative_path)
    return {
        "upstream_alignment_map": "Upstream Truth Flow",
        "requirement_intake": "Requirement Intake",
        "requirement_adjudication": "Requirement Adjudication",
        "architecture_estimation": "Upstream Truth Flow",
        "graph_draft_check": "Upstream Truth Flow",
        "graph_validation": "Upstream Truth Flow",
        "hierarchy": "Upstream Truth Flow",
        "freeze": "Upstream Truth Flow",
        "generation_plan": "Upstream Truth Flow",
        "rtl_generation": "Upstream Truth Flow",
        "v2_verilator_sim": "03_v2_verilator_sim",
        "v09_handoff_preflight": "Upstream Truth Flow",
        "upstream_node_output_check": "Upstream Truth Flow",
        "chip_bootstrap": "Requirement Intake",
        "supporting_artifact": "Upstream Truth Flow",
    }[node]


def _prd_refs_for(relative_path: str) -> list[str]:
    path = Path(relative_path)
    name = path.name
    refs = [
        "PRD v1.0 — Spec Completion & Architecture Graph Baseline for ic-agent-flow",
        "PRD v1.0 Addendum — Requirement Intake UI, Attachment & Template Bootstrap",
    ]
    if name in {"upstream_alignment_map.json", "upstream_alignment_map.md", "upstream_alignment_map.md.hash.json"}:
        refs.extend(
            [
                "PRD v1.0 Addendum — Requirement Intake UI, Attachment & Template Bootstrap",
                "PRD v0.9 Routine-B Operator Runbook v0.1",
            ]
        )
    if relative_path.startswith("specs/intake/") or name in {"requirement_item.json", "requirement_item_review_package.json", "requirement_item_review_package.md", "requirement_item_adjudication_record.json", "requirement_item_adjudication_record.template.json", "requirement_item_adjudication_guide.md"}:
        refs.append("PRD v1.0 Addendum — Requirement Intake UI, Attachment & Template Bootstrap")
    if relative_path.startswith("specs/architecture_estimation/"):
        refs.extend(
            [
                "PRD v1.0 — Spec Completion & Architecture Graph Baseline for ic-agent-flow",
                "PRD v1.0 Addendum — Requirement Intake UI, Attachment & Template Bootstrap",
            ]
        )
    if relative_path.startswith("architecture/validation/") or name in {"architecture_graph.draft.json", "architecture_graph.json", "builder_validation_handoff.json"}:
        refs.extend(
            [
                "PRD v1.0 — Spec Completion & Architecture Graph Baseline for ic-agent-flow",
                "PRD v1.0 Addendum — Requirement Intake UI, Attachment & Template Bootstrap",
            ]
        )
    if relative_path.startswith("governance/freeze/") or name in {"requirement_freeze_record.json", "graph_freeze_record.json"}:
        refs.extend(
            [
                "PRD v1.0 — Spec Completion & Architecture Graph Baseline for ic-agent-flow",
                "PRD v1.0 Addendum — Requirement Intake UI, Attachment & Template Bootstrap",
                "PRD v0.9 Routine-B Operator Runbook v0.1",
            ]
        )
    if relative_path.startswith("generation/") or name == "graph_to_generation_plan.json":
        refs.extend(
            [
                "PRD v1.0 — Spec Completion & Architecture Graph Baseline for ic-agent-flow",
                "PRD v0.9 Routine-B Operator Runbook v0.1",
            ]
        )
    if relative_path.startswith("rtl/") and path.suffix.lower() in {".v", ".sv"}:
        refs.extend(
            [
                "PRD v1.0 — Spec Completion & Architecture Graph Baseline for ic-agent-flow",
                "PRD v0.9 Routine-B Operator Runbook v0.1",
            ]
        )
    if relative_path.startswith("verification/tb/"):
        refs.extend(
            [
                "PRD v1.0 Addendum — Requirement Intake UI, Attachment & Template Bootstrap",
                "PRD v0.9 Routine-B Operator Runbook v0.1",
            ]
        )
    if name in {"v09_handoff_preflight_manifest.json", "upstream_node_output_check.json"}:
        refs.extend(
            [
                "PRD v1.0 Addendum — Requirement Intake UI, Attachment & Template Bootstrap",
                "PRD v0.9 Routine-B Operator Runbook v0.1",
            ]
        )
    if name in {"chip_program_manifest.yaml", "production_intent.json"}:
        refs.append("PRD v1.0 Addendum — Requirement Intake UI, Attachment & Template Bootstrap")
    return sorted(dict.fromkeys(refs))


def _notes_for(relative_path: str) -> str:
    path = Path(relative_path)
    name = path.name
    if name == "upstream_alignment_map.json":
        return "Agent-facing derived routing contract that maps chip files to upstream nodes, console surfaces, and PRD references."
    if name == "upstream_alignment_map.md":
        return "Human-readable companion generated from upstream_alignment_map.json; keep it in sync by regenerating from JSON."
    if relative_path.startswith("verification/tb/"):
        return "Chip-scoped testbench lane for bounded simulation and simulation-derived activity evidence."
    if relative_path.startswith("specs/architecture_estimation/"):
        return "Pre-spec estimation companion materialized upstream so the flow can avoid heuristic-only advisory gaps."
    if relative_path.startswith("governance/freeze/"):
        return "Freeze authority object that closes the upstream truth gate before generation planning."
    if relative_path.startswith("generation/"):
        return "Generation planning handoff object bridging frozen truth toward RTL candidate materialization."
    if relative_path.startswith("rtl/") and path.suffix.lower() in {".v", ".sv"}:
        return "Candidate RTL source consumed by bounded simulation / downstream execution after upstream truth is frozen."
    if name == "v09_handoff_preflight_manifest.json":
        return "Chip-scoped handoff contract that proves the upstream truth is ready for PRD v0.9 runner execution."
    if name == "upstream_node_output_check.json":
        return "Machine-readable authoritative checker result for upstream node output completeness."
    if relative_path.startswith("architecture/validation/") or name in {"architecture_graph.draft.json", "architecture_graph.json"}:
        return "Graph boundary object used by validation / freeze / handoff surfaces."
    if name in {"requirement_item.json", "requirement_item_review_package.json", "requirement_item_adjudication_record.json"}:
        return "Human authority and requirement truth lane object."
    if name == "requirement_item_review_package.md" or name == "builder_validation_handoff.md":
        return "Derived human companion generated from JSON truth; do not use as authority input."
    if name in {"chip_program_manifest.yaml", "production_intent.json"}:
        return "Chip bootstrap evidence that anchors upstream workspace identity."
    return "Chip-scoped upstream truth object routed through the console handoff surfaces."


def _required_for(relative_path: str) -> bool:
    return not relative_path.endswith(".md") and not relative_path.endswith(".hash.json")


def _build_item(chip_dir: Path, file_path: Path) -> dict[str, Any]:
    relative_path = file_path.relative_to(chip_dir).as_posix()
    artifact_family = _artifact_family_for(relative_path)
    return {
        "file_path": f"chips/{chip_dir.name}/{relative_path}",
        "file_digest": _sha256_file(file_path),
        "artifact_family": artifact_family,
        "source_lane": _source_lane_for(relative_path),
        "upstream_node": _upstream_node_for(relative_path),
        "upstream_output_contract": _notes_for(relative_path),
        "runner_consumption_stage": _runner_stage_for(relative_path),
        "console_surfaces": DEFAULT_CONSOLE_SURFACES,
        "prd_refs": _prd_refs_for(relative_path),
        "status": "READY" if not relative_path.endswith(".md") else "DERIVED_COMPANION",
        "required": _required_for(relative_path),
        "evidence_refs": [],
        "next_action": {
            "requirement_intake": "continue_requirement_adjudication",
            "requirement_adjudication": "continue_upstream_truth_flow",
            "architecture_estimation": "continue_upstream_truth_flow",
            "graph_draft_check": "continue_graph_validation",
            "graph_validation": "continue_freeze",
            "hierarchy": "continue_upstream_truth_flow",
            "freeze": "continue_generation_plan",
            "generation_plan": "continue_rtl_generation",
            "rtl_generation": "continue_v09_handoff_preflight",
            "v2_verilator_sim": "consume_in_bounded_sim",
            "v09_handoff_preflight": "continue_prd_v0_9_runner_execution",
            "upstream_node_output_check": "refresh_manifest_if_status_pass",
            "chip_bootstrap": "continue_requirement_intake",
            "supporting_artifact": "review_as_upstream_supporting_evidence",
        }[_upstream_node_for(relative_path)],
        "blocker_class": None,
        "notes": _notes_for(relative_path),
        "legacy_aliases": [],
    }


def render_upstream_alignment_map_markdown(payload: dict[str, Any]) -> str:
    surface_aliases = payload.get("surface_aliases", {})
    latest_run = payload.get("latest_run_ref") or "-"
    latest_readiness = payload.get("latest_readiness_ref") or "-"
    open_blockers = payload.get("open_blockers") or []
    lines: list[str] = [
        "# Upstream Alignment Map",
        "",
        "> Derived agent routing contract. JSON is canonical; Markdown is generated from JSON only.",
        "",
        f"- schema_version: `{payload.get('schema_version', ALIGNMENT_MAP_SCHEMA_VERSION)}`",
        f"- chip_id: `{payload.get('chip_id', '-')}`",
        f"- generated_at: `{payload.get('generated_at', '-')}`",
        f"- upstream_execution_id: `{payload.get('upstream_execution_id', '-')}`",
        f"- source_manifest_ref: `{payload.get('source_manifest_ref', '-')}`",
        f"- validation_manifest_ref: `{payload.get('validation_manifest_ref', '-')}`",
        f"- alignment_status: `{payload.get('alignment_status', '-')}`",
        f"- execution_handoff_status: `{payload.get('execution_handoff_status', '-')}`",
        f"- latest_run_ref: `{latest_run}`",
        f"- latest_readiness_ref: `{latest_readiness}`",
        f"- open_blockers: `{', '.join(open_blockers) if open_blockers else 'none'}`",
        "",
        "## Surface Aliases",
        "",
        f"- dashboard_objects canonical: `{surface_aliases.get('dashboard_objects', {}).get('canonical', CANONICAL_DASHBOARD_OBJECT_SURFACE)}`",
        f"- dashboard_objects legacy aliases: `{', '.join(surface_aliases.get('dashboard_objects', {}).get('legacy', [LEGACY_DASHBOARD_OBJECT_ALIAS]))}`",
        "",
        "## Items",
        "",
        "| File | Upstream node | Console surfaces | PRD refs | Status | Next action |",
        "|---|---|---|---|---|---|",
    ]
    for item in payload.get("items", []):
        if not isinstance(item, dict):
            continue
        lines.append(
            "| "
            f"{item.get('file_path', '-')}"
            " | "
            f"{item.get('upstream_node', '-')}"
            " | "
            f"{', '.join(item.get('console_surfaces', []))}"
            " | "
            f"{'; '.join(item.get('prd_refs', []))}"
            " | "
            f"{item.get('status', '-')}"
            " | "
            f"{item.get('next_action', '-')}"
            " |"
        )
    lines.append("")
    return "\n".join(lines)


def build_upstream_alignment_map(*, chip_dir: Path | str, generated_at: str | None = None) -> dict[str, Any]:
    chip_dir = Path(chip_dir)
    repo_root = _repo_root(chip_dir)
    generated_at = generated_at or get_tw_now().isoformat()
    source_manifest = chip_dir / "governance" / "v09_handoff_preflight_manifest.json"
    validation_manifest = chip_dir / "governance" / "upstream_node_output_check.json"
    items = [_build_item(chip_dir, path) for path in _iter_alignment_files(chip_dir)]
    source_digest_bundle = _sha256_json({item["file_path"]: item["file_digest"] for item in items})
    latest_run_context = _latest_run_context(chip_dir)
    payload = {
        "schema_version": ALIGNMENT_MAP_SCHEMA_VERSION,
        "chip_id": chip_dir.name,
        "generated_at": generated_at,
        "upstream_execution_id": str(
            _read_json(source_manifest).get("upstream_operation_id")
            or _read_json(source_manifest).get("manifest_id")
            or latest_run_context.get("latest_run_ref")
            or chip_dir.name
        ),
        "source_manifest_ref": _relative_ref(source_manifest, repo_root),
        "validation_manifest_ref": _relative_ref(validation_manifest, repo_root),
        "alignment_status": "READY" if items else "BLOCKED",
        "execution_handoff_status": (
            "READY_WITH_PHYSICAL_BLOCKERS"
            if latest_run_context.get("open_blockers")
            else "READY"
        ),
        "open_blockers": latest_run_context.get("open_blockers", []),
        "latest_run_ref": latest_run_context.get("latest_run_ref"),
        "latest_readiness_ref": latest_run_context.get("latest_readiness_ref"),
        "latest_readiness_summary": latest_run_context.get("latest_readiness_summary"),
        "surface_aliases": {
            "dashboard_objects": {
                "canonical": CANONICAL_DASHBOARD_OBJECT_SURFACE,
                "legacy": [LEGACY_DASHBOARD_OBJECT_ALIAS],
                "status": "legacy_compatibility",
                "notes": "Normalize older runs to the canonical dashboard-object surface when reading history.",
            }
        },
        "console_surfaces": DEFAULT_CONSOLE_SURFACES,
        "source_digest_bundle": source_digest_bundle,
        "items": items,
        "companion_outputs": {
            "json": (chip_dir / "governance" / "upstream_alignment_map.json").as_posix(),
            "md": (chip_dir / "governance" / "upstream_alignment_map.md").as_posix(),
        },
    }
    payload["validation"] = validate_upstream_alignment_map(payload=payload, chip_dir=chip_dir)
    return payload


def validate_upstream_alignment_map(*, payload: dict[str, Any], chip_dir: Path | str) -> dict[str, Any]:
    chip_dir = Path(chip_dir)
    repo_root = _repo_root(chip_dir)
    errors: list[str] = []
    warnings: list[str] = []

    if not isinstance(payload, dict):
        return {"status": "BLOCKED", "errors": ["payload_not_dict"], "warnings": []}

    if str(payload.get("schema_version")) != ALIGNMENT_MAP_SCHEMA_VERSION:
        errors.append("schema_version_mismatch")
    if str(payload.get("chip_id")) != chip_dir.name:
        errors.append("chip_id_mismatch")

    source_manifest_ref = str(payload.get("source_manifest_ref") or "").strip()
    if not source_manifest_ref:
        errors.append("missing_source_manifest_ref")
    elif not (repo_root / source_manifest_ref).exists():
        errors.append("source_manifest_missing")

    validation_manifest_ref = str(payload.get("validation_manifest_ref") or "").strip()
    if validation_manifest_ref and not (repo_root / validation_manifest_ref).exists():
        errors.append("validation_manifest_missing")

    surface_aliases = payload.get("surface_aliases", {})
    dashboard_alias = surface_aliases.get("dashboard_objects", {}) if isinstance(surface_aliases, dict) else {}
    if dashboard_alias.get("canonical") != CANONICAL_DASHBOARD_OBJECT_SURFACE:
        errors.append("dashboard_object_canonical_alias_missing")
    legacy_aliases = dashboard_alias.get("legacy", [])
    if LEGACY_DASHBOARD_OBJECT_ALIAS not in legacy_aliases:
        errors.append("dashboard_object_legacy_alias_missing")

    items = payload.get("items", [])
    if not isinstance(items, list) or not items:
        errors.append("items_missing_or_empty")
        items = []

    seen_paths: set[str] = set()
    source_digest_index: dict[str, str] = {}
    allowed_surfaces = set(DEFAULT_CONSOLE_SURFACES)
    for idx, item in enumerate(items):
        if not isinstance(item, dict):
            errors.append(f"item_{idx}_not_dict")
            continue
        file_path = str(item.get("file_path") or "").strip()
        if not file_path:
            errors.append(f"item_{idx}_missing_file_path")
            continue
        if file_path in seen_paths:
            errors.append(f"duplicate_item_path:{file_path}")
        seen_paths.add(file_path)
        rel = file_path
        if rel.startswith("chips/"):
            rel = rel.split(f"chips/{chip_dir.name}/", 1)[-1]
        file_on_disk = chip_dir / rel
        if not file_on_disk.exists():
            errors.append(f"missing_file:{file_path}")
            continue
        file_digest = str(item.get("file_digest") or "").strip()
        actual_digest = _sha256_file(file_on_disk)
        source_digest_index[file_path] = actual_digest
        if file_digest != actual_digest:
            errors.append(f"digest_mismatch:{file_path}")
        surfaces = item.get("console_surfaces", [])
        if not isinstance(surfaces, list) or not surfaces:
            errors.append(f"console_surfaces_missing:{file_path}")
        else:
            for surface in surfaces:
                if str(surface) not in allowed_surfaces:
                    warnings.append(f"unknown_console_surface:{file_path}:{surface}")
        if not isinstance(item.get("prd_refs", []), list) or not item.get("prd_refs"):
            errors.append(f"prd_refs_missing:{file_path}")
        if str(item.get("next_action") or "").strip() == "":
            errors.append(f"next_action_missing:{file_path}")

    source_digest_bundle = _sha256_json(source_digest_index) if source_digest_index else ""
    if payload.get("source_digest_bundle") != source_digest_bundle:
        errors.append("source_digest_bundle_mismatch")

    status = "PASS" if not errors else "BLOCKED"
    return {
        "status": status,
        "errors": errors,
        "warnings": warnings,
        "item_count": len(items),
        "source_digest_bundle": source_digest_bundle,
        "alignment_status": payload.get("alignment_status", "UNKNOWN"),
        "execution_handoff_status": payload.get("execution_handoff_status", "UNKNOWN"),
    }


def ensure_upstream_alignment_map(
    *,
    chip_dir: Path | str,
    generated_at: str | None = None,
    refresh_if_stale: bool = True,
) -> dict[str, Any]:
    chip_dir = Path(chip_dir)
    output_json = chip_dir / "governance" / "upstream_alignment_map.json"
    output_md = chip_dir / "governance" / "upstream_alignment_map.md"
    output_hash = output_md.with_suffix(output_md.suffix + ".hash.json")

    payload = build_upstream_alignment_map(chip_dir=chip_dir, generated_at=generated_at)
    existing = _read_json(output_json) if output_json.exists() else {}
    existing_bundle = str(existing.get("source_digest_bundle") or "")
    if not refresh_if_stale and existing_bundle == payload["source_digest_bundle"] and output_md.exists():
        return existing or payload

    output_json.parent.mkdir(parents=True, exist_ok=True)
    output_json.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    markdown = render_upstream_alignment_map_markdown(payload)
    output_md.write_text(markdown.rstrip() + "\n", encoding="utf-8")
    output_hash.write_text(
        json.dumps(
            {
                "schema_version": "upstream-alignment-map-markdown-hash.v0.1",
                "source_digest_bundle": payload["source_digest_bundle"],
                "generated_at": payload["generated_at"],
                "companion_ref": output_md.as_posix(),
                "json_ref": output_json.as_posix(),
            },
            indent=2,
            ensure_ascii=False,
        )
        + "\n",
        encoding="utf-8",
    )
    return payload
