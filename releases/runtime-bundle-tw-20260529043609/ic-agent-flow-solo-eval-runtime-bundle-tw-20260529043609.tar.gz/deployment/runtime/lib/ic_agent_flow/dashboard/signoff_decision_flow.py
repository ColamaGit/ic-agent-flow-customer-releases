from __future__ import annotations

from datetime import datetime, timezone


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def build_signoff_decision_inbox(*, run_scope: dict, objects: dict) -> dict:
    waiver = objects.get("waiver_approval_record", {})
    risk = objects.get("risk_acceptance_record", {})
    final_readiness = objects.get("final_tapeout_readiness_record", {})
    gap = objects.get("signoff_gap_record", {})
    authority = objects.get("authority_chain_verdict", {})
    stage_conditional_pass = objects.get("stage_conditional_pass_record", {})
    stage_claim_boundary = objects.get("stage_claim_boundary_record", {})
    items: list[dict] = []
    completed_items: list[dict] = []

    blocked_claims = []
    if isinstance(stage_conditional_pass.get("blocked_claims"), list):
        blocked_claims.extend(str(x) for x in stage_conditional_pass["blocked_claims"])
    if isinstance(stage_claim_boundary.get("blocked_claims"), list):
        blocked_claims.extend(str(x) for x in stage_claim_boundary["blocked_claims"])
    if blocked_claims:
        items.append(
            {
                "action_id": "request_revalidation_for_blocked_claims",
                "status": "PENDING",
                "required_role": "SIGNOFF_APPROVER",
                "reason": ",".join(sorted(set(blocked_claims))),
            }
        )

    if waiver.get("status") != "APPROVED":
        items.append(
            {
                "action_id": "approve_waiver",
                "status": "PENDING",
                "required_role": "SIGNOFF_APPROVER",
                "reason": "waiver_approval_record not approved",
            }
        )
    else:
        completed_items.append(
            {
                "action_id": "approve_waiver",
                "status": "DONE",
                "required_role": "SIGNOFF_APPROVER",
                "reason": "waiver_approval_record approved",
            }
        )
    if risk.get("status") != "ACCEPTED":
        items.append(
            {
                "action_id": "accept_risk",
                "status": "PENDING",
                "required_role": "RELEASE_AUTHORITY",
                "reason": "risk_acceptance_record not accepted",
            }
        )
    else:
        completed_items.append(
            {
                "action_id": "accept_risk",
                "status": "DONE",
                "required_role": "RELEASE_AUTHORITY",
                "reason": "risk_acceptance_record accepted",
            }
        )

    final_status = str(final_readiness.get("status", "NOT_AVAILABLE")).upper()
    if final_status != "READY_FOR_TAPEOUT_PACKAGE_ASSEMBLY":
        reason_parts = [
            f"final={final_status}",
            f"gap={str(gap.get('status', 'NOT_AVAILABLE')).upper()}",
            f"authority={str(authority.get('status', 'NOT_AVAILABLE')).upper()}",
        ]
        items.append(
            {
                "action_id": "finalize_tapeout_readiness",
                "status": "PENDING",
                "required_role": "RELEASE_AUTHORITY",
                "reason": ",".join(reason_parts),
            }
        )
    else:
        completed_items.append(
            {
                "action_id": "finalize_tapeout_readiness",
                "status": "DONE",
                "required_role": "RELEASE_AUTHORITY",
                "reason": "final_tapeout_readiness_record ready",
            }
        )

    return {
        "schema_version": "v1.13",
        "type": "signoff_decision_inbox",
        "generated_at": _now_iso(),
        "scope": run_scope,
        "items": items,
        "pending_count": len(items),
        "completed_items": completed_items,
        "completed_count": len(completed_items),
    }
