import json
from datetime import datetime, timezone
from pathlib import Path


def _read_json(path: Path) -> dict:
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def _logical_uri(chip_id: str, run_id: str, date_time: str, artifact_family: str, filename: str) -> str:
    relative_path = f"production-runs/{chip_id}/{run_id}/{date_time}/{artifact_family}/{filename}"
    return f"icaf://artifact/{relative_path}"


def _artifact_ref(chip_id: str, run_id: str, date_time: str, artifact_family: str, filename: str) -> dict:
    return {
        "logical_uri": _logical_uri(chip_id, run_id, date_time, artifact_family, filename),
        "artifact_family": artifact_family,
    }


def _load_companion_artifact(input_root: Path, relative_path: str) -> dict:
    return _read_json(Path(input_root) / relative_path)


def _generated_at_from_date_time(date_time: str) -> str:
    try:
        dt = datetime.strptime(date_time, "%Y%m%d-%H%M%S").replace(tzinfo=timezone.utc)
        return dt.isoformat().replace("+00:00", "Z")
    except ValueError:
        return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _derive_scenario_requirement_matrix_from_artifacts(input_root: Path) -> dict:
    workload = _load_companion_artifact(input_root, "inputs/architecture_estimation/systemc_workload_profile.json")
    tradeoff = _load_companion_artifact(input_root, "inputs/architecture_estimation/architecture_tradeoff_matrix.json")
    scenarios = workload.get("scenarios") if isinstance(workload.get("scenarios"), list) else []
    requirements = workload.get("requirements") if isinstance(workload.get("requirements"), list) else []
    scenario_evidence_ref = {
        "logical_uri": "icaf://artifact/inputs/architecture_estimation/systemc_workload_profile.json",
        "artifact_family": "architecture_estimation",
    }
    requirement_evidence_ref = {
        "logical_uri": "icaf://artifact/inputs/architecture_estimation/systemc_workload_profile.json",
        "artifact_family": "architecture_estimation",
    }

    scenario_results = []
    for item in scenarios:
        if not isinstance(item, dict):
            continue
        verdict = str(item.get("verdict", "PARTIAL")).upper()
        if verdict not in {"MEETING", "NOT_MEETING", "PARTIAL"}:
            verdict = "PARTIAL"
        failed_requirements = [str(x) for x in item.get("failed_requirements", [])] if isinstance(item.get("failed_requirements"), list) else []
        failed_assumptions = [str(x) for x in item.get("failed_assumptions", [])] if isinstance(item.get("failed_assumptions"), list) else []
        if verdict == "MEETING":
            verdict_rule_id = "SCENARIO_VERDICT_RULE_V1_MEETING"
            verdict_reason = "scenario_marked_meeting_by_workload_profile"
        elif verdict == "NOT_MEETING":
            verdict_rule_id = "SCENARIO_VERDICT_RULE_V1_NOT_MEETING"
            verdict_reason = "scenario_marked_not_meeting_by_workload_profile"
        else:
            verdict_rule_id = "SCENARIO_VERDICT_RULE_V1_PARTIAL"
            verdict_reason = (
                "partial_due_to_failed_requirements_listed"
                if failed_requirements
                else "partial_due_to_unresolved_or_missing_workload_evidence"
            )
        scenario_results.append(
            {
                "scenario_id": str(item.get("scenario_id", item.get("id", "unknown_scenario"))),
                "verdict": verdict,
                "failed_requirements": failed_requirements,
                "failed_assumptions": failed_assumptions,
                "verdict_rule_id": verdict_rule_id,
                "verdict_reason": verdict_reason,
                "evidence_refs": [scenario_evidence_ref],
            }
        )

    requirement_results = []
    for item in requirements:
        if not isinstance(item, dict):
            continue
        verdict = str(item.get("verdict", "PARTIAL")).upper()
        if verdict not in {"MEETING", "NOT_MEETING", "PARTIAL"}:
            verdict = "PARTIAL"
        evidence_refs = []
        if isinstance(item.get("evidence_refs"), list):
            evidence_refs = [x for x in item.get("evidence_refs", []) if isinstance(x, dict)]
        if not evidence_refs:
            evidence_refs = [requirement_evidence_ref]
        if verdict == "MEETING":
            verdict_rule_id = "REQUIREMENT_VERDICT_RULE_V1_MEETING"
            verdict_reason = "requirement_marked_meeting_by_workload_profile"
        elif verdict == "NOT_MEETING":
            verdict_rule_id = "REQUIREMENT_VERDICT_RULE_V1_NOT_MEETING"
            verdict_reason = "requirement_marked_not_meeting_by_workload_profile"
        else:
            verdict_rule_id = "REQUIREMENT_VERDICT_RULE_V1_PARTIAL"
            verdict_reason = "requirement_partial_due_to_unresolved_or_mixed_scenario_results"
        requirement_results.append(
            {
                "requirement_id": str(item.get("requirement_id", item.get("id", "unknown_requirement"))),
                "verdict": verdict,
                "failed_assumptions": [str(x) for x in item.get("failed_assumptions", [])] if isinstance(item.get("failed_assumptions"), list) else [],
                "verdict_rule_id": verdict_rule_id,
                "verdict_reason": verdict_reason,
                "evidence_refs": evidence_refs,
            }
        )

    if not scenario_results:
        missing_catalog_req = "REQ_WORKLOAD_SCENARIO_CATALOG_MISSING"
        scenario_results.append(
            {
                "scenario_id": "SCENARIO_WORKLOAD_PROFILE_MISSING",
                "verdict": "PARTIAL",
                "failed_requirements": [missing_catalog_req],
                "failed_assumptions": ["ASSUME_WORKLOAD_PROFILE_PRESENT"],
                "verdict_rule_id": "SCENARIO_VERDICT_RULE_V1_SEMANTIC_MISSING_WORKLOAD_CATALOG",
                "verdict_reason": "semantic_fail_closed_due_to_missing_workload_profile_scenarios",
                "evidence_refs": [
                    {
                        "logical_uri": "icaf://artifact/inputs/architecture_estimation/systemc_workload_profile.json",
                        "artifact_family": "architecture_estimation",
                    }
                ],
            }
        )
        requirement_results.append(
            {
                "requirement_id": missing_catalog_req,
                "verdict": "PARTIAL",
                "failed_assumptions": ["ASSUME_WORKLOAD_PROFILE_PRESENT"],
                "verdict_rule_id": "REQUIREMENT_VERDICT_RULE_V1_SEMANTIC_MISSING_WORKLOAD_CATALOG",
                "verdict_reason": "semantic_fail_closed_due_to_missing_workload_profile_scenarios",
                "evidence_refs": [requirement_evidence_ref],
            }
        )

    # Invariant convergence:
    # 1) scenario.failed_requirements must map to requirement_results.
    # 2) requirement_results(PARTIAL/NOT_MEETING) must be referenced by at least one scenario failed_requirements.
    req_by_id = {}
    for req in requirement_results:
        rid = str(req.get("requirement_id", ""))
        if rid:
            req_by_id[rid] = req

    for s in scenario_results:
        failed = [str(x) for x in s.get("failed_requirements", []) if str(x)]
        if s.get("verdict") == "MEETING" and failed:
            s["verdict"] = "PARTIAL"
            s["verdict_rule_id"] = "SCENARIO_VERDICT_RULE_V1_INVARIANT_CONVERGED"
            s["verdict_reason"] = "scenario_failed_requirements_non_empty_forced_to_partial"
        s["failed_requirements"] = failed
        if "failed_assumptions" not in s or not isinstance(s.get("failed_assumptions"), list):
            s["failed_assumptions"] = []
        for rid in failed:
            req = req_by_id.get(rid)
            if req is None:
                req = {
                    "requirement_id": rid,
                    "verdict": "PARTIAL",
                    "verdict_rule_id": "REQUIREMENT_VERDICT_RULE_V1_INVARIANT_SYNTHESIZED",
                    "verdict_reason": "synthesized_from_scenario_failed_requirements_invariant",
                    "evidence_refs": [requirement_evidence_ref],
                }
                requirement_results.append(req)
                req_by_id[rid] = req
            elif req.get("verdict") == "MEETING":
                req["verdict"] = "PARTIAL"
                req["verdict_rule_id"] = "REQUIREMENT_VERDICT_RULE_V1_INVARIANT_DOWNGRADED"
                req["verdict_reason"] = "downgraded_from_meeting_due_to_scenario_failed_requirements_invariant"

    failed_refs = set()
    for s in scenario_results:
        for rid in s.get("failed_requirements", []):
            failed_refs.add(str(rid))

    req_need_reference = [
        str(r.get("requirement_id"))
        for r in requirement_results
        if str(r.get("verdict", "")).upper() in {"PARTIAL", "NOT_MEETING"}
    ]
    scenario_non_meeting = [s for s in scenario_results if str(s.get("verdict", "")).upper() != "MEETING"]
    for rid in req_need_reference:
        if rid in failed_refs:
            continue
        if scenario_non_meeting:
            target = scenario_non_meeting[0]
            target_failed = list(target.get("failed_requirements", []))
            if rid not in target_failed:
                target_failed.append(rid)
                target["failed_requirements"] = target_failed
                if str(target.get("verdict", "")).upper() == "MEETING":
                    target["verdict"] = "PARTIAL"
                    target["verdict_rule_id"] = "SCENARIO_VERDICT_RULE_V1_INVARIANT_CONVERGED"
                    target["verdict_reason"] = "forced_partial_for_requirement_reverse_mapping_invariant"
            failed_refs.add(rid)
        elif scenario_results:
            target = scenario_results[0]
            target_failed = list(target.get("failed_requirements", []))
            if rid not in target_failed:
                target_failed.append(rid)
                target["failed_requirements"] = target_failed
                if str(target.get("verdict", "")).upper() == "MEETING":
                    target["verdict"] = "PARTIAL"
                    target["verdict_rule_id"] = "SCENARIO_VERDICT_RULE_V1_INVARIANT_CONVERGED"
                    target["verdict_reason"] = "forced_partial_for_requirement_reverse_mapping_invariant"
            failed_refs.add(rid)
        else:
            scenario_results.append(
                {
                    "scenario_id": "invariant_synthesized_scenario_1",
                    "verdict": "PARTIAL",
                    "failed_requirements": [rid],
                    "failed_assumptions": [],
                    "verdict_rule_id": "SCENARIO_VERDICT_RULE_V1_INVARIANT_SYNTHESIZED",
                    "verdict_reason": "synthesized_from_unmapped_requirement_invariant",
                    "evidence_refs": [scenario_evidence_ref],
                }
            )
            failed_refs.add(rid)

    # Fail-closed synthesis for sparse workload inputs:
    # if scenarios exist but no requirement catalog is provided,
    # emit a synthetic requirement row so requirement drill-down remains actionable.
    if scenario_results and not requirement_results:
        synthesized_requirement_id = "REQ_WORKLOAD_REQUIREMENTS_NOT_PROVIDED"
        requirement_results.append(
            {
                "requirement_id": synthesized_requirement_id,
                "verdict": "PARTIAL",
                "failed_assumptions": [],
                "verdict_rule_id": "REQUIREMENT_VERDICT_RULE_V1_SYNTHESIZED_MISSING_REQUIREMENT_CATALOG",
                "verdict_reason": "synthesized_due_to_missing_workload_requirement_catalog",
                "evidence_refs": [requirement_evidence_ref],
            }
        )
        first = scenario_results[0]
        first_failed = [str(x) for x in first.get("failed_requirements", []) if str(x)]
        if synthesized_requirement_id not in first_failed:
            first_failed.append(synthesized_requirement_id)
            first["failed_requirements"] = first_failed
            if str(first.get("verdict", "")).upper() == "MEETING":
                first["verdict"] = "PARTIAL"
                first["verdict_rule_id"] = "SCENARIO_VERDICT_RULE_V1_INVARIANT_CONVERGED"
                first["verdict_reason"] = "forced_partial_for_synthesized_requirement_catalog_gap"

    scenario_count = len(scenario_results)
    scenario_pass_count = sum(1 for row in scenario_results if row["verdict"] == "MEETING")
    requirement_count = len(requirement_results)
    requirement_global_pass_count = sum(1 for row in requirement_results if row["verdict"] == "MEETING")
    return {
        "scenario_count": scenario_count,
        "scenario_pass_count": scenario_pass_count,
        "requirement_count": requirement_count,
        "requirement_global_pass_count": requirement_global_pass_count,
        "scenario_results": scenario_results,
        "requirement_results": requirement_results,
    }


def _derive_candidate_scorecards_from_artifacts(input_root: Path) -> dict:
    score_version = "opt_arch_002_v1"

    def _clamp_ratio(raw: object) -> float:
        try:
            value = float(raw)
        except Exception:
            value = 0.0
        return max(0.0, min(1.0, value))

    def _risk_from_ratio(ratio: float) -> str:
        if ratio >= 0.85:
            return "LOW"
        if ratio >= 0.60:
            return "MEDIUM"
        return "HIGH"

    def _normalize_risk(raw: object, fallback_ratio: float) -> str:
        risk = str(raw or "").upper()
        if risk in {"LOW", "MEDIUM", "HIGH"}:
            return risk
        return _risk_from_ratio(fallback_ratio)

    def _recommendation_from_profile(
        *,
        is_selected: bool,
        scenario_ratio: float,
        requirement_ratio: float,
        risk_levels: list[str],
    ) -> str:
        high_count = sum(1 for r in risk_levels if r == "HIGH")
        if is_selected and scenario_ratio >= 0.75 and requirement_ratio >= 0.75 and high_count <= 1:
            return "PREFERRED"
        if scenario_ratio >= 0.60 and requirement_ratio >= 0.60 and high_count <= 2:
            return "ALTERNATIVE"
        if scenario_ratio < 0.35 or requirement_ratio < 0.35 or high_count >= 4:
            return "REJECTED"
        return "NEEDS_MORE_EVIDENCE"

    tradeoff = _load_companion_artifact(input_root, "inputs/architecture_estimation/architecture_tradeoff_matrix.json")
    decision = _load_companion_artifact(input_root, "inputs/architecture_estimation/human_architecture_decision_record.json")
    selected = str(decision.get("selected_candidate_id", ""))
    candidates = tradeoff.get("candidates") if isinstance(tradeoff.get("candidates"), list) else []
    records = []
    for idx, candidate in enumerate(candidates):
        if not isinstance(candidate, dict):
            continue
        cid = str(candidate.get("candidate_id", f"candidate_{idx + 1}"))
        scenario_ratio = _clamp_ratio(candidate.get("scenario_meeting_ratio", 0.0))
        requirement_ratio = _clamp_ratio(candidate.get("requirement_meeting_ratio", 0.0))
        bandwidth_risk = _normalize_risk(candidate.get("bandwidth_risk"), scenario_ratio)
        latency_risk = _normalize_risk(candidate.get("latency_risk"), scenario_ratio)
        power_risk = _normalize_risk(candidate.get("power_risk"), requirement_ratio)
        area_risk = _normalize_risk(candidate.get("area_risk"), requirement_ratio)
        ip_risk = _normalize_risk(candidate.get("ip_integration_risk"), min(scenario_ratio, requirement_ratio))
        normalized_recommendation = _recommendation_from_profile(
            is_selected=bool(selected and selected == cid),
            scenario_ratio=scenario_ratio,
            requirement_ratio=requirement_ratio,
            risk_levels=[bandwidth_risk, latency_risk, power_risk, area_risk, ip_risk],
        )
        records.append(
            {
                "candidate_id": cid,
                "scenario_meeting_ratio": scenario_ratio,
                "requirement_meeting_ratio": requirement_ratio,
                "bandwidth_risk": bandwidth_risk,
                "latency_risk": latency_risk,
                "power_risk": power_risk,
                "area_risk": area_risk,
                "ip_integration_risk": ip_risk,
                "recommendation": normalized_recommendation,
                "score_version": score_version,
                "scoring_inputs": {
                    "scenario_meeting_ratio": scenario_ratio,
                    "requirement_meeting_ratio": requirement_ratio,
                    "selected_candidate_id": selected,
                },
                "scoring_trace": {
                    "rule_id": "ARCH_CANDIDATE_SCORECARD_RULE_OPT_ARCH_002_V1",
                    "high_risk_count": sum(1 for r in [bandwidth_risk, latency_risk, power_risk, area_risk, ip_risk] if r == "HIGH"),
                    "derived_recommendation": normalized_recommendation,
                },
                "evidence_refs": [],
            }
        )
    return {"candidates": records}


def build_architecture_exploration_objects(
    *,
    chip_id: str,
    run_id: str,
    date_time: str,
    input_root: Path,
) -> dict:
    generated_at = _generated_at_from_date_time(date_time)
    object_version = "opt_arch_004_v1"
    scenario_matrix_input = _read_json(Path(input_root) / "scenario_requirement_matrix_input.json")
    candidate_scorecards_input = _read_json(Path(input_root) / "architecture_candidate_scorecards_input.json")
    if not scenario_matrix_input:
        scenario_matrix_input = _derive_scenario_requirement_matrix_from_artifacts(Path(input_root))
    if not candidate_scorecards_input:
        candidate_scorecards_input = _derive_candidate_scorecards_from_artifacts(Path(input_root))

    model_view_manifest = {
        "manifest_id": f"arch-view-{chip_id}-{run_id}-{date_time}",
        "type": "architecture_model_view_manifest",
        "schema_version": "1.8.0",
        "chip_id": chip_id,
        "run_id": run_id,
        "source_run_id": run_id,
        "source_date_time": date_time,
        "generated_at": generated_at,
        "object_version": object_version,
        "compatibility_mode": "STRICT",
        "source_refs": {
            "hierarchy_manifest": _artifact_ref(chip_id, run_id, date_time, "hierarchy", "hierarchy_manifest.json"),
            "interface_contracts": _artifact_ref(
                chip_id, run_id, date_time, "hierarchy", "hierarchy_interface_contracts.json"
            ),
            "workload_profile": _artifact_ref(
                chip_id, run_id, date_time, "architecture_estimation", "systemc_workload_profile.json"
            ),
            "power_estimation": _artifact_ref(
                chip_id, run_id, date_time, "architecture_estimation", "power_toggle_estimation.json"
            ),
            "area_estimation": _artifact_ref(
                chip_id, run_id, date_time, "architecture_estimation", "area_budget_estimation.json"
            ),
            "ip_selection": _artifact_ref(
                chip_id, run_id, date_time, "architecture_estimation", "ip_selection_estimation.json"
            ),
            "tradeoff_matrix": _artifact_ref(
                chip_id, run_id, date_time, "architecture_estimation", "architecture_tradeoff_matrix.json"
            ),
        },
        "layout_regions": [
            "hw_model",
            "scenario_summary",
            "bus_bottleneck",
            "ppa_proxy",
            "ip_decision",
            "human_decision",
        ],
    }

    scenario_requirement_matrix = {
        "matrix_id": f"scenario-matrix-{chip_id}-{run_id}-{date_time}",
        "type": "scenario_requirement_matrix",
        "schema_version": "1.8.0",
        "chip_id": chip_id,
        "run_id": run_id,
        "source_run_id": run_id,
        "source_date_time": date_time,
        "generated_at": generated_at,
        "object_version": object_version,
        "compatibility_mode": "STRICT",
        "scenario_count": int(scenario_matrix_input.get("scenario_count", 0)),
        "scenario_pass_count": int(scenario_matrix_input.get("scenario_pass_count", 0)),
        "requirement_count": int(scenario_matrix_input.get("requirement_count", 0)),
        "requirement_global_pass_count": int(scenario_matrix_input.get("requirement_global_pass_count", 0)),
        "scenario_results": scenario_matrix_input.get("scenario_results", []),
        "requirement_results": scenario_matrix_input.get("requirement_results", []),
    }

    candidates = candidate_scorecards_input.get("candidates", [])
    if not candidates:
        candidates = [
            {
                "candidate_id": "candidate_default",
                "scenario_meeting_ratio": 0.0,
                "requirement_meeting_ratio": 0.0,
                "bandwidth_risk": "MEDIUM",
                "latency_risk": "MEDIUM",
                "power_risk": "MEDIUM",
                "area_risk": "MEDIUM",
                "ip_integration_risk": "MEDIUM",
                "recommendation": "NEEDS_MORE_EVIDENCE",
                "score_version": "opt_arch_002_v1",
                "scoring_inputs": {
                    "scenario_meeting_ratio": 0.0,
                    "requirement_meeting_ratio": 0.0,
                    "selected_candidate_id": "",
                },
                "scoring_trace": {
                    "rule_id": "ARCH_CANDIDATE_SCORECARD_RULE_OPT_ARCH_002_V1",
                    "high_risk_count": 0,
                    "derived_recommendation": "NEEDS_MORE_EVIDENCE",
                },
            }
        ]

    architecture_candidate_scorecards = []
    for candidate in candidates:
        scenario_ratio = max(0.0, min(1.0, float(candidate.get("scenario_meeting_ratio", 0.0))))
        requirement_ratio = max(0.0, min(1.0, float(candidate.get("requirement_meeting_ratio", 0.0))))
        recommendation = str(candidate.get("recommendation", "NEEDS_MORE_EVIDENCE")).upper()
        if recommendation not in {"PREFERRED", "ALTERNATIVE", "REJECTED", "NEEDS_MORE_EVIDENCE"}:
            recommendation = "NEEDS_MORE_EVIDENCE"
        score_version = str(candidate.get("score_version", "opt_arch_002_v1"))
        scoring_inputs = candidate.get(
            "scoring_inputs",
            {
                "scenario_meeting_ratio": scenario_ratio,
                "requirement_meeting_ratio": requirement_ratio,
                "selected_candidate_id": "",
            },
        )
        scoring_trace = candidate.get(
            "scoring_trace",
            {
                "rule_id": "ARCH_CANDIDATE_SCORECARD_RULE_OPT_ARCH_002_V1",
                "high_risk_count": 0,
                "derived_recommendation": recommendation,
            },
        )
        if isinstance(scoring_trace, dict) and "derived_recommendation" not in scoring_trace:
            scoring_trace["derived_recommendation"] = recommendation
        if isinstance(scoring_trace, dict) and "rule_id" not in scoring_trace:
            scoring_trace["rule_id"] = "ARCH_CANDIDATE_SCORECARD_RULE_OPT_ARCH_002_V1"
        architecture_candidate_scorecards.append(
            {
                "scorecard_id": f"candidate-{chip_id}-{run_id}-{candidate['candidate_id']}",
                "type": "architecture_candidate_scorecard",
                "schema_version": "1.8.0",
                "chip_id": chip_id,
                "run_id": run_id,
                "source_run_id": run_id,
                "source_date_time": date_time,
                "generated_at": generated_at,
                "object_version": object_version,
                "compatibility_mode": "STRICT",
                "candidate_id": candidate["candidate_id"],
                "scenario_meeting_ratio": scenario_ratio,
                "requirement_meeting_ratio": requirement_ratio,
                "bandwidth_risk": candidate.get("bandwidth_risk", "MEDIUM"),
                "latency_risk": candidate.get("latency_risk", "MEDIUM"),
                "power_risk": candidate.get("power_risk", "MEDIUM"),
                "area_risk": candidate.get("area_risk", "MEDIUM"),
                "ip_integration_risk": candidate.get("ip_integration_risk", "MEDIUM"),
                "recommendation": recommendation,
                "score_version": score_version,
                "scoring_inputs": scoring_inputs,
                "scoring_trace": scoring_trace,
                "evidence_refs": candidate.get("evidence_refs", []),
            }
        )

    return {
        "architecture_model_view_manifest": model_view_manifest,
        "scenario_requirement_matrix": scenario_requirement_matrix,
        "architecture_candidate_scorecards": architecture_candidate_scorecards,
    }
