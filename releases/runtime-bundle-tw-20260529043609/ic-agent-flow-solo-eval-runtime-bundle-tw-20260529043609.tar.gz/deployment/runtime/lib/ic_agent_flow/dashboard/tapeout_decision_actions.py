from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

_ALLOWED_ROLES: dict[str, set[str]] = {
    "approve_handoff": {"TAPEOUT_AUTHORITY"},
    "approve_with_limitations": {"TAPEOUT_AUTHORITY"},
    "hold_handoff": {"TAPEOUT_AUTHORITY"},
    "reject_handoff": {"TAPEOUT_AUTHORITY"},
    "request_more_evidence": {"TAPEOUT_AUTHORITY", "RELEASE_OPERATOR"},
    "record_transfer": {"RELEASE_OPERATOR"},
    "record_receipt": {"RELEASE_OPERATOR"},
}


def _iso_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def _save(path: Path, payload: dict) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def _write_action_record(out_dir: Path, *, action_id: str, actor_role: str, result: str, notes: str) -> None:
    rec_dir = out_dir / "tapeout_action_records"
    rec_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    payload = {
        "schema_version": "v1.14",
        "type": "tapeout_action_record",
        "action_id": action_id,
        "actor_role": actor_role,
        "result": result,
        "notes": notes,
        "generated_at": _iso_now(),
    }
    _save(rec_dir / f"{ts}_{action_id}.json", payload)


def _require_role(action_id: str, actor_role: str) -> None:
    allowed = _ALLOWED_ROLES.get(action_id)
    if not allowed:
        raise ValueError(f"unsupported action_id: {action_id}")
    if actor_role not in allowed:
        raise PermissionError(f"RBAC_DENIED:{action_id}:{actor_role}")


def apply_tapeout_action(out_dir: Path, *, action_id: str, actor_role: str) -> None:
    _require_role(action_id, actor_role)
    authority_path = out_dir / "handoff_authority_record.json"
    transfer_path = out_dir / "handoff_transfer_record.json"
    receipt_path = out_dir / "handoff_receipt_record.json"
    inbox_path = out_dir / "tapeout_decision_inbox.json"

    authority = _load(authority_path)
    transfer = _load(transfer_path)
    receipt = _load(receipt_path)

    result = "DONE"
    notes = ""

    if action_id == "approve_handoff":
        authority["decision"] = "APPROVE"
        authority["approver_role"] = actor_role
        authority["timestamp"] = _iso_now()
        notes = "handoff approved"

    elif action_id == "approve_with_limitations":
        authority["decision"] = "APPROVE_WITH_LIMITATIONS"
        authority["approver_role"] = actor_role
        authority["timestamp"] = _iso_now()
        notes = "handoff approved with limitations"

    elif action_id == "hold_handoff":
        authority["decision"] = "HOLD"
        authority["approver_role"] = actor_role
        authority["timestamp"] = _iso_now()
        notes = "handoff on hold"

    elif action_id == "reject_handoff":
        authority["decision"] = "REJECT"
        authority["approver_role"] = actor_role
        authority["timestamp"] = _iso_now()
        notes = "handoff rejected"

    elif action_id == "request_more_evidence":
        authority["decision"] = "HOLD"
        authority["approver_role"] = actor_role
        authority["timestamp"] = _iso_now()
        notes = "requested more evidence"

    elif action_id == "record_transfer":
        if str(authority.get("decision", "")).upper() not in {"APPROVE", "APPROVE_WITH_LIMITATIONS"}:
            result = "BLOCKED"
            notes = "AUTHORITY_APPROVAL_REQUIRED"
        else:
            transfer["status"] = "TRANSFERRED"
            transfer["transferred_by"] = actor_role
            transfer["transferred_at"] = _iso_now()
            notes = "transfer recorded"

    elif action_id == "record_receipt":
        if str(transfer.get("status", "")).upper() != "TRANSFERRED":
            result = "BLOCKED"
            notes = "TRANSFER_REQUIRED"
        else:
            receipt["status"] = "RECEIPT_CONFIRMED"
            receipt["received_by"] = actor_role
            receipt["received_at"] = _iso_now()
            receipt["digest_match"] = True
            receipt["acceptance_claim"] = "RECEIVED_ONLY_NOT_TECHNICALLY_ACCEPTED"
            notes = "receipt recorded"

    _save(authority_path, authority)
    _save(transfer_path, transfer)
    _save(receipt_path, receipt)

    if inbox_path.exists():
        inbox = _load(inbox_path)
        items = inbox.get("items") or []
        completed = inbox.get("completed_items") or []
        for item in items:
            if str(item.get("action_id")) == action_id:
                completed.append({
                    "action_id": action_id,
                    "status": result,
                    "required_role": actor_role,
                    "reason": notes,
                })
        inbox["items"] = [item for item in items if str(item.get("action_id")) != action_id]
        inbox["pending_count"] = len(inbox["items"])
        inbox["completed_items"] = completed
        inbox["completed_count"] = len(completed)
        inbox["generated_at"] = _iso_now()
        _save(inbox_path, inbox)

    _write_action_record(out_dir, action_id=action_id, actor_role=actor_role, result=result, notes=notes)
