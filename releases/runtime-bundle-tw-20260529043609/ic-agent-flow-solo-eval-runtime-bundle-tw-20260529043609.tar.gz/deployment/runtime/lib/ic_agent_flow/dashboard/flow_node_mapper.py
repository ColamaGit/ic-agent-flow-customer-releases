from dataclasses import dataclass

from .flow_status_resolver import resolve_initial_flow_status


@dataclass(frozen=True)
class FlowNodeSpec:
    node_id: str
    prd_scope: str
    prd_ref: str
    node_group: str
    node_type: str
    label: str
    artifact_family: str


V17_FLOW_NODE_SPECS = [
    FlowNodeSpec(
        node_id="v1_0_upstream_truth",
        prd_scope="v1.0",
        prd_ref="PRD v1.0",
        node_group="v1_0_upstream_truth",
        node_type="flow_stage",
        label="Upstream Design Truth",
        artifact_family="upstream_truth",
    ),
    FlowNodeSpec(
        node_id="v0_9_eda_scenario",
        prd_scope="v0.9",
        prd_ref="PRD v0.9",
        node_group="v0_9_eda_scenario",
        node_type="flow_stage",
        label="Governed EDA Scenario",
        artifact_family="eda_evidence",
    ),
    FlowNodeSpec(
        node_id="v1_3_silicon_contract",
        prd_scope="v1.3",
        prd_ref="PRD v1.3",
        node_group="v1_3_silicon_contract",
        node_type="release_binder",
        label="Silicon Contract",
        artifact_family="silicon_contract",
    ),
    FlowNodeSpec(
        node_id="v1_5_site_activation",
        prd_scope="v1.5",
        prd_ref="PRD v1.5",
        node_group="v1_5_site_activation",
        node_type="activation_surface",
        label="Customer Site Activation",
        artifact_family="site_activation",
    ),
    FlowNodeSpec(
        node_id="v1_4_qa_gate",
        prd_scope="v1.4_gate",
        prd_ref="PRD v1.4",
        node_group="v1_4_qa_gate",
        node_type="gate_signal",
        label="QA Trust Gate",
        artifact_family="qa_trust",
    ),
    FlowNodeSpec(
        node_id="v1_6_distribution_gate",
        prd_scope="v1.6_gate",
        prd_ref="PRD v1.6",
        node_group="v1_6_distribution_gate",
        node_type="gate_signal",
        label="Controlled Distribution Gate",
        artifact_family="distribution_gate",
    ),
]


V18_FLOW_NODE_SPECS = [
    *V17_FLOW_NODE_SPECS,
    FlowNodeSpec(
        node_id="v1_8_live_console",
        prd_scope="v1.8",
        prd_ref="PRD v1.8",
        node_group="v1_8_live_console",
        node_type="authority_surface",
        label="Live Console Hardening",
        artifact_family="live_console",
    ),
]


def specs_for_dashboard_version(dashboard_version: str) -> list[FlowNodeSpec]:
    if dashboard_version == "v1_7":
        return V17_FLOW_NODE_SPECS
    if dashboard_version == "v1_8":
        return V18_FLOW_NODE_SPECS
    raise ValueError(f"unsupported dashboard_version: {dashboard_version}")


def map_flow_node(spec: FlowNodeSpec, *, chip_id: str, schema_version: str = "1.7.0") -> dict:
    base_uri = f"icaf://artifact/{spec.prd_scope}/{chip_id}/current/{spec.artifact_family}"
    return {
        "node_id": spec.node_id,
        "type": "flow_dashboard_node",
        "schema_version": schema_version,
        "prd_scope": spec.prd_scope,
        "prd_ref": spec.prd_ref,
        "node_type": spec.node_type,
        "node_group": spec.node_group,
        "label": spec.label,
        "status": resolve_initial_flow_status(spec.node_group),
        "source_of_truth": "derived_from_governed_artifacts",
        "truth_mutability": "read_only",
        "logical_artifact_refs": [f"{base_uri}/index.json"],
        "input_refs": [f"{base_uri}/inputs.json"],
        "output_refs": [f"{base_uri}/outputs.json"],
        "evidence_refs": [f"{base_uri}/evidence.json"],
        "decision_state": "none",
        "blocker_refs": [],
    }
