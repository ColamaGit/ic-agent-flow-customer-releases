from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


RECORD_FILENAMES = {
    "dashboard_action_request": "dashboard_action_request",
    "dashboard_action_authorization_record": "dashboard_action_authorization_record",
    "dashboard_action_audit_record": "dashboard_action_audit_record",
    "dashboard_action_result_record": "dashboard_action_result_record",
    "reentry_request_record": "reentry_request_record",
}

CONSOLE_ACTION_REF_PREFIX = "icaf://console-actions/"

PATH_LEAK_PATTERNS = (
    re.compile(r"/customer-home/"),
    re.compile(r"/customer-home/"),
    re.compile(r"[A-Za-z]:\\\\Users\\\\"),
    re.compile(r"\bpackage_ws/"),
    re.compile(r"\binternal-dev\b"),
    re.compile(r"\bsource_ref\b"),
)


def _iso_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def resolve_console_actions_dir(*, run_dir: Path | str, console_state_root: Path | str | None) -> Path:
    if console_state_root:
        return Path(console_state_root) / "governance" / "console_actions"
    return Path(run_dir) / "governance" / "console_actions"


def _console_action_record_ref(path: Path) -> str:
    return f"{CONSOLE_ACTION_REF_PREFIX}{path.name}"


def resolve_console_action_record_ref(record_ref: str, actions_dir: Path | str) -> Path:
    ref = str(record_ref).strip()
    if ref.startswith(CONSOLE_ACTION_REF_PREFIX):
        filename = ref.removeprefix(CONSOLE_ACTION_REF_PREFIX)
        if not filename or "/" in filename or "\\" in filename:
            raise ValueError(f"invalid_console_action_record_ref:{record_ref}")
        return Path(actions_dir) / filename
    return Path(ref)


def _write_json_append_only(path: Path, payload: dict[str, Any]) -> None:
    if path.exists():
        raise FileExistsError(f"append_only_record_exists:{path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def _load_index(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {
            "type": "action_chain_index",
            "schema_version": "1.8.0",
            "actions": [],
            "updated_at": _iso_now(),
        }
    return json.loads(path.read_text(encoding="utf-8"))


def append_console_action_records(
    *,
    run_dir: Path | str,
    action_id: str,
    records: dict[str, dict[str, Any]],
    console_state_root: Path | str | None,
) -> dict[str, Any]:
    if not action_id:
        raise ValueError("missing_action_id")

    actions_dir = resolve_console_actions_dir(run_dir=run_dir, console_state_root=console_state_root)
    actions_dir.mkdir(parents=True, exist_ok=True)

    written: dict[str, str] = {}
    for record_key, basename in RECORD_FILENAMES.items():
        payload = records.get(record_key)
        if payload is None:
            continue
        path = actions_dir / f"{basename}.{action_id}.json"
        _write_json_append_only(path, payload)
        written[record_key] = _console_action_record_ref(path)

    index_path = actions_dir / "action_chain_index.json"
    index = _load_index(index_path)
    if any(entry.get("action_id") == action_id for entry in index.get("actions", [])):
        raise FileExistsError(f"append_only_index_entry_exists:{action_id}")
    index.setdefault("actions", []).append(
        {
            "action_id": action_id,
            "records": written,
            "created_at": _iso_now(),
        }
    )
    index["updated_at"] = _iso_now()
    index_path.write_text(json.dumps(index, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    return {
        "actions_dir": "icaf://console-actions",
        "action_id": action_id,
        "records": written,
        "index_ref": f"{CONSOLE_ACTION_REF_PREFIX}{index_path.name}",
    }


def scan_console_action_records_for_path_leaks(actions_dir: Path | str) -> list[dict[str, str]]:
    root = Path(actions_dir)
    if not root.exists():
        return []
    leaks: list[dict[str, str]] = []
    for path in sorted(root.rglob("*.json")):
        text = path.read_text(encoding="utf-8")
        for pattern in PATH_LEAK_PATTERNS:
            if pattern.search(text):
                leaks.append({"path": path.as_posix(), "pattern": pattern.pattern})
    return leaks
