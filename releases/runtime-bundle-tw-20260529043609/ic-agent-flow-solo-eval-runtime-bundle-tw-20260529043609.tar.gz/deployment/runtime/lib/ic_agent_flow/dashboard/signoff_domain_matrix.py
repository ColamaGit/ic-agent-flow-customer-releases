from __future__ import annotations

from datetime import datetime, timezone


def _generated_at_from_date_time(date_time: str) -> str:
    try:
        dt = datetime.strptime(date_time, "%Y%m%d-%H%M%S").replace(tzinfo=timezone.utc)
        return dt.isoformat().replace("+00:00", "Z")
    except ValueError:
        return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def build_signoff_domain_matrix(*, chip_id: str, run_id: str, date_time: str) -> dict:
    return {
        "schema_version": "v1.13",
        "type": "signoff_domain_matrix",
        "chip_id": chip_id,
        "run_id": run_id,
        "date_time": date_time,
        "generated_at": _generated_at_from_date_time(date_time),
        "domains": [
            {
                "domain_id": "STA",
                "required_evidence": ["h5_opensta/normalized.sta.meta.json"],
                "accepted_tool_class": ["open_source_bounded", "commercial_signoff_tool"],
                "owner_role": "TIMING_SIGNOFF_OWNER",
                "closure_rule": "all_required_evidence_present_and_fresh",
                "waiver_policy": "formal_waiver_required",
                "freshness_rule": "must_match_current_execution",
                "blocker_policy": "missing_or_stale_blocks",
                "replay_requirement": "must_reconstructable_from_artifact_refs",
                "claim_class_allowed": ["BOUNDED_SIGNOFF_ASSIST"],
            },
            {
                "domain_id": "DRC",
                "required_evidence": ["h4_klayout/normalized.drc.meta.json"],
                "accepted_tool_class": ["open_source_bounded", "foundry_rule_deck", "commercial_signoff_tool"],
                "owner_role": "PHYSICAL_SIGNOFF_OWNER",
                "closure_rule": "all_required_evidence_present_and_fresh",
                "waiver_policy": "formal_waiver_required",
                "freshness_rule": "must_match_current_execution",
                "blocker_policy": "missing_or_stale_blocks",
                "replay_requirement": "must_reconstructable_from_artifact_refs",
                "claim_class_allowed": ["BOUNDED_SIGNOFF_ASSIST"],
            },
            {
                "domain_id": "CDC_LITE",
                "required_evidence": ["v3b_cdc_signoff_lite/normalized.cdc_signoff_lite.meta.json"],
                "accepted_tool_class": ["open_source_bounded"],
                "owner_role": "CDC_SIGNOFF_OWNER",
                "closure_rule": "artifact_present_with_non_signoff_claim_class",
                "waiver_policy": "formal_waiver_required",
                "freshness_rule": "must_match_current_execution",
                "blocker_policy": "overclaim_or_missing_blocks",
                "replay_requirement": "must_reconstructable_from_artifact_refs",
                "claim_class_allowed": ["NON_SIGNOFF_CDC_LITE"],
            },
        ],
    }


def build_stage_claim_boundary_record(*, chip_id: str, run_id: str, date_time: str) -> dict:
    return {
        "schema_version": "v1.13",
        "type": "stage_claim_boundary_record",
        "chip_id": chip_id,
        "run_id": run_id,
        "date_time": date_time,
        "generated_at": _generated_at_from_date_time(date_time),
        "stage": "S8_EQUIVALENCE",
        "display_status": "PASS",
        "claim_class": "PASS_WITH_BLACKBOX_LIMITATION",
        "allowed_claims": [
            "synthesis_netlist_matches_wrapper_observable_points",
        ],
        "blocked_claims": [
            "full_cpu_equivalence_proven",
            "full_chip_functional_equivalence_proven",
        ],
        "limitations": [
            "cortexm3ds_logic black-boxed",
            "behavioral memory unmatched on reference side",
        ],
    }


def build_stage_conditional_pass_record(*, chip_id: str, run_id: str, date_time: str) -> dict:
    return {
        "schema_version": "v1.13",
        "type": "stage_conditional_pass_record",
        "chip_id": chip_id,
        "run_id": run_id,
        "date_time": date_time,
        "generated_at": _generated_at_from_date_time(date_time),
        "stage": "S10_DRC",
        "verdict": "CONDITIONAL_PASS",
        "rules_checked": 2869,
        "rules_clean": 2796,
        "rules_violated": 73,
        "violation_classes": [
            {
                "rule": "M1.R.3 / M10.R.2",
                "count": "360 / 90",
                "class": "PDK_MAP",
                "status": "OPEN",
            },
            {
                "rule": "G.4 density",
                "count": "6502",
                "class": "EXPECTED_DEMO_LIMITATION",
                "status": "WAIVER_OR_DEMO_SCOPE_ONLY",
            },
        ],
        "allowed_claims": [
            "drc_reviewed_under_demo_constraints",
        ],
        "blocked_claims": [
            "drc_clean",
            "foundry_ready",
            "tapeout_ready",
        ],
    }


def build_flow_completion_verdict_record(*, chip_id: str, run_id: str, date_time: str) -> dict:
    return {
        "schema_version": "v1.13",
        "type": "flow_completion_verdict_record",
        "chip_id": chip_id,
        "run_id": run_id,
        "date_time": date_time,
        "generated_at": _generated_at_from_date_time(date_time),
        "flow_name": "cortex_m3_mcu_spec_to_gds_demo",
        "execution_verdict": "PASS_WITH_CONDITIONS",
        "completed_stages": 10,
        "total_stages": 12,
        "blocking_conditions": [
            "drc_conditional_pass_with_73_violated_rule_classes",
            "cpu_logic_black_boxed",
            "area_power_exclude_major_macro_scope",
        ],
        "allowed_public_claim": "demo_spec_to_gds_flow_executed",
        "blocked_public_claims": [
            "production_signoff_complete",
            "tapeout_ready",
            "silicon_proven",
        ],
    }
