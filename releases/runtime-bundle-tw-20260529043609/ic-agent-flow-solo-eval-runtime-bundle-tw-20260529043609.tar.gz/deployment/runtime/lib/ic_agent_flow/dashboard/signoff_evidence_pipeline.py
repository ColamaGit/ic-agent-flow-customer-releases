from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import re


def _generated_at_from_date_time(date_time: str) -> str:
    try:
        dt = datetime.strptime(date_time, "%Y%m%d-%H%M%S").replace(tzinfo=timezone.utc)
        return dt.isoformat().replace("+00:00", "Z")
    except ValueError:
        return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _classify_tool_source(path: str) -> str:
    p = path.lower()
    if "external_signoff_manifest" in p:
        return "customer_supplied_report"
    if "klayout" in p or "drc" in p:
        return "foundry_rule_deck"
    if "opensta" in p or "yosys" in p or "cdc_signoff_lite" in p:
        return "open_source_bounded"
    return "manual_review"


def build_signoff_phase2_objects(
    *,
    chip_id: str,
    run_id: str,
    date_time: str,
    input_root: Path,
    signoff_domain_matrix: dict,
) -> dict:
    generated_at = _generated_at_from_date_time(date_time)
    entries = []
    missing = []
    classifications = []

    for domain in signoff_domain_matrix.get("domains", []):
        domain_id = str(domain.get("domain_id", "UNKNOWN"))
        for rel_path in domain.get("required_evidence", []):
            rel = str(rel_path)
            expected = input_root / rel
            if expected.exists():
                exists = True
            else:
                segs = rel.split("/")
                if segs:
                    stage = segs[0]
                    suffix = "/".join(segs[1:])
                    pattern = re.compile(rf"^\d+_{re.escape(stage)}$")
                    matched = [p for p in input_root.iterdir() if p.is_dir() and pattern.match(p.name)]
                    exists = any((p / suffix).exists() for p in matched) if suffix else bool(matched)
                else:
                    exists = False
            status = "PRESENT" if exists else "MISSING"
            entries.append(
                {
                    "domain_id": domain_id,
                    "evidence_ref": rel,
                    "status": status,
                }
            )
            classifications.append(
                {
                    "domain_id": domain_id,
                    "evidence_ref": rel,
                    "tool_source_class": _classify_tool_source(rel),
                }
            )
            if not exists:
                missing.append({"domain_id": domain_id, "evidence_ref": rel})

    total = len(entries)
    present = sum(1 for row in entries if row["status"] == "PRESENT")
    ratio = round((present / total), 4) if total else 0.0
    status = "PASS" if not missing else "BLOCKED"

    return {
        "signoff_evidence_manifest": {
            "schema_version": "v1.13",
            "type": "signoff_evidence_manifest",
            "chip_id": chip_id,
            "run_id": run_id,
            "date_time": date_time,
            "generated_at": generated_at,
            "entries": entries,
        },
        "tool_source_classification": {
            "schema_version": "v1.13",
            "type": "tool_source_classification",
            "chip_id": chip_id,
            "run_id": run_id,
            "date_time": date_time,
            "generated_at": generated_at,
            "records": classifications,
        },
        "evidence_classification_report": {
            "schema_version": "v1.13",
            "type": "evidence_classification_report",
            "chip_id": chip_id,
            "run_id": run_id,
            "date_time": date_time,
            "generated_at": generated_at,
            "required_evidence_total": total,
            "required_evidence_present": present,
            "coverage_ratio": ratio,
            "status": status,
        },
        "signoff_gap_record": {
            "schema_version": "v1.13",
            "type": "signoff_gap_record",
            "chip_id": chip_id,
            "run_id": run_id,
            "date_time": date_time,
            "generated_at": generated_at,
            "status": status,
            "missing_required_evidence_count": len(missing),
            "missing_required_evidence": missing,
        },
    }
