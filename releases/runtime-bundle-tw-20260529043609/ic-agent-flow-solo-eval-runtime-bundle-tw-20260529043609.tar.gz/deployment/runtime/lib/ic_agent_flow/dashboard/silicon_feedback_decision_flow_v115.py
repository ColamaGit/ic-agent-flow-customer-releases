from __future__ import annotations

from datetime import datetime, timezone


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def build_v115_decision_inbox(*, run_scope: dict, objects: dict) -> dict:
    validation = objects.get("silicon_validation_result", {})
    eco = objects.get("eco_decision_record", {})
    claim = objects.get("silicon_proven_claim_record", {})
    items: list[dict] = []
    completed_items: list[dict] = []

    if str(validation.get("overall_verdict", "")).upper() != "PASS":
        items.append(
            {
                "action_id": "acknowledge_bringup_failure",
                "status": "PENDING",
                "required_role": "BRINGUP_OWNER",
                "reason": "silicon_validation_result not PASS",
            }
        )
    else:
        completed_items.append(
            {
                "action_id": "acknowledge_bringup_failure",
                "status": "DONE",
                "required_role": "BRINGUP_OWNER",
                "reason": "silicon_validation_result PASS",
            }
        )

    if str(eco.get("decision", "")).upper() == "HOLD":
        items.append(
            {
                "action_id": "approve_or_reject_eco",
                "status": "PENDING",
                "required_role": "ECO_AUTHORITY",
                "reason": "eco_decision_record still HOLD",
            }
        )
    else:
        completed_items.append(
            {
                "action_id": "approve_or_reject_eco",
                "status": "DONE",
                "required_role": "ECO_AUTHORITY",
                "reason": f"eco_decision_record is {str(eco.get('decision', 'UNKNOWN')).upper()}",
            }
        )

    if str(claim.get("status", "")).upper() != "SILICON_PROVEN_BOUNDED":
        items.append(
            {
                "action_id": "finalize_silicon_proven_bounded",
                "status": "PENDING",
                "required_role": "RELEASE_AUTHORITY",
                "reason": "silicon_proven_claim_record not finalized",
            }
        )
    else:
        completed_items.append(
            {
                "action_id": "finalize_silicon_proven_bounded",
                "status": "DONE",
                "required_role": "RELEASE_AUTHORITY",
                "reason": "silicon_proven_claim_record finalized",
            }
        )

    return {
        "schema_version": "v1.15",
        "type": "silicon_feedback_decision_inbox",
        "generated_at": _now_iso(),
        "scope": run_scope,
        "items": items,
        "pending_count": len(items),
        "completed_items": completed_items,
        "completed_count": len(completed_items),
    }
