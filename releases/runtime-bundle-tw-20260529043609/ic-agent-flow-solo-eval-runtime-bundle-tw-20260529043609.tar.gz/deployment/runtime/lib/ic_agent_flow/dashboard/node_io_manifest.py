from pathlib import Path


V10_INPUTS = {
    "requirement_item": "v1.0/specs/requirement_item.json",
    "design_spec": "v1.0/specs/design_spec.json",
    "spec_completeness_report": "v1.0/specs/spec_completeness_report.json",
    "architecture_graph": "v1.0/architecture/architecture_graph.json",
    "graph_validation_result": "v1.0/architecture/graph_validation_result.json",
    "graph_freeze_record": "v1.0/architecture/graph_freeze_record.json",
    "graph_to_generation_plan": "v1.0/architecture/graph_to_generation_plan.json",
}

V09_INPUTS = {
    "execution_run": "v0.9/execution/execution_run.json",
    "raw_artifacts": "v0.9/raw/raw_artifacts.json",
    "normalized_artifacts": "v0.9/normalized/normalized_artifacts.json",
    "evidence_bundle": "v0.9/evidence/evidence_bundle.json",
    "readiness_report": "v0.9/readiness/readiness_report.v0.2.md",
    "review_package_input_set": "v0.9/review/review_package_input_set.json",
    "re_entry_marker": "v0.9/reentry/re_entry_marker.json",
}

NODE_INPUTS = {
    "v1_0_upstream_truth": V10_INPUTS,
    "v0_9_eda_scenario": V09_INPUTS,
    "v1_8_live_console": {
        "console_session_record": "dashboard/v1.8/objects/console_session_record.json",
        "console_role_binding_record": "dashboard/v1.8/objects/console_role_binding_record.json",
        "console_route_access_record": "dashboard/v1.8/objects/console_route_access_record.json",
        "dashboard_selector_state_record": "dashboard/v1.8/objects/dashboard_selector_state_record.json",
        "dashboard_action_request": "dashboard/v1.8/objects/dashboard_action_request.json",
        "dashboard_action_authorization_record": "dashboard/v1.8/objects/dashboard_action_authorization_record.json",
        "dashboard_action_audit_record": "dashboard/v1.8/objects/dashboard_action_audit_record.json",
        "dashboard_action_result_record": "dashboard/v1.8/objects/dashboard_action_result_record.json",
        "dashboard_replay_trace": "dashboard/v1.8/objects/dashboard_replay_trace.json",
        "dashboard_fail_closed_record": "dashboard/v1.8/objects/dashboard_fail_closed_record.json",
    },
}


def _logical_uri(node: dict, artifact_family: str, relative_path: str) -> str:
    return (
        f"icaf://artifact/{node['prd_scope']}/"
        f"{node['node_id']}/current/{artifact_family}/{relative_path}"
    )


def _artifact_ref(node: dict, artifact_family: str, relative_path: str) -> dict:
    return {
        "logical_uri": _logical_uri(node, artifact_family, relative_path),
        "artifact_family": artifact_family,
    }


def build_node_io_for_node(*, node: dict, artifact_root: Path, downstream_consumers: list[str]) -> dict:
    required_map = NODE_INPUTS.get(node["node_id"], {})
    resolved_inputs = []
    missing_inputs = []

    for artifact_family, relative_path in required_map.items():
        if (Path(artifact_root) / relative_path).exists():
            resolved_inputs.append(_artifact_ref(node, artifact_family, relative_path))
        else:
            missing_inputs.append(artifact_family)

    produced_outputs = [
        _artifact_ref(node, "node_io_manifest", f"{node['node_id']}.flow_node_io_manifest.json")
    ]
    evidence_refs = list(resolved_inputs)
    artifact_refs = [*resolved_inputs, *produced_outputs]
    verdict = "blocked" if missing_inputs else "pass"

    return {
        "manifest_id": f"node-io-{node['node_id']}",
        "type": "flow_node_io_manifest",
        "schema_version": "1.7.0",
        "node_id": node["node_id"],
        "required_inputs": list(required_map.keys()),
        "resolved_inputs": resolved_inputs,
        "missing_inputs": missing_inputs,
        "produced_outputs": produced_outputs,
        "evidence_refs": evidence_refs,
        "decision_refs": [],
        "artifact_refs": artifact_refs,
        "downstream_consumers": downstream_consumers,
        "blocker_refs": [f"missing_input:{item}" for item in missing_inputs],
        "verdict": verdict,
    }


def build_node_io_manifest(*, flow_registry: dict, artifact_root: Path) -> dict:
    dashboard_version = flow_registry.get("dashboard_version", "v1_7")
    schema_version = "1.8.0" if dashboard_version == "v1_8" else "1.7.0"
    nodes = flow_registry["nodes"]
    node_manifests = []
    for index, node in enumerate(nodes):
        downstream_consumers = [nodes[index + 1]["node_id"]] if index + 1 < len(nodes) else []
        node_manifests.append(
            build_node_io_for_node(
                node=node,
                artifact_root=Path(artifact_root),
                downstream_consumers=downstream_consumers,
            )
        )

    overall_verdict = (
        "blocked"
        if any(item["verdict"] == "blocked" for item in node_manifests)
        else "pass"
    )
    return {
        "manifest_id": f"flow-node-io-{flow_registry['chip_id']}-{flow_registry['package_mode']}",
        "type": "dashboard_flow_node_io_manifest",
        "schema_version": schema_version,
        "dashboard_version": dashboard_version,
        "flow_registry_ref": flow_registry["registry_id"],
        "chip_id": flow_registry["chip_id"],
        "package_mode": flow_registry["package_mode"],
        "node_manifests": node_manifests,
        "overall_verdict": overall_verdict,
    }
