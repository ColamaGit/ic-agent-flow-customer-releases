from __future__ import annotations

from datetime import datetime, timezone


def _generated_at_from_date_time(date_time: str) -> str:
    try:
        dt = datetime.strptime(date_time, "%Y%m%d-%H%M%S").replace(tzinfo=timezone.utc)
        return dt.isoformat().replace("+00:00", "Z")
    except ValueError:
        return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def finalize_phase5_with_contract_binding(
    *,
    chip_id: str,
    run_id: str,
    date_time: str,
    draft_status: str,
    silicon_contract_binding_valid: bool,
    silicon_contract_status: str,
    stage_conditional_pass_status: str = "NOT_AVAILABLE",
    stage_claim_class: str = "NOT_AVAILABLE",
    ai_artifact_admission_record: dict | None = None,
) -> dict:
    reasons: list[str] = []
    conditional_status = stage_conditional_pass_status.upper()
    claim_class = stage_claim_class.upper()
    if not silicon_contract_binding_valid:
        final_status = "BLOCKED"
        reasons.append("SILICON_CONTRACT_BINDING_REQUIRED")
    elif conditional_status == "CONDITIONAL_PASS" or claim_class == "PASS_WITH_BLACKBOX_LIMITATION":
        final_status = "BLOCKED"
        reasons.append("CONDITIONAL_STAGE_NOT_SIGNOFF_READY")
    elif draft_status == "BLOCKED" and silicon_contract_status == "BOUND_PASS":
        final_status = "INVALID"
        reasons.append("PARALLEL_TRUTH_CONFLICT")
    elif draft_status == "READY_FOR_TAPEOUT_PACKAGE_ASSEMBLY_CANDIDATE":
        final_status = "READY_FOR_TAPEOUT_PACKAGE_ASSEMBLY"
    else:
        final_status = "BLOCKED"
        reasons.append("DRAFT_NOT_READY")

    admission_verdict = str((ai_artifact_admission_record or {}).get("admission_verdict", "NOT_AVAILABLE")).upper()
    admission_authority_ref = (ai_artifact_admission_record or {}).get("human_authority_ref")
    if admission_verdict == "AI_ARTIFACT_ADMISSION_BLOCKED":
        final_status = "BLOCKED"
        reasons.append("AI_ARTIFACT_ADMISSION_BLOCKED")
    elif admission_verdict == "AI_ARTIFACT_ADMISSION_NOT_APPLICABLE":
        final_status = "BLOCKED"
        reasons.append("AI_ARTIFACT_ADMISSION_NOT_APPLICABLE")
    elif admission_verdict == "AI_ARTIFACT_ADMISSION_WAIVED_WITH_AUTHORITY" and not admission_authority_ref:
        final_status = "BLOCKED"
        reasons.append("AI_ARTIFACT_ADMISSION_WAIVER_MISSING_AUTHORITY")

    generated_at = _generated_at_from_date_time(date_time)
    return {
        "final_signoff_closure_report": {
            "schema_version": "v1.13",
            "type": "signoff_closure_report",
            "chip_id": chip_id,
            "run_id": run_id,
            "date_time": date_time,
            "generated_at": generated_at,
            "status": final_status,
            "blocking_reasons": reasons,
            "is_draft": False,
        },
        "silicon_contract_v113_binding_record": {
            "schema_version": "v1.13",
            "type": "silicon_contract_v113_binding_record",
            "chip_id": chip_id,
            "run_id": run_id,
            "date_time": date_time,
            "generated_at": generated_at,
            "binding_valid": silicon_contract_binding_valid,
            "contract_status": silicon_contract_status,
        },
        "final_tapeout_readiness_record": {
            "schema_version": "v1.13",
            "type": "tapeout_readiness_record",
            "chip_id": chip_id,
            "run_id": run_id,
            "date_time": date_time,
            "generated_at": generated_at,
            "status": final_status,
            "authoritative": silicon_contract_binding_valid and final_status == "READY_FOR_TAPEOUT_PACKAGE_ASSEMBLY",
            "blocking_reasons": reasons,
        },
    }
