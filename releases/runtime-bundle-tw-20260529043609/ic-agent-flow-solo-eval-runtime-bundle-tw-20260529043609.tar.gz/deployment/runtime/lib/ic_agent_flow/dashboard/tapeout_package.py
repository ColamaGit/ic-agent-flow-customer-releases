from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

_ALLOWED_PROFILES = {
    "MPW_SHUTTLE",
    "INTERNAL_PROTOTYPE",
    "CUSTOMER_REVIEW_ONLY",
    "FOUNDRY_PRODUCTION",
}
_FORBIDDEN_PATH_TOKENS = [
    "/customer-home/",
    "/tmp/",
    "repo_root/package_ws/",
    "internal-redacted/",
    "source_ref",
    "prompt/context strategy path",
]


def _iso_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _iso_from_execution(execution: str) -> str:
    if len(execution) == 15 and execution[8] == "-":
        return f"{execution[:4]}-{execution[4:6]}-{execution[6:8]}T{execution[9:11]}:{execution[11:13]}:{execution[13:15]}Z"
    return _iso_now()


def _sha256_hex(content: str) -> str:
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


def _collect_files(input_root: Path) -> list[Path]:
    return [p for p in input_root.rglob("*") if p.is_file()]


def _rel(root: Path, node: Path) -> str:
    return node.relative_to(root).as_posix()


def _artifact_type_for_path(rel: str) -> str:
    n = rel.lower()
    if "gds" in n:
        return "GDSII"
    if "oasis" in n:
        return "OASIS"
    if "def" in n:
        return "DEF"
    if "lef" in n:
        return "LEF"
    if "sdf" in n:
        return "SDF"
    if "sdc" in n:
        return "SDC"
    if "drc" in n:
        return "DRC_REPORT"
    if "lvs" in n:
        return "LVS_REPORT"
    if "sta" in n:
        return "STA_REPORT"
    if "netlist" in n:
        return "GATE_LEVEL_NETLIST"
    return "SUPPORT_ARTIFACT"


def _classification_for_type(artifact_type: str) -> str:
    if artifact_type in {"GDSII", "OASIS", "DEF", "LEF", "GATE_LEVEL_NETLIST", "SDF", "SDC"}:
        return "FOUNDRY_REQUIRED"
    if artifact_type in {"DRC_REPORT", "LVS_REPORT", "STA_REPORT"}:
        return "CUSTOMER_REVIEWABLE"
    return "INTERNAL_ONLY"


def _visibility_for_classification(classification: str) -> list[str]:
    if classification == "FOUNDRY_REQUIRED":
        return ["INTERNAL_ARCHIVE_VIEW", "FOUNDRY_HANDOFF_VIEW"]
    if classification == "CUSTOMER_REVIEWABLE":
        return ["INTERNAL_ARCHIVE_VIEW", "FOUNDRY_HANDOFF_VIEW", "CUSTOMER_REVIEW_VIEW"]
    return ["INTERNAL_ARCHIVE_VIEW"]


def _required_artifact_types_for_profile(profile: str) -> tuple[set[str], list[set[str]]]:
    if profile == "INTERNAL_PROTOTYPE":
        return {"GATE_LEVEL_NETLIST", "SDF", "SDC"}, []
    if profile == "CUSTOMER_REVIEW_ONLY":
        return {"DRC_REPORT", "LVS_REPORT", "STA_REPORT"}, []
    # MPW_SHUTTLE / FOUNDRY_PRODUCTION
    return {"DRC_REPORT", "LVS_REPORT", "STA_REPORT"}, [{"GDSII", "OASIS"}]


def _scan_path_leaks(paths: Iterable[str]) -> list[str]:
    findings: list[str] = []
    for rel in paths:
        for token in _FORBIDDEN_PATH_TOKENS:
            if token in rel:
                findings.append(f"{token}::{rel}")
    return findings


def build_tapeout_package_objects(
    *,
    chip_id: str,
    run_id: str,
    execution: str,
    input_root: Path,
    handoff_profile: str = "MPW_SHUTTLE",
    final_readiness: dict | None = None,
    silicon_contract_binding: dict | None = None,
    ai_artifact_admission_record: dict | None = None,
) -> dict:
    profile = handoff_profile if handoff_profile in _ALLOWED_PROFILES else "MPW_SHUTTLE"
    final_readiness = final_readiness or {}
    silicon_contract_binding = silicon_contract_binding or {}

    files = _collect_files(input_root)
    artifact_records: list[dict] = []
    for p in files:
        rel = _rel(input_root, p)
        artifact_type = _artifact_type_for_path(rel)
        classification = _classification_for_type(artifact_type)
        visibility = _visibility_for_classification(classification)
        artifact_records.append(
            {
                "artifact_id": rel.replace("/", "__"),
                "artifact_type": artifact_type,
                "relative_path": rel,
                "classification": classification,
                "view_visibility": visibility,
                "source_run_ref": f"artifacts/production-runs/{chip_id}/{run_id}/{execution}",
                "digest": hashlib.sha256(p.read_bytes()).hexdigest(),
                "hash_algorithm": "sha256",
                "size": p.stat().st_size,
                "generated_at": _iso_from_execution(execution),
                "producer": "governance_pipeline_runner",
                "freeze_status": "DRAFT",
                "required_by_profile": profile in {"MPW_SHUTTLE", "INTERNAL_PROTOTYPE"},
            }
        )

    required_types, required_any_of = _required_artifact_types_for_profile(profile)
    present_types = {str(row["artifact_type"]) for row in artifact_records}
    missing_required_types = sorted(required_types - present_types)
    for any_group in required_any_of:
        if not any_group.intersection(present_types):
            missing_required_types.append("ONE_OF(" + "|".join(sorted(any_group)) + ")")

    path_leaks = _scan_path_leaks([row["relative_path"] for row in artifact_records])
    external_manifest_leak = len(path_leaks) > 0
    readiness_status = str(final_readiness.get("status", "NOT_AVAILABLE")).upper()
    binding_valid = bool(silicon_contract_binding.get("binding_valid", False))
    admission = ai_artifact_admission_record or {}
    admission_verdict = str(admission.get("admission_verdict", "NOT_AVAILABLE")).upper()
    admission_authority_ref = admission.get("human_authority_ref")
    blocking_reasons: list[str] = []

    if admission_verdict == "AI_ARTIFACT_ADMISSION_BLOCKED":
        package_status = "PACKAGE_BLOCKED"
        blocking_reasons.append("AI_ARTIFACT_ADMISSION_BLOCKED")
    elif admission_verdict == "AI_ARTIFACT_ADMISSION_NOT_APPLICABLE":
        package_status = "PACKAGE_BLOCKED"
        blocking_reasons.append("AI_ARTIFACT_ADMISSION_NOT_APPLICABLE")
    elif admission_verdict == "AI_ARTIFACT_ADMISSION_WAIVED_WITH_AUTHORITY" and not admission_authority_ref:
        package_status = "PACKAGE_BLOCKED"
        blocking_reasons.append("AI_ARTIFACT_ADMISSION_WAIVER_MISSING_AUTHORITY")
    elif readiness_status in {"BLOCKED", "INVALID", "NOT_AVAILABLE"}:
        package_status = "PACKAGE_BLOCKED"
        blocking_reasons.append(f"READINESS_{readiness_status}")
    elif missing_required_types:
        package_status = "PACKAGE_BLOCKED"
        blocking_reasons.append("MISSING_REQUIRED_ARTIFACT_TYPES")
    elif not binding_valid:
        package_status = "PACKAGE_INVALID"
        blocking_reasons.append("SILICON_CONTRACT_BINDING_INVALID")
    elif external_manifest_leak:
        package_status = "PACKAGE_INVALID"
        blocking_reasons.append("PATH_LEAK_DETECTED")
    else:
        package_status = "PACKAGE_READY"

    package_id = f"PKG-{chip_id}-{run_id}-{execution}"
    package_digest = _sha256_hex(json.dumps(artifact_records, sort_keys=True, ensure_ascii=False))

    tapeout_package_manifest = {
        "schema_version": "v1.14",
        "type": "tapeout_package_manifest",
        "chip_id": chip_id,
        "run_id": run_id,
        "execution": execution,
        "package_id": package_id,
        "handoff_profile": profile,
        "status": package_status,
        "blocking_reasons": blocking_reasons,
        "missing_required_artifact_types": missing_required_types,
        "v13_readiness_status": readiness_status,
        "silicon_contract_binding_status": str(silicon_contract_binding.get("contract_status", "NOT_AVAILABLE")),
        "artifact_count": len(artifact_records),
        "manifest_generated_at": _iso_now(),
    }

    foundry_handoff_manifest = {
        "schema_version": "v1.14",
        "type": "foundry_handoff_manifest",
        "package_id": package_id,
        "view": "FOUNDRY_HANDOFF_VIEW",
        "handoff_profile": profile,
        "status": "BLOCKED" if package_status not in {"PACKAGE_READY", "PACKAGE_READY_WITH_WAIVERS", "PACKAGE_READY_WITH_LIMITATIONS"} else "READY",
        "artifact_refs": [r["relative_path"] for r in artifact_records if "FOUNDRY_HANDOFF_VIEW" in r["view_visibility"]],
        "generated_at": _iso_now(),
    }

    deliverable_artifact_manifest = {
        "schema_version": "v1.14",
        "type": "deliverable_artifact_manifest",
        "package_id": package_id,
        "records": artifact_records,
        "generated_at": _iso_now(),
    }

    package_integrity_manifest = {
        "schema_version": "v1.14",
        "type": "package_integrity_manifest",
        "package_id": package_id,
        "package_digest": package_digest,
        "hash_algorithm": "sha256",
        "artifact_hashes": [{"artifact_id": r["artifact_id"], "digest": r["digest"]} for r in artifact_records],
        "freeze_status": "DRAFT",
        "integrity_verdict": "PASS" if package_status != "PACKAGE_INVALID" else "BLOCKED",
        "generated_at": _iso_now(),
    }

    package_freeze_record = {
        "schema_version": "v1.14",
        "type": "package_freeze_record",
        "package_id": package_id,
        "freeze_status": "FROZEN",
        "frozen_at": _iso_now(),
        "frozen_by": "system.pipeline",
        "digest": package_digest,
    }

    package_delta_record = {
        "schema_version": "v1.14",
        "type": "package_delta_record",
        "package_id": package_id,
        "status": "NO_DELTA",
        "delta_items": [],
        "generated_at": _iso_now(),
    }

    internal_archive_manifest = {
        "schema_version": "v1.14",
        "type": "internal_archive_manifest",
        "package_id": package_id,
        "artifact_refs": [r["relative_path"] for r in artifact_records],
        "generated_at": _iso_now(),
    }
    foundry_safe_manifest = {
        "schema_version": "v1.14",
        "type": "foundry_safe_manifest",
        "package_id": package_id,
        "artifact_refs": [r["relative_path"] for r in artifact_records if "FOUNDRY_HANDOFF_VIEW" in r["view_visibility"]],
        "path_leak_findings": path_leaks,
        "generated_at": _iso_now(),
    }
    customer_review_manifest = {
        "schema_version": "v1.14",
        "type": "customer_review_manifest",
        "package_id": package_id,
        "artifact_refs": [r["relative_path"] for r in artifact_records if "CUSTOMER_REVIEW_VIEW" in r["view_visibility"]],
        "path_leak_findings": path_leaks,
        "generated_at": _iso_now(),
    }

    handoff_authority_record = {
        "schema_version": "v1.14",
        "type": "handoff_authority_record",
        "package_id": package_id,
        "decision": "PENDING",
        "approver_role": "TAPEOUT_AUTHORITY",
        "reviewed_manifest_refs": ["dashboard_objects/tapeout_package_manifest.json"],
        "timestamp": _iso_now(),
    }
    handoff_transfer_record = {
        "schema_version": "v1.14",
        "type": "handoff_transfer_record",
        "package_id": package_id,
        "status": "PENDING",
        "transfer_method": "manual_upload",
        "recipient": "shuttle",
        "package_digest": package_digest,
        "transferred_at": None,
    }
    handoff_receipt_record = {
        "schema_version": "v1.14",
        "type": "handoff_receipt_record",
        "package_id": package_id,
        "status": "PENDING",
        "acceptance_claim": "RECEIVED_ONLY_NOT_TECHNICALLY_ACCEPTED",
        "digest_match": None,
        "received_at": None,
    }

    handoff_readiness_report = {
        "schema_version": "v1.14",
        "type": "handoff_readiness_report",
        "package_id": package_id,
        "status": package_status,
        "missing_required_artifacts": [],
        "missing_required_artifact_types": missing_required_types,
        "path_leak_findings": path_leaks,
        "generated_at": _iso_now(),
    }
    handoff_profile_record = {
        "schema_version": "v1.14",
        "type": "handoff_profile_record",
        "profile_id": profile,
        "profile_class": profile,
        "required_artifacts": sorted(required_types),
        "acceptance_checklist": [
            "required_artifacts_present",
            "path_leak_scan_pass",
            "integrity_manifest_present",
            "authority_record_present",
        ],
        "owner": "tapeout_package_owner",
    }
    foundry_requirement_checklist = {
        "schema_version": "v1.14",
        "type": "foundry_requirement_checklist",
        "profile_id": profile,
        "items": [
            {
                "item_id": "required_artifacts_present",
                "required": True,
                "status": "PASS" if not missing_required_types else "BLOCKED",
            },
            {
                "item_id": "path_leak_scan_pass",
                "required": True,
                "status": "PASS" if not path_leaks else "BLOCKED",
            },
            {
                "item_id": "binding_valid",
                "required": True,
                "status": "PASS" if binding_valid else "BLOCKED",
            },
        ],
        "status": "PASS" if package_status == "PACKAGE_READY" else "BLOCKED",
    }

    inbox_items = []
    completed_items = []
    if handoff_authority_record["decision"] == "PENDING":
        inbox_items.append({
            "action_id": "approve_handoff",
            "status": "PENDING",
            "required_role": "TAPEOUT_AUTHORITY",
            "reason": f"package_status={package_status}",
        })
    else:
        completed_items.append({
            "action_id": "approve_handoff",
            "status": "DONE",
            "required_role": "TAPEOUT_AUTHORITY",
            "reason": "handoff_authority_record approved",
        })

    inbox_items.append({
        "action_id": "record_transfer",
        "status": "PENDING",
        "required_role": "RELEASE_OPERATOR",
        "reason": "handoff_transfer_record pending",
    })
    inbox_items.append({
        "action_id": "record_receipt",
        "status": "PENDING",
        "required_role": "RELEASE_OPERATOR",
        "reason": "handoff_receipt_record pending",
    })

    tapeout_decision_inbox = {
        "schema_version": "v1.14",
        "type": "tapeout_decision_inbox",
        "scope": {
            "chip_id": chip_id,
            "run_id": run_id,
            "execution": execution,
        },
        "items": inbox_items,
        "pending_count": len(inbox_items),
        "completed_items": completed_items,
        "completed_count": len(completed_items),
        "generated_at": _iso_now(),
    }

    return {
        "tapeout_package_manifest": tapeout_package_manifest,
        "foundry_handoff_manifest": foundry_handoff_manifest,
        "deliverable_artifact_manifest": deliverable_artifact_manifest,
        "package_integrity_manifest": package_integrity_manifest,
        "package_freeze_record": package_freeze_record,
        "package_delta_record": package_delta_record,
        "internal_archive_manifest": internal_archive_manifest,
        "foundry_safe_manifest": foundry_safe_manifest,
        "customer_review_manifest": customer_review_manifest,
        "handoff_authority_record": handoff_authority_record,
        "handoff_transfer_record": handoff_transfer_record,
        "handoff_receipt_record": handoff_receipt_record,
        "handoff_readiness_report": handoff_readiness_report,
        "handoff_profile_record": handoff_profile_record,
        "foundry_requirement_checklist": foundry_requirement_checklist,
        "tapeout_decision_inbox": tapeout_decision_inbox,
        "path_leak_scan_report": {
            "schema_version": "v1.14",
            "type": "path_leak_scan_report",
            "scope": "external_views",
            "status": "BLOCKED" if external_manifest_leak else "PASS",
            "findings": path_leaks,
            "generated_at": _iso_now(),
        },
    }


def build_tapeout_readiness_summary_markdown(*, chip_id: str, run_id: str, execution: str, objects: dict) -> str:
    package = objects.get("tapeout_package_manifest", {})
    authority = objects.get("handoff_authority_record", {})
    transfer = objects.get("handoff_transfer_record", {})
    receipt = objects.get("handoff_receipt_record", {})
    integrity = objects.get("package_integrity_manifest", {})
    leaks = objects.get("path_leak_scan_report", {}).get("findings", [])
    lines = [
        "# Tapeout Package Summary",
        "",
        f"- chip_id: `{chip_id}`",
        f"- run_id: `{run_id}`",
        f"- execution: `{execution}`",
        "",
        "## Package Verdict",
        "",
        f"- status: `{package.get('status', 'NOT_AVAILABLE')}`",
        f"- handoff_profile: `{package.get('handoff_profile', 'NOT_AVAILABLE')}`",
        f"- artifact_count: `{package.get('artifact_count', 0)}`",
        f"- integrity_verdict: `{integrity.get('integrity_verdict', 'NOT_AVAILABLE')}`",
        "",
        "## Handoff Chain",
        "",
        f"- authority_decision: `{authority.get('decision', 'NOT_AVAILABLE')}`",
        f"- transfer_status: `{transfer.get('status', 'NOT_AVAILABLE')}`",
        f"- receipt_status: `{receipt.get('status', 'NOT_AVAILABLE')}`",
        "",
        "## External Path Leak",
        "",
        f"- findings_count: `{len(leaks)}`",
    ]
    if leaks:
        lines.append("- findings:")
        lines.extend([f"  - `{row}`" for row in leaks[:20]])
    return "\n".join(lines) + "\n"
