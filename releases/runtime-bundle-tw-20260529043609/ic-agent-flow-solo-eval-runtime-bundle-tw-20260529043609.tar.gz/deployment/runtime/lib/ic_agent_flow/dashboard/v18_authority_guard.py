from datetime import datetime, timedelta, timezone


def evaluate_declare_release_ready_precheck(
    *,
    gate_verdicts: dict[str, str],
    authority_closure_complete: bool,
    replay_chain_integrity: str,
) -> tuple[bool, list[str]]:
    policy_flags: list[str] = []
    blocked = {"blocked", "failed", "not_run"}
    if any(verdict in blocked for verdict in gate_verdicts.values()):
        policy_flags.append("precheck_gate_blocked")
    if not authority_closure_complete:
        policy_flags.append("authority_closure_incomplete")
    if replay_chain_integrity != "COMPLETE":
        policy_flags.append("replay_chain_incomplete")
    return (len(policy_flags) == 0, policy_flags)


def is_session_stale(*, created_at: str, ttl_minutes: int = 30, now: datetime | None = None) -> bool:
    now_ts = now or datetime.now(timezone.utc)
    created_ts = datetime.fromisoformat(created_at.replace("Z", "+00:00"))
    return now_ts - created_ts > timedelta(minutes=ttl_minutes)


def acquire_mutation_lock(
    *,
    lock_state: dict[str, str],
    lock_key: str,
    actor_id: str,
) -> tuple[bool, str | None]:
    existing_owner = lock_state.get(lock_key)
    if existing_owner is None or existing_owner == actor_id:
        lock_state[lock_key] = actor_id
        return (True, None)
    return (False, existing_owner)
