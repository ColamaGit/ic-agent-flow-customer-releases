from .flow_node_mapper import map_flow_node, specs_for_dashboard_version


VALID_PACKAGE_MODES = {"solo_eval", "team_project", "enterprise_site", "internal_dev"}
VALID_DASHBOARD_VERSIONS = {"v1_7", "v1_8"}


def _build_edges(nodes: list[dict], *, schema_version: str) -> list[dict]:
    edges: list[dict] = []
    for index, (source, target) in enumerate(zip(nodes, nodes[1:]), start=1):
        edges.append(
            {
                "edge_id": f"edge-{index:02d}-{source['node_id']}-to-{target['node_id']}",
                "type": "flow_dashboard_edge",
                "schema_version": schema_version,
                "from_node_id": source["node_id"],
                "to_node_id": target["node_id"],
                "edge_kind": "flow_order",
                "required": True,
            }
        )
    return edges


def _schema_version_for_dashboard_version(dashboard_version: str) -> str:
    if dashboard_version == "v1_7":
        return "1.7.0"
    if dashboard_version == "v1_8":
        return "1.8.0"
    raise ValueError(f"unsupported dashboard_version: {dashboard_version}")


def build_flow_registry(*, chip_id: str, package_mode: str, dashboard_version: str = "v1_7") -> dict:
    if package_mode not in VALID_PACKAGE_MODES:
        raise ValueError(f"unsupported package_mode: {package_mode}")
    if dashboard_version not in VALID_DASHBOARD_VERSIONS:
        raise ValueError(f"unsupported dashboard_version: {dashboard_version}")

    schema_version = _schema_version_for_dashboard_version(dashboard_version)
    node_specs = specs_for_dashboard_version(dashboard_version)
    nodes = [map_flow_node(spec, chip_id=chip_id, schema_version=schema_version) for spec in node_specs]
    edges = _build_edges(nodes, schema_version=schema_version)
    return {
        "registry_id": f"dashboard-flow-registry-{dashboard_version}-{chip_id}-{package_mode}",
        "type": "dashboard_flow_registry",
        "schema_version": schema_version,
        "dashboard_version": dashboard_version,
        "chip_id": chip_id,
        "package_mode": package_mode,
        "node_order": [node["node_id"] for node in nodes],
        "nodes": nodes,
        "edges": edges,
    }
