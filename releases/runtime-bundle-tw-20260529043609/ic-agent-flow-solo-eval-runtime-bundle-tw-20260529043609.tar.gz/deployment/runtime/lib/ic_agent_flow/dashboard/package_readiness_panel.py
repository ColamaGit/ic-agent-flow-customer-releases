from pathlib import Path

from .package_gate_collector import (
    REQUIRED_GATES,
    REQUIRED_GATES_V18,
    V15_ACTIVATION_GATES,
    V16_RELEASE_GATES,
    V18_LIVE_CONSOLE_GATES,
    VARIANTS,
    collect_package_gates,
)


def _panel_for_variant(*, input_root: Path, variant: str, dashboard_version: str) -> dict:
    is_v18 = dashboard_version == "v1_8"
    schema_version = "1.8.0" if is_v18 else "1.7.0"
    required_gates = REQUIRED_GATES_V18 if is_v18 else REQUIRED_GATES
    gate_results = collect_package_gates(input_root=input_root, variant=variant, required_gates=required_gates)
    missing_gates = [item["gate_id"] for item in gate_results if item["verdict"] == "blocked"]
    missing_v16 = [gate for gate in missing_gates if gate in V16_RELEASE_GATES]
    missing_v15 = [gate for gate in missing_gates if gate in V15_ACTIVATION_GATES]
    missing_v18 = [gate for gate in missing_gates if gate in V18_LIVE_CONSOLE_GATES]

    release_claim_verdict = "blocked" if missing_v16 else "allowed"
    customer_ready_claim_verdict = "blocked" if missing_v16 or missing_v15 else "allowed"
    live_console_claim_verdict = "blocked" if is_v18 and missing_v18 else "allowed"
    blocked_claims = []
    if release_claim_verdict == "blocked":
        blocked_claims.append("release-ready")
    if customer_ready_claim_verdict == "blocked":
        blocked_claims.append("customer-ready")
    if is_v18 and live_console_claim_verdict == "blocked":
        blocked_claims.append("live-console-ready")

    readiness_verdict = "blocked" if blocked_claims else "ready"
    panel = {
        "panel_id": f"package-readiness-{variant}",
        "type": "package_readiness_panel",
        "schema_version": schema_version,
        "variant": variant,
        "readiness_verdict": readiness_verdict,
        "release_claim_verdict": release_claim_verdict,
        "customer_ready_claim_verdict": customer_ready_claim_verdict,
        "gate_results": gate_results,
        "missing_gates": missing_gates,
        "blocked_claims": blocked_claims,
        "claim_boundary": f"{variant}: readiness is variant-scoped and must not be generalized across package modes",
    }
    if is_v18:
        panel["dashboard_version"] = "v1_8"
        panel["live_console_claim_verdict"] = live_console_claim_verdict
    return panel


def build_package_readiness_board(*, input_root: Path, dashboard_version: str = "v1_7") -> dict:
    is_v18 = dashboard_version == "v1_8"
    schema_version = "1.8.0" if is_v18 else "1.7.0"
    panels = [
        _panel_for_variant(input_root=Path(input_root), variant=variant, dashboard_version=dashboard_version)
        for variant in VARIANTS
    ]
    overall_verdict = "blocked" if any(panel["readiness_verdict"] == "blocked" for panel in panels) else "ready"
    return {
        "board_id": f"package-readiness-board-{dashboard_version.replace('_', '.')}",
        "type": "package_readiness_board",
        "schema_version": schema_version,
        "dashboard_version": dashboard_version,
        "variants": VARIANTS,
        "required_gates": REQUIRED_GATES_V18 if is_v18 else REQUIRED_GATES,
        "universal_readiness_badge": False,
        "panels": panels,
        "overall_verdict": overall_verdict,
    }
