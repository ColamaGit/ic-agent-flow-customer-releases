"""Dashboard i18n contract helpers."""
