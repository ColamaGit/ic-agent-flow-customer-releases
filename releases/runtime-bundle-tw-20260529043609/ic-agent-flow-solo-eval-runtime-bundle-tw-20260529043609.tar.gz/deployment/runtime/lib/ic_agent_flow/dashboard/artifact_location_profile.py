from pathlib import Path


def build_location_profile(
    *,
    context: str,
    root: Path,
    package_mode: str | None = None,
    dashboard_version: str = "v1_7",
) -> dict:
    schema_version = "1.8.0" if dashboard_version == "v1_8" else "1.7.0"
    if context == "working_project":
        return {
            "profile_id": "working_project",
            "type": "artifact_location_profile",
            "schema_version": schema_version,
            "dashboard_version": dashboard_version,
            "context": "working_project",
            "root_kind": "repo_root",
            "root_ref": str(Path(root)),
            "uri_prefixes": ["icaf://artifact/"],
            "path_policy": "environment_resolved",
            "display_path_mode": "absolute",
            "repo_root_fallback_allowed": True,
        }
    if context == "release_package_extract":
        if not package_mode:
            raise ValueError("package_mode is required for release_package_extract")
        return {
            "profile_id": f"package_extract_{package_mode}",
            "type": "artifact_location_profile",
            "schema_version": schema_version,
            "dashboard_version": dashboard_version,
            "context": "release_package_extract",
            "root_kind": "package_extract_root",
            "root_ref": str(Path(root)),
            "uri_prefixes": ["icaf://artifact/"],
            "path_policy": "no_hardcoded_absolute_paths",
            "display_path_mode": "relative",
            "repo_root_fallback_allowed": False,
            "package_mode": package_mode,
        }
    raise ValueError(f"unsupported context: {context}")
