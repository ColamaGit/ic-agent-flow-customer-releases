from pathlib import Path

from .artifact_uri import parse_artifact_uri


def _physical_path(profile: dict, relative_path: str) -> Path:
    return Path(profile["root_ref"]) / "artifacts" / relative_path


def _display_path(profile: dict, physical_path: Path, relative_path: str) -> str:
    if profile["display_path_mode"] == "relative":
        return str(Path("artifacts") / relative_path)
    return str(physical_path)


def resolve_artifact_uri(
    *,
    uri: str,
    profile: dict,
    repo_root_fallback: Path | None = None,
) -> dict:
    parsed = parse_artifact_uri(uri)
    physical_path = _physical_path(profile, parsed.relative_path)
    policy_flags: list[str] = []
    schema_version = "1.8.0" if profile.get("dashboard_version") == "v1_8" else "1.7.0"

    if ".." in parsed.parts:
        status = "blocked_by_policy"
        policy_flags.append("path_traversal_blocked")
    elif physical_path.exists():
        status = "resolved"
    elif (
        repo_root_fallback is not None
        and not profile.get("repo_root_fallback_allowed", False)
        and (Path(repo_root_fallback) / "artifacts" / parsed.relative_path).exists()
    ):
        status = "blocked_by_policy"
        policy_flags.append("repo_root_fallback_blocked")
    else:
        status = "missing"

    record = {
        "record_id": f"resolved-{profile['profile_id']}-{parsed.relative_path.replace('/', '-')}",
        "type": "artifact_resolved_path_record",
        "schema_version": schema_version,
        "logical_uri": uri,
        "context": profile["context"],
        "profile_id": profile["profile_id"],
        "resolved_path": _display_path(profile, physical_path, parsed.relative_path),
        "resolution_status": status,
        "display_path_mode": profile["display_path_mode"],
        "policy_flags": policy_flags,
    }
    if profile.get("dashboard_version") == "v1_8":
        record["dashboard_version"] = "v1_8"
    return record
