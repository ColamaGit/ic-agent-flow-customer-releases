MVP_DECISION_TYPES = [
    "approve",
    "approve_with_conditions",
    "hold",
    "reject",
    "request_more_evidence",
    "escalate",
    "block_release",
    "approve_activation",
    "approve_package_release",
]


def build_decision_queue_item(*, decision_type: str, authority_role: str, formal_decision_ref: str, artifact_refs: list[str]) -> dict:
    return build_decision_queue_item_v17(
        decision_type=decision_type,
        authority_role=authority_role,
        formal_decision_ref=formal_decision_ref,
        artifact_refs=artifact_refs,
    )


def build_decision_queue_item_v17(
    *,
    decision_type: str,
    authority_role: str,
    formal_decision_ref: str,
    artifact_refs: list[str],
) -> dict:
    if decision_type not in MVP_DECISION_TYPES:
        raise ValueError(f"unsupported decision_type: {decision_type}")
    return {
        "item_id": f"decision-{decision_type}",
        "type": "human_decision_queue_item",
        "schema_version": "1.7.0",
        "decision_type": decision_type,
        "status": "pending",
        "authority_role": authority_role,
        "allowed_actions": MVP_DECISION_TYPES,
        "artifact_refs": artifact_refs,
        "formal_decision_ref": formal_decision_ref,
    }


def build_decision_queue_item_v18(
    *,
    decision_type: str,
    authority_role: str,
    formal_decision_ref: str,
    artifact_refs: list[str],
    profile: str,
    chip_id: str,
    run_id: str,
) -> dict:
    if decision_type not in MVP_DECISION_TYPES:
        raise ValueError(f"unsupported decision_type: {decision_type}")
    return {
        "item_id": f"decision-{decision_type}-{chip_id}-{run_id}",
        "type": "human_decision_queue_item",
        "schema_version": "1.8.0",
        "dashboard_version": "v1_8",
        "decision_type": decision_type,
        "status": "pending",
        "authority_role": authority_role,
        "allowed_actions": MVP_DECISION_TYPES,
        "artifact_refs": artifact_refs,
        "formal_decision_ref": formal_decision_ref,
        "profile": profile,
        "chip_id": chip_id,
        "run_id": run_id,
    }
