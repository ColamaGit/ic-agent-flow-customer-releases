from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


def _iso_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def _save(path: Path, payload: dict) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def apply_agent_trust_panel_action(
    out_dir: Path,
    *,
    binding_id: str,
    action: str,
    actor_role: str,
) -> None:
    binding_path = out_dir / "agent_trust_panel_action_binding.json"
    panel_path = out_dir / "agent_trust_panel_view.json"
    if not binding_path.exists():
        raise FileNotFoundError(f"missing action binding: {binding_path}")
    if not panel_path.exists():
        raise FileNotFoundError(f"missing panel view: {panel_path}")

    binding = _load(binding_path)
    panel = _load(panel_path)
    if str(binding.get("binding_id")) != binding_id:
        raise ValueError(f"binding_id mismatch: expected {binding.get('binding_id')}, got {binding_id}")

    requested = str(binding.get("requested_action", "")).lower()
    candidate = action.lower()
    allowed = {"approve", "reject", "rerun", "waive", "request_more_evidence"}
    if candidate not in allowed:
        raise ValueError(f"unsupported action: {action}")

    request = {
        "request_id": f"agent-trust-request::{binding_id}::{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}",
        "type": "dashboard_action_request",
        "target_binding_id": binding_id,
        "requested_action": candidate,
        "actor_role": actor_role,
        "created_at": _iso_now(),
    }
    _save(out_dir / "dashboard_action_request.json", request)

    if requested and requested != candidate:
        binding["status"] = "FAILED_CLOSED"
        _save(binding_path, binding)
        auth = {
            "type": "dashboard_action_authorization_record",
            "status": "BLOCKED",
            "reason": "ACTION_MISMATCH",
            "requested_action": requested,
            "attempted_action": candidate,
            "actor_role": actor_role,
            "generated_at": _iso_now(),
        }
        _save(out_dir / "dashboard_action_authorization_record.json", auth)
        audit = {
            "type": "dashboard_action_audit_record",
            "status": "BLOCKED",
            "actor_role": actor_role,
            "action": candidate,
            "reason": "ACTION_MISMATCH",
            "generated_at": _iso_now(),
        }
        _save(out_dir / "dashboard_action_audit_record.json", audit)
        result = {
            "type": "dashboard_action_result_record",
            "status": "FAILED_CLOSED",
            "action": candidate,
            "generated_at": _iso_now(),
        }
        _save(out_dir / "dashboard_action_result_record.json", result)
        trace = {
            "type": "dashboard_replay_trace",
            "replay_trace_id": f"agent-trust-replay::{binding_id}",
            "status": "FAILED_CLOSED",
            "generated_at": _iso_now(),
        }
        _save(out_dir / "dashboard_replay_trace.json", trace)
        return

    binding["status"] = "EXECUTED"
    _save(binding_path, binding)
    auth = {
        "type": "dashboard_action_authorization_record",
        "status": "AUTHORIZED",
        "requested_action": candidate,
        "actor_role": actor_role,
        "generated_at": _iso_now(),
    }
    _save(out_dir / "dashboard_action_authorization_record.json", auth)
    audit = {
        "type": "dashboard_action_audit_record",
        "status": "RECORDED",
        "actor_role": actor_role,
        "action": candidate,
        "generated_at": _iso_now(),
    }
    _save(out_dir / "dashboard_action_audit_record.json", audit)
    result = {
        "type": "dashboard_action_result_record",
        "status": "EXECUTED",
        "action": candidate,
        "generated_at": _iso_now(),
    }
    _save(out_dir / "dashboard_action_result_record.json", result)
    trace = {
        "type": "dashboard_replay_trace",
        "replay_trace_id": f"agent-trust-replay::{binding_id}",
        "status": "COMPLETE",
        "generated_at": _iso_now(),
    }
    _save(out_dir / "dashboard_replay_trace.json", trace)

    rec_dir = out_dir / "agent_trust_panel_action_records"
    rec_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    record = {
        "type": "agent_trust_panel_action_record",
        "binding_id": binding_id,
        "action": candidate,
        "actor_role": actor_role,
        "result": "EXECUTED",
        "generated_at": _iso_now(),
    }
    _save(rec_dir / f"{stamp}_{candidate}.json", record)

    refs = list(panel.get("human_action_refs", []))
    refs.append(f"agent_trust_panel_action_records/{stamp}_{candidate}.json")
    panel["human_action_refs"] = refs
    _save(panel_path, panel)
