def resolve_initial_flow_status(node_group: str) -> str:
    gate_groups = {"v1_4_qa_gate", "v1_6_distribution_gate"}
    if node_group in gate_groups:
        return "unknown"
    return "not_started"
