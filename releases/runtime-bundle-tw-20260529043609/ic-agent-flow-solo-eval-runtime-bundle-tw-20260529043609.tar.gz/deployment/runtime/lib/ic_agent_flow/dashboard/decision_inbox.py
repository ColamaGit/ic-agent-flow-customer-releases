import json
from pathlib import Path

from .decision_queue_item import (
    MVP_DECISION_TYPES,
    build_decision_queue_item_v17,
    build_decision_queue_item_v18,
)


def _load_decision(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def build_decision_inbox(*, input_root: Path, dashboard_version: str = "v1_7") -> dict:
    is_v18 = dashboard_version == "v1_8"
    schema_version = "1.8.0" if is_v18 else "1.7.0"
    items = []
    for decision_type in MVP_DECISION_TYPES:
        path = Path(input_root) / f"{decision_type}.json"
        if not path.exists():
            continue
        payload = _load_decision(path)
        if is_v18:
            items.append(
                build_decision_queue_item_v18(
                    decision_type=payload["decision_type"],
                    authority_role=payload["authority_role"],
                    formal_decision_ref=payload["formal_decision_ref"],
                    artifact_refs=payload.get("artifact_refs", []),
                    profile=payload.get("profile", "team_project"),
                    chip_id=payload.get("chip_id", "SN2025"),
                    run_id=payload.get("run_id", "RUN-UNSPECIFIED"),
                )
            )
        else:
            items.append(
                build_decision_queue_item_v17(
                    decision_type=payload["decision_type"],
                    authority_role=payload["authority_role"],
                    formal_decision_ref=payload["formal_decision_ref"],
                    artifact_refs=payload.get("artifact_refs", []),
                )
            )
    queue = {
        "queue_id": f"human-decision-queue-{dashboard_version.replace('_', '.')}",
        "type": "human_decision_queue",
        "schema_version": schema_version,
        "items": items,
        "pending_count": len([item for item in items if item["status"] == "pending"]),
    }
    if is_v18:
        queue["dashboard_version"] = "v1_8"
    return queue
