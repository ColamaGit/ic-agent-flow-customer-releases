from .locale_manifest import FALLBACK_DASHBOARD_LOCALE, SUPPORTED_DASHBOARD_LOCALES


def resolve_locale(requested_locale: str | None) -> str:
    if requested_locale in SUPPORTED_DASHBOARD_LOCALES:
        return requested_locale
    return FALLBACK_DASHBOARD_LOCALE
