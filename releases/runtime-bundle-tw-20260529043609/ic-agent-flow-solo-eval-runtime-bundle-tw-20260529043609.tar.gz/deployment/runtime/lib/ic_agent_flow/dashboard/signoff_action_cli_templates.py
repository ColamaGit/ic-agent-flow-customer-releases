from __future__ import annotations

from datetime import datetime, timezone


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _map_blocked_claim_to_recommendation(token: str) -> str:
    normalized = token.strip().lower()
    if "tapeout_ready" in normalized or "drc_clean" in normalized:
        return "request_revalidation"
    if "full_chip_functional_equivalence_proven" in normalized or "full_cpu_equivalence_proven" in normalized:
        return "start_waiver_review_path"
    if "foundry_ready" in normalized or "silicon_proven" in normalized:
        return "block_public_claim_and_escalate_authority_review"
    return "request_more_evidence"


def _templates_for_recommendation(recommendation: str, run_dir: str) -> list[str]:
    if recommendation == "request_revalidation":
        return [
            "python3 package_ws/shared-runtime/scripts/backfill_signoff_readiness_summary.py --artifacts-root artifacts/production-runs",
            f"python3 package_ws/shared-runtime/scripts/apply_signoff_decision_action.py --run-dir {run_dir} --action-id request_revalidation_for_blocked_claims --actor-role SIGNOFF_APPROVER",
            f"python3 package_ws/shared-runtime/scripts/apply_signoff_decision_action.py --run-dir {run_dir} --action-id finalize_tapeout_readiness --actor-role RELEASE_AUTHORITY",
        ]
    if recommendation == "start_waiver_review_path":
        return [
            f"python3 package_ws/shared-runtime/scripts/apply_signoff_decision_action.py --run-dir {run_dir} --action-id approve_waiver --actor-role SIGNOFF_APPROVER",
            f"python3 package_ws/shared-runtime/scripts/apply_signoff_decision_action.py --run-dir {run_dir} --action-id accept_risk --actor-role RELEASE_AUTHORITY",
        ]
    if recommendation == "block_public_claim_and_escalate_authority_review":
        return [
            f"python3 package_ws/shared-runtime/scripts/apply_signoff_decision_action.py --run-dir {run_dir} --action-id finalize_tapeout_readiness --actor-role RELEASE_AUTHORITY",
            "# escalate: keep BLOCKED until domain closure evidence is complete",
        ]
    return [
        "# request_more_evidence: attach missing domain evidence then rerun signoff adjudication",
        f"python3 package_ws/shared-runtime/scripts/apply_signoff_decision_action.py --run-dir {run_dir} --action-id finalize_tapeout_readiness --actor-role RELEASE_AUTHORITY",
    ]


def build_signoff_action_cli_templates(*, run_scope: dict, run_dir: str, decision_inbox: dict) -> dict:
    templates: list[dict] = []
    for item in decision_inbox.get("items", []):
        action_id = str(item.get("action_id", "-"))
        reason = str(item.get("reason", ""))
        recommendations = sorted(
            {
                _map_blocked_claim_to_recommendation(token)
                for token in reason.split(",")
                if token.strip()
            }
            or {"request_more_evidence"}
        )
        cli_templates = []
        for rec in recommendations:
            cli_templates.extend(_templates_for_recommendation(rec, run_dir))
        deduped = []
        for line in cli_templates:
            if line not in deduped:
                deduped.append(line)
        templates.append(
            {
                "action_id": action_id,
                "recommended_next_actions": recommendations,
                "cli_templates": deduped,
            }
        )
    return {
        "schema_version": "v1.13",
        "type": "signoff_action_cli_templates",
        "generated_at": _now_iso(),
        "scope": run_scope,
        "templates": templates,
    }
