from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from ic_agent_flow.dashboard.silicon_feedback_v115 import evaluate_v115_silicon_proven_gate

_ALLOWED_ROLES: dict[str, set[str]] = {
    "acknowledge_bringup_failure": {"BRINGUP_OWNER", "RELEASE_AUTHORITY"},
    "approve_or_reject_eco": {"ECO_AUTHORITY"},
    "finalize_silicon_proven_bounded": {"RELEASE_AUTHORITY"},
}


def _iso_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def _save(path: Path, payload: dict) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def _write_action_record(out_dir: Path, *, action_id: str, actor_role: str, result: str, notes: str) -> None:
    rec_dir = out_dir / "v115_action_records"
    rec_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    payload = {
        "schema_version": "v1.15",
        "type": "silicon_feedback_action_record",
        "action_id": action_id,
        "actor_role": actor_role,
        "result": result,
        "notes": notes,
        "generated_at": _iso_now(),
    }
    _save(rec_dir / f"{ts}_{action_id}.json", payload)


def _require_role(action_id: str, actor_role: str) -> None:
    allowed = _ALLOWED_ROLES.get(action_id)
    if not allowed:
        raise ValueError(f"unsupported action_id: {action_id}")
    if actor_role not in allowed:
        raise PermissionError(f"RBAC_DENIED:{action_id}:{actor_role}")


def apply_v115_action(out_dir: Path, *, action_id: str, actor_role: str) -> None:
    _require_role(action_id, actor_role)
    validation_path = out_dir / "v115_silicon_validation_result.json"
    eco_path = out_dir / "v115_eco_decision_record.json"
    claim_path = out_dir / "v115_silicon_proven_claim_record.json"
    inbox_path = out_dir / "v115_silicon_feedback_decision_inbox.json"

    validation = _load(validation_path)
    eco = _load(eco_path)
    claim = _load(claim_path)

    result = "DONE"
    notes = ""

    if action_id == "acknowledge_bringup_failure":
        validation["acknowledged_by_role"] = actor_role
        validation["acknowledged_at"] = _iso_now()
        notes = "bringup review acknowledged"

    elif action_id == "approve_or_reject_eco":
        if str(validation.get("overall_verdict", "")).upper() != "PASS":
            eco["decision"] = "REJECT"
            result = "BLOCKED"
            notes = "validation_not_pass"
        else:
            eco["decision"] = "APPROVE"
            eco["decided_by"] = actor_role
            eco["generated_at"] = _iso_now()
            notes = "eco approved"

    elif action_id == "finalize_silicon_proven_bounded":
        # Authoritative hard gate – all three conditions required
        v114_lineage_ref = claim.get("v114_lineage_ref") or ""
        gate = evaluate_v115_silicon_proven_gate(
            bringup_result=validation if validation else None,
            eco_decision=eco if eco else None,
            v114_lineage_ref=v114_lineage_ref if v114_lineage_ref else None,
        )
        if gate["status"] == "PASS":
            claim["status"] = "SILICON_PROVEN_BOUNDED"
            claim["authoritative"] = True
            claim["finalized_by"] = actor_role
            claim["finalized_at"] = _iso_now()
            claim["blocking_reasons"] = []
            claim["gate_result"] = gate
            notes = "claim finalized via authoritative gate"
        else:
            claim["status"] = "BLOCKED"
            claim["authoritative"] = False
            claim["blocking_reasons"] = gate["blocking_reasons"]
            claim["gate_result"] = gate
            result = "BLOCKED"
            notes = ",".join(gate["blocking_reasons"])

    _save(validation_path, validation)
    _save(eco_path, eco)
    _save(claim_path, claim)

    if inbox_path.exists():
        inbox = _load(inbox_path)
        items = inbox.get("items") or []
        completed = inbox.get("completed_items") or []
        for item in items:
            if str(item.get("action_id")) == action_id:
                completed.append(
                    {
                        "action_id": action_id,
                        "status": result,
                        "required_role": actor_role,
                        "reason": notes,
                    }
                )
        inbox["items"] = [it for it in items if str(it.get("action_id")) != action_id]
        inbox["pending_count"] = len(inbox["items"])
        inbox["completed_items"] = completed
        inbox["completed_count"] = len(completed)
        inbox["generated_at"] = _iso_now()
        _save(inbox_path, inbox)

    _write_action_record(out_dir, action_id=action_id, actor_role=actor_role, result=result, notes=notes)
