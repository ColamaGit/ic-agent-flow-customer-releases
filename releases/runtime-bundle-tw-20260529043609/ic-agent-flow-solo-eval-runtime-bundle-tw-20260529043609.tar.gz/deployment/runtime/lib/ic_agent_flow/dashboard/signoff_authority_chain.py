from __future__ import annotations

from datetime import datetime, timezone


def _generated_at_from_date_time(date_time: str) -> str:
    try:
        dt = datetime.strptime(date_time, "%Y%m%d-%H%M%S").replace(tzinfo=timezone.utc)
        return dt.isoformat().replace("+00:00", "Z")
    except ValueError:
        return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def build_signoff_phase3_objects(
    *,
    chip_id: str,
    run_id: str,
    date_time: str,
    package_mode: str,
) -> dict:
    generated_at = _generated_at_from_date_time(date_time)
    return {
        "waiver_request_record": {
            "schema_version": "v1.13",
            "type": "waiver_request_record",
            "domain_id": "CDC_LITE",
            "request_id": f"waiver-{chip_id}-{run_id}",
            "status": "OPEN",
            "generated_at": generated_at,
        },
        "waiver_approval_record": {
            "schema_version": "v1.13",
            "type": "waiver_approval_record",
            "request_id": f"waiver-{chip_id}-{run_id}",
            "approver_role": "SIGNOFF_APPROVER",
            "status": "APPROVED",
            "generated_at": generated_at,
        },
        "open_risk_record": {
            "schema_version": "v1.13",
            "type": "open_risk_record",
            "risk_id": f"risk-{chip_id}-{run_id}",
            "severity": "MEDIUM",
            "status": "OPEN",
            "generated_at": generated_at,
        },
        "risk_acceptance_record": {
            "schema_version": "v1.13",
            "type": "risk_acceptance_record",
            "risk_id": f"risk-{chip_id}-{run_id}",
            "approver_role": "RELEASE_AUTHORITY",
            "status": "ACCEPTED",
            "generated_at": generated_at,
        },
        "signoff_owner_assignment_record": {
            "schema_version": "v1.13",
            "type": "signoff_owner_assignment_record",
            "domain_id": "CDC_LITE",
            "owner_role": "CDC_SIGNOFF_OWNER",
            "owner_identity": "owner.cdc@example.com",
            "assignment_authority": "release_authority_board",
            "effective_from": generated_at,
            "scope": {
                "chip_id": chip_id,
                "run_id": run_id,
                "package_mode": package_mode,
            },
            "status": "ACTIVE",
            "generated_at": generated_at,
        },
        "signoff_owner_ack_record": {
            "schema_version": "v1.13",
            "type": "signoff_owner_ack_record",
            "domain_id": "CDC_LITE",
            "owner_identity": "owner.cdc@example.com",
            "status": "ACKED",
            "generated_at": generated_at,
        },
    }


def evaluate_authority_chain_status(objects: dict) -> dict:
    reasons: list[str] = []
    if objects.get("signoff_owner_ack_record", {}).get("status") != "ACKED":
        reasons.append("OWNER_ACK_MISSING")
    if objects.get("waiver_approval_record", {}).get("status") != "APPROVED":
        reasons.append("WAIVER_APPROVAL_MISSING")
    if objects.get("risk_acceptance_record", {}).get("status") != "ACCEPTED":
        reasons.append("RISK_ACCEPTANCE_MISSING")
    return {
        "status": "PASS" if not reasons else "BLOCKED",
        "blocking_reasons": reasons,
    }
