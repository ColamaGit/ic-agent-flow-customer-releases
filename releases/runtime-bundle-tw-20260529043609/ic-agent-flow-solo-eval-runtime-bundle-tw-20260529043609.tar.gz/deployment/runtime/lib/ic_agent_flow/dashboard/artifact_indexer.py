from pathlib import Path

from .artifact_uri import logical_uri_from_relative_path


def _artifact_family(relative_path: str) -> str:
    parts = Path(relative_path).parts
    if len(parts) >= 5:
        return parts[4]
    return "artifact"


def build_artifact_run_index(*, context: str, root: Path) -> dict:
    artifact_root = Path(root) / "artifacts"
    refs = []
    if artifact_root.exists():
        for path in sorted(item for item in artifact_root.rglob("*") if item.is_file()):
            relative_path = str(path.relative_to(artifact_root))
            refs.append(
                {
                    "logical_uri": logical_uri_from_relative_path(relative_path),
                    "artifact_family": _artifact_family(relative_path),
                }
            )

    first_parts = Path(refs[0]["logical_uri"].removeprefix("icaf://artifact/")).parts if refs else ()
    chip_id = first_parts[1] if len(first_parts) > 1 else "unknown"
    run_id = first_parts[3] if len(first_parts) > 3 else "unknown"
    return {
        "index_id": f"artifact-run-index-{context}-{chip_id}-{run_id}",
        "type": "artifact_run_index",
        "schema_version": "1.7.0",
        "chip_id": chip_id,
        "run_id": run_id,
        "context": context,
        "artifact_refs": refs,
    }
