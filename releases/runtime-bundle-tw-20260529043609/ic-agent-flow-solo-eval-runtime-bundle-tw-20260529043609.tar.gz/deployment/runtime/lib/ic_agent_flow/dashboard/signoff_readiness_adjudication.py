from __future__ import annotations

from datetime import datetime, timezone


def _generated_at_from_date_time(date_time: str) -> str:
    try:
        dt = datetime.strptime(date_time, "%Y%m%d-%H%M%S").replace(tzinfo=timezone.utc)
        return dt.isoformat().replace("+00:00", "Z")
    except ValueError:
        return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def build_phase4_draft(
    *,
    chip_id: str,
    run_id: str,
    date_time: str,
    gap_status: str,
    authority_status: str,
) -> dict:
    generated_at = _generated_at_from_date_time(date_time)
    if gap_status == "PASS" and authority_status == "PASS":
        status = "READY_FOR_TAPEOUT_PACKAGE_ASSEMBLY_CANDIDATE"
        reasons = []
    else:
        status = "BLOCKED"
        reasons = [f"gap_status={gap_status}", f"authority_status={authority_status}"]
    return {
        "signoff_closure_report": {
            "schema_version": "v1.13",
            "type": "signoff_closure_report",
            "chip_id": chip_id,
            "run_id": run_id,
            "date_time": date_time,
            "generated_at": generated_at,
            "status": status,
            "blocking_reasons": reasons,
            "is_draft": True,
        },
        "tapeout_readiness_record_draft": {
            "schema_version": "v1.13",
            "type": "tapeout_readiness_record",
            "chip_id": chip_id,
            "run_id": run_id,
            "date_time": date_time,
            "generated_at": generated_at,
            "status": status,
            "authoritative": False,
            "requires_silicon_contract_binding": True,
        },
        "tapeout_readiness_adjudication_draft": {
            "schema_version": "v1.13",
            "type": "tapeout_readiness_adjudication",
            "chip_id": chip_id,
            "run_id": run_id,
            "date_time": date_time,
            "generated_at": generated_at,
            "adjudication": "DRAFT_ONLY",
            "blocking_reasons": reasons,
        },
    }
