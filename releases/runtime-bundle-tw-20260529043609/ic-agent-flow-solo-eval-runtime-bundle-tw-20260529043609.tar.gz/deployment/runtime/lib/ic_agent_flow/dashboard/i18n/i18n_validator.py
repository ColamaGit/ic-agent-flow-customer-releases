import json
from pathlib import Path


def _load_bundle(resource_root: Path, locale: str) -> dict:
    bundle_path = resource_root / f"{locale}.json"
    return json.loads(bundle_path.read_text(encoding="utf-8"))


def validate_i18n_resources(
    *,
    resource_root: Path,
    locales: list[str],
    required_keys: list[str],
) -> dict:
    locale_results: dict[str, dict] = {}
    all_missing: set[str] = set()
    required_key_set = set(required_keys)

    for locale in locales:
        bundle = _load_bundle(Path(resource_root), locale)
        translations = bundle.get("translations", {})
        present_keys = set(translations.keys())
        missing = sorted(required_key_set - present_keys)
        extra = sorted(present_keys - required_key_set)
        all_missing.update(f"{locale}:{key}" for key in missing)
        locale_results[locale] = {
            "present_key_count": len(present_keys & required_key_set),
            "missing_keys": missing,
            "extra_keys": extra,
            "verdict": "pass" if not missing else "blocked",
        }

    return {
        "report_id": "dashboard-i18n-coverage-v1.7.0",
        "type": "dashboard_i18n_coverage_report",
        "schema_version": "1.7.0",
        "locales": locales,
        "required_key_count": len(required_keys),
        "missing_required_keys": sorted(all_missing),
        "locale_results": locale_results,
        "overall_verdict": "pass" if not all_missing else "blocked",
    }
