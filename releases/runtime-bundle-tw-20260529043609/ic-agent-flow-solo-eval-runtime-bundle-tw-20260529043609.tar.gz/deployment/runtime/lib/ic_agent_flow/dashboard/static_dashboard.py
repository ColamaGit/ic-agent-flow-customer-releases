from html import escape
from pathlib import Path


VIEWS = [
    ("index.html", "Overview", "home"),
    ("flow-map.html", "Flow Map", "flow"),
    ("node-io.html", "Node IO Detail", "io"),
    ("artifacts.html", "Artifact Browser", "artifact"),
    ("run-detail.html", "Run Detail", "run"),
    ("package-readiness.html", "Package Readiness", "package"),
    ("decision-inbox.html", "Decision Inbox", "decision"),
]

DEFAULT_LOGICAL_URI = "icaf://artifact/production-runs/SN2025/raw/yosys.raw.log"
DEFAULT_RELATIVE_PATH = "artifacts/production-runs/SN2025/raw/yosys.raw.log"

ICON_PATHS = {
    "home": '<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/><path d="M9 21v-7h6v7"/>',
    "flow": '<path d="M4 7h6"/><path d="M14 7h6"/><path d="M10 7a2 2 0 1 0 4 0 2 2 0 0 0-4 0Z"/><path d="M6 17h12"/><path d="M18 17a2 2 0 1 0 4 0 2 2 0 0 0-4 0Z"/><path d="M2 17a2 2 0 1 0 4 0 2 2 0 0 0-4 0Z"/>',
    "io": '<path d="M4 7h8"/><path d="m9 4 3 3-3 3"/><path d="M20 17h-8"/><path d="m15 14-3 3 3 3"/>',
    "artifact": '<path d="M4 4h7v7H4z"/><path d="M13 4h7v7h-7z"/><path d="M4 13h7v7H4z"/><path d="M13 13h7v7h-7z"/>',
    "run": '<path d="M5 12h14"/><path d="m13 6 6 6-6 6"/><path d="M5 5v14"/>',
    "package": '<path d="m12 3 8 4.5v9L12 21l-8-4.5v-9L12 3Z"/><path d="M4.5 8 12 12.5 19.5 8"/><path d="M12 21v-8.5"/>',
    "decision": '<path d="M4 5h16v11H7l-3 3V5Z"/><path d="M8 9h8"/><path d="M8 13h5"/>',
}


def _icon(icon_id: str, class_name: str) -> str:
    paths = ICON_PATHS[icon_id]
    return (
        f'<svg class="{class_name}" aria-hidden="true" viewBox="0 0 24 24" '
        'fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" '
        f'stroke-linejoin="round">{paths}</svg>'
    )


def _safe_display_path(path: str, context: str) -> str:
    if context == "release_package_extract":
        marker = "/artifacts/"
        if marker in path:
            return "artifacts/" + path.split(marker, 1)[1]
        if path.startswith("artifacts/"):
            return path
        return DEFAULT_RELATIVE_PATH
    return path


def _nav() -> str:
    items = []
    for filename, label, icon_id in VIEWS:
        items.append(
            f'<a class="nav-icon" href="{filename}" aria-label="{escape(label)}" '
            f'title="{escape(label)}" data-hint="{escape(label)}">'
            f'{_icon(icon_id, "nav-svg")}</a>'
        )
    return '<nav class="header-icon-nav">' + "".join(items) + "</nav>"


def _html(
    *,
    title: str,
    context: str,
    logical_uri: str,
    display_path: str,
    dashboard_version: str,
) -> str:
    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{escape(title)} | Flow Control Tower</title>
  <style>
    :root {{ color-scheme: dark; }}
    body {{ margin: 0; background: #08111f; color: #dbe4f0; font: 14px/1.5 Inter, ui-sans-serif, system-ui, sans-serif; }}
    header {{ position: sticky; top: 0; z-index: 10; display: flex; align-items: center; justify-content: space-between; gap: 16px; min-height: 56px; padding: 0 20px; border-bottom: 1px solid #203047; background: #0d1726; }}
    .brand {{ display: flex; flex-direction: column; gap: 1px; min-width: 180px; }}
    .brand strong {{ color: #f8fafc; font-size: 16px; letter-spacing: .12em; text-transform: uppercase; }}
    .brand span {{ color: #8ea0b8; font-size: 13px; letter-spacing: .04em; text-transform: uppercase; }}
    .header-icon-nav {{ display: flex; align-items: center; gap: 6px; flex-wrap: wrap; justify-content: flex-end; }}
    .nav-icon {{ position: relative; width: 44px; height: 44px; display: inline-flex; align-items: center; justify-content: center; border: 1px solid #263850; border-radius: 8px; background: #111d2e; color: #c8d3e2; text-decoration: none; }}
    .nav-svg {{ width: 20px; height: 20px; display: block; }}
    .nav-icon::after {{ content: attr(data-hint); position: absolute; bottom: -34px; left: 50%; transform: translateX(-50%); white-space: nowrap; font-size: 14px; letter-spacing: .02em; color: #e2e8f0; background: #0f1e31; border: 1px solid #2d4562; border-radius: 6px; padding: 3px 8px; display: none; pointer-events: none; }}
    .nav-icon:hover::after, .nav-icon:focus-visible::after {{ display: block; }}
    .nav-icon:focus-visible {{ outline: 2px solid #38bdf8; outline-offset: 2px; }}
    main {{ max-width: 1440px; margin: 0 auto; padding: 16px 12px; }}
    .panel {{ border: 1px solid #263850; border-radius: 8px; background: #0d1726; padding: 18px; margin: 14px 0; }}
    h1 {{ margin: 0 0 8px; font-size: 24px; letter-spacing: 0; display: flex; align-items: center; gap: 10px; }}
    .page-title-icon-wrap {{ position: relative; display: inline-flex; align-items: center; justify-content: center; }}
    .page-title-icon-wrap::after {{ content: attr(data-hint); position: absolute; top: 34px; left: 50%; transform: translateX(-50%); white-space: nowrap; font-size: 15px; letter-spacing: .02em; color: #dbeafe; background: #0f1e31; border: 1px solid #2d4562; border-radius: 6px; padding: 3px 8px; display: none; pointer-events: none; }}
    .page-title-icon-wrap:hover::after {{ display: block; }}
    .page-title-icon {{ width: 28px; height: 28px; color: #7dd3fc; flex: 0 0 auto; }}
    h2 {{ font-size: 15px; margin: 0 0 10px; }}
    code {{ color: #93c5fd; word-break: break-word; }}
    table {{ width: 100%; border-collapse: collapse; }}
    th, td {{ text-align: left; padding: 10px; border-bottom: 1px solid #203047; }}
    th {{ color: #93a4bb; font-size: 14px; letter-spacing: .05em; text-transform: uppercase; }}
  </style>
</head>
<body>
  <header>
    <div class="brand"><strong>Flow Control Tower</strong><span>PRD {escape(_dashboard_label(dashboard_version))} static dashboard</span></div>
    {_nav()}
  </header>
  <main>
    <h1><span class="page-title-icon-wrap" data-hint="{escape(title)}">{_icon(_icon_id_for_title(title), "page-title-icon")}</span>{escape(title)}</h1>
    <p>Context: <code>{escape(context)}</code></p>
    <section class="panel">
      <h2>Logical Artifact Navigation</h2>
      <table>
        <tr><th>Logical URI</th><td><code>{escape(logical_uri)}</code></td></tr>
        <tr><th>Resolved Path</th><td><code>{escape(display_path)}</code></td></tr>
      </table>
    </section>
    <section class="panel">
      <h2>View Contract</h2>
      <p>This static view is source-independent and derived from governed dashboard objects.</p>
    </section>
  </main>
</body>
</html>
"""


def _icon_id_for_title(title: str) -> str:
    for _filename, label, icon_id in VIEWS:
        if label == title:
            return icon_id
    return "home"


def _dashboard_label(dashboard_version: str) -> str:
    return "v1.8" if dashboard_version == "v1_8" else "v1.7"


def build_static_dashboard(
    *,
    out_dir: Path,
    context: str,
    resolved_artifact_path: str = DEFAULT_RELATIVE_PATH,
    dashboard_version: str = "v1_7",
) -> dict:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    display_path = _safe_display_path(resolved_artifact_path, context)

    for filename, label, _icon in VIEWS:
        (out_dir / filename).write_text(
            _html(
                title=label,
                context=context,
                logical_uri=DEFAULT_LOGICAL_URI,
                display_path=display_path,
                dashboard_version=dashboard_version,
            ),
            encoding="utf-8",
        )

    return {
        "manifest_id": f"static-dashboard-{dashboard_version.replace('_', '.')}",
        "type": "static_dashboard_manifest",
        "schema_version": "1.8.0" if dashboard_version == "v1_8" else "1.7.0",
        "dashboard_version": dashboard_version,
        "context": context,
        "views": [filename for filename, _label, _icon in VIEWS],
    }
