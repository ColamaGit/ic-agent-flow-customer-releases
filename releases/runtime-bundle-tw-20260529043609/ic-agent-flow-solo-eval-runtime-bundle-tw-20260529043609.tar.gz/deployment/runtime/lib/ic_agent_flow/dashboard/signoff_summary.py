from __future__ import annotations


def build_signoff_readiness_summary_markdown(
    *,
    chip_id: str,
    run_id: str,
    execution: str,
    signoff_domain_matrix: dict,
    signoff_gap_record: dict,
    final_tapeout_readiness_record: dict,
    silicon_contract_v113_binding_record: dict,
    authority_chain_verdict: dict,
) -> str:
    missing_by_domain: dict[str, int] = {}
    for row in signoff_gap_record.get("missing_required_evidence", []):
        domain = str(row.get("domain_id", "UNKNOWN"))
        missing_by_domain[domain] = missing_by_domain.get(domain, 0) + 1

    lines = [
        "# Signoff Readiness Summary",
        "",
        f"- chip_id: `{chip_id}`",
        f"- run_id: `{run_id}`",
        f"- execution: `{execution}`",
        "",
        "## Final Adjudication",
        "",
        f"- final_readiness: `{final_tapeout_readiness_record.get('status', 'NOT_AVAILABLE')}`",
        f"- silicon_contract_binding: `{silicon_contract_v113_binding_record.get('contract_status', 'NOT_AVAILABLE')}`",
        f"- signoff_gap_status: `{signoff_gap_record.get('status', 'NOT_AVAILABLE')}`",
        f"- authority_chain_status: `{authority_chain_verdict.get('status', 'NOT_AVAILABLE')}`",
        "",
        "## Per-Domain Status",
        "",
        "| Domain | Status | Missing Required Evidence | Owner Role | Claim Class Allowed |",
        "| --- | --- | --- | --- | --- |",
    ]
    for domain in signoff_domain_matrix.get("domains", []):
        domain_id = str(domain.get("domain_id", "UNKNOWN"))
        missing_count = missing_by_domain.get(domain_id, 0)
        status = "BLOCKED" if missing_count > 0 else "PASS"
        owner_role = str(domain.get("owner_role", "-"))
        claim_classes = domain.get("claim_class_allowed", [])
        claim_text = ", ".join(str(x) for x in claim_classes) if isinstance(claim_classes, list) and claim_classes else "-"
        lines.append(f"| {domain_id} | {status} | {missing_count} | {owner_role} | {claim_text} |")
    lines.extend(
        [
            "",
            "## Notes",
            "",
            "- This markdown is a derived human-readable summary.",
            "- Canonical truth remains in governed JSON artifacts under `dashboard_objects/.`",
            "",
        ]
    )
    return "\n".join(lines)
