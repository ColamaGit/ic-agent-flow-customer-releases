from __future__ import annotations

from datetime import datetime, timezone
import re
from typing import Iterable


_DEV_ABS_PATH_PATTERNS = (
    re.compile(r"/customer-home/[^/\s]+/"),
    re.compile(r"/customer-home/[^/\s]+/"),
    re.compile(r"[A-Za-z]:\\Users\\"),
)


def _iso_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _contains_developer_absolute_path(payload: str) -> bool:
    return any(pattern.search(payload) for pattern in _DEV_ABS_PATH_PATTERNS)


def is_safe_artifact_root(artifact_root: str | None) -> bool:
    if not artifact_root:
        return False
    return not _contains_developer_absolute_path(str(artifact_root))


def build_dashboard_selector_state_record(
    *,
    session_id: str,
    chip_id: str,
    run_id: str,
    date_time: str,
    package_mode: str,
    profile: str,
    selected_artifact_ref: str | None = None,
    selected_decision_item_ref: str | None = None,
    validity: str = "VALID",
) -> dict:
    record: dict[str, str] = {
        "selector_state_id": f"selector-state::{session_id}::{chip_id}::{run_id}::{date_time}",
        "type": "dashboard_selector_state_record",
        "schema_version": "1.8.0",
        "session_id": session_id,
        "chip_id": chip_id,
        "run_id": run_id,
        "date_time": date_time,
        "package_mode": package_mode,
        "profile": profile,
        "validity": validity,
    }
    if selected_artifact_ref:
        record["selected_artifact_ref"] = selected_artifact_ref
    if selected_decision_item_ref:
        record["selected_decision_item_ref"] = selected_decision_item_ref
    return record


def build_dashboard_action_request(
    *,
    session_id: str,
    action_name: str,
    actor_id: str,
    role: str,
    target_object_refs: list[str],
    source_evidence_refs: list[str],
    decision_context_ref: str,
) -> dict:
    return {
        "action_request_id": f"dashboard-action-request::{session_id}::{actor_id}::{action_name}::{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}",
        "type": "dashboard_action_request",
        "schema_version": "1.8.0",
        "session_id": session_id,
        "action_name": action_name,
        "actor_id": actor_id,
        "role": role,
        "target_object_refs": target_object_refs,
        "source_evidence_refs": source_evidence_refs,
        "decision_context_ref": decision_context_ref,
        "requested_at": _iso_now(),
    }


def build_downstream_decision_entrypoint_preview(
    *,
    backend_binding_state: str,
    live_submission_enabled: bool,
    session_id: str,
    action_name: str,
    actor_id: str,
    role: str,
    target_object_refs: list[str],
    source_evidence_refs: list[str],
    decision_context_ref: str,
    formal_object_refs: list[str],
    readiness_status: str,
    decision_status: str,
) -> dict:
    action_request = build_dashboard_action_request(
        session_id=session_id,
        action_name=action_name,
        actor_id=actor_id,
        role=role,
        target_object_refs=target_object_refs,
        source_evidence_refs=source_evidence_refs,
        decision_context_ref=decision_context_ref,
    )
    return {
        "entrypointId": f"downstream-action-entrypoint::{session_id}::{actor_id}::{action_name}",
        "backendBindingState": backend_binding_state,
        "liveSubmissionEnabled": live_submission_enabled,
        "readinessDimension": readiness_status,
        "decisionDimension": decision_status,
        "decisionContextRef": decision_context_ref,
        "allowedSubmissionActions": [
            "request_more_evidence",
            "hold",
            "reject",
            "approve_with_conditions",
            "block_release",
            "unblock_release",
        ],
        "actionRequest": action_request,
        "formalObjectRefs": formal_object_refs,
        "submissionHint": "Live submission disabled until v1.8 action backend is bound." if not live_submission_enabled else "Live submission is bound to the v1.8 action backend.",
        "entrypoint_id": f"downstream-action-entrypoint::{session_id}::{actor_id}::{action_name}",
        "backend_binding_state": backend_binding_state,
        "live_submission_enabled": live_submission_enabled,
        "readiness_dimension": readiness_status,
        "decision_dimension": decision_status,
        "decision_context_ref": decision_context_ref,
        "allowed_submission_actions": [
            "request_more_evidence",
            "hold",
            "reject",
            "approve_with_conditions",
            "block_release",
            "unblock_release",
        ],
        "action_request": action_request,
        "formal_object_refs": formal_object_refs,
        "submission_hint": "Live submission disabled until v1.8 action backend is bound." if not live_submission_enabled else "Live submission is bound to the v1.8 action backend.",
    }


def authorize_dashboard_action(
    *,
    action_request: dict,
    required_role: str,
    allowed_actions: Iterable[str],
    read_only: bool = False,
) -> dict:
    policy_flags: list[str] = []
    action_name = str(action_request.get("action_name", ""))
    role = str(action_request.get("role", ""))

    if read_only:
        policy_flags.append("read_only_role_blocked")
    if role != required_role:
        policy_flags.append("unauthorized_role")
    if action_name not in set(allowed_actions):
        policy_flags.append("action_not_allowed")

    decision = "DENY" if policy_flags else "ALLOW"
    return {
        "authorization_id": f"dashboard-authorization::{action_request['action_request_id']}",
        "type": "dashboard_action_authorization_record",
        "schema_version": "1.8.0",
        "action_request_id": action_request["action_request_id"],
        "session_id": action_request["session_id"],
        "actor_id": action_request["actor_id"],
        "role": role,
        "decision": decision,
        "policy_flags": policy_flags,
        "evaluated_at": _iso_now(),
    }


def build_dashboard_action_audit_record(
    *,
    action_request: dict,
    authorization_record: dict,
    before_state_ref: str,
    after_state_ref: str,
    artifact_refs: list[str],
) -> dict:
    return {
        "audit_record_id": f"dashboard-audit::{action_request['action_request_id']}",
        "type": "dashboard_action_audit_record",
        "schema_version": "1.8.0",
        "action_request_id": action_request["action_request_id"],
        "authorization_id": authorization_record["authorization_id"],
        "session_id": action_request["session_id"],
        "actor_id": action_request["actor_id"],
        "before_state_ref": before_state_ref,
        "after_state_ref": after_state_ref,
        "artifact_refs": artifact_refs,
        "recorded_at": _iso_now(),
    }


def build_dashboard_action_result_record(
    *,
    action_request: dict,
    authorization_record: dict,
    audit_record: dict,
    result_status: str,
    formal_object_refs: list[str],
) -> dict:
    return {
        "action_result_id": f"dashboard-result::{action_request['action_request_id']}",
        "type": "dashboard_action_result_record",
        "schema_version": "1.8.0",
        "action_request_id": action_request["action_request_id"],
        "authorization_id": authorization_record["authorization_id"],
        "audit_record_id": audit_record["audit_record_id"],
        "result_status": result_status,
        "formal_object_refs": formal_object_refs,
        "completed_at": _iso_now(),
    }


def build_console_decision_write_record(
    *,
    action_request_id: str,
    formal_decision_ref: str,
    decision_status_before: str,
    decision_status_after: str,
    decision_type: str,
    decision_projection_ref: str,
    projection_consumer_refs: list[str] | None = None,
) -> dict:
    return {
        "decision_write_id": f"console-decision-write::{action_request_id}",
        "record_type": "console_decision_write_record",
        "schema_version": "0.1",
        "action_request_id": action_request_id,
        "formal_decision_ref": formal_decision_ref,
        "decision_status_before": decision_status_before,
        "decision_status_after": decision_status_after,
        "decision_type": decision_type,
        "decision_projection_ref": decision_projection_ref,
        "projection_consumer_refs": projection_consumer_refs or [],
        "created_at": _iso_now(),
    }


def build_dashboard_replay_trace(
    *,
    root_action_request_id: str,
    trace_chain: list[dict],
    integrity_status: str,
) -> dict:
    return {
        "replay_trace_id": f"dashboard-replay::{root_action_request_id}",
        "type": "dashboard_replay_trace",
        "schema_version": "1.8.0",
        "root_action_request_id": root_action_request_id,
        "trace_chain": trace_chain,
        "integrity_status": integrity_status,
        "generated_at": _iso_now(),
    }


def build_dashboard_fail_closed_record(
    *,
    session_id: str,
    action_request_id: str,
    reason_code: str,
    reason_detail: str,
    policy_ref: str,
) -> dict:
    return {
        "fail_closed_id": f"dashboard-fail-closed::{action_request_id}",
        "type": "dashboard_fail_closed_record",
        "schema_version": "1.8.0",
        "session_id": session_id,
        "action_request_id": action_request_id,
        "reason_code": reason_code,
        "reason_detail": reason_detail,
        "policy_ref": policy_ref,
        "triggered_at": _iso_now(),
    }


def build_dashboard_action_bundle(
    *,
    session_id: str,
    action_name: str,
    actor_id: str,
    role: str,
    target_object_refs: list[str],
    source_evidence_refs: list[str],
    decision_context_ref: str,
    required_role: str,
    allowed_actions: Iterable[str],
    before_state_ref: str,
    after_state_ref: str,
    formal_object_refs: list[str],
    artifact_refs: list[str],
    read_only: bool = False,
) -> dict:
    request = build_dashboard_action_request(
        session_id=session_id,
        action_name=action_name,
        actor_id=actor_id,
        role=role,
        target_object_refs=target_object_refs,
        source_evidence_refs=source_evidence_refs,
        decision_context_ref=decision_context_ref,
    )
    authorization = authorize_dashboard_action(
        action_request=request,
        required_role=required_role,
        allowed_actions=allowed_actions,
        read_only=read_only,
    )

    if authorization["decision"] == "DENY":
        fail_closed = build_dashboard_fail_closed_record(
            session_id=session_id,
            action_request_id=request["action_request_id"],
            reason_code="RBAC_POLICY_BLOCKED",
            reason_detail="action denied by backend policy",
            policy_ref="governance://policy/dashboard-action-rbac",
        )
        audit = build_dashboard_action_audit_record(
            action_request=request,
            authorization_record=authorization,
            before_state_ref=before_state_ref,
            after_state_ref=before_state_ref,
            artifact_refs=[*artifact_refs, f"icaf://artifact/{fail_closed['fail_closed_id']}"],
        )
        result = build_dashboard_action_result_record(
            action_request=request,
            authorization_record=authorization,
            audit_record=audit,
            result_status="BLOCKED",
            formal_object_refs=[f"icaf://artifact/{fail_closed['fail_closed_id']}"],
        )
        replay = build_dashboard_replay_trace(
            root_action_request_id=request["action_request_id"],
            trace_chain=[
                {"step": 1, "record_ref": request["action_request_id"]},
                {"step": 2, "record_ref": authorization["authorization_id"]},
                {"step": 3, "record_ref": fail_closed["fail_closed_id"]},
                {"step": 4, "record_ref": audit["audit_record_id"]},
                {"step": 5, "record_ref": result["action_result_id"]},
            ],
            integrity_status="COMPLETE",
        )
        return {
            "request": request,
            "authorization": authorization,
            "fail_closed": fail_closed,
            "audit": audit,
            "result": result,
            "replay": replay,
        }

    audit = build_dashboard_action_audit_record(
        action_request=request,
        authorization_record=authorization,
        before_state_ref=before_state_ref,
        after_state_ref=after_state_ref,
        artifact_refs=artifact_refs,
    )
    result = build_dashboard_action_result_record(
        action_request=request,
        authorization_record=authorization,
        audit_record=audit,
        result_status="SUCCESS",
        formal_object_refs=formal_object_refs,
    )
    replay = build_dashboard_replay_trace(
        root_action_request_id=request["action_request_id"],
        trace_chain=[
            {"step": 1, "record_ref": request["action_request_id"]},
            {"step": 2, "record_ref": authorization["authorization_id"]},
            {"step": 3, "record_ref": audit["audit_record_id"]},
            {"step": 4, "record_ref": result["action_result_id"]},
        ],
        integrity_status="COMPLETE",
    )
    return {
        "request": request,
        "authorization": authorization,
        "audit": audit,
        "result": result,
        "replay": replay,
    }
