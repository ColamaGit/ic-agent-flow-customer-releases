REQUIRED_DASHBOARD_TRANSLATION_KEYS = [
    "app.title",
    "nav.flow_map",
    "nav.decision_inbox",
    "nav.artifact_browser",
    "panel.package_readiness",
    "status.pass",
    "status.blocked",
    "decision.approve",
    "decision.request_more_evidence",
    "artifact.digest",
]
