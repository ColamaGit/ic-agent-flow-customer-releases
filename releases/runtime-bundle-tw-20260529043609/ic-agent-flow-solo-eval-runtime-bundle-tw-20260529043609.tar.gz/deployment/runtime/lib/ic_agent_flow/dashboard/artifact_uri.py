from dataclasses import dataclass


ARTIFACT_URI_PREFIX = "icaf://artifact/"


@dataclass(frozen=True)
class ArtifactUri:
    raw: str
    relative_path: str
    parts: list[str]


def parse_artifact_uri(uri: str) -> ArtifactUri:
    if not uri.startswith(ARTIFACT_URI_PREFIX):
        raise ValueError(f"unsupported artifact uri: {uri}")
    relative_path = uri.removeprefix(ARTIFACT_URI_PREFIX).strip("/")
    if not relative_path:
        raise ValueError("artifact uri has no path")
    return ArtifactUri(raw=uri, relative_path=relative_path, parts=relative_path.split("/"))


def logical_uri_from_relative_path(relative_path: str) -> str:
    return ARTIFACT_URI_PREFIX + relative_path.strip("/")
