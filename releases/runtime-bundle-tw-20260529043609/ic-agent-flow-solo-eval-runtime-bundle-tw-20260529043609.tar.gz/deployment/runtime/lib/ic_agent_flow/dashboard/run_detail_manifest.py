from pathlib import Path


def _artifact_uri(chip_id: str, run_id: str, date_time: str, filename: str) -> str:
    return f"icaf://artifact/production-runs/{chip_id}/{run_id}/{date_time}/dashboard_objects/{filename}"


def _derive_verification_source_lane(input_root: Path | None) -> dict:
    if input_root is None:
        return {
            "required_by_policy": False,
            "source_family": "verification_tb",
            "source_root": "verification/tb",
            "logical_input_root": "inputs/verification/tb",
            "physical_01_inputs_root": "01_inputs/verification/tb",
            "consumer_stages": ["v2_verilator_sim", "h10_power_ir_dynamic"],
            "expected_files": [],
            "missing_files": [],
            "materialized": False,
        }

    candidate_roots = [
        input_root / "01_inputs" / "verification" / "tb",
        input_root / "inputs" / "verification" / "tb",
        input_root / "verification" / "tb",
    ]
    source_root = next((root for root in candidate_roots if root.exists()), candidate_roots[0])
    file_paths = sorted(path for path in source_root.rglob("*") if path.is_file()) if source_root.exists() else []
    expected_files = []
    missing_files = []
    for path in file_paths:
        rel = path.relative_to(source_root).as_posix()
        expected_files.append(f"01_inputs/verification/tb/{rel}")
    required_by_policy = source_root.exists() and bool(file_paths)
    return {
        "required_by_policy": required_by_policy,
        "source_family": "verification_tb",
        "source_root": "verification/tb",
        "logical_input_root": "inputs/verification/tb",
        "physical_01_inputs_root": "01_inputs/verification/tb",
        "consumer_stages": ["v2_verilator_sim", "h10_power_ir_dynamic"],
        "expected_files": expected_files,
        "missing_files": missing_files,
        "materialized": required_by_policy and not missing_files,
    }


def _default_run_topology_policy() -> dict:
    return {
        "prefix_counts_are_topology_dependent": True,
        "fixed_highest_prefix_is_not_authoritative": True,
        "reports_dir_must_follow_materialized_topology": True,
    }


def build_run_detail_manifest(
    *,
    chip_id: str,
    run_id: str,
    date_time: str,
    dashboard_version: str = "v1_8",
    run_input_source_coverage: dict | None = None,
    input_root: Path | str | None = None,
    verification_source_lane: dict | None = None,
    run_topology_policy: dict | None = None,
) -> dict:
    input_root_path = Path(input_root) if input_root is not None else None
    resolved_verification_lane = verification_source_lane or _derive_verification_source_lane(input_root_path)
    manifest = {
        "manifest_id": f"run-detail-{chip_id}-{run_id}-{date_time}",
        "type": "run_detail_manifest",
        "schema_version": "1.8.0" if dashboard_version == "v1_8" else "1.7.0",
        "dashboard_version": dashboard_version,
        "chip_id": chip_id,
        "run_id": run_id,
        "date_time": date_time,
        "sections": [
            {
                "section_id": "architecture_exploration",
                "label": "Architecture Exploration Board",
                "artifact_refs": [
                    _artifact_uri(chip_id, run_id, date_time, "architecture_model_view_manifest.json"),
                    _artifact_uri(chip_id, run_id, date_time, "scenario_requirement_matrix.json"),
                    _artifact_uri(chip_id, run_id, date_time, "architecture_candidate_scorecard.json"),
                ],
            }
        ],
        "verification_source_lane": resolved_verification_lane,
        "run_topology_policy": run_topology_policy or _default_run_topology_policy(),
    }
    if run_input_source_coverage:
        verdict = str(run_input_source_coverage.get("verdict", "UNKNOWN")).upper()
        run_admission_status = "ALLOWED" if verdict == "PASS" else "BLOCKED"
        manifest["run_input_source_coverage_gate"] = {
            "verdict": verdict,
            "summary": run_input_source_coverage.get("summary", {}),
            "source_coverage_manifest_path": run_input_source_coverage.get("manifest_path", ""),
            "recovery_manifest_path": run_input_source_coverage.get("recovery_manifest_path", ""),
            "run_admission_status": run_admission_status,
            "rule": "BLOCKED_WITH_RECOVERY is never run-valid until post-recovery audit returns PASS.",
        }
    return manifest


def build_readiness_manifest(
    *,
    chip_id: str,
    run_id: str,
    date_time: str,
    dashboard_version: str = "v1_8",
    run_input_source_coverage: dict | None = None,
) -> dict:
    manifest = {
        "manifest_id": f"readiness-{chip_id}-{run_id}-{date_time}",
        "type": "readiness_manifest",
        "schema_version": "1.8.0" if dashboard_version == "v1_8" else "1.7.0",
        "dashboard_version": dashboard_version,
        "chip_id": chip_id,
        "run_id": run_id,
        "date_time": date_time,
        "readiness_sections": [
            {
                "section_id": "architecture_pre_spec_readiness",
                "label": "Architecture / Scenario Readiness",
                "artifact_refs": [
                    _artifact_uri(chip_id, run_id, date_time, "scenario_requirement_matrix.json"),
                    _artifact_uri(chip_id, run_id, date_time, "architecture_candidate_scorecard.json"),
                ],
            }
        ],
        "claim_boundary": "Derived readiness summary only; canonical truth remains governed artifacts and evidence records.",
    }
    if run_input_source_coverage:
        verdict = str(run_input_source_coverage.get("verdict", "UNKNOWN")).upper()
        manifest["run_input_source_coverage_gate"] = {
            "verdict": verdict,
            "run_admission_status": "ALLOWED" if verdict == "PASS" else "BLOCKED",
            "summary": run_input_source_coverage.get("summary", {}),
        }
    return manifest
