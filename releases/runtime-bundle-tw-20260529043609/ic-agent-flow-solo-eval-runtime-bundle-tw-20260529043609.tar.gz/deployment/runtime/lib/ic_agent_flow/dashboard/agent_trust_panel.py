from __future__ import annotations

from datetime import datetime, timezone


def _iso_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def build_agent_trust_panel_view(
    *,
    chip_id: str,
    run_id: str,
    execution: str,
    final_readiness_status: str,
    admission_verdict: str,
    execution_plane: str = "local_runner",
) -> dict:
    panel_id = f"agent-trust-panel::{chip_id}::{run_id}::{execution}"
    return {
        "panel_id": panel_id,
        "view_mode": "READ_ONLY",
        "agent_or_skill_name": "signoff_tapeout_silicon_reports",
        "execution_plane": execution_plane,
        "input_contract_ref": "dashboard_objects/signoff_domain_matrix.json",
        "output_contract_ref": "dashboard_objects/final_tapeout_readiness_record.json",
        "evidence_refs": [
            "dashboard_objects/signoff_gap_record.json",
            "dashboard_objects/final_tapeout_readiness_record.json",
            "dashboard_objects/ai_artifact_admission_record.json",
        ],
        "risk_boundary_refs": [
            f"READINESS_STATUS::{final_readiness_status}",
            f"AI_ADMISSION_VERDICT::{admission_verdict}",
        ],
        "human_action_refs": [
            "approve",
            "reject",
            "rerun",
            "waive",
            "request_more_evidence",
        ],
        "replay_ref": f"python3 package_ws/shared-runtime/scripts/apply_agent_trust_panel_action.py --run-dir artifacts/production-runs/{chip_id}/{run_id}/{execution} --action request_more_evidence --actor-role RELEASE_AUTHORITY --binding-id auto",
        "generated_at": _iso_now(),
    }


def build_agent_trust_panel_action_binding(
    *,
    panel_ref: str,
    source_skill_ref: str,
    source_invocation_ref: str,
    requested_action: str,
) -> dict:
    binding_id = f"agent-trust-binding::{source_invocation_ref}"
    return {
        "binding_id": binding_id,
        "panel_ref": panel_ref,
        "source_skill_ref": source_skill_ref,
        "source_invocation_ref": source_invocation_ref,
        "requested_action": requested_action,
        "dashboard_action_request_ref": "dashboard_objects/dashboard_action_request.json",
        "authorization_record_ref": "dashboard_objects/dashboard_action_authorization_record.json",
        "audit_record_ref": "dashboard_objects/dashboard_action_audit_record.json",
        "result_record_ref": "dashboard_objects/dashboard_action_result_record.json",
        "replay_trace_ref": "dashboard_objects/dashboard_replay_trace.json",
        "status": "REQUESTED",
        "generated_at": _iso_now(),
    }
