from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


FORBIDDEN_CLAIMS = [
    "TAPEOUT_RELEASED",
    "FOUNDRY_ACCEPTED",
    "MASS_PRODUCTION_READY",
    "PRODUCT_READY",
]


def _iso_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _iso_from_execution(execution: str) -> str:
    if len(execution) == 15 and execution[8] == "-":
        return f"{execution[:4]}-{execution[4:6]}-{execution[6:8]}T{execution[9:11]}:{execution[11:13]}:{execution[13:15]}Z"
    return _iso_now()


def _load_json_if_exists(path: Path) -> dict[str, Any] | None:
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None
    return data if isinstance(data, dict) else None


def build_v115_claim_boundary(*, chip_id: str, run_id: str, execution: str) -> dict[str, Any]:
    return {
        "schema_version": "v1.15",
        "type": "claim_boundary",
        "chip_id": chip_id,
        "run_id": run_id,
        "execution": execution,
        "generated_at": _iso_from_execution(execution),
        "allowed_authoritative_claims": [
            "SILICON_FEEDBACK_CAPTURED",
            "BRINGUP_PARTIAL",
            "BRINGUP_BLOCKED",
            "SILICON_PROVEN_BOUNDED",
        ],
        "forbidden_claims": FORBIDDEN_CLAIMS,
        "must_require_evidence_for_silicon_proven": True,
    }


def evaluate_v115_claim_guard_text(text: str) -> dict[str, Any]:
    upper = (text or "").upper()
    matches = [token for token in FORBIDDEN_CLAIMS if token in upper]
    return {
        "status": "BLOCKED" if matches else "PASS",
        "matched_forbidden_claims": matches,
    }


def build_v115_sample_records(*, chip_id: str, run_id: str, execution: str) -> dict[str, Any]:
    sample_id = f"{chip_id}-{execution}-ES1"
    return {
        "silicon_sample_record": {
            "schema_version": "v1.15",
            "sample_id": sample_id,
            "chip_id": chip_id,
            "run_id": run_id,
            "execution": execution,
            "silicon_revision": "ES1",
            "lot_id": "LOT-001",
            "die_id": "DIE-001",
            "package_id": "PKG-001",
            "board_id": "BOARD-001",
            "handoff_package_ref": f"icaf://tapeout-package/{chip_id}/{run_id}/{execution}",
            "status": "REGISTERED",
            "generated_at": _iso_from_execution(execution),
        },
        "sample_custody_record": {
            "schema_version": "v1.15",
            "sample_id": sample_id,
            "received_by": "lab_operator",
            "received_at": _iso_from_execution(execution),
            "custody_status": "CUSTODY_VERIFIED",
            "notes": "initial intake",
        },
    }


def build_v115_lab_records(*, chip_id: str, run_id: str, execution: str) -> dict[str, Any]:
    sample_id = f"{chip_id}-{execution}-ES1"
    return {
        "bringup_plan": {
            "schema_version": "v1.15",
            "plan_id": f"bringup-{chip_id}-{execution}",
            "chip_id": chip_id,
            "run_id": run_id,
            "execution": execution,
            "sample_id": sample_id,
            "status": "APPROVED",
        },
        "lab_setup_record": {
            "schema_version": "v1.15",
            "sample_id": sample_id,
            "board_revision": "REV-A",
            "operator": "lab_operator",
            "environment": {
                "temperature_c": 25,
                "voltage_v": 0.8,
                "clock_mhz": 500,
            },
            "generated_at": _iso_from_execution(execution),
        },
        "measurement_record": {
            "schema_version": "v1.15",
            "measurement_id": f"meas-{chip_id}-{execution}",
            "sample_id": sample_id,
            "operator": "lab_operator",
            "instrument": "scope-001",
            "expected_range": "0.75-0.85",
            "observed_value": "0.80",
            "unit": "V",
            "verdict": "PASS",
            "raw_capture_ref": "icaf://raw/scope_capture_001",
            "generated_at": _iso_from_execution(execution),
        },
    }


def build_v115_bringup_records(*, chip_id: str, run_id: str, execution: str) -> dict[str, Any]:
    sample_id = f"{chip_id}-{execution}-ES1"
    return {
        "power_on_record": {
            "schema_version": "v1.15",
            "sample_id": sample_id,
            "result": "PASS",
            "evidence_ref": "icaf://evidence/power_on",
            "generated_at": _iso_from_execution(execution),
        },
        "functional_bringup_result": {
            "schema_version": "v1.15",
            "sample_id": sample_id,
            "test_id": "functional_smoke",
            "result": "PASS",
            "evidence_ref": "icaf://evidence/functional_smoke",
            "generated_at": _iso_from_execution(execution),
        },
        "silicon_validation_result": {
            "schema_version": "v1.15",
            "sample_id": sample_id,
            "overall_verdict": "PASS",
            "generated_at": _iso_from_execution(execution),
        },
    }


def build_v115_errata_eco_records(
    *,
    chip_id: str,
    run_id: str,
    execution: str,
    evidence_root: Path | None = None,
) -> dict[str, Any]:
    mismatch_id = f"mismatch-{chip_id}-{execution}-001"
    mismatch_default = {
        "schema_version": "v1.15",
        "mismatch_id": mismatch_id,
        "expected_behavior": "NOT_EVALUATED",
        "observed_behavior": "NOT_EVALUATED",
        "status": "NOT_EVALUATED",
        "source_mode": "TEMPLATE_DEFAULT",
        "notes": "No evidence-backed silicon mismatch input; keep fail-closed without asserting OPEN mismatch.",
        "generated_at": _iso_from_execution(execution),
    }
    eco_default = {
        "schema_version": "v1.15",
        "eco_id": f"eco-candidate-{chip_id}-{execution}-001",
        "decision": "NOT_EVALUATED",
        "decided_by": "NOT_EVALUATED",
        "source_mode": "TEMPLATE_DEFAULT",
        "generated_at": _iso_from_execution(execution),
    }
    mismatch_record = mismatch_default
    eco_decision_record = eco_default
    if evidence_root:
        loaded_mismatch = _load_json_if_exists(evidence_root / "v115_silicon_mismatch_record.json")
        loaded_eco = _load_json_if_exists(evidence_root / "v115_eco_decision_record.json")
        if loaded_mismatch:
            loaded_mismatch.setdefault("source_mode", "EVIDENCE_INPUT")
            mismatch_record = loaded_mismatch
        if loaded_eco:
            loaded_eco.setdefault("source_mode", "EVIDENCE_INPUT")
            eco_decision_record = loaded_eco
    return {
        "silicon_mismatch_record": mismatch_record,
        "silicon_errata_record": {
            "schema_version": "v1.15",
            "errata_id": f"errata-{chip_id}-{execution}-001",
            "linked_mismatch_id": str(mismatch_record.get("mismatch_id", mismatch_id)),
            "impact": "medium",
            "workaround": "apply reset hold extension",
            "status": "NOT_EVALUATED" if mismatch_record.get("status") == "NOT_EVALUATED" else "OPEN",
            "generated_at": _iso_from_execution(execution),
        },
        "eco_candidate_record": {
            "schema_version": "v1.15",
            "eco_id": f"eco-candidate-{chip_id}-{execution}-001",
            "reason": "pending evidence-backed mismatch adjudication",
            "status": "NOT_EVALUATED" if mismatch_record.get("status") == "NOT_EVALUATED" else "CANDIDATE_ONLY",
            "generated_at": _iso_from_execution(execution),
        },
        "eco_decision_record": eco_decision_record,
    }


def build_v115_backflow_records(*, chip_id: str, run_id: str, execution: str) -> dict[str, Any]:
    return {
        "knowledge_backflow_record": {
            "schema_version": "v1.15",
            "record_id": f"knowledge-backflow-{chip_id}-{execution}",
            "target": "design_spec",
            "recommendation": "tighten reset sequencing constraints",
            "status": "CANDIDATE",
            "generated_at": _iso_from_execution(execution),
        },
        "skill_backflow_record": {
            "schema_version": "v1.15",
            "record_id": f"skill-backflow-{chip_id}-{execution}",
            "target": "verification_plan",
            "recommendation": "add reset jitter lab-derived case",
            "status": "CANDIDATE",
            "generated_at": _iso_from_execution(execution),
        },
    }


def evaluate_v115_resignoff_escalation(
    *,
    silicon_validation_result: dict[str, Any] | None,
    silicon_mismatch_record: dict[str, Any] | None,
    eco_decision_record: dict[str, Any] | None,
) -> dict[str, Any]:
    """Evaluate whether v1.15 findings must escalate back to v1.13 re-signoff."""
    reasons: list[str] = []

    bringup_verdict = str((silicon_validation_result or {}).get("overall_verdict", "")).upper()
    if not silicon_validation_result or bringup_verdict != "PASS":
        reasons.append("SILICON_VALIDATION_NOT_PASS")

    mismatch_status = str((silicon_mismatch_record or {}).get("status", "")).upper()
    mismatch_source_mode = str((silicon_mismatch_record or {}).get("source_mode", "")).upper()
    mismatch_is_evidence_backed = mismatch_source_mode == "EVIDENCE_INPUT"
    if mismatch_status in {"OPEN", "BLOCKED", "ESCALATED"} and mismatch_is_evidence_backed:
        reasons.append("OPEN_SILICON_MISMATCH_PRESENT")

    eco_decision = str((eco_decision_record or {}).get("decision", "")).upper()
    eco_source_mode = str((eco_decision_record or {}).get("source_mode", "")).upper()
    eco_is_evidence_backed = eco_source_mode == "EVIDENCE_INPUT"
    if eco_decision in {"HOLD", "REJECT", "", "NOT_EVALUATED"} and (mismatch_is_evidence_backed or eco_is_evidence_backed):
        reasons.append("ECO_DECISION_NOT_APPROVED")

    required = len(reasons) > 0
    return {
        "required": required,
        "status": "ESCALATION_REQUIRED" if required else "NO_ESCALATION_REQUIRED",
        "reason_codes": reasons,
        "target_phase": "PRD_v1.13_RE_SIGNOFF",
    }


def build_v115_resignoff_escalation_record(
    *,
    chip_id: str,
    run_id: str,
    execution: str,
    silicon_validation_result: dict[str, Any] | None,
    silicon_mismatch_record: dict[str, Any] | None,
    eco_decision_record: dict[str, Any] | None,
) -> dict[str, Any]:
    escalation = evaluate_v115_resignoff_escalation(
        silicon_validation_result=silicon_validation_result,
        silicon_mismatch_record=silicon_mismatch_record,
        eco_decision_record=eco_decision_record,
    )
    return {
        "schema_version": "v1.15",
        "type": "resignoff_escalation_record",
        "chip_id": chip_id,
        "run_id": run_id,
        "execution": execution,
        "status": escalation["status"],
        "required": escalation["required"],
        "reason_codes": escalation["reason_codes"],
        "target_phase": escalation["target_phase"],
        "next_required_action": "open_v1_13_resignoff_inbox" if escalation["required"] else "none",
        "generated_at": _iso_from_execution(execution),
    }


def build_v115_silicon_proven_claim_record(*, chip_id: str, run_id: str, execution: str) -> dict[str, Any]:
    return {
        "schema_version": "v1.15",
        "type": "silicon_proven_claim_record",
        "chip_id": chip_id,
        "run_id": run_id,
        "execution": execution,
        "status": "BLOCKED",
        "authoritative": False,
        "claim_class": "SILICON_PROVEN_BOUNDED",
        "blocking_reasons": ["PENDING_ECO_DECISION", "PENDING_FINAL_REVIEW"],
        "generated_at": _iso_from_execution(execution),
    }


def evaluate_v115_silicon_proven_gate(
    *,
    bringup_result: dict[str, Any] | None,
    eco_decision: dict[str, Any] | None,
    v114_lineage_ref: str | None,
) -> dict[str, Any]:
    """Authoritative hard gate for silicon_proven_claim_record.

    All three conditions must pass before status may be elevated to
    SILICON_PROVEN_BOUNDED.  Any failure returns BLOCKED with an explicit
    list of blocking_reasons so that the UI and tests can assert exact
    failure modes rather than relying on implicit behaviour.

    Args:
        bringup_result: The ``silicon_validation_result`` object from Phase 3.
        eco_decision:   The ``eco_decision_record`` object from Phase 4.
        v114_lineage_ref: An icaf:// or non-empty string referencing the
            upstream v1.14 tapeout-package artifact.  ``None`` or ``""``
            means the lineage has not been established.

    Returns:
        A gate result dict with keys ``gate``, ``status``, and
        ``blocking_reasons``.
    """
    blocking_reasons: list[str] = []

    # Gate 1 – bringup evidence must exist and be PASS
    bringup_verdict = str((bringup_result or {}).get("overall_verdict", "")).upper()
    if not bringup_result or bringup_verdict != "PASS":
        blocking_reasons.append("BRINGUP_EVIDENCE_MISSING_OR_NOT_PASS")

    # Gate 2 – ECO decision must be APPROVE (not HOLD / REJECT / missing)
    eco_decision_val = str((eco_decision or {}).get("decision", "")).upper()
    if not eco_decision or eco_decision_val != "APPROVE":
        blocking_reasons.append("ECO_DECISION_NOT_APPROVED")

    # Gate 3 – v1.14 lineage reference must be present
    if not v114_lineage_ref or not str(v114_lineage_ref).strip():
        blocking_reasons.append("V114_LINEAGE_NOT_ESTABLISHED")

    status = "PASS" if not blocking_reasons else "BLOCKED"
    return {
        "gate": "silicon_proven_claim_gate",
        "gate_version": "v1.15_authoritative_v1",
        "status": status,
        "blocking_reasons": blocking_reasons,
    }


def build_v115_audit_bundle(*, chip_id: str, run_id: str, execution: str, input_root: Path) -> dict[str, Any]:
    records = [p.relative_to(input_root).as_posix() for p in input_root.rglob("*") if p.is_file()]
    return {
        "schema_version": "v1.15",
        "bundle_id": f"post-tapeout-audit-{chip_id}-{run_id}-{execution}",
        "chip_id": chip_id,
        "run_id": run_id,
        "execution": execution,
        "artifact_refs": sorted(records)[:500],
        "reconstruction_status": "PASS" if records else "PASS_WITH_WARNINGS",
        "generated_at": _iso_from_execution(execution),
    }


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
