from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


def _iso_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def _save(path: Path, payload: dict) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def _write_action_record(out_dir: Path, *, action_id: str, actor_role: str, result: str, notes: str) -> None:
    rec_dir = out_dir / "signoff_action_records"
    rec_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    payload = {
        "schema_version": "v1.13",
        "type": "signoff_action_record",
        "action_id": action_id,
        "actor_role": actor_role,
        "result": result,
        "notes": notes,
        "generated_at": _iso_now(),
    }
    _save(rec_dir / f"{ts}_{action_id}.json", payload)


def apply_signoff_action(out_dir: Path, *, action_id: str, actor_role: str) -> None:
    waiver_path = out_dir / "waiver_approval_record.json"
    risk_path = out_dir / "risk_acceptance_record.json"
    gap_path = out_dir / "signoff_gap_record.json"
    authority_path = out_dir / "authority_chain_verdict.json"
    draft_path = out_dir / "tapeout_readiness_record.draft.json"
    final_path = out_dir / "final_tapeout_readiness_record.json"
    closure_final_path = out_dir / "final_signoff_closure_report.json"
    binding_path = out_dir / "silicon_contract_v113_binding_record.json"

    if action_id == "approve_waiver":
        waiver = _load(waiver_path)
        waiver["status"] = "APPROVED"
        waiver["approved_by_role"] = actor_role
        waiver["approved_at"] = _iso_now()
        _save(waiver_path, waiver)
        _write_action_record(out_dir, action_id=action_id, actor_role=actor_role, result="DONE", notes="waiver approved")
        return

    if action_id == "accept_risk":
        risk = _load(risk_path)
        risk["status"] = "ACCEPTED"
        risk["accepted_by_role"] = actor_role
        risk["accepted_at"] = _iso_now()
        _save(risk_path, risk)
        _write_action_record(out_dir, action_id=action_id, actor_role=actor_role, result="DONE", notes="risk accepted")
        return

    if action_id == "finalize_tapeout_readiness":
        gap = _load(gap_path)
        authority = _load(authority_path)
        draft = _load(draft_path)
        binding = _load(binding_path)

        gap_ok = str(gap.get("status", "")).upper() == "PASS"
        auth_ok = str(authority.get("status", "")).upper() == "PASS"
        binding_ok = bool(binding.get("binding_valid", False))
        draft_ok = str(draft.get("status", "")).upper() == "READY_FOR_TAPEOUT_PACKAGE_ASSEMBLY_CANDIDATE"

        if gap_ok and auth_ok and binding_ok and draft_ok:
            final_status = "READY_FOR_TAPEOUT_PACKAGE_ASSEMBLY"
            authoritative = True
            reasons = []
        else:
            final_status = "BLOCKED"
            authoritative = False
            reasons = []
            if not gap_ok:
                reasons.append("GAP_NOT_CLOSED")
            if not auth_ok:
                reasons.append("AUTHORITY_NOT_CLOSED")
            if not binding_ok:
                reasons.append("BINDING_INVALID")
            if not draft_ok:
                reasons.append("DRAFT_NOT_READY")

        final = _load(final_path)
        final["status"] = final_status
        final["authoritative"] = authoritative
        final["blocking_reasons"] = reasons
        final["finalized_by_role"] = actor_role
        final["finalized_at"] = _iso_now()
        _save(final_path, final)

        closure = _load(closure_final_path)
        closure["status"] = final_status
        closure["blocking_reasons"] = reasons
        closure["finalized_by_role"] = actor_role
        closure["finalized_at"] = _iso_now()
        _save(closure_final_path, closure)

        _write_action_record(
            out_dir,
            action_id=action_id,
            actor_role=actor_role,
            result="DONE" if final_status == "READY_FOR_TAPEOUT_PACKAGE_ASSEMBLY" else "BLOCKED",
            notes=",".join(reasons) if reasons else "ready finalized",
        )
        return

    if action_id == "request_revalidation_for_blocked_claims":
        final = _load(final_path)
        reasons = list(final.get("blocking_reasons", []))
        if "REVALIDATION_REQUESTED" not in reasons:
            reasons.append("REVALIDATION_REQUESTED")
        final["status"] = "BLOCKED"
        final["authoritative"] = False
        final["blocking_reasons"] = reasons
        final["revalidation_requested_by_role"] = actor_role
        final["revalidation_requested_at"] = _iso_now()
        _save(final_path, final)

        closure = _load(closure_final_path)
        closure["status"] = "BLOCKED"
        closure["blocking_reasons"] = reasons
        closure["revalidation_requested_by_role"] = actor_role
        closure["revalidation_requested_at"] = _iso_now()
        _save(closure_final_path, closure)

        _write_action_record(
            out_dir,
            action_id=action_id,
            actor_role=actor_role,
            result="DONE",
            notes="revalidation requested for blocked claims",
        )
        return

    raise ValueError(f"unsupported action_id: {action_id}")
