from pathlib import Path


VARIANTS = ["solo_eval", "team_project", "enterprise_site"]

V16_RELEASE_GATES = [
    "distribution_content_manifest",
    "source_exclusion_report",
    "vendor_ip_leak_scan_report",
    "docs_gate_report",
    "eda_toolchain_preflight_report",
    "backend_secret_binding_report",
    "qa_trust_report",
]

V15_ACTIVATION_GATES = [
    "site_readiness_report",
    "activation_decision_record",
]

REQUIRED_GATES = [*V16_RELEASE_GATES, *V15_ACTIVATION_GATES]

V18_LIVE_CONSOLE_GATES = [
    "selector_persistence_report",
    "rbac_route_action_guard_report",
    "dashboard_action_audit_report",
    "audit_replay_integrity_report",
    "console_package_release_qa_audit_report",
]

REQUIRED_GATES_V18 = [*REQUIRED_GATES, *V18_LIVE_CONSOLE_GATES]


def collect_package_gates(*, input_root: Path, variant: str, required_gates: list[str] | None = None) -> list[dict]:
    variant_root = Path(input_root) / variant
    results = []
    gates = required_gates or REQUIRED_GATES
    for gate_id in gates:
        gate_path = variant_root / f"{gate_id}.json"
        if gate_path.exists():
            verdict = "pass"
            evidence_ref = f"icaf://artifact/package-readiness/{variant}/{gate_id}.json"
        else:
            verdict = "blocked"
            evidence_ref = f"icaf://artifact/package-readiness/{variant}/missing/{gate_id}.json"
        results.append(
            {
                "gate_id": gate_id,
                "verdict": verdict,
                "evidence_ref": evidence_ref,
            }
        )
    return results
