from datetime import datetime, timezone
import re

from .v18_authority_guard import (
    acquire_mutation_lock,
    evaluate_declare_release_ready_precheck,
    is_session_stale,
)


_DEV_ABS_PATH_PATTERNS = (
    re.compile(r"/customer-home/[^/\s]+/"),
    re.compile(r"/customer-home/[^/\s]+/"),
    re.compile(r"[A-Za-z]:\\Users\\"),
)


def _contains_developer_absolute_path(payload: str) -> bool:
    return any(pattern.search(payload) for pattern in _DEV_ABS_PATH_PATTERNS)


def apply_dashboard_action(*, item: dict, actor_id: str, actor_roles: list[str], action_type: str) -> dict:
    policy_flags = []
    if item["authority_role"] not in actor_roles:
        policy_flags.append("unauthorized_role")
    if action_type not in item["allowed_actions"]:
        policy_flags.append("action_not_allowed")

    result = "blocked_by_policy" if policy_flags else "recorded"
    return {
        "action_id": f"dashboard-action-{item['item_id']}-{action_type}-{actor_id}",
        "type": "dashboard_action_record",
        "schema_version": "1.7.0",
        "actor_id": actor_id,
        "actor_roles": actor_roles,
        "action_type": action_type,
        "target_ref": item["item_id"],
        "formal_decision_ref": item["formal_decision_ref"],
        "created_at": datetime.now(timezone.utc).isoformat(),
        "result": result,
        "policy_flags": policy_flags,
    }


def apply_dashboard_action_v18(
    *,
    item: dict,
    actor_id: str,
    actor_roles: list[str],
    action_type: str,
    session_created_at: str,
    lock_state: dict[str, str] | None = None,
    gate_verdicts: dict[str, str] | None = None,
    authority_closure_complete: bool = True,
    replay_chain_integrity: str = "COMPLETE",
    current_package_mode: str | None = None,
    current_chip_id: str | None = None,
    current_run_id: str | None = None,
    required_evidence_refs: list[str] | None = None,
    available_evidence_refs: list[str] | None = None,
    enforce_api_authorization: bool = False,
    api_authorized: bool = True,
    before_state: dict | None = None,
    after_state: dict | None = None,
    customer_visible_payload: str | None = None,
) -> dict:
    policy_flags: list[str] = []
    mutation_actions = {
        "approve",
        "approve_with_conditions",
        "hold",
        "reject",
        "request_more_evidence",
        "escalate",
        "acknowledge_open_risk",
        "block_release",
        "unblock_release",
        "return_to_evidence_completion",
        "declare_release_ready_precheck",
    }
    state_mutation_actions = mutation_actions - {"declare_release_ready_precheck"}

    if "read_only" in actor_roles and action_type in mutation_actions:
        policy_flags.append("read_only_role_blocked")
    if item["authority_role"] not in actor_roles:
        policy_flags.append("unauthorized_role")
    if action_type not in item["allowed_actions"]:
        policy_flags.append("action_not_allowed")
    if is_session_stale(created_at=session_created_at):
        policy_flags.append("stale_session_blocked")

    if action_type in state_mutation_actions and (not current_package_mode):
        policy_flags.append("mode_context_missing")

    if current_chip_id and item.get("chip_id") and current_chip_id != item["chip_id"]:
        policy_flags.append("chip_selector_mismatch_blocked")
    if current_run_id and item.get("run_id") and current_run_id != item["run_id"]:
        policy_flags.append("run_selector_mismatch_blocked")

    object_status = str(item.get("object_status", "active")).lower()
    if object_status in {"superseded", "revoked"}:
        policy_flags.append(f"object_{object_status}_blocked")

    if action_type == "approve":
        required = set(required_evidence_refs or [])
        available = set(available_evidence_refs or [])
        if required and not required.issubset(available):
            policy_flags.append("required_evidence_missing")

    if action_type == "unblock_release":
        item_package_mode = item.get("package_mode") or item.get("profile")
        if current_package_mode and item_package_mode and current_package_mode != item_package_mode:
            policy_flags.append("package_mode_mismatch_blocked")

    if enforce_api_authorization and action_type in state_mutation_actions and not api_authorized:
        policy_flags.append("api_authorization_denied")

    if action_type in {"approve", "unblock_release"}:
        if before_state is None or after_state is None:
            policy_flags.append("replay_before_after_missing")

    if customer_visible_payload and _contains_developer_absolute_path(customer_visible_payload):
        policy_flags.append("developer_path_leakage_detected")

    if lock_state is not None and "chip_id" in item and "run_id" in item:
        lock_key = f"{item['chip_id']}::{item['run_id']}"
        acquired, owner = acquire_mutation_lock(
            lock_state=lock_state,
            lock_key=lock_key,
            actor_id=actor_id,
        )
        if not acquired:
            policy_flags.append("concurrent_mutation_blocked")
            if owner:
                policy_flags.append(f"lock_owned_by:{owner}")

    if action_type == "declare_release_ready_precheck":
        ok, precheck_flags = evaluate_declare_release_ready_precheck(
            gate_verdicts=gate_verdicts or {},
            authority_closure_complete=authority_closure_complete,
            replay_chain_integrity=replay_chain_integrity,
        )
        if not ok:
            policy_flags.extend(precheck_flags)

    result = "blocked_by_policy" if policy_flags else "recorded"
    return {
        "action_id": f"dashboard-action-v18-{item['item_id']}-{action_type}-{actor_id}",
        "type": "dashboard_action_record",
        "schema_version": "1.8.0",
        "dashboard_version": "v1_8",
        "actor_id": actor_id,
        "actor_roles": actor_roles,
        "action_type": action_type,
        "target_ref": item["item_id"],
        "formal_decision_ref": item["formal_decision_ref"],
        "created_at": datetime.now(timezone.utc).isoformat(),
        "result": result,
        "policy_flags": policy_flags,
    }
