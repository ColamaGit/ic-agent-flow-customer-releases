import hashlib
import json


def evaluate_quorum(
    *,
    required_roles: list[str],
    approvals_by_role: dict[str, bool],
) -> tuple[bool, list[str]]:
    missing = [role for role in required_roles if not approvals_by_role.get(role, False)]
    return (len(missing) == 0, missing)


def build_cross_site_replay_trace(
    *,
    action_chain: list[dict],
    source_site: str,
    target_site: str,
) -> dict:
    canonical = json.dumps(action_chain, sort_keys=True, separators=(",", ":"))
    digest = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
    return {
        "type": "cross_site_replay_trace",
        "schema_version": "1.8.0",
        "source_site": source_site,
        "target_site": target_site,
        "action_count": len(action_chain),
        "deterministic_digest": digest,
    }
