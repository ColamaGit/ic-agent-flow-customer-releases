def validate_node_io_manifest(manifest: dict) -> dict:
    missing_nodes = [
        item["node_id"]
        for item in manifest.get("node_manifests", [])
        if item.get("verdict") == "blocked"
    ]
    return {
        "verdict": "blocked" if missing_nodes else "pass",
        "blocked_nodes": missing_nodes,
    }
