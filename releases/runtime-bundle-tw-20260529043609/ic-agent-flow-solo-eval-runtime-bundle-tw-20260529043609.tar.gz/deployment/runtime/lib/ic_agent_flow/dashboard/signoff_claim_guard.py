from __future__ import annotations

from datetime import datetime, timezone


FORBIDDEN_CLAIMS = [
    "TAPEOUT_RELEASED",
    "FOUNDRY_ACCEPTED",
    "SILICON_PROVEN",
]


def _generated_at_from_date_time(date_time: str) -> str:
    try:
        dt = datetime.strptime(date_time, "%Y%m%d-%H%M%S").replace(tzinfo=timezone.utc)
        return dt.isoformat().replace("+00:00", "Z")
    except ValueError:
        return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def build_claim_guard_policy(*, chip_id: str, run_id: str, date_time: str) -> dict:
    return {
        "schema_version": "v1.13",
        "type": "claim_guard_policy",
        "chip_id": chip_id,
        "run_id": run_id,
        "date_time": date_time,
        "generated_at": _generated_at_from_date_time(date_time),
        "forbidden_claims": list(FORBIDDEN_CLAIMS),
        "allowed_boundary_claims": [
            "READY_FOR_TAPEOUT_PACKAGE_ASSEMBLY",
            "PASS_WITH_LIMITATIONS",
            "BLOCKED",
        ],
        "authoritative_readiness_claim": "READY_FOR_TAPEOUT_PACKAGE_ASSEMBLY",
        "non_authoritative_surface_rule": "derived_surface_only",
    }


def build_forbidden_claim_test_matrix(*, chip_id: str, run_id: str, date_time: str) -> dict:
    return {
        "schema_version": "v1.13",
        "type": "forbidden_claim_test_matrix",
        "chip_id": chip_id,
        "run_id": run_id,
        "date_time": date_time,
        "generated_at": _generated_at_from_date_time(date_time),
        "negative_cases": [
            {
                "case_id": "forbidden_claim_tapeout_released",
                "forbidden_token": "TAPEOUT_RELEASED",
                "expected_status": "BLOCKED",
            },
            {
                "case_id": "forbidden_claim_foundry_accepted",
                "forbidden_token": "FOUNDRY_ACCEPTED",
                "expected_status": "BLOCKED",
            },
            {
                "case_id": "forbidden_claim_silicon_proven",
                "forbidden_token": "SILICON_PROVEN",
                "expected_status": "BLOCKED",
            },
        ],
    }


def evaluate_claim_guard_text(text: str) -> dict:
    upper_text = (text or "").upper()
    matches = [token for token in FORBIDDEN_CLAIMS if token in upper_text]
    return {
        "status": "BLOCKED" if matches else "PASS",
        "matched_forbidden_claims": matches,
    }
