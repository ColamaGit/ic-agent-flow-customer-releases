from __future__ import annotations

import json
from typing import Any, Callable, Dict, Tuple
from urllib.parse import parse_qs, urlparse


JsonObj = Dict[str, Any]
Processor = Callable[[JsonObj], JsonObj]


def _error_response(exc: Exception) -> Tuple[int, JsonObj]:
    if isinstance(exc, FileNotFoundError):
        return 404, {"error": str(exc)}
    if isinstance(exc, PermissionError):
        return 403, {"error": str(exc)}
    if isinstance(exc, ValueError):
        return 400, {"error": str(exc)}
    return 500, {"error": f"internal_error:{exc}"}


def handle_get_request(path: str, routes: Dict[str, Callable[..., JsonObj]]) -> Tuple[int, JsonObj]:
    try:
        portfolio_route = routes["resolve_portfolio_inventory_route"](path)
    except ValueError:
        portfolio_route = {}

    try:
        if portfolio_route.get("layer") == "run_detail":
            result = routes["process_portfolio_run_detail_payload"](
                {"source_dir": portfolio_route["source_dir"], "run_id": portfolio_route["run_id"]}
            )
            return 200, result
        if portfolio_route.get("layer") == "chip_runs":
            result = routes["process_portfolio_chip_runs_payload"]({"source_dir": portfolio_route["source_dir"]})
            return 200, result
        if portfolio_route.get("layer") == "chips":
            result = routes["process_portfolio_chips_payload"]()
            return 200, result

        if path.startswith("/api/intake/adjudication"):
            parsed = urlparse(path)
            query = parse_qs(parsed.query)
            chip_id = str((query.get("chip_id") or [""])[0])
            return 200, routes["process_requirement_adjudication_context_payload"]({"chip_id": chip_id})
        if path.startswith("/api/intake/chips"):
            return 200, routes["process_upstream_chip_inventory_payload"]()
        if path.startswith("/api/intake/session"):
            parsed = urlparse(path)
            query = parse_qs(parsed.query)
            chip_id = str((query.get("chip_id") or [""])[0])
            intake_session_id = str((query.get("intake_session_id") or [""])[0])
            return 200, routes["process_intake_session_context_payload"](
                {"chip_id": chip_id, "intake_session_id": intake_session_id}
            )
        if path.startswith("/api/intake/upstream-files"):
            parsed = urlparse(path)
            query = parse_qs(parsed.query)
            chip_id = str((query.get("chip_id") or [""])[0])
            return 200, routes["process_upstream_file_family_payload"]({"chip_id": chip_id})
        if path.startswith("/api/intake/upstream-node-status"):
            parsed = urlparse(path)
            query = parse_qs(parsed.query)
            chip_id = str((query.get("chip_id") or [""])[0])
            return 200, routes["process_upstream_node_status_payload"]({"chip_id": chip_id})
        if path.startswith("/api/intake/options"):
            return 200, routes["build_options_payload"]()
        if path.startswith("/api/console/decision-state"):
            parsed = urlparse(path)
            query = parse_qs(parsed.query)
            payload = {key: str((values or [""])[0]) for key, values in query.items()}
            return 200, routes["process_console_decision_state_payload"](payload)
        if path.startswith("/api/console/audit-replay"):
            parsed = urlparse(path)
            query = parse_qs(parsed.query)
            payload = {key: str((values or [""])[0]) for key, values in query.items()}
            return 200, routes["process_console_audit_replay_payload"](payload)
        return 404, {"error": "not_found"}
    except Exception as exc:  # pragma: no cover - defensive runtime fallback
        return _error_response(exc)


def handle_post_request(
    path: str,
    headers: Dict[str, str],
    read_body: Callable[[int], bytes],
    routes: Dict[str, Processor],
) -> Tuple[int, JsonObj]:
    if path not in {
        "/api/intake",
        "/api/intake/adjudication",
        "/api/agent-trust/action",
        "/api/console/actions",
        "/api/console/downstream-decision/entrypoint",
        "/api/console/downstream-decision/action",
        "/api/console/package-builds/sync-folders",
        "/api/console/package-release-candidates/publish-preflight",
        "/api/console/package-release-candidates/publish-to-customer-releases",
    }:
        return 404, {"error": "not_found"}
    try:
        length = int(headers.get("Content-Length", "0"))
        raw = read_body(length)
        payload = json.loads(raw.decode("utf-8"))
        if not isinstance(payload, dict):
            raise ValueError("invalid_payload")

        # Strict Schema Hardening for publish actions
        if path in {
            "/api/console/package-builds/sync-folders",
            "/api/console/package-release-candidates/publish-preflight",
            "/api/console/package-release-candidates/publish-to-customer-releases",
        }:
            blacklist_keys = {"files", "file_paths", "source_refs", "target_paths"}
            if any(k in payload for k in blacklist_keys):
                raise ValueError("FRONTEND_FILE_LIST_NOT_ALLOWED")

        if path == "/api/intake":
            result = routes["process_intake_payload"](payload)
        elif path == "/api/intake/adjudication":
            result = routes["process_requirement_adjudication_submit_payload"](payload)
        elif path == "/api/console/downstream-decision/entrypoint":
            result = routes["process_downstream_decision_entrypoint_payload"](payload)
        elif path == "/api/console/downstream-decision/action":
            result = routes["process_downstream_decision_action_payload"](payload)
        elif path == "/api/console/actions":
            result = routes["process_console_action_payload"](payload)
        elif path == "/api/console/package-builds/sync-folders":
            result = routes["process_console_sync_folders_payload"](payload)
        elif path == "/api/console/package-release-candidates/publish-preflight":
            result = routes["process_console_publish_preflight_payload"](payload)
        elif path == "/api/console/package-release-candidates/publish-to-customer-releases":
            result = routes["process_console_publish_to_customer_releases_payload"](payload)
        else:
            result = routes["process_agent_trust_action_payload"](payload)
        return 200, result
    except (json.JSONDecodeError, UnicodeDecodeError):
        return 400, {"error": "invalid_json"}
    except Exception as exc:  # pragma: no cover - defensive runtime fallback
        return _error_response(exc)
