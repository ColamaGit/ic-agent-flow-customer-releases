from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

ALLOWED_CLASSIFICATIONS = {
    "PUBLIC_CONTRACT",
    "CUSTOMER_RUNTIME",
    "CUSTOMER_CONFIGURABLE",
    "CUSTOMER_REVIEWABLE",
    "SUPPORT_ONLY",
    "INTERNAL_ONLY",
    "PROPRIETARY_SECRET",
    "SOURCE_ESCROW_ONLY",
    "PARTNER_SDK_ALLOWED",
}


@dataclass(frozen=True)
class ResolutionContext:
    mode: str
    phase: str


def load_catalog(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    _validate_catalog(payload)
    return payload


def _validate_catalog(catalog: dict[str, Any]) -> None:
    required_top = ["catalog_version", "default_hash_algorithm", "governance", "documents"]
    for key in required_top:
        if key not in catalog:
            raise ValueError(f"catalog_missing_key:{key}")

    governance = catalog.get("governance", {})
    for key in [
        "change_ticket_ref",
        "requestor",
        "approver_role",
        "approved_at",
        "change_type",
        "catalog_version_before",
        "catalog_version_after",
    ]:
        if not governance.get(key):
            raise ValueError(f"catalog_governance_missing:{key}")
    _validate_governance_versioning(governance)

    seen_doc_ids: set[str] = set()
    for doc in catalog.get("documents", []):
        doc_id = str(doc.get("doc_id", "")).strip()
        if not doc_id:
            raise ValueError("catalog_doc_missing:doc_id")
        if doc_id in seen_doc_ids:
            raise ValueError(f"catalog_doc_duplicate:{doc_id}")
        seen_doc_ids.add(doc_id)

        classification = doc.get("classification")
        if classification not in ALLOWED_CLASSIFICATIONS:
            raise ValueError(f"catalog_doc_invalid_classification:{doc_id}:{classification}")

        if not doc.get("owner"):
            raise ValueError(f"catalog_doc_missing_owner:{doc_id}")

        for key in ["required_modes", "required_phases", "target_paths"]:
            if key not in doc:
                raise ValueError(f"catalog_doc_missing:{doc_id}:{key}")


def _parse_semver_major(version: str) -> int:
    head = str(version).split(".")[0].strip()
    return int(head)


def _validate_governance_versioning(governance: dict[str, Any]) -> None:
    change_type = str(governance.get("change_type", ""))
    before = str(governance.get("catalog_version_before", "0.0.0"))
    after = str(governance.get("catalog_version_after", "0.0.0"))
    approved_at = str(governance.get("approved_at", ""))

    if change_type == "breaking":
        if _parse_semver_major(after) <= _parse_semver_major(before):
            raise ValueError("catalog_breaking_requires_major_bump")
    if change_type == "security_hotfix":
        if not approved_at or approved_at == "TBD":
            raise ValueError("catalog_security_hotfix_requires_security_approval_record")


def resolve_required_docs(catalog: dict[str, Any], mode: str, phase: str) -> dict[str, Any]:
    ctx = ResolutionContext(mode=mode, phase=phase)
    required_docs: list[dict[str, Any]] = []
    excluded_docs: list[dict[str, Any]] = []
    blocked_docs: list[dict[str, Any]] = []

    for doc in catalog.get("documents", []):
        doc_modes = set(doc.get("required_modes", []))
        doc_phases = set(doc.get("required_phases", []))
        if ctx.mode not in doc_modes:
            excluded_docs.append({"doc_id": doc["doc_id"], "reason": f"mode_mismatch:{ctx.mode}"})
            continue
        if ctx.phase not in doc_phases:
            excluded_docs.append({"doc_id": doc["doc_id"], "reason": f"phase_mismatch:{ctx.phase}"})
            continue

        if doc.get("visibility") in {"customer_visible", "customer_reviewable"} and doc.get("classification") in {
            "INTERNAL_ONLY",
            "PROPRIETARY_SECRET",
        }:
            blocked_docs.append({"doc_id": doc["doc_id"], "reason": "forbidden_customer_visibility_classification"})
            continue

        required_docs.append(doc)

    return {
        "mode": mode,
        "phase": phase,
        "required_docs": required_docs,
        "optional_docs": [],
        "excluded_docs": excluded_docs,
        "blocked_docs": blocked_docs,
        "copy_plan": [
            {
                "doc_id": doc["doc_id"],
                "source_ref": doc["source_ref"],
                "target_path": doc["target_paths"]["extract"],
                "hash_required": bool(doc.get("hash_required", True)),
                "hash_algorithm": doc.get("hash_algorithm", "sha256"),
            }
            for doc in required_docs
        ],
        "hash_plan": [{"doc_id": doc["doc_id"], "algorithm": doc.get("hash_algorithm", "sha256")} for doc in required_docs],
    }


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def build_customer_manifest_view(required_docs: list[dict[str, Any]], hash_by_doc: dict[str, str], mode: str) -> dict[str, Any]:
    entries = []
    for doc in required_docs:
        entries.append(
            {
                "doc_id": doc["doc_id"],
                "title": doc["title"],
                "bundle_path": doc["target_paths"]["bundle"],
                "extract_path": doc["target_paths"]["extract"],
                "hash": hash_by_doc.get(doc["doc_id"], ""),
                "classification_safe_view": doc.get("classification_safe_view", ""),
            }
        )
    return {"mode": mode, "entries": entries}


def copy_and_verify_required_docs(repo_root: Path, staging_root: Path, required_docs: list[dict[str, Any]]) -> list[dict[str, Any]]:
    copied: list[dict[str, Any]] = []
    for doc in required_docs:
        src = repo_root / doc["source_ref"]
        dst = staging_root / doc["target_paths"]["staging"]
        if not src.exists():
            raise FileNotFoundError(f"required_doc_missing_source:{doc['doc_id']}:{doc['source_ref']}")
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_bytes(src.read_bytes())

        src_hash = sha256_file(src)
        dst_hash = sha256_file(dst)
        if src_hash != dst_hash:
            raise RuntimeError(f"required_doc_hash_mismatch:{doc['doc_id']}")

        copied.append(
            {
                "doc_id": doc["doc_id"],
                "source_ref": doc["source_ref"],
                "staging_path": doc["target_paths"]["staging"],
                "source_hash": src_hash,
                "staging_hash": dst_hash,
            }
        )
    return copied
