# Template Usage Guide — Baseline Digital SoC

- scope_type: `TEMPLATE`

## When To Select

Select this template when the chip intent includes:

- Generic digital top-level scaffold.
- Early architecture exploration before final protocol choice.
- Minimal RTL/testbench seed for PRD v1.0 to PRD v0.9 flow validation.

## Required Human Follow-Up

After Requirement Intake creates `chips/<chip_id>/`, fill or adjudicate:

- Concrete module/interface responsibilities.
- Clock/reset and timing constraints.
- Architecture graph candidate and validation expectations.
- Generation-plan and RTL candidate boundary.

## Handoff

This template only seeds the workspace. Canonical requirements, graph, freeze, generation plan, and RTL candidate decisions must be recorded under `chips/<chip_id>/`.
