# Template Contract — Baseline Digital SoC

## Scope

- scope_type: `TEMPLATE`
- canonical owner after intake: `chips/<chip_id>/`
- execution evidence owner: `artifacts/production-runs/...`

## Non-Claims

This template does not claim:

- chip-specific requirement approval; it is not chip-specific canonical truth
- graph validation
- graph or requirement freeze
- generation-plan readiness
- RTL candidate approval
- PRD v0.9 runner execution; it is not run execution evidence
- silicon/tapeout readiness

## Promotion Rule

A copied file from this template becomes chip-scoped only when referenced by `chips/<chip_id>/` records and governed by PRD v1.0 upstream flow.
