# Baseline Digital SoC Template

- scope_type: `TEMPLATE`

This template is a reusable TEMPLATE blueprint for a minimal digital SoC-style scaffold. It is not a chip instance, not adjudicated chip truth, and not run evidence.

## Contents

| Path | Meaning |
| --- | --- |
| `template_manifest.yaml` | Machine-readable template metadata anchor. |
| `specs/chip_spec.md` | Baseline spec seed for human review. |
| `rtl/top.v` | Top-level RTL seed. |
| `rtl/top_tb.v` | Smoke testbench seed. |
| `constraints/base.sdc` | Baseline timing constraint seed. |

## Best Fit

Use this template when the intake intent needs a generic digital scaffold before a more specific protocol/template is available.

## Not Enough By Itself

Human/operator must still define module responsibilities, interfaces, clock/reset, verification plan, graph, freeze, generation plan, and RTL candidate status under `chips/<chip_id>/`.
