# Asynchronous FIFO Template

- scope_type: `TEMPLATE`

This template is a reusable TEMPLATE blueprint for an asynchronous FIFO block. It is not a chip instance, not adjudicated chip truth, and not run evidence.

## Contents

| Path | Meaning |
| --- | --- |
| `asynchronous_fifo.sv` | Top-level asynchronous FIFO RTL seed. |
| `fifo_mem.v` | FIFO memory seed. |
| `write_pointer.v` | Write-domain pointer logic seed. |
| `read_pointer.v` | Read-domain pointer logic seed. |
| `synchronizer.v` | Cross-domain synchronizer seed. |
| `testbench.sv` | Smoke testbench seed. |
| `constraints/base.sdc` | Baseline timing constraint seed. |

## Best Fit

Use this template when the intake intent is primarily an async FIFO, CDC boundary, or dual-clock buffering problem.

## Not Enough By Itself

Human/operator must still define FIFO depth, data width, almost_full/almost_empty thresholds, reset behavior, CDC assumptions, latency/throughput targets, and error handling under `chips/<chip_id>/`.
