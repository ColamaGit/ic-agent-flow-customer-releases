# Template Usage Guide — Asynchronous FIFO

- scope_type: `TEMPLATE`

## When To Select

Select this template when the chip intent includes:

- Two clock domains with write/read decoupling.
- FIFO buffering across CDC boundary.
- Need for pointer synchronization or full/empty flag behavior.

## Required Human Follow-Up

After Requirement Intake creates `chips/<chip_id>/`, fill or adjudicate:

- FIFO depth and data width.
- `almost_full` / `almost_empty` thresholds.
- Write clock, read clock, and reset release assumptions.
- Overflow/underflow policy.
- Required assertions and coverage scenarios.

## Handoff

This template only seeds the workspace. Canonical requirements, graph, freeze, generation plan, and RTL candidate decisions must be recorded under `chips/<chip_id>/`.
