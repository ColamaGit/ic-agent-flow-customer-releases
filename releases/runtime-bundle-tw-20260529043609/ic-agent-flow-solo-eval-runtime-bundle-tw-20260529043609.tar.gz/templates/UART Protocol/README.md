# UART Protocol Template

- scope_type: `TEMPLATE`

This template is a reusable TEMPLATE blueprint for UART protocol logic. It is not a chip instance, not adjudicated chip truth, and not run evidence.

## Contents

| Path | Meaning |
| --- | --- |
| `UART_Top.v` | UART top-level RTL seed. |
| `Uart_receiver.v` / `Uart_transmitter.v` | RX/TX RTL seeds. |
| `Baud_rate_generator.v` | Baud generator seed. |
| `rx_fsm.v` / `tx_fsm.v` | UART state machine seeds. |
| `parity_*`, `stop_bit_checker.v`, `detect_start.v` | Frame checking helper seeds. |
| `UART_Top_tb.v` | Smoke testbench seed. |
| `constraints/base.sdc` | Baseline timing constraint seed. |

## Best Fit

Use this template when the intake intent is primarily UART serial communication, configurable baud, RX/TX, framing, parity, or stop-bit behavior.

## Not Enough By Itself

Human/operator must still define baud range, frame format, parity policy, stop bits, clock/reset behavior, FIFO coupling if any, error handling, and verification targets under `chips/<chip_id>/`.
