# Template Usage Guide — UART Protocol

- scope_type: `TEMPLATE`

## When To Select

Select this template when the chip intent includes:

- UART RX/TX interface.
- Configurable baud rate.
- Data frame parsing or generation.
- Parity / stop-bit / start-bit behavior.

## Required Human Follow-Up

After Requirement Intake creates `chips/<chip_id>/`, fill or adjudicate:

- Supported baud range and divisor assumptions.
- Data bits, parity modes, stop-bit count.
- RX/TX buffering policy and FIFO requirements if present.
- Error reporting for parity, framing, overflow, and underflow.
- Required assertions, test scenarios, and coverage targets.

## Handoff

This template only seeds the workspace. Canonical requirements, graph, freeze, generation plan, and RTL candidate decisions must be recorded under `chips/<chip_id>/`.
