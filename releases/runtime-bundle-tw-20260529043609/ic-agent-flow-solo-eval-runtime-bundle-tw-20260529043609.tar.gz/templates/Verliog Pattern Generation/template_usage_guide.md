# Template Usage Guide — Verilog Pattern Generation

- scope_type: `TEMPLATE`

## When To Select

Select this template when the chip intent includes:

- Simple deterministic pattern generation.
- Counter/state-machine output sequence.
- Minimal RTL seed for early PRD v1.0 flow validation.

## Required Human Follow-Up

After Requirement Intake creates `chips/<chip_id>/`, fill or adjudicate:

- Exact pattern sequence and reset state.
- Interface width and timing contract.
- Stop/repeat behavior.
- Testbench expectations and coverage targets.

## Handoff

This template only seeds the workspace. Canonical requirements, graph, freeze, generation plan, and RTL candidate decisions must be recorded under `chips/<chip_id>/`.
