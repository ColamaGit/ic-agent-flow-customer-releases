# Verilog Pattern Generation Template

- scope_type: `TEMPLATE`

This template is a reusable TEMPLATE blueprint for simple Verilog pattern generation logic. It is not a chip instance, not adjudicated chip truth, and not run evidence.

## Contents

| Path | Meaning |
| --- | --- |
| `pattern_gen.v` | Pattern generator RTL seed. |
| `pattern_gen_tb.v` | Smoke testbench seed. |

## Best Fit

Use this template when the intake intent is a small pattern generator, counter-driven output source, or starter RTL exercise.

## Not Enough By Itself

Human/operator must still define output sequence, reset behavior, timing assumptions, interfaces, verification targets, and downstream flow expectations under `chips/<chip_id>/`.
