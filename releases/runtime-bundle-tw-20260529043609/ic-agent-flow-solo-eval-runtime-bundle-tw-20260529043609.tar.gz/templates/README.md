# templates/ Blueprint Contract

`templates/<chip_template>/` stores reusable chip blueprints and bootstrap seed assets. A template is not a chip instance, not human adjudication truth, and not run evidence.

This README is package-friendly documentation: when release packages include `templates/`, include this file so operators can understand template semantics without opening PRDs first.

## Scope Boundary

| Scope | Directory | Meaning |
| --- | --- | --- |
| `TEMPLATE` | `templates/<chip_template>/` | Reusable blueprint / initialization DNA. It may provide RTL, constraints, baseline specs, and template metadata. |
| `CHIP_UPSTREAM` | `chips/<chip_id>/` | Instantiated chip truth after Requirement Intake materializes or resolves a chip workspace. |
| `RUN_EXECUTION` | `artifacts/production-runs/...` | Formal runner execution evidence. Templates must not store run evidence. |

A template can seed a chip workspace, but after `Execute Intake` the chip-specific truth belongs under `chips/<chip_id>/`.

## Expected Template Root

```text
templates/<chip_template>/
  README.md
  template_usage_guide.md
  template_contract.md
  template_manifest.yaml  # recommended when available
  specs/
  rtl/
  constraints/
  *.v / *.sv / *_tb.v / *_tb.sv
```

| Path | Meaning |
| --- | --- |
| `README.md` | Human-readable overview of the template contents, best-fit use case, and missing chip-specific decisions. |
| `template_usage_guide.md` | Human-readable intake guidance: when to select the template, what human follow-up is required, and where handoff moves after `Execute Intake`. |
| `template_contract.md` | Human-readable boundary contract: template is blueprint only and must not contain chip-specific adjudication, freeze, generation plan, `run_id`, or run evidence. |
| `template_manifest.yaml` | Optional/recommended template metadata: name, intent, supported flow, seed files, and constraints. |
| `specs/` | Baseline human-readable or machine-readable template spec seed. It is not chip-specific frozen truth. |
| `rtl/` | Reusable RTL seed files. |
| `constraints/` | Reusable constraints such as `base.sdc`. |
| `*_tb.v`, `*_tb.sv`, `testbench.sv` | Reusable testbench examples or smoke seeds. |

Current templates may be directory-style (`baseline-digital-soc/`) or flat RTL seed style (`UART Protocol/`, `Asynchronous FIFO/`). Both are legal as `TEMPLATE` scope, but package/build tooling should treat `template_manifest.yaml` as the preferred metadata anchor when present.

## Required Human Companion Files

Each current template should carry:

```text
README.md
template_usage_guide.md
template_contract.md
```

These files help a human decide whether a template is appropriate before `Execute Intake`. They are advisory companions to the machine-readable seed files and must not become chip-specific truth. Once a chip workspace is created, human review moves to `chips/<chip_id>/specs/` and `chips/<chip_id>/architecture/`.

## Template Resolution Verdicts

Requirement Intake records template resolution under:

```text
chips/<chip_id>/specs/intake/<session>/template_resolution_record.json
```

| Verdict | Meaning |
| --- | --- |
| `TEMPLATE_SELECTED` | Human selected a template. |
| `TEMPLATE_AUTO_RESOLVED` | System resolved a template from chip intent/prompt. |
| `TEMPLATE_DEFERRED` | Intake can proceed without a selected template; downstream graph freeze/generation must remain blocked until sufficient truth exists. |
| `TEMPLATE_BLOCKED` | Template-specific flow was requested but no valid template exists; fail closed. |
| `LEGACY_COMPATIBILITY` | Compatibility marker used by older chip workspaces; do not treat it as a fresh template resolution. |

## What Templates Must Not Contain

Templates must not contain chip-instance authority decisions, human adjudication records, freeze records for a specific chip, generation plans for a specific chip, `run_id`, or production-run evidence.

If a template asset is copied into a chip workspace, the copied artifact becomes chip-scoped only after it is referenced by `chips/<chip_id>/` records and governed by the PRD v1.0 upstream flow.

## Packaging Note

If a package includes reusable templates, include this `templates/README.md` together with the selected `templates/<chip_template>/...` directories. Package consumers should use the README to distinguish reusable blueprint assets from `chips/<chip_id>/` upstream truth.
