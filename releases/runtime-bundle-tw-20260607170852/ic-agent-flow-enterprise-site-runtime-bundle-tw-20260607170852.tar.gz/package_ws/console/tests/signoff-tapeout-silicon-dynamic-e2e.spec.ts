import { expect, test } from '@playwright/test'

type ScopeCase = {
  route: '/signoff' | '/tapeout-package' | '/silicon-feedback'
  pathChip: string
  queryMode: 'enterprise_site'
  queryRun: string
  queryExecution: string
  headingPattern: RegExp
  decisionInboxPattern: RegExp
}

const cases: ScopeCase[] = [
  {
    route: '/signoff',
    pathChip: 'ASYNC_FIFO',
    queryMode: 'enterprise_site',
    queryRun: 'T-FIFO-001',
    queryExecution: '20260507-061543',
    headingPattern: /Signoff|就緒度|收斂看板/i,
    decisionInboxPattern: /Decision Inbox|決策收件匣/i,
  },
  {
    route: '/tapeout-package',
    pathChip: 'ASYNC_FIFO',
    queryMode: 'enterprise_site',
    queryRun: 'T-FIFO-001',
    queryExecution: '20260507-061543',
    headingPattern: /Tapeout Package|封裝交付|Foundry/i,
    decisionInboxPattern: /Decision Inbox|決策收件匣/i,
  },
  {
    route: '/silicon-feedback',
    pathChip: 'ASYNC_FIFO',
    queryMode: 'enterprise_site',
    queryRun: 'T-FIFO-001',
    queryExecution: '20260507-173846',
    headingPattern: /Silicon Feedback|矽後回饋|Bring-up/i,
    decisionInboxPattern: /Decision Inbox|決策收件匣/i,
  },
]

test.describe('QA-003 dynamic E2E for signoff/tapeout/silicon feedback pages', () => {
  for (const c of cases) {
    test(`${c.route} supports run-style scope and dynamic blocks`, async ({ page }) => {
      const url = `${c.route}/${encodeURIComponent(c.pathChip)}?mode=${c.queryMode}&run=${encodeURIComponent(c.queryRun)}&execution=${encodeURIComponent(c.queryExecution)}`
      await page.goto(url)

      await expect(page.locator('main')).toContainText(c.headingPattern)
      await expect(page.locator('main')).toContainText(c.decisionInboxPattern)

      // selector exists and has selected values from query scope
      const combos = page.getByRole('combobox')
      await expect(combos).toHaveCount(3)
      await expect(combos.nth(1)).toHaveValue(c.queryRun)
      await expect(combos.nth(2)).toHaveValue(c.queryExecution)

      // URL should keep run-detail-style query scope
      await expect(page).toHaveURL(new RegExp(`${c.route}/[^?]+\\?mode=${c.queryMode}&run=${c.queryRun}&execution=`))

      // i18n continuity smoke: page must not expose unresolved i18n key placeholders
      const mainText = await page.locator('main').innerText()
      expect(mainText).not.toContain('nav.')
      expect(mainText).not.toContain('page.')
      expect(mainText).not.toContain('signoff.')
    })
  }
})
