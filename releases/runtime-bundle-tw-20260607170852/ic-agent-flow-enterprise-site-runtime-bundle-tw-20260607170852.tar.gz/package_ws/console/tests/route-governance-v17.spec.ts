import { expect, test } from '@playwright/test'

test('root redirects to /console and renders mission control content', async ({ page }) => {
  await page.goto('/')
  await expect(page).toHaveURL(/\/console$/)
  await expect(page.getByRole('heading', { name: 'Console Home' })).toBeVisible()
  await expect(page.getByText('Needs Your Attention')).toBeVisible()
})

test('/decision-inbox renders dedicated decision queue page', async ({ page }) => {
  await page.goto('/decision-inbox')
  await expect(page.getByRole('heading', { name: 'Decision Inbox' })).toBeVisible()
  await expect(page.getByText('Pending review actions, evidence requests, escalations, and release blockers.')).toBeVisible()
  await expect(page.getByText('Silicon Portfolio')).toHaveCount(0)
})

test('legacy /qa alias redirects to /qa-strategy', async ({ page }) => {
  await page.goto('/qa')
  await expect(page).toHaveURL(/\/qa-strategy$/)
  const breadcrumb = page.locator('div.font-medium.text-slate-200').first()
  await expect(breadcrumb).toContainText('QA & Trust')
  await expect(breadcrumb).toContainText('QA Strategy')
})

test('legacy run alias shows canonical run breadcrumb context', async ({ page }) => {
  await page.goto('/run/latest')
  await expect(page.getByText('Console Home > Flow & Run Operations > Run Detail')).toBeVisible()
  await expect(page.getByText('Active Run: latest')).toBeVisible()
})

test('console home switches content by operating mode', async ({ page }) => {
  await page.goto('/console?mode=solo_eval')
  await expect(page.locator('main').getByText('solo_eval', { exact: true })).toBeVisible()
  await expect(page.getByText('Package verified and install path ready')).toBeVisible()

  await page.goto('/console?mode=team_project')
  await expect(page.locator('main').getByText('team_project', { exact: true })).toBeVisible()
  await expect(page.getByText('Team roles and reviewer assignment')).toBeVisible()

  await page.goto('/console?mode=enterprise_site')
  await expect(page.locator('main').getByText('enterprise_site', { exact: true })).toBeVisible()
  await expect(page.getByText('Trust root and provenance checkpoints')).toBeVisible()
})

test('mode persists across icon navigation (no fallback to team_project)', async ({ page }) => {
  const header = page.getByRole('banner')
  await page.goto('/artifacts?mode=team_project')
  await expect(header.getByText('Mode: team_project')).toBeVisible()

  await page.goto('/console?mode=enterprise_site')
  await expect(header.getByText('Mode: enterprise_site')).toBeVisible()

  await page.locator('header nav[aria-label="Primary"] a[href="/artifacts?mode=enterprise_site"]').click()
  await expect(page).toHaveURL(/\/artifacts\?mode=enterprise_site$/)
  await expect(header.getByText('Mode: enterprise_site')).toBeVisible()
})

test('artifacts page follows mode chip visibility and excludes legacy chip', async ({ page }) => {
  await page.goto('/artifacts?mode=solo_eval')
  await expect(page.getByRole('cell', { name: 'SN2025', exact: true })).toBeVisible()
  await expect(page.getByRole('cell', { name: 'UART', exact: true })).toHaveCount(0)
  await expect(page.getByRole('cell', { name: 'ASYNC_FIFO', exact: true })).toHaveCount(0)
  await expect(page.getByText('legacy-chip-v0.1')).toHaveCount(0)

  await page.goto('/artifacts?mode=team_project')
  await expect(page.getByRole('cell', { name: 'SN2025', exact: true })).toBeVisible()
  await expect(page.getByRole('cell', { name: 'UART', exact: true })).toBeVisible()
  await expect(page.getByRole('cell', { name: 'ASYNC_FIFO', exact: true })).toHaveCount(0)
  await expect(page.getByText('legacy-chip-v0.1')).toHaveCount(0)

  await page.goto('/artifacts?mode=enterprise_site')
  await expect(page.getByRole('cell', { name: 'SN2025', exact: true })).toBeVisible()
  await expect(page.getByRole('cell', { name: 'UART', exact: true })).toBeVisible()
  await expect(page.getByRole('cell', { name: 'ASYNC_FIFO', exact: true })).toBeVisible()
  await expect(page.getByText('legacy-chip-v0.1')).toHaveCount(0)
})

test('enterprise artifacts row click keeps mode and opens valid run detail', async ({ page }) => {
  await page.goto('/artifacts?mode=enterprise_site')
  await page.getByRole('cell', { name: 'SN2025', exact: true }).click()

  await expect(page).toHaveURL(/\/run\/SN2025\?mode=enterprise_site&run=[^&]+&execution=[^&]+$/)
  await expect(page.getByRole('banner').getByText('Mode: enterprise_site')).toBeVisible()
  await expect(page.getByText("Unexpected token '<'")).toHaveCount(0)
  await expect(page.getByText('Invalid bundle reference')).toHaveCount(0)
  await expect(page.getByRole('heading', { name: /Run Artifact Explorer/i })).toBeVisible()
})

test('run detail explorer exposes chip/run/execution selectors and file list', async ({ page }) => {
  await page.goto('/run/async-fifo-v0.1?mode=enterprise_site')
  await expect(page.getByRole('heading', { name: /Run Artifact Explorer/i })).toBeVisible()
  await expect(page.getByText('Chip ID', { exact: true })).toBeVisible()
  await expect(page.getByText('Run ID', { exact: true })).toBeVisible()
  await expect(page.getByText('Execution Timestamp', { exact: true })).toBeVisible()
  await expect(page.getByText('Artifact Structure', { exact: true })).toBeVisible()
  await expect(page.getByText('Resolved Root', { exact: true })).toBeVisible()
  await expect(page.locator('div.text-xs.font-mono.text-cyan-300').first()).toContainText('artifacts/production-runs/async-fifo-v0.1')
})
