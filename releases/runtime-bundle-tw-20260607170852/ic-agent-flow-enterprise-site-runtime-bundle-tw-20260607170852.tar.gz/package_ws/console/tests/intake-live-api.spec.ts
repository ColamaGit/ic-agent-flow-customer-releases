import { expect, test } from '@playwright/test'
import fs from 'node:fs'
import path from 'node:path'

test('dev:with-intake serves /api/intake/options with 200', async ({ request }) => {
  const response = await request.get('/api/intake/options')
  expect(response.status()).toBe(200)

  const payload = await response.json()
  expect(payload).toHaveProperty('templates_root')
  expect(Array.isArray(payload?.templates)).toBe(true)
})

function seedAgentTrustFixture(): { runDir: string; bindingId: string } {
  const runDir = path.resolve(
    process.cwd(),
    '..',
    'artifacts',
    'production-runs',
    'agent-trust-api-e2e-chip',
    'T-API-001',
    '20260516-230000',
  )
  const outDir = path.join(runDir, 'dashboard_objects')
  fs.mkdirSync(outDir, { recursive: true })
  const panel = {
    panel_id: 'agent-trust-panel::APIE2E',
    view_mode: 'READ_ONLY',
    agent_or_skill_name: 'signoff_tapeout_silicon_reports',
    execution_plane: 'local_runner',
    input_contract_ref: 'dashboard_objects/signoff_domain_matrix.json',
    output_contract_ref: 'dashboard_objects/final_tapeout_readiness_record.json',
    evidence_refs: ['dashboard_objects/final_tapeout_readiness_record.json'],
    risk_boundary_refs: ['READINESS_STATUS::BLOCKED'],
    replay_ref: 'python3 package_ws/shared-runtime/scripts/apply_agent_trust_panel_action.py ...',
  }
  const bindingId = 'agent-trust-binding::APIE2E'
  const binding = {
    binding_id: bindingId,
    panel_ref: panel.panel_id,
    source_skill_ref: 'signoff_tapeout_silicon_reports',
    source_invocation_ref: 'APIE2E',
    requested_action: 'request_more_evidence',
    dashboard_action_request_ref: 'dashboard_objects/dashboard_action_request.json',
    authorization_record_ref: 'dashboard_objects/dashboard_action_authorization_record.json',
    audit_record_ref: 'dashboard_objects/dashboard_action_audit_record.json',
    result_record_ref: 'dashboard_objects/dashboard_action_result_record.json',
    replay_trace_ref: 'dashboard_objects/dashboard_replay_trace.json',
    status: 'REQUESTED',
  }
  fs.writeFileSync(path.join(outDir, 'agent_trust_panel_view.json'), JSON.stringify(panel))
  fs.writeFileSync(path.join(outDir, 'agent_trust_panel_action_binding.json'), JSON.stringify(binding))
  return { runDir, bindingId }
}

test('agent trust action API blocks read-only role', async ({ request }) => {
  const { runDir, bindingId } = seedAgentTrustFixture()
  const response = await request.post('/api/agent-trust/action', {
    data: {
      run_dir: runDir,
      binding_id: bindingId,
      action: 'request_more_evidence',
      actor_role: 'READ_ONLY',
      session_id: 'sess-readonly',
    },
  })
  expect(response.status()).toBe(403)
  const payload = await response.json()
  expect(String(payload?.error ?? '')).toContain('rbac_blocked')
})

test('agent trust action API allows release authority role', async ({ request }) => {
  const { runDir, bindingId } = seedAgentTrustFixture()
  const response = await request.post('/api/agent-trust/action', {
    data: {
      run_dir: runDir,
      binding_id: bindingId,
      action: 'request_more_evidence',
      actor_role: 'RELEASE_AUTHORITY',
      session_id: 'sess-release',
    },
  })
  expect(response.status()).toBe(200)
  const payload = await response.json()
  expect(payload?.status).toBe('ok')
  expect(payload?.result_record?.status).toBe('EXECUTED')
})
