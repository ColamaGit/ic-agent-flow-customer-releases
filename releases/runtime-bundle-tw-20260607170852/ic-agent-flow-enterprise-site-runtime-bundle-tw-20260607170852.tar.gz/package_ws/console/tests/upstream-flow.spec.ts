import { expect, test } from '@playwright/test'

test('upstream flow page shows fail-closed error state when chip context cannot be loaded', async ({ page }) => {
  await page.route('**/api/intake/adjudication?chip_id=missing_chip', async (route) => {
    await route.fulfill({
      status: 404,
      contentType: 'application/json',
      body: JSON.stringify({
        error: 'chip_not_found:missing_chip',
      }),
    })
  })

  await page.goto('/upstream-flow?mode=team_project&chip=missing_chip')
  await expect(page.getByText(/Error|錯誤/)).toBeVisible()
  await expect(page.getByText(/chip_not_found:missing_chip/)).toBeVisible()
})

test('upstream flow page shows chip selector when chip query is missing', async ({ page }) => {
  await page.route('**/api/intake/chips', async (route) => {
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        status: 'ok',
        scope_type: 'CHIP_UPSTREAM',
        chips: [
          { chip_id: 'uart_with_fifo', source_dir: 'chips/uart_with_fifo' },
          { chip_id: 'quad_uart', source_dir: 'chips/quad_uart' },
        ],
      }),
    })
  })
  await page.route('**/api/intake/adjudication?chip_id=quad_uart', async (route) => {
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        status: 'ok',
        chip_id: 'quad_uart',
        scope_type: 'CHIP_UPSTREAM',
        review_package: { status: 'ADJUDICATED_APPROVED' },
        builder_handoff: { handoff_status: 'PENDING_VALIDATION' },
        requirement_item: { requirement_items: [] },
        adjudication_template: { conditions_suggested: [] },
        adjudication_record: { status: 'DECISION_RECORDED' },
        upstream_truth_flow: [],
      }),
    })
  })

  await page.goto('/upstream-flow?mode=team_project')

  const combo = page.getByRole('combobox', { name: /Select Chip|選擇 Chip/ })
  await expect(combo).toBeVisible()
  await combo.selectOption('quad_uart')
  await expect(page).toHaveURL(/mode=team_project/)
  await expect(page).toHaveURL(/chip=quad_uart/)
  await expect(page.locator('main').getByText('chip_id: quad_uart', { exact: true })).toBeVisible()
})

test('upstream flow page shows remaining v1.0 nodes and local AI handoff', async ({ page }) => {
  await page.route('**/api/intake/adjudication?chip_id=quad_uart', async (route) => {
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        status: 'ok',
        chip_id: 'quad_uart',
        scope_type: 'CHIP_UPSTREAM',
        upstream_operation_id: 'UOP-INTAKE-quad_uart-20260517-120000',
        review_package: {
          status: 'ADJUDICATED_APPROVED',
          intake_session_id: 'INTAKE-quad_uart-20260517-120000',
        },
        builder_handoff: {
          handoff_status: 'PENDING_VALIDATION',
        },
        requirement_item: {
          draft_status: 'AUTO_DRAFT_PENDING_REVIEW',
          requirement_items: [],
        },
        adjudication_template: {
          status: 'PENDING_DECISION',
          conditions_suggested: [],
        },
        adjudication_record: {
          status: 'DECISION_RECORDED',
          decision_outcome: 'approve',
          decision_rationale: 'Spec can proceed to graph validation.',
          authority_signer: 'owner@icaf',
        },
        upstream_truth_flow: [
          {
            node_id: 'requirement_intake',
            scope_type: 'CHIP_UPSTREAM',
            status: 'PASS',
            expected_files: ['chips/quad_uart/specs/intake/INTAKE-quad_uart-20260517-120000/intake_session_record.json'],
            existing_files: ['chips/quad_uart/specs/intake/INTAKE-quad_uart-20260517-120000/intake_session_record.json'],
            missing_files: [],
            next_action: 'requirement_adjudication',
          },
          {
            node_id: 'requirement_adjudication',
            scope_type: 'CHIP_UPSTREAM',
            status: 'PASS',
            expected_files: ['chips/quad_uart/specs/requirement_item_adjudication_record.json'],
            existing_files: ['chips/quad_uart/specs/requirement_item_adjudication_record.json'],
            missing_files: [],
            next_action: 'graph_draft_check',
          },
          {
            node_id: 'graph_draft_check',
            scope_type: 'CHIP_UPSTREAM',
            status: 'PASS',
            expected_files: ['chips/quad_uart/architecture/architecture_graph.draft.json'],
            existing_files: ['chips/quad_uart/architecture/architecture_graph.draft.json'],
            missing_files: [],
            next_action: 'graph_validation',
          },
          {
            node_id: 'graph_validation',
            scope_type: 'CHIP_UPSTREAM',
            status: 'NOT_CREATED',
            expected_files: [
              'chips/quad_uart/architecture/validation/graph_validation_result.json',
              'chips/quad_uart/architecture/validation/validator_run_record.json',
            ],
            existing_files: [],
            missing_files: [
              'chips/quad_uart/architecture/validation/graph_validation_result.json',
              'chips/quad_uart/architecture/validation/validator_run_record.json',
            ],
            next_action: 'freeze',
          },
          {
            node_id: 'freeze',
            scope_type: 'CHIP_UPSTREAM',
            status: 'NOT_CREATED',
            expected_files: [
              'chips/quad_uart/governance/freeze/requirement_freeze_record.json',
              'chips/quad_uart/governance/freeze/graph_freeze_record.json',
            ],
            existing_files: [],
            missing_files: [
              'chips/quad_uart/governance/freeze/requirement_freeze_record.json',
              'chips/quad_uart/governance/freeze/graph_freeze_record.json',
            ],
            next_action: 'generation_plan',
          },
          {
            node_id: 'generation_plan',
            scope_type: 'CHIP_UPSTREAM',
            status: 'NOT_CREATED',
            expected_files: ['chips/quad_uart/generation/graph_to_generation_plan.json'],
            existing_files: [],
            missing_files: ['chips/quad_uart/generation/graph_to_generation_plan.json'],
            next_action: 'runner_execution',
          },
          {
            node_id: 'v09_handoff_preflight',
            scope_type: 'CHIP_UPSTREAM',
            status: 'NOT_CREATED',
            expected_files: ['chips/quad_uart/governance/v09_handoff_preflight_manifest.json'],
            existing_files: [],
            missing_files: ['chips/quad_uart/governance/v09_handoff_preflight_manifest.json'],
            next_action: 'runner_execution',
            manifest_detail: {
              manifest_ref: 'chips/quad_uart/governance/v09_handoff_preflight_manifest.json',
              manifest_status: 'BLOCKED_MISSING_SOURCES',
              ready_for_v09_handoff: false,
              missing_sources: ['chips/quad_uart/rtl/rtl_manifest.json'],
              root_cause_required: true,
              upstream_node_output_check: {
                ref: 'chips/quad_uart/governance/upstream_node_output_check.json',
                status: 'FAIL',
              },
              verification_source_lane: {
                required_by_policy: true,
                source_root: 'chips/quad_uart',
                consumer_stages: ['v0.9_runner'],
                expected_files: ['chips/quad_uart/rtl/rtl_manifest.json'],
                missing_files: ['chips/quad_uart/rtl/rtl_manifest.json'],
                materialized: false,
              },
              run_topology_policy: {
                prefix_counts_are_topology_dependent: true,
                fixed_highest_prefix_is_not_authoritative: true,
                reports_dir_must_follow_materialized_topology: true,
              },
              alignment_map_detail: {
                json_ref: 'chips/quad_uart/governance/upstream_alignment_map.json',
                md_ref: 'chips/quad_uart/governance/upstream_alignment_map.md',
                alignment_status: 'DRIFTED',
                execution_handoff_status: 'BLOCKED',
                item_count: 3,
                open_blockers: ['rtl_manifest_missing'],
                surface_aliases: {
                  dashboard_objects: {
                    canonical: '21_dashboard_objects',
                    legacy: ['dashboard_objects'],
                  },
                },
              },
              source_coverage_groups: [
                {
                  source_family: 'rtl',
                  expected_files: ['chips/quad_uart/rtl/rtl_manifest.json'],
                  missing_files: ['chips/quad_uart/rtl/rtl_manifest.json'],
                },
              ],
            },
          },
        ],
      }),
    })
  })

  await page.goto('/upstream-flow?mode=team_project&chip=quad_uart')

  await expect(page.locator('a[data-route-key="/upstream-flow"]')).toBeVisible()
  await expect(page.getByRole('heading', { name: /Spec-to-Architecture Closure Flow|規格到架構收斂流程/ })).toBeVisible()
  await expect(page.locator('main').getByText('scope_type: CHIP_UPSTREAM', { exact: true })).toBeVisible()
  await expect(page.locator('main').getByText('handoff_status: PENDING_VALIDATION', { exact: true })).toBeVisible()
  await expect(page.getByText('Graph Validation', { exact: true })).toBeVisible()
  await expect(page.getByText('Freeze', { exact: true })).toBeVisible()
  await expect(page.getByText('Generation Plan', { exact: true })).toBeVisible()
  await expect(page.getByText('v0.9 Handoff Preflight', { exact: true })).toBeVisible()
  await expect(page.getByText(/Manifest Status|Manifest 狀態/)).toHaveCount(0)
  await page.getByTestId('upstream-node-toggle-v09_handoff_preflight').click()
  await expect(page.getByTestId('v09-section-toggle-manifest_overview')).toBeVisible()
  await expect(page.getByTestId('v09-section-toggle-verification_source_lane')).toBeVisible()
  await expect(page.getByText(/source_root/i)).toHaveCount(0)
  await page.getByTestId('v09-section-toggle-manifest_overview').click()
  await expect(page.getByTestId('v09-manifest-row-manifest_ref')).toBeVisible()
  await expect(page.getByTestId('v09-manifest-row-manifest_status')).toBeVisible()
  await expect(page.getByTestId('v09-manifest-row-upstream_check')).toBeVisible()
  await expect(page.getByTestId('v09-manifest-row-checker_ref')).toBeVisible()
  await expect(page.getByTestId('v09-manifest-row-root_cause_required')).toBeVisible()
  await expect(page.getByTestId('v09-manifest-value-manifest_ref')).toContainText('chips/quad_uart/governance/v09_handoff_preflight_manifest.json')
  await expect(page.getByTestId('v09-manifest-value-checker_ref')).toContainText('chips/quad_uart/governance/upstream_node_output_check.json')
  await page.getByTestId('v09-section-toggle-verification_source_lane').click()
  await expect(page.locator('[data-testid="v09-section-body-verification_source_lane"]')).toContainText('chips/quad_uart')
  await expect(page.getByText('chips/quad_uart/architecture/validation/graph_validation_result.json').last()).toBeVisible()
  await expect(page.getByText(/Prepare PRD v0.9 Handoff|準備 PRD v0.9 交接/)).toBeVisible()
  await expect(page.getByLabel(/Local AI Handoff Prompt|本地 AI 交接 Prompt/)).toContainText('Task: Continue PRD v1.0 upstream truth flow toward PRD v0.9')
  await expect(page.getByLabel(/Local AI Handoff Prompt|本地 AI 交接 Prompt/)).toContainText('Do not create run_id')
  await expect(page.getByLabel(/Local AI Handoff Prompt|本地 AI 交接 Prompt/)).toContainText('chips/quad_uart/generation/graph_to_generation_plan.json')
  await expect(page.locator('main').getByRole('link', { name: /Run Detail|執行詳情/ })).toHaveCount(0)
})
