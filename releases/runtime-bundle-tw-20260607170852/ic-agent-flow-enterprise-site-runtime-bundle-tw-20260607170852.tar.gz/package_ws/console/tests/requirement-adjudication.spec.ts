import { expect, test } from '@playwright/test'

test('intake next-step CTA points to requirement adjudication page', async ({ page }) => {
  await page.route('**/api/intake/options', async (route) => {
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        templates_root: 'templates',
        templates: [{ name: 'UART Protocol', path: 'templates/UART Protocol' }],
      }),
    })
  })

  await page.goto('/intake')
  await page.locator('input').first().fill('quad uart')
  await page.locator('textarea').first().fill('quad uart in one chip and with high speed Tx/Rx')

  const cta = page.getByRole('link', { name: /Start Requirement Adjudication|開始 Requirement Adjudication/ })
  await expect(cta).toHaveAttribute('href', /requirement-adjudication\?chip=quad_uart/)
})

test('requirement adjudication page shows chip selector when chip query is missing', async ({ page }) => {
  await page.route('**/portfolio/summaries/production_runs_inventory.json?*', async (route) => {
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        workspace_id: 'icaf',
        timestamp: '2026-05-17T00:00:00Z',
        chips: [
          { chip_id: 'SN2025', source_dir: 'chips/test-chip-02', runs: [] },
          { chip_id: 'UART', source_dir: 'chips/uart-controller-v0.1', runs: [] },
          { chip_id: 'ASYNC_FIFO', source_dir: 'chips/async-fifo-v0.1', runs: [] },
        ],
      }),
    })
  })
  await page.route('**/api/intake/chips', async (route) => {
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        scope_type: 'CHIP_UPSTREAM',
        workspace_id: 'icaf',
        timestamp: '2026-05-17T00:00:00Z',
        chips: [
          { chip_id: 'quad_uart', source_dir: 'chips/quad_uart', requirement_adjudication_ready: true },
          { chip_id: 'uart_with_async_fifo', source_dir: 'chips/uart_with_async_fifo', requirement_adjudication_ready: false },
          { chip_id: 'chip-1', source_dir: 'chips/chip-1', requirement_adjudication_ready: false },
        ],
      }),
    })
  })

  await page.route('**/api/intake/adjudication?chip_id=quad_uart', async (route) => {
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        status: 'ok',
        chip_id: 'quad_uart',
        requirement_item: {
          draft_status: 'AUTO_DRAFT_PENDING_REVIEW',
          requirement_items: [
            {
              requirement_id: 'REQ-QUAD_UART-001',
              title: 'quad uart in one chip and with high speed Tx/Rx',
              ambiguity_status: 'OPEN',
              ambiguity_note: 'Auto-drafted from intake prompt; human adjudication required.',
            },
          ],
        },
        review_package: {
          status: 'PENDING_HUMAN_ADJUDICATION',
        },
        scope_type: 'CHIP_UPSTREAM',
        upstream_operation_id: 'UOP-INTAKE-quad_uart-20260517-120000',
        upstream_truth_flow: [
          {
            node_id: 'requirement_intake',
            scope_type: 'CHIP_UPSTREAM',
            status: 'PASS',
            expected_files: ['chips/quad_uart/specs/intake/INTAKE-quad_uart-20260517-120000/intake_session_record.json'],
            existing_files: ['chips/quad_uart/specs/intake/INTAKE-quad_uart-20260517-120000/intake_session_record.json'],
            missing_files: [],
            next_action: 'requirement_adjudication',
          },
          {
            node_id: 'generation_plan',
            scope_type: 'CHIP_UPSTREAM',
            status: 'NOT_CREATED',
            expected_files: ['chips/quad_uart/generation/graph_to_generation_plan.json'],
            existing_files: [],
            missing_files: ['chips/quad_uart/generation/graph_to_generation_plan.json'],
            next_action: 'runner_execution',
          },
        ],
        adjudication_template: {
          status: 'PENDING_DECISION',
          conditions_suggested: ['Close ambiguity for baud/frame'],
        },
        builder_handoff: {
          handoff_status: 'PENDING_HUMAN_ADJUDICATION',
        },
        adjudication_record: null,
      }),
    })
  })

  await page.goto('/requirement-adjudication?mode=enterprise_site')

  const combo = page.getByRole('combobox', { name: /Select Chip|選擇 Chip/ })
  await expect(combo).toBeVisible()
  await expect(combo.locator('option')).toHaveCount(4)
  await combo.selectOption('quad_uart')
  await expect(page).toHaveURL(/chip=quad_uart/)
  await expect(page.getByText(/chip_id:\s*quad_uart/).first()).toBeVisible()
})

test('requirement adjudication page renders API context', async ({ page }) => {
  let adjudicationRecorded = false
  let postedPayload: Record<string, unknown> | null = null

  await page.route('**/api/intake/options', async (route) => {
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        templates_root: 'templates',
        templates: [{ name: 'UART Protocol', path: 'templates/UART Protocol' }],
      }),
    })
  })
  await page.route('**/api/intake/session?chip_id=quad_uart&intake_session_id=INTAKE-quad_uart-20260517-120000', async (route) => {
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        status: 'ok',
        scope_type: 'CHIP_UPSTREAM',
        chip_id: 'quad_uart',
        requested_intake_session_id: 'INTAKE-quad_uart-20260517-120000',
        intake_session_id: 'INTAKE-quad_uart-20260517-121500',
        intake_session_record: {
          prompt_text: 'quad uart in one chip and with high speed Tx/Rx',
          template_match_result: 'MATCHED',
          template_ref: 'templates/UART Protocol',
          bootstrap_mode: 'TEMPLATE_BASED',
        },
        template_resolution_record: {
          verdict: 'TEMPLATE_AUTO_RESOLVED',
          template_ref: 'templates/UART Protocol',
          bootstrap_mode: 'TEMPLATE_BASED',
        },
        upstream_truth_flow: [
          {
            node_id: 'requirement_intake',
            scope_type: 'CHIP_UPSTREAM',
            status: 'PASS',
            expected_files: ['chips/quad_uart/specs/intake/INTAKE-quad_uart-20260517-120000/intake_session_record.json'],
            existing_files: ['chips/quad_uart/specs/intake/INTAKE-quad_uart-20260517-120000/intake_session_record.json'],
            missing_files: [],
            next_action: 'requirement_adjudication',
          },
          {
            node_id: 'generation_plan',
            scope_type: 'CHIP_UPSTREAM',
            status: 'NOT_CREATED',
            expected_files: ['chips/quad_uart/generation/graph_to_generation_plan.json'],
            existing_files: [],
            missing_files: ['chips/quad_uart/generation/graph_to_generation_plan.json'],
            next_action: 'runner_execution',
          },
        ],
      }),
    })
  })
  await page.route('**/api/intake/adjudication', async (route) => {
    if (route.request().method() !== 'POST') {
      await route.fallback()
      return
    }
    postedPayload = route.request().postDataJSON() as Record<string, unknown>
    adjudicationRecorded = true
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        status: 'ok',
        chip_id: 'quad_uart',
        adjudication_record_ref: 'chips/quad_uart/specs/requirement_item_adjudication_record.json',
        review_package_status: 'ADJUDICATED_APPROVED',
        handoff_status: 'PENDING_VALIDATION',
      }),
    })
  })
  await page.route('**/api/intake/adjudication?chip_id=quad_uart', async (route) => {
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        status: 'ok',
        chip_id: 'quad_uart',
        requirement_item: {
          draft_status: 'AUTO_DRAFT_PENDING_REVIEW',
          requirement_items: [
            {
              requirement_id: 'REQ-QUAD_UART-001',
              title: 'quad uart in one chip and with high speed Tx/Rx',
              ambiguity_status: 'OPEN',
              ambiguity_note: 'Auto-drafted from intake prompt; human adjudication required.',
            },
          ],
        },
        review_package: {
          status: adjudicationRecorded ? 'ADJUDICATED_APPROVED' : 'PENDING_HUMAN_ADJUDICATION',
          intake_session_id: 'INTAKE-quad_uart-20260517-120000',
        },
        scope_type: 'CHIP_UPSTREAM',
        upstream_operation_id: 'UOP-INTAKE-quad_uart-20260517-120000',
        upstream_truth_flow: [
          {
            node_id: 'requirement_intake',
            scope_type: 'CHIP_UPSTREAM',
            status: 'PASS',
            expected_files: ['chips/quad_uart/specs/intake/INTAKE-quad_uart-20260517-120000/intake_session_record.json'],
            existing_files: ['chips/quad_uart/specs/intake/INTAKE-quad_uart-20260517-120000/intake_session_record.json'],
            missing_files: [],
            next_action: 'requirement_adjudication',
          },
          {
            node_id: 'generation_plan',
            scope_type: 'CHIP_UPSTREAM',
            status: 'NOT_CREATED',
            expected_files: ['chips/quad_uart/generation/graph_to_generation_plan.json'],
            existing_files: [],
            missing_files: ['chips/quad_uart/generation/graph_to_generation_plan.json'],
            next_action: 'runner_execution',
          },
        ],
        adjudication_template: {
          status: 'PENDING_DECISION',
          conditions_suggested: ['Close ambiguity for baud/frame'],
        },
        builder_handoff: {
          handoff_status: adjudicationRecorded ? 'PENDING_VALIDATION' : 'PENDING_HUMAN_ADJUDICATION',
        },
        adjudication_record: adjudicationRecorded
          ? {
              status: 'DECISION_RECORDED',
              decision_outcome: 'approve',
              decision_rationale: 'Spec can proceed after preserving UART channel conditions.',
              authority_signer: 'owner@icaf',
              conditions: ['Keep all four UART channels independently configurable'],
            }
          : null,
      }),
    })
  })

  await page.goto('/requirement-adjudication?chip=quad_uart')

  await expect(page.getByRole('heading', { name: /Requirement Adjudication|需求裁決/ })).toBeVisible()
  await expect(page.getByText(/chip_id:\s*quad_uart/).first()).toBeVisible()
  await expect(page.getByText(/scope_type:\s*CHIP_UPSTREAM/).first()).toBeVisible()
  await expect(page.getByText('upstream_operation_id:').first()).toBeVisible()
  await expect(page.getByText('UOP-INTAKE-quad_uart-20260517-120000').first()).toBeVisible()
  await expect(page.getByText('Upstream Truth Flow Board')).toBeVisible()
  await expect(page.getByText(/This board shows chip upstream truth objects under chips\/quad_uart\//)).toBeVisible()
  await expect(page.getByText('Generation Plan', { exact: true })).toBeVisible()
  await expect(page.getByText('NOT_CREATED').first()).toBeVisible()
  await expect(page.getByText(/review package:\s*PENDING_HUMAN_ADJUDICATION/)).toBeVisible()
  await expect(page.getByText('Close ambiguity for baud/frame')).toBeVisible()
  await expect(page.getByRole('link', { name: /Open Upstream Truth Flow|開啟上游真值流程/ })).toBeVisible()
  await expect(page.getByRole('link', { name: /Open Upstream Truth Flow|開啟上游真值流程/ })).toHaveAttribute('href', /upstream-flow\?chip=quad_uart/)
  await expect(page.getByText(/Open Run Detail|前往 Run Detail/)).toHaveCount(0)
  await expect(page.getByText(/Authority signer and decision rationale are required before writing adjudication|寫入 adjudication 前必須填寫簽署者與決策理由/)).toBeVisible()
  await expect(page.getByRole('button', { name: /Write Adjudication Record|寫入 Adjudication Record/ })).toBeDisabled()
  await page.getByLabel('Authority Signer').fill('owner@icaf')
  await page.getByLabel('Decision Rationale').fill('Spec can proceed after preserving UART channel conditions.')
  await page.getByRole('textbox', { name: 'Conditions' }).fill('Keep all four UART channels independently configurable')
  await expect(page.getByRole('button', { name: /Write Adjudication Record|寫入 Adjudication Record/ })).toBeEnabled()
  await page.getByRole('button', { name: /Write Adjudication Record|寫入 Adjudication Record/ }).click()
  await expect(page).toHaveURL(/\/requirement-adjudication\?chip=quad_uart/)
  await expect(page.getByText(/Adjudication recorded: ADJUDICATED_APPROVED \/ PENDING_VALIDATION|Adjudication 已寫入: ADJUDICATED_APPROVED \/ PENDING_VALIDATION/)).toBeVisible()
  await expect(page.getByText(/review package:\s*ADJUDICATED_APPROVED/)).toBeVisible()
  await expect(page.getByText(/handoff:\s*PENDING_VALIDATION/)).toBeVisible()
  await expect(page.getByRole('link', { name: /Open Upstream Truth Flow|開啟上游真值流程/ })).toHaveAttribute('href', /upstream-flow\?chip=quad_uart/)
  await expect(page.getByText(/Open Run Detail|前往 Run Detail/)).toHaveCount(0)
  expect(postedPayload).toMatchObject({
    chip_id: 'quad_uart',
    decision_outcome: 'approve',
    decision_rationale: 'Spec can proceed after preserving UART channel conditions.',
    authority_signer: 'owner@icaf',
    conditions: ['Keep all four UART channels independently configurable'],
  })

  await expect(page.getByRole('heading', { name: /Local AI Handoff Prompt|本地 AI 交接 Prompt/ })).toBeVisible()
  await expect(page.getByLabel(/Local AI Handoff Prompt|本地 AI 交接 Prompt/)).toContainText('chip_id: quad_uart')
  await expect(page.getByLabel(/Local AI Handoff Prompt|本地 AI 交接 Prompt/)).toContainText('intake_session_id: INTAKE-quad_uart-20260517-120000')
  await expect(page.getByLabel(/Local AI Handoff Prompt|本地 AI 交接 Prompt/)).toContainText('decision_outcome: approve')
  await expect(page.getByLabel(/Local AI Handoff Prompt|本地 AI 交接 Prompt/)).toContainText('authority_signer: owner@icaf')
  await expect(page.getByLabel(/Local AI Handoff Prompt|本地 AI 交接 Prompt/)).toContainText('Spec can proceed after preserving UART channel conditions.')
  await expect(page.getByLabel(/Local AI Handoff Prompt|本地 AI 交接 Prompt/)).toContainText('chips/quad_uart/specs/requirement_item_adjudication_record.json')

  await page.evaluate(() => {
    const clipboard = {
      text: '',
      writeText(value: string) {
        this.text = value
        return Promise.resolve()
      },
    }
    Object.defineProperty(navigator, 'clipboard', {
      configurable: true,
      value: clipboard,
    })
  })
  await page.getByRole('button', { name: /Copy Handoff Prompt|複製交接 Prompt/ }).click()
  await expect(page.getByText(/Handoff prompt copied|交接 Prompt 已複製/)).toBeVisible()

  await page.getByRole('link', { name: /Back to Intake|回到 Intake/ }).click()
  await expect(page).toHaveURL(/\/intake\?/)
  await expect(page).toHaveURL(/chip=quad_uart/)
  await expect(page).toHaveURL(/source=requirement-adjudication/)
  await expect(page).toHaveURL(/intake_session=INTAKE-quad_uart-20260517-120000/)
  await expect(page.locator('input').first()).toHaveValue('quad_uart')
  await expect(page.locator('textarea').first()).toHaveValue('quad uart in one chip and with high speed Tx/Rx')
  await expect(page.getByText(/Restored Intake Session|已還原 Intake Session/)).toBeVisible()
  await expect(
    page.getByText(/Requested intake session not found, fallback to latest existing session|找不到指定 intake session，已回退到最新可用 session/),
  ).toBeVisible()
  await expect(page.getByText(/template_resolution:\s*TEMPLATE_AUTO_RESOLVED/)).toBeVisible()
  await expect(page.getByText(/template_ref:\s*templates\/UART Protocol/).first()).toBeVisible()
  await expect(page.getByText('Upstream Truth Flow Board')).toBeVisible()
  await expect(page.getByText(/This board shows chip upstream truth objects under chips\/quad_uart\//)).toBeVisible()
})

test('requirement adjudication page hides v0.9 handoff preflight block', async ({ page }) => {
  await page.goto('/requirement-adjudication?mode=team_project&chip=quad_uart')

  await expect(page.getByRole('heading', { name: /Requirement Sign-off Gate/i })).toBeVisible()
  await expect(page.getByText('v0.9 Handoff Preflight')).toHaveCount(0)
})

test('requirement adjudication rewrites legacy chip alias to canonical chip id', async ({ page }) => {
  await page.route('**/api/intake/adjudication?chip_id=UART', async (route) => {
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        status: 'ok',
        chip_id: 'quad_uart',
        scope_type: 'CHIP_UPSTREAM',
        requirement_item: {
          draft_status: 'AUTO_DRAFT_PENDING_REVIEW',
          requirement_items: [
            {
              requirement_id: 'REQ-QUAD_UART-001',
              title: 'quad uart in one chip and with high speed Tx/Rx',
              ambiguity_status: 'OPEN',
              ambiguity_note: 'Auto-drafted from intake prompt; human adjudication required.',
            },
          ],
        },
        review_package: {
          status: 'PENDING_HUMAN_ADJUDICATION',
        },
        adjudication_template: {
          status: 'PENDING_DECISION',
          conditions_suggested: ['Close ambiguity for baud/frame'],
        },
        builder_handoff: {
          handoff_status: 'PENDING_HUMAN_ADJUDICATION',
        },
        adjudication_record: null,
      }),
    })
  })
  await page.route('**/api/intake/adjudication?chip_id=quad_uart', async (route) => {
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        status: 'ok',
        chip_id: 'quad_uart',
        scope_type: 'CHIP_UPSTREAM',
        requirement_item: {
          draft_status: 'AUTO_DRAFT_PENDING_REVIEW',
          requirement_items: [
            {
              requirement_id: 'REQ-QUAD_UART-001',
              title: 'quad uart in one chip and with high speed Tx/Rx',
              ambiguity_status: 'OPEN',
              ambiguity_note: 'Auto-drafted from intake prompt; human adjudication required.',
            },
          ],
        },
        review_package: {
          status: 'PENDING_HUMAN_ADJUDICATION',
        },
        adjudication_template: {
          status: 'PENDING_DECISION',
          conditions_suggested: ['Close ambiguity for baud/frame'],
        },
        builder_handoff: {
          handoff_status: 'PENDING_HUMAN_ADJUDICATION',
        },
        adjudication_record: null,
      }),
    })
  })

  await page.goto('/requirement-adjudication?mode=team_project&chip=UART')

  await expect(page).toHaveURL(/chip=quad_uart/)
  await expect(page.getByText(/chip_id:\s*quad_uart/).first()).toBeVisible()
})
