import { execFileSync } from 'node:child_process'
import { existsSync, mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { pathToFileURL } from 'node:url'

import { expect, test } from '@playwright/test'

const repoRoot = path.resolve(import.meta.dirname, '../../..')
const runtimeLib = path.join(repoRoot, 'package_ws/shared-runtime/lib')

const requiredPages = [
  'flow-map.html',
  'node-io.html',
  'artifacts.html',
  'run-detail.html',
  'package-readiness.html',
  'decision-inbox.html',
]

function buildDashboard(): string {
  const outDir = mkdtempSync(path.join(tmpdir(), 'icaf-static-dashboard-'))
  execFileSync(
    'python3',
    [
      '-m',
      'ic_agent_flow.cli.main',
      'dashboard',
      'build-static',
      '--context',
      'release_package_extract',
      '--out',
      outDir,
    ],
    {
      cwd: repoRoot,
      env: {
        ...process.env,
        PYTHONPATH: [runtimeLib, process.env.PYTHONPATH].filter(Boolean).join(path.delimiter),
      },
      stdio: 'pipe',
    },
  )
  return outDir
}

test.describe('PRD v1.7 static dashboard HTML closeout', () => {
  let dashboardDir: string

  test.beforeAll(() => {
    dashboardDir = buildDashboard()
  })

  for (const pageName of requiredPages) {
    test(`${pageName} opens with portable artifact navigation and header icons`, async ({ page }) => {
      const pagePath = path.join(dashboardDir, pageName)
      expect(existsSync(pagePath)).toBe(true)

      await page.goto(pathToFileURL(pagePath).href)

      await expect(page).toHaveTitle(/Flow Control Tower/)
      await expect(page.locator('header')).toContainText('Flow Control Tower')
      await expect(page.locator('h1 .page-title-icon')).toBeVisible()
      await expect(page.locator('.header-icon-nav')).toBeVisible()
      await expect(page.locator('.header-icon-nav a[aria-label="Flow Map"]')).toBeVisible()
      await expect(page.locator('.header-icon-nav a[aria-label="Decision Inbox"]')).toBeVisible()
      const navHint = await page.evaluate(() => {
        const node = document.querySelector('.header-icon-nav a[aria-label="Flow Map"]')
        if (!node) return { content: '', fontSize: '' }
        const style = getComputedStyle(node, '::after')
        return { content: style.content.replaceAll('"', ''), fontSize: style.fontSize }
      })
      expect(navHint.content).toBe('Flow Map')
      expect(navHint.fontSize).toBe('14px')

      const titleHint = await page.evaluate(() => {
        const node = document.querySelector('.page-title-icon-wrap')
        if (!node) return { content: '', fontSize: '' }
        const style = getComputedStyle(node, '::after')
        return { content: style.content.replaceAll('"', ''), fontSize: style.fontSize }
      })
      expect(titleHint.fontSize).toBe('15px')

      await expect(page.getByText('release_package_extract')).toBeVisible()
      await expect(page.getByText('icaf://artifact/production-runs/SN2025/raw/yosys.raw.log')).toBeVisible()
      await expect(page.getByText('artifacts/production-runs/SN2025/raw/yosys.raw.log')).toBeVisible()
      await expect(page.getByText('/customer-home/imac')).toHaveCount(0)

      const hasHorizontalOverflow = await page.evaluate(
        () => document.documentElement.scrollWidth > document.documentElement.clientWidth,
      )
      expect(hasHorizontalOverflow).toBe(false)
    })
  }
})
