import { execFileSync } from 'node:child_process'
import { existsSync, mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { pathToFileURL } from 'node:url'

import { expect, test } from '@playwright/test'

const repoRoot = path.resolve(import.meta.dirname, '../../..')
const runtimeLib = path.join(repoRoot, 'package_ws/shared-runtime/lib')

const requiredPages = [
  'flow-map.html',
  'node-io.html',
  'artifacts.html',
  'run-detail.html',
  'package-readiness.html',
  'decision-inbox.html',
]

function buildDashboardV18(): string {
  const outDir = mkdtempSync(path.join(tmpdir(), 'icaf-static-dashboard-v18-'))
  execFileSync(
    'python3',
    [
      '-m',
      'ic_agent_flow.cli.main',
      'dashboard',
      'build-static',
      '--context',
      'release_package_extract',
      '--dashboard-version',
      'v1_8',
      '--out',
      outDir,
    ],
    {
      cwd: repoRoot,
      env: {
        ...process.env,
        PYTHONPATH: [runtimeLib, process.env.PYTHONPATH].filter(Boolean).join(path.delimiter),
      },
      stdio: 'pipe',
    },
  )
  return outDir
}

test.describe('PRD v1.8 static dashboard HTML baseline', () => {
  let dashboardDir: string

  test.beforeAll(() => {
    dashboardDir = buildDashboardV18()
  })

  for (const pageName of requiredPages) {
    test(`${pageName} opens with v1.8 branding and package-safe paths`, async ({ page }) => {
      const pagePath = path.join(dashboardDir, pageName)
      expect(existsSync(pagePath)).toBe(true)

      await page.goto(pathToFileURL(pagePath).href)

      await expect(page).toHaveTitle(/Flow Control Tower/)
      await expect(page.locator('header')).toContainText('Flow Control Tower')
      await expect(page.locator('header')).toContainText('PRD v1.8 static dashboard')
      await expect(page.locator('h1 .page-title-icon')).toBeVisible()
      await expect(page.locator('.header-icon-nav a[aria-label="Flow Map"]')).toBeVisible()
      await expect(page.locator('.header-icon-nav a[aria-label="Decision Inbox"]')).toBeVisible()
      await expect(page.getByText('release_package_extract')).toBeVisible()
      await expect(page.getByText('icaf://artifact/production-runs/SN2025/raw/yosys.raw.log')).toBeVisible()
      await expect(page.getByText('artifacts/production-runs/SN2025/raw/yosys.raw.log')).toBeVisible()
      await expect(page.getByText('/customer-home/imac')).toHaveCount(0)
    })
  }
})
