import { expect, test } from '@playwright/test'

test('hint tooltip supports click-open behavior on chip id', async ({ page }) => {
  await page.route('**/api/intake/options', async (route) => {
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        templates_root: 'templates',
        templates: [{ name: 'UART Protocol', path: 'templates/UART Protocol' }],
      }),
    })
  })

  await page.goto('/intake')

  const hintButton = page
    .locator('label:has(input[placeholder*="uart-controller"]) button[aria-controls]')
    .first()
  await hintButton.click()

  await expect(hintButton).toHaveAttribute('aria-expanded', 'true')
  await expect(page.getByText('chips/<chip-id>/...')).toBeVisible()
})

test('template override surfaces empty/retry message when options API fails', async ({ page }) => {
  await page.route('**/api/intake/options', async (route) => {
    await route.fulfill({
      status: 503,
      contentType: 'application/json',
      body: JSON.stringify({ error: 'service_unavailable' }),
    })
  })

  await page.goto('/intake')
  await page.getByLabel('Use manual template override').check()

  await expect(page.getByText('No template options loaded. Ensure intake API server is running.')).toBeVisible()
  await expect(page.getByRole('button', { name: 'Retry' })).toBeVisible()
})

test('attachments keep previous selection and support explicit remove action', async ({ page }) => {
  await page.route('**/api/intake/options', async (route) => {
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        templates_root: 'templates',
        templates: [{ name: 'UART Protocol', path: 'templates/UART Protocol' }],
      }),
    })
  })

  await page.goto('/intake')
  const attachmentInput = page.locator('input[type="file"][accept=".txt,.md,.pdf,.jpg,.jpeg,.png"]')

  await attachmentInput.setInputFiles([
    {
      name: 'first-spec.md',
      mimeType: 'text/markdown',
      buffer: Buffer.from('# first'),
    },
  ])
  await attachmentInput.setInputFiles([
    {
      name: 'second-spec.md',
      mimeType: 'text/markdown',
      buffer: Buffer.from('# second'),
    },
  ])

  await expect(page.getByText('first-spec.md')).toBeVisible()
  await expect(page.getByText('second-spec.md')).toBeVisible()

  await page.getByLabel('remove-first-spec.md').click()
  await expect(page.getByText('first-spec.md')).toHaveCount(0)
  await expect(page.getByText('second-spec.md')).toBeVisible()
})

test('successful execute intake renders upstream truth flow board without run evidence claim', async ({ page }) => {
  await page.route('**/api/intake/options', async (route) => {
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        templates_root: 'templates',
        templates: [{ name: 'UART Protocol', path: 'templates/UART Protocol' }],
      }),
    })
  })
  await page.route('**/api/intake', async (route) => {
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        scope_type: 'CHIP_UPSTREAM',
        upstream_operation_id: 'UOP-INTAKE-quad_uart-20260517-120000',
        chip_id: 'quad_uart',
        intake_session_id: 'INTAKE-quad_uart-20260517-120000',
        bootstrap_mode: 'TEMPLATE_BASED',
        session_dir_ref: 'chips/quad_uart/specs/intake/INTAKE-quad_uart-20260517-120000',
        requirement_item_ref: 'chips/quad_uart/specs/requirement_item.json',
        requirement_item_review_package_ref: 'chips/quad_uart/specs/requirement_item_review_package.json',
        requirement_item_adjudication_template_ref:
          'chips/quad_uart/specs/requirement_item_adjudication_record.template.json',
        graph_draft_ref: 'chips/quad_uart/architecture/architecture_graph.draft.json',
        builder_handoff_ref: 'chips/quad_uart/architecture/builder_validation_handoff.json',
      }),
    })
  })

  await page.goto('/intake')
  await page.locator('input').first().fill('quad uart')
  await page.locator('textarea').first().fill('quad uart in one chip and with high speed Tx/Rx')
  await page.getByRole('button', { name: /Execute Intake/ }).click()

  await expect(page.getByText(/Intake submitted:/)).toBeVisible()
  await expect(page.getByTestId('upstream-truth-flow-board')).toBeVisible()
  await expect(page.getByText(/This board shows chip upstream truth objects under chips\/quad_uart\//)).toBeVisible()
  await expect(page.getByTestId('intake-main-grid').getByTestId('upstream-truth-flow-board')).toHaveCount(0)
  await expect(page.getByTestId('upstream-truth-flow-board-nodes')).toHaveCSS('grid-auto-flow', 'row')
  await expect(page.getByText('chips/quad_uart/specs/requirement_item_adjudication_record.json').last()).toBeVisible()
  await expect(page.getByText('v0.9 Handoff Preflight')).toHaveCount(0)
})
