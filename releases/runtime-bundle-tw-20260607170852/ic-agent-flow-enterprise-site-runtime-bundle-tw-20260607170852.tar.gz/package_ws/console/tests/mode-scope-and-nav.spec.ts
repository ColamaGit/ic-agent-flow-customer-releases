import { expect, test } from '@playwright/test'

test('artifacts page keeps dynamically created chips visible in solo mode', async ({ page }) => {
  await page.route('**/portfolio/summaries/production_runs_inventory.json?*', async (route) => {
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        workspace_id: 'icaf',
        timestamp: '2026-05-17T12:00:00Z',
        chips: [
          { chip_id: 'SN2025', source_dir: 'sn2025', runs: [] },
          { chip_id: 'QUAD_UART', source_dir: 'quad_uart', runs: [] },
        ],
      }),
    })
  })

  await page.goto('/artifacts?mode=solo_eval')

  await expect(page.locator('tbody tr').filter({ hasText: 'SN2025' })).toBeVisible()
  await expect(page.locator('tbody tr').filter({ hasText: 'QUAD_UART' })).toBeVisible()
})

test('requirement adjudication route has dedicated nav icon entry', async ({ page }) => {
  await page.route('**/api/intake/adjudication?chip_id=quad_uart', async (route) => {
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        status: 'ok',
        chip_id: 'quad_uart',
        requirement_item: {
          draft_status: 'AUTO_DRAFT_PENDING_REVIEW',
          requirement_items: [
            {
              requirement_id: 'REQ-QUAD_UART-001',
              title: 'quad uart in one chip and with high speed Tx/Rx',
              ambiguity_status: 'OPEN',
              ambiguity_note: 'Auto-drafted from intake prompt; human adjudication required.',
            },
          ],
        },
        review_package: { status: 'PENDING_HUMAN_ADJUDICATION' },
        adjudication_template: {
          status: 'PENDING_DECISION',
          conditions_suggested: ['Close ambiguity for baud/frame'],
        },
        builder_handoff: { handoff_status: 'PENDING_HUMAN_ADJUDICATION' },
        adjudication_record: null,
      }),
    })
  })

  await page.goto('/requirement-adjudication?chip=quad_uart')

  await expect(page.locator('a[data-route-key="/requirement-adjudication"]')).toBeVisible()
})
