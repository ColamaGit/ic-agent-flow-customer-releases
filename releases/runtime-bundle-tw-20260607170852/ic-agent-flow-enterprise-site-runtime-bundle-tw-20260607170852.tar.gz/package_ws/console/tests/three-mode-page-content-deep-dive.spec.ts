import { expect, test } from '@playwright/test'

type OperatingMode = 'solo_eval' | 'team_project' | 'enterprise_site'

const modes: OperatingMode[] = ['solo_eval', 'team_project', 'enterprise_site']

const routes = [
  '/console',
  '/intake',
  '/flow-map',
  '/run-detail',
  '/node-io',
  '/artifacts',
  '/qa-trust',
  '/qa-strategy',
  '/decision-inbox',
  '/package-readiness',
  '/authority-plane',
  '/audit-replay',
  '/style-guide',
]

test.describe('PRD v1.7/v1.8 deep-dive: three-mode page coverage', () => {
  for (const mode of modes) {
    for (const route of routes) {
      test(`${mode} ${route} renders valid content`, async ({ page }, testInfo) => {
        await page.goto(`${route}?mode=${mode}`)

        const topBanner = page.getByRole('banner').first()
        await expect(topBanner).toContainText(mode)

        const headingCount = await page.locator('main h1').count()
        if (headingCount > 0) {
          await expect(page.locator('main h1').first()).toBeVisible()
        } else {
          await expect(page.locator('main')).toContainText(/No explicit Gate Evidence|No signoff evidence records|No Human Adjudication Records|No data/i)
        }

        const bodyTextLength = await page.evaluate(() => document.body.innerText.trim().length)
        expect(bodyTextLength).toBeGreaterThan(120)

        const pageText = await page.locator('main').innerText()
        expect(pageText).not.toContain('Cannot GET')
        expect(pageText).not.toContain('Not Found')
        expect(pageText).not.toContain('undefined')

        // Hard gate: every mode must be first-class; non-team modes cannot render team-only activation title.
        if (route === '/decision-inbox') {
          await expect(page.locator('main')).toContainText(`Approve activation for ${mode} package`)
        }

        await testInfo.attach(`screenshot-${mode}-${route.replaceAll('/', '_') || 'root'}`, {
          body: await page.screenshot({ fullPage: true }),
          contentType: 'image/png',
        })
      })
    }
  }
})
