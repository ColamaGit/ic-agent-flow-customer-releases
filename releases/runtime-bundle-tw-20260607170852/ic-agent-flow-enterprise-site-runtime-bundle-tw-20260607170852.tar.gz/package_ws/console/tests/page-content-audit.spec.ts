import { expect, test } from '@playwright/test'

type PageAuditTarget = {
  path: string
  description: string
  kind: 'react-route' | 'static-html'
}

const targets: PageAuditTarget[] = [
  { path: '/flow-map', description: 'Flow map view (GateBoard)', kind: 'react-route' },
  { path: '/node-io', description: 'Node IO view (HumanReview)', kind: 'react-route' },
  { path: '/artifacts', description: 'Artifact browser view (QADashboard)', kind: 'react-route' },
  { path: '/run-detail', description: 'Run detail view', kind: 'react-route' },
  { path: '/package-readiness', description: 'Package readiness view (HumanAuthority)', kind: 'react-route' },
  { path: '/decision-inbox', description: 'Decision inbox view (QADashboard)', kind: 'react-route' },
  { path: '/run/latest', description: 'Legacy run route with bundle parameter', kind: 'react-route' },
  { path: '/verdicts/latest', description: 'Legacy verdicts route with bundle parameter', kind: 'react-route' },
  { path: '/checkpoint/latest', description: 'Legacy checkpoint route with bundle parameter', kind: 'react-route' },
  { path: '/authority', description: 'Legacy authority route', kind: 'react-route' },
  { path: '/qa', description: 'Legacy QA route', kind: 'react-route' },
  { path: '/intake', description: 'Requirement intake route', kind: 'react-route' },
  { path: '/static-dashboard-v17-icons/index.html', description: 'Static dashboard overview page', kind: 'static-html' },
  { path: '/static-dashboard-v17-icons/flow-map.html', description: 'Static dashboard flow map page', kind: 'static-html' },
  { path: '/static-dashboard-v17-icons/node-io.html', description: 'Static dashboard node IO page', kind: 'static-html' },
  { path: '/static-dashboard-v17-icons/artifacts.html', description: 'Static dashboard artifacts page', kind: 'static-html' },
  { path: '/static-dashboard-v17-icons/run-detail.html', description: 'Static dashboard run detail page', kind: 'static-html' },
  { path: '/static-dashboard-v17-icons/package-readiness.html', description: 'Static dashboard package readiness page', kind: 'static-html' },
  { path: '/static-dashboard-v17-icons/decision-inbox.html', description: 'Static dashboard decision inbox page', kind: 'static-html' },
]

test.describe('console module page content audit', () => {
  for (const target of targets) {
    test(`${target.path} has real visible content`, async ({ page }) => {
      await page.goto(target.path)

      const bodyTextLength = await page.evaluate(() => document.body.innerText.trim().length)
      const hasHeading = (await page.locator('h1, h2').count()) > 0
      const hasMainLikeElement = (await page.locator('main, table, form, textarea, button').count()) > 0
      const rawHtml = await page.content()

      expect(rawHtml).not.toContain('Cannot GET')
      expect(rawHtml).not.toContain('<pre>Not Found</pre>')
      expect(bodyTextLength).toBeGreaterThan(80)
      expect(hasHeading || hasMainLikeElement).toBeTruthy()
    })
  }
})
