import { expect, test } from '@playwright/test'

test('knowledge asset center inventory block clarifies unique assets and source occurrences', async ({ page }) => {
  await page.goto('/knowledge-assets?mode=enterprise_site&context=shared_packs')

  await expect(page.getByRole('heading', { name: /Asset Inventory — Unique Assets:/i })).toContainText('Unique Assets')
  await expect(page.getByRole('heading', { name: /Asset Inventory — Unique Assets:/i })).toContainText('Source Occurrences')

  const initialRows = page.locator('table tbody tr')
  await expect(initialRows.first()).toBeVisible()

  await page.getByLabel('Flow Scope').selectOption('PLATFORM_LINE')
  await expect(initialRows).toHaveCount(2)
  await expect(page.getByRole('heading', { name: /Asset Inventory — Unique Assets:/i })).toContainText('Unique Assets')
})
