import { expect, test } from '@playwright/test'

test('run detail selectors change scope on SN2025 route', async ({ page }) => {
  await page.goto('/run/SN2025?mode=team_project&run=T-SN2025-01&execution=20260508-170714')
  await expect(page.getByRole('heading', { name: /Run Artifact Explorer/i })).toBeVisible()

  const runSelect = page.locator('label').filter({ hasText: 'Run ID' }).locator('select')
  const executionSelect = page.locator('label').filter({ hasText: 'Execution Timestamp' }).locator('select')
  const resolvedRoot = page.locator('div').filter({ hasText: 'Resolved Root' }).locator('..').locator('.text-xs.font-mono.text-cyan-300').first()

  const runOptions = await runSelect.locator('option').evaluateAll((opts) => opts.map((o) => ({ value: (o as HTMLOptionElement).value, text: o.textContent ?? '' })))
  const executionOptionsBefore = await executionSelect.locator('option').evaluateAll((opts) => opts.map((o) => ({ value: (o as HTMLOptionElement).value, text: o.textContent ?? '' })))

  expect(runOptions.length).toBeGreaterThan(1)
  expect(executionOptionsBefore.length).toBeGreaterThan(1)

  const initialRun = await runSelect.inputValue()
  const initialExecution = await executionSelect.inputValue()
  const nextRun = runOptions.find((o) => o.value !== initialRun)
  expect(nextRun).toBeTruthy()

  await runSelect.selectOption(nextRun!.value)
  await expect(runSelect).toHaveValue(nextRun!.value)
  await expect(page).toHaveURL(new RegExp(`run=${encodeURIComponent(nextRun!.value)}`))

  const executionOptionsAfterRun = await executionSelect.locator('option').evaluateAll((opts) => opts.map((o) => ({ value: (o as HTMLOptionElement).value, text: o.textContent ?? '' })))
  const nextExecution = executionOptionsAfterRun.find((o) => o.value !== initialExecution)
  expect(nextExecution).toBeTruthy()

  await executionSelect.selectOption(nextExecution!.value)
  await expect(executionSelect).toHaveValue(nextExecution!.value)
  await expect(page).toHaveURL(new RegExp(`execution=${encodeURIComponent(nextExecution!.value)}`))
  await expect(resolvedRoot).toContainText(nextExecution!.value)
})
