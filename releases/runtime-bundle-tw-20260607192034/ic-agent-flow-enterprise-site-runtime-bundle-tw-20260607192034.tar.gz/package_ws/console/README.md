# Console Runtime Notes

This console is a Vite + React frontend for governed run evidence and authority workflows.

## Boot Modes

### 1) Default dev (frontend + intake API)

```bash
cd package_ws/console
npm run dev
```

- Starts both:
  - intake API server (`127.0.0.1:8787`)
  - Vite frontend (`127.0.0.1:5173`)
- This is the recommended default for normal console usage.

### 2) Frontend only (debug mode)

```bash
cd package_ws/console
npm run dev:frontend
```

- Starts only Vite frontend.
- `/api/*` endpoints require a separate intake API process.

## Why This Matters

- The frontend proxies `/api/*` to `127.0.0.1:8787` via `vite.config.ts`.
- If port `8787` is not serving intake API, `/intake` and browser-native trust actions can fail with HTTP errors.

## Root-Path Materialization Contract

Intake-created artifacts must land under repo root:

- `chips/...`
- `artifacts/...`

They must **not** land under `package_ws/console/chips/...`.

This contract is enforced in `package_ws/shared-runtime/scripts/run_requirement_intake.py` using repo-root based paths.

## Release Package Clarification

- In customer release/extract mode, console remains a derived view surface.
- If intake operations are enabled in a package environment, package must include/route a valid intake API endpoint.
- Do not assume dev-local `127.0.0.1:8787` exists in customer environments unless explicitly provided.
