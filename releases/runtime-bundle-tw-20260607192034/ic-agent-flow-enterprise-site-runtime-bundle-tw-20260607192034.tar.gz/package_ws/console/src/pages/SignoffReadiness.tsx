import { useEffect, useMemo, useState } from 'react'
import { useNavigate, useParams, useLocation } from 'react-router-dom'
import { useProductionRunsInventory } from '../hooks/useProductionRunsInventory'
import { parseMode, sortChipsForMode } from '../hooks/evidenceSummary'
import { useRunDetailExecutions } from '../hooks/useRunDetailExecutions'
import { useTranslation } from '../contexts/i18n'
import { AlertTriangle, CheckCircle2, MinusCircle, ShieldAlert } from 'lucide-react'

function normalizeSequencePath(path: string) {
  return path
    .split('/')
    .map((seg) => seg.replace(/^\d+_/, ''))
    .join('/')
}

function parseArtifactJson(files: Array<{ relative_path: string; kind: 'file' | 'dir'; preview_text?: string | null }>, logicalPath: string) {
  const normalizedLogicalPath = normalizeSequencePath(logicalPath)
  const found = files.find(
    (f) =>
      f.kind === 'file' &&
      (f.relative_path === logicalPath || normalizeSequencePath(f.relative_path) === normalizedLogicalPath),
  )
  if (!found?.preview_text) return null
  try {
    return JSON.parse(found.preview_text) as Record<string, unknown>
  } catch {
    return null
  }
}

function resolveActionCommandContext(resolvedRoot: string | undefined, fallbackRelativeRunDir: string) {
  const normalizedFallback = fallbackRelativeRunDir.replace(/\\/g, '/')
  const source = (resolvedRoot ?? '').trim().replace(/\\/g, '/')
  if (!source) {
    return { scriptPath: 'package_ws/shared-runtime/scripts/apply_signoff_decision_action.py', runDirArg: normalizedFallback }
  }
  const repoMarker = '/artifacts/production-runs/'
  const repoIdx = source.lastIndexOf(repoMarker)
  if (repoIdx >= 0) {
    return {
      scriptPath: 'package_ws/shared-runtime/scripts/apply_signoff_decision_action.py',
      runDirArg: source.slice(repoIdx + 1),
    }
  }
  const releaseMarker = '/production-runs/'
  const releaseIdx = source.lastIndexOf(releaseMarker)
  if (releaseIdx >= 0) {
    const sourceRunDir = source.slice(releaseIdx + 1)
    if (normalizedFallback.startsWith('artifacts/production-runs/')) {
      return {
        scriptPath: 'scripts/apply_signoff_decision_action.py',
        runDirArg: normalizedFallback,
      }
    }
    return {
      scriptPath: 'scripts/apply_signoff_decision_action.py',
      runDirArg: sourceRunDir,
    }
  }
  return { scriptPath: 'scripts/apply_signoff_decision_action.py', runDirArg: normalizedFallback }
}

function statusPill(statusRaw: string) {
  const status = statusRaw.toUpperCase()
  if (status === 'PASS' || status === 'READY_FOR_TAPEOUT_PACKAGE_ASSEMBLY') {
    return {
      icon: <CheckCircle2 size={14} className="text-emerald-300" />,
      className: 'border-emerald-700/50 bg-emerald-900/20 text-emerald-200',
      label: statusRaw,
    }
  }
  if (status === 'PASS_WITH_LIMITATION' || status === 'PASS_WITH_CONDITIONS' || status === 'CONDITIONAL_PASS') {
    return {
      icon: <AlertTriangle size={14} className="text-amber-300" />,
      className: 'border-amber-700/50 bg-amber-900/20 text-amber-200',
      label: statusRaw,
    }
  }
  if (status === 'BLOCKED' || status === 'INVALID') {
    return {
      icon: <ShieldAlert size={14} className="text-red-300" />,
      className: 'border-red-700/50 bg-red-900/20 text-red-200',
      label: statusRaw,
    }
  }
  if (status === 'PENDING' || status === 'PARTIAL') {
    return {
      icon: <AlertTriangle size={14} className="text-amber-300" />,
      className: 'border-amber-700/50 bg-amber-900/20 text-amber-200',
      label: statusRaw,
    }
  }
  return {
    icon: <MinusCircle size={14} className="text-slate-300" />,
    className: 'border-slate-700 bg-slate-900/40 text-slate-200',
    label: statusRaw,
  }
}

function mapBlockedClaimToRecommendation(token: string): string {
  const normalized = token.trim().toLowerCase()
  if (normalized.includes('tapeout_ready') || normalized.includes('drc_clean')) {
    return 'request_revalidation'
  }
  if (normalized.includes('full_chip_functional_equivalence_proven') || normalized.includes('full_cpu_equivalence_proven')) {
    return 'start_waiver_review_path'
  }
  if (normalized.includes('foundry_ready') || normalized.includes('silicon_proven')) {
    return 'block_public_claim_and_escalate_authority_review'
  }
  return 'request_more_evidence'
}

function buildRoutingCliTemplates(
  recommendation: string,
  runDir: string,
): string[] {
  if (recommendation === 'request_revalidation') {
    return [
      'python3 package_ws/shared-runtime/scripts/backfill_signoff_readiness_summary.py --artifacts-root artifacts/production-runs',
      `python3 package_ws/shared-runtime/scripts/apply_signoff_decision_action.py --run-dir ${runDir} --action-id finalize_tapeout_readiness --actor-role RELEASE_AUTHORITY`,
    ]
  }
  if (recommendation === 'start_waiver_review_path') {
    return [
      `python3 package_ws/shared-runtime/scripts/apply_signoff_decision_action.py --run-dir ${runDir} --action-id approve_waiver --actor-role SIGNOFF_APPROVER`,
      `python3 package_ws/shared-runtime/scripts/apply_signoff_decision_action.py --run-dir ${runDir} --action-id accept_risk --actor-role RELEASE_AUTHORITY`,
    ]
  }
  if (recommendation === 'block_public_claim_and_escalate_authority_review') {
    return [
      `python3 package_ws/shared-runtime/scripts/apply_signoff_decision_action.py --run-dir ${runDir} --action-id finalize_tapeout_readiness --actor-role RELEASE_AUTHORITY`,
      '# escalate: open authority review and keep status BLOCKED until domain closure evidence is complete',
    ]
  }
  return [
    '# request_more_evidence: attach missing domain evidence then re-run signoff adjudication',
    `python3 package_ws/shared-runtime/scripts/apply_signoff_decision_action.py --run-dir ${runDir} --action-id finalize_tapeout_readiness --actor-role RELEASE_AUTHORITY`,
  ]
}

export default function SignoffReadiness() {
  const { bundleId } = useParams<{ bundleId: string }>()
  const location = useLocation()
  const navigate = useNavigate()
  const { t } = useTranslation()
  const mode = useMemo(() => parseMode(location.search), [location.search])
  const searchParams = useMemo(() => new URLSearchParams(location.search), [location.search])
  const requestedRunId = searchParams.get('run') ?? ''
  const requestedExecutionId = searchParams.get('execution') ?? ''
  const { data, loading, error } = useProductionRunsInventory({ layeredWithRuns: true })

  const chips = useMemo(() => sortChipsForMode(data?.chips ?? [], mode), [data, mode])

  const [chipSourceDirOverride, setChipSourceDirOverride] = useState('')
  const initialChip = useMemo(() => {
    if (!chips.length) return ''
    if (!bundleId) return chips[0].source_dir
    return chips.find((c) => c.chip_id === bundleId)?.source_dir ?? chips[0].source_dir
  }, [bundleId, chips])
  const selectedChip = chips.find((c) => c.source_dir === (chipSourceDirOverride || initialChip))

  const runs = selectedChip?.runs ?? []
  const [runOverride, setRunOverride] = useState('')
  const runId = runOverride || (requestedRunId && runs.some((r) => r.run_id === requestedRunId) ? requestedRunId : runs[0]?.run_id || '')
  const selectedRun = runs.find((r) => r.run_id === runId)

  const { executions: runDetailExecutions } = useRunDetailExecutions(selectedChip?.source_dir ?? '', selectedRun?.run_id ?? '')
  const executions = runDetailExecutions ?? selectedRun?.executions ?? []
  const [executionOverride, setExecutionOverride] = useState('')
  const executionId =
    executionOverride ||
    (requestedExecutionId && executions.some((e) => e.execution_id === requestedExecutionId)
      ? requestedExecutionId
      : executions[executions.length - 1]?.execution_id || '')
  const selectedExecution = executions.find((e) => e.execution_id === executionId)

  useEffect(() => {
    if (!selectedChip) return
    const current = new URLSearchParams(location.search)
    const currentMode = current.get('mode') ?? 'team_project'
    const currentRun = current.get('run') ?? ''
    const currentExec = current.get('execution') ?? ''
    const desiredRun = runId || ''
    const desiredExec = executionId || ''
    const pathChip = bundleId ?? ''

    if (
      pathChip === selectedChip.chip_id &&
      currentMode === mode &&
      currentRun === desiredRun &&
      currentExec === desiredExec
    ) {
      return
    }

    const next = new URLSearchParams()
    next.set('mode', mode)
    if (desiredRun) next.set('run', desiredRun)
    if (desiredExec) next.set('execution', desiredExec)
    navigate(`/signoff/${encodeURIComponent(selectedChip.chip_id)}?${next.toString()}`, { replace: true })
  }, [bundleId, executionId, location.search, mode, navigate, runId, selectedChip])

  const fileList = useMemo(() => selectedExecution?.files ?? [], [selectedExecution])

  const signoffMatrix = parseArtifactJson(fileList, 'dashboard_objects/signoff_domain_matrix.json')
  const gapRecord = parseArtifactJson(fileList, 'dashboard_objects/signoff_gap_record.json')
  const finalReadiness = parseArtifactJson(fileList, 'dashboard_objects/final_tapeout_readiness_record.json')
  const bindingRecord = parseArtifactJson(fileList, 'dashboard_objects/silicon_contract_v113_binding_record.json')
  const decisionInbox = parseArtifactJson(fileList, 'dashboard_objects/signoff_decision_inbox.json')
  const stageClaimBoundary = parseArtifactJson(fileList, 'dashboard_objects/stage_claim_boundary_record.json')
  const stageConditionalPass = parseArtifactJson(fileList, 'dashboard_objects/stage_conditional_pass_record.json')
  const flowCompletionVerdict = parseArtifactJson(fileList, 'dashboard_objects/flow_completion_verdict_record.json')
  const actionCliTemplates = parseArtifactJson(fileList, 'dashboard_objects/signoff_action_cli_templates.json')
  const actionHistory = useMemo(() => {
    const rows: Array<Record<string, string>> = []
    const actionFiles = fileList
      .filter((f) => f.kind === 'file' && normalizeSequencePath(f.relative_path).startsWith('dashboard_objects/signoff_action_records/') && f.relative_path.endsWith('.json'))
      .sort((a, b) => b.relative_path.localeCompare(a.relative_path))
    for (const file of actionFiles) {
      if (!file.preview_text) continue
      try {
        const parsed = JSON.parse(file.preview_text) as Record<string, unknown>
        rows.push({
          action_id: String(parsed.action_id ?? '-'),
          actor_role: String(parsed.actor_role ?? '-'),
          result: String(parsed.result ?? '-'),
          generated_at: String(parsed.generated_at ?? '-'),
          notes: String(parsed.notes ?? '-'),
        })
      } catch {
        // ignore parse error
      }
    }
    return rows
  }, [fileList])

  const domains = (signoffMatrix?.domains as Array<Record<string, unknown>> | undefined) ?? []
  const missing = (gapRecord?.missing_required_evidence as Array<Record<string, unknown>> | undefined) ?? []
  const domainRows = domains.map((d) => {
    const domainId = String(d.domain_id ?? '-')
    const blocked = missing.some((m) => String(m.domain_id ?? '') === domainId)
    const conditionalDrc =
      domainId === 'DRC' && String(stageConditionalPass?.verdict ?? '').toUpperCase() === 'CONDITIONAL_PASS'
    const cdcLite =
      domainId === 'CDC_LITE' &&
      Array.isArray(d.claim_class_allowed) &&
      d.claim_class_allowed.includes('NON_SIGNOFF_CDC_LITE')
    let status = 'PASS'
    if (blocked) status = 'BLOCKED'
    else if (conditionalDrc) status = 'CONDITIONAL_PASS'
    else if (cdcLite) status = 'PASS_WITH_LIMITATION'
    const scope =
      domainId === 'DRC'
        ? String(stageConditionalPass?.stage ?? 'S10_DRC')
        : domainId === 'CDC_LITE'
          ? 'CDC_LITE_NON_SIGNOFF_SCOPE'
          : 'DOMAIN_SCOPE'
    const limitations =
      domainId === 'DRC'
        ? ((stageConditionalPass?.violation_classes as Array<Record<string, unknown>> | undefined) ?? []).map((v) =>
            `${String(v.rule ?? '-')} [${String(v.class ?? '-')}]`
          )
        : domainId === 'CDC_LITE'
          ? ['non_signoff_cdc_lite_domain']
          : []
    const blockedClaims =
      domainId === 'DRC'
        ? ((stageConditionalPass?.blocked_claims as string[] | undefined) ?? [])
        : domainId === 'CDC_LITE'
          ? ['cdc_lite_cannot_claim_full_cdc_signoff']
          : []
    return {
      domainId,
      ownerRole: String(d.owner_role ?? '-'),
      toolClass: Array.isArray(d.accepted_tool_class) ? d.accepted_tool_class.join(', ') : '-',
      claimClass: Array.isArray(d.claim_class_allowed) ? d.claim_class_allowed.join(', ') : '-',
      status,
      scope,
      limitations,
      blockedClaims,
    }
  })
  const hasBlocked = domainRows.some((row) => row.status === 'BLOCKED') || String(finalReadiness?.status ?? '').toUpperCase() === 'BLOCKED' || String(finalReadiness?.status ?? '').toUpperCase() === 'INVALID'

  if (loading) return <div className="rounded-xl border border-slate-800 bg-slate-900 p-6 text-sm text-slate-300">{t('common.loading')}</div>
  if (error) return <div className="rounded-xl border border-red-900/40 bg-red-950/30 p-6 text-sm text-red-200">{t('common.error')}: {error}</div>

  return (
    <div className="space-y-5">
      <section className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
        <h2 className="text-lg font-semibold text-slate-100">{t('signoff.title')}</h2>
        <p className="mt-1 text-xs text-slate-400">{t('signoff.subtitle')}</p>
        <div className="mt-4 grid gap-3 md:grid-cols-3">
          <select value={selectedChip?.source_dir ?? ''} onChange={(e) => { setChipSourceDirOverride(e.target.value); setRunOverride(''); setExecutionOverride('') }} className="rounded border border-slate-700 bg-slate-950 px-2 py-2 text-sm text-slate-200">
            {chips.map((chip) => <option key={chip.source_dir} value={chip.source_dir}>{chip.chip_id}</option>)}
          </select>
          <select value={runId} onChange={(e) => { setRunOverride(e.target.value); setExecutionOverride('') }} className="rounded border border-slate-700 bg-slate-950 px-2 py-2 text-sm text-slate-200">
            {runs.map((run) => <option key={run.run_id} value={run.run_id}>{run.run_id}</option>)}
          </select>
          <select value={executionId} onChange={(e) => setExecutionOverride(e.target.value)} className="rounded border border-slate-700 bg-slate-950 px-2 py-2 text-sm text-slate-200">
            {executions.map((exec) => <option key={exec.execution_id} value={exec.execution_id}>{exec.execution_id}</option>)}
          </select>
        </div>
      </section>

      <section className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
        <div className="grid gap-3 md:grid-cols-3">
          <div className="rounded border border-slate-800 bg-slate-950/50 p-3">
            <div className="text-xs text-slate-400">{t('signoff.final_readiness')}</div>
            <div className="mt-1 text-base font-semibold text-slate-100">{String(finalReadiness?.status ?? 'NOT_AVAILABLE')}</div>
          </div>
          <div className="rounded border border-slate-800 bg-slate-950/50 p-3">
            <div className="text-xs text-slate-400">{t('signoff.binding_status')}</div>
            <div className="mt-1 text-base font-semibold text-slate-100">{String(bindingRecord?.contract_status ?? 'NOT_AVAILABLE')}</div>
          </div>
          <div className="rounded border border-slate-800 bg-slate-950/50 p-3">
            <div className="text-xs text-slate-400">flow_execution_verdict</div>
            <div className="mt-1 text-base font-semibold text-slate-100">{String(flowCompletionVerdict?.execution_verdict ?? 'NOT_AVAILABLE')}</div>
            <div className="mt-1 text-[11px] text-slate-400">{String(stageClaimBoundary?.claim_class ?? 'NOT_AVAILABLE')}</div>
          </div>
        </div>
      </section>

      <section className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
        <h3 className="text-sm font-semibold text-slate-100">{t('signoff.domain_table_title')}</h3>
        <div className="mt-3 overflow-x-auto">
          <table className="min-w-full text-left text-xs">
            <thead className="bg-slate-900 text-slate-300">
              <tr>
                <th className="px-2 py-2">{t('signoff.col_domain')}</th>
                <th className="px-2 py-2">{t('signoff.col_status')}</th>
                <th className="px-2 py-2">{t('signoff.col_owner')}</th>
                <th className="px-2 py-2">{t('signoff.col_tool')}</th>
                <th className="px-2 py-2">{t('signoff.col_claim')}</th>
                <th className="px-2 py-2">scope</th>
                <th className="px-2 py-2">limitations</th>
                <th className="px-2 py-2">blocked_claims</th>
              </tr>
            </thead>
            <tbody>
              {domainRows.map((row) => (
                <tr key={row.domainId} className="border-t border-slate-800">
                  <td className="px-2 py-2 text-slate-200">{row.domainId}</td>
                  <td className="px-2 py-2 text-slate-200">
                    {(() => {
                      const pill = statusPill(row.status)
                      return (
                        <span className={`inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 text-[11px] font-semibold tracking-wide ${pill.className}`}>
                          {pill.icon}
                          <span>{pill.label}</span>
                        </span>
                      )
                    })()}
                  </td>
                  <td className="px-2 py-2 text-slate-300">{row.ownerRole}</td>
                  <td className="px-2 py-2 text-slate-300">{row.toolClass}</td>
                  <td className="px-2 py-2 text-slate-300">{row.claimClass}</td>
                  <td className="px-2 py-2 text-slate-300">{row.scope}</td>
                  <td className="px-2 py-2 text-slate-300">{row.limitations.length ? row.limitations.join('; ') : '-'}</td>
                  <td className="px-2 py-2 text-slate-300">{row.blockedClaims.length ? row.blockedClaims.join(', ') : '-'}</td>
                </tr>
              ))}
              {domainRows.length === 0 && (
                <tr>
                  <td className="px-2 py-3 text-slate-400" colSpan={8}>NOT_AVAILABLE</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      <section className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
        <h3 className="text-sm font-semibold text-slate-100">stage claim drill-down</h3>
        <div className="mt-3 grid gap-3 md:grid-cols-2">
          <div className="rounded border border-slate-800 bg-slate-950/50 p-3">
            <div className="text-xs text-slate-400">S8 scope</div>
            <div className="mt-1 text-sm font-semibold text-slate-100">{String(stageClaimBoundary?.stage ?? 'NOT_AVAILABLE')}</div>
            <div className="mt-2 text-xs text-slate-300">limitations: {Array.isArray(stageClaimBoundary?.limitations) ? (stageClaimBoundary?.limitations as string[]).join('; ') : '-'}</div>
            <div className="mt-1 text-xs text-slate-300">blocked_claims: {Array.isArray(stageClaimBoundary?.blocked_claims) ? (stageClaimBoundary?.blocked_claims as string[]).join(', ') : '-'}</div>
          </div>
          <div className="rounded border border-slate-800 bg-slate-950/50 p-3">
            <div className="text-xs text-slate-400">S10 scope</div>
            <div className="mt-1 text-sm font-semibold text-slate-100">{String(stageConditionalPass?.stage ?? 'NOT_AVAILABLE')}</div>
            <div className="mt-2 text-xs text-slate-300">limitations: {Array.isArray(stageConditionalPass?.violation_classes) ? (stageConditionalPass?.violation_classes as Array<Record<string, unknown>>).map((v) => `${String(v.rule ?? '-')}[${String(v.class ?? '-')}]`).join('; ') : '-'}</div>
            <div className="mt-1 text-xs text-slate-300">blocked_claims: {Array.isArray(stageConditionalPass?.blocked_claims) ? (stageConditionalPass?.blocked_claims as string[]).join(', ') : '-'}</div>
          </div>
        </div>
      </section>
      {hasBlocked && (
        <section className="rounded-xl border border-amber-700/50 bg-amber-950/20 p-4">
          <h3 className="text-sm font-semibold text-amber-200">{t('signoff.reco_title')}</h3>
          <ol className="mt-2 list-decimal space-y-1 pl-5 text-xs text-amber-100">
            <li>{t('signoff.reco_step_1')}</li>
            <li>{t('signoff.reco_step_2')}</li>
            <li>{t('signoff.reco_step_3')}</li>
          </ol>
        </section>
      )}
      <section className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
        <h3 className="text-sm font-semibold text-slate-100">{t('signoff.decision_inbox_title')}</h3>
        <div className="mt-2 text-xs text-slate-400">{t('signoff.decision_inbox_subtitle')}</div>
        <div className="mt-2 grid gap-2 md:grid-cols-2">
          <div className="rounded border border-slate-700 bg-slate-950/40 px-2 py-1 text-xs text-slate-300">
            {t('signoff.pending_count')}: <span className="font-mono text-amber-300">{String(decisionInbox?.pending_count ?? 0)}</span>
          </div>
          <div className="rounded border border-slate-700 bg-slate-950/40 px-2 py-1 text-xs text-slate-300">
            {t('signoff.completed_count')}: <span className="font-mono text-emerald-300">{String(decisionInbox?.completed_count ?? 0)}</span>
          </div>
        </div>
        <div className="mt-3 overflow-x-auto">
          <table className="min-w-full text-left text-xs">
            <thead className="bg-slate-900 text-slate-300">
              <tr>
                <th className="px-2 py-2">{t('signoff.decision_action')}</th>
                <th className="px-2 py-2">{t('signoff.decision_role')}</th>
                <th className="px-2 py-2">{t('signoff.decision_reason')}</th>
                <th className="px-2 py-2">recommended_next_action</th>
                <th className="px-2 py-2">routing_cli_templates</th>
                <th className="px-2 py-2">{t('signoff.decision_command')}</th>
              </tr>
            </thead>
            <tbody>
              {((decisionInbox?.items as Array<Record<string, unknown>> | undefined) ?? []).map((item, idx) => {
                const actionId = String(item.action_id ?? '-')
                const role = String(item.required_role ?? '-')
                const reason = String(item.reason ?? '-')
                const recommendations = reason
                  .split(',')
                  .map((token) => token.trim())
                  .filter(Boolean)
                  .map(mapBlockedClaimToRecommendation)
                const recommendation = recommendations.length ? Array.from(new Set(recommendations)).join(', ') : 'request_more_evidence'
                const fallbackRunDir = `artifacts/production-runs/${selectedChip?.source_dir}/${runId}/${executionId}`
                const actionCtx = resolveActionCommandContext(
                  selectedExecution?.resolved_root ?? fallbackRunDir,
                  fallbackRunDir,
                )
                const cmd = `python3 ${actionCtx.scriptPath} --run-dir ${actionCtx.runDirArg} --action-id ${actionId} --actor-role ${role}`
                const runtimeTemplateRecord =
                  ((actionCliTemplates?.templates as Array<Record<string, unknown>> | undefined) ?? []).find(
                    (t) => String(t.action_id ?? '') === actionId
                  ) ?? null
                const runtimeRecommendations = runtimeTemplateRecord && Array.isArray(runtimeTemplateRecord.recommended_next_actions)
                  ? (runtimeTemplateRecord.recommended_next_actions as string[])
                  : recommendation.split(',').map((x) => x.trim()).filter(Boolean)
                const routingTemplates = runtimeTemplateRecord && Array.isArray(runtimeTemplateRecord.cli_templates)
                  ? (runtimeTemplateRecord.cli_templates as string[])
                  : Array.from(
                      new Set(
                        runtimeRecommendations.flatMap((x) => buildRoutingCliTemplates(x, actionCtx.runDirArg))
                      )
                    )
                return (
                  <tr key={`${actionId}-${idx}`} className="border-t border-slate-800">
                    <td className="px-2 py-2 text-slate-200 font-mono">{actionId}</td>
                    <td className="px-2 py-2 text-slate-300">{role}</td>
                    <td className="px-2 py-2 text-slate-300">{reason}</td>
                    <td className="px-2 py-2 text-amber-300 font-mono">{runtimeRecommendations.join(', ') || recommendation}</td>
                    <td className="px-2 py-2 text-slate-300">
                      {routingTemplates.map((line, i) => (
                        <div key={i} className="font-mono text-[11px] break-all text-violet-300">{line}</div>
                      ))}
                    </td>
                    <td className="px-2 py-2 text-cyan-300 font-mono break-all">{cmd}</td>
                  </tr>
                )
              })}
              {(((decisionInbox?.items as Array<Record<string, unknown>> | undefined) ?? []).length === 0) && (
                <tr>
                  <td className="px-2 py-3 text-slate-400" colSpan={6}>NO_PENDING_ACTIONS</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        <h4 className="mt-4 text-xs font-semibold uppercase tracking-wide text-slate-300">{t('signoff.completed_actions_title')}</h4>
        <div className="mt-2 overflow-x-auto">
          <table className="min-w-full text-left text-xs">
            <thead className="bg-slate-900 text-slate-300">
              <tr>
                <th className="px-2 py-2">{t('signoff.decision_action')}</th>
                <th className="px-2 py-2">{t('signoff.decision_role')}</th>
                <th className="px-2 py-2">{t('signoff.decision_reason')}</th>
              </tr>
            </thead>
            <tbody>
              {((decisionInbox?.completed_items as Array<Record<string, unknown>> | undefined) ?? []).map((item, idx) => (
                <tr key={`done-${idx}`} className="border-t border-slate-800">
                  <td className="px-2 py-2 text-emerald-200 font-mono">{String(item.action_id ?? '-')}</td>
                  <td className="px-2 py-2 text-slate-300">{String(item.required_role ?? '-')}</td>
                  <td className="px-2 py-2 text-slate-300">{String(item.reason ?? '-')}</td>
                </tr>
              ))}
              {(((decisionInbox?.completed_items as Array<Record<string, unknown>> | undefined) ?? []).length === 0) && (
                <tr>
                  <td className="px-2 py-3 text-slate-400" colSpan={3}>NO_COMPLETED_ACTIONS</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        <h4 className="mt-4 text-xs font-semibold uppercase tracking-wide text-slate-300">{t('signoff.action_history_title')}</h4>
        <div className="mt-2 overflow-x-auto">
          <table className="min-w-full text-left text-xs">
            <thead className="bg-slate-900 text-slate-300">
              <tr>
                <th className="px-2 py-2">{t('signoff.decision_action')}</th>
                <th className="px-2 py-2">{t('signoff.decision_role')}</th>
                <th className="px-2 py-2">{t('signoff.history_result')}</th>
                <th className="px-2 py-2">{t('signoff.history_time')}</th>
                <th className="px-2 py-2">{t('signoff.history_notes')}</th>
              </tr>
            </thead>
            <tbody>
              {actionHistory.map((row, idx) => (
                <tr key={`hist-${idx}`} className="border-t border-slate-800">
                  <td className="px-2 py-2 text-slate-200 font-mono">{row.action_id}</td>
                  <td className="px-2 py-2 text-slate-300">{row.actor_role}</td>
                  <td className="px-2 py-2 text-slate-300">{row.result}</td>
                  <td className="px-2 py-2 text-slate-300 font-mono">{row.generated_at}</td>
                  <td className="px-2 py-2 text-slate-300">{row.notes}</td>
                </tr>
              ))}
              {actionHistory.length === 0 && (
                <tr>
                  <td className="px-2 py-3 text-slate-400" colSpan={5}>NO_ACTION_HISTORY</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  )
}
