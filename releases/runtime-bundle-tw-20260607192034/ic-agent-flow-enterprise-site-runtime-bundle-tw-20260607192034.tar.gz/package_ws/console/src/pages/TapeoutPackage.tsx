import { useEffect, useMemo, useState } from 'react'
import { useLocation, useNavigate, useParams } from 'react-router-dom'
import { AlertTriangle, CheckCircle2, MinusCircle, ShieldAlert } from 'lucide-react'
import { useTranslation } from '../contexts/i18n'
import { parseMode, sortChipsForMode } from '../hooks/evidenceSummary'
import { useProductionRunsInventory } from '../hooks/useProductionRunsInventory'
import { useRunDetailExecutions } from '../hooks/useRunDetailExecutions'

type FileEntry = { relative_path: string; kind: 'file' | 'dir'; preview_text?: string | null }

function normalizeSequencePath(path: string) {
  return path
    .split('/')
    .map((seg) => seg.replace(/^\d+_/, ''))
    .join('/')
}

function resolveActionCommandContext(resolvedRoot: string | undefined, fallbackRelativeRunDir: string) {
  const normalizedFallback = fallbackRelativeRunDir.replace(/\\/g, '/')
  const source = (resolvedRoot ?? '').trim().replace(/\\/g, '/')
  if (!source) {
    return { scriptPath: 'package_ws/shared-runtime/scripts/apply_tapeout_decision_action.py', runDirArg: normalizedFallback }
  }
  const repoMarker = '/artifacts/production-runs/'
  const repoIdx = source.lastIndexOf(repoMarker)
  if (repoIdx >= 0) {
    return {
      scriptPath: 'package_ws/shared-runtime/scripts/apply_tapeout_decision_action.py',
      runDirArg: source.slice(repoIdx + 1),
    }
  }
  const releaseMarker = '/production-runs/'
  const releaseIdx = source.lastIndexOf(releaseMarker)
  if (releaseIdx >= 0) {
    const sourceRunDir = source.slice(releaseIdx + 1)
    if (normalizedFallback.startsWith('artifacts/production-runs/')) {
      return {
        scriptPath: 'scripts/apply_tapeout_decision_action.py',
        runDirArg: normalizedFallback,
      }
    }
    return {
      scriptPath: 'scripts/apply_tapeout_decision_action.py',
      runDirArg: sourceRunDir,
    }
  }
  return { scriptPath: 'scripts/apply_tapeout_decision_action.py', runDirArg: normalizedFallback }
}

function parseArtifactJson(files: FileEntry[], logicalPath: string) {
  const normalizedLogicalPath = normalizeSequencePath(logicalPath)
  const found = files.find(
    (f) =>
      f.kind === 'file' &&
      (f.relative_path === logicalPath || normalizeSequencePath(f.relative_path) === normalizedLogicalPath),
  )
  if (!found?.preview_text) return null
  try {
    return JSON.parse(found.preview_text) as Record<string, unknown>
  } catch {
    return null
  }
}

function statusPill(statusRaw: string) {
  const status = statusRaw.toUpperCase()
  if (['PASS', 'READY', 'PACKAGE_READY', 'TRANSFERRED', 'RECEIPT_CONFIRMED', 'APPROVE', 'APPROVE_WITH_LIMITATIONS'].includes(status)) {
    return { icon: <CheckCircle2 size={14} className="text-emerald-300" />, className: 'border-emerald-700/50 bg-emerald-900/20 text-emerald-200' }
  }
  if (['BLOCKED', 'INVALID', 'REJECT'].includes(status)) {
    return { icon: <ShieldAlert size={14} className="text-red-300" />, className: 'border-red-700/50 bg-red-900/20 text-red-200' }
  }
  if (['PENDING', 'HOLD', 'PACKAGE_READY_WITH_LIMITATIONS', 'PACKAGE_READY_WITH_WAIVERS'].includes(status)) {
    return { icon: <AlertTriangle size={14} className="text-amber-300" />, className: 'border-amber-700/50 bg-amber-900/20 text-amber-200' }
  }
  return { icon: <MinusCircle size={14} className="text-slate-300" />, className: 'border-slate-700 bg-slate-900/40 text-slate-200' }
}

function summarizeTypeCounts(records: Array<Record<string, unknown>>) {
  const out: Record<string, number> = {}
  for (const rec of records) {
    const typ = String(rec.artifact_type ?? 'UNKNOWN')
    out[typ] = (out[typ] ?? 0) + 1
  }
  return Object.entries(out).sort((a, b) => b[1] - a[1]).slice(0, 12)
}

export default function TapeoutPackage() {
  const { bundleId } = useParams<{ bundleId: string }>()
  const location = useLocation()
  const navigate = useNavigate()
  const { t } = useTranslation()
  const mode = useMemo(() => parseMode(location.search), [location.search])
  const searchParams = useMemo(() => new URLSearchParams(location.search), [location.search])
  const requestedRunId = searchParams.get('run') ?? ''
  const requestedExecutionId = searchParams.get('execution') ?? ''
  const { data, loading, error } = useProductionRunsInventory({ layeredWithRuns: true })

  const chips = useMemo(() => sortChipsForMode(data?.chips ?? [], mode), [data, mode])

  const [chipSourceDirOverride, setChipSourceDirOverride] = useState('')
  const initialChip = useMemo(() => {
    if (!chips.length) return ''
    if (!bundleId) return chips[0].source_dir
    return chips.find((c) => c.chip_id === bundleId)?.source_dir ?? chips[0].source_dir
  }, [bundleId, chips])
  const selectedChip = chips.find((c) => c.source_dir === (chipSourceDirOverride || initialChip))

  const runs = selectedChip?.runs ?? []
  const [runOverride, setRunOverride] = useState('')
  const runId = runOverride || (requestedRunId && runs.some((r) => r.run_id === requestedRunId) ? requestedRunId : runs[0]?.run_id || '')
  const selectedRun = runs.find((r) => r.run_id === runId)

  const { executions: runDetailExecutions } = useRunDetailExecutions(selectedChip?.source_dir ?? '', selectedRun?.run_id ?? '')
  const executions = runDetailExecutions ?? selectedRun?.executions ?? []
  const [executionOverride, setExecutionOverride] = useState('')
  const executionId = executionOverride || (requestedExecutionId && executions.some((e) => e.execution_id === requestedExecutionId)
    ? requestedExecutionId
    : executions[executions.length - 1]?.execution_id || '')

  useEffect(() => {
    if (!selectedChip) return
    const current = new URLSearchParams(location.search)
    const currentMode = current.get('mode') ?? 'team_project'
    const currentRun = current.get('run') ?? ''
    const currentExec = current.get('execution') ?? ''
    const desiredRun = runId || ''
    const desiredExec = executionId || ''
    const pathChip = bundleId ?? ''

    if (pathChip === selectedChip.chip_id && currentMode === mode && currentRun === desiredRun && currentExec === desiredExec) return

    const next = new URLSearchParams()
    next.set('mode', mode)
    if (desiredRun) next.set('run', desiredRun)
    if (desiredExec) next.set('execution', desiredExec)
    navigate(`/tapeout-package/${encodeURIComponent(selectedChip.chip_id)}?${next.toString()}`, { replace: true })
  }, [bundleId, executionId, location.search, mode, navigate, runId, selectedChip])

  const selectedExecution = executions.find((e) => e.execution_id === executionId)
  const fileList = useMemo(() => selectedExecution?.files ?? [], [selectedExecution])

  const packageManifest = parseArtifactJson(fileList, 'dashboard_objects/tapeout_package_manifest.json')
  const foundryManifest = parseArtifactJson(fileList, 'dashboard_objects/foundry_handoff_manifest.json')
  const integrityManifest = parseArtifactJson(fileList, 'dashboard_objects/package_integrity_manifest.json')
  const leakScan = parseArtifactJson(fileList, 'dashboard_objects/path_leak_scan_report.json')
  const authorityRecord = parseArtifactJson(fileList, 'dashboard_objects/handoff_authority_record.json')
  const transferRecord = parseArtifactJson(fileList, 'dashboard_objects/handoff_transfer_record.json')
  const receiptRecord = parseArtifactJson(fileList, 'dashboard_objects/handoff_receipt_record.json')
  const decisionInbox = parseArtifactJson(fileList, 'dashboard_objects/tapeout_decision_inbox.json')
  const artifactManifest = parseArtifactJson(fileList, 'dashboard_objects/deliverable_artifact_manifest.json')

  const artifactRows = ((artifactManifest?.records as Array<Record<string, unknown>> | undefined) ?? [])
  const typeCounts = summarizeTypeCounts(artifactRows)
  const leakRows = ((leakScan?.findings as Array<unknown> | undefined) ?? []).map((v) => String(v))

  const actionHistory = useMemo(() => {
    const rows: Array<Record<string, string>> = []
    const actionFiles = fileList
      .filter((f) => f.kind === 'file' && normalizeSequencePath(f.relative_path).startsWith('dashboard_objects/tapeout_action_records/') && f.relative_path.endsWith('.json'))
      .sort((a, b) => b.relative_path.localeCompare(a.relative_path))
    for (const file of actionFiles) {
      if (!file.preview_text) continue
      try {
        const parsed = JSON.parse(file.preview_text) as Record<string, unknown>
        rows.push({
          action_id: String(parsed.action_id ?? '-'),
          actor_role: String(parsed.actor_role ?? '-'),
          result: String(parsed.result ?? '-'),
          generated_at: String(parsed.generated_at ?? '-'),
          notes: String(parsed.notes ?? '-'),
        })
      } catch {
        // ignore malformed preview
      }
    }
    return rows
  }, [fileList])

  if (loading) return <div className="rounded-xl border border-slate-800 bg-slate-900 p-6 text-sm text-slate-300">{t('common.loading')}</div>
  if (error) return <div className="rounded-xl border border-red-900/40 bg-red-950/30 p-6 text-sm text-red-200">{t('common.error')}: {error}</div>

  return (
    <div className="space-y-5">
      <section className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
        <h2 className="text-lg font-semibold text-slate-100">{t('tapeout.title')}</h2>
        <p className="mt-1 text-xs text-slate-400">{t('tapeout.subtitle')}</p>
        <div className="mt-4 grid gap-3 md:grid-cols-3">
          <select value={selectedChip?.source_dir ?? ''} onChange={(e) => { setChipSourceDirOverride(e.target.value); setRunOverride(''); setExecutionOverride('') }} className="rounded border border-slate-700 bg-slate-950 px-2 py-2 text-sm text-slate-200">
            {chips.map((chip) => <option key={chip.source_dir} value={chip.source_dir}>{chip.chip_id}</option>)}
          </select>
          <select value={runId} onChange={(e) => { setRunOverride(e.target.value); setExecutionOverride('') }} className="rounded border border-slate-700 bg-slate-950 px-2 py-2 text-sm text-slate-200">
            {runs.map((run) => <option key={run.run_id} value={run.run_id}>{run.run_id}</option>)}
          </select>
          <select value={executionId} onChange={(e) => setExecutionOverride(e.target.value)} className="rounded border border-slate-700 bg-slate-950 px-2 py-2 text-sm text-slate-200">
            {executions.map((exec) => <option key={exec.execution_id} value={exec.execution_id}>{exec.execution_id}</option>)}
          </select>
        </div>
      </section>

      <section className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
        <div className="grid gap-3 md:grid-cols-4">
          {[
            { label: t('tapeout.package_status'), value: String(packageManifest?.status ?? 'NOT_AVAILABLE') },
            { label: t('tapeout.authority_status'), value: String(authorityRecord?.decision ?? 'NOT_AVAILABLE') },
            { label: t('tapeout.transfer_status'), value: String(transferRecord?.status ?? 'NOT_AVAILABLE') },
            { label: t('tapeout.receipt_status'), value: String(receiptRecord?.status ?? 'NOT_AVAILABLE') },
          ].map((card) => {
            const pill = statusPill(card.value)
            return (
              <div key={card.label} className="rounded border border-slate-800 bg-slate-950/50 p-3">
                <div className="text-xs text-slate-400">{card.label}</div>
                <div className="mt-1">
                  <span className={`inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 text-[11px] font-semibold tracking-wide ${pill.className}`}>
                    {pill.icon}
                    <span>{card.value}</span>
                  </span>
                </div>
              </div>
            )
          })}
        </div>
      </section>

      <section className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
        <h3 className="text-sm font-semibold text-slate-100">{t('tapeout.integrity_title')}</h3>
        <div className="mt-3 grid gap-3 md:grid-cols-3">
          <div className="rounded border border-slate-800 bg-slate-950/50 p-3 text-xs text-slate-300">{t('tapeout.digest')}: <span className="font-mono text-slate-100">{String(integrityManifest?.package_digest ?? '-')}</span></div>
          <div className="rounded border border-slate-800 bg-slate-950/50 p-3 text-xs text-slate-300">{t('tapeout.integrity_verdict')}: <span className="font-mono text-slate-100">{String(integrityManifest?.integrity_verdict ?? '-')}</span></div>
          <div className="rounded border border-slate-800 bg-slate-950/50 p-3 text-xs text-slate-300">{t('tapeout.foundry_artifacts')}: <span className="font-mono text-slate-100">{String((foundryManifest?.artifact_refs as Array<unknown> | undefined)?.length ?? 0)}</span></div>
        </div>
      </section>

      <section className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
        <h3 className="text-sm font-semibold text-slate-100">{t('tapeout.artifact_mix')}</h3>
        <div className="mt-3 overflow-x-auto">
          <table className="min-w-full text-left text-xs">
            <thead className="bg-slate-900 text-slate-300"><tr><th className="px-2 py-2">Type</th><th className="px-2 py-2">Count</th></tr></thead>
            <tbody>
              {typeCounts.map(([typ, cnt]) => <tr key={typ} className="border-t border-slate-800"><td className="px-2 py-2 text-slate-200">{typ}</td><td className="px-2 py-2 text-slate-300">{cnt}</td></tr>)}
              {typeCounts.length === 0 && <tr><td colSpan={2} className="px-2 py-3 text-slate-400">NOT_AVAILABLE</td></tr>}
            </tbody>
          </table>
        </div>
      </section>

      <section className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
        <h3 className="text-sm font-semibold text-slate-100">{t('tapeout.path_leak_title')}</h3>
        <div className="mt-2 text-xs text-slate-400">{t('tapeout.path_leak_note')}</div>
        <div className="mt-3 overflow-x-auto">
          <table className="min-w-full text-left text-xs">
            <thead className="bg-slate-900 text-slate-300"><tr><th className="px-2 py-2">Finding</th></tr></thead>
            <tbody>
              {leakRows.map((row, idx) => <tr key={`${row}-${idx}`} className="border-t border-slate-800"><td className="px-2 py-2 text-slate-200 font-mono break-all">{row}</td></tr>)}
              {leakRows.length === 0 && <tr><td className="px-2 py-3 text-emerald-300">PASS (no external path leak)</td></tr>}
            </tbody>
          </table>
        </div>
      </section>

      <section className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
        <h3 className="text-sm font-semibold text-slate-100">{t('tapeout.decision_title')}</h3>
        <div className="mt-2 text-xs text-slate-400">{t('tapeout.decision_subtitle')}</div>
        <div className="mt-3 overflow-x-auto">
          <table className="min-w-full text-left text-xs">
            <thead className="bg-slate-900 text-slate-300"><tr><th className="px-2 py-2">{t('signoff.decision_action')}</th><th className="px-2 py-2">{t('signoff.decision_role')}</th><th className="px-2 py-2">{t('signoff.decision_reason')}</th><th className="px-2 py-2">{t('signoff.decision_command')}</th></tr></thead>
            <tbody>
              {((decisionInbox?.items as Array<Record<string, unknown>> | undefined) ?? []).map((item, idx) => {
                const actionId = String(item.action_id ?? '-')
                const role = String(item.required_role ?? '-')
                const reason = String(item.reason ?? '-')
                const fallbackRunDir =
                  `artifacts/production-runs/${selectedChip?.source_dir}/${runId}/${executionId}`
                const actionCtx = resolveActionCommandContext(
                  selectedExecution?.resolved_root ??
                  fallbackRunDir,
                  fallbackRunDir,
                )
                const cmd = `python3 ${actionCtx.scriptPath} --run-dir ${actionCtx.runDirArg} --action-id ${actionId} --actor-role ${role}`
                return <tr key={`${actionId}-${idx}`} className="border-t border-slate-800"><td className="px-2 py-2 text-slate-200 font-mono">{actionId}</td><td className="px-2 py-2 text-slate-300">{role}</td><td className="px-2 py-2 text-slate-300">{reason}</td><td className="px-2 py-2 text-cyan-300 font-mono break-all whitespace-pre-line">{cmd}</td></tr>
              })}
              {(((decisionInbox?.items as Array<Record<string, unknown>> | undefined) ?? []).length === 0) && <tr><td className="px-2 py-3 text-slate-400" colSpan={4}>NO_PENDING_ACTIONS</td></tr>}
            </tbody>
          </table>
        </div>

        <h4 className="mt-4 text-xs font-semibold uppercase tracking-wide text-slate-300">{t('signoff.action_history_title')}</h4>
        <div className="mt-2 overflow-x-auto">
          <table className="min-w-full text-left text-xs">
            <thead className="bg-slate-900 text-slate-300"><tr><th className="px-2 py-2">{t('signoff.decision_action')}</th><th className="px-2 py-2">{t('signoff.decision_role')}</th><th className="px-2 py-2">{t('signoff.history_result')}</th><th className="px-2 py-2">{t('signoff.history_time')}</th><th className="px-2 py-2">{t('signoff.history_notes')}</th></tr></thead>
            <tbody>
              {actionHistory.map((row, idx) => <tr key={`${row.action_id}-${idx}`} className="border-t border-slate-800"><td className="px-2 py-2 text-slate-200 font-mono">{row.action_id}</td><td className="px-2 py-2 text-slate-300">{row.actor_role}</td><td className="px-2 py-2 text-slate-300">{row.result}</td><td className="px-2 py-2 text-slate-400 font-mono">{row.generated_at}</td><td className="px-2 py-2 text-slate-300">{row.notes}</td></tr>)}
              {actionHistory.length === 0 && <tr><td colSpan={5} className="px-2 py-3 text-slate-400">NO_ACTION_HISTORY</td></tr>}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  )
}
