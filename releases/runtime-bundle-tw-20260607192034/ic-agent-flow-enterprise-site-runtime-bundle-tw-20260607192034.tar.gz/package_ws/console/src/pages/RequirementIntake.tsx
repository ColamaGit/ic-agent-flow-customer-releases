import { useCallback, useEffect, useId, useMemo, useRef, useState } from 'react'
import { Upload, FileText, Sparkles, AlertTriangle, X, CircleHelp } from 'lucide-react'
import { Link, useSearchParams } from 'react-router-dom'
import UpstreamTruthFlowBoard from '../components/UpstreamTruthFlowBoard'
import type { UpstreamTruthFlowNode } from '../components/UpstreamTruthFlowBoard'
import { useTranslation } from '../contexts/i18n'

const TEMPLATE_HINTS: Array<{ label: string; tokens: string[] }> = [
  { label: 'baseline-digital-soc', tokens: ['soc', 'digital', 'controller', 'chip'] },
  { label: 'UART Protocol', tokens: ['uart', 'serial', 'baud', 'rx', 'tx'] },
  { label: 'Asynchronous FIFO', tokens: ['fifo', 'async', 'asynchronous', 'cdc'] },
  { label: 'Verliog Pattern Generation', tokens: ['verilog', 'pattern', 'generation'] },
]

type IntakeSubmitResult = {
  scope_type?: string
  upstream_operation_id?: string
  chip_id?: string
  intake_session_id?: string
  session_dir_ref?: string
  requirement_item_ref?: string
  requirement_item_review_package_ref?: string
  requirement_item_adjudication_template_ref?: string
  graph_draft_ref?: string
  builder_handoff_ref?: string
}

type IntakeSessionContext = {
  status?: string
  scope_type?: string
  chip_id?: string
  intake_session_id?: string
  intake_session_record?: {
    prompt_text?: string
    template_match_result?: string
    template_ref?: string
    bootstrap_mode?: string
  }
  template_resolution_record?: {
    verdict?: string
    template_ref?: string
    bootstrap_mode?: string
  }
  requested_intake_session_id?: string
  upstream_truth_flow?: UpstreamTruthFlowNode[]
  upstream_node_status?: UpstreamTruthFlowNode[]
}

const preHandoffNodeIds = new Set([
  'requirement_intake',
  'requirement_adjudication',
  'graph_draft_check',
  'graph_validation',
  'freeze',
  'generation_plan',
  'rtl_generation',
])

function normalizeChipIdInput(raw: string): string {
  const normalized = raw
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_')
    .trim()
    .replace(/^_+|_+$/g, '')
    .replace(/_+/g, '_')
  return normalized.length > 0 ? normalized : 'chip'
}

function inferTemplate(prompt: string): string | null {
  const text = prompt.toLowerCase()
  let best: { label: string; score: number } | null = null

  for (const candidate of TEMPLATE_HINTS) {
    const score = candidate.tokens.reduce((acc, token) => acc + (text.includes(token) ? 1 : 0), 0)
    if (!best || score > best.score) {
      best = { label: candidate.label, score }
    }
  }

  return best && best.score > 0 ? best.label : null
}

function HintTooltip({ title, lines }: { title: string; lines: string[] }) {
  const [open, setOpen] = useState(false)
  const panelId = useId()
  const rootRef = useRef<HTMLSpanElement>(null)

  useEffect(() => {
    function onPointerDown(event: PointerEvent) {
      if (!rootRef.current) return
      if (!rootRef.current.contains(event.target as Node)) {
        setOpen(false)
      }
    }

    function onKeyDown(event: KeyboardEvent) {
      if (event.key === 'Escape') {
        setOpen(false)
      }
    }

    document.addEventListener('pointerdown', onPointerDown)
    document.addEventListener('keydown', onKeyDown)
    return () => {
      document.removeEventListener('pointerdown', onPointerDown)
      document.removeEventListener('keydown', onKeyDown)
    }
  }, [])

  return (
    <span ref={rootRef} className="group relative inline-flex">
      <button
        type="button"
        aria-label={`${title}-hint`}
        aria-expanded={open}
        aria-controls={panelId}
        className="inline-flex h-6 w-6 cursor-help items-center justify-center rounded-full border border-slate-600 bg-slate-900 text-slate-300 transition hover:border-cyan-400 hover:text-cyan-300"
        onClick={() => setOpen((prev) => !prev)}
      >
        <CircleHelp size={14} />
      </button>
      <div
        id={panelId}
        className={`absolute left-1/2 top-8 z-30 w-[320px] -translate-x-1/2 rounded-lg border border-slate-700 bg-slate-950/95 p-3 text-left text-xs normal-case tracking-normal text-slate-200 shadow-xl ${
          open ? 'pointer-events-auto block' : 'pointer-events-none hidden'
        }`}
      >
        <div className="mb-1 text-sm font-semibold text-cyan-300">{title}</div>
        <ul className="list-disc space-y-1 pl-4">
          {lines.map((line, idx) => (
            <li key={`${title}-${idx}`}>{line}</li>
          ))}
        </ul>
      </div>
    </span>
  )
}

export default function RequirementIntake() {
  const { t } = useTranslation()
  const [searchParams] = useSearchParams()
  const prefillChipId = (searchParams.get('chip') || '').trim()
  const prefillIntakeSession = (searchParams.get('intake_session') || '').trim()
  const prefillSource = (searchParams.get('source') || '').trim()
  const hasReturnContext = Boolean(prefillChipId || prefillIntakeSession || prefillSource)
  const [chipId, setChipId] = useState(prefillChipId)
  const [promptText, setPromptText] = useState('')
  const [files, setFiles] = useState<File[]>([])
  const [noMatchAction, setNoMatchAction] = useState<'B' | 'C'>('B')
  const [templateOptions, setTemplateOptions] = useState<Array<{ name: string; path: string }>>([])
  const [templateOptionsLoading, setTemplateOptionsLoading] = useState(false)
  const [templateOptionsError, setTemplateOptionsError] = useState('')
  const [templateOptionsHttpStatus, setTemplateOptionsHttpStatus] = useState<number | null>(null)
  const [manualTemplateOverride, setManualTemplateOverride] = useState(false)
  const [templateOverrideRef, setTemplateOverrideRef] = useState('')
  const [submitState, setSubmitState] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle')
  const [submitMessage, setSubmitMessage] = useState('')
  const [submitResult, setSubmitResult] = useState<IntakeSubmitResult | null>(null)
  const [restoredIntakeContext, setRestoredIntakeContext] = useState<IntakeSessionContext | null>(null)
  const [restoredIntakeLoading, setRestoredIntakeLoading] = useState(false)
  const [restoredIntakeError, setRestoredIntakeError] = useState('')
  const [restoredIntakeWarning, setRestoredIntakeWarning] = useState('')

  useEffect(() => {
    if (prefillChipId) setChipId(prefillChipId)
  }, [prefillChipId])

  useEffect(() => {
    if (!prefillChipId || !prefillIntakeSession) {
      setRestoredIntakeContext(null)
      setRestoredIntakeError('')
      setRestoredIntakeWarning('')
      return
    }

    let cancelled = false
    async function loadIntakeSessionContext() {
      setRestoredIntakeLoading(true)
      setRestoredIntakeError('')
      setRestoredIntakeWarning('')
      try {
        const params = new URLSearchParams({
          chip_id: prefillChipId,
          intake_session_id: prefillIntakeSession,
        })
        const response = await fetch(`/api/intake/session?${params.toString()}`, { cache: 'no-store' })
        const payload = await response.json()
        if (!response.ok) {
          throw new Error(payload?.error ?? `http_${response.status}`)
        }
        if (cancelled) return
        setRestoredIntakeContext(payload)
        const requestedSessionId = String(payload?.requested_intake_session_id ?? '').trim()
        const resolvedSessionId = String(payload?.intake_session_id ?? '').trim()
        if (requestedSessionId && resolvedSessionId && requestedSessionId !== resolvedSessionId) {
          setRestoredIntakeWarning(`${t('intake.restored_context_session_fallback')}: ${requestedSessionId} -> ${resolvedSessionId}`)
        }
        if (typeof payload?.chip_id === 'string' && payload.chip_id.trim()) {
          setChipId(payload.chip_id)
        }
        const restoredPrompt = payload?.intake_session_record?.prompt_text
        if (typeof restoredPrompt === 'string') {
          setPromptText(restoredPrompt)
        }
      } catch (error) {
        if (cancelled) return
        setRestoredIntakeContext(null)
        setRestoredIntakeWarning('')
        setRestoredIntakeError(error instanceof Error ? error.message : 'unknown_error')
      } finally {
        if (!cancelled) setRestoredIntakeLoading(false)
      }
    }

    void loadIntakeSessionContext()
    return () => {
      cancelled = true
    }
  }, [prefillChipId, prefillIntakeSession, t])

  const loadTemplateOptions = useCallback(async () => {
    setTemplateOptionsLoading(true)
    try {
      const response = await fetch('/api/intake/options')
      setTemplateOptionsHttpStatus(response.status)
      if (!response.ok) {
        throw new Error(`http_${response.status}`)
      }
      const payload = await response.json()
      const templates: unknown[] = Array.isArray(payload?.templates) ? payload.templates : []
      const normalized = templates
        .filter((item: unknown): item is { name: string; path: string } => {
          if (!item || typeof item !== 'object') return false
          const maybe = item as { name?: unknown; path?: unknown }
          return typeof maybe.name === 'string' && typeof maybe.path === 'string'
        })
        .map((item) => ({ name: item.name, path: item.path }))
      setTemplateOptions(normalized)
      setTemplateOptionsError('')
    } catch (error) {
      setTemplateOptions([])
      const msg = error instanceof Error ? error.message : 'unknown_error'
      setTemplateOptionsError(msg)
      setTemplateOptionsHttpStatus(null)
    } finally {
      setTemplateOptionsLoading(false)
    }
  }, [])

  useEffect(() => {
    loadTemplateOptions()
  }, [loadTemplateOptions])

  useEffect(() => {
    if (templateOptions.length > 0) return
    const timer = window.setInterval(() => {
      loadTemplateOptions()
    }, 5000)
    return () => window.clearInterval(timer)
  }, [templateOptions.length, loadTemplateOptions])

  const intakeSessionId = useMemo(() => {
    const normalizedChip = normalizeChipIdInput(chipId)
    const stamp = new Date().toISOString().replace(/[-:.TZ]/g, '').slice(0, 14)
    return `INTAKE-${normalizedChip}-${stamp}`
  }, [chipId])
  const normalizedChipId = useMemo(() => normalizeChipIdInput(chipId), [chipId])

  const autoDetectedTemplate = useMemo(() => inferTemplate(promptText), [promptText])
  const overrideTemplateName = useMemo(() => {
    if (!templateOverrideRef) return null
    const fromOptions = templateOptions.find((item) => item.path === templateOverrideRef)
    return fromOptions?.name ?? templateOverrideRef
  }, [templateOptions, templateOverrideRef])
  const matchedTemplate = manualTemplateOverride ? overrideTemplateName : autoDetectedTemplate
  const templateMatchResult = matchedTemplate ? 'MATCHED' : 'NO_MATCH'
  const bootstrapMode = matchedTemplate ? 'TEMPLATE_BASED' : noMatchAction === 'B' ? 'BLANK_SCAFFOLD' : 'PENDING_TEMPLATE'
  const canSubmit = chipId.trim().length > 0 && promptText.trim().length > 0

  async function fileToBase64(file: File): Promise<string> {
    const buffer = await file.arrayBuffer()
    const bytes = new Uint8Array(buffer)
    let binary = ''
    for (const b of bytes) binary += String.fromCharCode(b)
    return btoa(binary)
  }

  async function submitIntake() {
    if (!canSubmit || submitState === 'submitting') return
    setSubmitState('submitting')
    setSubmitMessage('')

    try {
      const attachmentsInline = await Promise.all(
        files.map(async (file) => ({
          filename: file.name,
          content_base64: await fileToBase64(file),
        })),
      )

      const response = await fetch('/api/intake', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chip_id: normalizeChipIdInput(chipId),
          prompt_text: promptText,
          no_match_action: noMatchAction,
          template_override_ref: manualTemplateOverride ? (templateOverrideRef || undefined) : undefined,
          attachments_inline: attachmentsInline,
        }),
      })

      const payload = await response.json()
      if (!response.ok) {
        throw new Error(payload?.error ?? `http_${response.status}`)
      }
      setSubmitState('success')
      setSubmitResult(payload)
      setSubmitMessage(
        `${t('intake.submit_success')}: ${payload.intake_session_id ?? '-'} | ${payload.bootstrap_mode ?? '-'}`,
      )
    } catch (error) {
      setSubmitState('error')
      setSubmitResult(null)
      const msg = error instanceof Error ? error.message : 'unknown_error'
      setSubmitMessage(`${t('intake.submit_error')}: ${msg}`)
    }
  }

  function appendSelectedFiles(selected: File[]) {
    if (!selected.length) return
    setFiles((prev) => {
      const keyed = new Map<string, File>()
      for (const f of prev) keyed.set(`${f.name}-${f.size}-${f.lastModified}`, f)
      for (const f of selected) keyed.set(`${f.name}-${f.size}-${f.lastModified}`, f)
      return Array.from(keyed.values())
    })
  }

  function removeFile(target: File) {
    setFiles((prev) => prev.filter((f) => !(f.name === target.name && f.size === target.size && f.lastModified === target.lastModified)))
  }

  const upstreamFlowNodes = useMemo<UpstreamTruthFlowNode[]>(() => {
    if (!submitResult) return []
    const chip = submitResult.chip_id ?? normalizedChipId
    const sessionDir = submitResult.session_dir_ref ?? `chips/${chip}/specs/intake/${submitResult.intake_session_id ?? intakeSessionId}`
    return [
      {
        node_id: 'requirement_intake',
        scope_type: 'CHIP_UPSTREAM',
        status: 'PASS',
        expected_files: [
          `${sessionDir}/intake_session_record.json`,
          `${sessionDir}/template_resolution_record.json`,
          submitResult.requirement_item_ref ?? `chips/${chip}/specs/requirement_item.json`,
        ],
        existing_files: [
          `${sessionDir}/intake_session_record.json`,
          `${sessionDir}/template_resolution_record.json`,
          submitResult.requirement_item_ref ?? `chips/${chip}/specs/requirement_item.json`,
        ],
        missing_files: [],
        next_action: 'requirement_adjudication',
      },
      {
        node_id: 'requirement_adjudication',
        scope_type: 'CHIP_UPSTREAM',
        status: 'HUMAN_REVIEW_REQUIRED',
        expected_files: [
          submitResult.requirement_item_review_package_ref ?? `chips/${chip}/specs/requirement_item_review_package.json`,
          submitResult.requirement_item_adjudication_template_ref ?? `chips/${chip}/specs/requirement_item_adjudication_record.template.json`,
          `chips/${chip}/specs/requirement_item_adjudication_record.json`,
        ],
        existing_files: [
          submitResult.requirement_item_review_package_ref ?? `chips/${chip}/specs/requirement_item_review_package.json`,
          submitResult.requirement_item_adjudication_template_ref ?? `chips/${chip}/specs/requirement_item_adjudication_record.template.json`,
        ],
        missing_files: [`chips/${chip}/specs/requirement_item_adjudication_record.json`],
        next_action: 'graph_draft_check',
      },
      {
        node_id: 'graph_draft_check',
        scope_type: 'CHIP_UPSTREAM',
        status: 'HUMAN_REVIEW_REQUIRED',
        expected_files: [
          submitResult.graph_draft_ref ?? `chips/${chip}/architecture/architecture_graph.draft.json`,
          submitResult.builder_handoff_ref ?? `chips/${chip}/architecture/builder_validation_handoff.json`,
        ],
        existing_files: [
          submitResult.graph_draft_ref ?? `chips/${chip}/architecture/architecture_graph.draft.json`,
          submitResult.builder_handoff_ref ?? `chips/${chip}/architecture/builder_validation_handoff.json`,
        ],
        missing_files: [],
        next_action: 'graph_validation',
      },
      {
        node_id: 'graph_validation',
        scope_type: 'CHIP_UPSTREAM',
        status: 'NOT_CREATED',
        expected_files: [
          `chips/${chip}/architecture/validation/graph_validation_result.json`,
          `chips/${chip}/architecture/validation/validator_run_record.json`,
        ],
        existing_files: [],
        missing_files: [
          `chips/${chip}/architecture/validation/graph_validation_result.json`,
          `chips/${chip}/architecture/validation/validator_run_record.json`,
        ],
        next_action: 'freeze',
      },
      {
        node_id: 'freeze',
        scope_type: 'CHIP_UPSTREAM',
        status: 'NOT_CREATED',
        expected_files: [
          `chips/${chip}/governance/freeze/requirement_freeze_record.json`,
          `chips/${chip}/governance/freeze/graph_freeze_record.json`,
        ],
        existing_files: [],
        missing_files: [
          `chips/${chip}/governance/freeze/requirement_freeze_record.json`,
          `chips/${chip}/governance/freeze/graph_freeze_record.json`,
        ],
        next_action: 'generation_plan',
      },
      {
        node_id: 'generation_plan',
        scope_type: 'CHIP_UPSTREAM',
        status: 'NOT_CREATED',
        expected_files: [`chips/${chip}/generation/graph_to_generation_plan.json`],
        existing_files: [],
        missing_files: [`chips/${chip}/generation/graph_to_generation_plan.json`],
        next_action: 'rtl_generation',
      },
      {
        node_id: 'rtl_generation',
        scope_type: 'CHIP_UPSTREAM',
        status: 'NOT_CREATED',
        expected_files: [
          `chips/${chip}/rtl/rtl_generation_request.json`,
          `chips/${chip}/rtl/rtl_generation_record.json`,
        ],
        existing_files: [],
        missing_files: [
          `chips/${chip}/rtl/rtl_generation_request.json`,
          `chips/${chip}/rtl/rtl_generation_record.json`,
        ],
        next_action: 'runner_execution',
      },
    ]
  }, [intakeSessionId, normalizedChipId, submitResult])
  const filteredUpstreamFlowNodes = useMemo(
    () => upstreamFlowNodes.filter((node) => preHandoffNodeIds.has(node.node_id)),
    [upstreamFlowNodes],
  )
  const restoredUpstreamFlowNodes = useMemo(
    () =>
      (restoredIntakeContext?.upstream_node_status ?? restoredIntakeContext?.upstream_truth_flow ?? []).filter((node) =>
        preHandoffNodeIds.has(node.node_id),
      ),
    [restoredIntakeContext],
  )
  const restoredChipId = restoredIntakeContext?.chip_id ?? prefillChipId

  return (
    <div className="space-y-7">
      <header className="rounded-xl border border-cyan-500/30 bg-gradient-to-br from-cyan-500/10 via-slate-900 to-slate-950 p-7 shadow-lg shadow-cyan-500/10">
        <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-cyan-400/40 bg-cyan-500/15 px-3 py-1 text-sm font-semibold tracking-wide text-cyan-300">
          <Sparkles size={14} />
          {t('intake.badge')}
        </div>
        <h1 className="text-3xl font-bold text-white">{t('intake.title')}</h1>
        <p className="mt-3 max-w-4xl text-base leading-7 text-slate-300">{t('intake.subtitle')}</p>
      </header>

      <section data-testid="intake-main-grid" className="grid gap-7 xl:grid-cols-[1.35fr_0.95fr]">
        <div className="space-y-6 rounded-xl border border-slate-800 bg-slate-900/70 p-6">
          <label className="block text-sm font-semibold uppercase tracking-wider text-slate-400">
            <span className="flex items-center gap-2">
              {t('intake.chip_id')}
              <HintTooltip
                title={t('intake.chip_hint_title')}
                lines={[
                  t('intake.chip_hint_1'),
                  t('intake.chip_hint_2'),
                  t('intake.chip_hint_3'),
                  t('intake.chip_hint_4'),
                  t('intake.chip_hint_5'),
                  t('intake.chip_hint_6'),
                ]}
              />
            </span>
            <input
              className="mt-2 w-full rounded-lg border border-slate-700 bg-slate-950 px-4 py-3 text-base text-slate-100 outline-none transition focus:border-cyan-400"
              placeholder={t('intake.chip_id_placeholder')}
              value={chipId}
              onChange={(e) => setChipId(e.target.value)}
            />
            <div className="mt-2 text-sm normal-case tracking-normal text-slate-500">
              {t('intake.chip_id_hint')}
            </div>
          </label>

          <div className="rounded-lg border border-slate-700 bg-slate-950/70 p-4">
            <div className="flex items-center gap-2 text-sm font-semibold uppercase tracking-wider text-slate-400">
              {t('intake.detected_template')}
              <HintTooltip
                title={t('intake.template_hint_title')}
                lines={[
                  t('intake.template_hint_1'),
                  t('intake.template_hint_2'),
                  t('intake.template_hint_3'),
                ]}
              />
            </div>
            <div className="mt-2 text-base text-slate-200">
              {autoDetectedTemplate ? (
                <span className="inline-flex rounded border border-emerald-500/40 bg-emerald-500/10 px-3 py-1.5 text-sm text-emerald-200">
                  {autoDetectedTemplate}
                </span>
              ) : (
                <span className="inline-flex rounded border border-amber-500/40 bg-amber-500/10 px-3 py-1.5 text-sm text-amber-200">
                  {t('intake.detected_template_none')}
                </span>
              )}
            </div>
            <div className="mt-3 text-xs normal-case tracking-normal">
              {templateOptionsHttpStatus === 200 ? (
                <span className="inline-flex items-center gap-2 rounded border border-emerald-500/40 bg-emerald-500/10 px-2 py-1 text-emerald-200">
                  {t('intake.api_health')}: {t('status.healthy')} (GET /api/intake/options = 200)
                </span>
              ) : (
                <span className="inline-flex items-center gap-2 rounded border border-amber-500/40 bg-amber-500/10 px-2 py-1 text-amber-200">
                  {t('intake.api_health')}: {t('status.degraded')} ({templateOptionsError || 'connection_failed'})
                </span>
              )}
            </div>
            <label className="mt-4 flex cursor-pointer items-center gap-2 text-sm text-slate-300">
              <input
                type="checkbox"
                className="h-5 w-5 cursor-pointer accent-cyan-400"
                checked={manualTemplateOverride}
                onChange={(e) => {
                  const checked = e.target.checked
                  setManualTemplateOverride(checked)
                  if (!checked) setTemplateOverrideRef('')
                }}
              />
              {t('intake.template_override_toggle')}
            </label>
            {manualTemplateOverride && (
              <label className="mt-4 block text-sm font-semibold uppercase tracking-wider text-slate-400">
                {t('intake.template_override')}
                <select
                  className="mt-2 w-full cursor-pointer rounded-lg border border-slate-700 bg-slate-950 px-4 py-3 text-base text-slate-100 outline-none transition focus:border-cyan-400 disabled:cursor-not-allowed disabled:opacity-60"
                  value={templateOverrideRef}
                  disabled={templateOptions.length === 0}
                  onChange={(e) => setTemplateOverrideRef(e.target.value)}
                >
                  <option value="">{t('intake.template_override_select')}</option>
                  {templateOptions.map((item) => (
                    <option key={item.path} value={item.path}>
                      {item.name}
                    </option>
                  ))}
                </select>
                {templateOptionsLoading && (
                  <div className="mt-2 text-sm normal-case tracking-normal text-slate-400">
                    {t('intake.template_loading')}
                  </div>
                )}
                {!templateOptionsLoading && templateOptions.length === 0 && (
                  <div className="mt-2 flex flex-wrap items-center gap-2 text-sm normal-case tracking-normal text-rose-300">
                    <span>{t('intake.template_empty')}</span>
                    <button
                      type="button"
                      onClick={() => void loadTemplateOptions()}
                      className="cursor-pointer rounded border border-slate-600 px-3 py-1 text-sm text-slate-200 transition hover:border-cyan-400 hover:text-cyan-200"
                    >
                      {t('intake.template_retry')}
                    </button>
                    {templateOptionsError && <span className="text-slate-500">({templateOptionsError})</span>}
                  </div>
                )}
              </label>
            )}
          </div>

          <label className="block text-sm font-semibold uppercase tracking-wider text-slate-400">
            <span className="flex items-center gap-2">
              {t('intake.prompt')}
              <HintTooltip
                title={t('intake.prompt_hint_title')}
                lines={[
                  t('intake.prompt_hint_1'),
                  t('intake.prompt_hint_2'),
                  t('intake.prompt_hint_3'),
                ]}
              />
            </span>
            <textarea
              className="mt-2 h-56 w-full resize-y rounded-lg border border-slate-700 bg-slate-950 px-4 py-3 text-base leading-7 text-slate-100 outline-none transition focus:border-cyan-400"
              placeholder={t('intake.prompt_placeholder')}
              value={promptText}
              onChange={(e) => setPromptText(e.target.value)}
            />
          </label>

          <div>
            <div className="mb-2 flex items-center gap-2 text-sm font-semibold uppercase tracking-wider text-slate-400">
              {t('intake.attachments')}
              <HintTooltip
                title={t('intake.attachments_hint_title')}
                lines={[
                  t('intake.attachments_hint_1'),
                  t('intake.attachments_hint_2'),
                  t('intake.attachments_hint_3'),
                ]}
              />
            </div>
            <label className="flex min-h-12 cursor-pointer items-center gap-3 rounded-lg border border-dashed border-slate-600 bg-slate-950/60 px-4 py-3 text-base text-slate-300 transition hover:border-cyan-400/70 hover:bg-slate-900">
              <Upload size={18} className="text-cyan-300" />
              {t('intake.upload_cta')}
              <input
                type="file"
                accept=".txt,.md,.pdf,.jpg,.jpeg,.png"
                multiple
                className="hidden"
                onChange={(e) => {
                  const selected = Array.from(e.target.files ?? [])
                  appendSelectedFiles(selected)
                  e.currentTarget.value = ''
                }}
              />
            </label>
            <ul className="mt-3 space-y-2 text-sm text-slate-300">
              {files.length === 0 ? (
                <li>{t('intake.no_files')}</li>
              ) : (
                files.map((file) => (
                  <li
                    key={`${file.name}-${file.size}-${file.lastModified}`}
                    className="flex items-center justify-between gap-2 rounded bg-slate-800/60 px-3 py-2"
                  >
                    <div className="flex min-w-0 items-center gap-2">
                      <FileText size={16} className="shrink-0 text-cyan-300" />
                      <span className="truncate">{file.name}</span>
                    </div>
                    <button
                      type="button"
                      aria-label={`remove-${file.name}`}
                      onClick={() => removeFile(file)}
                      className="inline-flex h-10 w-10 cursor-pointer items-center justify-center rounded border border-slate-600 bg-slate-900 text-slate-300 transition hover:border-rose-400 hover:text-rose-300 focus:outline-none focus:ring-2 focus:ring-cyan-400/60"
                    >
                      <X size={16} />
                    </button>
                  </li>
                ))
              )}
            </ul>
          </div>

          {templateMatchResult === 'NO_MATCH' && (
            <div className="rounded-lg border border-amber-500/40 bg-amber-500/10 p-5">
              <div className="mb-3 flex items-center gap-2 text-base font-semibold text-amber-300">
                <AlertTriangle size={18} />
                {t('intake.no_match_title')}
              </div>
              <p className="mb-3 text-sm leading-6 text-amber-100/90">{t('intake.no_match_desc')}</p>
              <fieldset className="space-y-3 text-sm">
                <label
                  htmlFor="no-match-b"
                  className={`flex cursor-pointer items-center gap-2 rounded border px-3 py-2 ${
                    noMatchAction === 'B'
                      ? 'border-cyan-400 bg-cyan-500/15 text-cyan-200'
                      : 'border-slate-600 bg-slate-900 text-slate-200'
                  }`}
                >
                  <input
                    id="no-match-b"
                    type="radio"
                    name="no-match-action"
                    className="h-5 w-5 cursor-pointer accent-cyan-400"
                    checked={noMatchAction === 'B'}
                    onChange={() => setNoMatchAction('B')}
                  />
                  {t('intake.option_b')}
                </label>
                <label
                  htmlFor="no-match-c"
                  className={`flex cursor-pointer items-center gap-2 rounded border px-3 py-2 ${
                    noMatchAction === 'C'
                      ? 'border-amber-400 bg-amber-500/15 text-amber-100'
                      : 'border-slate-600 bg-slate-900 text-slate-200'
                  }`}
                >
                  <input
                    id="no-match-c"
                    type="radio"
                    name="no-match-action"
                    className="h-5 w-5 cursor-pointer accent-amber-400"
                    checked={noMatchAction === 'C'}
                    onChange={() => setNoMatchAction('C')}
                  />
                  {t('intake.option_c')}
                </label>
              </fieldset>
            </div>
          )}
        </div>

        <aside className="space-y-5 rounded-xl border border-slate-800 bg-slate-900/70 p-6">
          <h2 className="flex items-center gap-2 text-base font-semibold tracking-wide text-cyan-300">
            {t('intake.preview_title')}
            <HintTooltip
              title={t('intake.preview_hint_title')}
              lines={[
                t('intake.preview_hint_1'),
                t('intake.preview_hint_2'),
                t('intake.preview_hint_3'),
              ]}
            />
          </h2>
          <div className="space-y-2 rounded-lg border border-slate-700 bg-slate-950/70 p-4 text-sm text-slate-300">
            <div><span className="text-slate-500">intake_session_id:</span> {intakeSessionId}</div>
            {hasReturnContext && (
              <div className="rounded border border-cyan-800/60 bg-cyan-950/20 p-2 text-xs leading-5 text-cyan-100">
                <div>{t('intake.return_context_title')}</div>
                <div><span className="text-cyan-300">{t('intake.return_context_source')}:</span> {prefillSource || '-'}</div>
                <div><span className="text-cyan-300">{t('intake.return_context_chip')}:</span> {prefillChipId || '-'}</div>
                <div><span className="text-cyan-300">{t('intake.return_context_intake_session')}:</span> {prefillIntakeSession || '-'}</div>
              </div>
            )}
            {restoredIntakeLoading && (
              <div className="rounded border border-slate-700 bg-slate-950/70 p-2 text-xs text-slate-300">
                {t('intake.restored_context_loading')}
              </div>
            )}
            {restoredIntakeError && (
              <div className="rounded border border-rose-500/40 bg-rose-500/10 p-2 text-xs text-rose-200">
                {t('intake.restored_context_error')}: {restoredIntakeError}
              </div>
            )}
            {restoredIntakeWarning && (
              <div className="rounded border border-amber-500/40 bg-amber-500/10 p-2 text-xs text-amber-200">
                {restoredIntakeWarning}
              </div>
            )}
            {restoredIntakeContext && (
              <div className="rounded border border-emerald-500/40 bg-emerald-500/10 p-2 text-xs leading-5 text-emerald-100">
                <div>{t('intake.restored_context_title')}</div>
                <div><span className="text-emerald-300">{t('intake.restored_context_template_resolution')}:</span> {restoredIntakeContext.template_resolution_record?.verdict ?? '-'}</div>
                <div><span className="text-emerald-300">{t('intake.restored_context_template_ref')}:</span> {restoredIntakeContext.template_resolution_record?.template_ref ?? restoredIntakeContext.intake_session_record?.template_ref ?? '-'}</div>
                <div><span className="text-emerald-300">{t('intake.restored_context_bootstrap_mode')}:</span> {restoredIntakeContext.template_resolution_record?.bootstrap_mode ?? restoredIntakeContext.intake_session_record?.bootstrap_mode ?? '-'}</div>
              </div>
            )}
            <div><span className="text-slate-500">template_match_result:</span> {templateMatchResult}</div>
            <div><span className="text-slate-500">detected_template:</span> {autoDetectedTemplate ?? 'null'}</div>
            <div><span className="text-slate-500">override_enabled:</span> {manualTemplateOverride ? 'true' : 'false'}</div>
            <div><span className="text-slate-500">template_ref:</span> {matchedTemplate ? `templates/${matchedTemplate}` : 'null'}</div>
            <div><span className="text-slate-500">bootstrap_mode:</span> {bootstrapMode}</div>
            <div><span className="text-slate-500">attachment_count:</span> {files.length}</div>
          </div>
          <p className="text-sm leading-6 text-slate-400">{t('intake.preview_note')}</p>
          <button
            type="button"
            onClick={submitIntake}
            disabled={!canSubmit || submitState === 'submitting'}
            className="mt-2 min-h-12 w-full rounded-md bg-cyan-400 px-4 py-3 text-base font-semibold text-slate-950 transition hover:bg-cyan-300 disabled:cursor-not-allowed disabled:bg-slate-700 disabled:text-slate-300"
          >
            {submitState === 'submitting' ? t('intake.submitting') : t('intake.submit')}
          </button>
          <div className="rounded-md border border-slate-700 bg-slate-950/60 p-3">
            <div className="mb-2 text-sm font-semibold uppercase tracking-wider text-slate-300">
              {t('intake.execute_actions_title')}
            </div>
            <ol className="list-decimal space-y-1.5 pl-5 text-sm leading-6 text-slate-300">
              <li>{t('intake.execute_action_1')}</li>
              <li>{t('intake.execute_action_2')}</li>
              <li>{t('intake.execute_action_3')}</li>
              <li>{t('intake.execute_action_4')}</li>
              <li>{t('intake.execute_action_5')}</li>
            </ol>
          </div>
          <div className="rounded-md border border-cyan-700/40 bg-cyan-950/20 p-3">
            <div className="mb-2 text-sm font-semibold uppercase tracking-wider text-cyan-300">
              {t('intake.next_steps_title')}
            </div>
            <div className="space-y-2 text-sm leading-6 text-slate-200">
              <div>
                <div>{t('intake.next_step_2_title')}</div>
                <div className="font-mono text-xs text-cyan-200 break-all">
                  chips/{normalizedChipId}/specs/requirement_item.json
                </div>
                <div className="font-mono text-xs text-cyan-200 break-all">
                  chips/{normalizedChipId}/specs/requirement_item_review_package.json
                </div>
              </div>
              <div>{t('intake.next_step_3_title')}</div>
              <div className="font-mono text-xs text-cyan-200 break-all">
                chips/{normalizedChipId}/specs/requirement_item_adjudication_record.template.json
              </div>
              <div className="font-mono text-xs text-cyan-200 break-all">
                chips/{normalizedChipId}/specs/requirement_item_adjudication_record.json
              </div>
              <div>
                <div>{t('intake.next_step_4_title')}</div>
                <div className="font-mono text-xs text-cyan-200 break-all">
                  chips/{normalizedChipId}/architecture/architecture_graph.draft.json
                </div>
                <div className="font-mono text-xs text-cyan-200 break-all">
                  chips/{normalizedChipId}/architecture/builder_validation_handoff.json
                </div>
              </div>
            </div>
            <div className="mt-3 rounded border border-cyan-800/60 bg-slate-950/50 px-3 py-2 text-xs leading-5 text-cyan-100">
              {t('intake.next_steps_note')}
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              <Link to={`/requirement-adjudication?chip=${encodeURIComponent(normalizedChipId)}`} className="rounded border border-slate-600 bg-slate-900 px-2 py-1 text-xs text-slate-200 hover:border-cyan-400 hover:text-cyan-200">
                {t('intake.next_cta_authority')}
              </Link>
              <Link to="/run-detail" className="rounded border border-slate-600 bg-slate-900 px-2 py-1 text-xs text-slate-200 hover:border-cyan-400 hover:text-cyan-200">
                {t('intake.next_cta_run_detail')}
              </Link>
            </div>
          </div>
          {submitState !== 'idle' && (
            <div
              className={`rounded-md border px-3 py-2 text-sm ${
                submitState === 'success'
                  ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-200'
                  : submitState === 'error'
                    ? 'border-rose-500/40 bg-rose-500/10 text-rose-200'
                    : 'border-slate-600 bg-slate-800 text-slate-200'
              }`}
            >
              {submitMessage || t('intake.submitting')}
            </div>
          )}
        </aside>
      </section>
      {submitState === 'success' && submitResult && (
        <UpstreamTruthFlowBoard
          chipId={submitResult.chip_id ?? normalizedChipId}
          nodes={filteredUpstreamFlowNodes}
        />
      )}
      {submitState !== 'success' && restoredIntakeContext && (
        <UpstreamTruthFlowBoard
          chipId={restoredChipId}
          nodes={restoredUpstreamFlowNodes}
        />
      )}
    </div>
  )
}
