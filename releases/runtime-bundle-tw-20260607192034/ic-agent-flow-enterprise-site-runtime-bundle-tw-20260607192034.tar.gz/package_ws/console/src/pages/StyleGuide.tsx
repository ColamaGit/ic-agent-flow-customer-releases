import HeaderIcon, { type HeaderIconKey } from '../components/HeaderIcon'

export default function StyleGuide() {
  const headerIcons: HeaderIconKey[] = [
    'dashboard', 'flow', 'chip', 'policy', 'gate', 'evidence',
    'report', 'audit', 'warning', 'error', 'pass', 'block',
    'runtime', 'profile', 'package', 'release', 'settings', 'user',
    'lock', 'clock', 'route', 'decision', 'qa', 'trust',
  ]

  const badges = [
    ['PASS', 'ok'],
    ['PASS_WITH_WARNINGS', 'warn'],
    ['BLOCKED', 'block'],
    ['APPROVED_CANONICAL', 'ok'],
    ['REAL_RUN', 'info'],
    ['CONDITIONAL_READY', 'neutral'],
    ['v1.9', 'info'],
    ['post-v1.9', 'info'],
    ['G1~G9 PASS', 'ok'],
    ['GOVERNED', 'neutral'],
    ['FAIL_CLOSED', 'neutral'],
    ['TRACEABLE', 'neutral'],
    ['AUDIT_READY', 'info'],
    ['CUSTOMER_LOCAL', 'neutral'],
    ['ROUTE_A', 'info'],
    ['ROUTE_B', 'info'],
    ['FULL_IMPL', 'ok'],
  ] as const

  return (
    <div className="space-y-6">
      <section className="rounded-xl border border-slate-800 bg-slate-900/60 p-5">
        <h1 className="text-2xl font-semibold tracking-tight text-white">ICAF Style Guide</h1>
        <p className="mt-2 text-sm text-slate-400">
          Extracted from Image #1 for dark-mode console usage.
        </p>
      </section>

      <section className="rounded-xl border border-slate-800 bg-slate-900 p-5">
        <h2 className="text-lg font-semibold text-white">Logo (#6 Preferred)</h2>
        <div className="mt-3 flex items-center gap-4">
          <div className="icaf-logo-wrap">
            <svg viewBox="0 0 64 64" className="icaf-logo-mark" aria-hidden="true">
              <rect x="16" y="14" width="32" height="36" rx="7" className="chip-core" />
              <path d="M8 22h8M8 30h8M8 38h8M8 46h8M48 22h8M48 30h8M48 38h8M48 46h8" className="pin-line" />
              <path d="M22 20v-6M30 20v-6M38 20v-6M22 56v-6M30 56v-6M38 56v-6" className="pin-line" />
              <circle cx="41.5" cy="33.5" r="2.8" className="node-dot" />
              <path d="M23 27h11" className="arrow-green" />
              <path d="M30.5 24.5 34 27l-3.5 2.5" className="arrow-green" />
              <path d="M34 40H23" className="arrow-amber" />
              <path d="M26.5 37.5 23 40l3.5 2.5" className="arrow-amber" />
            </svg>
          </div>
          <div>
            <div className="text-lg font-bold tracking-[0.08em] text-white">ic-agent-flow</div>
            <div className="text-sm tracking-[0.08em] text-cyan-300">console</div>
          </div>
        </div>
      </section>

      <section className="rounded-xl border border-slate-800 bg-slate-900 p-5">
        <h2 className="text-lg font-semibold text-white">Header Icon Tokens (24)</h2>
        <div className="mt-3 grid grid-cols-2 gap-2 text-sm text-slate-300 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
          {headerIcons.map((name) => (
            <div key={name} className="rounded border border-slate-700 bg-slate-950/70 px-2 py-2">
              <div className="inline-flex items-center gap-2">
                <HeaderIcon name={name} className="text-cyan-300" size={16} />
                <span>{name}</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="rounded-xl border border-slate-800 bg-slate-900 p-5">
        <h2 className="text-lg font-semibold text-white">Recommended Web Badges</h2>
        <div className="mt-3 flex flex-wrap gap-2">
          {badges.map(([label, tone]) => (
            <span key={label} className={`icaf-badge ${tone}`}>{label}</span>
          ))}
        </div>
      </section>

      <section className="rounded-xl border border-slate-800 bg-slate-900 p-5">
        <h2 className="text-lg font-semibold text-white">Status Lights Pack (Dark)</h2>
        <div className="mt-3 flex flex-wrap gap-2">
          <span className="status-pill pass">PASS</span>
          <span className="status-pill warn">WARN</span>
          <span className="status-pill block">BLOCKED</span>
          <span className="status-pill info">INFO</span>
          <span className="status-pill unknown">UNKNOWN</span>
        </div>
        <div className="mt-3 flex flex-wrap items-center gap-3">
          <span className="status-light pass" />
          <span className="status-light warn" />
          <span className="status-light block" />
          <span className="status-light info" />
          <span className="status-light unknown" />
        </div>
      </section>
    </div>
  )
}
