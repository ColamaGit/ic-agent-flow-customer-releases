import React, { useMemo } from 'react'
import { AlertTriangle, Clock, FileSearch, Lock, Shield, XCircle } from 'lucide-react'
import { Link, useLocation } from 'react-router-dom'
import { useTranslation } from '../contexts/i18n'
import { parseMode, sortChipsForMode } from '../hooks/evidenceSummary'
import { useProductionRunsInventory } from '../hooks/useProductionRunsInventory'
type AuthorityStatus = 'PENDING' | 'APPROVED'

interface AuthorityEntry {
  id: string
  scenario_name: string
  tier: string
  status: AuthorityStatus
  requested_by: string
  subjects: string[]
  evidence_summary: string
  gate_type: string
}

interface StatusSignal {
  relativePath: string
  status: string
}

function parseStatusSignals(files: Array<{ relative_path: string; kind: string; preview_text?: string | null }>): StatusSignal[] {
  const signals: StatusSignal[] = []
  for (const file of files) {
    if (file.kind !== 'file') continue
    if (!/normalized\..*\.json$/i.test(file.relative_path)) continue
    const preview = file.preview_text ?? ''
    if (!preview.trim().startsWith('{')) continue
    try {
      const parsed = JSON.parse(preview) as { status?: string }
      if (parsed.status) {
        signals.push({ relativePath: file.relative_path, status: String(parsed.status).toUpperCase() })
      }
    } catch {
      // ignore malformed preview
    }
  }
  return signals
}

function classifyAuthorityStatus(signals: StatusSignal[]): AuthorityStatus {
  if (signals.some((s) => ['FAIL', 'BLOCKED', 'ERROR'].includes(s.status))) return 'PENDING'
  if (signals.some((s) => ['NOT_CHECKED', 'WARNING', 'WARN', 'PENDING', 'UNVALIDATED', 'PARTIAL'].includes(s.status))) return 'PENDING'
  return 'APPROVED'
}

const HumanAuthorityPage: React.FC = () => {
  const { t } = useTranslation()
  const location = useLocation()
  const mode = useMemo(() => parseMode(location.search), [location.search])
  const { data, loading, error } = useProductionRunsInventory({ layeredWithRuns: true })

  const entries = useMemo<AuthorityEntry[]>(() => {
    if (!data?.chips) return []

    const selectedChips = sortChipsForMode(data.chips, mode)

    const result: AuthorityEntry[] = []

    for (const chip of selectedChips) {
      for (const run of chip.runs) {
        for (const execution of run.executions) {
          const signals = parseStatusSignals(execution.files)
          const status = classifyAuthorityStatus(signals)
          const subjectBindingFiles = execution.files
            .filter((f) => f.kind === 'file' && f.relative_path.startsWith('subject_binding/'))
            .map((f) => f.relative_path)
          const flaggedSignals = signals.filter((s) => ['FAIL', 'BLOCKED', 'ERROR', 'NOT_CHECKED', 'WARNING', 'WARN', 'PENDING', 'UNVALIDATED', 'PARTIAL'].includes(s.status))

          const subjects = [
            ...subjectBindingFiles.slice(0, 2),
            ...flaggedSignals.slice(0, 2).map((s) => `${s.relativePath} (${s.status})`),
          ]

          const gateType = status === 'PENDING' ? 'FAIL_CLOSED_REVIEW_REQUIRED' : 'AUTHORITY_CLOSED'
          const evidenceSummary = status === 'PENDING'
            ? `${flaggedSignals.length} warning/blocked signals detected; manual authority review required.`
            : 'No warning/blocked normalized status found in this execution.'

          result.push({
            id: `${chip.chip_id}:${run.run_id}:${execution.execution_id}`,
            scenario_name: `${chip.chip_id} / ${run.run_id} / ${execution.execution_id}`,
            tier: mode === 'enterprise_site' ? 'Tier 3 (High-Value)' : mode === 'team_project' ? 'Tier 2 (Team)' : 'Tier 1 (Solo)',
            status,
            requested_by: 'execution_evidence_scanner',
            subjects: subjects.length > 0 ? subjects : ['(no subject_binding / normalized signal preview)'],
            evidence_summary: evidenceSummary,
            gate_type: gateType,
          })
        }
      }
    }

    return result
      .filter((entry) => entry.status === 'PENDING')
      .sort((a, b) => b.id.localeCompare(a.id))
      .slice(0, 30)
  }, [data, mode])

  if (loading) return <div className="text-slate-500 font-mono text-sm animate-pulse p-8">{t('common.loading')}</div>
  if (error) return <div className="text-rose-400 p-6">{t('common.error')}: {error}</div>

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <header className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-white flex items-center gap-3">
            <Lock className="w-8 h-8 text-indigo-400" />
            {t('human_authority.title')}
          </h1>
          <p className="mt-2 text-slate-400 max-w-3xl text-lg">
            {t('human_authority.subtitle')}
          </p>
        </div>
        <div className="flex gap-4">
          <div className="bg-slate-800/50 px-4 py-2 rounded-lg border border-slate-700/50">
            <span className="text-slate-500 text-sm block">{t('human_authority.pending_adjudications')}</span>
            <span className="text-2xl font-bold text-amber-400">{entries.length}</span>
          </div>
        </div>
      </header>

      {entries.length === 0 ? (
        <section className="rounded-xl border border-emerald-800/50 bg-emerald-950/20 p-5 text-sm text-emerald-200">
          {t('human_authority.no_pending')}
        </section>
      ) : (
        <div className="grid gap-6">
          {entries.map((entry) => (
            <article key={entry.id} className="bg-slate-900/50 border border-slate-800 rounded-2xl overflow-hidden glass-card">
              <div className="p-6 border-b border-slate-800 flex justify-between items-center">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-indigo-500/10 rounded-xl border border-indigo-500/20">
                    <Shield className="w-6 h-6 text-indigo-400" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white break-all">{entry.scenario_name}</h3>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-xs uppercase tracking-widest font-bold text-amber-500 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                        {entry.tier}
                      </span>
                      <span className="text-slate-500 mr-2 opacity-50">•</span>
                      <span className="text-sm text-slate-400 flex items-center gap-1">
                        <Clock className="w-3 h-3" /> {entry.requested_by}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-sm text-slate-500 block mb-1">{t('human_authority.req_id')}</span>
                  <code className="text-xs text-indigo-400 bg-indigo-500/5 px-2 py-1 rounded">{entry.id}</code>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-0">
                <div className="p-6 border-r border-slate-800">
                  <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-2 mb-4">
                    <FileSearch className="w-4 h-4" /> {t('human_authority.subjects_evidence')}
                  </h4>
                  <ul className="space-y-2">
                    {entry.subjects.map((s) => (
                      <li key={`${entry.id}-${s}`} className="text-xs text-slate-300 bg-slate-800/50 px-3 py-2 rounded border border-slate-700/50 break-all">
                        <code>{s}</code>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="p-6 border-r border-slate-800">
                  <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-2 mb-4">
                    <AlertTriangle className="w-4 h-4 text-amber-400" /> {t('human_authority.gate_violation_exception')}
                  </h4>
                  <div className="bg-amber-500/5 border border-amber-500/20 p-4 rounded-xl">
                    <span className="text-sm font-bold text-amber-400 block mb-1 uppercase tracking-tighter">{entry.gate_type}</span>
                    <p className="text-xs text-slate-300 leading-relaxed">{entry.evidence_summary}</p>
                  </div>
                </div>

                <div className="p-6 bg-slate-900/80">
                  <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-4">{t('human_authority.human_signoff')}</h4>
                  <div className="p-4 rounded-xl border bg-amber-500/10 border-amber-500/20 text-amber-200 text-sm">
                    <div className="inline-flex items-center gap-2 font-semibold">
                      <XCircle className="w-4 h-4" /> PENDING
                    </div>
                    <p className="mt-2 text-xs text-amber-100/90">{t('human_authority.readonly_notice')}</p>
                    {(() => {
                      const [chipId, runId, executionId] = entry.id.split(':')
                      const q = `mode=${mode}&chip=${encodeURIComponent(chipId)}&run=${encodeURIComponent(runId)}&execution=${encodeURIComponent(executionId)}`
                      return (
                        <div className="mt-3 flex flex-wrap gap-2">
                          <Link
                            to={`/decision-inbox?${q}`}
                            className="inline-flex items-center rounded-md border border-amber-400/40 bg-amber-500/10 px-2.5 py-1.5 text-xs font-medium text-amber-100 hover:bg-amber-500/20"
                          >
                            {t('human_authority.open_decision_inbox')}
                          </Link>
                          <Link
                            to={`/audit-replay?${q}`}
                            className="inline-flex items-center rounded-md border border-cyan-400/40 bg-cyan-500/10 px-2.5 py-1.5 text-xs font-medium text-cyan-100 hover:bg-cyan-500/20"
                          >
                            {t('human_authority.open_audit_replay')}
                          </Link>
                        </div>
                      )
                    })()}
                  </div>
                </div>
              </div>
            </article>
          ))}
        </div>
      )}
    </div>
  )
}

export default HumanAuthorityPage
