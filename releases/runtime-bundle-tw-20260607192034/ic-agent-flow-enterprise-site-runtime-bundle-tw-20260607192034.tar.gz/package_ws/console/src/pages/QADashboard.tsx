import { AlertCircle, CheckCircle2, ShieldAlert, Zap, Activity, Database, CircleHelp } from 'lucide-react'
import { useEffect, useId, useMemo, useRef, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { useTranslation } from '../contexts/i18n'
import { parseMode, sortChipsForMode } from '../hooks/evidenceSummary'
import { useProductionRunsInventory, type ProductionRunExecution } from '../hooks/useProductionRunsInventory'

function HintTooltip({
  title,
  lines,
  align = 'center',
}: {
  title: string
  lines: string[]
  align?: 'left' | 'center' | 'right'
}) {
  const [open, setOpen] = useState(false)
  const panelId = useId()
  const rootRef = useRef<HTMLSpanElement>(null)

  useEffect(() => {
    function onPointerDown(event: PointerEvent) {
      if (!rootRef.current) return
      if (!rootRef.current.contains(event.target as Node)) {
        setOpen(false)
      }
    }

    function onKeyDown(event: KeyboardEvent) {
      if (event.key === 'Escape') {
        setOpen(false)
      }
    }

    document.addEventListener('pointerdown', onPointerDown)
    document.addEventListener('keydown', onKeyDown)
    return () => {
      document.removeEventListener('pointerdown', onPointerDown)
      document.removeEventListener('keydown', onKeyDown)
    }
  }, [])

  const panelAlignClass =
    align === 'left'
      ? 'left-0'
      : align === 'right'
        ? 'right-0'
        : 'left-1/2 -translate-x-1/2'

  return (
    <span ref={rootRef} className="group relative inline-flex">
      <button
        type="button"
        aria-label={`${title}-hint`}
        aria-expanded={open}
        aria-controls={panelId}
        className="inline-flex h-6 w-6 cursor-help items-center justify-center rounded-full border border-slate-600 bg-slate-900 text-slate-300 transition hover:border-cyan-400 hover:text-cyan-300"
        onClick={() => setOpen((prev) => !prev)}
      >
        <CircleHelp size={14} />
      </button>
      <div
        id={panelId}
        className={`absolute top-8 z-30 w-[340px] rounded-lg border border-slate-700 bg-slate-950/95 p-3 text-left text-xs normal-case tracking-normal text-slate-200 shadow-xl ${panelAlignClass} ${
          open ? 'pointer-events-auto block' : 'pointer-events-none hidden'
        }`}
      >
        <div className="mb-1 text-sm font-semibold text-cyan-300">{title}</div>
        <ul className="list-disc space-y-1 pl-4">
          {lines.map((line, idx) => (
            <li key={`${title}-${idx}`}>{line}</li>
          ))}
        </ul>
      </div>
    </span>
  )
}

export default function QADashboard() {
  const location = useLocation()
  const { t } = useTranslation()
  const mode = useMemo(() => parseMode(location.search), [location.search])
  const { data, loading, error } = useProductionRunsInventory({ layeredWithRuns: true })
  const navigate = useNavigate()

  if (loading) return <div className="text-slate-500 font-mono text-sm animate-pulse p-8">{t('qa_dashboard.loading')}</div>
  if (error) return <div className="text-rose-500 font-mono text-sm p-8">{t('qa_dashboard.error')}: {error}</div>

  const portfolio = sortChipsForMode(data?.chips ?? [], mode)

  function executionVerdict(execution: ProductionRunExecution): 'PASS' | 'WARN' | 'BLOCKED' | 'UNKNOWN' {
    if ((!execution.files || execution.files.length === 0) && execution.verdict) {
      return execution.verdict
    }
    const normalizedStatuses: string[] = []
    let passTokenInLog = false

    for (const file of execution.files) {
      if (file.kind !== 'file') continue
      const preview = file.preview_text ?? ''
      if (/normalized\..*\.json$/i.test(file.relative_path) && preview.trim().startsWith('{')) {
        try {
          const parsed = JSON.parse(preview) as { status?: string }
          if (parsed.status) normalizedStatuses.push(parsed.status.toUpperCase())
        } catch {
          // ignore invalid preview json; fallback to other signals.
        }
      }
      if (/raw\.log$/i.test(file.relative_path) && /REAL_RUN_PASS|_PASS\b| PASS\b/i.test(preview)) {
        passTokenInLog = true
      }
    }

    if (normalizedStatuses.some((s) => ['FAIL', 'BLOCKED', 'ERROR'].includes(s))) return 'BLOCKED'
    if (normalizedStatuses.some((s) => ['NOT_CHECKED', 'WARNING', 'WARN', 'PENDING', 'UNVALIDATED'].includes(s))) return 'WARN'
    if (normalizedStatuses.some((s) => ['PASS', 'OK'].includes(s))) return 'PASS'
    if (passTokenInLog) return 'PASS'
    return 'UNKNOWN'
  }

  const executionRows = portfolio.flatMap((chip) =>
    chip.runs.flatMap((run) =>
      run.executions.map((execution) => ({
        chip_id: chip.chip_id,
        source_dir: chip.source_dir,
        run_id: run.run_id,
        execution_id: execution.execution_id,
        resolved_root: execution.resolved_root,
        file_count: execution.file_count ?? execution.files.filter((f) => f.kind === 'file').length,
        verdict: executionVerdict(execution),
      })),
    ),
  )

  const totalExecutions = executionRows.length
  const passCount = executionRows.filter((r) => r.verdict === 'PASS').length
  const warnCount = executionRows.filter((r) => r.verdict === 'WARN').length
  const blockedCount = executionRows.filter((r) => r.verdict === 'BLOCKED').length
  const unknownCount = executionRows.filter((r) => r.verdict === 'UNKNOWN').length
  const observedCount = totalExecutions - unknownCount
  const realBindingPct = totalExecutions > 0 ? Math.round((observedCount / totalExecutions) * 100) : 0
  const unclassifiedPct = totalExecutions > 0 ? Math.round((unknownCount / totalExecutions) * 100) : 0
  const revalidationQueue = executionRows.filter((r) => r.verdict === 'WARN' || r.verdict === 'BLOCKED').slice(0, 8)
  const historicalRows = [...executionRows]
    .sort((a, b) => b.execution_id.localeCompare(a.execution_id))
    .slice(0, 8)

  function chipVerification(chipId: string): string {
    const rows = executionRows.filter((row) => row.chip_id === chipId)
    if (rows.some((row) => row.verdict === 'BLOCKED')) return 'BLOCKED'
    if (rows.some((row) => row.verdict === 'WARN')) return 'WARN'
    if (rows.some((row) => row.verdict === 'PASS')) return 'PASS'
    return 'UNKNOWN'
  }

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-2 duration-700">
      <div className="flex justify-between items-end border-b border-slate-800/50 pb-6">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]"></span>
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em]">{t('dash.active_chips')}</span>
          </div>
          <h1 className="text-4xl font-light text-white mb-2 tracking-tight">{t('dash.portfolio')}</h1>
          <p className="text-slate-400 text-sm max-w-2xl">{t('dash.subtitle')}</p>
        </div>
        <div className="flex flex-col items-end gap-2 text-right">
          <div className="bg-blue-500/10 border border-blue-500/20 px-3 py-1.5 rounded text-[11px] font-mono font-bold text-blue-400 shadow-lg shadow-blue-500/5 uppercase">
            {mode.replace('_', ' ').toUpperCase()}
          </div>
          <div className="text-[10px] text-slate-600 font-mono uppercase">{t('qa_dashboard.workspace')}: {data?.workspace_id}</div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
        {[
          {
            label: t('qa_dashboard.card_observed'),
            status: `${observedCount}/${totalExecutions}`,
            icon: CheckCircle2,
            color: 'text-emerald-400',
            bg: 'bg-emerald-500/5',
            hintTitle: t('qa_dashboard.hint_card_observed_title'),
            hintLines: [t('qa_dashboard.hint_card_observed_1'), t('qa_dashboard.hint_card_observed_2'), t('qa_dashboard.hint_card_observed_3')],
          },
          {
            label: t('qa_dashboard.card_revalidation'),
            status: `${revalidationQueue.length}`,
            icon: Zap,
            color: 'text-blue-400',
            bg: 'bg-blue-500/5',
            hintTitle: t('qa_dashboard.hint_card_revalidation_title'),
            hintLines: [t('qa_dashboard.hint_card_revalidation_1'), t('qa_dashboard.hint_card_revalidation_2'), t('qa_dashboard.hint_card_revalidation_3')],
          },
          {
            label: t('qa_dashboard.card_warn_or_blocked'),
            status: `${warnCount + blockedCount}`,
            icon: Activity,
            color: 'text-amber-400',
            bg: 'bg-amber-500/5',
            hintTitle: t('qa_dashboard.hint_card_warn_blocked_title'),
            hintLines: [t('qa_dashboard.hint_card_warn_blocked_1'), t('qa_dashboard.hint_card_warn_blocked_2'), t('qa_dashboard.hint_card_warn_blocked_3')],
          },
          {
            label: t('qa_dashboard.card_chips_in_scope'),
            status: `${portfolio.length}`,
            icon: ShieldAlert,
            color: 'text-emerald-400',
            bg: 'bg-emerald-500/5',
            hintTitle: t('qa_dashboard.hint_card_chips_scope_title'),
            hintLines: [t('qa_dashboard.hint_card_chips_scope_1'), t('qa_dashboard.hint_card_chips_scope_2'), t('qa_dashboard.hint_card_chips_scope_3')],
          },
        ].map((s, i) => (
          <div key={i} className={`group ${s.bg} border border-slate-800/80 rounded-xl p-5 flex items-center justify-between shadow-xl shadow-slate-950/40 hover:border-slate-700 transition-all duration-300 hover:-translate-y-1`}>
            <div>
              <span className="text-[11px] text-slate-500 uppercase font-bold tracking-[0.15em] mb-2 inline-flex items-center gap-1">
                {s.label}
                <HintTooltip title={s.hintTitle} lines={s.hintLines} />
              </span>
              <span className={`text-xl font-semibold ${s.color} tracking-tight`}>{s.status}</span>
            </div>
            <s.icon className={`w-10 h-10 opacity-10 group-hover:opacity-30 transition-opacity ${s.color}`} />
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-2xl">
            <div className="p-5 border-b border-slate-800 bg-slate-900/50 flex justify-between items-center">
              <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <Database size={18} className="text-indigo-400" />
                {t('dash.inventory_table')}
                <HintTooltip
                  title={t('qa_dashboard.hint_inventory_table_title')}
                  lines={[
                    t('qa_dashboard.hint_inventory_table_1'),
                    t('qa_dashboard.hint_inventory_table_2'),
                    t('qa_dashboard.hint_inventory_table_3'),
                  ]}
                />
              </h2>
              <div className="flex gap-4 text-[11px] font-mono font-bold">
                 <span className="text-emerald-500 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">{portfolio.length} {t('dash.active_chips')}</span>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-[11px] text-slate-500 uppercase tracking-widest bg-slate-950/30">
                    <th className="p-5 font-bold">{t('table.chip_id')}</th>
                    <th className="p-5 font-bold">{t('table.phase')}</th>
                    <th className="p-5 font-bold">{t('table.verification')}</th>
                    <th className="p-5 font-bold">
                      <span className="inline-flex items-center gap-1">
                        {t('table.readiness')}
                        <HintTooltip
                          title={t('qa_dashboard.hint_readiness_title')}
                          lines={[
                            t('qa_dashboard.hint_readiness_1'),
                            t('qa_dashboard.hint_readiness_2'),
                            t('qa_dashboard.hint_readiness_3'),
                          ]}
                        />
                      </span>
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {portfolio.map((f, i) => (
                    <tr 
                      key={i} 
                      className="hover:bg-slate-800/40 transition-colors text-[13px] group cursor-pointer"
                      onClick={() => navigate(`/run/${f.source_dir ?? f.chip_id}?mode=${mode}`)}
                    >
                      <td className="p-5 text-slate-300 font-mono group-hover:text-amber-400 transition-colors">
                        {f.chip_id}
                      </td>
                      <td className="p-5 text-slate-500">
                         <span className="px-2 py-0.5 rounded bg-slate-950/50 border border-slate-800 text-[11px] text-slate-400 font-mono uppercase">PRODUCTION_RUNS</span>
                      </td>
                      <td className="p-5 text-slate-500">
                         <span className="px-2 py-0.5 rounded bg-slate-950/50 border border-slate-800 text-[11px] text-slate-400 font-mono uppercase">{chipVerification(f.chip_id)}</span>
                      </td>
                      <td className="p-5">
                         <span className="font-bold text-blue-400">{f.runs.length} runs</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-2xl">
            <div className="p-5 border-b border-slate-800 bg-slate-900/50 flex justify-between items-center">
              <h2 className="text-base font-bold text-slate-100 inline-flex items-center gap-2">
                {t('dash.historical')}
                <HintTooltip
                  title={t('qa_dashboard.hint_historical_title')}
                  lines={[
                    t('qa_dashboard.hint_historical_1'),
                    t('qa_dashboard.hint_historical_2'),
                    t('qa_dashboard.hint_historical_3'),
                  ]}
                />
              </h2>
              <span className="text-[11px] text-slate-500 italic uppercase font-bold tracking-tighter">{t('table.last_update')}: {data?.timestamp ?? '-'}</span>
            </div>
            <div className="divide-y divide-slate-800">
              {historicalRows.map((v, i) => (
                <button
                  type="button"
                  key={i}
                  className="w-full p-5 flex items-center justify-between hover:bg-slate-800/40 transition-colors text-left"
                  onClick={() =>
                    navigate(
                      `/artifacts?mode=${mode}&chip=${encodeURIComponent(v.chip_id)}&run=${encodeURIComponent(v.run_id)}&execution=${encodeURIComponent(v.execution_id)}`,
                    )
                  }
                >
                   <div className="flex flex-col">
                      <span className={`text-sm font-bold tracking-tight ${v.verdict === 'BLOCKED' ? 'text-rose-500' : v.verdict === 'WARN' ? 'text-amber-500' : v.verdict === 'PASS' ? 'text-emerald-500' : 'text-slate-400'}`}>
                        {v.verdict}
                      </span>
                      <span className="text-[11px] text-slate-500 font-mono mt-1">{v.chip_id} / {v.run_id}</span>
                   </div>
                   <span className="text-xs text-slate-600 font-mono">{v.execution_id}</span>
                </button>
              ))}
              {historicalRows.length === 0 && (
                <div className="p-5 text-sm text-slate-500">{t('run_explorer.no_runs')}</div>
              )}
            </div>
          </div>
        </div>

        <div className="space-y-8">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl">
             <h3 className="text-sm font-bold text-slate-100 mb-6 uppercase tracking-[0.1em] inline-flex items-center gap-2">
               {t('dash.vmode_breakdown')}
               <HintTooltip
                 title={t('qa_dashboard.hint_vmode_title')}
                 lines={[
                   t('qa_dashboard.hint_vmode_1'),
                   t('qa_dashboard.hint_vmode_2'),
                   t('qa_dashboard.hint_vmode_3'),
                 ]}
               />
             </h3>
             <div className="space-y-6">
               {[
                 { label: t('qa_dashboard.real_binding'), value: `${realBindingPct}%` },
                 { label: t('qa_dashboard.simulated'), value: `${unclassifiedPct}%` }
               ].map((m, i) => (
                 <div key={i} className="space-y-2">
                   <div className="flex justify-between text-[11px] font-mono font-bold text-slate-400">
                     <span>{m.label}</span>
                     <span>{m.value}</span>
                   </div>
                   <div className="w-full h-1.5 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                     <div className="h-full bg-indigo-500 shadow-lg transition-all duration-1000" style={{ width: m.value }}></div>
                   </div>
                 </div>
               ))}
             </div>
          </div>

          <div className="bg-rose-950/5 border border-rose-900/30 rounded-xl p-6 shadow-xl shadow-rose-950/20">
            <h3 className="text-sm font-bold text-rose-400 mb-4 flex items-center gap-2 uppercase tracking-[0.1em]">
               <AlertCircle size={17} /> {t('dash.reval_queue')}
            </h3>
            <p className="text-xs text-rose-300/60 mb-6 leading-relaxed">{t('dash.reval_subtitle')}</p>
            <div className="space-y-3">
              {revalidationQueue.map((row, idx) => (
                <div key={`${row.chip_id}-${row.run_id}-${row.execution_id}-${idx}`} className="bg-rose-950/20 border border-rose-900/40 p-3 rounded-lg">
                  <div className="text-[11px] font-bold text-rose-400 mb-1">{row.chip_id} / {row.run_id}</div>
                  <div className="text-[10px] text-rose-600 font-medium italic">{row.execution_id} · {row.verdict}</div>
                </div>
              ))}
              {revalidationQueue.length === 0 && (
                <div className="text-[11px] text-slate-500">{t('qa_dashboard.no_revalidation')}</div>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 relative overflow-hidden group">
        <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity pointer-events-none">
          <Database size={120} className="text-indigo-500" />
        </div>
        <h2 className="text-xl font-bold text-white mb-2 inline-flex items-center gap-2">
          {t('dash.inventory_audit')}
          <HintTooltip
            title={t('qa_dashboard.hint_inventory_audit_title')}
            lines={[
              t('qa_dashboard.hint_inventory_audit_1'),
              t('qa_dashboard.hint_inventory_audit_2'),
              t('qa_dashboard.hint_inventory_audit_3'),
            ]}
            align="right"
          />
        </h2>
        <p className="text-slate-400 text-sm max-w-xl leading-relaxed">
          {t('dash.inventory_desc')} ({t('qa_dashboard.pass')}: {passCount}, {t('qa_dashboard.warn')}: {warnCount}, {t('qa_dashboard.blocked')}: {blockedCount})
        </p>
      </div>
    </div>
  )
}
