import HeaderIcon from '../components/HeaderIcon'
import { usePackageBuildIndex } from '../hooks/usePackageBuildIndex'
import { Link, useLocation, useParams } from 'react-router-dom'
import { useEffect, useMemo, useState } from 'react'
import { useTranslation } from '../contexts/i18n'

type OperatingMode = 'solo_eval' | 'team_project' | 'enterprise_site'

function parseMode(search: string): OperatingMode {
  const params = new URLSearchParams(search)
  const candidate = params.get('mode')
  if (candidate === 'solo_eval' || candidate === 'enterprise_site') return candidate
  return 'team_project'
}

export default function PackageBuildDetail() {
  const { t } = useTranslation()
  const location = useLocation()
  const mode = useMemo(() => parseMode(location.search), [location.search])
  const { buildId = '' } = useParams<{ buildId: string }>()
  const { data, loading, error } = usePackageBuildIndex()

  const [isCustomerPackage, setIsCustomerPackage] = useState(false)

  // NOTE: Package Builds page and detail subpages are STRICTLY available in the development repository only.
  // In any customer release package (where isCustomerPackage is true or import.meta.env.DEV is false),
  // this page must fail-closed and block access entirely to prevent vendor IP leakage.
  useEffect(() => {
    fetch('/api/intake/options')
      .then((res) => {
        if (!res.ok) throw new Error()
        return res.json()
      })
      .then((data) => {
        if (data?.is_customer_package) {
          setIsCustomerPackage(true)
        }
      })
      .catch(() => {
        // Fallback
      })
  }, [])

  if (!import.meta.env.DEV || isCustomerPackage) {
    return (
      <div className="rounded-xl border border-amber-900/40 bg-amber-950/30 p-6 text-sm text-amber-200">
        {t('package_build.dev_only')} (ONLY available in development repository)
      </div>
    )
  }

  const row = useMemo(() => {
    return (data?.builds ?? []).find((x) => x.build_id === buildId) ?? null
  }, [data, buildId])

  if (loading) return <div className="rounded-xl border border-slate-800 bg-slate-900 p-6 text-sm text-slate-300">{t('common.loading')}</div>
  if (error) return <div className="rounded-xl border border-rose-900/40 bg-rose-950/30 p-6 text-sm text-rose-200">{t('common.error')}: {error}</div>
  if (!row) return <div className="rounded-xl border border-slate-800 bg-slate-900 p-6 text-sm text-slate-300">{t('package_build.not_found')}</div>

  return (
    <div className="space-y-5">
      <section className="rounded-xl border border-slate-800 bg-slate-900/60 p-5">
        <div className="flex items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight text-white inline-flex items-center gap-2">
              <HeaderIcon name="package" className="text-cyan-300" size={20} />
              {t('package_build.detail_title')}
            </h1>
            <p className="text-sm text-slate-400">{row.build_id}</p>
          </div>
          <Link
            to={`/package-builds?mode=${mode}`}
            className="inline-flex items-center gap-2 rounded-md border border-cyan-700/50 bg-cyan-900/20 px-3 py-1.5 text-xs text-cyan-200 hover:bg-cyan-900/40"
            aria-label={t('package_build.location_icon_aria')}
            title={t('package_build.location_icon_aria')}
          >
            <HeaderIcon name="route" size={14} className="text-cyan-200" />
            {t('package_build.location_icon_label')}
          </Link>
        </div>
      </section>

      <section className="rounded-xl border border-slate-800 bg-slate-900 p-4">
        <div className="grid gap-2 text-xs font-mono text-slate-300">
          <div>{t('package_build.col_time')}: {row.build_timestamp}</div>
          <div>{t('package_build.col_variant')}: {row.package_variant}</div>
          <div>{t('package_build.col_runtime_mode')}: {row.runtime_delivery_mode}</div>
          <div>{t('package_build.col_source_mode')}: {row.source_disclosure_mode}</div>
          <div>{t('package_build.col_artifact_class')}: {row.release_artifact_class}</div>
          <div>{t('package_build.col_verdict')}: <span className={row.build_verdict === 'PASS' ? 'text-emerald-300' : 'text-rose-300'}>{row.build_verdict}</span></div>
          <div>{t('package_build.col_release_claim')}: {row.release_claim}</div>
        </div>
      </section>

      <section className="rounded-xl border border-slate-800 bg-slate-900 p-4">
        <h2 className="text-sm font-semibold text-slate-100 mb-3">{t('package_build.detail_refs')}</h2>
        <div className="space-y-2 text-xs font-mono">
          <div className="text-slate-300">package_artifact_ref: <span className="text-cyan-300">{row.package_artifact_ref}</span></div>
          <div className="text-slate-300">audit_record_ref: <span className="text-cyan-300">{row.audit_record_ref}</span></div>
          <div className="text-slate-300">customer_safe_manifest_ref: <span className="text-cyan-300">{row.customer_safe_manifest_ref}</span></div>
        </div>
      </section>

      <section className="rounded-xl border border-slate-800 bg-slate-900 p-4">
        <h2 className="text-sm font-semibold text-slate-100 mb-3">{t('package_build.detail_gates')}</h2>
        <div className="grid gap-2 text-xs font-mono text-slate-300">
          <div>source_leak_scan_verdict: {row.source_leak_scan_verdict}</div>
          <div>internal_path_leak_scan_verdict: {row.internal_path_leak_scan_verdict}</div>
          <div>signature_verdict: {row.signature_verdict}</div>
          <div>extract_validation_verdict: {row.extract_validation_verdict}</div>
        </div>
      </section>
    </div>
  )
}
