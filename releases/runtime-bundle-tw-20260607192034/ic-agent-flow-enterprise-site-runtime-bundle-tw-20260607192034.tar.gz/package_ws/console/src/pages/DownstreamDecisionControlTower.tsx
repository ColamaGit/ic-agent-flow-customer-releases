import { AlertTriangle, CheckCircle2, Clock3, FileSearch2 } from 'lucide-react'
import { useEffect, useMemo, useState } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import Badge from '../components/Badge'
import FileFamilyExplorer, { type FileFamilyEntry } from '../components/FileFamilyExplorer'
import HeaderIcon from '../components/HeaderIcon'
import { buildDownstreamDecisionActionEntrypoint } from '../lib/downstreamDecisionEntrypoint'
import { resolveDecisionStatusFromFormalQueue } from '../lib/downstreamDecisionQueue'
import { buildDecisionState } from '../lib/downstreamDecisionStatus'
import { useTranslation } from '../contexts/i18n'
import { parseMode } from '../hooks/evidenceSummary'
import { useProductionRunsInventory, type ProductionRunExecutionFile } from '../hooks/useProductionRunsInventory'

type GateFamily =
  | 'ALL_DOWNSTREAM_GATES'
  | 'QA_TRUST_GATE'
  | 'SILICON_CONTRACT_BINDER'
  | 'SIGNOFF_READINESS_GATE'
  | 'TAPEOUT_PACKAGE_GATE'
  | 'SILICON_FEEDBACK_GATE'
  | 'SKILL_PACK_REUSE_GATE'
  | 'KNOWLEDGE_ECOSYSTEM_GATE'

type ReadinessStatus = 'EVIDENCE_READY' | 'WARN' | 'BLOCKED'
type DecisionStatus = 'PENDING' | 'APPROVED' | 'REJECTED' | 'HOLD' | 'REQUEST_MORE_EVIDENCE'

type ExpectedFile = {
  path: string
  required: boolean
}

type DownstreamGate = {
  family: GateFamily
  labelKey: string
  prdRef: string
  formalDecisionRef: string
  requiredRole: string
  owner: string
  domainRoute: string
  expectedFiles: ExpectedFile[]
  allowedActions: string[]
  nextAction: string
}

const gateFamilies: GateFamily[] = [
  'ALL_DOWNSTREAM_GATES',
  'QA_TRUST_GATE',
  'SILICON_CONTRACT_BINDER',
  'SIGNOFF_READINESS_GATE',
  'TAPEOUT_PACKAGE_GATE',
  'SILICON_FEEDBACK_GATE',
  'SKILL_PACK_REUSE_GATE',
  'KNOWLEDGE_ECOSYSTEM_GATE',
]

const downstreamGates: DownstreamGate[] = [
  {
    family: 'QA_TRUST_GATE',
    labelKey: 'downstream_decisions.gate.qa_trust',
    prdRef: 'PRD v1.4',
    formalDecisionRef: 'governance://decision/downstream/qa-trust',
    requiredRole: 'QA Owner',
    owner: 'qa_authority',
    domainRoute: '/qa-trust',
    expectedFiles: [
      { path: 'dashboard_objects/readiness_manifest.json', required: true },
      { path: 'reports/readiness_report_manifest.v0.2.json', required: true },
      { path: 'reports/readiness_report_mapping.v0.2.json', required: true },
    ],
    allowedActions: ['approve_trust_gate', 'hold_for_evidence', 'request_more_evidence', 'reject_claim_scope'],
    nextAction: 'review evidence quality, scenario validity, and claim boundary',
  },
  {
    family: 'SILICON_CONTRACT_BINDER',
    labelKey: 'downstream_decisions.gate.silicon_contract',
    prdRef: 'PRD v1.3',
    formalDecisionRef: 'governance://decision/downstream/silicon-contract',
    requiredRole: 'Release Authority',
    owner: 'release_authority',
    domainRoute: '/authority-plane',
    expectedFiles: [
      { path: 'subject_binding/capability_contract_index.v0.1.json', required: true },
      { path: 'subject_binding/decision_package.v0.1.json', required: true },
      { path: 'subject_binding/re_entry_record.v0.1.json', required: true },
    ],
    allowedActions: ['sign_contract_section', 'block_release', 'request_more_evidence'],
    nextAction: 'bind trusted evidence into controlled release authority chain',
  },
  {
    family: 'SIGNOFF_READINESS_GATE',
    labelKey: 'downstream_decisions.gate.signoff',
    prdRef: 'PRD v1.13',
    formalDecisionRef: 'governance://decision/downstream/signoff-readiness',
    requiredRole: 'Signoff Owner',
    owner: 'signoff_owner',
    domainRoute: '/signoff',
    expectedFiles: [
      { path: 'dashboard_objects/signoff_domain_matrix.json', required: true },
      { path: 'dashboard_objects/signoff_evidence_manifest.json', required: true },
      { path: 'dashboard_objects/final_tapeout_readiness_record.json', required: true },
      { path: 'reports/signoff_report_manifest.v1.13.json', required: true },
    ],
    allowedActions: ['approve_with_waivers', 'hold', 'reject', 'request_more_evidence'],
    nextAction: 'adjudicate signoff closure and tapeout-readiness evidence',
  },
  {
    family: 'TAPEOUT_PACKAGE_GATE',
    labelKey: 'downstream_decisions.gate.tapeout',
    prdRef: 'PRD v1.14',
    formalDecisionRef: 'governance://decision/downstream/tapeout-package',
    requiredRole: 'Tapeout Owner',
    owner: 'tapeout_owner',
    domainRoute: '/tapeout-package',
    expectedFiles: [
      { path: 'dashboard_objects/tapeout_package_manifest.json', required: true },
      { path: 'dashboard_objects/tapeout_readiness_record.draft.json', required: true },
      { path: 'dashboard_objects/tapeout_decision_inbox.json', required: true },
      { path: 'reports/tapeout_package_report_manifest.v1.14.json', required: true },
    ],
    allowedActions: ['approve_handoff_package', 'hold', 'reject'],
    nextAction: 'review package assembly, integrity, handoff, and foundry-facing boundary',
  },
  {
    family: 'SILICON_FEEDBACK_GATE',
    labelKey: 'downstream_decisions.gate.silicon_feedback',
    prdRef: 'PRD v1.15',
    formalDecisionRef: 'governance://decision/downstream/silicon-feedback',
    requiredRole: 'Bring-up Owner',
    owner: 'bringup_owner',
    domainRoute: '/silicon-feedback',
    expectedFiles: [
      { path: 'dashboard_objects/v115_bringup_plan.json', required: true },
      { path: 'dashboard_objects/v115_silicon_feedback_decision_inbox.json', required: true },
      { path: 'dashboard_objects/v115_post_tapeout_audit_bundle.json', required: true },
      { path: 'reports/silicon_feedback_report_manifest.v1.15.json', required: false },
    ],
    allowedActions: ['accept_errata', 'request_root_cause', 'approve_eco_candidate'],
    nextAction: 'review bring-up, mismatch, errata, ECO, and feedback-derived evidence',
  },
  {
    family: 'SKILL_PACK_REUSE_GATE',
    labelKey: 'downstream_decisions.gate.skill_pack',
    prdRef: 'PRD v1.9',
    formalDecisionRef: 'governance://decision/downstream/skill-pack-reuse',
    requiredRole: 'Skill Owner',
    owner: 'skill_owner',
    domainRoute: '/knowledge-assets',
    expectedFiles: [
      { path: 'skill_usage/skill_usage_summary.md', required: true },
      { path: 'skill_usage/skill_invocation_record.jsonl', required: true },
      { path: 'reports/skill_backflow_report_manifest.v1.9.json', required: false },
    ],
    allowedActions: ['promote_skill', 'reject_skill', 'mark_local_only'],
    nextAction: 'decide whether downstream evidence creates a reusable governed skill candidate',
  },
  {
    family: 'KNOWLEDGE_ECOSYSTEM_GATE',
    labelKey: 'downstream_decisions.gate.knowledge',
    prdRef: 'PRD v1.1 / PRD v1.2',
    formalDecisionRef: 'governance://decision/downstream/knowledge-ecosystem',
    requiredRole: 'Governance Owner',
    owner: 'knowledge_governance_owner',
    domainRoute: '/knowledge-assets',
    expectedFiles: [
      { path: 'reports/knowledge_backflow_report_manifest.v1.1_v1.2.json', required: true },
      { path: 'reports/knowledge_backflow_report_mapping.v1.1_v1.2.json', required: true },
      { path: 'reports/knowledge_backflow_report_action_items.v1.1_v1.2.json', required: true },
    ],
    allowedActions: ['adopt', 'defer', 'reject', 'local_override', 'share_back_review'],
    nextAction: 'classify candidate asset scope and ecosystem boundary disposition',
  },
]

function normalizePath(path: string) {
  const parts = path.split('/')
  if (parts.length > 0) parts[0] = parts[0].replace(/^\d+_/, '')
  return parts.join('/')
}

function gatePreviewCandidates(expectedPath: string) {
  const normalized = normalizePath(expectedPath)
  const candidates = new Set<string>([normalized, `${normalized}.md`])
  const lastSlash = normalized.lastIndexOf('/')
  const dir = lastSlash >= 0 ? normalized.slice(0, lastSlash) : ''
  const fileName = lastSlash >= 0 ? normalized.slice(lastSlash + 1) : normalized
  const dotIndex = fileName.lastIndexOf('.')
  if (dotIndex > 0) {
    const stem = fileName.slice(0, dotIndex)
    const mdName = `${stem}.md`
    candidates.add(dir ? `${dir}/${mdName}` : mdName)
  }
  return [...candidates]
}

function gateGroupLabel(gate: DownstreamGate, translate: (key: string) => string) {
  return translate(gate.labelKey).replace(/\s*\/\s*/g, ' · ')
}

function buildGatePreviewFiles(gate: DownstreamGate, files: ProductionRunExecutionFile[], translate: (key: string) => string): FileFamilyEntry[] {
  const groupLabel = gateGroupLabel(gate, translate)
  const candidatePaths = new Set<string>()
  gate.expectedFiles.forEach((expected) => {
    gatePreviewCandidates(expected.path).forEach((candidate) => candidatePaths.add(candidate))
  })

  const matchedFiles = files
    .filter((file) => file.kind === 'file' && candidatePaths.has(normalizePath(file.relative_path)))
    .map((file) => ({
      relative_path: `${groupLabel}/${normalizePath(file.relative_path)}`,
      kind: 'file' as const,
      preview_text: file.preview_text ?? null,
      size_bytes: file.size_bytes,
    }))
    .sort((a, b) => a.relative_path.localeCompare(b.relative_path))

  const present = gate.expectedFiles.filter((expected) => candidatePaths.has(expected.path)).map((expected) => expected.path)
  const missing = gate.expectedFiles.filter((expected) => !present.includes(expected.path)).map((expected) => expected.path)
  const summaryText = [
    `Gate: ${translate(gate.labelKey)}`,
    `PRD: ${gate.prdRef}`,
    `Present: ${present.length}/${gate.expectedFiles.length}`,
    `Missing: ${missing.length}`,
    '',
    present.length > 0 ? `Present files:\n- ${present.join('\n- ')}` : 'Present files:\n- none',
    '',
    missing.length > 0 ? `Missing files:\n- ${missing.join('\n- ')}` : 'Missing files:\n- none',
    '',
    `Use the tree below to inspect any matched JSON or .md companion file before making a decision.`,
  ].join('\n')

  return [
    {
      relative_path: `${groupLabel}/__gate_summary__.md`,
      kind: 'file',
      preview_text: summaryText,
      size_bytes: 0,
    },
    ...matchedFiles,
  ]
}

function buildGatePreviewFileList(
  gates: DownstreamGate[],
  files: ProductionRunExecutionFile[],
  translate: (key: string) => string,
): FileFamilyEntry[] {
  return gates.flatMap((gate) => buildGatePreviewFiles(gate, files, translate))
}

function findFile(files: ProductionRunExecutionFile[], logicalPath: string) {
  return files.find((file) => file.kind === 'file' && normalizePath(file.relative_path) === logicalPath)
}

function evaluateGate(
  gate: DownstreamGate,
  files: ProductionRunExecutionFile[],
  decisionStatusOverride?: DecisionStatus | null,
) {
  const present = gate.expectedFiles.filter((expected) => findFile(files, expected.path)).map((expected) => expected.path)
  const missing = gate.expectedFiles.filter((expected) => !findFile(files, expected.path)).map((expected) => expected.path)
  const requiredMissing = gate.expectedFiles.filter((expected) => expected.required && !findFile(files, expected.path)).map((expected) => expected.path)
  const optionalMissing = gate.expectedFiles.filter((expected) => !expected.required && !findFile(files, expected.path)).map((expected) => expected.path)
  const stale = files
    .filter((file) => file.kind === 'file' && /superseded|stale/i.test(file.relative_path))
    .map((file) => normalizePath(file.relative_path))
  const readinessStatus: ReadinessStatus = requiredMissing.length > 0 ? 'BLOCKED' : optionalMissing.length > 0 ? 'WARN' : 'EVIDENCE_READY'
  const decisionStatus: DecisionStatus = decisionStatusOverride ?? resolveDecisionStatusFromFormalQueue(gate, files)
  const statusState = buildDecisionState({
    readinessStatus,
    decisionStatus,
    backendBindingState: 'UNBOUND',
    liveSubmissionEnabled: false,
  })
  return { present, missing, requiredMissing, optionalMissing, stale, readinessStatus, decisionStatus, statusState, decisionRequired: decisionStatus !== 'APPROVED' }
}

function statusIcon(status: ReadinessStatus) {
  if (status === 'EVIDENCE_READY') return <CheckCircle2 className="h-4 w-4 text-emerald-300" />
  if (status === 'WARN') return <Clock3 className="h-4 w-4 text-amber-300" />
  return <AlertTriangle className="h-4 w-4 text-rose-300" />
}

export default function DownstreamDecisionControlTower() {
  const { t } = useTranslation()
  const location = useLocation()
  const navigate = useNavigate()
  const mode = useMemo(() => parseMode(location.search), [location.search])
  const params = useMemo(() => new URLSearchParams(location.search), [location.search])
  const { data, loading, error, reload } = useProductionRunsInventory()

  const chips = data?.chips ?? []
  const selectedChip = params.get('chip') || chips[0]?.chip_id || ''
  const chip = chips.find((candidate) => candidate.chip_id === selectedChip || candidate.source_dir === selectedChip) ?? chips[0]
  const selectedRun = params.get('run') || chip?.runs[0]?.run_id || ''
  const run = chip?.runs.find((candidate) => candidate.run_id === selectedRun) ?? chip?.runs[0]
  const selectedExecution = params.get('execution') || params.get('date_time') || run?.executions[0]?.execution_id || ''
  const execution = run?.executions.find((candidate) => candidate.execution_id === selectedExecution) ?? run?.executions[0]
  const selectedGate = (params.get('gate') as GateFamily | null) || 'ALL_DOWNSTREAM_GATES'
  const visibleGates = selectedGate === 'ALL_DOWNSTREAM_GATES' ? downstreamGates : downstreamGates.filter((gate) => gate.family === selectedGate)
  const selectedGateRecord = downstreamGates.find((gate) => gate.family === selectedGate) ?? downstreamGates[0]
  const [selectedActionName, setSelectedActionName] = useState(() => selectedGateRecord.allowedActions[0] ?? '')
  const [entrypointPreview, setEntrypointPreview] = useState<ReturnType<typeof buildDownstreamDecisionActionEntrypoint> | null>(null)
  const [submissionRationale, setSubmissionRationale] = useState('')
  const [submissionFeedback, setSubmissionFeedback] = useState('')
  const [submissionInFlight, setSubmissionInFlight] = useState(false)
  const [decisionStatusOverrides, setDecisionStatusOverrides] = useState<Record<string, DecisionStatus>>({})
  const [previewExpanded, setPreviewExpanded] = useState(false)

  function updateParam(key: string, value: string) {
    const next = new URLSearchParams(location.search)
    next.set('mode', mode)
    next.set(key, value)
    if (key === 'chip') {
      const nextChip = chips.find((candidate) => candidate.chip_id === value || candidate.source_dir === value)
      next.set('run', nextChip?.runs[0]?.run_id || '')
      next.set('execution', nextChip?.runs[0]?.executions[0]?.execution_id || '')
    }
    if (key === 'run') {
      const nextRun = chip?.runs.find((candidate) => candidate.run_id === value)
      next.set('execution', nextRun?.executions[0]?.execution_id || '')
    }
    navigate({ pathname: location.pathname, search: next.toString() })
  }

  const rows = visibleGates.map((gate) => ({
    gate,
    evaluation: evaluateGate(gate, execution?.files ?? [], decisionStatusOverrides[gate.formalDecisionRef] ?? null),
  }))
  const selectedEvaluation = evaluateGate(
    selectedGateRecord,
    execution?.files ?? [],
    decisionStatusOverrides[selectedGateRecord.formalDecisionRef] ?? null,
  )
  const previewGateScope = useMemo(
    () => (selectedGate === 'ALL_DOWNSTREAM_GATES' ? downstreamGates : [selectedGateRecord]),
    [selectedGate, selectedGateRecord],
  )
  const selectedGatePreviewFiles = useMemo(
    () => buildGatePreviewFileList(previewGateScope, execution?.files ?? [], t),
    [execution?.files, previewGateScope, t],
  )
  const selectedEvidenceKey = selectedEvaluation.present.join('|')
  const blockedCount = rows.filter((row) => row.evaluation.readinessStatus === 'BLOCKED').length
  const warnCount = rows.filter((row) => row.evaluation.readinessStatus === 'WARN').length
  const readyCount = rows.filter((row) => row.evaluation.readinessStatus === 'EVIDENCE_READY').length
  const selectedGateAllowedActions = selectedGateRecord.allowedActions
  const targetObjectRef = `icaf://artifact/${selectedGateRecord.family.toLowerCase()}`
  const formalObjectRef = `icaf://artifact/${selectedGateRecord.family.toLowerCase()}/formal-object.json`
  const selectedAction = selectedGateAllowedActions.includes(selectedActionName)
    ? selectedActionName
    : (selectedGateAllowedActions[0] || '')
  const localActionEntrypoint = buildDownstreamDecisionActionEntrypoint({
    sessionId: 'downstream-session-preview',
    actorId: 'local-agent',
    role: selectedGateRecord.requiredRole,
    chipId: chip?.chip_id ?? '',
    runId: run?.run_id ?? '',
    dateTime: execution?.execution_id ?? '',
    gateFamily: selectedGateRecord.family,
    actionName: selectedAction,
    targetObjectRefs: [targetObjectRef],
    sourceEvidenceRefs: selectedEvidenceKey ? selectedEvidenceKey.split('|').map((path) => `icaf://artifact/${path}`) : [],
    formalObjectRefs: [formalObjectRef],
    readinessStatus: selectedEvaluation.readinessStatus,
    decisionStatus: selectedEvaluation.decisionStatus,
  })
  const actionEntrypoint = entrypointPreview ?? localActionEntrypoint
  const actionRequest = actionEntrypoint.actionRequest ?? null
  const selectedStatusState = buildDecisionState({
    readinessStatus: selectedEvaluation.readinessStatus,
    decisionStatus: selectedEvaluation.decisionStatus,
    backendBindingState: actionEntrypoint.backendBindingState,
    liveSubmissionEnabled: actionEntrypoint.liveSubmissionEnabled,
  })

  useEffect(() => {
    const runDir = execution?.resolved_root ?? ''
    if (!runDir) {
      setEntrypointPreview(null)
      return
    }

    const controller = new AbortController()
    const payload = {
      run_dir: runDir,
      session_id: 'downstream-session-preview',
      actor_id: 'local-agent',
      role: selectedGateRecord.requiredRole,
      action_name: selectedAction,
      chip_id: chip?.chip_id ?? '',
      run_id: run?.run_id ?? '',
      date_time: execution?.execution_id ?? '',
      gate_family: selectedGateRecord.family,
      required_role: selectedGateRecord.requiredRole,
      allowed_actions: selectedGateAllowedActions,
      decision_context_ref: localActionEntrypoint.decisionContextRef,
      target_object_refs: [targetObjectRef],
      source_evidence_refs: selectedEvidenceKey ? selectedEvidenceKey.split('|').map((path) => `icaf://artifact/${path}`) : [],
      formal_object_refs: [formalObjectRef],
      readiness_status: selectedEvaluation.readinessStatus,
      decision_status: selectedEvaluation.decisionStatus,
    }

    setEntrypointPreview(null)
    void (async () => {
      try {
        const response = await fetch('/api/console/downstream-decision/entrypoint', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
          signal: controller.signal,
        })
        const result = await response.json()
        if (!response.ok) {
          throw new Error(result?.error ?? `http_${response.status}`)
        }
        if (!controller.signal.aborted) {
          setEntrypointPreview(result)
        }
      } catch {
        if (!controller.signal.aborted) {
          setEntrypointPreview(null)
        }
      }
    })()

    return () => controller.abort()
  }, [
    chip?.chip_id,
    execution?.execution_id,
    execution?.resolved_root,
    localActionEntrypoint.decisionContextRef,
    run?.run_id,
    selectedAction,
    selectedEvaluation.decisionStatus,
    selectedEvaluation.readinessStatus,
    selectedGateRecord.family,
    selectedGateRecord.requiredRole,
    selectedGateAllowedActions,
    selectedEvidenceKey,
    targetObjectRef,
    formalObjectRef,
  ])

  async function submitDownstreamDecisionAction() {
    if (!actionEntrypoint.liveSubmissionEnabled || submissionInFlight) return
    const runDir = execution?.resolved_root ?? ''
    if (!runDir) return
    setSubmissionInFlight(true)
    setSubmissionFeedback('')
    try {
      const response = await fetch('/api/console/downstream-decision/action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          run_dir: runDir,
          package_mode: mode,
          session_id: actionEntrypoint.actionRequest.session_id,
          actor_id: actionEntrypoint.actionRequest.actor_id,
          role: actionEntrypoint.actionRequest.role,
          action_name: actionEntrypoint.actionRequest.action_name,
          chip_id: chip?.chip_id ?? '',
          run_id: run?.run_id ?? '',
          date_time: execution?.execution_id ?? '',
          gate_family: selectedGateRecord.family,
          required_role: selectedGateRecord.requiredRole,
          allowed_actions: selectedGateAllowedActions,
          decision_context_ref: actionEntrypoint.decisionContextRef,
          target_object_refs: actionEntrypoint.actionRequest.target_object_refs,
          source_evidence_refs: actionEntrypoint.actionRequest.source_evidence_refs,
          formal_object_refs: actionEntrypoint.formalObjectRefs,
          readiness_status: actionEntrypoint.readinessDimension,
          decision_status: actionEntrypoint.decisionDimension,
          decision_rationale: submissionRationale,
        }),
      })
      const result = await response.json()
      if (!response.ok) {
        throw new Error(result?.error ?? `http_${response.status}`)
      }
      if (result?.decision_write?.formal_decision_ref && result?.decision_write?.decision_status_after) {
        setDecisionStatusOverrides((current) => ({
          ...current,
          [result.decision_write.formal_decision_ref]: result.decision_write.decision_status_after,
        }))
      }
      reload()
      setSubmissionFeedback(`${t('downstream_decisions.form_submission_success')}: ${result?.bundle?.result?.result_status ?? 'OK'}`)
    } catch (error) {
      const msg = error instanceof Error ? error.message : 'unknown_error'
      setSubmissionFeedback(`${t('downstream_decisions.form_submission_error')}: ${msg}`)
    } finally {
      setSubmissionInFlight(false)
    }
  }

  if (loading) return <div className="p-6 text-slate-500">{t('common.loading')}</div>
  if (error) return <div className="p-6 text-rose-400">{t('common.error')}: {error}</div>

  return (
    <div className="space-y-5">
      <section className="rounded-2xl border border-slate-800 bg-[radial-gradient(circle_at_top_left,rgba(34,211,238,0.16),transparent_32%),linear-gradient(135deg,rgba(15,23,42,0.95),rgba(2,6,23,0.92))] p-5 shadow-xl shadow-slate-950/30">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <div className="flex flex-col items-start gap-3">
              <div className="inline-flex items-center gap-2 rounded-full border border-cyan-500/30 bg-cyan-500/10 px-3 py-1 text-xs font-semibold uppercase tracking-[0.18em] text-cyan-200">
                <HeaderIcon name="decision" size={14} />
                {t('downstream_decisions.section_tag')}
              </div>
              <h1 className="text-3xl font-semibold tracking-tight text-white">{t('downstream_decisions.title')}</h1>
            </div>
            <p className="mt-2 max-w-4xl text-sm leading-6 text-slate-300">{t('downstream_decisions.subtitle')}</p>
          </div>
          <div className="grid min-w-[260px] gap-2 rounded-xl border border-slate-700 bg-slate-950/70 p-3 text-xs text-slate-300">
            <div className="flex items-center justify-between"><span>{t('downstream_decisions.evidence_ready')}</span><span className="font-mono text-emerald-300">{readyCount}</span></div>
            <div className="flex items-center justify-between"><span>{t('downstream_decisions.warn')}</span><span className="font-mono text-amber-300">{warnCount}</span></div>
            <div className="flex items-center justify-between"><span>{t('downstream_decisions.blocked')}</span><span className="font-mono text-rose-300">{blockedCount}</span></div>
          </div>
        </div>
      </section>

      <section className="grid gap-3 rounded-xl border border-slate-800 bg-slate-900/70 p-4 md:grid-cols-4">
        <label className="space-y-1 text-xs text-slate-400">
          <span>{t('downstream_decisions.selector.chip')}</span>
          <select className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-slate-100" value={chip?.chip_id ?? ''} onChange={(event) => updateParam('chip', event.target.value)}>
            {chips.map((candidate) => <option key={candidate.chip_id} value={candidate.chip_id}>{candidate.chip_id}</option>)}
          </select>
        </label>
        <label className="space-y-1 text-xs text-slate-400">
          <span>{t('downstream_decisions.selector.run')}</span>
          <select className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-slate-100" value={run?.run_id ?? ''} onChange={(event) => updateParam('run', event.target.value)}>
            {(chip?.runs ?? []).map((candidate) => <option key={candidate.run_id} value={candidate.run_id}>{candidate.run_id}</option>)}
          </select>
        </label>
        <label className="space-y-1 text-xs text-slate-400">
          <span>{t('downstream_decisions.selector.execution')}</span>
          <select className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-slate-100" value={execution?.execution_id ?? ''} onChange={(event) => updateParam('execution', event.target.value)}>
            {(run?.executions ?? []).map((candidate) => <option key={candidate.execution_id} value={candidate.execution_id}>{candidate.execution_id}</option>)}
          </select>
        </label>
        <label className="space-y-1 text-xs text-slate-400">
          <span>{t('downstream_decisions.selector.gate')}</span>
          <select className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-slate-100" value={selectedGate} onChange={(event) => updateParam('gate', event.target.value)}>
            {gateFamilies.map((family) => <option key={family} value={family}>{t(`downstream_decisions.family.${family}`)}</option>)}
          </select>
        </label>
      </section>

      <section className="overflow-hidden rounded-xl border border-slate-800 bg-slate-950/80">
        <div className="border-b border-slate-800 px-4 py-3">
            <h2 className="text-base font-semibold text-white">{t('downstream_decisions.board_title')}</h2>
            <p className="text-xs text-slate-500">{t('downstream_decisions.board_note')}</p>
            <p className="mt-1 text-xs text-cyan-200/90">{t('downstream_decisions.board_help')}</p>
          </div>
        <div className="overflow-x-auto">
          <table className="min-w-[1180px] w-full text-left text-sm">
            <thead className="bg-slate-900/80 text-xs uppercase tracking-[0.12em] text-slate-500">
              <tr>
                <th className="px-4 py-3">{t('downstream_decisions.col_gate')}</th>
                <th className="px-4 py-3">
                  <span title={t('downstream_decisions.evidence_tooltip')}>{t('downstream_decisions.col_evidence_status')}</span>
                </th>
                <th className="px-4 py-3">
                  <span title={t('downstream_decisions.decision_tooltip')}>{t('downstream_decisions.col_decision_status')}</span>
                </th>
                <th className="px-4 py-3">{t('downstream_decisions.col_expected')}</th>
                <th className="px-4 py-3">{t('downstream_decisions.col_missing')}</th>
                <th className="px-4 py-3">{t('downstream_decisions.col_stale')}</th>
                <th className="px-4 py-3">{t('downstream_decisions.col_role')}</th>
                <th className="px-4 py-3">{t('downstream_decisions.col_next')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {rows.map(({ gate, evaluation }) => {
                const q = `mode=${mode}&chip=${encodeURIComponent(chip?.chip_id ?? '')}&run=${encodeURIComponent(run?.run_id ?? '')}&execution=${encodeURIComponent(execution?.execution_id ?? '')}`
                return (
                  <tr key={gate.family} className="align-top hover:bg-slate-900/40">
                    <td className="px-4 py-4">
                      <div className="font-semibold text-slate-100">{t(gate.labelKey)}</div>
                      <div className="mt-1 font-mono text-xs text-cyan-300">{gate.prdRef}</div>
                      <Link className="mt-2 inline-flex items-center gap-1 text-xs text-blue-300 hover:text-blue-200" to={`${gate.domainRoute}?${q}`}>
                        <FileSearch2 size={13} /> {t('downstream_decisions.open_domain_page')}
                      </Link>
                    </td>
                    <td className="px-4 py-4">
                      <div className="inline-flex items-center gap-2">
                        {statusIcon(evaluation.readinessStatus)}
                        <Badge label={evaluation.statusState.evidence_status} />
                      </div>
                      <div className="mt-2 text-xs text-slate-500">{t('downstream_decisions.evidence_ready_hint')}</div>
                      <div className="mt-2 text-xs text-slate-500">gate_status: <span className="font-mono text-slate-300">{evaluation.statusState.gate_status}</span></div>
                    </td>
                    <td className="px-4 py-4">
                      <Badge label={evaluation.statusState.decision_status} />
                      <div className="mt-2 text-xs text-slate-500">{evaluation.decisionRequired ? t('downstream_decisions.decision_required') : t('downstream_decisions.no_decision_required')}</div>
                    </td>
                    <td className="px-4 py-4">
                      <div className="font-mono text-xs text-emerald-300">{evaluation.present.length} / {gate.expectedFiles.length}</div>
                      <div className="mt-2 space-y-1 text-xs text-slate-300">
                        {gate.expectedFiles.map((file) => <div key={file.path} className="break-all">{file.required ? '*' : '~'} {file.path}</div>)}
                      </div>
                    </td>
                    <td className="px-4 py-4">
                      <div className="font-mono text-xs text-rose-300">{evaluation.missing.length}</div>
                      <div className="mt-2 space-y-1 text-xs text-slate-300">
                        {evaluation.missing.length === 0 ? <span className="text-slate-500">{t('downstream_decisions.none')}</span> : evaluation.missing.map((file) => <div key={file} className="break-all">{file}</div>)}
                      </div>
                    </td>
                    <td className="px-4 py-4">
                      <div className="font-mono text-xs text-amber-300">{evaluation.stale.length}</div>
                      <div className="mt-2 space-y-1 text-xs text-slate-300">
                        {evaluation.stale.length === 0 ? <span className="text-slate-500">{t('downstream_decisions.none')}</span> : evaluation.stale.map((file) => <div key={file} className="break-all">{file}</div>)}
                      </div>
                    </td>
                    <td className="px-4 py-4">
                      <div className="text-sm text-slate-200">{gate.requiredRole}</div>
                      <div className="font-mono text-xs text-slate-500">{gate.owner}</div>
                    </td>
                    <td className="px-4 py-4 text-xs text-slate-300">{gate.nextAction}</td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </section>

      <section className="overflow-hidden rounded-xl border border-slate-800 bg-slate-950/80">
        <button
          type="button"
          className="flex w-full items-center justify-between gap-4 border-b border-slate-800 px-4 py-3 text-left hover:bg-slate-900/40"
          onClick={() => setPreviewExpanded((current) => !current)}
        >
          <div>
            <h2 className="text-base font-semibold text-white">
              {t('downstream_decisions.preview_section_title')}
            </h2>
            <p className="text-xs text-slate-500">{t('downstream_decisions.preview_section_note')}</p>
            <p className="mt-1 text-xs text-cyan-200/90">{t('downstream_decisions.preview_section_hint')}</p>
          </div>
          <div className="rounded-full border border-slate-700 bg-slate-900 px-3 py-1 text-xs font-semibold text-slate-200">
            {previewExpanded ? t('downstream_decisions.preview_section_collapse') : t('downstream_decisions.preview_section_expand')}
          </div>
        </button>
        {previewExpanded && (
          <div className="p-0">
            <FileFamilyExplorer
              title={t('downstream_decisions.preview_section_title')}
              subtitle={t('downstream_decisions.preview_section_subtitle')}
              files={selectedGatePreviewFiles}
              showHeader={false}
            />
          </div>
        )}
      </section>

      <section className="grid gap-4 lg:grid-cols-[1fr_0.9fr]">
        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
          <h2 className="text-base font-semibold text-white">{t('downstream_decisions.selected_title')}</h2>
          <div className="mt-3 grid gap-2 text-sm text-slate-300 sm:grid-cols-2">
            <div><span className="text-slate-500">chip_id:</span> <span className="font-mono text-cyan-200">{chip?.chip_id ?? 'N/A'}</span></div>
            <div><span className="text-slate-500">run_id:</span> <span className="font-mono text-cyan-200">{run?.run_id ?? 'N/A'}</span></div>
            <div><span className="text-slate-500">date_time:</span> <span className="font-mono text-cyan-200">{execution?.execution_id ?? 'N/A'}</span></div>
            <div><span className="text-slate-500">gate:</span> <span className="font-mono text-cyan-200">{selectedGate}</span></div>
          </div>
          <div className="mt-4 rounded-lg border border-slate-800 bg-slate-950 p-3">
            <div className="text-xs uppercase tracking-[0.12em] text-slate-500">{t('downstream_decisions.allowed_actions')}</div>
            <div className="mt-2 flex flex-wrap gap-2">
              {selectedGateAllowedActions.map((action) => <span key={action} className="rounded-full border border-slate-700 bg-slate-900 px-2 py-1 font-mono text-xs text-slate-200">{action}</span>)}
            </div>
          </div>
          <div className="mt-4 rounded-lg border border-cyan-900/50 bg-cyan-950/10 p-3">
            <div className="text-xs uppercase tracking-[0.12em] text-cyan-200">{t('downstream_decisions.entrypoint_title')}</div>
            <p className="mt-1 text-xs text-slate-400">{t('downstream_decisions.entrypoint_note')}</p>
            <div className="mt-3 grid gap-2 text-xs text-slate-300">
              <div><span className="text-slate-500">{t('downstream_decisions.entrypoint_backend_state')}:</span> <span className="font-mono text-cyan-200">{actionEntrypoint.backendBindingState}</span></div>
              <div><span className="text-slate-500">{t('downstream_decisions.entrypoint_decision_context')}:</span> <span className="font-mono text-cyan-200 break-all">{actionEntrypoint.decisionContextRef}</span></div>
              <div><span className="text-slate-500">{t('downstream_decisions.entrypoint_action_request')}:</span> <span className="font-mono text-cyan-200 break-all">{actionRequest?.action_request_id ?? t('downstream_decisions.entrypoint_action_request_missing')}</span></div>
              <div><span className="text-slate-500">{t('downstream_decisions.entrypoint_formal_objects')}:</span> <span className="font-mono text-cyan-200 break-all">{actionEntrypoint.formalObjectRefs.join(', ')}</span></div>
              <div><span className="text-slate-500">{t('downstream_decisions.entrypoint_readiness')}:</span> <span className="font-mono text-cyan-200">{actionEntrypoint.readinessDimension}</span></div>
              <div><span className="text-slate-500">{t('downstream_decisions.entrypoint_decision')}:</span> <span className="font-mono text-cyan-200">{actionEntrypoint.decisionDimension}</span></div>
              <div><span className="text-slate-500">evidence_status:</span> <span className="font-mono text-cyan-200">{selectedStatusState.evidence_status}</span></div>
              <div><span className="text-slate-500">gate_status:</span> <span className="font-mono text-cyan-200">{selectedStatusState.gate_status}</span></div>
              <div><span className="text-slate-500">decision_status:</span> <span className="font-mono text-cyan-200">{selectedStatusState.decision_status}</span></div>
              <div><span className="text-slate-500">authority_status:</span> <span className="font-mono text-cyan-200">{selectedStatusState.authority_status}</span></div>
            </div>
          </div>
        </div>

        <form
          className="rounded-xl border border-cyan-900/50 bg-cyan-950/10 p-4"
          onSubmit={async (event) => {
            event.preventDefault()
            await submitDownstreamDecisionAction()
          }}
        >
          <h2 className="inline-flex items-center gap-2 text-base font-semibold text-white"><HeaderIcon name="decision" size={16} />{t('downstream_decisions.form_title')}</h2>
          <p className="mt-1 text-xs text-slate-400">{t('downstream_decisions.form_note')}</p>
          <div className="mt-3 rounded-lg border border-cyan-900/50 bg-cyan-950/15 p-3 text-xs text-slate-300">
            <div className="flex items-center justify-between gap-2">
              <span>{t('downstream_decisions.entrypoint_backend_state')}</span>
              <span className="font-mono text-cyan-200">{actionEntrypoint.backendBindingState}</span>
            </div>
            <div className="mt-1 flex items-center justify-between gap-2">
              <span>{t('downstream_decisions.entrypoint_live_state')}</span>
              <span className="font-mono text-cyan-200">{actionEntrypoint.liveSubmissionEnabled ? t('downstream_decisions.form_enabled') : t('downstream_decisions.form_disabled')}</span>
            </div>
            <div className="mt-1 text-slate-400">{actionEntrypoint.submissionHint}</div>
          </div>
          <label className="mt-4 block space-y-1 text-xs text-slate-400">
            <span>{t('downstream_decisions.form_action')}</span>
            <select className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-slate-100" value={selectedAction} onChange={(event) => setSelectedActionName(event.target.value)}>
              {selectedGateAllowedActions.map((action) => <option key={action} value={action}>{action}</option>)}
            </select>
          </label>
          <label className="mt-3 block space-y-1 text-xs text-slate-400">
            <span>{t('downstream_decisions.form_rationale')}</span>
            <textarea
              className="min-h-24 w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-slate-100"
              placeholder={t('downstream_decisions.form_placeholder')}
              value={submissionRationale}
              onChange={(event) => setSubmissionRationale(event.target.value)}
            />
          </label>
          <div className="mt-3 rounded-lg border border-slate-800 bg-slate-950 p-3 text-xs text-slate-400">
            <div>{t('downstream_decisions.would_emit')}: <span className="font-mono text-cyan-200">downstream_decision_action_record.json</span></div>
            <div>{t('downstream_decisions.missing_count')}: <span className="font-mono text-rose-300">{selectedEvaluation.missing.length}</span></div>
            <div className="mt-1 text-slate-500">
              {actionEntrypoint.liveSubmissionEnabled ? t('downstream_decisions.form_enabled') : t('downstream_decisions.form_disabled_hint')}
            </div>
            {submissionFeedback ? <div className="mt-2 font-mono text-slate-200">{submissionFeedback}</div> : null}
          </div>
          <button
            type="submit"
            disabled={!actionEntrypoint.liveSubmissionEnabled || submissionInFlight || actionRequest === null}
            className="mt-4 w-full rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-sm font-semibold text-slate-400 disabled:cursor-not-allowed disabled:opacity-60"
          >
            {submissionInFlight ? t('downstream_decisions.form_submit_pending') : actionEntrypoint.liveSubmissionEnabled ? t('downstream_decisions.form_submit_enabled') : t('downstream_decisions.form_disabled')}
          </button>
        </form>
      </section>
    </div>
  )
}
