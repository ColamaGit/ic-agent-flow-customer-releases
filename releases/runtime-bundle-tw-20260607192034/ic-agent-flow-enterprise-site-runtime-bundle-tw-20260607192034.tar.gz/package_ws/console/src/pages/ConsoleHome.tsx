import { AlertTriangle, Ban, CheckCircle2, CircleHelp, Clock3, Database, ShieldCheck } from 'lucide-react'
import { useEffect, useMemo, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { useTranslation } from '../contexts/i18n'
import { useDashboardSignals } from '../hooks/useDashboardSignals'
import { useProductionRunsInventory } from '../hooks/useProductionRunsInventory'
import { classifyExecution, flattenExecutions, parseMode, scopedChips } from '../hooks/evidenceSummary'

function normalizeSequencePath(path: string) {
  const segs = path.split('/')
  if (segs.length === 0) return path
  segs[0] = segs[0].replace(/^\d+_/, '')
  return segs.join('/')
}

function parseArtifactJson(files: Array<{ relative_path: string; kind: 'file'; preview_text?: string | null }>, logicalPath: string) {
  const found = files.find((f) => normalizeSequencePath(f.relative_path) === logicalPath)
  if (!found?.preview_text) return null
  try {
    return JSON.parse(found.preview_text) as Record<string, unknown>
  } catch {
    return null
  }
}

export default function ConsoleHome() {
  const { t } = useTranslation()
  const location = useLocation()
  const navigate = useNavigate()
  const mode = useMemo(() => parseMode(location.search), [location.search])
  const [showAuthorityHint, setShowAuthorityHint] = useState(false)
  const { signals } = useDashboardSignals(mode)
  const { data: inventory } = useProductionRunsInventory({ layeredSummaryOnly: true })

  const chips = useMemo(() => scopedChips(inventory, mode), [inventory, mode])
  const executions = useMemo(() => flattenExecutions(chips), [chips])
  const summary = useMemo(() => {
    let pass = 0
    let warn = 0
    let blocked = 0
    let unknown = 0
    for (const chip of chips) {
      const s = chip.effective_dashboard_summary ?? chip.verdict_summary
      if (s) {
        pass += Number(s.pass ?? 0)
        warn += Number(s.warn ?? 0)
        blocked += Number(s.blocked ?? 0)
        unknown += Number(s.unknown ?? 0)
        continue
      }
      for (const run of chip.runs) {
        for (const execution of run.executions) {
          const verdict = classifyExecution(execution.files)
          if (verdict === 'PASS') pass += 1
          else if (verdict === 'WARN') warn += 1
          else if (verdict === 'BLOCKED') blocked += 1
          else unknown += 1
        }
      }
    }
    return { pass, warn, blocked, unknown, total: pass + warn + blocked + unknown }
  }, [chips])

  const quickRows = useMemo(() => {
    return chips.map((chip) => {
      const s = chip.effective_dashboard_summary ?? chip.verdict_summary
      if (s) {
        const pass = Number(s.pass ?? 0)
        const warn = Number(s.warn ?? 0)
        const blocked = Number(s.blocked ?? 0)
        const unknown = Number(s.unknown ?? 0)
        return { chipId: chip.chip_id, total: pass + warn + blocked + unknown, verdictCounts: { pass, warn, blocked, unknown } }
      }
      let pass = 0
      let warn = 0
      let blocked = 0
      let unknown = 0
      for (const run of chip.runs) {
        for (const execution of run.executions) {
          const verdict = classifyExecution(execution.files)
          if (verdict === 'PASS') pass += 1
          else if (verdict === 'WARN') warn += 1
          else if (verdict === 'BLOCKED') blocked += 1
          else unknown += 1
        }
      }
      return { chipId: chip.chip_id, total: pass + warn + blocked + unknown, verdictCounts: { pass, warn, blocked, unknown } }
    })
  }, [chips])

  const governanceSummary = useMemo(() => {
    const result = {
      signoff: { pass: 0, warn: 0, blocked: 0, na: 0 },
      tapeout: { pass: 0, warn: 0, blocked: 0, na: 0 },
      silicon: { pass: 0, warn: 0, blocked: 0, na: 0 },
    }

    for (const chip of chips) {
      const latestRun = chip.runs[0]
      const latestExec = latestRun?.executions[latestRun.executions.length - 1]
      const files = latestExec?.files ?? []

      const signoff = parseArtifactJson(files as Array<{ relative_path: string; kind: 'file'; preview_text?: string | null }>, 'dashboard_objects/final_tapeout_readiness_record.json')
      const signoffStatus = String(signoff?.status ?? 'NOT_AVAILABLE').toUpperCase()
      if (signoffStatus === 'READY_FOR_TAPEOUT_PACKAGE_ASSEMBLY') result.signoff.pass += 1
      else if (signoffStatus === 'BLOCKED' || signoffStatus === 'INVALID') result.signoff.blocked += 1
      else if (signoffStatus === 'NOT_AVAILABLE') result.signoff.na += 1
      else result.signoff.warn += 1

      const tapeout = parseArtifactJson(files as Array<{ relative_path: string; kind: 'file'; preview_text?: string | null }>, 'dashboard_objects/tapeout_package_manifest.json')
      const tapeoutStatus = String(tapeout?.status ?? 'NOT_AVAILABLE').toUpperCase()
      if (tapeoutStatus === 'PACKAGE_READY') result.tapeout.pass += 1
      else if (tapeoutStatus.includes('BLOCKED') || tapeoutStatus.includes('INVALID') || tapeoutStatus.includes('REJECT')) result.tapeout.blocked += 1
      else if (tapeoutStatus === 'NOT_AVAILABLE') result.tapeout.na += 1
      else result.tapeout.warn += 1

      const silicon = parseArtifactJson(files as Array<{ relative_path: string; kind: 'file'; preview_text?: string | null }>, 'dashboard_objects/v115_silicon_proven_claim_record.json')
      const siliconStatus = String(silicon?.status ?? 'NOT_AVAILABLE').toUpperCase()
      if (siliconStatus === 'SILICON_PROVEN_BOUNDED') result.silicon.pass += 1
      else if (siliconStatus === 'BLOCKED' || siliconStatus === 'INVALID') result.silicon.blocked += 1
      else if (siliconStatus === 'NOT_AVAILABLE') result.silicon.na += 1
      else result.silicon.warn += 1
    }
    return result
  }, [chips])

  const latest = executions[0]
  const latestContextQuery = useMemo(() => {
    if (!latest) return `mode=${mode}`
    const q = new URLSearchParams()
    q.set('mode', mode)
    q.set('chip', latest.chip_id)
    q.set('run', latest.run_id)
    q.set('execution', latest.execution_id)
    return q.toString()
  }, [latest, mode])

  useEffect(() => {
    if (!latest) return
    const params = new URLSearchParams(location.search)
    const hasScope = params.get('chip') && params.get('run') && params.get('execution')
    if (hasScope) return
    navigate(`/console?${latestContextQuery}`, { replace: true })
  }, [latest, latestContextQuery, location.search, navigate])

  const attentionItems = useMemo(() => {
    const rows: Array<{ severity: 'info' | 'warning' | 'blocker'; title: string; reason: string; action: string; target: string }> = []
    if (summary.blocked > 0) rows.push({ severity: 'blocker', title: t('console_home.attn_1_title'), reason: `blocked executions=${summary.blocked}`, action: t('console_home.attn_1_action'), target: `/decision-inbox?${latestContextQuery}` })
    if (summary.warn > 0) rows.push({ severity: 'warning', title: t('console_home.attn_2_title'), reason: `warn executions=${summary.warn}`, action: t('console_home.attn_2_action'), target: `/package-readiness?${latestContextQuery}` })
    if (summary.unknown > 0) rows.push({ severity: 'info', title: t('console_home.attn_3_title'), reason: `unknown executions=${summary.unknown}`, action: t('console_home.attn_3_action'), target: `/artifacts?${latestContextQuery}` })
    if (rows.length === 0) rows.push({ severity: 'info', title: 'No active alert', reason: 'current mode scope has no warn/blocked/unknown execution', action: t('console_home.mode_action_artifacts'), target: `/artifacts?${latestContextQuery}` })
    return rows
  }, [summary, t, latestContextQuery])

  const readinessLights = [
    { label: t('console_home.strip_1'), value: summary.pass > 0 ? 'PASS' : 'UNKNOWN', dot: summary.pass > 0 ? 'bg-emerald-400' : 'bg-slate-400' },
    { label: t('console_home.strip_2'), value: summary.warn > 0 ? 'PASS_WITH_WARNINGS' : 'PASS', dot: summary.warn > 0 ? 'bg-amber-400' : 'bg-emerald-400' },
    { label: t('console_home.strip_3'), value: summary.blocked > 0 ? 'BLOCKED' : 'PASS', dot: summary.blocked > 0 ? 'bg-rose-400' : 'bg-emerald-400' },
    { label: t('console_home.strip_4'), value: signals.flow.status, dot: signals.flow.status === 'BLOCKED' ? 'bg-rose-400' : signals.flow.status === 'PASS_WITH_WARNINGS' ? 'bg-amber-400' : 'bg-emerald-400' },
    { label: t('console_home.strip_5'), value: signals.evidence.status, dot: signals.evidence.status === 'BLOCKED' ? 'bg-rose-400' : signals.evidence.status === 'PASS_WITH_WARNINGS' ? 'bg-amber-400' : 'bg-emerald-400' },
    { label: t('console_home.strip_6'), value: signals.decision.status, dot: signals.decision.status === 'BLOCKED' ? 'bg-rose-400' : signals.decision.status === 'PENDING' ? 'bg-blue-400' : 'bg-emerald-400' },
  ]

  const modeCards = useMemo(() => {
    if (mode === 'solo_eval') {
      return [
        { text: t('console_home.mode_solo_card_1'), action: t('console_home.mode_action_run_detail'), target: '/run-detail', gateStatus: signals.flow.status, blockers: signals.flow.blockers },
        { text: t('console_home.mode_solo_card_2'), action: t('console_home.mode_action_intake'), target: '/intake', gateStatus: signals.flow.status, blockers: signals.flow.blockers },
        { text: t('console_home.mode_solo_card_3'), action: t('console_home.mode_action_decision'), target: '/decision-inbox', gateStatus: signals.decision.status, blockers: signals.decision.blockers },
        { text: t('console_home.mode_solo_card_4'), action: t('console_home.mode_action_artifacts'), target: '/artifacts', gateStatus: signals.evidence.status, blockers: signals.evidence.blockers },
      ]
    }
    if (mode === 'enterprise_site') {
      return [
        { text: t('console_home.mode_enterprise_card_1'), action: t('console_home.mode_action_qa_trust'), target: '/qa-trust', gateStatus: signals.evidence.status, blockers: signals.evidence.blockers },
        { text: t('console_home.mode_enterprise_card_2'), action: t('console_home.mode_action_decision'), target: '/decision-inbox', gateStatus: signals.decision.status, blockers: signals.decision.blockers },
        { text: t('console_home.mode_enterprise_card_3'), action: t('console_home.mode_action_package'), target: '/package-readiness', gateStatus: signals.package.status, blockers: signals.package.blockers },
        { text: t('console_home.mode_enterprise_card_4'), action: t('console_home.mode_action_audit'), target: '/audit-replay', gateStatus: signals.flow.status, blockers: signals.flow.blockers },
      ]
    }
    return [
      { text: t('console_home.mode_team_card_1'), action: t('console_home.mode_action_decision'), target: '/decision-inbox', gateStatus: signals.decision.status, blockers: signals.decision.blockers },
      { text: t('console_home.mode_team_card_2'), action: t('console_home.mode_action_package'), target: '/package-readiness', gateStatus: signals.package.status, blockers: signals.package.blockers },
      { text: t('console_home.mode_team_card_3'), action: t('console_home.mode_action_run_detail'), target: '/run-detail', gateStatus: signals.flow.status, blockers: signals.flow.blockers },
      { text: t('console_home.mode_team_card_4'), action: t('console_home.mode_action_artifacts'), target: '/artifacts', gateStatus: signals.evidence.status, blockers: signals.evidence.blockers },
    ]
  }, [mode, signals, t])

  const gateTone = (status: string) => {
    if (status === 'PASS') return 'border-emerald-500/30 bg-emerald-500/10 text-emerald-300'
    if (status === 'PASS_WITH_WARNINGS') return 'border-amber-500/30 bg-amber-500/10 text-amber-300'
    if (status === 'PENDING') return 'border-blue-500/30 bg-blue-500/10 text-blue-300'
    return 'border-rose-500/30 bg-rose-500/10 text-rose-300'
  }

  return (
    <div className="space-y-6">
      <section className="rounded-xl border border-slate-800 bg-slate-900/60 p-5">
        <div className="flex items-center gap-3">
          <h1 className="text-2xl font-semibold tracking-tight text-white">{t('console_home.title')}</h1>
          <p className="text-sm text-slate-400">{t(`console_home.mode_${mode}`)}</p>
        </div>
        <div className="mt-4 grid gap-2 text-sm text-slate-300 md:grid-cols-2 xl:grid-cols-4">
          <div>{t('common.customer')}: <span className="font-mono text-slate-100">{inventory?.workspace_id ?? 'N/A'}</span></div>
          <div>{t('common.site')}: <span className="font-mono text-slate-100">mode-scoped</span></div>
          <div>{t('common.mode')}: <span className="font-mono text-cyan-300">{mode}</span></div>
          <div>{t('common.role')}: <span className="font-mono text-slate-100">derived_from_inventory</span></div>
        </div>
      </section>

      <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-6">
        {readinessLights.map((light) => (
          <div key={light.label} className="rounded-lg border border-slate-800 bg-slate-900 p-3">
            <div className="text-xs uppercase tracking-[0.08em] text-slate-500">{light.label}</div>
            <div className="mt-1 inline-flex items-center gap-2 text-sm font-medium text-slate-100">
              <span className={`h-2.5 w-2.5 rounded-full ${light.dot}`} aria-hidden="true" />
              <span>{light.value}</span>
            </div>
          </div>
        ))}
      </section>

      {/* Fail-Closed 阻斷原因 premium 渲染組件 / Active Blocked Reasons Panel */}
      {latest?.execution?.verdict === 'BLOCKED' && latest?.execution?.fail_closed_blockers && latest.execution.fail_closed_blockers.length > 0 && (
        <section className="rounded-xl border border-rose-500/20 bg-rose-950/20 p-5 space-y-4 backdrop-blur-md">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="flex items-center gap-3">
              <Ban className="h-5 w-5 text-rose-400 animate-pulse" />
              <div>
                <h3 className="text-sm font-semibold uppercase tracking-[0.06em] text-rose-300">
                  {t('console_home.active_blocked_reasons')}
                </h3>
                <p className="text-xs text-rose-400/80 mt-0.5">
                  Fail-closed safety gateway triggered for execution: <span className="font-mono font-medium text-rose-200">{latest.execution_id}</span>
                </p>
              </div>
            </div>
            <div>
              <button
                type="button"
                onClick={() => navigate(`/run/${encodeURIComponent(latest.chip_id)}?run=${encodeURIComponent(latest.run_id)}&execution=${encodeURIComponent(latest.execution_id)}&mode=${mode}`)}
                className="inline-flex items-center rounded-lg border border-rose-500/30 bg-rose-500/10 px-3 py-1.5 text-xs font-medium text-rose-300 hover:bg-rose-500/20 hover:border-rose-500/40 transition-colors"
              >
                {t('console_home.trace_link_to_detail')}
              </button>
            </div>
          </div>

          <div className="rounded-lg border border-rose-500/10 bg-slate-950/40 p-4 text-xs font-mono text-rose-200 space-y-2 select-text">
            <ul className="list-disc list-inside space-y-1.5 pl-1">
              {latest.execution.fail_closed_blockers.map((blocker: string, idx: number) => (
                <li key={idx} className="break-all selection:bg-rose-500/40 selection:text-white">
                  {blocker}
                </li>
              ))}
            </ul>
          </div>
        </section>
      )}

      <section className="grid gap-3 md:grid-cols-3">
        <div className="rounded-xl border border-slate-800 bg-slate-900 p-4">
          <div className="text-xs uppercase tracking-[0.08em] text-slate-500">{t('console_home.signoff_summary_title')}</div>
          <div className="mt-2 text-sm text-slate-200">{t('console_home.summary_latest_scope')}</div>
          <div className="mt-3 flex flex-wrap gap-2 text-xs">
            <span className="inline-flex items-center gap-1 rounded border border-emerald-700/40 bg-emerald-900/20 px-2 py-0.5 text-emerald-300"><CheckCircle2 size={12} /> P:{governanceSummary.signoff.pass}</span>
            <span className="inline-flex items-center gap-1 rounded border border-amber-700/40 bg-amber-900/20 px-2 py-0.5 text-amber-300"><AlertTriangle size={12} /> W:{governanceSummary.signoff.warn}</span>
            <span className="inline-flex items-center gap-1 rounded border border-rose-700/40 bg-rose-900/20 px-2 py-0.5 text-rose-300"><Ban size={12} /> B:{governanceSummary.signoff.blocked}</span>
            <span className="inline-flex items-center gap-1 rounded border border-slate-700/60 bg-slate-900/40 px-2 py-0.5 text-slate-300">N/A:{governanceSummary.signoff.na}</span>
          </div>
        </div>
        <div className="rounded-xl border border-slate-800 bg-slate-900 p-4">
          <div className="text-xs uppercase tracking-[0.08em] text-slate-500">{t('console_home.tapeout_summary_title')}</div>
          <div className="mt-2 text-sm text-slate-200">{t('console_home.summary_latest_scope')}</div>
          <div className="mt-3 flex flex-wrap gap-2 text-xs">
            <span className="inline-flex items-center gap-1 rounded border border-emerald-700/40 bg-emerald-900/20 px-2 py-0.5 text-emerald-300"><CheckCircle2 size={12} /> P:{governanceSummary.tapeout.pass}</span>
            <span className="inline-flex items-center gap-1 rounded border border-amber-700/40 bg-amber-900/20 px-2 py-0.5 text-amber-300"><AlertTriangle size={12} /> W:{governanceSummary.tapeout.warn}</span>
            <span className="inline-flex items-center gap-1 rounded border border-rose-700/40 bg-rose-900/20 px-2 py-0.5 text-rose-300"><Ban size={12} /> B:{governanceSummary.tapeout.blocked}</span>
            <span className="inline-flex items-center gap-1 rounded border border-slate-700/60 bg-slate-900/40 px-2 py-0.5 text-slate-300">N/A:{governanceSummary.tapeout.na}</span>
          </div>
        </div>
        <div className="rounded-xl border border-slate-800 bg-slate-900 p-4">
          <div className="text-xs uppercase tracking-[0.08em] text-slate-500">{t('console_home.silicon_feedback_summary_title')}</div>
          <div className="mt-2 text-sm text-slate-200">{t('console_home.summary_latest_scope')}</div>
          <div className="mt-3 flex flex-wrap gap-2 text-xs">
            <span className="inline-flex items-center gap-1 rounded border border-emerald-700/40 bg-emerald-900/20 px-2 py-0.5 text-emerald-300"><CheckCircle2 size={12} /> P:{governanceSummary.silicon.pass}</span>
            <span className="inline-flex items-center gap-1 rounded border border-amber-700/40 bg-amber-900/20 px-2 py-0.5 text-amber-300"><AlertTriangle size={12} /> W:{governanceSummary.silicon.warn}</span>
            <span className="inline-flex items-center gap-1 rounded border border-rose-700/40 bg-rose-900/20 px-2 py-0.5 text-rose-300"><Ban size={12} /> B:{governanceSummary.silicon.blocked}</span>
            <span className="inline-flex items-center gap-1 rounded border border-slate-700/60 bg-slate-900/40 px-2 py-0.5 text-slate-300">N/A:{governanceSummary.silicon.na}</span>
          </div>
        </div>
      </section>

      <section className="grid grid-cols-2 gap-4 items-start">
        <div className="rounded-xl border border-slate-800 bg-slate-900 p-5 h-full">
          <h2 className="text-lg font-semibold text-white">{t('console_home.attention_title')}</h2>
          <div className="mt-4 space-y-3">
            {attentionItems.map((item) => {
              const icon = item.severity === 'blocker' ? <AlertTriangle className="h-4 w-4 text-rose-400" /> : item.severity === 'warning' ? <Clock3 className="h-4 w-4 text-amber-400" /> : <CheckCircle2 className="h-4 w-4 text-blue-400" />
              return (
                <div key={item.title + item.reason} className="rounded-lg border border-slate-800 bg-slate-950/60 p-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-2">
                      {icon}
                      <div>
                        <div className="text-sm font-medium text-slate-100">{item.title}</div>
                        <div className="text-xs text-slate-400 font-mono">{item.reason}</div>
                      </div>
                    </div>
                    <a href={item.target} className="rounded-md border border-slate-700 px-2 py-1 text-xs text-slate-200 hover:border-slate-600 hover:bg-slate-800">{item.action}</a>
                  </div>
                </div>
              )
            })}
          </div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900 overflow-hidden h-full">
          <div className="flex items-center justify-between border-b border-slate-800 p-4">
            <h2 className="text-base font-semibold text-slate-100 flex items-center gap-2">
              <Database size={18} className="text-indigo-400" />
              {t('dash.inventory_table')}
            </h2>
            <span className="text-sm text-slate-300">{quickRows.length} {t('dash.active_chips')}</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-slate-500 uppercase tracking-wider bg-slate-950/30">
                  <th className="p-4 font-semibold">{t('table.chip_id')}</th>
                  <th className="p-4 font-semibold">{t('table.readiness')}</th>
                  <th className="p-4 font-semibold">{t('artifacts.verdict_summary')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {quickRows.map((row) => (
                  <tr
                    key={row.chipId}
                    className="hover:bg-slate-800/40 transition-colors cursor-pointer"
                    onClick={() => {
                      const chip = chips.find((c) => c.chip_id === row.chipId)
                      const run = chip?.runs[0]
                      const execution = run?.executions[run.executions.length - 1]
                      const q = new URLSearchParams()
                      q.set('mode', mode)
                      q.set('chip', row.chipId)
                      if (run) q.set('run', run.run_id)
                      if (execution) q.set('execution', execution.execution_id)
                      navigate(`/artifacts?${q.toString()}`)
                    }}
                  >
                    <td className="p-4 text-slate-200 font-mono">{row.chipId}</td>
                    <td className="p-4 text-slate-200 font-mono">{row.total} runs</td>
                    <td className="p-4 text-slate-300">
                      <div className="flex flex-wrap gap-2 text-xs">
                        <span className="inline-flex items-center gap-1 rounded border border-emerald-700/40 bg-emerald-900/20 px-2 py-0.5 text-emerald-300"><CheckCircle2 size={12} /> P:{row.verdictCounts.pass}</span>
                        <span className="inline-flex items-center gap-1 rounded border border-amber-700/40 bg-amber-900/20 px-2 py-0.5 text-amber-300"><AlertTriangle size={12} /> W:{row.verdictCounts.warn}</span>
                        <span className="inline-flex items-center gap-1 rounded border border-rose-700/40 bg-rose-900/20 px-2 py-0.5 text-rose-300"><Ban size={12} /> B:{row.verdictCounts.blocked}</span>
                        <span className="inline-flex items-center gap-1 rounded border border-slate-700/60 bg-slate-900/40 px-2 py-0.5 text-slate-300">U:{row.verdictCounts.unknown}</span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <section className="rounded-xl border border-slate-800 bg-slate-900 p-5">
        <h2 className="text-lg font-semibold text-white">{t('console_home.mode_focus_title')}</h2>
        <div className="mt-3 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
          {modeCards.map((card) => (
            <div key={card.text} className="rounded-lg border border-slate-800 bg-slate-950/60 p-3 text-sm text-slate-300">
              <div className="mb-2 flex items-center justify-between gap-2">
                <span className={`inline-flex rounded border px-2 py-0.5 text-[11px] font-medium ${gateTone(card.gateStatus)}`}>
                  {t('console_home.gate_label')}: {card.gateStatus}
                </span>
                <span className="inline-flex rounded border border-slate-700 bg-slate-900 px-2 py-0.5 text-[11px] text-slate-300">
                  {t('console_home.blockers_label')}: {card.blockers}
                </span>
              </div>
              <p>{card.text}</p>
              <a
                href={`${card.target}?${latestContextQuery}`}
                className="mt-3 inline-flex rounded-md border border-slate-700 px-2 py-1 text-xs text-slate-200 hover:border-slate-600 hover:bg-slate-800"
              >
                {card.action}
              </a>
            </div>
          ))}
        </div>
      </section>

      <section className="grid gap-4 lg:grid-cols-2">
        <div className="rounded-xl border border-slate-800 bg-slate-900 p-5">
          <h3 className="text-sm font-semibold uppercase tracking-[0.06em] text-slate-200">{t('console_home.active_run')}</h3>
          <div className="mt-3 space-y-1 text-sm text-slate-300">
            <div>
              {t('common.active_run')}: {latest ? (
                <a
                  href={`/run/${encodeURIComponent(latest.chip_id)}?${latestContextQuery}`}
                  className="font-mono text-cyan-300 underline-offset-2 hover:underline"
                >
                  {latest.run_id}
                </a>
              ) : <span className="font-mono">-</span>}
            </div>
            <div>{t('common.active_chip')}: <span className="font-mono">{latest?.chip_id ?? '-'}</span></div>
            <div>{t('common.phase')}: <span className="font-mono">production-runs execution evidence</span></div>
            <div>{t('common.verdict')}: <span className="font-mono text-amber-300">{latest ? classifyExecution(latest.execution.files) : 'UNKNOWN'}</span></div>
          </div>
        </div>
        <div className="rounded-xl border border-slate-800 bg-slate-900 p-5">
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-semibold uppercase tracking-[0.06em] text-slate-200">{t('console_home.authority_status')}</h3>
            <div className="relative">
              <button
                type="button"
                aria-label="Authority status hint"
                onClick={() => setShowAuthorityHint((prev) => !prev)}
                className="rounded text-slate-400 transition hover:text-slate-200"
              >
                <CircleHelp className="h-4 w-4" />
              </button>
              {showAuthorityHint ? (
                <div className="absolute right-0 z-30 mt-2 w-80 rounded-md border border-slate-700 bg-slate-950 p-3 text-xs leading-5 text-slate-200 shadow-xl">
                  <div className="font-semibold text-slate-100">計算方式 / Calculation</div>
                  <div>`Reviewer Closure` = total executions - (warn + blocked)</div>
                  <div>`Approver Closure` = blocked 為 0 時顯示 1/1，否則 0/1</div>
                  <div>`Release Blockers` = blocked executions 數量</div>
                  <div>`Ready Declaration` = blocked &gt; 0 時 `NOT_ALLOWED`，否則 `CONDITIONAL_READY`</div>
                </div>
              ) : null}
            </div>
          </div>
          <div className="mt-3 space-y-1 text-sm text-slate-300">
            <div>{t('console_home.reviewer_closure')}: <span className="font-mono">{Math.max(summary.total - (summary.warn + summary.blocked), 0)} / {summary.total}</span></div>
            <div>{t('console_home.approver_closure')}: <span className="font-mono">{summary.blocked === 0 ? 1 : 0} / 1</span></div>
            <div>{t('console_home.release_blockers')}: <span className="font-mono text-rose-300">{summary.blocked}</span></div>
            <div className="inline-flex items-center gap-2 pt-1 text-slate-100">
              <ShieldCheck className="h-4 w-4 text-indigo-300" />
              <span>{t('console_home.ready_declaration')}: {summary.blocked > 0 ? t('console_home.not_allowed') : 'CONDITIONAL_READY'}</span>
            </div>
          </div>
        </div>
      </section>

      <section className="rounded-xl border border-amber-900/50 bg-amber-950/20 p-4 text-xs text-amber-200">
        Non-authoritative note: this home dashboard is a derived summary surface; canonical truth remains execution artifacts and governed records.
      </section>
    </div>
  )
}
