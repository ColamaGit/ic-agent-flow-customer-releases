import { ChevronDown, ChevronRight, CircleHelp, FileCode2, FileJson2, FileText, FolderTree, HardDrive } from 'lucide-react'
import { useEffect, useMemo, useState } from 'react'
import type { ReactNode } from 'react'
import { useLocation, useNavigate, useParams } from 'react-router-dom'
import { parseMode, sortChipsForMode, type OperatingMode } from '../hooks/evidenceSummary'
import { useProductionRunsInventory } from '../hooks/useProductionRunsInventory'
import type { ProductionRunChip, ProductionRunExecution, ProductionRunTask } from '../hooks/useProductionRunsInventory'
import FileFamilyExplorer from '../components/FileFamilyExplorer'
import HeaderIcon from '../components/HeaderIcon'
import { useTranslation } from '../contexts/i18n'

type AgentTrustActionRow = {
  action: string
  actor_role: string
  result: string
  generated_at: string
}

type LayeredRunDetailResponse = {
  schema_version: string
  source_dir: string
  run_id: string
  executions: ProductionRunExecution[]
}

function filterModeChips(chips: ProductionRunChip[], mode: OperatingMode) {
  return sortChipsForMode(chips, mode)
}

function humanSize(size: number) {
  if (size < 1024) return `${size} B`
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`
  return `${(size / (1024 * 1024)).toFixed(1)} MB`
}

function formatLocalDateTime(value: string) {
  const raw = String(value ?? '').trim()
  if (!raw) return '-'
  const d = new Date(raw)
  if (Number.isNaN(d.getTime())) return raw
  return d.toLocaleString()
}

type TreeNode = {
  name: string
  path: string
  kind: 'dir' | 'file'
  children: TreeNode[]
  preview_text?: string | null
  size_bytes?: number
}

function buildTree(fileList: ProductionRunExecution['files']): TreeNode[] {
  const root: TreeNode = { name: '/', path: '', kind: 'dir', children: [] }
  const nodeMap = new Map<string, TreeNode>([['', root]])
  const sorted = [...fileList].sort((a, b) => a.relative_path.localeCompare(b.relative_path))

  for (const item of sorted) {
    const segs = item.relative_path.split('/').filter(Boolean)
    let currentPath = ''
    let parent = root
    for (let i = 0; i < segs.length; i += 1) {
      const seg = segs[i]
      currentPath = currentPath ? `${currentPath}/${seg}` : seg
      const isLeaf = i === segs.length - 1
      const kind: 'dir' | 'file' = isLeaf ? item.kind : 'dir'
      if (!nodeMap.has(currentPath)) {
        const node: TreeNode = {
          name: seg,
          path: currentPath,
          kind,
          children: [],
          preview_text: isLeaf ? item.preview_text ?? null : null,
          size_bytes: isLeaf ? item.size_bytes : 0,
        }
        nodeMap.set(currentPath, node)
        parent.children.push(node)
      }
      parent = nodeMap.get(currentPath)!
    }
  }

  const sortNodes = (nodes: TreeNode[]) => {
    nodes.sort((a, b) => {
      if (a.kind !== b.kind) return a.kind === 'dir' ? -1 : 1
      return a.name.localeCompare(b.name)
    })
    nodes.forEach((n) => sortNodes(n.children))
  }
  sortNodes(root.children)
  return root.children
}

function iconForFile(name: string) {
  if (name.endsWith('.json')) return <FileJson2 size={14} className="text-cyan-300" />
  if (/\.(md|log|sv|v|sdc)$/i.test(name)) return <FileCode2 size={14} className="text-blue-300" />
  return <FileText size={14} className="text-slate-300" />
}

function stripPrefix(path: string, prefix: string) {
  return path.startsWith(prefix) ? path.slice(prefix.length) : path
}

function normalizeSequencePath(path: string) {
  return path
    .split('/')
    .map((seg) => seg.replace(/^\d+_/, ''))
    .join('/')
}

function parseArtifactJson(fileList: ProductionRunExecution['files'], logicalPath: string): Record<string, unknown> | null {
  const normalizedLogicalPath = normalizeSequencePath(logicalPath)
  const found = fileList.find(
    (f) =>
      f.kind === 'file' &&
      (f.relative_path === logicalPath || normalizeSequencePath(f.relative_path) === normalizedLogicalPath),
  )
  if (!found?.preview_text) return null
  try {
    return JSON.parse(found.preview_text) as Record<string, unknown>
  } catch {
    return null
  }
}

function resolveAgentTrustActionCommandContext(resolvedRoot: string | undefined, fallbackRelativeRunDir: string) {
  const normalizedFallback = fallbackRelativeRunDir.replace(/\\/g, '/')
  const source = (resolvedRoot ?? '').trim().replace(/\\/g, '/')
  if (!source) {
    return { scriptPath: 'package_ws/shared-runtime/scripts/apply_agent_trust_panel_action.py', runDirArg: normalizedFallback }
  }
  const repoMarker = '/artifacts/production-runs/'
  const repoIdx = source.lastIndexOf(repoMarker)
  if (repoIdx >= 0) {
    return {
      scriptPath: 'package_ws/shared-runtime/scripts/apply_agent_trust_panel_action.py',
      runDirArg: source.slice(repoIdx + 1),
    }
  }
  const releaseMarker = '/production-runs/'
  const releaseIdx = source.lastIndexOf(releaseMarker)
  if (releaseIdx >= 0) {
    const sourceRunDir = source.slice(releaseIdx + 1)
    // In local repo mode, keep artifacts/production-runs prefix for API path resolution.
    if (normalizedFallback.startsWith('artifacts/production-runs/')) {
      return {
        scriptPath: 'scripts/apply_agent_trust_panel_action.py',
        runDirArg: normalizedFallback,
      }
    }
    return {
      scriptPath: 'scripts/apply_agent_trust_panel_action.py',
      runDirArg: sourceRunDir,
    }
  }
  return { scriptPath: 'scripts/apply_agent_trust_panel_action.py', runDirArg: normalizedFallback }
}

type Verdict = 'PASS' | 'WARN' | 'BLOCKED' | 'UNKNOWN'

function classifyExecution(files: ProductionRunExecution['files']): {
  verdict: Verdict
  normalizedSignals: Array<{ relativePath: string; status: string }>
} {
  const statuses: Array<{ relativePath: string; status: string }> = []
  let passTokenInLog = false
  for (const file of files) {
    if (file.kind !== 'file') continue
    const preview = file.preview_text ?? ''
    if (/normalized\..*\.json$/i.test(file.relative_path) && preview.trim().startsWith('{')) {
      try {
        const parsed = JSON.parse(preview) as { status?: string }
        if (parsed.status) statuses.push({ relativePath: file.relative_path, status: String(parsed.status).toUpperCase() })
      } catch {
        // ignore invalid preview json
      }
    }
    if (/raw\.log$/i.test(file.relative_path) && /REAL_RUN_PASS|_PASS\b| PASS\b/i.test(preview)) {
      passTokenInLog = true
    }
  }

  if (statuses.some((s) => ['FAIL', 'BLOCKED', 'ERROR'].includes(s.status))) return { verdict: 'BLOCKED', normalizedSignals: statuses }
  if (statuses.some((s) => ['NOT_CHECKED', 'WARNING', 'WARN', 'PENDING', 'UNVALIDATED', 'PARTIAL'].includes(s.status))) return { verdict: 'WARN', normalizedSignals: statuses }
  if (statuses.some((s) => ['PASS', 'OK'].includes(s.status)) || passTokenInLog) return { verdict: 'PASS', normalizedSignals: statuses }
  return { verdict: 'UNKNOWN', normalizedSignals: statuses }
}

export default function RunDetail() {
  const { bundleId } = useParams<{ bundleId: string }>()
  const location = useLocation()
  const navigate = useNavigate()
  const mode = useMemo(() => parseMode(location.search), [location.search])
  const searchParams = useMemo(() => new URLSearchParams(location.search), [location.search])
  const requestedRunId = searchParams.get('run') ?? ''
  const requestedExecutionId = searchParams.get('execution') ?? ''
  const requestedChipId = searchParams.get('chip') ?? ''
  const { data, loading, error } = useProductionRunsInventory({ layeredWithRuns: true })
  const { t } = useTranslation()

  const chips = useMemo(() => {
    const source = data?.chips || []
    return filterModeChips(source, mode)
  }, [data, mode])

  const initialChipKey = useMemo(() => {
    if (!chips.length) return ''
    const targetId = bundleId || requestedChipId
    if (!targetId) return chips[0].source_dir
    const bySource = chips.find((c) => c.source_dir === targetId)
    if (bySource) return bySource.source_dir
    const byAlias = chips.find((c) => c.chip_id === targetId)
    return byAlias?.source_dir ?? chips[0].source_dir
  }, [chips, bundleId, requestedChipId])

  const [chipSourceDirOverride, setChipSourceDirOverride] = useState('')
  const effectiveChipSourceDir = chipSourceDirOverride || initialChipKey
  const selectedChip = useMemo(
    () => chips.find((chip) => chip.source_dir === effectiveChipSourceDir),
    [chips, effectiveChipSourceDir],
  )

  const [runIdOverride, setRunIdOverride] = useState('')
  const runOptions = useMemo(() => selectedChip?.runs ?? [], [selectedChip])
  const effectiveRunId = useMemo(() => {
    if (runIdOverride && runOptions.some((run) => run.run_id === runIdOverride)) return runIdOverride
    if (requestedRunId && runOptions.some((run) => run.run_id === requestedRunId)) return requestedRunId
    return runOptions[0]?.run_id || ''
  }, [requestedRunId, runIdOverride, runOptions])
  const selectedRun = useMemo(
    () => runOptions.find((run) => run.run_id === effectiveRunId),
    [runOptions, effectiveRunId],
  )
  const [selectedRunDetail, setSelectedRunDetail] = useState<ProductionRunTask | null>(null)
  const [selectedRunDetailError, setSelectedRunDetailError] = useState<string | null>(null)

  useEffect(() => {
    let cancelled = false
    if (!selectedChip?.source_dir || !effectiveRunId) {
      queueMicrotask(() => {
        if (cancelled) return
        setSelectedRunDetail(null)
        setSelectedRunDetailError(null)
      })
      return
    }

    queueMicrotask(() => {
      if (cancelled) return
      setSelectedRunDetail(null)
      setSelectedRunDetailError(null)
    })
    fetch(`/api/portfolio/chips/${encodeURIComponent(selectedChip.source_dir)}/runs/${encodeURIComponent(effectiveRunId)}?_ts=${Date.now()}`, {
      cache: 'no-store',
    })
      .then((res) => {
        if (!res.ok) throw new Error(`Failed to load run detail (${res.status})`)
        return res.json()
      })
      .then((json: LayeredRunDetailResponse) => {
        if (cancelled) return
        setSelectedRunDetail({
          run_id: json.run_id,
          executions: json.executions ?? [],
        })
      })
      .catch((err) => {
        if (cancelled) return
        setSelectedRunDetail(null)
        setSelectedRunDetailError(err instanceof Error ? err.message : String(err))
      })

    return () => {
      cancelled = true
    }
  }, [effectiveRunId, selectedChip?.source_dir])

  const [executionIdOverride, setExecutionIdOverride] = useState('')
  const executionOptions = useMemo(
    () => selectedRunDetail?.executions ?? selectedRun?.executions ?? [],
    [selectedRun, selectedRunDetail],
  )
  const effectiveExecutionId = useMemo(() => {
    if (executionIdOverride && executionOptions.some((exec) => exec.execution_id === executionIdOverride)) {
      return executionIdOverride
    }
    if (requestedExecutionId && executionOptions.some((exec) => exec.execution_id === requestedExecutionId)) {
      return requestedExecutionId
    }
    return executionOptions[executionOptions.length - 1]?.execution_id || ''
  }, [requestedExecutionId, executionIdOverride, executionOptions])
  const selectedExecution = useMemo(
    () => executionOptions.find((exec) => exec.execution_id === effectiveExecutionId),
    [executionOptions, effectiveExecutionId],
  )

  useEffect(() => {
    if (!selectedChip) return
    const current = new URLSearchParams(location.search)
    const currentMode = current.get('mode') ?? 'team_project'
    const currentRun = current.get('run') ?? ''
    const currentExec = current.get('execution') ?? ''
    const desiredRun = effectiveRunId || ''
    const desiredExec = effectiveExecutionId || ''
    const pathChip = bundleId ?? ''

    if (
      pathChip === selectedChip.chip_id &&
      currentMode === mode &&
      currentRun === desiredRun &&
      currentExec === desiredExec
    ) {
      return
    }

    const next = new URLSearchParams()
    next.set('mode', mode)
    if (desiredRun) next.set('run', desiredRun)
    if (desiredExec) next.set('execution', desiredExec)
    navigate(`/run/${encodeURIComponent(selectedChip.chip_id)}?${next.toString()}`, { replace: true })
  }, [bundleId, effectiveExecutionId, effectiveRunId, location.search, mode, navigate, selectedChip])

  const fileList = useMemo(() => selectedExecution?.files ?? [], [selectedExecution])
  const selectedExecutionVerdict = useMemo(() => classifyExecution(fileList), [fileList])
  const selectedExecutionSummary = useMemo(() => {
    const summary = { pass: 0, warn: 0, blocked: 0, unknown: 0 }
    const v = selectedExecutionVerdict.verdict
    if (v === 'PASS') summary.pass = 1
    else if (v === 'WARN') summary.warn = 1
    else if (v === 'BLOCKED') summary.blocked = 1
    else summary.unknown = 1
    return summary
  }, [selectedExecutionVerdict])
  const selectedExecutionSignals = useMemo(() => {
    const verdict = selectedExecutionVerdict.verdict
    const all = selectedExecutionVerdict.normalizedSignals
    if (verdict === 'BLOCKED') {
      return all.filter((s) => ['FAIL', 'BLOCKED', 'ERROR'].includes(s.status))
    }
    if (verdict === 'WARN') {
      return all.filter((s) => ['NOT_CHECKED', 'WARNING', 'WARN', 'PENDING', 'UNVALIDATED', 'PARTIAL'].includes(s.status))
    }
    if (verdict === 'UNKNOWN') {
      return [{ relativePath: '-', status: 'NO_NORMALIZED_STATUS' }]
    }
    return []
  }, [selectedExecutionVerdict])
  const siliconContractPrefix = 'subject_binding/'
  const siliconContractFiles = useMemo(
    () =>
      fileList
        .filter((f) => {
          const logicalPath = normalizeSequencePath(f.relative_path)
          return logicalPath === 'subject_binding' || logicalPath.startsWith(siliconContractPrefix)
        })
        .map((f) => ({
          ...f,
          relative_path: (() => {
            const logicalPath = normalizeSequencePath(f.relative_path)
            return logicalPath === 'subject_binding' ? '' : stripPrefix(logicalPath, siliconContractPrefix)
          })(),
        }))
        .filter((f) => f.relative_path !== ''),
    [fileList],
  )
  const siliconTree = useMemo(() => buildTree(siliconContractFiles), [siliconContractFiles])
  const skillUsageFiles = useMemo(() => {
    const isSkillPath = (p: string) =>
      p.startsWith('skill_usage/') ||
      /(^|\/)(skill_invocation_record|routing_decision_record|fallback_execution_record|decision_tree|skill_evaluation_matrix)/i.test(p) ||
      /(^|\/)v1\.9_.*(skill|routing)/i.test(p)
    return fileList
      .filter((f) => f.kind === 'file' && isSkillPath(normalizeSequencePath(f.relative_path)))
      .map((f) => ({
        ...f,
        relative_path: (() => {
          const logicalPath = normalizeSequencePath(f.relative_path)
          return logicalPath.startsWith('skill_usage/') ? stripPrefix(logicalPath, 'skill_usage/') : logicalPath
        })(),
      }))
  }, [fileList])
  const skillUsageSummary = useMemo(() => {
    const classifyMainline = (flowNodeRef: string) => {
      if (flowNodeRef.startsWith('v1_0_')) return 'v1_0' as const
      if (flowNodeRef.startsWith('v1_3_')) return 'v1_3' as const
      if (flowNodeRef.startsWith('v1_9_') || flowNodeRef.startsWith('route_b_')) return 'v1_9' as const
      if (flowNodeRef.startsWith('v1_1_v1_2_')) return 'v1_1_v1_2' as const
      if (
        [
          'v1_verilator_lint',
          'v2_verilator_sim',
          'v3_cdc_rdc',
          'v3b_cdc_signoff_lite',
          'v4_yosys_lec',
          'h1_yosys',
          'h2_openroad',
          'h5_opensta',
          'h4_klayout',
          'h3_netgen',
        ].includes(flowNodeRef)
      ) return 'v0_9' as const
      return null
    }
    const initCoverage = () => ({
      v1_0: false,
      v0_9: false,
      v1_3: false,
      v1_9: false,
      v1_1_v1_2: false,
    })
    const summaryFromRows = (rows: Array<{ flowNodeRef: string; skillType: string }>) => {
      let total = 0
      let execution = 0
      let governance = 0
      let decisionTree = 0
      const coverage = initCoverage()
      for (const row of rows) {
        total += 1
        if (row.skillType === 'execution_skill') execution += 1
        if (row.skillType === 'governance_skill') governance += 1
        if (row.skillType === 'decision_tree_skill') decisionTree += 1
        const lane = classifyMainline(row.flowNodeRef)
        if (lane) coverage[lane] = true
      }
      return {
        total,
        execution,
        governance,
        decisionTree,
        routeAUsed: coverage.v1_0,
        coverage,
      }
    }

    const ledger = fileList.find(
      (f) => f.kind === 'file' && normalizeSequencePath(f.relative_path) === 'skill_usage/skill_invocation_record.jsonl',
    )
    if (ledger?.preview_text) {
      const rows: Array<{ flowNodeRef: string; skillType: string }> = []
      for (const line of ledger.preview_text.split('\n')) {
        const text = line.trim()
        if (!text) continue
        try {
          const rec = JSON.parse(text) as { skill_type?: string; flow_node_ref?: string }
          rows.push({
            flowNodeRef: String(rec.flow_node_ref ?? ''),
            skillType: String(rec.skill_type ?? ''),
          })
        } catch {
          // ignore malformed jsonl rows
        }
      }
      if (rows.length > 0) return summaryFromRows(rows)
    }

    const summaryMd = fileList.find(
      (f) => f.kind === 'file' && normalizeSequencePath(f.relative_path) === 'skill_usage/skill_usage_summary.md',
    )
    if (summaryMd?.preview_text) {
      const rows: Array<{ flowNodeRef: string; skillType: string }> = []
      for (const line of summaryMd.preview_text.split('\n')) {
        const m = /^\|\s*([^|]+?)\s*\|\s*[^|]+\|\s*([^|]+?)\s*\|/.exec(line)
        if (!m) continue
        const flowNodeRef = m[1].trim()
        const skillType = m[2].trim()
        if (flowNodeRef.toLowerCase() === 'flow node') continue
        if (/^-+$/.test(flowNodeRef) || /^-+$/.test(skillType)) continue
        rows.push({ flowNodeRef, skillType })
      }
      if (rows.length > 0) return summaryFromRows(rows)
    }

    return {
      total: 0,
      execution: 0,
      governance: 0,
      decisionTree: 0,
      routeAUsed: false,
      coverage: initCoverage(),
    }
  }, [fileList])
  const skillTree = useMemo(() => buildTree(skillUsageFiles), [skillUsageFiles])
  const architectureSvgCandidates = useMemo(() => {
    const pick = fileList
      .filter((f) => {
        const logicalPath = normalizeSequencePath(f.relative_path)
        return (
          f.kind === 'file' &&
          (
            logicalPath === 'inputs/graph/architecture_graph.view.svg' ||
            logicalPath === 'inputs/graph/architecture_graph.draft.svg'
          )
        )
      })
      .sort((a, b) => a.relative_path.localeCompare(b.relative_path))
    return pick
  }, [fileList])
  const selectedArchitectureSvg = useMemo(() => {
    if (!architectureSvgCandidates.length) return null
    const preferred = architectureSvgCandidates.find((f) => normalizeSequencePath(f.relative_path).endsWith('architecture_graph.view.svg'))
    return preferred ?? architectureSvgCandidates[0]
  }, [architectureSvgCandidates])
  const architectureSvgDataUrl = useMemo(() => {
    const preview = selectedArchitectureSvg?.preview_text
    if (!preview || !preview.trim().startsWith('<svg')) return null
    return `data:image/svg+xml;utf8,${encodeURIComponent(preview)}`
  }, [selectedArchitectureSvg])
  const upstreamCompanionStatus = useMemo(() => {
    const preSpec = [
      'inputs/architecture_estimation/pre_spec_bandwidth_proxy.json',
      'inputs/architecture_estimation/pre_spec_power_proxy.json',
      'inputs/architecture_estimation/pre_spec_area_proxy.json',
    ]
    const hierarchy = [
      'inputs/hierarchy/hierarchy_manifest.json',
      'inputs/hierarchy/hierarchy_interface_contracts.json',
      'inputs/hierarchy/hierarchy_partition_report.json',
    ]
    const logicalSet = new Set(fileList.filter((f) => f.kind === 'file').map((f) => normalizeSequencePath(f.relative_path)))
    const count = (paths: string[]) => paths.filter((p) => logicalSet.has(p)).length
    return {
      preSpecPresent: count(preSpec),
      preSpecTotal: preSpec.length,
      hierarchyPresent: count(hierarchy),
      hierarchyTotal: hierarchy.length,
    }
  }, [fileList])
  const architectureExploration = useMemo(() => {
    const bandwidth = parseArtifactJson(fileList, 'inputs/architecture_estimation/pre_spec_bandwidth_proxy.json')
    const power = parseArtifactJson(fileList, 'inputs/architecture_estimation/pre_spec_power_proxy.json')
    const area = parseArtifactJson(fileList, 'inputs/architecture_estimation/pre_spec_area_proxy.json')
    const tradeoff = parseArtifactJson(fileList, 'inputs/architecture_estimation/architecture_tradeoff_matrix.json')
    const decision = parseArtifactJson(fileList, 'inputs/architecture_estimation/human_architecture_decision_record.json')
    const hierarchy = parseArtifactJson(fileList, 'inputs/hierarchy/hierarchy_manifest.json')
    const contracts = parseArtifactJson(fileList, 'inputs/hierarchy/hierarchy_interface_contracts.json')
    const assumptions = new Set<string>()
    const pushAssumption = (obj: Record<string, unknown> | null) => {
      const a = obj?.assumptions
      if (Array.isArray(a)) a.forEach((x) => assumptions.add(String(x)))
    }
    ;[bandwidth, power, area, tradeoff, decision].forEach(pushAssumption)
    const candidates = Array.isArray(tradeoff?.candidates) ? tradeoff?.candidates as Array<Record<string, unknown>> : []
    const top3Area = [
      { name: 'logic_area_um2', value: Number((area?.estimate as Record<string, unknown> | undefined)?.logic_area_um2 ?? 0) },
      { name: 'memory_area_um2', value: Number((area?.estimate as Record<string, unknown> | undefined)?.memory_area_um2 ?? 0) },
      { name: 'io_area_um2', value: Number((area?.estimate as Record<string, unknown> | undefined)?.io_area_um2 ?? 0) },
    ].sort((a, b) => b.value - a.value)
    const contractsCount = Array.isArray(contracts?.contracts) ? contracts?.contracts.length : 0
    const subsystems = Array.isArray(hierarchy?.subsystems) ? hierarchy?.subsystems.length : 0
    const selected = String((decision?.selected_candidate_id ?? (tradeoff?.final_recommendation as Record<string, unknown> | undefined)?.selected_candidate_id ?? t('run_explorer.na')))
    return {
      bandwidthGbps: Number((bandwidth?.estimate as Record<string, unknown> | undefined)?.required_bandwidth_gbps ?? 0),
      powerDynamicMw: Number((power?.estimate as Record<string, unknown> | undefined)?.estimated_dynamic_mw ?? 0),
      powerLeakageMw: Number((power?.estimate as Record<string, unknown> | undefined)?.estimated_leakage_mw ?? 0),
      top3Area,
      selectedCandidate: selected,
      candidates,
      subsystems,
      contractsCount,
      assumptions: Array.from(assumptions),
    }
  }, [fileList, t])
  const architectureBoardObjects = useMemo(() => {
    const runDetailManifest = parseArtifactJson(fileList, 'dashboard_objects/run_detail_manifest.json')
    const scenarioMatrix = parseArtifactJson(fileList, 'dashboard_objects/scenario_requirement_matrix.json')
    const candidateScorecard = parseArtifactJson(fileList, 'dashboard_objects/architecture_candidate_scorecard.json')
    const candidateScorecards = parseArtifactJson(fileList, 'dashboard_objects/architecture_candidate_scorecards.json')
    const candidatesRaw =
      (Array.isArray((candidateScorecard as Record<string, unknown> | null)?.records)
        ? (candidateScorecard as Record<string, unknown>).records
        : null) ??
      (Array.isArray((candidateScorecards as Record<string, unknown> | null)?.records)
        ? (candidateScorecards as Record<string, unknown>).records
        : [])
    const rawScenarioResults = Array.isArray((scenarioMatrix as Record<string, unknown> | null)?.scenario_results)
      ? ((scenarioMatrix as Record<string, unknown>).scenario_results as Array<Record<string, unknown>>)
      : []
    const scenarioResults = rawScenarioResults.map((row, idx) => {
      const verdict = String(row.verdict ?? 'PARTIAL').toUpperCase()
      const isLegacyTradeoffFallback = String(row.scenario_id ?? '').startsWith('candidate_eval_')
      const fallbackRule =
        verdict === 'MEETING'
          ? 'SCENARIO_VERDICT_RULE_V1_MEETING_LEGACY'
          : verdict === 'NOT_MEETING'
            ? 'SCENARIO_VERDICT_RULE_V1_NOT_MEETING_LEGACY'
            : isLegacyTradeoffFallback
              ? 'SCENARIO_VERDICT_RULE_V1_FALLBACK_FROM_TRADEOFF_LEGACY'
              : 'SCENARIO_VERDICT_RULE_V1_PARTIAL_LEGACY'
      const fallbackReason =
        verdict === 'MEETING'
          ? 'legacy_matrix_missing_verdict_reason_marked_meeting'
          : verdict === 'NOT_MEETING'
            ? 'legacy_matrix_missing_verdict_reason_marked_not_meeting'
            : isLegacyTradeoffFallback
              ? 'legacy_matrix_missing_rule_reason_generated_from_tradeoff_candidates'
              : 'legacy_matrix_missing_verdict_reason_partial_or_unresolved'
      return {
        ...row,
        scenario_id: String(row.scenario_id ?? `legacy_scenario_${idx + 1}`),
        verdict,
        verdict_rule_id: String(row.verdict_rule_id ?? fallbackRule),
        verdict_reason: String(row.verdict_reason ?? fallbackReason),
        failed_requirements: Array.isArray(row.failed_requirements) ? row.failed_requirements : [],
        failed_assumptions: Array.isArray(row.failed_assumptions) ? row.failed_assumptions : [],
        evidence_refs: Array.isArray(row.evidence_refs) ? row.evidence_refs : [],
      }
    })
    const rawRequirementResults = Array.isArray((scenarioMatrix as Record<string, unknown> | null)?.requirement_results)
      ? ((scenarioMatrix as Record<string, unknown>).requirement_results as Array<Record<string, unknown>>)
      : []
    const normalizedRequirementResults =
      rawRequirementResults.length > 0
        ? rawRequirementResults.map((row, idx) => {
            const verdict = String(row.verdict ?? 'PARTIAL').toUpperCase()
            const fallbackRule =
              verdict === 'MEETING'
                ? 'REQUIREMENT_VERDICT_RULE_V1_MEETING_LEGACY'
                : verdict === 'NOT_MEETING'
                  ? 'REQUIREMENT_VERDICT_RULE_V1_NOT_MEETING_LEGACY'
                  : 'REQUIREMENT_VERDICT_RULE_V1_PARTIAL_LEGACY'
            const fallbackReason =
              verdict === 'MEETING'
                ? 'legacy_matrix_missing_requirement_reason_marked_meeting'
                : verdict === 'NOT_MEETING'
                  ? 'legacy_matrix_missing_requirement_reason_marked_not_meeting'
                  : 'legacy_matrix_missing_requirement_reason_partial_or_unresolved'
            return {
              ...row,
              requirement_id: String(row.requirement_id ?? `legacy_requirement_${idx + 1}`),
              verdict,
              verdict_rule_id: String(row.verdict_rule_id ?? fallbackRule),
              verdict_reason: String(row.verdict_reason ?? fallbackReason),
              failed_assumptions: Array.isArray(row.failed_assumptions) ? row.failed_assumptions : [],
              evidence_refs: Array.isArray(row.evidence_refs) ? row.evidence_refs : [],
            }
          })
        : scenarioResults.length > 0
          ? [
              {
                requirement_id: 'LEGACY_REQUIREMENT_NOT_AVAILABLE',
                verdict: 'PARTIAL',
                verdict_rule_id: 'REQUIREMENT_VERDICT_RULE_V1_LEGACY_MISSING_REQUIREMENT_RESULTS',
                verdict_reason: 'legacy_matrix_has_scenarios_but_no_requirement_results',
                failed_assumptions: [],
                evidence_refs: [],
              },
            ]
          : []

    return {
      runDetailManifest,
      matrixAvailable: Boolean(scenarioMatrix),
      objectVersion: String((scenarioMatrix?.object_version as string | undefined) ?? 'NOT_AVAILABLE'),
      generatedAt: String((scenarioMatrix?.generated_at as string | undefined) ?? 'NOT_AVAILABLE'),
      sourceRunId: String((scenarioMatrix?.source_run_id as string | undefined) ?? 'NOT_AVAILABLE'),
      sourceDateTime: String((scenarioMatrix?.source_date_time as string | undefined) ?? 'NOT_AVAILABLE'),
      compatibilityMode: String((scenarioMatrix?.compatibility_mode as string | undefined) ?? 'NOT_AVAILABLE'),
      scenarioCount: Number((scenarioMatrix?.scenario_count as number | undefined) ?? 0),
      scenarioPassCount: Number((scenarioMatrix?.scenario_pass_count as number | undefined) ?? 0),
      requirementCount: Number((scenarioMatrix?.requirement_count as number | undefined) ?? 0),
      requirementPassCount: Number((scenarioMatrix?.requirement_global_pass_count as number | undefined) ?? 0),
      scenarioResults,
      requirementResults: normalizedRequirementResults,
      candidates: candidatesRaw as Array<Record<string, unknown>>,
    }
  }, [fileList])
  const runInputCoverageGate = useMemo(() => {
    const manifest = architectureBoardObjects.runDetailManifest as Record<string, unknown> | null
    const gate = manifest?.run_input_source_coverage_gate
    if (!gate || typeof gate !== 'object') return null
    return gate as Record<string, unknown>
  }, [architectureBoardObjects.runDetailManifest])
  const runTopologyAndVerification = useMemo(() => {
    const manifest = architectureBoardObjects.runDetailManifest as Record<string, unknown> | null
    const rawLane = manifest?.verification_source_lane as Record<string, unknown> | null
    const rawPolicy = manifest?.run_topology_policy as Record<string, unknown> | null
    const filePaths = fileList
      .filter((f) => f.kind === 'file')
      .map((f) => String(f.relative_path ?? '').replace(/\\/g, '/'))
    const verificationFilePaths = filePaths.filter(
      (path) =>
        path.startsWith('01_inputs/verification/tb/') ||
        path.startsWith('inputs/verification/tb/') ||
        path.startsWith('verification/tb/'),
    )
    const verificationSourceLane = rawLane && Object.keys(rawLane).length > 0
      ? rawLane
      : {
          required_by_policy: verificationFilePaths.length > 0,
          source_family: 'verification_tb',
          source_root: 'verification/tb',
          logical_input_root: 'inputs/verification/tb',
          physical_01_inputs_root: '01_inputs/verification/tb',
          consumer_stages: ['v2_verilator_sim', 'h10_power_ir_dynamic'],
          expected_files: verificationFilePaths,
          missing_files: [],
          materialized: verificationFilePaths.length > 0,
        }
    const runTopologyPolicy = rawPolicy && Object.keys(rawPolicy).length > 0
      ? rawPolicy
      : {
          prefix_counts_are_topology_dependent: true,
          fixed_highest_prefix_is_not_authoritative: true,
          reports_dir_must_follow_materialized_topology: true,
        }
    return {
      verificationSourceLane,
      runTopologyPolicy,
    }
  }, [architectureBoardObjects.runDetailManifest, fileList])
  const verificationSourceLane = runTopologyAndVerification.verificationSourceLane as Record<string, unknown> | undefined
  const verificationConsumerStages = Array.isArray(verificationSourceLane?.consumer_stages)
    ? (verificationSourceLane.consumer_stages as Array<unknown>)
    : []
  const verificationExpectedFiles = Array.isArray(verificationSourceLane?.expected_files)
    ? (verificationSourceLane.expected_files as Array<unknown>)
    : []
  const verificationMissingFiles = Array.isArray(verificationSourceLane?.missing_files)
    ? (verificationSourceLane.missing_files as Array<unknown>)
    : []
  const v116Objects = useMemo(() => {
    const enforcement = parseArtifactJson(fileList, 'dashboard_objects/v1_16_adapter_schema_enforcement_record.json')
    const equivalence = parseArtifactJson(fileList, 'dashboard_objects/v1_16_node_replacement_equivalence_claim_record.json')
    const lineageBridge = parseArtifactJson(fileList, 'dashboard_objects/v1_16_lineage_bridge_record.json')
    const invalidation = parseArtifactJson(fileList, 'dashboard_objects/v1_16_equivalence_invalidation_record.json')
    const downstreamConsumption = parseArtifactJson(fileList, 'dashboard_objects/v1_16_downstream_replacement_consumption_record.json')
    const overclaimScan = parseArtifactJson(fileList, 'dashboard_objects/v1_16_overclaim_scan_report.json')
    const negativeTest = parseArtifactJson(fileList, 'dashboard_objects/v1_16_mandatory_node_replacement_negative_test.json')
    const available = Boolean(
      enforcement ||
      equivalence ||
      lineageBridge ||
      invalidation ||
      downstreamConsumption ||
      overclaimScan ||
      negativeTest,
    )
    return {
      available,
      enforcementStatus: String(enforcement?.overall_status ?? enforcement?.status ?? 'NOT_AVAILABLE'),
      equivalenceStatus: String(equivalence?.status ?? 'NOT_AVAILABLE'),
      lineageStatus: String(lineageBridge?.status ?? 'NOT_AVAILABLE'),
      invalidationStatus: String(invalidation?.status ?? 'NOT_AVAILABLE'),
      downstreamStatus: String(downstreamConsumption?.status ?? 'NOT_AVAILABLE'),
      overclaimStatus: String(overclaimScan?.status ?? 'NOT_AVAILABLE'),
      negativeTestStatus: String(negativeTest?.status ?? 'NOT_AVAILABLE'),
      equivalenceClass: String(equivalence?.equivalence_class ?? 'NOT_AVAILABLE'),
      requestedClaim: String(downstreamConsumption?.requested_claim ?? 'NOT_AVAILABLE'),
      blockedClaims: Array.isArray(equivalence?.claim_ineligible) ? (equivalence.claim_ineligible as Array<unknown>).map((x) => String(x)) : [],
    }
  }, [fileList])
  const flowReportIndex = useMemo(() => parseArtifactJson(fileList, 'flow_report_index.json'), [fileList])
  const flowReportFamilies = useMemo(() => {
    const rows = Array.isArray(flowReportIndex?.report_families)
      ? (flowReportIndex.report_families as Array<Record<string, unknown>>)
      : []
    return rows.map((row) => ({
      familyId: String(row.family_id ?? 'NOT_AVAILABLE'),
      version: String(row.version ?? 'NOT_AVAILABLE'),
      phase: String(row.phase ?? 'NOT_AVAILABLE'),
      required: Boolean(row.required),
      status: String(row.status ?? 'NOT_AVAILABLE'),
      missingCount: Array.isArray(row.files_missing) ? row.files_missing.length : 0,
    }))
  }, [flowReportIndex])
  const flowMainline = useMemo(() => {
    const rows = Array.isArray(flowReportIndex?.silicon_lifecycle_mainline)
      ? (flowReportIndex.silicon_lifecycle_mainline as Array<unknown>)
      : []
    return rows.map((x) => String(x))
  }, [flowReportIndex])
  const flowLanes = useMemo(() => {
    const rows = Array.isArray(flowReportIndex?.cross_cutting_backflow_lanes)
      ? (flowReportIndex.cross_cutting_backflow_lanes as Array<unknown>)
      : []
    return rows.map((x) => String(x))
  }, [flowReportIndex])
  const agentTrustPanelView = useMemo(
    () => parseArtifactJson(fileList, 'dashboard_objects/agent_trust_panel_view.json'),
    [fileList],
  )
  const agentTrustPanelBinding = useMemo(
    () => parseArtifactJson(fileList, 'dashboard_objects/agent_trust_panel_action_binding.json'),
    [fileList],
  )
  const agentTrustActionHistory = useMemo(() => {
    const rows: AgentTrustActionRow[] = []
    const actionFiles = fileList
      .filter((f) => f.kind === 'file' && normalizeSequencePath(f.relative_path).startsWith('dashboard_objects/agent_trust_panel_action_records/') && f.relative_path.endsWith('.json'))
      .sort((a, b) => b.relative_path.localeCompare(a.relative_path))
    for (const file of actionFiles) {
      if (!file.preview_text) continue
      try {
        const parsed = JSON.parse(file.preview_text) as Record<string, unknown>
        rows.push({
          action: String(parsed.action ?? '-'),
          actor_role: String(parsed.actor_role ?? '-'),
          result: String(parsed.result ?? '-'),
          generated_at: String(parsed.generated_at ?? '-'),
        })
      } catch {
        // ignore malformed preview
      }
    }
    return rows
  }, [fileList])
  const [expandedSilicon, setExpandedSilicon] = useState<Record<string, boolean>>({})
  const [selectedSiliconFilePath, setSelectedSiliconFilePath] = useState<string>('')
  const [expandedSkill, setExpandedSkill] = useState<Record<string, boolean>>({})
  const [selectedSkillFilePath, setSelectedSkillFilePath] = useState<string>('')
  const [sectionExpanded, setSectionExpanded] = useState<Record<string, boolean>>({
    artifactStructure: true,
    siliconContract: false,
    architectureGraph: false,
    architectureBoard: false,
    reportFamilies: false,
    replacementGovernance: false,
    agentTrustPanel: false,
    skillUsage: false,
  })
  const [agentTrustActorRole, setAgentTrustActorRole] = useState<string>('RELEASE_AUTHORITY')
  const [agentTrustSessionId, setAgentTrustSessionId] = useState<string>('session-release-authority')
  const [agentTrustActionStatus, setAgentTrustActionStatus] = useState<string>('')
  const [agentTrustApiHintOpen, setAgentTrustApiHintOpen] = useState<boolean>(false)
  const [agentTrustActionHistoryLocal, setAgentTrustActionHistoryLocal] = useState<AgentTrustActionRow[]>([])
  const defaultSelectedSiliconFilePath = useMemo(
    () => siliconContractFiles.find((f) => f.kind === 'file' && f.preview_text)?.relative_path ?? '',
    [siliconContractFiles],
  )
  const effectiveSelectedSiliconFilePath = selectedSiliconFilePath || defaultSelectedSiliconFilePath
  const defaultSelectedSkillFilePath = useMemo(
    () => skillUsageFiles.find((f) => f.kind === 'file' && f.preview_text)?.relative_path ?? '',
    [skillUsageFiles],
  )
  const effectiveSelectedSkillFilePath = selectedSkillFilePath || defaultSelectedSkillFilePath
  const mergedAgentTrustActionHistory = useMemo(() => {
    const rows = [...agentTrustActionHistoryLocal, ...agentTrustActionHistory]
    const seen = new Set<string>()
    const merged: AgentTrustActionRow[] = []
    for (const row of rows) {
      const key = `${row.generated_at}|${row.actor_role}|${row.action}|${row.result}`
      if (seen.has(key)) continue
      seen.add(key)
      merged.push(row)
    }
    return merged
  }, [agentTrustActionHistoryLocal, agentTrustActionHistory])
  useEffect(() => {
    const resetTimer = window.setTimeout(() => setAgentTrustActionHistoryLocal([]), 0)
    return () => window.clearTimeout(resetTimer)
  }, [selectedChip?.source_dir, effectiveRunId, effectiveExecutionId])

  const selectedSiliconFile = useMemo(
    () => siliconContractFiles.find((f) => f.relative_path === effectiveSelectedSiliconFilePath && f.kind === 'file') ?? null,
    [siliconContractFiles, effectiveSelectedSiliconFilePath],
  )
  const selectedSkillFile = useMemo(
    () => skillUsageFiles.find((f) => f.relative_path === effectiveSelectedSkillFilePath && f.kind === 'file') ?? null,
    [skillUsageFiles, effectiveSelectedSkillFilePath],
  )
  const toggleSection = (key: string) => {
    setSectionExpanded((prev) => ({ ...prev, [key]: !prev[key] }))
  }
  const renderSectionHintIcon = (hintText: string) => (
    <span className="relative inline-flex items-center group" title={t('run_explorer.section_hint_button_aria')}>
      <CircleHelp size={14} className="text-slate-400 hover:text-cyan-300" aria-hidden="true" />
      <span className="pointer-events-none absolute right-0 top-5 z-20 hidden w-[26rem] rounded border border-slate-700 bg-slate-950/95 p-2 text-left text-xs text-cyan-200 shadow-lg group-hover:block group-focus-within:block">
        {hintText}
      </span>
    </span>
  )

  const applyAgentTrustActionViaApi = async () => {
    if (!agentTrustPanelBinding) {
      setAgentTrustActionStatus(t('run_explorer.agent_trust_api_no_binding'))
      return
    }
    const action = String(agentTrustPanelBinding.requested_action ?? 'request_more_evidence')
    const bindingId = String(agentTrustPanelBinding.binding_id ?? '')
    if (!bindingId) {
      setAgentTrustActionStatus(t('run_explorer.agent_trust_api_missing_binding_id'))
      return
    }
    const fallbackRunDir = `artifacts/production-runs/${selectedChip?.source_dir}/${effectiveRunId}/${effectiveExecutionId}`
    const actionCtx = resolveAgentTrustActionCommandContext(selectedExecution?.resolved_root ?? fallbackRunDir, fallbackRunDir)
    const payload = {
      run_dir: actionCtx.runDirArg,
      binding_id: bindingId,
      action,
      actor_role: agentTrustActorRole,
      session_id: agentTrustSessionId.trim() || 'session-default',
    }
    setAgentTrustActionStatus(t('run_explorer.agent_trust_api_submitting'))
    try {
      const res = await fetch('/api/agent-trust/action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      const body = await res.json().catch(() => ({}))
      if (!res.ok) {
        setAgentTrustActionStatus(`${t('run_explorer.agent_trust_api_prefix')} ${res.status}: ${String((body as { error?: string }).error ?? 'unknown_error')}`)
        return
      }
      const result = body as { status?: string; result_record?: { status?: string } }
      setAgentTrustActionStatus(
        `${t('run_explorer.agent_trust_api_prefix')} ${res.status}: ${String(result.status ?? 'ok')} / ${t('run_explorer.agent_trust_result_label')}=${String(result.result_record?.status ?? 'NOT_AVAILABLE')}`,
      )
      setAgentTrustActionHistoryLocal((prev) => [
        {
          action,
          actor_role: agentTrustActorRole,
          result: String(result.result_record?.status ?? 'EXECUTED'),
          generated_at: new Date().toISOString(),
        },
        ...prev,
      ])
      // Do not trigger global reload here; keep Action History update local and stable.
    } catch (error) {
      setAgentTrustActionStatus(`${t('run_explorer.agent_trust_api_error')}: ${error instanceof Error ? error.message : String(error)}`)
    }
  }

  const renderSiliconTree = (nodes: TreeNode[], depth = 0): ReactNode[] =>
    nodes.map((node) => {
      const isDir = node.kind === 'dir'
      const isOpen = expandedSilicon[node.path] ?? false
      const rowBase = 'flex items-center gap-2 rounded px-2 py-1 text-sm'
      const active = effectiveSelectedSiliconFilePath === node.path ? 'bg-cyan-500/15 text-cyan-200' : 'text-slate-300 hover:bg-slate-800'
      return (
        <div key={`sc-${node.path}`}>
          <button
            type="button"
            className={`${rowBase} w-full text-left ${active}`}
            style={{ paddingLeft: `${8 + depth * 14}px` }}
            onClick={() => {
              if (isDir) {
                setExpandedSilicon((prev) => ({ ...prev, [node.path]: !isOpen }))
              } else {
                setSelectedSiliconFilePath(node.path)
              }
            }}
          >
            {isDir ? (
              isOpen ? <ChevronDown size={14} className="text-slate-400" /> : <ChevronRight size={14} className="text-slate-400" />
            ) : (
              <span className="w-[14px]" />
            )}
            {isDir ? <HardDrive size={14} className="text-amber-300" /> : iconForFile(node.name)}
            <span className="font-mono text-xs">{node.name}</span>
          </button>
          {isDir && isOpen && node.children.length > 0 && <div>{renderSiliconTree(node.children, depth + 1)}</div>}
        </div>
      )
    })

  const renderSkillTree = (nodes: TreeNode[], depth = 0): ReactNode[] =>
    nodes.map((node) => {
      const isDir = node.kind === 'dir'
      const isOpen = expandedSkill[node.path] ?? false
      const rowBase = 'flex items-center gap-2 rounded px-2 py-1 text-sm'
      const active = effectiveSelectedSkillFilePath === node.path ? 'bg-cyan-500/15 text-cyan-200' : 'text-slate-300 hover:bg-slate-800'
      return (
        <div key={`sk-${node.path}`}>
          <button
            type="button"
            className={`${rowBase} w-full text-left ${active}`}
            style={{ paddingLeft: `${8 + depth * 14}px` }}
            onClick={() => {
              if (isDir) {
                setExpandedSkill((prev) => ({ ...prev, [node.path]: !isOpen }))
              } else {
                setSelectedSkillFilePath(node.path)
              }
            }}
          >
            {isDir ? (
              isOpen ? <ChevronDown size={14} className="text-slate-400" /> : <ChevronRight size={14} className="text-slate-400" />
            ) : (
              <span className="w-[14px]" />
            )}
            {isDir ? <HardDrive size={14} className="text-amber-300" /> : iconForFile(node.name)}
            <span className="font-mono text-xs">{node.name}</span>
          </button>
          {isDir && isOpen && node.children.length > 0 && <div>{renderSkillTree(node.children, depth + 1)}</div>}
        </div>
      )
    })

  if (loading) return <div className="text-slate-500 font-mono text-sm animate-pulse p-8">{t('run_explorer.loading')}</div>
  if (error) return <div className="text-rose-500 font-mono text-sm p-8">{t('common.error')}: {error}</div>
  if (!chips.length) return <div className="text-slate-400 p-8">{t('run_explorer.no_runs')}: {mode}</div>

  return (
    <div className="space-y-6">
      <div className="border-b border-slate-800/50 pb-5">
        <h1 className="text-3xl font-semibold tracking-tight text-white inline-flex items-center gap-2">
          <HeaderIcon name="report" className="text-cyan-300" size={22} />
          {t('run_explorer.title')}
        </h1>
        <p className="text-sm text-slate-400 mt-1">
          {t('run_explorer.subtitle')}
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
        <label className="rounded-xl border border-slate-800 bg-slate-900 p-4">
          <div className="text-xs uppercase tracking-widest text-slate-500 mb-2">{t('run_explorer.chip_id')}</div>
          <select
            value={selectedChip?.source_dir ?? ''}
            onChange={(e) => {
              setChipSourceDirOverride(e.target.value)
              setRunIdOverride('')
              setExecutionIdOverride('')
            }}
            className="w-full rounded-md border border-slate-700 bg-slate-950 px-3 py-2 text-slate-200"
          >
            {chips.map((chip) => (
              <option key={chip.source_dir} value={chip.source_dir}>
                {chip.chip_id} ({chip.source_dir})
              </option>
            ))}
          </select>
        </label>

        <label className="rounded-xl border border-slate-800 bg-slate-900 p-4">
          <div className="text-xs uppercase tracking-widest text-slate-500 mb-2">{t('run_explorer.run_id')}</div>
          <select
            value={effectiveRunId}
            onChange={(e) => {
              setRunIdOverride(e.target.value)
              setExecutionIdOverride('')
            }}
            className="w-full rounded-md border border-slate-700 bg-slate-950 px-3 py-2 text-slate-200"
          >
            {runOptions.map((run: ProductionRunTask) => (
              <option key={run.run_id} value={run.run_id}>{run.run_id}</option>
            ))}
          </select>
        </label>

        <label className="rounded-xl border border-slate-800 bg-slate-900 p-4">
          <div className="text-xs uppercase tracking-widest text-slate-500 mb-2">{t('run_explorer.execution_ts')}</div>
          <select
            value={effectiveExecutionId}
            onChange={(e) => setExecutionIdOverride(e.target.value)}
            className="w-full rounded-md border border-slate-700 bg-slate-950 px-3 py-2 text-slate-200"
          >
            {executionOptions.map((exec: ProductionRunExecution) => (
              <option key={exec.execution_id} value={exec.execution_id}>{exec.execution_id}</option>
            ))}
          </select>
        </label>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
        <div className="rounded-xl border border-slate-800 bg-slate-900 p-4">
          <div className="text-xs uppercase tracking-widest text-slate-500 mb-2">{t('run_explorer.resolved_root')}</div>
          <div className="text-xs font-mono text-cyan-300 break-all">{selectedExecution?.resolved_root ?? '-'}</div>
        </div>
        <div className="rounded-xl border border-slate-800 bg-slate-900 p-4">
          <div className="text-xs uppercase tracking-widest text-slate-500 mb-2">{t('run_explorer.files_dirs')}</div>
          <div className="text-sm text-slate-100">{fileList.length}</div>
        </div>
        <div className="rounded-xl border border-slate-800 bg-slate-900 p-4">
          <div className="text-xs uppercase tracking-widest text-slate-500 mb-2">{t('common.mode')}</div>
          <div className="text-sm text-slate-100">{mode}</div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <div className="rounded-xl border border-slate-800 bg-slate-900 p-4">
          <div className="text-xs uppercase tracking-widest text-slate-500 mb-2">{t('artifacts.verdict_summary')}</div>
          <div className="text-[11px] text-slate-500 mb-2">{t('run_explorer.execution_scope_note')}</div>
          <div className="flex flex-wrap gap-2 text-xs font-mono">
            <span className="rounded border border-emerald-700/40 bg-emerald-900/20 px-2 py-0.5 text-emerald-300">P:{selectedExecutionSummary.pass}</span>
            <span className="rounded border border-amber-700/40 bg-amber-900/20 px-2 py-0.5 text-amber-300">W:{selectedExecutionSummary.warn}</span>
            <span className="rounded border border-rose-700/40 bg-rose-900/20 px-2 py-0.5 text-rose-300">B:{selectedExecutionSummary.blocked}</span>
            <span className="rounded border border-slate-700/60 bg-slate-900/40 px-2 py-0.5 text-slate-300">U:{selectedExecutionSummary.unknown}</span>
          </div>
        </div>
        <div className="rounded-xl border border-slate-800 bg-slate-900 p-4">
          <div className="text-xs uppercase tracking-widest text-slate-500 mb-2 flex items-center justify-between gap-2">
            <span>{t('artifacts.evidence_signal')} ({effectiveExecutionId} · {selectedExecutionVerdict.verdict})</span>
            <span className="text-[11px] normal-case tracking-normal text-slate-500">{t('run_explorer.signal_count')}: {selectedExecutionSignals.length}</span>
          </div>
          <div className="space-y-1 text-xs font-mono text-slate-300 max-h-40 overflow-y-auto pr-1">
            {selectedExecutionSignals.length > 0 ? (
              selectedExecutionSignals.map((signal, idx) => (
                <div key={`${signal.relativePath}-${signal.status}-${idx}`} className="break-all">
                  [{selectedExecutionVerdict.verdict}] {signal.status} @ {signal.relativePath}
                </div>
              ))
            ) : (
              <div className="text-slate-500">{t('artifacts.no_signal')}</div>
            )}
          </div>
        </div>
      </div>
      <div className="rounded-xl border border-slate-800 bg-slate-900 overflow-hidden">
        <button type="button" onClick={() => toggleSection('reportFamilies')} className="w-full p-4 border-b border-slate-800 flex items-center justify-between text-left hover:bg-slate-900/60">
          <h2 className="text-base font-semibold text-slate-100 inline-flex items-center gap-2">
            {sectionExpanded.reportFamilies ? <ChevronDown size={22} className="text-slate-300" /> : <ChevronRight size={22} className="text-slate-300" />}
            <FolderTree size={18} className="text-violet-300" />
            {t('run_explorer.report_family_board')}
          </h2>
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">{t('run_explorer.report_family_note')}</span>
            {renderSectionHintIcon(t('run_explorer.section_hint_reportFamilies'))}
          </div>
        </button>
        {sectionExpanded.reportFamilies && <div className="p-4 space-y-3">
          {!flowReportIndex ? (
            <div className="text-xs text-slate-500">{t('run_explorer.not_available')}</div>
          ) : (
            <>
              <div className="rounded border border-slate-800 bg-slate-950 p-3 text-xs text-slate-300">
                <div><span className="text-slate-500">{t('run_explorer.report_family_completeness')}:</span> <span className="font-mono text-cyan-300">{String(flowReportIndex.completeness_status ?? 'NOT_AVAILABLE')}</span></div>
                <div className="mt-1"><span className="text-slate-500">{t('run_explorer.report_family_generated_at')}:</span> <span className="font-mono">{String(flowReportIndex.generated_at ?? 'NOT_AVAILABLE')}</span></div>
                <div className="mt-1"><span className="text-slate-500">{t('run_explorer.report_family_derived_only')}:</span> <span className="font-mono">{String(flowReportIndex.derived_only ?? true)}</span></div>
              </div>
              <div className="rounded border border-slate-800 bg-slate-950 p-3 text-xs text-slate-300">
                <div className="text-slate-200 mb-1">{t('run_explorer.report_family_mainline')}</div>
                <div className="font-mono text-cyan-300">{flowMainline.length > 0 ? flowMainline.join(' -> ') : t('run_explorer.not_available')}</div>
              </div>
              <div className="rounded border border-slate-800 bg-slate-950 p-3 text-xs text-slate-300">
                <div className="text-slate-200 mb-1">{t('run_explorer.report_family_lanes')}</div>
                <div className="font-mono text-cyan-300">{flowLanes.length > 0 ? flowLanes.join(' -> ') : t('run_explorer.not_available')}</div>
              </div>
              <div className="rounded border border-slate-800 bg-slate-950 p-3 overflow-x-auto">
                <table className="min-w-full text-left text-xs">
                  <thead className="text-slate-500 uppercase tracking-wider">
                    <tr>
                      <th className="pr-3 pb-2">{t('run_explorer.report_family_col_family')}</th>
                      <th className="pr-3 pb-2">{t('run_explorer.report_family_col_version')}</th>
                      <th className="pr-3 pb-2">{t('run_explorer.report_family_col_phase')}</th>
                      <th className="pr-3 pb-2">{t('run_explorer.report_family_col_required')}</th>
                      <th className="pr-3 pb-2">{t('run_explorer.report_family_col_status')}</th>
                      <th className="pr-3 pb-2">{t('run_explorer.report_family_col_missing')}</th>
                    </tr>
                  </thead>
                  <tbody className="text-slate-300">
                    {flowReportFamilies.length === 0 ? (
                      <tr className="border-t border-slate-800/70">
                        <td className="py-2 pr-3 font-mono" colSpan={6}>{t('run_explorer.not_available')}</td>
                      </tr>
                    ) : (
                      flowReportFamilies.map((row) => (
                        <tr key={`${row.familyId}-${row.version}`} className="border-t border-slate-800/70">
                          <td className="py-2 pr-3 font-mono">{row.familyId}</td>
                          <td className="py-2 pr-3 font-mono">{row.version}</td>
                          <td className="py-2 pr-3">{row.phase}</td>
                          <td className="py-2 pr-3 font-mono">{row.required ? 'true' : 'false'}</td>
                          <td className="py-2 pr-3 font-mono">{row.status}</td>
                          <td className="py-2 pr-3 font-mono">{row.missingCount}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </>
          )}
        </div>}
      </div>
      <div className="rounded-xl border border-slate-800 bg-slate-900 overflow-hidden" data-testid="v116-replacement-governance">
        <button type="button" onClick={() => toggleSection('replacementGovernance')} className="w-full p-4 border-b border-slate-800 flex items-center justify-between text-left hover:bg-slate-900/60">
          <h2 className="text-base font-semibold text-slate-100 inline-flex items-center gap-2">
            {sectionExpanded.replacementGovernance ? <ChevronDown size={22} className="text-slate-300" /> : <ChevronRight size={22} className="text-slate-300" />}
            <FolderTree size={18} className="text-teal-300" />
            {t('run_explorer.v116_board')}
          </h2>
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">{t('run_explorer.v116_board_note')}</span>
            {renderSectionHintIcon(t('run_explorer.section_hint_replacementGovernance'))}
          </div>
        </button>
        {sectionExpanded.replacementGovernance && <div className="p-4 space-y-3">
          {!v116Objects.available ? (
            <div className="text-xs text-slate-500">{t('run_explorer.not_available')}</div>
          ) : (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-2 text-xs">
                <div className="rounded border border-slate-800 bg-slate-950 p-2"><span className="text-slate-500">{t('run_explorer.v116_enforcement')}:</span> <span className="font-mono text-cyan-300">{v116Objects.enforcementStatus}</span></div>
                <div className="rounded border border-slate-800 bg-slate-950 p-2"><span className="text-slate-500">{t('run_explorer.v116_equivalence')}:</span> <span className="font-mono text-cyan-300">{v116Objects.equivalenceStatus}</span></div>
                <div className="rounded border border-slate-800 bg-slate-950 p-2"><span className="text-slate-500">{t('run_explorer.v116_lineage_bridge')}:</span> <span className="font-mono text-cyan-300">{v116Objects.lineageStatus}</span></div>
                <div className="rounded border border-slate-800 bg-slate-950 p-2"><span className="text-slate-500">{t('run_explorer.v116_downstream_consumption')}:</span> <span className="font-mono text-cyan-300">{v116Objects.downstreamStatus}</span></div>
                <div className="rounded border border-slate-800 bg-slate-950 p-2"><span className="text-slate-500">{t('run_explorer.v116_overclaim_scan')}:</span> <span className="font-mono text-cyan-300">{v116Objects.overclaimStatus}</span></div>
                <div className="rounded border border-slate-800 bg-slate-950 p-2"><span className="text-slate-500">{t('run_explorer.v116_negative_test')}:</span> <span className="font-mono text-cyan-300">{v116Objects.negativeTestStatus}</span></div>
                <div className="rounded border border-slate-800 bg-slate-950 p-2"><span className="text-slate-500">{t('run_explorer.v116_invalidation')}:</span> <span className="font-mono text-cyan-300">{v116Objects.invalidationStatus}</span></div>
                <div className="rounded border border-slate-800 bg-slate-950 p-2"><span className="text-slate-500">{t('run_explorer.v116_requested_claim')}:</span> <span className="font-mono text-cyan-300">{v116Objects.requestedClaim}</span></div>
              </div>
              <div className="rounded border border-slate-800 bg-slate-950 p-3 text-xs text-slate-300">
                <div><span className="text-slate-500">{t('run_explorer.v116_equivalence_class')}:</span> <span className="font-mono text-cyan-300">{v116Objects.equivalenceClass}</span></div>
                <div className="mt-1">
                  <span className="text-slate-500">{t('run_explorer.v116_blocked_claims')}:</span>{' '}
                  <span className="font-mono text-cyan-300">{v116Objects.blockedClaims.length > 0 ? v116Objects.blockedClaims.join(', ') : t('run_explorer.na')}</span>
                </div>
              </div>
            </>
          )}
        </div>}
      </div>

      <div className="rounded-xl border border-slate-800 bg-slate-900 overflow-hidden" data-testid="agent-trust-panel">
        <button type="button" onClick={() => toggleSection('agentTrustPanel')} className="w-full p-4 border-b border-slate-800 flex items-center justify-between text-left hover:bg-slate-900/60">
          <h2 className="text-base font-semibold text-slate-100 inline-flex items-center gap-2">
            {sectionExpanded.agentTrustPanel ? <ChevronDown size={22} className="text-slate-300" /> : <ChevronRight size={22} className="text-slate-300" />}
            <FolderTree size={18} className="text-amber-300" />
            {t('run_explorer.agent_trust_panel_title')}
          </h2>
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">{t('run_explorer.agent_trust_panel_note')}</span>
            {renderSectionHintIcon(t('run_explorer.section_hint_agentTrustPanel'))}
          </div>
        </button>
        {sectionExpanded.agentTrustPanel && <div className="p-4 space-y-3">
          {!agentTrustPanelView ? (
            <div className="text-xs text-slate-500">{t('run_explorer.not_available')}</div>
          ) : (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2 text-xs">
                <div className="rounded border border-slate-800 bg-slate-950 p-2"><span className="text-slate-500">{t('run_explorer.agent_trust_agent_skill')}:</span> <span className="font-mono text-cyan-300">{String(agentTrustPanelView.agent_or_skill_name ?? 'NOT_AVAILABLE')}</span></div>
                <div className="rounded border border-slate-800 bg-slate-950 p-2"><span className="text-slate-500">{t('run_explorer.agent_trust_execution_plane')}:</span> <span className="font-mono text-cyan-300">{String(agentTrustPanelView.execution_plane ?? 'NOT_AVAILABLE')}</span></div>
                <div className="rounded border border-slate-800 bg-slate-950 p-2"><span className="text-slate-500">{t('run_explorer.agent_trust_panel_mode')}:</span> <span className="font-mono text-cyan-300">{String(agentTrustPanelView.view_mode ?? 'NOT_AVAILABLE')}</span></div>
                <div className="rounded border border-slate-800 bg-slate-950 p-2"><span className="text-slate-500">{t('run_explorer.agent_trust_input_contract')}:</span> <span className="font-mono text-cyan-300 break-all">{String(agentTrustPanelView.input_contract_ref ?? 'NOT_AVAILABLE')}</span></div>
                <div className="rounded border border-slate-800 bg-slate-950 p-2"><span className="text-slate-500">{t('run_explorer.agent_trust_output_contract')}:</span> <span className="font-mono text-cyan-300 break-all">{String(agentTrustPanelView.output_contract_ref ?? 'NOT_AVAILABLE')}</span></div>
                <div className="rounded border border-slate-800 bg-slate-950 p-2"><span className="text-slate-500">{t('run_explorer.agent_trust_replay_ref')}:</span> <span className="font-mono text-cyan-300 break-all">{String(agentTrustPanelView.replay_ref ?? 'NOT_AVAILABLE')}</span></div>
              </div>

              <div className="rounded border border-slate-800 bg-slate-950 p-3 text-xs text-slate-300">
                <div className="text-slate-200 mb-1">{t('run_explorer.agent_trust_evidence_refs')}</div>
                <div className="font-mono text-cyan-300 break-all">{Array.isArray(agentTrustPanelView.evidence_refs) && agentTrustPanelView.evidence_refs.length > 0 ? (agentTrustPanelView.evidence_refs as Array<unknown>).map((x) => String(x)).join(' | ') : 'NOT_AVAILABLE'}</div>
              </div>
              <div className="rounded border border-slate-800 bg-slate-950 p-3 text-xs text-slate-300">
                <div className="text-slate-200 mb-1">{t('run_explorer.agent_trust_risk_boundary_refs')}</div>
                <div className="font-mono text-cyan-300 break-all">{Array.isArray(agentTrustPanelView.risk_boundary_refs) && agentTrustPanelView.risk_boundary_refs.length > 0 ? (agentTrustPanelView.risk_boundary_refs as Array<unknown>).map((x) => String(x)).join(' | ') : 'NOT_AVAILABLE'}</div>
              </div>
            </>
          )}

              <div className="rounded border border-slate-800 bg-slate-950 p-3 text-xs text-slate-300">
                <div className="text-slate-200 mb-2">{t('run_explorer.agent_trust_action_binding')}</div>
                {!agentTrustPanelBinding ? (
                  <div className="text-slate-500">{t('run_explorer.not_available')}</div>
                ) : (
                  <>
                <div><span className="text-slate-500">{t('run_explorer.agent_trust_binding_id')}:</span> <span className="font-mono text-cyan-300 break-all">{String(agentTrustPanelBinding.binding_id ?? 'NOT_AVAILABLE')}</span></div>
                <div className="mt-1"><span className="text-slate-500">{t('run_explorer.agent_trust_requested_action')}:</span> <span className="font-mono text-cyan-300">{String(agentTrustPanelBinding.requested_action ?? 'NOT_AVAILABLE')}</span></div>
                <div className="mt-1"><span className="text-slate-500">{t('run_explorer.agent_trust_status')}:</span> <span className="font-mono text-cyan-300">{String(agentTrustPanelBinding.status ?? 'NOT_AVAILABLE')}</span></div>
                <div className="mt-3 text-slate-200">{t('run_explorer.agent_trust_mutate_command')}</div>
                <div className="mt-1 font-mono text-cyan-300 break-all whitespace-pre-line">
                  {(() => {
                    const fallbackRunDir = `artifacts/production-runs/${selectedChip?.source_dir}/${effectiveRunId}/${effectiveExecutionId}`
                    const actionCtx = resolveAgentTrustActionCommandContext(selectedExecution?.resolved_root ?? fallbackRunDir, fallbackRunDir)
                    const action = String(agentTrustPanelBinding.requested_action ?? 'request_more_evidence')
                    const bindingId = String(agentTrustPanelBinding.binding_id ?? 'auto')
                    return `python3 ${actionCtx.scriptPath} --run-dir ${actionCtx.runDirArg} --binding-id ${bindingId} --action ${action} --actor-role RELEASE_AUTHORITY`
                  })()}
                </div>
                <div className="mt-4 border-t border-slate-800 pt-3">
                  <div className="mb-2 flex items-center justify-between">
                    <div className="text-slate-200">{t('run_explorer.agent_trust_browser_native_action')}</div>
                    <button
                      type="button"
                      onClick={() => setAgentTrustApiHintOpen((prev) => !prev)}
                      aria-expanded={agentTrustApiHintOpen}
                      aria-label={t('run_explorer.agent_trust_api_hint_button_aria')}
                      className="rounded border border-slate-700 bg-slate-900/60 p-1 text-slate-300 hover:text-cyan-300"
                    >
                      <CircleHelp size={14} />
                    </button>
                  </div>
                  {agentTrustApiHintOpen && (
                    <div className="mb-3 space-y-1 rounded border border-cyan-800/40 bg-slate-950 p-3 text-xs text-cyan-200">
                      <div>{t('run_explorer.agent_trust_api_hint_meaning')}</div>
                      <div>{t('run_explorer.agent_trust_api_hint_roles_title')}</div>
                      <div>{t('run_explorer.agent_trust_api_hint_role_release')}</div>
                      <div>{t('run_explorer.agent_trust_api_hint_role_tapeout')}</div>
                      <div>{t('run_explorer.agent_trust_api_hint_role_signoff')}</div>
                      <div>{t('run_explorer.agent_trust_api_hint_role_readonly')}</div>
                      <div>{t('run_explorer.agent_trust_api_hint_apply')}</div>
                    </div>
                  )}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                    <select
                      value={agentTrustActorRole}
                      onChange={(e) => setAgentTrustActorRole(e.target.value)}
                      className="rounded border border-slate-700 bg-slate-950 px-2 py-2 text-xs text-slate-200"
                    >
                      <option value="RELEASE_AUTHORITY">{t('run_explorer.agent_trust_role_release_authority')}</option>
                      <option value="TAPEOUT_AUTHORITY">{t('run_explorer.agent_trust_role_tapeout_authority')}</option>
                      <option value="SIGNOFF_APPROVER">{t('run_explorer.agent_trust_role_signoff_approver')}</option>
                      <option value="READ_ONLY">{t('run_explorer.agent_trust_role_read_only_expect_blocked')}</option>
                    </select>
                    <input
                      value={agentTrustSessionId}
                      onChange={(e) => setAgentTrustSessionId(e.target.value)}
                      className="rounded border border-slate-700 bg-slate-950 px-2 py-2 text-xs text-slate-200"
                      placeholder={t('run_explorer.agent_trust_session_id_placeholder')}
                    />
                    <button
                      type="button"
                      onClick={() => {
                        void applyAgentTrustActionViaApi()
                      }}
                      className="rounded border border-cyan-700/50 bg-cyan-900/20 px-3 py-2 text-xs text-cyan-200 hover:bg-cyan-900/40"
                    >
                      {t('run_explorer.agent_trust_apply_action_via_api')}
                    </button>
                  </div>
                  <div className="mt-2 font-mono text-xs text-slate-300" data-testid="agent-trust-api-status">
                    {agentTrustActionStatus || t('run_explorer.agent_trust_api_idle')}
                  </div>
                </div>
              </>
            )}
          </div>

          <div className="rounded border border-slate-800 bg-slate-950 p-3 text-xs text-slate-300">
            <div className="text-slate-200 mb-2">{t('run_explorer.agent_trust_action_history')}</div>
            <div className="overflow-x-auto">
              <table className="min-w-full text-left text-xs">
                <thead className="text-slate-500 uppercase tracking-wider">
                  <tr>
                    <th className="pr-3 pb-2">{t('run_explorer.agent_trust_col_action')}</th>
                    <th className="pr-3 pb-2">{t('run_explorer.agent_trust_col_actor_role')}</th>
                    <th className="pr-3 pb-2">{t('run_explorer.agent_trust_col_result')}</th>
                    <th className="pr-3 pb-2">{t('run_explorer.agent_trust_col_time')}</th>
                  </tr>
                </thead>
                <tbody className="text-slate-300">
                  {mergedAgentTrustActionHistory.map((row, idx) => (
                    <tr key={`${row.action}-${idx}`} className="border-t border-slate-800/70">
                      <td className="py-2 pr-3 font-mono">{row.action}</td>
                      <td className="py-2 pr-3">{row.actor_role}</td>
                      <td className="py-2 pr-3 font-mono">{row.result}</td>
                      <td className="py-2 pr-3 font-mono" title={row.generated_at}>{formatLocalDateTime(row.generated_at)}</td>
                    </tr>
                  ))}
                  {mergedAgentTrustActionHistory.length === 0 && (
                    <tr className="border-t border-slate-800/70">
                      <td className="py-2 pr-3 font-mono" colSpan={4}>{t('run_explorer.agent_trust_no_action_history')}</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>}
      </div>

      <div className="rounded-xl border border-slate-800 bg-slate-900 overflow-hidden">
        <button type="button" onClick={() => toggleSection('artifactStructure')} className="w-full p-4 border-b border-slate-800 flex items-center justify-between text-left hover:bg-slate-900/60">
          <h2 className="text-base font-semibold text-slate-100 inline-flex items-center gap-2">
            {sectionExpanded.artifactStructure ? <ChevronDown size={22} className="text-slate-300" /> : <ChevronRight size={22} className="text-slate-300" />}
            <FolderTree size={18} className="text-indigo-300" />
            {t('run_explorer.structure')}
          </h2>
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">{t('run_explorer.structure_hint')}</span>
            {renderSectionHintIcon(t('run_explorer.section_hint_artifactStructure'))}
          </div>
        </button>
        {sectionExpanded.artifactStructure && (
          <div className="p-0">
            {selectedRunDetailError && (
              <div className="border-b border-amber-900/60 bg-amber-950/30 px-4 py-3 text-sm text-amber-200">
                {selectedRunDetailError}
              </div>
            )}
            <FileFamilyExplorer
              title={t('run_explorer.structure')}
              subtitle={t('run_explorer.subtitle')}
              files={fileList}
              showHeader={false}
            />
          </div>
        )}
      </div>

      {siliconContractFiles.length > 0 && (
        <div className="rounded-xl border border-slate-800 bg-slate-900 overflow-hidden">
          <button type="button" onClick={() => toggleSection('siliconContract')} className="w-full p-4 border-b border-slate-800 flex items-center justify-between text-left hover:bg-slate-900/60">
            <h2 className="text-base font-semibold text-slate-100 inline-flex items-center gap-2">
              {sectionExpanded.siliconContract ? <ChevronDown size={22} className="text-slate-300" /> : <ChevronRight size={22} className="text-slate-300" />}
              <FolderTree size={18} className="text-emerald-300" />
              {t('run_explorer.silicon_contract_structure')}
            </h2>
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-400">{t('run_explorer.structure_hint')}</span>
              {renderSectionHintIcon(t('run_explorer.section_hint_siliconContract'))}
            </div>
          </button>
          {sectionExpanded.siliconContract && <div className="grid grid-cols-1 lg:grid-cols-2 min-h-[42vh]">
            <div className="border-r border-slate-800">
              <div className="px-3 py-2 text-xs uppercase tracking-widest text-slate-500 border-b border-slate-800">{t('run_explorer.file_tree')}</div>
              <div className="max-h-[42vh] overflow-auto p-2">
                {siliconTree.length > 0 ? renderSiliconTree(siliconTree) : <div className="text-slate-500 text-sm p-2">{t('run_explorer.no_files')}</div>}
              </div>
            </div>
            <div>
              <div className="px-3 py-2 text-xs uppercase tracking-widest text-slate-500 border-b border-slate-800">{t('run_explorer.preview')}</div>
              <div className="max-h-[42vh] overflow-auto p-3">
                {!selectedSiliconFile && <div className="text-slate-500 text-sm">{t('run_explorer.select_file')}</div>}
                {selectedSiliconFile && (
                  <div className="space-y-3">
                    <div className="rounded border border-slate-800 bg-slate-950 p-2">
                      <div className="text-xs text-slate-400 mb-1">{t('run_explorer.path')}</div>
                      <div className="font-mono text-xs text-cyan-300 break-all">subject_binding/{selectedSiliconFile.relative_path}</div>
                      <div className="text-xs text-slate-400 mt-2">{t('run_explorer.size')}: {humanSize(selectedSiliconFile.size_bytes)}</div>
                    </div>
                    {selectedSiliconFile.preview_text ? (
                      <pre className="rounded border border-slate-800 bg-slate-950 p-3 text-xs text-slate-200 overflow-auto whitespace-pre-wrap">
                        {selectedSiliconFile.preview_text}
                      </pre>
                    ) : (
                      <div className="text-slate-500 text-sm">{t('run_explorer.preview_not_supported')}</div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>}
        </div>
      )}

      <div className="rounded-xl border border-slate-800 bg-slate-900 overflow-hidden">
        <button type="button" onClick={() => toggleSection('architectureGraph')} className="w-full p-4 border-b border-slate-800 flex items-center justify-between text-left hover:bg-slate-900/60">
          <h2 className="text-base font-semibold text-slate-100 inline-flex items-center gap-2">
            {sectionExpanded.architectureGraph ? <ChevronDown size={22} className="text-slate-300" /> : <ChevronRight size={22} className="text-slate-300" />}
            <FolderTree size={18} className="text-cyan-300" />
            {t('run_explorer.architecture_graph_svg')}
          </h2>
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">{t('run_explorer.architecture_graph_companion_note')}</span>
            {renderSectionHintIcon(t('run_explorer.section_hint_architectureGraph'))}
          </div>
        </button>
        {sectionExpanded.architectureGraph && <div className="p-4 space-y-3">
          {selectedArchitectureSvg ? (
            <>
              <div className="rounded border border-slate-800 bg-slate-950 p-2">
                <div className="text-xs text-slate-400 mb-1">{t('run_explorer.source_ref')}</div>
                <div className="font-mono text-xs text-cyan-300 break-all">{selectedArchitectureSvg.relative_path}</div>
              </div>
              {architectureSvgDataUrl ? (
                <div className="rounded border border-slate-800 bg-white p-2 overflow-auto">
                  <img src={architectureSvgDataUrl} alt={t('run_explorer.architecture_graph_svg')} className="max-w-full h-auto" />
                </div>
              ) : (
                <div className="rounded border border-amber-800/60 bg-amber-950/20 p-3 text-sm text-amber-200">
                  {t('run_explorer.svg_preview_unavailable')}
                </div>
              )}
            </>
          ) : (
            <div className="rounded border border-slate-800 bg-slate-950 p-3 text-sm text-slate-400">
              {t('run_explorer.no_architecture_svg_companion')}
            </div>
          )}
        </div>}
      </div>
      <div className="rounded-xl border border-slate-800 bg-slate-900 overflow-hidden">
        <button type="button" onClick={() => toggleSection('architectureBoard')} className="w-full p-4 border-b border-slate-800 flex items-center justify-between text-left hover:bg-slate-900/60">
          <h2 className="text-base font-semibold text-slate-100 inline-flex items-center gap-2">
            {sectionExpanded.architectureBoard ? <ChevronDown size={22} className="text-slate-300" /> : <ChevronRight size={22} className="text-slate-300" />}
            <FolderTree size={18} className="text-emerald-300" />
            {t('run_explorer.architecture_exploration_board')}
          </h2>
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">{t('run_explorer.architecture_exploration_note')}</span>
            {renderSectionHintIcon(t('run_explorer.section_hint_architectureBoard'))}
          </div>
        </button>
        {sectionExpanded.architectureBoard && <div className="p-4 grid grid-cols-1 lg:grid-cols-3 gap-3">
          <div className="rounded border border-slate-800 bg-slate-950 p-3">
            <div className="text-sm text-slate-200">{t('run_explorer.arch_board_hierarchy_graph')}</div>
            <div className="text-xs text-slate-400 mt-1">{t('run_explorer.arch_board_subsystems')}={architectureExploration.subsystems}; {t('run_explorer.arch_board_interfaces')}={architectureExploration.contractsCount}</div>
          </div>
          <div className="rounded border border-slate-800 bg-slate-950 p-3">
            <div className="text-sm text-slate-200">{t('run_explorer.arch_board_bus_scenario')}</div>
            <div className="text-xs text-slate-400 mt-1">{t('run_explorer.arch_board_required_bandwidth_gbps')}={architectureExploration.bandwidthGbps || t('run_explorer.na')}</div>
          </div>
          <div className="rounded border border-slate-800 bg-slate-950 p-3">
            <div className="text-sm text-slate-200">{t('run_explorer.arch_board_power_hotspot')}</div>
            <div className="text-xs text-slate-400 mt-1">{t('run_explorer.arch_board_dynamic_mw')}={architectureExploration.powerDynamicMw || t('run_explorer.na')}; {t('run_explorer.arch_board_leakage_mw')}={architectureExploration.powerLeakageMw || t('run_explorer.na')}</div>
          </div>
          <div className="rounded border border-slate-800 bg-slate-950 p-3 lg:col-span-2">
            <div className="text-sm text-slate-200">{t('run_explorer.arch_board_area_budget_top_n')}</div>
            <div className="mt-2 grid grid-cols-1 md:grid-cols-3 gap-2">
              {architectureExploration.top3Area.map((x) => (
                <div key={x.name} className="rounded border border-slate-800 bg-slate-900 p-2 text-xs text-slate-300">
                  {x.name}: <span className="font-mono text-cyan-300">{x.value || t('run_explorer.na')}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="rounded border border-slate-800 bg-slate-950 p-3">
            <div className="text-sm text-slate-200">{t('run_explorer.arch_board_ip_tradeoff_matrix')}</div>
            <div className="text-xs text-slate-400 mt-1">{t('run_explorer.arch_board_selected')}={architectureExploration.selectedCandidate}; {t('run_explorer.arch_board_candidates')}={architectureExploration.candidates.length}</div>
          </div>
          <div className="rounded border border-slate-800 bg-slate-950 p-3">
            <div className="text-sm text-slate-200">{t('run_explorer.arch_board_scenario_coverage')}</div>
            <div className="text-xs text-slate-400 mt-1">
              {!architectureBoardObjects.matrixAvailable
                ? t('run_explorer.not_available')
                : `${architectureBoardObjects.scenarioPassCount}/${architectureBoardObjects.scenarioCount} ${t('run_explorer.arch_board_scenarios_meeting')}`}
            </div>
          </div>
          <div className="rounded border border-slate-800 bg-slate-950 p-3">
            <div className="text-sm text-slate-200">{t('run_explorer.arch_board_requirement_coverage')}</div>
            <div className="text-xs text-slate-400 mt-1">
              {!architectureBoardObjects.matrixAvailable
                ? t('run_explorer.not_available')
                : `${architectureBoardObjects.requirementPassCount}/${architectureBoardObjects.requirementCount} ${t('run_explorer.arch_board_requirements_globally_passing')}`}
            </div>
          </div>
          <div className="rounded border border-slate-800 bg-slate-950 p-3">
            <div className="text-sm text-slate-200">{t('run_explorer.arch_board_candidate_scorecards')}</div>
            <div className="text-xs text-slate-400 mt-1">
              {t('run_explorer.arch_board_records')}={architectureBoardObjects.candidates.length}
              {architectureBoardObjects.candidates.length > 0
                ? `; ${t('run_explorer.arch_board_preferred')}=${architectureBoardObjects.candidates.filter((x) => String(x.recommendation) === 'PREFERRED').length}`
                : ''}
            </div>
          </div>
          <div className="rounded border border-slate-800 bg-slate-950 p-3 lg:col-span-3">
            <div className="text-sm text-slate-200">{t('run_explorer.arch_board_companion_assumptions')}</div>
            <div className="text-xs text-slate-400 mt-1">{t('run_explorer.arch_board_pre_spec')}={upstreamCompanionStatus.preSpecPresent}/{upstreamCompanionStatus.preSpecTotal}; {t('run_explorer.arch_board_hierarchy')}={upstreamCompanionStatus.hierarchyPresent}/{upstreamCompanionStatus.hierarchyTotal}</div>
            <div className="mt-2 text-xs text-slate-300">
              {t('run_explorer.arch_board_assumptions')}: {architectureExploration.assumptions.length > 0 ? architectureExploration.assumptions.join(' | ') : t('run_explorer.arch_board_none')}
            </div>
            <div className="mt-2 text-xs text-cyan-300">
              {t('run_explorer.arch_board_run_detail_manifest')}: {architectureBoardObjects.runDetailManifest ? t('run_explorer.arch_board_present') : t('run_explorer.not_available')}
            </div>
            <div className="mt-1 text-xs text-slate-500">
              {t('run_explorer.arch_board_object_version')}: {architectureBoardObjects.objectVersion}; {t('run_explorer.arch_board_generated_at')}: {architectureBoardObjects.generatedAt}
            </div>
            <div className="mt-1 text-xs text-slate-500">
              {t('run_explorer.arch_board_source_run')}: {architectureBoardObjects.sourceRunId}/{architectureBoardObjects.sourceDateTime}; {t('run_explorer.arch_board_compatibility_mode')}: {architectureBoardObjects.compatibilityMode}
            </div>
            <div className="mt-3 rounded border border-slate-700 bg-slate-900/80 p-2 text-xs text-slate-300">
              <div className="font-semibold text-cyan-300">RUN_INPUT_SOURCE_COVERAGE_GATE</div>
              {!runInputCoverageGate ? (
                <div className="mt-1 text-slate-500">{t('run_explorer.not_available')}</div>
              ) : (
                <div className="mt-1 grid gap-1 md:grid-cols-2">
                  <div>verdict: <span className="font-mono">{String(runInputCoverageGate.verdict ?? '-')}</span></div>
                  <div>run_admission_status: <span className="font-mono">{String(runInputCoverageGate.run_admission_status ?? '-')}</span></div>
                  <div>total_01_inputs_files: <span className="font-mono">{String((runInputCoverageGate.summary as Record<string, unknown> | undefined)?.total_run_input_files ?? '-')}</span></div>
                  <div>mapped_source_count: <span className="font-mono">{String((runInputCoverageGate.summary as Record<string, unknown> | undefined)?.mapped_to_chips_source ?? '-')}</span></div>
                  <div>digest_match_count: <span className="font-mono">{String((runInputCoverageGate.summary as Record<string, unknown> | undefined)?.digest_match ?? '-')}</span></div>
                  <div>missing_source_count: <span className="font-mono">{String((runInputCoverageGate.summary as Record<string, unknown> | undefined)?.missing_source ?? '-')}</span></div>
                  <div>digest_mismatch_count: <span className="font-mono">{String((runInputCoverageGate.summary as Record<string, unknown> | undefined)?.digest_mismatch ?? '-')}</span></div>
                  <div>recoverable_count: <span className="font-mono">{String((runInputCoverageGate.summary as Record<string, unknown> | undefined)?.recoverable_missing_source ?? '-')}</span></div>
                  <div className="md:col-span-2 break-all">source_coverage_manifest_path: <span className="font-mono">{String(runInputCoverageGate.source_coverage_manifest_path ?? '-')}</span></div>
                  <div className="md:col-span-2 break-all">recovery_manifest_path: <span className="font-mono">{String(runInputCoverageGate.recovery_manifest_path ?? '-')}</span></div>
                </div>
              )}
            </div>
            <div className="mt-3 rounded border border-slate-700 bg-slate-900/80 p-2 text-xs text-slate-300">
              <div className="font-semibold text-cyan-300">{t('run_explorer.run_topology_policy_title')}</div>
              <div className="mt-1 grid gap-1 md:grid-cols-2">
                <div>{t('run_explorer.topology_dependent_prefixes')}: <span className="font-mono">{String((runTopologyAndVerification.runTopologyPolicy as Record<string, unknown>)?.prefix_counts_are_topology_dependent ?? false)}</span></div>
                <div>{t('run_explorer.topology_prefix_authority')}: <span className="font-mono">{String((runTopologyAndVerification.runTopologyPolicy as Record<string, unknown>)?.fixed_highest_prefix_is_not_authoritative ?? false)}</span></div>
                <div className="md:col-span-2 break-all">{t('run_explorer.topology_reports_policy')}: <span className="font-mono">{String((runTopologyAndVerification.runTopologyPolicy as Record<string, unknown>)?.reports_dir_must_follow_materialized_topology ?? false)}</span></div>
              </div>
            </div>
            <div className="mt-3 rounded border border-slate-700 bg-slate-900/80 p-2 text-xs text-slate-300">
              <div className="font-semibold text-cyan-300">{t('run_explorer.verification_lane_title')}</div>
              <div className="mt-1 grid gap-1 md:grid-cols-2">
                <div>{t('run_explorer.verification_lane_required')}: <span className="font-mono">{String(verificationSourceLane?.required_by_policy ?? false)}</span></div>
                <div>{t('run_explorer.verification_lane_source_root')}: <span className="font-mono">{String(verificationSourceLane?.source_root ?? '-')}</span></div>
                <div>{t('run_explorer.verification_lane_logical_root')}: <span className="font-mono">{String(verificationSourceLane?.logical_input_root ?? '-')}</span></div>
                <div>{t('run_explorer.verification_lane_physical_root')}: <span className="font-mono">{String(verificationSourceLane?.physical_01_inputs_root ?? '-')}</span></div>
                <div className="md:col-span-2">{t('run_explorer.verification_lane_consumers')}: <span className="font-mono">{verificationConsumerStages.length > 0 ? verificationConsumerStages.map((x) => String(x)).join(', ') : '-'}</span></div>
                <div>{t('upstream_board.expected_files')}: <span className="font-mono">{verificationExpectedFiles.length}</span></div>
                <div>{t('upstream_board.missing_files')}: <span className="font-mono">{verificationMissingFiles.length}</span></div>
                <div className="md:col-span-2">
                  <div className="font-semibold text-slate-200">{t('upstream_board.expected_files')}</div>
                  <ul className="mt-1 space-y-1">
                    {verificationExpectedFiles.length > 0
                      ? verificationExpectedFiles.map((path) => (
                          <li key={`run-detail-verification-expected-${String(path)}`} className="break-all font-mono text-[11px] text-cyan-100">
                            - {String(path)}
                          </li>
                        ))
                      : <li className="font-mono text-[11px] text-slate-500">- none</li>}
                  </ul>
                </div>
                <div className="md:col-span-2">
                  <div className="font-semibold text-slate-200">{t('upstream_board.missing_files')}</div>
                  <ul className="mt-1 space-y-1">
                    {verificationMissingFiles.length > 0
                      ? verificationMissingFiles.map((path) => (
                          <li key={`run-detail-verification-missing-${String(path)}`} className="break-all font-mono text-[11px] text-amber-200">
                            - {String(path)}
                          </li>
                        ))
                      : <li className="font-mono text-[11px] text-slate-500">- none</li>}
                  </ul>
                </div>
                <div className="md:col-span-2">{t('run_explorer.verification_lane_materialized')}: <span className="font-mono">{String(verificationSourceLane?.materialized ?? false)}</span></div>
              </div>
            </div>
          </div>
          <div className="rounded border border-slate-800 bg-slate-950 p-3 lg:col-span-3">
            <div className="text-sm text-slate-200">{t('run_explorer.arch_board_scenario_drilldown')}</div>
            {architectureBoardObjects.scenarioResults.length === 0 ? (
              <div className="mt-2 text-xs text-slate-500">{t('run_explorer.not_available')}</div>
            ) : (
              <div className="mt-2 overflow-x-auto">
                <table className="min-w-full text-left text-xs">
                  <thead className="text-slate-500 uppercase tracking-wider">
                    <tr>
                      <th className="pr-3 pb-2">{t('run_explorer.arch_board_scenario_id')}</th>
                      <th className="pr-3 pb-2">{t('run_explorer.arch_board_verdict')}</th>
                      <th className="pr-3 pb-2">{t('run_explorer.arch_board_verdict_rule')}</th>
                      <th className="pr-3 pb-2">{t('run_explorer.arch_board_reason')}</th>
                      <th className="pr-3 pb-2">{t('run_explorer.arch_board_failed_requirements')}</th>
                      <th className="pr-3 pb-2">{t('run_explorer.arch_board_failed_assumptions')}</th>
                      <th className="pr-3 pb-2">{t('run_explorer.arch_board_evidence_count')}</th>
                    </tr>
                  </thead>
                  <tbody className="text-slate-300">
                    {architectureBoardObjects.scenarioResults.slice(0, 10).map((row, idx) => (
                      <tr key={`sc-row-${idx}`} className="border-t border-slate-800/70">
                        <td className="py-2 pr-3 font-mono">{String(row.scenario_id ?? '-')}</td>
                        <td className="py-2 pr-3 font-mono">{String(row.verdict ?? '-')}</td>
                        <td className="py-2 pr-3 font-mono">{String(row.verdict_rule_id ?? '-')}</td>
                        <td className="py-2 pr-3">{String(row.verdict_reason ?? '-')}</td>
                        <td className="py-2 pr-3 font-mono">
                          {Array.isArray(row.failed_requirements) && row.failed_requirements.length > 0
                            ? row.failed_requirements.map((x) => String(x)).join(', ')
                            : '-'}
                        </td>
                        <td className="py-2 pr-3 font-mono">
                          {Array.isArray(row.failed_assumptions) && row.failed_assumptions.length > 0
                            ? row.failed_assumptions.map((x) => String(x)).join(', ')
                            : '-'}
                        </td>
                        <td className="py-2 pr-3 font-mono">{Array.isArray(row.evidence_refs) ? row.evidence_refs.length : 0}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
          <div className="rounded border border-slate-800 bg-slate-950 p-3 lg:col-span-3">
            <div className="text-sm text-slate-200">{t('run_explorer.arch_board_requirement_drilldown')}</div>
            {architectureBoardObjects.requirementResults.length === 0 ? (
              <div className="mt-2 text-xs text-slate-500">{t('run_explorer.not_available')}</div>
            ) : (
              <div className="mt-2 overflow-x-auto">
                <table className="min-w-full text-left text-xs">
                  <thead className="text-slate-500 uppercase tracking-wider">
                    <tr>
                      <th className="pr-3 pb-2">{t('run_explorer.arch_board_requirement_id')}</th>
                      <th className="pr-3 pb-2">{t('run_explorer.arch_board_verdict')}</th>
                      <th className="pr-3 pb-2">{t('run_explorer.arch_board_verdict_rule')}</th>
                      <th className="pr-3 pb-2">{t('run_explorer.arch_board_reason')}</th>
                      <th className="pr-3 pb-2">{t('run_explorer.arch_board_failed_assumptions')}</th>
                      <th className="pr-3 pb-2">{t('run_explorer.arch_board_evidence_count')}</th>
                    </tr>
                  </thead>
                  <tbody className="text-slate-300">
                    {architectureBoardObjects.requirementResults.slice(0, 10).map((row, idx) => (
                      <tr key={`req-row-${idx}`} className="border-t border-slate-800/70">
                        <td className="py-2 pr-3 font-mono">{String(row.requirement_id ?? '-')}</td>
                        <td className="py-2 pr-3 font-mono">{String(row.verdict ?? '-')}</td>
                        <td className="py-2 pr-3 font-mono">{String(row.verdict_rule_id ?? '-')}</td>
                        <td className="py-2 pr-3">{String(row.verdict_reason ?? '-')}</td>
                        <td className="py-2 pr-3 font-mono">
                          {Array.isArray(row.failed_assumptions) && row.failed_assumptions.length > 0
                            ? row.failed_assumptions.map((x) => String(x)).join(', ')
                            : '-'}
                        </td>
                        <td className="py-2 pr-3 font-mono">{Array.isArray(row.evidence_refs) ? row.evidence_refs.length : 0}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>}
      </div>

      <div className="rounded-xl border border-slate-800 bg-slate-900 overflow-hidden">
        <button type="button" onClick={() => toggleSection('skillUsage')} className="w-full p-4 border-b border-slate-800 flex items-center justify-between text-left hover:bg-slate-900/60">
          <h2 className="text-base font-semibold text-slate-100 inline-flex items-center gap-2">
            {sectionExpanded.skillUsage ? <ChevronDown size={22} className="text-slate-300" /> : <ChevronRight size={22} className="text-slate-300" />}
            <FolderTree size={18} className="text-fuchsia-300" />
            {t('run_explorer.skill_usage_structure')}
          </h2>
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">{t('run_explorer.structure_hint')}</span>
            {renderSectionHintIcon(t('run_explorer.section_hint_skillUsage'))}
          </div>
        </button>
        {sectionExpanded.skillUsage && <><div className="px-4 py-3 border-b border-slate-800 bg-slate-950/40">
          <div className="text-xs text-slate-400">{t('run_explorer.skill_usage_summary_title')}</div>
          <div className="mt-1 flex flex-wrap gap-2 text-xs font-mono">
            <span className="rounded border border-slate-700 bg-slate-900 px-2 py-0.5 text-slate-200">{t('run_explorer.skill_usage_total')}: {skillUsageSummary.total}</span>
            <span className="rounded border border-cyan-700/40 bg-cyan-900/20 px-2 py-0.5 text-cyan-200">{t('run_explorer.skill_usage_execution')}: {skillUsageSummary.execution}</span>
            <span className="rounded border border-emerald-700/40 bg-emerald-900/20 px-2 py-0.5 text-emerald-200">{t('run_explorer.skill_usage_governance')}: {skillUsageSummary.governance}</span>
            <span className="rounded border border-amber-700/40 bg-amber-900/20 px-2 py-0.5 text-amber-200">{t('run_explorer.skill_usage_decision_tree')}: {skillUsageSummary.decisionTree}</span>
            <span className={`rounded border px-2 py-0.5 ${
              skillUsageSummary.routeAUsed
                ? 'border-emerald-700/40 bg-emerald-900/20 text-emerald-200'
                : 'border-rose-700/40 bg-rose-900/20 text-rose-200'
            }`}>
              {t('run_explorer.skill_usage_route_a')}: {skillUsageSummary.routeAUsed ? t('run_explorer.arch_board_present') : 'NOT_AVAILABLE'}
            </span>
          </div>
          <div className="mt-2 flex flex-wrap gap-2 text-[11px] font-mono">
            <span className={`rounded border px-2 py-0.5 ${skillUsageSummary.coverage.v1_0 ? 'border-emerald-700/40 bg-emerald-900/20 text-emerald-200' : 'border-rose-700/40 bg-rose-900/20 text-rose-200'}`}>PRD v1.0: {skillUsageSummary.coverage.v1_0 ? t('run_explorer.arch_board_present') : 'NOT_AVAILABLE'}</span>
            <span className={`rounded border px-2 py-0.5 ${skillUsageSummary.coverage.v0_9 ? 'border-emerald-700/40 bg-emerald-900/20 text-emerald-200' : 'border-rose-700/40 bg-rose-900/20 text-rose-200'}`}>PRD v0.9: {skillUsageSummary.coverage.v0_9 ? t('run_explorer.arch_board_present') : 'NOT_AVAILABLE'}</span>
            <span className={`rounded border px-2 py-0.5 ${skillUsageSummary.coverage.v1_3 ? 'border-emerald-700/40 bg-emerald-900/20 text-emerald-200' : 'border-rose-700/40 bg-rose-900/20 text-rose-200'}`}>PRD v1.3: {skillUsageSummary.coverage.v1_3 ? t('run_explorer.arch_board_present') : 'NOT_AVAILABLE'}</span>
            <span className={`rounded border px-2 py-0.5 ${skillUsageSummary.coverage.v1_9 ? 'border-emerald-700/40 bg-emerald-900/20 text-emerald-200' : 'border-rose-700/40 bg-rose-900/20 text-rose-200'}`}>PRD v1.9: {skillUsageSummary.coverage.v1_9 ? t('run_explorer.arch_board_present') : 'NOT_AVAILABLE'}</span>
            <span className={`rounded border px-2 py-0.5 ${skillUsageSummary.coverage.v1_1_v1_2 ? 'border-emerald-700/40 bg-emerald-900/20 text-emerald-200' : 'border-rose-700/40 bg-rose-900/20 text-rose-200'}`}>PRD v1.1/v1.2: {skillUsageSummary.coverage.v1_1_v1_2 ? t('run_explorer.arch_board_present') : 'NOT_AVAILABLE'}</span>
          </div>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 min-h-[42vh]">
          <div className="border-r border-slate-800">
            <div className="px-3 py-2 text-xs uppercase tracking-widest text-slate-500 border-b border-slate-800">{t('run_explorer.file_tree')}</div>
            <div className="max-h-[42vh] overflow-auto p-2">
              {skillTree.length > 0 ? renderSkillTree(skillTree) : <div className="text-slate-500 text-sm p-2">{t('run_explorer.no_skill_usage')}</div>}
            </div>
          </div>
          <div>
            <div className="px-3 py-2 text-xs uppercase tracking-widest text-slate-500 border-b border-slate-800">{t('run_explorer.preview')}</div>
            <div className="max-h-[42vh] overflow-auto p-3">
              {!selectedSkillFile && <div className="text-slate-500 text-sm">{t('run_explorer.select_file')}</div>}
              {selectedSkillFile && (
                <div className="space-y-3">
                  <div className="rounded border border-slate-800 bg-slate-950 p-2">
                    <div className="text-xs text-slate-400 mb-1">{t('run_explorer.path')}</div>
                    <div className="font-mono text-xs text-cyan-300 break-all">{selectedSkillFile.relative_path}</div>
                    <div className="text-xs text-slate-400 mt-2">{t('run_explorer.size')}: {humanSize(selectedSkillFile.size_bytes)}</div>
                  </div>
                  {selectedSkillFile.preview_text ? (
                    <pre className="rounded border border-slate-800 bg-slate-950 p-3 text-xs text-slate-200 overflow-auto whitespace-pre-wrap">
                      {selectedSkillFile.preview_text}
                    </pre>
                  ) : (
                    <div className="text-slate-500 text-sm">{t('run_explorer.preview_not_supported')}</div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div></>}
      </div>
    </div>
  )
}
