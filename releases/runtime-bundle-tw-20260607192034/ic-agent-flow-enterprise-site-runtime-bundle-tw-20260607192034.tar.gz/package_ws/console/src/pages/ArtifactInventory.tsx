import { AlertTriangle, Ban, CheckCircle2, Database, HelpCircle } from 'lucide-react'
import { useMemo } from 'react'
import { useLocation } from 'react-router-dom'
import { useNavigate } from 'react-router-dom'
import { useTranslation } from '../contexts/i18n'
import { parseMode, sortChipsForMode } from '../hooks/evidenceSummary'
import { useProductionRunsInventory } from '../hooks/useProductionRunsInventory'

export default function ArtifactInventory() {
  const location = useLocation()
  const { t } = useTranslation()
  const mode = useMemo(() => parseMode(location.search), [location.search])
  const params = useMemo(() => new URLSearchParams(location.search), [location.search])
  const focusChip = params.get('chip') ?? ''
  const focusRun = params.get('run') ?? ''
  const focusExecution = params.get('execution') ?? ''
  const { data, loading, error } = useProductionRunsInventory({ layeredWithRuns: true })
  const navigate = useNavigate()

  if (loading) return <div className="text-slate-400 p-6">{t('common.loading')}</div>
  if (error) return <div className="text-rose-400 p-6">{t('common.error')}: {error}</div>

  const portfolio = sortChipsForMode(data?.chips ?? [], mode)

  type Verdict = 'PASS' | 'WARN' | 'BLOCKED' | 'UNKNOWN'
  type EvidenceSignal = { verdict: Exclude<Verdict, 'PASS'>; relativePath: string; status: string; executionId: string }

  function classifyExecution(
    files: Array<{ relative_path: string; kind: string; preview_text?: string | null }>,
    verdictHint?: Verdict,
  ): { verdict: Verdict; signals: Array<{ relativePath: string; status: string }> } {
    if ((!files || files.length === 0) && verdictHint) {
      return { verdict: verdictHint, signals: [] }
    }
    const statuses: Array<{ relativePath: string; status: string }> = []
    let passTokenInLog = false
    for (const file of files) {
      if (file.kind !== 'file') continue
      const preview = file.preview_text ?? ''
      if ((/normalized\..*\.json$/i.test(file.relative_path) || /21_dashboard_objects\/.*\.json$/i.test(file.relative_path)) && preview.trim().startsWith('{')) {
        try {
          const parsed = JSON.parse(preview) as { status?: string }
          if (parsed.status) statuses.push({ relativePath: file.relative_path, status: String(parsed.status).toUpperCase() })
        } catch {
          // ignore invalid JSON preview
        }
      }
      if (/raw\.log$/i.test(file.relative_path) && /REAL_RUN_PASS|_PASS\b| PASS\b/i.test(preview)) {
        passTokenInLog = true
      }
    }
    if (statuses.some((s) => ['FAIL', 'BLOCKED', 'ERROR'].includes(s.status))) return { verdict: 'BLOCKED', signals: statuses }
    if (statuses.some((s) => ['NOT_CHECKED', 'WARNING', 'WARN', 'PENDING', 'UNVALIDATED', 'PARTIAL'].includes(s.status))) return { verdict: 'WARN', signals: statuses }
    if (statuses.some((s) => ['PASS', 'OK'].includes(s.status)) || passTokenInLog) return { verdict: 'PASS', signals: statuses }
    return { verdict: 'UNKNOWN', signals: statuses }
  }

  const chipRows = portfolio.map((chip) => {
    let pass = 0
    let warn = 0
    let blocked = 0
    let unknown = 0
    const evidenceSignals: EvidenceSignal[] = []

    for (const run of chip.runs) {
      for (const execution of run.executions) {
        const classified = classifyExecution(execution.files, execution.verdict as Verdict | undefined)
        const effectiveVerdict = execution.effective_dashboard_status ?? classified.verdict
        if (effectiveVerdict === 'PASS') pass += 1
        if (effectiveVerdict === 'WARN') warn += 1
        if (effectiveVerdict === 'BLOCKED') blocked += 1
        if (effectiveVerdict === 'UNKNOWN') unknown += 1
        if (effectiveVerdict !== 'PASS') {
          const matched = classified.signals.filter((s) => {
            if (classified.verdict === 'BLOCKED') return ['FAIL', 'BLOCKED', 'ERROR'].includes(s.status)
            if (classified.verdict === 'WARN') return ['NOT_CHECKED', 'WARNING', 'WARN', 'PENDING', 'UNVALIDATED', 'PARTIAL'].includes(s.status)
            return false
          })
          if (matched.length > 0) {
            evidenceSignals.push(
              ...matched.slice(0, 2).map((m) => ({
                verdict: classified.verdict as Exclude<Verdict, 'PASS'>,
                relativePath: m.relativePath,
                status: m.status,
                executionId: execution.execution_id,
              })),
            )
          } else if (classified.verdict === 'UNKNOWN') {
            evidenceSignals.push({
              verdict: 'UNKNOWN',
              relativePath: '-',
              status: 'NO_NORMALIZED_STATUS',
              executionId: execution.execution_id,
            })
          }
        }
      }
    }

    return {
      ...chip,
      summary: { pass, warn, blocked, unknown, total: pass + warn + blocked + unknown },
      topSignals: evidenceSignals.slice(0, 4),
    }
  })


  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between border-b border-slate-800/50 pb-4">
        <div>
          <h1 className="text-3xl font-semibold tracking-tight text-white">{t('artifacts.title')}</h1>
          <p className="text-sm text-slate-400">{t('artifacts.subtitle')}</p>
        </div>
      </div>

      {focusChip && focusRun && focusExecution && (
        <div className="rounded-xl border border-cyan-900/50 bg-cyan-950/20 p-4">
          <div className="text-xs uppercase tracking-widest text-cyan-300 mb-2">{t('artifacts.focused_record')}</div>
          <div className="text-sm text-slate-200 font-mono break-all">
            {focusChip} / {focusRun} / {focusExecution}
          </div>
          <div className="mt-3">
            <button
              type="button"
              className="rounded-md border border-cyan-700/60 bg-cyan-900/30 px-3 py-1.5 text-xs text-cyan-200 hover:bg-cyan-900/50"
              onClick={() => navigate(`/run/${focusChip}?mode=${mode}&run=${encodeURIComponent(focusRun)}&execution=${encodeURIComponent(focusExecution)}`)}
            >
              {t('artifacts.open_focused_execution')}
            </button>
          </div>
        </div>
      )}

      <div className="rounded-xl border border-slate-800 bg-slate-900 overflow-hidden">
        <div className="flex items-center justify-between border-b border-slate-800 p-4">
          <h2 className="text-base font-semibold text-slate-100 flex items-center gap-2">
            <Database size={18} className="text-indigo-400" />
            {t('dash.inventory_table')}
          </h2>
          <span className="text-sm text-slate-300">{chipRows.length} {t('dash.active_chips')}</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-500 uppercase tracking-wider bg-slate-950/30">
                <th className="p-4 font-semibold">{t('table.chip_id')}</th>
                <th className="p-4 font-semibold">{t('table.readiness')}</th>
                <th className="p-4 font-semibold">{t('artifacts.verdict_summary')}</th>
                <th className="p-4 font-semibold">
                  <span className="inline-flex items-center gap-1">
                    {t('artifacts.evidence_signal')}
                    <HelpCircle size={14} className="text-slate-500" />
                  </span>
                </th>
                <th className="p-4 font-semibold">{t('table.source')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {chipRows.map((f, i) => (
                <tr
                  key={i}
                  className="hover:bg-slate-800/40 transition-colors cursor-pointer"
                  onClick={() => {
                    const latestRun = f.runs[f.runs.length - 1]
                    const latestExecution = latestRun?.executions[latestRun.executions.length - 1]
                    const runParam = latestRun ? `&run=${encodeURIComponent(latestRun.run_id)}` : ''
                    const execParam = latestExecution ? `&execution=${encodeURIComponent(latestExecution.execution_id)}` : ''
                    navigate(`/run/${encodeURIComponent(f.chip_id)}?mode=${mode}${runParam}${execParam}`)
                  }}
                >
                  <td className="p-4 text-slate-200 font-mono">{f.chip_id}</td>
                  <td className="p-4 text-slate-200 font-mono">{f.summary.total} runs</td>
                  <td className="p-4 text-slate-300">
                    <div className="flex flex-wrap gap-2 text-xs">
                      <span className="inline-flex items-center gap-1 rounded border border-emerald-700/40 bg-emerald-900/20 px-2 py-0.5 text-emerald-300">
                        <CheckCircle2 size={12} /> P:{f.summary.pass}
                      </span>
                      <span className="inline-flex items-center gap-1 rounded border border-amber-700/40 bg-amber-900/20 px-2 py-0.5 text-amber-300">
                        <AlertTriangle size={12} /> W:{f.summary.warn}
                      </span>
                      <span className="inline-flex items-center gap-1 rounded border border-rose-700/40 bg-rose-900/20 px-2 py-0.5 text-rose-300">
                        <Ban size={12} /> B:{f.summary.blocked}
                      </span>
                      <span className="inline-flex items-center gap-1 rounded border border-slate-700/60 bg-slate-900/40 px-2 py-0.5 text-slate-300">
                        U:{f.summary.unknown}
                      </span>
                    </div>
                  </td>
                  <td className="p-4 text-xs text-slate-300">
                    {f.topSignals.length > 0 ? (
                      <div className="space-y-1 max-h-28 overflow-y-auto pr-1">
                        {f.topSignals.map((signal, idx) => (
                          <div key={`${signal.executionId}-${signal.relativePath}-${idx}`} className="font-mono break-all">
                            [{signal.verdict}] {signal.status} @ {signal.relativePath} ({signal.executionId})
                          </div>
                        ))}
                      </div>
                    ) : (
                      <span className="text-slate-500">{t('artifacts.no_signal')}</span>
                    )}
                  </td>
                  <td className="p-4 text-slate-400 font-mono text-xs">{f.source_dir ?? '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  )
}
