import { useCallback, useEffect, useState } from 'react'
import { Clipboard, FileCheck2, GitBranch } from 'lucide-react'
import { Link, useSearchParams } from 'react-router-dom'
import FileFamilyExplorer, { type FileFamilyEntry } from '../components/FileFamilyExplorer'
import HeaderIcon from '../components/HeaderIcon'
import UpstreamTruthFlowBoard from '../components/UpstreamTruthFlowBoard'
import type { UpstreamTruthFlowNode } from '../components/UpstreamTruthFlowBoard'
import { useTranslation } from '../contexts/i18n'

type UpstreamChipOption = {
  chip_id: string
  scope_type?: string
  source_dir?: string
  requirement_adjudication_ready?: boolean
}

type AdjudicationContext = {
  status: string
  chip_id: string
  requirement_item: {
    draft_status?: string
    requirement_items?: Array<{ requirement_id?: string; title?: string; ambiguity_status?: string; ambiguity_note?: string }>
  }
  review_package: {
    status?: string
    requirement_item_ref?: string
    source_session_ref?: string
    intake_session_id?: string
  }
  adjudication_template: {
    conditions_suggested?: string[]
    status?: string
  }
  builder_handoff: {
    handoff_status?: string
    graph_draft_ref?: string
  }
  adjudication_record?: {
    decision_outcome?: string
    decision_rationale?: string
    authority_signer?: string
    conditions?: string[]
    status?: string
  } | null
  scope_type?: string
  upstream_operation_id?: string
  upstream_truth_flow?: UpstreamTruthFlowNode[]
  upstream_node_status?: UpstreamTruthFlowNode[]
}

const preHandoffNodeIds = new Set([
  'requirement_intake',
  'requirement_adjudication',
  'graph_draft_check',
  'graph_validation',
  'freeze',
  'generation_plan',
  'rtl_generation',
])

export default function RequirementAdjudicationPage() {
  const { t } = useTranslation()
  const [searchParams, setSearchParams] = useSearchParams()
  const chipId = (searchParams.get('chip') || '').trim()
  const [chipOptions, setChipOptions] = useState<UpstreamChipOption[]>([])
  const [chipOptionsLoading, setChipOptionsLoading] = useState(true)
  const [chipOptionsError, setChipOptionsError] = useState('')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [context, setContext] = useState<AdjudicationContext | null>(null)
  const [decisionOutcome, setDecisionOutcome] = useState('approve')
  const [decisionRationale, setDecisionRationale] = useState('')
  const [authoritySigner, setAuthoritySigner] = useState('')
  const [conditionsText, setConditionsText] = useState('')
  const [submitState, setSubmitState] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle')
  const [submitMessage, setSubmitMessage] = useState('')
  const [copyPromptState, setCopyPromptState] = useState<'idle' | 'success' | 'error'>('idle')
  const [upstreamFiles, setUpstreamFiles] = useState<FileFamilyEntry[]>([])

  useEffect(() => {
    let cancelled = false
    async function loadUpstreamChips() {
      setChipOptionsLoading(true)
      setChipOptionsError('')
      try {
        const response = await fetch('/api/intake/chips', { cache: 'no-store' })
        const payload = await response.json()
        if (!response.ok) {
          throw new Error(payload?.error ?? `http_${response.status}`)
        }
        if (!cancelled) {
          setChipOptions(Array.isArray(payload?.chips) ? payload.chips : [])
        }
      } catch (fetchError) {
        if (!cancelled) {
          setChipOptionsError(fetchError instanceof Error ? fetchError.message : 'unknown_error')
          setChipOptions([])
        }
      } finally {
        if (!cancelled) setChipOptionsLoading(false)
      }
    }
    void loadUpstreamChips()
    return () => {
      cancelled = true
    }
  }, [])

  const loadContext = useCallback(async (activeChipId: string) => {
    if (!activeChipId) {
      setLoading(false)
      setError('')
      setContext(null)
      return
    }
    setLoading(true)
    setError('')
    try {
      const response = await fetch(`/api/intake/adjudication?chip_id=${encodeURIComponent(activeChipId)}`)
      const payload = await response.json()
      if (!response.ok) {
        throw new Error(payload?.error ?? `http_${response.status}`)
      }
      const resolvedChipId = typeof payload?.chip_id === 'string' ? payload.chip_id.trim() : ''
      if (resolvedChipId && resolvedChipId !== activeChipId) {
        const next = new URLSearchParams(searchParams)
        next.set('chip', resolvedChipId)
        setSearchParams(next, { replace: true })
      }
      setContext(payload)
      setDecisionOutcome(payload?.adjudication_record?.decision_outcome ?? 'approve')
      setDecisionRationale(payload?.adjudication_record?.decision_rationale ?? '')
      setAuthoritySigner(payload?.adjudication_record?.authority_signer ?? '')
      setConditionsText(Array.isArray(payload?.adjudication_record?.conditions) ? payload.adjudication_record.conditions.join('\n') : '')
    } catch (fetchError) {
      setError(fetchError instanceof Error ? fetchError.message : 'unknown_error')
    } finally {
      setLoading(false)
    }
  }, [searchParams, setSearchParams])

  useEffect(() => {
    void loadContext(chipId)
  }, [chipId, loadContext])

  const loadUpstreamFiles = useCallback(async (activeChipId: string) => {
    if (!activeChipId) {
      setUpstreamFiles([])
      return
    }
    try {
      const response = await fetch(`/api/intake/upstream-files?chip_id=${encodeURIComponent(activeChipId)}`, { cache: 'no-store' })
      const payload = await response.json()
      if (!response.ok) throw new Error(payload?.error ?? `http_${response.status}`)
      setUpstreamFiles(Array.isArray(payload?.files) ? payload.files : [])
    } catch {
      setUpstreamFiles([])
    }
  }, [])

  useEffect(() => {
    void loadUpstreamFiles(chipId)
  }, [chipId, loadUpstreamFiles])

  function selectChip(nextChipId: string) {
    if (!nextChipId) return
    const next = new URLSearchParams(searchParams)
    next.set('chip', nextChipId)
    setSearchParams(next)
  }

  async function submitDecision() {
    if (!chipId || submitState === 'submitting') return
    setSubmitState('submitting')
    setSubmitMessage('')
    try {
      const response = await fetch('/api/intake/adjudication', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chip_id: chipId,
          decision_outcome: decisionOutcome,
          decision_rationale: decisionRationale,
          authority_signer: authoritySigner,
          conditions: conditionsText
            .split('\n')
            .map((line) => line.trim())
            .filter(Boolean),
        }),
      })
      const payload = await response.json()
      if (!response.ok) {
        throw new Error(payload?.error ?? `http_${response.status}`)
      }
      setSubmitState('success')
      setSubmitMessage(`${t('req_adj.submit_success')}: ${payload.review_package_status} / ${payload.handoff_status}`)
      await Promise.all([
        loadContext(chipId),
        loadUpstreamFiles(chipId),
      ])
    } catch (submitError) {
      setSubmitState('error')
      setSubmitMessage(`${t('req_adj.submit_error')}: ${submitError instanceof Error ? submitError.message : 'unknown_error'}`)
    }
  }

  function buildHandoffPrompt(activeContext: AdjudicationContext): string {
    const sessionId = activeContext.review_package.intake_session_id
      || activeContext.review_package.source_session_ref?.split('/').filter(Boolean).pop()
      || '-'
    const conditions = conditionsText
      .split('\n')
      .map((line) => line.trim())
      .filter(Boolean)
    return [
      'Task: Continue CHIP_UPSTREAM flow after requirement adjudication (Codex CLI GPT-5.5 execution contract)',
      '',
      'Execution profile:',
      '- model_hint: gpt-5.5',
      '- mode: local codex cli agent',
      '- policy: fail-closed, machine-readable outputs only',
      '- operator_runbook: package_ws/docs/governance/ops/prd-v0.9-routine-b-operator-runbook.v0.1.md',
      '',
      'Scope:',
      '- scope_type: CHIP_UPSTREAM',
      `- chip_id: ${activeContext.chip_id}`,
      `- intake_session_id: ${sessionId}`,
      `- upstream_operation_id: ${activeContext.upstream_operation_id ?? '-'}`,
      '',
      'Authority decision just recorded or ready to record:',
      `- decision_outcome: ${decisionOutcome}`,
      `- decision_rationale: ${decisionRationale || '-'}`,
      `- authority_signer: ${authoritySigner || '-'}`,
      `- conditions: ${conditions.length ? conditions.join(' | ') : '-'}`,
      '',
      'Canonical refs (must read first):',
      `- chips/${activeContext.chip_id}/specs/requirement_item.json`,
      `- chips/${activeContext.chip_id}/specs/requirement_item_review_package.json`,
      `- chips/${activeContext.chip_id}/specs/requirement_item_adjudication_record.json`,
      `- chips/${activeContext.chip_id}/architecture/builder_validation_handoff.json`,
      `- chips/${activeContext.chip_id}/specs/intake/${sessionId}/intake_session_record.json`,
      `- chips/${activeContext.chip_id}/specs/intake/${sessionId}/template_resolution_record.json`,
      `- chips/${activeContext.chip_id}/governance/upstream_alignment_map.json`,
      `- chips/${activeContext.chip_id}/governance/upstream_alignment_map.md`,
      '',
      'Preflight checks (must pass before mutations):',
      '1. Resolve all canonical refs and fail if any required ref is missing.',
      '2. Verify chip_id/session_id in refs match scope values exactly.',
      '3. Verify decision outcome is one of: approve, approve_with_conditions, request_more_evidence, reject.',
      '3.1 Enforce PASS criteria for every upstream node: required JSON records + full node output files must exist, and every previous upstream node must already be PASS.',
      '3.2 If a previous node is not PASS, fix that previous node first; do not advance or mark later nodes as complete.',
      '4. OpenAI execution preflight (required for real graph generation):',
      '   - Use repo virtualenv python: .venv/bin/python',
      '   - Ensure OPENAI_API_KEY is loaded (script supports .env fallback but must still verify non-empty at runtime)',
      '   - Ensure openai package is importable in .venv',
      '   - Run Route-A with real call (no --openai-test-text) and require route_a_execution_mode=remote_openai + orchestration.status=DRAFT_SAVED',
      '   - If execution_mode is local_fallback or synthetic_backfill, stop fail-closed and emit blocker instead of fake completion',
      '',
      'Required behavior:',
      '1. Do not create run_id.',
      '2. Do not create artifacts/production-runs.',
      '3. Stay in CHIP_UPSTREAM only.',
      '4. If outcome=request_more_evidence, produce evidence request package and gap list under chips/<chip_id>/specs/.',
      '5. If outcome=approve or approve_with_conditions, continue the remaining Spec-to-Architecture Closure Flow gates in CHIP_UPSTREAM.',
      '6. Real graph generation belongs after requirement adjudication: use chips/<chip_id>/architecture/architecture_graph.draft.json only as scaffold, then produce or update chips/<chip_id>/architecture/architecture_graph.json.',
      '6.1 For Graph Draft Check, also materialize companion graph views under chips/<chip_id>/architecture/: architecture_graph.md, architecture_graph.mmd, architecture_graph.draft.dot (human-review companions; canonical authority remains JSON).',
      '6.2 Materialize or refresh chips/<chip_id>/governance/upstream_alignment_map.json from current upstream truth; treat JSON as the agent routing contract and generate upstream_alignment_map.md only from that JSON.',
      '7. Materialize full node outputs for Graph Validation under chips/<chip_id>/architecture/:',
      '   - validation/graph_validation_result.json',
      '   - validation/validator_run_record.json',
      '   - graph_issue.json (or equivalent issue list object)',
      '   - interface_binding_record.json (or equivalent binding snapshot)',
      '8. If validation passes and authority context is present, materialize full Freeze outputs under chips/<chip_id>/governance/freeze/:',
      '   - requirement_freeze_record.json',
      '   - graph_freeze_record.json',
      '   - freeze_summary.md (human-readable freeze rationale/constraints)',
      '9. After freeze, materialize full Generation Plan outputs under chips/<chip_id>/generation/:',
      '   - graph_to_generation_plan.json',
      '   - generation_plan.md (human-readable plan and guardrails)',
      '10. After generation plan is ready, materialize full RTL node outputs under chips/<chip_id>/rtl/:',
      '   - rtl_generation_request.json',
      '   - rtl_generation_record.json',
      '   - candidate RTL files (*.v / *.sv)',
      '   - rtl_manifest.json (candidate inventory for downstream 01_inputs mapping)',
      '11. After RTL Generation, materialize chips/<chip_id>/governance/v09_handoff_preflight_manifest.json; it must report READY_FOR_V09_HANDOFF before any PRD v0.9 runner execution.',
      '12. The OpenAI/local AI graph builder may construct/refine graph JSON only; validators establish graph legality and human authority controls freeze.',
      '13. The Requirement Sign-off Gate page itself does not mutate these later nodes, but this handoff prompt instructs the local AI agent to complete them inside CHIP_UPSTREAM before PRD v0.9.',
      '14. After any upstream execution change, regenerate upstream_alignment_map.json/md so the local AI agent can route files, console surfaces, and PRD refs without re-tracing code.',
      '15. After PRD v0.9 runner execution, return to the runbook and review readiness_report.v0.2.md; enumerate every yellow/red item, classify root cause, choose fix / re-run / re-entry / waiver / defer / not-applicable disposition, and write the closure artifacts before closeout.',
      '16. Emit machine-readable summary with current_node, next_action, updated refs, blockers, and any post-run closeout action plan if execution already happened.',
      '',
      'Completion criteria:',
      '- Overall PASS is sequential: a node can PASS only when its own required JSON records and full node outputs exist, and every previous upstream node is PASS.',
      '- Graph Validation full outputs exist and are internally consistent.',
      '- Freeze full outputs exist only after validation pass.',
      '- Generation Plan full outputs exist only after freeze records exist.',
      '- RTL full outputs exist only after generation plan exists.',
      '- Before PRD v0.9 handoff, generate chips/<chip_id>/governance/v09_handoff_preflight_manifest.json and require status=READY_FOR_V09_HANDOFF.',
      '- v09 handoff preflight missing_sources must be empty before runner execution.',
      '- No downstream run artifacts created.',
      '- After downstream run execution, perform readiness_report.v0.2.md yellow/red closure before claiming closeout.',
      '',
      'Fail-closed rules:',
      '- If any node cannot be completed, stop and emit blockers with exact missing files and corrective action.',
      '- If any previous node is not PASS, mark later nodes as blocked by dependency and solve the previous node first.',
      '- If v09_handoff_preflight_manifest.json reports missing_sources, do root-cause remediation first: classify missing family/node, inspect producer prompt/contract/generator/mapping/checker, fix the root cause, regenerate outputs, rerun upstream_node_output_check, then regenerate the manifest.',
      '- Backfilling a missing file without fixing the producer or contract gap is not closeout.',
      '- Never infer human approval from UI state; use machine-readable adjudication record only.',
      '- Never overwrite immutable evidence snapshots.',
      '- Do not claim graph generation success unless route_a_openai_worker_audit.json shows provider=openai, response_type=text, success=true.',
      '',
      'Output format:',
      '- concise action summary',
      '- changed file list',
      '- validation commands executed and results',
      '- machine-readable summary JSON: {scope_type, chip_id, intake_session_id, upstream_operation_id, current_node, next_action, updated_refs, blockers, v09_handoff_preflight_manifest_status, missing_sources, root_cause_actions}',
    ].join('\n')
  }

  async function copyHandoffPrompt(prompt: string) {
    try {
      await navigator.clipboard.writeText(prompt)
      setCopyPromptState('success')
    } catch {
      setCopyPromptState('error')
    }
  }

  if (loading) {
    return <div className="p-8 text-sm text-slate-400">{t('common.loading')}</div>
  }
  if (!chipId) {
    return (
      <div className="space-y-7">
        <header className="rounded-xl border border-amber-500/30 bg-gradient-to-br from-amber-500/10 via-slate-900 to-slate-950 p-7 shadow-lg shadow-amber-500/10">
          <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-amber-400/40 bg-amber-500/15 px-3 py-1 text-sm font-semibold tracking-wide text-amber-300">
            <HeaderIcon name="decision" size={14} />
            {t('req_adj.badge')}
          </div>
          <h1 className="inline-flex items-center gap-3 text-3xl font-bold text-white">
            <HeaderIcon name="decision" size={24} className="text-amber-300" />
            <span>{t('req_adj.title')}</span>
          </h1>
          <p className="mt-3 max-w-4xl text-base leading-7 text-slate-300">{t('req_adj.subtitle')}</p>
        </header>

        <section className="rounded-xl border border-slate-800 bg-slate-900/70 p-6">
          <div className="max-w-2xl space-y-4">
            <div>
              <h2 className="text-lg font-semibold text-white">{t('req_adj.select_chip_title')}</h2>
              <p className="mt-2 text-sm leading-6 text-slate-300">{t('req_adj.select_chip_subtitle')}</p>
            </div>
            <label className="block text-sm text-slate-300">
              <div className="mb-2 font-semibold text-slate-400">{t('req_adj.select_chip_label')}</div>
              <select
                aria-label={t('req_adj.select_chip_label')}
                defaultValue=""
                onChange={(e) => selectChip(e.target.value)}
                disabled={chipOptionsLoading || chipOptions.length === 0}
                className="w-full rounded-lg border border-slate-700 bg-slate-950 px-4 py-3 text-base text-slate-100 outline-none focus:border-cyan-400 disabled:cursor-not-allowed disabled:text-slate-500"
              >
                <option value="">{t('req_adj.select_chip_placeholder')}</option>
                {chipOptions.map((chip) => (
                  <option key={chip.chip_id} value={chip.chip_id}>
                    {chip.chip_id}
                  </option>
                ))}
              </select>
            </label>
            {chipOptionsLoading && <div className="text-sm text-slate-400">{t('common.loading')}</div>}
            {!chipOptionsLoading && chipOptionsError && (
              <div className="text-sm text-rose-300">{t('common.error')}: {chipOptionsError}</div>
            )}
            {!chipOptionsLoading && !chipOptionsError && chipOptions.length === 0 && (
              <div className="text-sm text-slate-400">{t('req_adj.no_chip_options')}</div>
            )}
          </div>
        </section>
      </div>
    )
  }

  if (error) {
    return <div className="p-8 text-sm text-rose-300">{t('common.error')}: {error}</div>
  }
  if (!context) {
    return <div className="p-8 text-sm text-slate-400">{t('req_adj.no_context')}</div>
  }

  const firstRequirement = context.requirement_item.requirement_items?.[0]
  const handoffPrompt = buildHandoffPrompt(context)
  const preHandoffNodes = (context.upstream_node_status ?? context.upstream_truth_flow ?? []).filter((node) =>
    preHandoffNodeIds.has(node.node_id),
  )
  const backToIntakeParams = new URLSearchParams({
    chip: context.chip_id,
    source: 'requirement-adjudication',
  })
  const sourceSession =
    context.review_package.intake_session_id
    || context.review_package.source_session_ref?.split('/').filter(Boolean).pop()
  if (sourceSession) backToIntakeParams.set('intake_session', sourceSession)
  const requiredDecisionFieldsReady = Boolean(authoritySigner.trim() && decisionRationale.trim())
  const hasRecordedDecision = context.adjudication_record?.status === 'DECISION_RECORDED'
  const upstreamFlowParams = new URLSearchParams(searchParams)
  upstreamFlowParams.set('chip', context.chip_id)

  return (
    <div className="space-y-7">
      <header className="rounded-xl border border-amber-500/30 bg-gradient-to-br from-amber-500/10 via-slate-900 to-slate-950 p-7 shadow-lg shadow-amber-500/10">
        <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-amber-400/40 bg-amber-500/15 px-3 py-1 text-sm font-semibold tracking-wide text-amber-300">
          <HeaderIcon name="decision" size={14} />
          {t('req_adj.badge')}
        </div>
        <h1 className="inline-flex items-center gap-3 text-3xl font-bold text-white">
          <HeaderIcon name="decision" size={24} className="text-amber-300" />
          <span>{t('req_adj.title')}</span>
        </h1>
        <p className="mt-3 max-w-4xl text-base leading-7 text-slate-300">{t('req_adj.subtitle')}</p>
      </header>

      <UpstreamTruthFlowBoard chipId={context.chip_id} nodes={preHandoffNodes} />

      <FileFamilyExplorer
        title={t('upstream_files.title')}
        subtitle={t('upstream_files.subtitle')}
        files={upstreamFiles}
      />

      <section className="grid gap-7 xl:grid-cols-[1.2fr_0.8fr]">
        <div className="space-y-6 rounded-xl border border-slate-800 bg-slate-900/70 p-6">
          <div className="rounded-lg border border-slate-700 bg-slate-950/70 p-4 text-sm text-slate-300">
            <div><span className="text-slate-500">scope_type:</span> {context.scope_type ?? 'CHIP_UPSTREAM'}</div>
            <div><span className="text-slate-500">upstream_operation_id:</span> {context.upstream_operation_id ?? '-'}</div>
            <div><span className="text-slate-500">chip_id:</span> {context.chip_id}</div>
            <div><span className="text-slate-500">requirement draft:</span> {context.requirement_item.draft_status ?? 'null'}</div>
            <div><span className="text-slate-500">review package:</span> {context.review_package.status ?? 'null'}</div>
            <div><span className="text-slate-500">builder handoff:</span> {context.builder_handoff.handoff_status ?? 'null'}</div>
          </div>

          <div className="rounded-lg border border-slate-700 bg-slate-950/70 p-4">
            <div className="mb-2 flex items-center gap-2 text-sm font-semibold uppercase tracking-wider text-slate-400">
              <FileCheck2 size={16} />
              {t('req_adj.requirement_summary')}
            </div>
            <div className="space-y-2 text-sm text-slate-200">
              <div>{firstRequirement?.requirement_id ?? '-'}</div>
              <div className="text-base font-semibold text-white">{firstRequirement?.title ?? '-'}</div>
              <div>{t('req_adj.ambiguity_status')}: {firstRequirement?.ambiguity_status ?? '-'}</div>
              <div className="text-slate-400">{firstRequirement?.ambiguity_note ?? '-'}</div>
            </div>
          </div>

          <div className="rounded-lg border border-slate-700 bg-slate-950/70 p-4">
            <div className="mb-2 flex items-center gap-2 text-sm font-semibold uppercase tracking-wider text-slate-400">
              <GitBranch size={16} />
              {t('req_adj.decision_form')}
            </div>
            <div className="space-y-4">
              <label className="block text-sm text-slate-300">
                <div className="mb-2 font-semibold text-slate-400">{t('req_adj.decision_outcome')}</div>
                <select
                  value={decisionOutcome}
                  onChange={(e) => setDecisionOutcome(e.target.value)}
                  className="w-full rounded-lg border border-slate-700 bg-slate-950 px-4 py-3 text-base text-slate-100 outline-none focus:border-cyan-400"
                >
                  <option value="approve">{t('req_adj.decision_option_approve')}</option>
                  <option value="approve_with_conditions">{t('req_adj.decision_option_approve_with_conditions')}</option>
                  <option value="request_more_evidence">{t('req_adj.decision_option_request_more_evidence')}</option>
                  <option value="reject">{t('req_adj.decision_option_reject')}</option>
                </select>
              </label>
              <label className="block text-sm text-slate-300">
                <div className="mb-2 font-semibold text-slate-400">{t('req_adj.authority_signer')}</div>
                <input
                  value={authoritySigner}
                  onChange={(e) => setAuthoritySigner(e.target.value)}
                  className="w-full rounded-lg border border-slate-700 bg-slate-950 px-4 py-3 text-base text-slate-100 outline-none focus:border-cyan-400"
                  placeholder={t('req_adj.authority_signer_placeholder')}
                />
              </label>
              <label className="block text-sm text-slate-300">
                <div className="mb-2 font-semibold text-slate-400">{t('req_adj.decision_rationale')}</div>
                <textarea
                  value={decisionRationale}
                  onChange={(e) => setDecisionRationale(e.target.value)}
                  className="h-40 w-full resize-y rounded-lg border border-slate-700 bg-slate-950 px-4 py-3 text-base leading-7 text-slate-100 outline-none focus:border-cyan-400"
                  placeholder={t('req_adj.decision_rationale_placeholder')}
                />
              </label>
              <label className="block text-sm text-slate-300">
                <div className="mb-2 font-semibold text-slate-400">{t('req_adj.conditions')}</div>
                <textarea
                  value={conditionsText}
                  onChange={(e) => setConditionsText(e.target.value)}
                  className="h-28 w-full resize-y rounded-lg border border-slate-700 bg-slate-950 px-4 py-3 text-base leading-7 text-slate-100 outline-none focus:border-cyan-400"
                  placeholder={t('req_adj.conditions_placeholder')}
                />
              </label>
              <button
                type="button"
                onClick={submitDecision}
                disabled={submitState === 'submitting' || !requiredDecisionFieldsReady}
                className="min-h-12 w-full rounded-md bg-cyan-400 px-4 py-3 text-base font-semibold text-slate-950 transition hover:bg-cyan-300 disabled:cursor-not-allowed disabled:bg-slate-700 disabled:text-slate-300"
              >
                {submitState === 'submitting' ? t('req_adj.submitting') : t('req_adj.submit')}
              </button>
              {hasRecordedDecision && (
                <div className="rounded border border-cyan-500/40 bg-cyan-500/10 px-3 py-2 text-xs leading-5 text-cyan-100">
                  {t('req_adj.supersede_note')}
                </div>
              )}
              {!requiredDecisionFieldsReady && (
                <div className="rounded border border-amber-500/40 bg-amber-500/10 px-3 py-2 text-xs leading-5 text-amber-100">
                  {t('req_adj.required_fields_note')}
                </div>
              )}
            </div>
          </div>
        </div>

        <aside className="space-y-5 rounded-xl border border-slate-800 bg-slate-900/70 p-6">
          <h2 className="text-base font-semibold tracking-wide text-cyan-300">{t('req_adj.operator_note_title')}</h2>
          <div className="rounded-lg border border-slate-700 bg-slate-950/70 p-4 text-sm leading-6 text-slate-300">
            {t('req_adj.operator_note')}
          </div>
          <div className="rounded-lg border border-slate-700 bg-slate-950/70 p-4">
            <div className="mb-3 flex items-center justify-between gap-3">
              <h2 className="text-base font-semibold tracking-wide text-cyan-300">{t('req_adj.handoff_prompt_title')}</h2>
              <button
                type="button"
                onClick={() => void copyHandoffPrompt(handoffPrompt)}
                className="inline-flex min-h-9 items-center gap-2 rounded border border-cyan-500/40 bg-cyan-500/10 px-3 py-2 text-xs font-semibold text-cyan-200 transition hover:border-cyan-300 hover:text-cyan-100"
              >
                <Clipboard size={14} />
                {t('req_adj.copy_handoff_prompt')}
              </button>
            </div>
            <textarea
              aria-label={t('req_adj.handoff_prompt_title')}
              readOnly
              value={handoffPrompt}
              className="h-72 w-full resize-y rounded border border-slate-700 bg-slate-950 px-3 py-2 font-mono text-xs leading-5 text-slate-200 outline-none"
            />
            {copyPromptState !== 'idle' && (
              <div
                className={`mt-2 rounded border px-3 py-2 text-xs ${
                  copyPromptState === 'success'
                    ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-200'
                    : 'border-rose-500/40 bg-rose-500/10 text-rose-200'
                }`}
              >
                {copyPromptState === 'success' ? t('req_adj.copy_handoff_success') : t('req_adj.copy_handoff_error')}
              </div>
            )}
          </div>
          <div className="rounded-lg border border-slate-700 bg-slate-950/70 p-4 text-sm text-slate-300">
            <div className="mb-2 font-semibold text-slate-400">{t('req_adj.suggested_conditions')}</div>
            <ul className="list-disc space-y-1 pl-5">
              {(context.adjudication_template.conditions_suggested ?? []).map((line) => (
                <li key={line}>{line}</li>
              ))}
            </ul>
          </div>
          <div className="rounded-lg border border-slate-700 bg-slate-950/70 p-4 text-sm text-slate-300">
            <div className="mb-2 font-semibold text-slate-400">{t('req_adj.output_refs')}</div>
            <div className="font-mono text-xs break-all text-cyan-200">
              chips/{context.chip_id}/specs/requirement_item_adjudication_record.json
            </div>
            <div className="font-mono text-xs break-all text-cyan-200">
              chips/{context.chip_id}/specs/requirement_item_review_package.json
            </div>
            <div className="font-mono text-xs break-all text-cyan-200">
              chips/{context.chip_id}/architecture/builder_validation_handoff.json
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <Link to={`/intake?${backToIntakeParams.toString()}`} className="rounded border border-slate-600 bg-slate-900 px-2 py-1 text-xs text-slate-200 hover:border-cyan-400 hover:text-cyan-200">
              {t('req_adj.back_to_intake')}
            </Link>
            <Link to={`/upstream-flow?${upstreamFlowParams.toString()}`} className="rounded border border-cyan-600 bg-cyan-950/40 px-2 py-1 text-xs text-cyan-100 hover:border-cyan-300 hover:text-white">
              {t('req_adj.open_upstream_flow')}
            </Link>
          </div>
          {submitState !== 'idle' && (
            <div
              className={`rounded-md border px-3 py-2 text-sm ${
                submitState === 'success'
                  ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-200'
                  : submitState === 'error'
                    ? 'border-rose-500/40 bg-rose-500/10 text-rose-200'
                    : 'border-slate-600 bg-slate-800 text-slate-200'
              }`}
            >
              {submitMessage}
            </div>
          )}
        </aside>
      </section>
    </div>
  )
}
