import { CircleHelp, ShieldCheck } from 'lucide-react'
import { useEffect, useId, useMemo, useRef, useState } from 'react'
import { useLocation } from 'react-router-dom'
import { useTranslation } from '../contexts/i18n'
import Badge from '../components/Badge'
import HeaderIcon from '../components/HeaderIcon'
import { useProductionRunsInventory } from '../hooks/useProductionRunsInventory'
import { flattenExecutions, parseMode, scopedChips, summarizeVerdicts } from '../hooks/evidenceSummary'

function normalizeSequencePath(path: string) {
  const segs = path.split('/')
  if (segs.length === 0) return path
  segs[0] = segs[0].replace(/^\d+_/, '')
  return segs.join('/')
}

function parseArtifactJson(files: Array<{ relative_path: string; kind: string; preview_text?: string | null }>, logicalPath: string): Record<string, unknown> | null {
  const found = files.find((f) => f.kind === 'file' && normalizeSequencePath(f.relative_path) === logicalPath)
  if (!found?.preview_text) return null
  try {
    return JSON.parse(found.preview_text) as Record<string, unknown>
  } catch {
    return null
  }
}

function verdictForRatio(pass: number, total: number): 'PASS' | 'PASS_WITH_WARNINGS' | 'BLOCKED' {
  if (total === 0) return 'BLOCKED'
  const ratio = pass / total
  if (ratio >= 0.85) return 'PASS'
  if (ratio >= 0.5) return 'PASS_WITH_WARNINGS'
  return 'BLOCKED'
}

function HintTooltip({
  title,
  lines,
  align = 'left',
}: {
  title: string
  lines: string[]
  align?: 'left' | 'center' | 'right'
}) {
  const [open, setOpen] = useState(false)
  const panelId = useId()
  const rootRef = useRef<HTMLSpanElement>(null)

  useEffect(() => {
    function onPointerDown(event: PointerEvent) {
      if (!rootRef.current) return
      if (!rootRef.current.contains(event.target as Node)) {
        setOpen(false)
      }
    }
    function onKeyDown(event: KeyboardEvent) {
      if (event.key === 'Escape') {
        setOpen(false)
      }
    }
    document.addEventListener('pointerdown', onPointerDown)
    document.addEventListener('keydown', onKeyDown)
    return () => {
      document.removeEventListener('pointerdown', onPointerDown)
      document.removeEventListener('keydown', onKeyDown)
    }
  }, [])

  const panelAlignClass =
    align === 'left'
      ? 'left-0'
      : align === 'right'
        ? 'right-0'
        : 'left-1/2 -translate-x-1/2'

  return (
    <span ref={rootRef} className="group relative inline-flex">
      <button
        type="button"
        aria-label={`${title}-hint`}
        aria-expanded={open}
        aria-controls={panelId}
        className="inline-flex h-6 w-6 cursor-help items-center justify-center rounded-full border border-slate-600 bg-slate-900 text-slate-300 transition hover:border-cyan-400 hover:text-cyan-300"
        onClick={() => setOpen((prev) => !prev)}
      >
        <CircleHelp size={14} />
      </button>
      <div
        id={panelId}
        className={`absolute top-8 z-30 w-80 max-w-[calc(100vw-2rem)] sm:w-[360px] rounded-lg border border-slate-700 bg-slate-950/95 p-3 text-left text-xs normal-case tracking-normal text-slate-200 shadow-xl break-words ${panelAlignClass} ${
          open ? 'pointer-events-auto block' : 'pointer-events-none hidden'
        }`}
      >
        <div className="mb-1 text-sm font-semibold text-cyan-300">{title}</div>
        <ul className="list-disc space-y-1 pl-4">
          {lines.map((line, idx) => (
            <li key={`${title}-${idx}`} className="whitespace-normal break-all">{line}</li>
          ))}
        </ul>
      </div>
    </span>
  )
}

export default function PackageReadiness() {
  const { t } = useTranslation()
  const location = useLocation()
  const mode = useMemo(() => parseMode(location.search), [location.search])
  const { data, loading, error } = useProductionRunsInventory({ layeredWithRuns: true })
  const [latestExecutionFiles, setLatestExecutionFiles] = useState<Array<{ relative_path: string; kind: string; preview_text?: string | null }>>([])
  const latestExecutionRef = useMemo(() => {
    const chips = scopedChips(data, mode)
    const refs: Array<{ source_dir: string; run_id: string; execution_id: string }> = []
    for (const chip of chips) {
      for (const run of chip.runs) {
        for (const execution of run.executions) {
          refs.push({
            source_dir: chip.source_dir,
            run_id: run.run_id,
            execution_id: execution.execution_id,
          })
        }
      }
    }
    refs.sort((a, b) => b.execution_id.localeCompare(a.execution_id))
    return refs[0] ?? null
  }, [data, mode])

  const summary = useMemo(() => {
    const chips = scopedChips(data, mode)
    let pass = 0
    let warn = 0
    let blocked = 0
    let unknown = 0
    for (const chip of chips) {
      if (chip.verdict_summary) {
        pass += Number(chip.verdict_summary.pass ?? 0)
        warn += Number(chip.verdict_summary.warn ?? 0)
        blocked += Number(chip.verdict_summary.blocked ?? 0)
        unknown += Number(chip.verdict_summary.unknown ?? 0)
        continue
      }
      const rows = flattenExecutions([chip])
      const fallback = summarizeVerdicts(rows)
      pass += fallback.pass
      warn += fallback.warn
      blocked += fallback.blocked
      unknown += fallback.unknown
    }
    return { pass, warn, blocked, unknown, total: pass + warn + blocked + unknown }
  }, [data, mode])

  useEffect(() => {
    let cancelled = false
    if (!latestExecutionRef) {
      return
    }
    fetch(`/api/portfolio/chips/${encodeURIComponent(latestExecutionRef.source_dir)}/runs/${encodeURIComponent(latestExecutionRef.run_id)}?_ts=${Date.now()}`)
      .then((res) => {
        if (!res.ok) throw new Error(`failed to load run detail (${res.status})`)
        return res.json()
      })
      .then((detail: { executions?: Array<{ execution_id: string; files?: Array<{ relative_path: string; kind: string; preview_text?: string | null }> }> }) => {
        if (cancelled) return
        const matched = (detail.executions || []).find((execution) => execution.execution_id === latestExecutionRef.execution_id)
        setLatestExecutionFiles(matched?.files ?? [])
      })
      .catch(() => {
        if (!cancelled) setLatestExecutionFiles([])
      })
    return () => {
      cancelled = true
    }
  }, [latestExecutionRef])
  const architectureReadiness = useMemo(() => {
    if (!latestExecutionRef) return null
    const readinessManifest = parseArtifactJson(latestExecutionFiles, 'dashboard_objects/readiness_manifest.json')
    const scenarioMatrix = parseArtifactJson(latestExecutionFiles, 'dashboard_objects/scenario_requirement_matrix.json')
    const matrixAvailable = Boolean(scenarioMatrix)
    const sectionCount = Array.isArray(readinessManifest?.readiness_sections)
      ? readinessManifest.readiness_sections.length
      : 0
    const scenarioPass = Number((scenarioMatrix?.scenario_pass_count as number | undefined) ?? 0)
    const scenarioTotal = Number((scenarioMatrix?.scenario_count as number | undefined) ?? 0)
    const reqPass = Number((scenarioMatrix?.requirement_global_pass_count as number | undefined) ?? 0)
    const reqTotal = Number((scenarioMatrix?.requirement_count as number | undefined) ?? 0)
    const scenarioResults = Array.isArray(scenarioMatrix?.scenario_results)
      ? (scenarioMatrix?.scenario_results as Array<Record<string, unknown>>)
      : []
    const requirementResults = Array.isArray(scenarioMatrix?.requirement_results)
      ? (scenarioMatrix?.requirement_results as Array<Record<string, unknown>>)
      : []
    const failedRequirements = Array.from(
      new Set(
        scenarioResults.flatMap((row) =>
          Array.isArray(row.failed_requirements) ? row.failed_requirements.map((x) => String(x)) : [],
        ),
      ),
    )
    const failedAssumptions = Array.from(
      new Set(
        [
          ...scenarioResults.flatMap((row) =>
            Array.isArray(row.failed_assumptions) ? row.failed_assumptions.map((x) => String(x)) : [],
          ),
          ...requirementResults.flatMap((row) =>
            Array.isArray(row.failed_assumptions) ? row.failed_assumptions.map((x) => String(x)) : [],
          ),
        ],
      ),
    )
    const evidenceRefCount = scenarioResults.reduce((acc, row) => acc + (Array.isArray(row.evidence_refs) ? row.evidence_refs.length : 0), 0) +
      requirementResults.reduce((acc, row) => acc + (Array.isArray(row.evidence_refs) ? row.evidence_refs.length : 0), 0)
    return {
      sectionCount,
      matrixAvailable,
      scenarioPass,
      scenarioTotal,
      reqPass,
      reqTotal,
      failedRequirements,
      failedAssumptions,
      evidenceRefCount,
    }
  }, [latestExecutionRef, latestExecutionFiles])

  if (loading) return <div className="text-slate-500 p-6">{t('common.loading')}</div>
  if (error) return <div className="text-rose-400 p-6">{t('common.error')}: {error}</div>

  const cardRows: Array<{ key: string; label: string; verdict: string; basis: string; hintLines: string[] }> = [
    {
      key: 'card_1',
      label: t('package_readiness.card_1'),
      verdict: verdictForRatio(summary.pass, summary.total),
      basis: `pass=${summary.pass}/${summary.total}`,
      hintLines: [
        t('package_readiness.hint_card_1_1'),
        t('package_readiness.hint_card_1_2'),
      ],
    },
    {
      key: 'card_2',
      label: t('package_readiness.card_2'),
      verdict: summary.blocked > 0 ? 'BLOCKED' : summary.warn > 0 ? 'PASS_WITH_WARNINGS' : 'PASS',
      basis: `warn=${summary.warn}, blocked=${summary.blocked}`,
      hintLines: [
        t('package_readiness.hint_card_2_1'),
        t('package_readiness.hint_card_2_2'),
      ],
    },
    {
      key: 'card_3',
      label: t('package_readiness.card_3'),
      verdict: summary.warn + summary.blocked > 0 ? 'PENDING' : 'PASS',
      basis: `pending=${summary.warn + summary.blocked}`,
      hintLines: [
        t('package_readiness.hint_card_3_1'),
        t('package_readiness.hint_card_3_2'),
      ],
    },
    {
      key: 'card_4',
      label: t('package_readiness.card_4'),
      verdict: summary.blocked > 0 ? 'BLOCKED' : 'PASS',
      basis: `blocked=${summary.blocked}`,
      hintLines: [
        t('package_readiness.hint_card_4_1'),
        t('package_readiness.hint_card_4_2'),
      ],
    },
  ]

  const chipCount = scopedChips(data, mode).length
  const reviewed = Math.max(summary.total - (summary.warn + summary.blocked), 0)
  const authorityHintLines = [
    t('package_readiness.hint_authority_1'),
    t('package_readiness.hint_authority_2'),
    t('package_readiness.hint_authority_3'),
  ]
  const architectureHintLines = [
    t('package_readiness.hint_architecture_1'),
    t('package_readiness.hint_architecture_2'),
    t('package_readiness.hint_architecture_3'),
    t('package_readiness.hint_architecture_4'),
  ]

  return (
    <div className="space-y-5">
      <div className="border-b border-slate-800/50 pb-4">
        <h1 className="text-3xl font-semibold tracking-tight text-white inline-flex items-center gap-2">
          <HeaderIcon name="package" className="text-cyan-300" size={22} />
          {t('package_readiness.title')}
        </h1>
        <p className="text-sm text-slate-400">{t('package_readiness.subtitle')}</p>
        <p className="mt-1 text-xs text-slate-500">{t('package_readiness.evidence_source')}</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {cardRows.map((card) => (
          <div key={card.key} className="rounded-xl border border-slate-800 bg-slate-900 p-4">
            <div className="text-sm text-slate-400 inline-flex items-center gap-2">
              {card.label}
              <HintTooltip title={card.label} lines={card.hintLines} align="left" />
            </div>
            <div className="mt-2"><Badge label={String(card.verdict)} /></div>
            <div className="mt-2 text-xs text-slate-500 font-mono">{card.basis}</div>
          </div>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <div className="rounded-xl border border-slate-800 bg-slate-900 p-5">
          <h2 className="text-base font-semibold text-slate-100 inline-flex items-center gap-2">
            <ShieldCheck className="h-4 w-4 text-indigo-300" />
            {t('package_readiness.authority_title')}
            <HintTooltip title={t('package_readiness.hint_authority_title')} lines={authorityHintLines} align="left" />
          </h2>
          <div className="mt-3 space-y-1 text-slate-300">
            <div>{t('console_home.reviewer_closure')}: <span className="font-mono">{reviewed} / {summary.total}</span></div>
            <div>{t('console_home.approver_closure')}: <span className="font-mono">{summary.blocked === 0 ? 1 : 0} / 1</span></div>
            <div>{t('console_home.release_blockers')}: <span className="font-mono text-rose-300">{summary.blocked}</span></div>
            <div className="text-xs text-slate-500 pt-1">{t('package_readiness.mode_chips')}: {chipCount}, {t('package_readiness.executions')}: {summary.total}</div>
          </div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900 p-5">
          <h2 className="text-base font-semibold text-slate-100 inline-flex items-center gap-2">
            {t('package_readiness.architecture_scenario_title')}
            <HintTooltip title={t('package_readiness.hint_architecture_title')} lines={architectureHintLines} align="left" />
          </h2>
          {!architectureReadiness ? (
            <div className="mt-3 text-sm text-slate-400">{t('package_readiness.no_readiness_manifest')}</div>
          ) : (
            <div className="mt-3 space-y-1 text-slate-300 text-sm">
              <div>{t('package_readiness.readiness_sections')}: <span className="font-mono">{architectureReadiness.sectionCount}</span></div>
              {!architectureReadiness.matrixAvailable ? (
                <div>{t('package_readiness.scenario_matrix_status')}: <span className="font-mono">NOT_AVAILABLE</span></div>
              ) : (
                <>
                  <div>{t('package_readiness.scenario_coverage')}: <span className="font-mono">{architectureReadiness.scenarioPass}/{architectureReadiness.scenarioTotal}</span></div>
                  <div>{t('package_readiness.requirement_coverage')}: <span className="font-mono">{architectureReadiness.reqPass}/{architectureReadiness.reqTotal}</span></div>
                  <div>{t('package_readiness.failed_requirements')}: <span className="font-mono">{architectureReadiness.failedRequirements.length}</span></div>
                  <div>{t('package_readiness.failed_assumptions')}: <span className="font-mono">{architectureReadiness.failedAssumptions.length}</span></div>
                  <div>{t('package_readiness.evidence_refs_total')}: <span className="font-mono">{architectureReadiness.evidenceRefCount}</span></div>
                </>
              )}
              <div className="pt-1 text-xs text-slate-400">
                {t('package_readiness.failed_requirements_list')}: {architectureReadiness.failedRequirements.length > 0 ? architectureReadiness.failedRequirements.join(', ') : '-'}
              </div>
              <div className="text-xs text-slate-400">
                {t('package_readiness.failed_assumptions_list')}: {architectureReadiness.failedAssumptions.length > 0 ? architectureReadiness.failedAssumptions.join(', ') : '-'}
              </div>
              <div className="text-xs text-slate-500">{t('package_readiness.derived_only_note')}</div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
