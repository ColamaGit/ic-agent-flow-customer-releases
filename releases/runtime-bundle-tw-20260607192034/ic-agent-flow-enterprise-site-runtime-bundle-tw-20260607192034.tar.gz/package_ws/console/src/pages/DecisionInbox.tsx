import { AlertTriangle, ChevronDown, Clock3, ShieldCheck } from 'lucide-react'
import { useMemo, useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { useTranslation } from '../contexts/i18n'
import { parseMode, sortChipsForMode } from '../hooks/evidenceSummary'
import Badge from '../components/Badge'
import HeaderIcon from '../components/HeaderIcon'
import { useProductionRunsInventory } from '../hooks/useProductionRunsInventory'
type QueueStatus = 'pending' | 'blocked' | 'escalated'

type QueueItem = {
  id: string
  title: string
  status: QueueStatus
  role: string
  chip: string
  run: string
  execution: string
  action: string
  signal_count: number
}

function parseStatusSignals(files: Array<{ relative_path: string; kind: string; preview_text?: string | null }>) {
  const signals: Array<{ relativePath: string; status: string }> = []
  for (const file of files) {
    if (file.kind !== 'file') continue
    if (!/normalized\..*\.json$/i.test(file.relative_path)) continue
    const preview = file.preview_text ?? ''
    if (!preview.trim().startsWith('{')) continue
    try {
      const parsed = JSON.parse(preview) as { status?: string }
      if (parsed.status) signals.push({ relativePath: file.relative_path, status: String(parsed.status).toUpperCase() })
    } catch {
      // ignore malformed preview
    }
  }
  return signals
}

function classify(signals: Array<{ relativePath: string; status: string }>): QueueStatus | null {
  if (signals.some((s) => ['FAIL', 'BLOCKED', 'ERROR'].includes(s.status))) return 'blocked'
  if (signals.some((s) => ['NOT_CHECKED', 'WARNING', 'WARN', 'PENDING', 'UNVALIDATED'].includes(s.status))) return 'pending'
  if (signals.some((s) => ['PARTIAL'].includes(s.status))) return 'escalated'
  return null
}

export default function DecisionInbox() {
  const location = useLocation()
  const { t } = useTranslation()
  const mode = useMemo(() => parseMode(location.search), [location.search])
  const params = useMemo(() => new URLSearchParams(location.search), [location.search])
  const focusChip = params.get('chip') ?? ''
  const focusRun = params.get('run') ?? ''
  const focusExecution = params.get('execution') ?? ''
  const { data, loading, error } = useProductionRunsInventory({ layeredWithRuns: true })
  const [collapsedOverride, setCollapsedOverride] = useState<Record<string, boolean>>({})

  const queue = useMemo<QueueItem[]>(() => {
    if (!data?.chips) return []

    const selectedChips = sortChipsForMode(data.chips, mode)

    const items: QueueItem[] = []

    for (const chip of selectedChips) {
      for (const run of chip.runs) {
        for (const execution of run.executions) {
          const signals = parseStatusSignals(execution.files)
          const status =
            classify(signals) ??
            (() => {
              if (execution.verdict === 'BLOCKED') return 'blocked' as QueueStatus
              if (execution.verdict === 'WARN') return 'pending' as QueueStatus
              return null
            })()
          if (!status) continue
          const severitySignals = signals.filter((s) => {
            if (status === 'blocked') return ['FAIL', 'BLOCKED', 'ERROR'].includes(s.status)
            if (status === 'pending') return ['NOT_CHECKED', 'WARNING', 'WARN', 'PENDING', 'UNVALIDATED'].includes(s.status)
            return s.status === 'PARTIAL'
          })

          items.push({
            id: `${chip.chip_id}:${run.run_id}:${execution.execution_id}`,
            title: `${chip.chip_id} ${run.run_id} ${execution.execution_id}`,
            status,
            role: 'release_authority',
            chip: chip.chip_id,
            run: run.run_id,
            execution: execution.execution_id,
            action: status === 'blocked' ? 'block_and_investigate' : status === 'pending' ? 'request_more_evidence' : 'escalate_for_signoff',
            signal_count: severitySignals.length > 0 ? severitySignals.length : 1,
          })
        }
      }
    }

    return items.sort((a, b) => b.id.localeCompare(a.id)).slice(0, 60)
  }, [data, mode])

  const groupedQueue = useMemo(() => {
    const groups: Record<string, QueueItem[]> = {}
    for (const item of queue) {
      if (!groups[item.chip]) groups[item.chip] = []
      groups[item.chip].push(item)
    }
    return groups
  }, [queue])

  const isChipCollapsed = (chip: string, index: number) => collapsedOverride[chip] ?? index !== 0

  if (loading) return <div className="text-slate-500 font-mono text-sm animate-pulse p-8">{t('common.loading')}</div>
  if (error) return <div className="text-rose-400 p-6">{t('common.error')}: {error}</div>

  return (
    <div className="space-y-5">
      <section className="rounded-xl border border-slate-800 bg-slate-900/60 p-5">
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
          <h1 className="text-2xl font-semibold tracking-tight text-white inline-flex items-center gap-2">
            <HeaderIcon name="decision" className="text-cyan-300" size={20} />
            {t('decision_inbox.title')}
          </h1>
          <p className="text-sm text-slate-400">{t('decision_inbox.subtitle')}</p>
        </div>
        <p className="mt-2 text-xs text-slate-500">{t('decision_inbox.evidence_source')}</p>
      </section>

      {focusChip && focusRun && focusExecution && (
        <section className="rounded-lg border border-cyan-900/50 bg-cyan-950/20 p-3 text-xs text-cyan-100 font-mono break-all">
          {t('decision_inbox.focus')}: {focusChip} / {focusRun} / {focusExecution}
        </section>
      )}

      <section className="grid gap-3 sm:grid-cols-3">
        <div className="rounded-lg border border-slate-800 bg-slate-900 p-3 text-sm text-slate-300">
          {t('decision_inbox.pending')}: <span className="font-mono text-blue-300">{queue.filter((q) => q.status === 'pending').length}</span>
        </div>
        <div className="rounded-lg border border-slate-800 bg-slate-900 p-3 text-sm text-slate-300">
          {t('decision_inbox.escalated')}: <span className="font-mono text-amber-300">{queue.filter((q) => q.status === 'escalated').length}</span>
        </div>
        <div className="rounded-lg border border-slate-800 bg-slate-900 p-3 text-sm text-slate-300">
          {t('decision_inbox.blocked')}: <span className="font-mono text-rose-300">{queue.filter((q) => q.status === 'blocked').length}</span>
        </div>
      </section>

      <section className="rounded-xl border border-slate-800 bg-slate-900 p-3">
        {queue.length === 0 ? (
          <div className="p-4 text-sm text-slate-400">{t('decision_inbox.empty')}</div>
        ) : (
          <div className="space-y-3">
            {Object.entries(groupedQueue).map(([chip, items], index) => (
              <div key={chip} className="rounded-lg border border-slate-800 bg-slate-950/40 overflow-hidden">
                <button
                  type="button"
                  className="w-full flex items-center justify-between px-4 py-3 text-left hover:bg-slate-900/60"
                  onClick={() =>
                    setCollapsedOverride((prev) => {
                      const current = isChipCollapsed(chip, index)
                      return { ...prev, [chip]: !current }
                    })
                  }
                >
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-semibold text-slate-100">{chip}</span>
                    <span className="text-xs text-slate-400 font-mono">{items.length} {t('decision_inbox.items')}</span>
                  </div>
                  <span
                    className={`inline-flex items-center justify-center rounded-md border border-slate-700 bg-slate-900/70 p-1.5 transition-transform ${
                      isChipCollapsed(chip, index) ? '-rotate-90' : 'rotate-0'
                    }`}
                  >
                    <ChevronDown className="h-5 w-5 text-slate-200" />
                  </span>
                </button>

                {!isChipCollapsed(chip, index) && (
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 p-3 border-t border-slate-800">
                    {items.map((item) => {
                      const q = `mode=${mode}&chip=${encodeURIComponent(item.chip)}&run=${encodeURIComponent(item.run)}&execution=${encodeURIComponent(item.execution)}`
                      return (
                        <article key={item.id} className="rounded-lg border border-slate-800 bg-slate-950/70 p-4">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="font-mono text-xs text-slate-500">{item.id}</span>
                            <Badge label={item.status.toUpperCase()} className="text-xs" />
                            <span className="rounded-md border border-slate-700 px-2 py-0.5 text-xs text-slate-300">{item.role}</span>
                          </div>
                          <h2 className="mt-2 text-base font-medium text-slate-100">{item.title}</h2>
                          <div className="mt-1 text-sm text-slate-400">{t('common.active_chip')}: {item.chip}</div>
                          <div className="mt-1 text-xs text-slate-500 font-mono">{t('decision_inbox.signals')}: {item.signal_count}</div>
                          <div className="mt-3 flex items-center gap-2 text-xs text-slate-300">
                            {item.status === 'blocked' ? (
                              <AlertTriangle className="h-4 w-4 text-rose-400" />
                            ) : item.status === 'escalated' ? (
                              <Clock3 className="h-4 w-4 text-amber-400" />
                            ) : (
                              <ShieldCheck className="h-4 w-4 text-blue-400" />
                            )}
                            <span>{t('decision_inbox.recommended_action')}: <span className="font-mono">{item.action}</span></span>
                          </div>
                          <div className="mt-3 flex gap-2">
                            <Link to={`/run/${encodeURIComponent(item.chip)}?${q}`} className="rounded border border-cyan-700/40 bg-cyan-900/20 px-2 py-1 text-xs text-cyan-200 hover:bg-cyan-900/40">{t('decision_inbox.open_run')}</Link>
                            <Link to={`/audit-replay?${q}`} className="rounded border border-indigo-700/40 bg-indigo-900/20 px-2 py-1 text-xs text-indigo-200 hover:bg-indigo-900/40">{t('decision_inbox.open_audit_replay')}</Link>
                          </div>
                        </article>
                      )
                    })}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  )
}
