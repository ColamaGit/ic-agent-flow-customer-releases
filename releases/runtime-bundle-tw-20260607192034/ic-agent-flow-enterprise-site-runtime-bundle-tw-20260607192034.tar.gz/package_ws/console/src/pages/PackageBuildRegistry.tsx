import HeaderIcon from '../components/HeaderIcon'
import { usePackageBuildIndex } from '../hooks/usePackageBuildIndex'
import { useCustomerPackageFolders } from '../hooks/useCustomerPackageFolders'
import { Fragment, useEffect, useMemo, useState } from 'react'
import { useTranslation } from '../contexts/i18n'
import { CircleHelp } from 'lucide-react'
import { useLocation, useNavigate } from 'react-router-dom'

type RowLike = {
  build_id: string
  package_variant: string
  runtime_delivery_mode: string
  source_disclosure_mode: string
  release_artifact_class: string
  build_verdict: string
  release_claim: string
  package_artifact_ref: string
  audit_record_ref: string
  customer_safe_manifest_ref: string
  source_leak_scan_verdict: string
  internal_path_leak_scan_verdict: string
  signature_verdict: string
  extract_validation_verdict: string
}

interface PreflightResponse {
  verdict: 'PASS' | 'BLOCKED'
  preflight_id: string
  bundle_id: string
  resolved_file_count: number
  resolved_file_digests: Record<string, string>
  preflight_digest: string
  target_repo_alias: string
  target_relative_dir: string
  expires_at: string
  blocked_reasons: string[]
}

interface PublishResultResponse {
  verdict: 'PASS' | 'BLOCKED'
  bundle_id: string
  published_file_count: number
  target_repo_alias: string
  target_relative_dir: string
  manifest_relative_path: string
  audit_record_relative_path: string
  git_status: {
    commit_created: boolean
    push_performed: boolean
  }
}

function toEvidenceHref(ref: string) {
  if (!ref) return ''
  if (ref.startsWith('artifacts/package-builds/')) {
    return `/portfolio/summaries/package-builds/${ref.replace('artifacts/package-builds/', '')}`
  }
  return ''
}

function inferVariantFromGzName(name: string): string {
  if (name.includes('enterprise-site')) return 'enterprise_site'
  if (name.includes('team-project')) return 'team_project'
  if (name.includes('solo-eval')) return 'solo_eval'
  return 'unknown'
}

export default function PackageBuildRegistry() {
  const { t } = useTranslation()
  const location = useLocation()
  const navigate = useNavigate()

  const [isCustomerPackage, setIsCustomerPackage] = useState(false)

  // NOTE: Package Builds registry page is STRICTLY available in the development repository only.
  // In any customer release package (where isCustomerPackage is true or import.meta.env.DEV is false),
  // this page must fail-closed and block access entirely to prevent vendor IP leakage.
  useEffect(() => {
    fetch('/api/intake/options')
      .then((res) => {
        if (!res.ok) throw new Error()
        return res.json()
      })
      .then((data) => {
        if (data?.is_customer_package) {
          setIsCustomerPackage(true)
        }
      })
      .catch(() => {
        // Fallback
      })
  }, [])

  if (!import.meta.env.DEV || isCustomerPackage) {
    return (
      <div className="rounded-xl border border-amber-900/40 bg-amber-950/30 p-6 text-sm text-amber-200">
        {t('package_build.dev_only')} (ONLY available in development repository)
      </div>
    )
  }

  const packageIndex = usePackageBuildIndex()
  const folderIndex = useCustomerPackageFolders()

  const loading = packageIndex.loading || folderIndex.loading
  const error = packageIndex.error || folderIndex.error

  const rows = useMemo(() => packageIndex.data?.builds ?? [], [packageIndex.data])
  const bundleRows = useMemo(() => folderIndex.data?.bundles ?? [], [folderIndex.data])
  const bundleIds = bundleRows.map((x) => x.bundle_id)
  const params = useMemo(() => new URLSearchParams(location.search), [location.search])
  const requestedMode = params.get('mode') ?? 'team_project'
  const requestedBundle = params.get('bundle') ?? ''
  const requestedFile = params.get('file') ?? ''
  const [selectedBundleId, setSelectedBundleId] = useState<string>(requestedBundle)
  const [selectedGzName, setSelectedGzName] = useState<string>(requestedFile)
  const [auditText, setAuditText] = useState<string>('')
  const [manifestText, setManifestText] = useState<string>('')
  const [openHintField, setOpenHintField] = useState<string>('')

  const [syncing, setSyncing] = useState(false)
  const [syncMessage, setSyncMessage] = useState('')
  const [preflightData, setPreflightData] = useState<PreflightResponse | null>(null)
  const [preflightLoading, setPreflightLoading] = useState(false)
  const [publishLoading, setPublishLoading] = useState(false)
  const [publishResult, setPublishResult] = useState<PublishResultResponse | null>(null)

  const effectiveBundleId = selectedBundleId || bundleIds[0] || ''

  const selectedBundle = bundleRows.find((b) => b.bundle_id === effectiveBundleId) ?? null

  const gzFiles = useMemo(() => selectedBundle?.gz_files ?? [], [selectedBundle])

  const activeGz = selectedGzName || gzFiles[0] || ''
  const activeVariant = inferVariantFromGzName(activeGz)

  // 聯鎖置灰：若選中的 bundle 或 file/gz 發生 any 改動，清除 preflightData 和 publishResult
  useEffect(() => {
    setPreflightData(null)
    setPublishResult(null)
  }, [effectiveBundleId, activeGz])

  const handleSyncIndex = async () => {
    setSyncing(true)
    setSyncMessage('')
    try {
      const res = await fetch('/api/console/package-builds/sync-folders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
      })
      if (res.ok) {
        setSyncMessage(t('package_build.sync_success'))
        setTimeout(() => {
          window.location.reload()
        }, 1000)
      } else {
        setSyncMessage('Failed to sync index.')
      }
    } catch (err) {
      const errMsg = err instanceof Error ? err.message : String(err)
      setSyncMessage(`Error: ${errMsg}`)
    } finally {
      setSyncing(false)
    }
  }

  const handlePreflight = async () => {
    setPreflightLoading(true)
    setPreflightData(null)
    try {
      const res = await fetch('/api/console/package-release-candidates/publish-preflight', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          bundle_id: effectiveBundleId,
          mode: activeVariant
        })
      })
      const data = await res.json()
      if (res.ok) {
        setPreflightData(data as PreflightResponse)
      } else {
        setPreflightData({
          verdict: 'BLOCKED',
          preflight_id: '',
          bundle_id: effectiveBundleId,
          resolved_file_count: 0,
          resolved_file_digests: {},
          preflight_digest: '',
          target_repo_alias: 'ic-agent-flow-customer-releases',
          target_relative_dir: `releases/${effectiveBundleId}`,
          expires_at: '',
          blocked_reasons: [data.error || 'PREFLIGHT_FAILED']
        })
      }
    } catch (err) {
      const errMsg = err instanceof Error ? err.message : String(err)
      setPreflightData({
        verdict: 'BLOCKED',
        preflight_id: '',
        bundle_id: effectiveBundleId,
        resolved_file_count: 0,
        resolved_file_digests: {},
        preflight_digest: '',
        target_repo_alias: 'ic-agent-flow-customer-releases',
        target_relative_dir: `releases/${effectiveBundleId}`,
        expires_at: '',
        blocked_reasons: [errMsg]
      })
    } finally {
      setPreflightLoading(false)
    }
  }

  const handlePublish = async () => {
    if (!preflightData || preflightData.verdict !== 'PASS') return
    setPublishLoading(true)
    setPublishResult(null)
    try {
      const res = await fetch('/api/console/package-release-candidates/publish-to-customer-releases', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          bundle_id: effectiveBundleId,
          mode: activeVariant,
          preflight_id: preflightData.preflight_id,
          preflight_digest: preflightData.preflight_digest
        })
      })
      const data = await res.json()
      if (res.ok && data.verdict === 'PASS') {
        setPublishResult(data as PublishResultResponse)
      } else {
        alert(`Publish Failed: ${data.error || 'Unknown error'}`)
      }
    } catch (err) {
      const errMsg = err instanceof Error ? err.message : String(err)
      alert(`Publish Error: ${errMsg}`)
    } finally {
      setPublishLoading(false)
    }
  }

  useEffect(() => {
    const next = new URLSearchParams()
    next.set('mode', requestedMode)
    if (effectiveBundleId) next.set('bundle', effectiveBundleId)
    if (activeGz) next.set('file', activeGz)
    const nextQs = next.toString()
    const currentQs = new URLSearchParams(location.search).toString()
    if (nextQs !== currentQs) {
      navigate(`/package-builds?${nextQs}`, { replace: true })
    }
  }, [requestedMode, effectiveBundleId, activeGz, location.search, navigate])

  const activeRow: RowLike | null =
    rows.find((r) => String(r.bundle_id ?? '') === effectiveBundleId && r.package_variant === activeVariant) ??
    ({
      build_id: `${effectiveBundleId}:${activeVariant}`,
      package_variant: activeVariant,
      runtime_delivery_mode: 'unknown',
      source_disclosure_mode: 'unknown',
      release_artifact_class: 'runtime_package',
      build_verdict: 'UNKNOWN',
      release_claim: 'UNKNOWN',
      package_artifact_ref: selectedBundle ? `${selectedBundle.folder_ref}/${activeGz}` : '',
      audit_record_ref: '',
      customer_safe_manifest_ref: '',
      source_leak_scan_verdict: 'UNKNOWN',
      internal_path_leak_scan_verdict: 'UNKNOWN',
      signature_verdict: 'UNKNOWN',
      extract_validation_verdict: 'UNKNOWN',
    } as RowLike)

  const activeAuditRecordRef = activeRow?.audit_record_ref ?? ''
  const activeCustomerSafeManifestRef = activeRow?.customer_safe_manifest_ref ?? ''

  useEffect(() => {
    let cancelled = false
    ;(async () => {
      setAuditText('')
      setManifestText('')
      const auditHref = toEvidenceHref(activeAuditRecordRef)
      const manifestHref = toEvidenceHref(activeCustomerSafeManifestRef)
      if (auditHref) {
        try {
          const res = await fetch(auditHref)
          const text = await res.text()
          if (!cancelled) setAuditText(text)
        } catch {
          if (!cancelled) setAuditText('NOT_AVAILABLE')
        }
      } else {
        setAuditText('NOT_AVAILABLE')
      }
      if (manifestHref) {
        try {
          const res = await fetch(manifestHref)
          const text = await res.text()
          if (!cancelled) setManifestText(text)
        } catch {
          if (!cancelled) setManifestText('NOT_AVAILABLE')
        }
      } else {
        setManifestText('NOT_AVAILABLE')
      }
    })()
    return () => {
      cancelled = true
    }
  }, [activeAuditRecordRef, activeCustomerSafeManifestRef])

  if (!import.meta.env.DEV) {
    return <div className="rounded-xl border border-amber-900/40 bg-amber-950/30 p-6 text-sm text-amber-200">{t('package_build.dev_only')}</div>
  }

  return (
    <div className="space-y-5">
      <section className="grid grid-cols-1 gap-3 lg:grid-cols-2">
        <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-5">
          <h1 className="text-2xl font-semibold tracking-tight text-white inline-flex items-center gap-2">
            <HeaderIcon name="package" className="text-cyan-300" size={20} />
            {t('package_build.title')}
          </h1>
          <p className="text-sm text-slate-400 mt-1">{t('package_build.subtitle')}</p>
        </div>
        <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-5">
          <div className="flex justify-between items-center mb-2">
            <label className="text-xs text-slate-400">
              {t('package_build.bundle_selector')} (Total Bundles: {bundleIds.length})
            </label>
            <button
              type="button"
              onClick={handleSyncIndex}
              disabled={syncing}
              className="px-2 py-0.5 rounded text-[11px] font-semibold bg-cyan-800 hover:bg-cyan-700 text-cyan-100 disabled:opacity-50 transition-colors"
            >
              {syncing ? t('package_build.syncing') : t('package_build.sync_button')}
            </button>
          </div>
          <select
            value={effectiveBundleId}
            onChange={(e) => {
              setSelectedBundleId(e.target.value)
              setSelectedGzName('')
            }}
            className="w-full rounded border border-slate-700 bg-slate-950 px-3 py-2 text-sm font-mono text-slate-200"
          >
            {bundleIds.map((id) => (
              <option key={id} value={id}>{id}</option>
            ))}
          </select>
        </div>
      </section>

      {loading && <div className="rounded-xl border border-slate-800 bg-slate-900 p-6 text-sm text-slate-300">{t('common.loading')}</div>}
      {error && <div className="rounded-xl border border-rose-900/40 bg-rose-950/30 p-6 text-sm text-rose-200">{t('common.error')}: {error}</div>}

      {!loading && !error && (
        <section className="rounded-xl border border-slate-800 bg-slate-900 overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-[360px_minmax(0,1fr)] min-h-[62vh]">
            <div className="border-r border-slate-800 bg-slate-950/40 p-3 overflow-auto">
              <div className="text-xs uppercase tracking-wider text-slate-500 mb-2">
                {t('package_build.file_tree')} (count: {gzFiles.length})
              </div>
              <div className="space-y-1">
                {gzFiles.map((name) => {
                  const isActive = name === activeGz
                  return (
                    <button
                      key={name}
                      type="button"
                      onClick={() => setSelectedGzName(name)}
                      className={`w-full rounded border px-2 py-1.5 text-left text-xs font-mono ${
                        isActive
                          ? 'border-cyan-600/70 bg-cyan-900/25 text-cyan-100'
                          : 'border-slate-800 bg-slate-900/70 text-slate-300 hover:bg-slate-800/70'
                      }`}
                    >
                      {name}
                    </button>
                  )
                })}
              </div>

              {/* Sync Message Display */}
              {syncMessage && (
                <div className="mt-2 text-[10px] text-cyan-300 font-mono text-center bg-cyan-950/30 py-1 rounded border border-cyan-900/40">
                  {syncMessage}
                </div>
              )}

              {/* Preflight & Publish Action Panel */}
              <div className="mt-6 pt-4 border-t border-slate-800/80 space-y-3">
                <div className="text-xs uppercase tracking-wider text-slate-500 font-semibold">
                  Governance Release Panel
                </div>

                <button
                  type="button"
                  onClick={handlePreflight}
                  disabled={preflightLoading || !effectiveBundleId}
                  className="w-full rounded py-2 text-xs font-semibold text-center border bg-slate-900 hover:bg-slate-800 border-slate-700 text-slate-200 transition-colors disabled:opacity-50"
                >
                  {preflightLoading ? 'Preflight Running...' : t('package_build.btn_preflight')}
                </button>

                {preflightData && preflightData.verdict === 'PASS' && (
                  <div className="text-[11px] font-mono text-emerald-400 bg-emerald-950/20 p-2 rounded border border-emerald-900/30">
                    ✓ {t('package_build.preflight_pass')}
                    <div className="mt-1 text-[10px] text-slate-400">
                      Expires in: {Math.max(0, Math.round((new Date(preflightData.expires_at).getTime() - Date.now()) / 60000))} min
                    </div>
                  </div>
                )}

                {preflightData && preflightData.verdict === 'BLOCKED' && (
                  <div className="text-[11px] font-mono text-rose-400 bg-rose-950/20 p-2 rounded border border-rose-900/30">
                    ❌ {t('package_build.preflight_blocked')}
                    <div className="mt-1 font-semibold text-rose-300 break-words">
                      {preflightData.blocked_reasons.join(', ')}
                    </div>
                  </div>
                )}

                <button
                  type="button"
                  onClick={handlePublish}
                  disabled={publishLoading || !preflightData || preflightData.verdict !== 'PASS'}
                  className="w-full rounded py-2 text-xs font-semibold text-center text-white bg-cyan-700 hover:bg-cyan-600 disabled:bg-slate-800 disabled:text-slate-500 disabled:opacity-50 transition-all shadow-md shadow-cyan-900/20"
                >
                  {publishLoading ? 'Publishing...' : t('package_build.btn_publish')}
                </button>

                {publishResult && (
                  <div className="text-[11px] font-mono text-cyan-300 bg-cyan-950/40 p-2 rounded border border-cyan-800/40 space-y-1 animate-pulse">
                    <div className="font-semibold text-emerald-400">✓ {t('package_build.publish_success')}</div>
                    <div className="text-[9px] text-slate-400">{t('package_build.publish_success_path')}</div>
                    <div className="text-[9px] text-slate-300 select-all break-all bg-slate-950/50 p-1 rounded font-semibold">
                      /customer-home/imac/Documents/Code/ic-agent-flow-customer-releases/{publishResult.target_relative_dir}
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="p-4 space-y-4 overflow-auto">
              {activeRow && (
                <>
                  <div className="rounded-lg border border-slate-800 bg-slate-950/30 overflow-auto max-h-[34vh]">
                    <table className="w-full border-collapse text-left text-sm">
                      <thead className="sticky top-0 z-10 bg-slate-900/95 border-b border-slate-700">
                        <tr>
                          <th className="px-3 py-2 text-xs uppercase tracking-wider text-slate-400">Field</th>
                          <th className="px-3 py-2 text-xs uppercase tracking-wider text-slate-400">Value</th>
                        </tr>
                      </thead>
                      <tbody>
                        {Object.entries(activeRow).map(([k, v]) => {
                          const hintKey = `package_build.field_hint.${k}`
                          const hintText = t(hintKey)
                          const hasHint = hintText !== hintKey
                          const runtimeDescKey = `package_build.runtime_mode_desc.${String(v)}`
                          const runtimeDesc = k === 'runtime_delivery_mode' ? t(runtimeDescKey) : ''
                          const showRuntimeDesc = k === 'runtime_delivery_mode' && runtimeDesc !== runtimeDescKey
                          return (
                            <Fragment key={k}>
                              <tr className="border-b border-slate-800/70">
                                <td className="px-3 py-2 text-xs font-mono text-slate-400">
                                  <div className="inline-flex items-center gap-1.5">
                                    <span>{k}</span>
                                    {hasHint && (
                                      <button
                                        type="button"
                                        className="inline-flex h-4 w-4 items-center justify-center rounded border border-slate-700 text-slate-300 hover:border-cyan-500 hover:text-cyan-300"
                                        onClick={() => setOpenHintField((prev) => (prev === k ? '' : k))}
                                        aria-label={`${k}-hint`}
                                      >
                                        <CircleHelp size={11} />
                                      </button>
                                    )}
                                  </div>
                                </td>
                                <td className="px-3 py-2 text-xs font-mono text-slate-200 break-all">
                                  {String(v)}
                                  {showRuntimeDesc && (
                                    <span className="ml-1 text-[11px] text-slate-400 normal-case">({runtimeDesc})</span>
                                  )}
                                </td>
                              </tr>
                              {hasHint && openHintField === k && (
                                <tr className="border-b border-slate-800/70 bg-slate-900/30">
                                  <td colSpan={2} className="px-3 py-2 text-[11px] text-slate-200">
                                    {hintText}
                                  </td>
                                </tr>
                              )}
                            </Fragment>
                          )
                        })}
                      </tbody>
                    </table>
                  </div>

                  <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
                    <div className="rounded-lg border border-slate-800 bg-slate-950/50 p-3">
                      <div className="text-xs uppercase tracking-wider text-slate-500 mb-2">Audit: release_build_audit_record.json</div>
                      <pre className="max-h-[28vh] overflow-auto whitespace-pre-wrap break-all text-[11px] font-mono text-cyan-100">{auditText || 'LOADING...'}</pre>
                    </div>
                    <div className="rounded-lg border border-slate-800 bg-slate-950/50 p-3">
                      <div className="text-xs uppercase tracking-wider text-slate-500 mb-2">Manifest: customer_safe_manifest.json</div>
                      <pre className="max-h-[28vh] overflow-auto whitespace-pre-wrap break-all text-[11px] font-mono text-indigo-100">{manifestText || 'LOADING...'}</pre>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </section>
      )}
    </div>
  )
}
