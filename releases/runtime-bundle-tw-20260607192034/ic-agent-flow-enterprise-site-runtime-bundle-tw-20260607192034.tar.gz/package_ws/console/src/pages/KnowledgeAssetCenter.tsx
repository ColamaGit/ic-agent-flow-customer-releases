import { AlertTriangle, BookOpen, CircleHelp, Clock3, ExternalLink, Filter, Layers3, Lock, ShieldCheck, Sparkles, Users2 } from 'lucide-react'
import { useMemo } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import Badge from '../components/Badge'
import HeaderIcon from '../components/HeaderIcon'
import { useTranslation } from '../contexts/i18n'
import { parseMode } from '../hooks/evidenceSummary'
import { useProductionRunsInventory } from '../hooks/useProductionRunsInventory'
import {
  computeInventoryStats,
  extractKnowledgeAssetRows,
  type AssetContext,
  type ScopeClass,
} from '../lib/knowledgeAssetCenter'

type FilterState = {
  context: AssetContext
  family: string
  flowScope: string
  originClass: string
  priorityClass: string
  assetId: string
}

const CONTEXTS: AssetContext[] = ['development_repo', 'shared_packs', 'customer_side_repo']

function isAssetContext(value: string | null): value is AssetContext {
  return value === 'development_repo' || value === 'shared_packs' || value === 'customer_side_repo'
}

function translationFallback(t: (key: string) => string, key: string, fallback: string) {
  const value = t(key)
  return value === key ? fallback : value
}

function contextLabelKey(context: AssetContext) {
  return `knowledge_assets.context.${context}`
}

function scopeClassLabelKey(scopeClass: ScopeClass) {
  return `knowledge_assets.scope_class.${scopeClass}`
}

function statusLabelKey(status: string) {
  const normalized = status.trim().toUpperCase()
  if (normalized === 'CANDIDATE') return 'knowledge_assets.status.candidate'
  if (normalized === 'PROMOTED') return 'knowledge_assets.status.promoted'
  if (normalized === 'LOCAL_ONLY') return 'knowledge_assets.status.local_only'
  if (normalized === 'SHARED_NONCANONICAL') return 'knowledge_assets.status.shared_noncanonical'
  if (normalized === 'CANONICAL_SHARED') return 'knowledge_assets.status.canonical_shared'
  if (normalized === 'BLOCKED') return 'knowledge_assets.status.blocked'
  return 'knowledge_assets.status.unknown'
}

function recommendationLabelKey(value: string) {
  const normalized = value.trim().toUpperCase()
  if (normalized === 'PROMOTE') return 'knowledge_assets.recommendation.promote'
  if (normalized === 'REVIEW') return 'knowledge_assets.recommendation.review'
  if (normalized === 'HOLD') return 'knowledge_assets.recommendation.hold'
  if (normalized === 'LOCAL_ONLY') return 'knowledge_assets.recommendation.local_only'
  if (normalized === 'NEEDS_ADJUDICATION') return 'knowledge_assets.recommendation.needs_adjudication'
  if (normalized === 'REJECT') return 'knowledge_assets.recommendation.reject'
  return 'knowledge_assets.recommendation.unknown'
}

function normalizeFamilyLabel(family: string) {
  return family.replace(/[_-]+/g, ' ').trim()
}

/**
 * Derive display label for flow_scope values for combo box.
 * Canonical enum values are never translated; only used as filter keys.
 * Display label may be translated via t().
 */
function flowScopeDisplayLabel(t: (key: string) => string, scope: string): string {
  if (scope === 'all') return t('knowledge_assets.filter_all_flow_scopes')
  const key = `knowledge_assets.filter.${scope}`
  const translated = t(key)
  return translated === key ? scope : translated
}

function buildQuery(pathname: string, currentSearch: string, next: Partial<FilterState>) {
  const params = new URLSearchParams(currentSearch)
  if (next.context) params.set('context', next.context)
  if (next.family !== undefined) {
    if (next.family === 'all') params.delete('family')
    else params.set('family', next.family)
  }
  if (next.flowScope !== undefined) {
    if (next.flowScope === 'all') params.delete('flow_scope')
    else params.set('flow_scope', next.flowScope)
  }
  if (next.originClass !== undefined) {
    if (next.originClass === 'all') params.delete('origin')
    else params.set('origin', next.originClass)
  }
  if (next.priorityClass !== undefined) {
    if (next.priorityClass === 'all') params.delete('priority')
    else params.set('priority', next.priorityClass)
  }
  if (next.assetId !== undefined) {
    if (next.assetId) params.set('asset', next.assetId)
    else params.delete('asset')
  }
  return `${pathname}?${params.toString()}`
}

export default function KnowledgeAssetCenter() {
  const { t } = useTranslation()
  const location = useLocation()
  const navigate = useNavigate()
  const mode = useMemo(() => parseMode(location.search), [location.search])
  const query = useMemo(() => new URLSearchParams(location.search), [location.search])
  const requestedContext = query.get('context')
  const requestedFamily = query.get('family') ?? 'all'
  const requestedFlowScope = query.get('flow_scope') ?? 'all'
  const requestedOriginClass = query.get('origin') ?? 'all'
  const requestedPriorityClass = query.get('priority') ?? 'all'
  const requestedAsset = query.get('asset') ?? ''
  const selectedContext: AssetContext = isAssetContext(requestedContext) ? requestedContext : 'development_repo'
  const { data, loading, error } = useProductionRunsInventory()

  // All rows (deduplicated by scope-aware identity)
  const allRows = useMemo(() => extractKnowledgeAssetRows(data, mode), [data, mode])

  // Inventory stats computed from ALL rows (not filtered), for the summary block
  const inventoryStats = useMemo(() => computeInventoryStats(allRows), [allRows])

  // Context-filtered rows
  const contextRows = useMemo(
    () => allRows.filter((row) => row.context === selectedContext),
    [allRows, selectedContext],
  )

  // Build filter option lists from contextRows
  const familyOptions = useMemo(
    () => ['all', ...Array.from(new Set(contextRows.map((row) => row.asset_family))).sort((a, b) => a.localeCompare(b))],
    [contextRows],
  )
  // Flow scope options: normalize empty array to 'NOT_FLOW_BOUND' sentinel for display
  const flowScopeOptions = useMemo(() => {
    const scopes = new Set<string>()
    for (const row of contextRows) {
      if (row.flow_scope.length === 0) {
        scopes.add('NOT_FLOW_BOUND')
      } else {
        for (const s of row.flow_scope) scopes.add(s)
      }
    }
    return ['all', ...Array.from(scopes).sort((a, b) => a.localeCompare(b))]
  }, [contextRows])

  const originClassOptions = useMemo(
    () => {
      const origins = Array.from(new Set(contextRows.map((row) => row.asset_origin_class).filter(Boolean))).sort((a, b) => a.localeCompare(b))
      return ['all', ...origins]
    },
    [contextRows],
  )
  const priorityClassOptions = useMemo(
    () => {
      const priorities = Array.from(new Set(contextRows.map((row) => row.priority_class).filter(Boolean))).sort((a, b) => a.localeCompare(b))
      return ['all', ...priorities]
    },
    [contextRows],
  )

  // Apply all three combo filters to contextRows
  const filteredRows = useMemo(() => {
    return contextRows.filter((row) => {
      if (requestedFamily !== 'all' && row.asset_family !== requestedFamily) return false
      if (requestedFlowScope !== 'all') {
        // Handle empty flow_scope → treat as NOT_FLOW_BOUND for filtering
        const rowScopes = row.flow_scope.length === 0 ? ['NOT_FLOW_BOUND'] : row.flow_scope
        if (!rowScopes.includes(requestedFlowScope)) return false
      }
      if (requestedOriginClass !== 'all' && row.asset_origin_class !== requestedOriginClass) return false
      if (requestedPriorityClass !== 'all' && row.priority_class !== requestedPriorityClass) return false
      return true
    })
  }, [contextRows, requestedFamily, requestedFlowScope, requestedOriginClass, requestedPriorityClass])

  const selectedRow =
    filteredRows.find((row) => row.asset_identity_key === requestedAsset) ??
    filteredRows[0] ??
    contextRows[0] ??
    allRows[0] ??
    null

  // Summary cards — based on ALL rows (not filtered, not context-limited)
  const summary = useMemo(() => {
    const rows = allRows
    const candidateCount = rows.filter((row) => row.promotion_status.toUpperCase() === 'CANDIDATE').length
    const promotedCount = rows.filter((row) => row.promotion_status.toUpperCase() === 'PROMOTED').length
    const localCount = rows.filter((row) => row.context === 'customer_side_repo').length
    const sharedCount = rows.filter((row) => row.context === 'shared_packs').length
    const blockedCount = rows.filter((row) => row.alignment_status.toUpperCase() !== 'PASS').length
    return {
      total: rows.length,
      candidateCount,
      promotedCount,
      localCount,
      sharedCount,
      blockedCount,
    }
  }, [allRows])

  const detailCards = [
    {
      label: t('knowledge_assets.summary.total'),
      value: summary.total,
      hint: t('knowledge_assets.summary.total_hint'),
      icon: BookOpen,
      tone: 'cyan',
    },
    {
      label: t('knowledge_assets.summary.candidate'),
      value: summary.candidateCount,
      hint: t('knowledge_assets.summary.candidate_hint'),
      icon: Sparkles,
      tone: 'indigo',
    },
    {
      label: t('knowledge_assets.summary.promoted'),
      value: summary.promotedCount,
      hint: t('knowledge_assets.summary.promoted_hint'),
      icon: ShieldCheck,
      tone: 'emerald',
    },
    {
      label: t('knowledge_assets.summary.local'),
      value: summary.localCount,
      hint: t('knowledge_assets.summary.local_hint'),
      icon: Users2,
      tone: 'orange',
    },
    {
      label: t('knowledge_assets.summary.shared'),
      value: summary.sharedCount,
      hint: t('knowledge_assets.summary.shared_hint'),
      icon: Layers3,
      tone: 'violet',
    },
    {
      label: t('knowledge_assets.summary.blocked'),
      value: summary.blockedCount,
      hint: t('knowledge_assets.summary.blocked_hint'),
      icon: AlertTriangle,
      tone: 'rose',
    },
  ] as const

  function setFilter(next: Partial<FilterState>) {
    navigate(buildQuery(location.pathname, location.search, next), { replace: true })
  }

  if (loading) {
    return <div className="p-6 text-sm text-slate-400">{t('common.loading')}</div>
  }

  if (error) {
    return <div className="p-6 text-sm text-rose-300">{t('common.error')}: {error}</div>
  }

  const assetRows = filteredRows
  const emptyReason = contextRows.length === 0 ? t(`knowledge_assets.empty.${selectedContext}`) : t('knowledge_assets.empty.filtered')
  const latestEvidence = selectedRow?.manifest_ref ?? translationFallback(t, 'knowledge_assets.evidence_source', 'knowledge_backflow_alignment manifest')

  return (
    <div className="space-y-6">
      {/* Header */}
      <section className="rounded-2xl border border-slate-800 bg-gradient-to-br from-slate-950 via-slate-950 to-slate-900 p-6 shadow-xl shadow-black/20">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
          <div className="space-y-3">
            <div className="flex flex-wrap items-center gap-3">
              <div className="inline-flex items-center gap-2 rounded-full border border-cyan-500/20 bg-cyan-500/10 px-3 py-1 text-xs font-medium text-cyan-200">
                <HeaderIcon name="knowledge" className="text-cyan-300" size={16} />
                {t('knowledge_assets.section_tag')}
              </div>
              <div className="flex items-center gap-3">
                <HeaderIcon name="knowledge" className="text-cyan-300" size={24} />
                <h1 className="text-3xl font-semibold tracking-tight text-white">{t('knowledge_assets.title')}</h1>
              </div>
            </div>
            <p className="max-w-4xl text-sm leading-6 text-slate-300">{t('knowledge_assets.subtitle')}</p>
            <div className="flex flex-wrap gap-2 text-xs text-slate-400">
              <span className="rounded-full border border-slate-700 bg-slate-900/70 px-3 py-1 font-mono">{t('knowledge_assets.mode_label')}: {mode}</span>
              <span className="rounded-full border border-slate-700 bg-slate-900/70 px-3 py-1 font-mono">{t('knowledge_assets.current_context')}: {t(contextLabelKey(selectedContext))}</span>
              <span className="rounded-full border border-slate-700 bg-slate-900/70 px-3 py-1 font-mono">{t('knowledge_assets.source_label')}: production_runs_inventory.json</span>
              <span className="rounded-full border border-slate-700 bg-slate-900/70 px-3 py-1 font-mono">{t('knowledge_assets.governance_label')}: PRD v1.1 / PRD v1.2</span>
            </div>
          </div>

          <div className="rounded-xl border border-slate-700 bg-slate-950/70 p-4 lg:w-[25.3rem]">
            <div className="text-xs uppercase tracking-[0.12em] text-slate-500">{t('knowledge_assets.evidence_title')}</div>
            <div className="mt-2 text-sm text-slate-200 break-all">{latestEvidence}</div>
            <div className="mt-3 flex items-center gap-2 text-xs text-slate-400">
              <Clock3 size={14} />
              <span>{t('knowledge_assets.last_updated')}: {data?.timestamp ?? 'N/A'}</span>
            </div>
          </div>
        </div>
      </section>

      {/* Summary cards */}
      <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-6">
        {detailCards.map((card) => (
          <div key={card.label} className="rounded-2xl border border-slate-800 bg-slate-900/80 p-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="text-xs uppercase tracking-[0.12em] text-slate-500">{card.label}</div>
                <div className="mt-2 text-3xl font-semibold text-white">{card.value}</div>
                <div className="mt-2 text-xs leading-5 text-slate-400">{card.hint}</div>
              </div>
              <div className={`rounded-xl border p-2 ${
                card.tone === 'cyan' ? 'border-cyan-500/20 bg-cyan-500/10 text-cyan-300'
                : card.tone === 'indigo' ? 'border-indigo-500/20 bg-indigo-500/10 text-indigo-300'
                : card.tone === 'emerald' ? 'border-emerald-500/20 bg-emerald-500/10 text-emerald-300'
                : card.tone === 'orange' ? 'border-orange-500/20 bg-orange-500/10 text-orange-300'
                : card.tone === 'violet' ? 'border-violet-500/20 bg-violet-500/10 text-violet-300'
                : 'border-rose-500/20 bg-rose-500/10 text-rose-300'
              }`}>
                <card.icon size={18} />
              </div>
            </div>
          </div>
        ))}
      </section>

      {/* Inventory summary block */}
      <section className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5">
        <div className="mb-4 flex items-center gap-2">
          <BookOpen size={16} className="text-cyan-300" />
          <h2 className="text-sm font-semibold uppercase tracking-[0.1em] text-slate-100">
            Asset Inventory — {t('knowledge_assets.inventory.unique_assets')}: {inventoryStats.unique_asset_count} / {t('knowledge_assets.inventory.source_occurrences')}: {inventoryStats.total_source_occurrences}
          </h2>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          {/* Scope breakdown */}
          <div className="rounded-xl border border-slate-800 bg-slate-950/40 p-4">
            <div className="text-xs uppercase tracking-[0.12em] text-slate-500 mb-3">Asset Scope Breakdown</div>
            <div className="space-y-2 text-xs text-slate-300">
              {[
                { label: t('knowledge_assets.inventory.chip_bound'), value: inventoryStats.chip_bound_count },
                { label: t('knowledge_assets.inventory.platform_line'), value: inventoryStats.platform_line_count },
                { label: t('knowledge_assets.inventory.release_line'), value: inventoryStats.release_line_count },
                { label: t('knowledge_assets.inventory.cross_line'), value: inventoryStats.cross_line_count },
                { label: t('knowledge_assets.inventory.not_flow_bound'), value: inventoryStats.not_flow_bound_count },
              ].map(({ label, value }) => (
                <div key={label} className="flex items-center justify-between">
                  <span className="text-slate-400">{label}</span>
                  <span className="font-mono font-semibold text-slate-100">{value}</span>
                </div>
              ))}
            </div>
          </div>
          {/* Chip applicability */}
          <div className="rounded-xl border border-slate-800 bg-slate-950/40 p-4">
            <div className="text-xs uppercase tracking-[0.12em] text-slate-500 mb-3">{t('knowledge_assets.inventory.chip_applicability')}</div>
            <div className="space-y-2 text-xs text-slate-300">
              {Object.entries(inventoryStats.chip_occurrence_map).sort(([a], [b]) => a.localeCompare(b)).map(([chipId, info]) => (
                <div key={chipId} className="flex items-center justify-between gap-2">
                  <span className="font-mono text-slate-400">{chipId}</span>
                  <span className="text-slate-500 text-[10px]">
                    {info.occurrences} {t('knowledge_assets.inventory.occurrences')} / {info.asset_ids.size} {t('knowledge_assets.inventory.applicable_assets')}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="grid gap-6 xl:grid-cols-[minmax(0,1.4fr)_minmax(0,0.95fr)]">
        <div className="space-y-5">
          {/* Filter panel */}
          <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-4">
            <div className="flex flex-wrap items-center gap-2">
              <Filter size={16} className="text-cyan-300" />
              <span className="text-sm font-medium text-slate-100">{t('knowledge_assets.context_filter_label')}</span>
              <div className="ml-auto flex flex-wrap gap-2">
                {CONTEXTS.map((context) => {
                  const active = selectedContext === context
                  return (
                    <button
                      key={context}
                      type="button"
                      onClick={() => setFilter({ context, family: 'all', flowScope: 'all', originClass: 'all', priorityClass: 'all', assetId: '' })}
                      className={`rounded-full border px-3 py-1.5 text-xs font-medium transition-colors ${
                        active
                          ? 'border-cyan-400/50 bg-cyan-500/15 text-cyan-100'
                          : 'border-slate-700 bg-slate-950/40 text-slate-300 hover:border-slate-600 hover:bg-slate-900'
                      }`}
                    >
                      {t(contextLabelKey(context))}
                    </button>
                  )
                })}
              </div>
            </div>
            <div className="mt-4 flex flex-wrap items-center gap-2">
              <span className="text-xs uppercase tracking-[0.12em] text-slate-500">{t('knowledge_assets.family_filter_label')}</span>
              {familyOptions.map((family) => {
                const active = requestedFamily === family
                return (
                  <button
                    key={family}
                    type="button"
                    onClick={() => setFilter({ family, assetId: '' })}
                    className={`rounded-full border px-3 py-1.5 text-xs font-medium transition-colors ${
                      active
                        ? 'border-violet-400/50 bg-violet-500/15 text-violet-100'
                        : 'border-slate-700 bg-slate-950/40 text-slate-300 hover:border-slate-600 hover:bg-slate-900'
                    }`}
                  >
                    {family === 'all' ? t('knowledge_assets.family_all') : normalizeFamilyLabel(family)}
                  </button>
                )
              })}
            </div>
            <div className="mt-4 grid gap-3 md:grid-cols-3">
              {[
                {
                  label: t('knowledge_assets.flow_scope_filter_label'),
                  value: requestedFlowScope,
                  options: flowScopeOptions,
                  keyName: 'flowScope' as const,
                  renderOption: (opt: string) => flowScopeDisplayLabel(t, opt),
                },
                {
                  label: t('knowledge_assets.origin_filter_label'),
                  value: requestedOriginClass,
                  options: originClassOptions,
                  keyName: 'originClass' as const,
                  renderOption: (opt: string) => opt === 'all' ? t('knowledge_assets.filter_all_origins') : opt,
                },
                {
                  label: t('knowledge_assets.priority_filter_label'),
                  value: requestedPriorityClass,
                  options: priorityClassOptions,
                  keyName: 'priorityClass' as const,
                  renderOption: (opt: string) => opt === 'all' ? t('knowledge_assets.filter_all_priorities') : opt,
                },
              ].map((filter) => (
                <label key={filter.keyName} className="space-y-1 text-xs text-slate-400">
                  <span className="uppercase tracking-[0.12em] text-slate-500">{filter.label}</span>
                  <select
                    value={filter.value}
                    onChange={(event) => setFilter({ [filter.keyName]: event.target.value, assetId: '' })}
                    className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-slate-100 outline-none transition-colors focus:border-cyan-400"
                  >
                    {filter.options.map((option) => (
                      <option key={`${filter.keyName}-${option}`} value={option}>
                        {filter.renderOption(option)}
                      </option>
                    ))}
                  </select>
                  {/* Live feedback: show filtered row count */}
                  {filter.keyName === 'flowScope' && requestedFlowScope !== 'all' && (
                    <span className="text-[10px] text-cyan-400">{filteredRows.length} {t('knowledge_assets.rows_label')}</span>
                  )}
                </label>
              ))}
            </div>
          </div>

          {/* Asset Inventory table — uses filteredRows */}
          <div className="overflow-hidden rounded-2xl border border-slate-800 bg-slate-900/80">
            <div className="flex items-center justify-between border-b border-slate-800 px-4 py-3">
              <div>
                <h2 className="text-base font-semibold text-slate-100">{t('knowledge_assets.table_title')}</h2>
                <p className="text-xs text-slate-500">{t('knowledge_assets.table_subtitle')}</p>
              </div>
              <div className="text-xs text-slate-500">{assetRows.length} {t('knowledge_assets.rows_label')}</div>
            </div>

            {assetRows.length === 0 ? (
              <div className="p-6 text-sm text-slate-400">
                <div className="flex items-start gap-2 rounded-xl border border-slate-800 bg-slate-950/40 p-4">
                  <CircleHelp className="mt-0.5 h-4 w-4 text-cyan-300" />
                  <div>
                    <div className="font-medium text-slate-100">{t('knowledge_assets.empty_title')}</div>
                    <p className="mt-1 leading-6">{emptyReason}</p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full border-collapse text-left">
                  <thead>
                    <tr className="border-b border-slate-800 bg-slate-950/40 text-xs uppercase tracking-[0.12em] text-slate-500">
                      <th className="px-4 py-3">{t('knowledge_assets.col_asset')}</th>
                      <th className="px-4 py-3">{t('knowledge_assets.col_context')}</th>
                      <th className="px-4 py-3">{t('knowledge_assets.col_status')}</th>
                      <th className="px-4 py-3">{t('knowledge_assets.col_source')}</th>
                      <th className="px-4 py-3">{t('knowledge_assets.col_evidence')}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {assetRows.map((row) => {
                      const active = row.asset_identity_key === selectedRow?.asset_identity_key
                      return (
                        <tr
                          key={row.asset_identity_key}
                          className={`cursor-pointer border-b border-slate-800/70 transition-colors ${
                            active ? 'bg-cyan-500/5' : 'hover:bg-slate-800/40'
                          }`}
                          onClick={() => setFilter({ context: row.context, family: requestedFamily, flowScope: requestedFlowScope, originClass: requestedOriginClass, priorityClass: requestedPriorityClass, assetId: row.asset_identity_key })}
                        >
                          <td className="px-4 py-3 align-top">
                            <div className="space-y-1">
                              <div className="font-mono text-sm text-slate-100 break-all">{row.asset_id}</div>
                              <div className="text-[11px] text-slate-500">{row.registry_id}</div>
                              {row.occurrence_count > 1 && (
                                <div className="text-[10px] text-cyan-500/70">{row.occurrence_count}× occurrences</div>
                              )}
                            </div>
                          </td>
                          <td className="px-4 py-3 align-top">
                            <div className="space-y-1">
                              <Badge label={t(contextLabelKey(row.context))} className="text-[11px]" />
                              <div className="text-[11px] text-slate-500">{normalizeFamilyLabel(row.asset_family)}</div>
                              <Badge label={translationFallback(t, scopeClassLabelKey(row.scope_class), row.scope_class)} className="text-[10px]" />
                            </div>
                          </td>
                          <td className="px-4 py-3 align-top">
                            <div className="flex flex-wrap gap-2">
                              <Badge label={translationFallback(t, statusLabelKey(row.promotion_status), row.promotion_status.toUpperCase())} className="text-[11px]" />
                              <Badge label={translationFallback(t, recommendationLabelKey(row.promotion_recommendation), row.promotion_recommendation.toUpperCase())} className="text-[11px]" />
                            </div>
                            <div className="mt-2 text-[11px] text-slate-500">{t('knowledge_assets.authority_line')}: {row.authority_line}</div>
                            {row.priority_class && <div className="mt-1 text-[11px] text-slate-500">{row.priority_class} / {row.asset_origin_class}</div>}
                          </td>
                          <td className="px-4 py-3 align-top font-mono text-xs text-slate-300">
                            <div>{row.source_dir}</div>
                            <div className="text-slate-500">{row.run_id} / {row.execution_id}</div>
                            {row.chip_binding_mode === 'not_chip_bound' && row.applies_to_chips.length > 0 && (
                              <div className="text-[10px] text-violet-400 mt-1">{t('knowledge_assets.applies_to_chips')}: {row.applies_to_chips.join(', ')}</div>
                            )}
                          </td>
                          <td className="px-4 py-3 align-top text-xs text-slate-300">
                            <div>{row.evidence_refs.length} {t('knowledge_assets.evidence_refs')}</div>
                            <div className="mt-1 text-[11px] text-slate-500">{row.alignment_status}</div>
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        <div className="space-y-5">
          {/* Asset Detail */}
          <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5">
            <div className="flex items-center gap-2">
              <HeaderIcon name="knowledge" className="text-cyan-300" size={18} />
              <h2 className="text-base font-semibold text-slate-100">{t('knowledge_assets.detail_title')}</h2>
            </div>
            {selectedRow ? (
              <div className="mt-4 space-y-4">
                <div className="rounded-xl border border-slate-800 bg-slate-950/40 p-4">
                  <div className="text-xs uppercase tracking-[0.12em] text-slate-500">{t('knowledge_assets.detail_asset')}</div>
                  <div className="mt-1 break-all text-sm font-semibold text-white">{selectedRow.asset_id}</div>
                  <div className="mt-2 flex flex-wrap gap-2">
                    <Badge label={translationFallback(t, statusLabelKey(selectedRow.promotion_status), selectedRow.promotion_status.toUpperCase())} />
                    <Badge label={translationFallback(t, recommendationLabelKey(selectedRow.promotion_recommendation), selectedRow.promotion_recommendation.toUpperCase())} />
                    <Badge label={t(contextLabelKey(selectedRow.context))} />
                    <Badge label={translationFallback(t, scopeClassLabelKey(selectedRow.scope_class), selectedRow.scope_class)} />
                  </div>
                  {selectedRow.occurrence_count > 1 && (
                    <div className="mt-2 text-[11px] text-cyan-400/80">{t('knowledge_assets.occurrence_note')}</div>
                  )}
                </div>

                <div className="rounded-xl border border-slate-800 bg-slate-950/40 p-4 text-sm text-slate-300">
                  <div className="text-xs uppercase tracking-[0.12em] text-slate-500">{t('knowledge_assets.detail_summary')}</div>
                  <p className="mt-2 leading-6 text-slate-200">{selectedRow.summary || t('knowledge_assets.no_summary')}</p>
                </div>

                <div className="rounded-xl border border-slate-800 bg-slate-950/40 p-4">
                  <div className="text-xs uppercase tracking-[0.12em] text-slate-500">{t('knowledge_assets.detail_lesson')}</div>
                  <ul className="mt-2 space-y-2 text-sm text-slate-200">
                    {selectedRow.reusable_lesson.length > 0 ? (
                      selectedRow.reusable_lesson.map((line, idx) => (
                        <li key={`${selectedRow.asset_id}-lesson-${idx}`} className="rounded-lg border border-slate-800 bg-slate-900/60 px-3 py-2 leading-6">{line}</li>
                      ))
                    ) : (
                      <li className="text-slate-500">{t('knowledge_assets.no_lesson')}</li>
                    )}
                  </ul>
                </div>

                <div className="grid gap-3 sm:grid-cols-2">
                  <div className="rounded-xl border border-slate-800 bg-slate-950/40 p-4">
                    <div className="text-xs uppercase tracking-[0.12em] text-slate-500">{t('knowledge_assets.detail_provenance')}</div>
                    <div className="mt-2 space-y-2 text-xs text-slate-300">
                      <div className="break-all"><span className="text-slate-500">{t('knowledge_assets.registry_ref')}:</span> {selectedRow.registry_ref}</div>
                      <div className="break-all"><span className="text-slate-500">{t('knowledge_assets.source_run_ref')}:</span> {selectedRow.source_run_ref}</div>
                      <div className="break-all"><span className="text-slate-500">{t('knowledge_assets.manifest_ref')}:</span> {selectedRow.manifest_ref}</div>
                    </div>
                  </div>

                  <div className="rounded-xl border border-slate-800 bg-slate-950/40 p-4">
                    <div className="text-xs uppercase tracking-[0.12em] text-slate-500">{t('knowledge_assets.detail_evidence')}</div>
                    <div className="mt-2 space-y-2 text-xs text-slate-300">
                      <div className="break-all"><span className="text-slate-500">{t('knowledge_assets.source_event_refs')}:</span> {selectedRow.source_event_refs.length}</div>
                      <div className="break-all"><span className="text-slate-500">{t('knowledge_assets.evidence_refs')}:</span> {selectedRow.evidence_refs.length}</div>
                      <div className="break-all"><span className="text-slate-500">{t('knowledge_assets.chip_evidence_refs')}:</span> {selectedRow.chip_evidence_refs.length}</div>
                      <div className="break-all"><span className="text-slate-500">{t('knowledge_assets.source_occurrences')}:</span> {selectedRow.occurrence_count}</div>
                    </div>
                  </div>
                </div>

                <div className="rounded-xl border border-slate-800 bg-slate-950/40 p-4">
                  <div className="text-xs uppercase tracking-[0.12em] text-slate-500">{t('knowledge_assets.detail_meta')}</div>
                  <div className="mt-2 grid grid-cols-1 gap-2 text-xs text-slate-300 sm:grid-cols-2">
                    <div><span className="text-slate-500">{t('knowledge_assets.asset_family')}:</span> {normalizeFamilyLabel(selectedRow.asset_family)}</div>
                    <div><span className="text-slate-500">{t('knowledge_assets.source_event_type')}:</span> {selectedRow.source_event_type}</div>
                    <div><span className="text-slate-500">{t('knowledge_assets.flow_scope')}:</span> {selectedRow.flow_scope.join(', ') || 'NOT_FLOW_BOUND'}</div>
                    <div><span className="text-slate-500">{t('knowledge_assets.chip_binding_mode')}:</span> {translationFallback(t, `knowledge_assets.chip_binding.${selectedRow.chip_binding_mode}`, selectedRow.chip_binding_mode)}</div>
                    {selectedRow.applies_to_chips.length > 0 && (
                      <div className="sm:col-span-2"><span className="text-slate-500">{t('knowledge_assets.applies_to_chips')}:</span> {selectedRow.applies_to_chips.join(', ')}</div>
                    )}
                    <div><span className="text-slate-500">{t('knowledge_assets.asset_origin_class')}:</span> {selectedRow.asset_origin_class || 'N/A'}</div>
                    <div><span className="text-slate-500">{t('knowledge_assets.priority_class')}:</span> {selectedRow.priority_class || 'N/A'}</div>
                    <div><span className="text-slate-500">{t('knowledge_assets.source_fix_ref')}:</span> {selectedRow.source_fix_ref || 'N/A'}</div>
                    <div className="sm:col-span-2"><span className="text-slate-500">{t('knowledge_assets.consumption_targets')}:</span> {selectedRow.consumption_targets.join(', ') || 'N/A'}</div>
                    <div><span className="text-slate-500">{t('knowledge_assets.scope_level')}:</span> {selectedRow.scope_level}</div>
                    <div><span className="text-slate-500">{t('knowledge_assets.non_canonical_notice')}:</span> {selectedRow.non_canonical_notice ? 'true' : 'false'}</div>
                  </div>
                </div>

                {/* Source occurrences accordion */}
                {selectedRow.occurrence_count > 1 && (
                  <div className="rounded-xl border border-slate-800 bg-slate-950/40 p-4">
                    <div className="text-xs uppercase tracking-[0.12em] text-slate-500 mb-2">{t('knowledge_assets.source_occurrences')} ({selectedRow.occurrence_count})</div>
                    <div className="space-y-2">
                      {selectedRow.source_occurrences.map((occ, idx) => (
                        <div key={`${occ.chip_id}-${occ.run_id}-${idx}`} className="rounded-lg border border-slate-800 bg-slate-900/40 px-3 py-2 text-[11px] text-slate-400 font-mono">
                          <span className="text-slate-200">{occ.chip_id}</span> / {occ.run_id} / {occ.execution_id}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div className="rounded-xl border border-slate-800 bg-slate-950/40 p-4">
                  <div className="text-xs uppercase tracking-[0.12em] text-slate-500">{t('knowledge_assets.live_ops_title')}</div>
                  <p className="mt-2 text-sm leading-6 text-slate-300">{t('knowledge_assets.live_ops_note')}</p>
                  <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2">
                    {[
                      'review_asset',
                      'submit_share_back_candidate',
                      'request_more_evidence',
                      'promote_to_shared_noncanonical',
                      'defer_asset_adoption',
                      'retire_asset',
                    ].map((action) => (
                      <div key={action} className="flex items-center justify-between rounded-lg border border-slate-800 bg-slate-900/60 px-3 py-2 text-xs">
                        <span className="font-mono text-slate-100">{t(`knowledge_assets.action.${action}`)}</span>
                        <span className="inline-flex items-center gap-1 text-slate-500">
                          <Lock size={12} />
                          {t('knowledge_assets.live_ops_locked')}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex flex-wrap gap-2">
                  <Link
                    to={`/run/${encodeURIComponent(selectedRow.chip_id)}?mode=${mode}&run=${encodeURIComponent(selectedRow.run_id)}&execution=${encodeURIComponent(selectedRow.execution_id)}`}
                    className="inline-flex items-center gap-2 rounded-lg border border-cyan-500/30 bg-cyan-500/10 px-3 py-2 text-sm text-cyan-100 transition-colors hover:bg-cyan-500/20"
                  >
                    <ExternalLink size={14} />
                    {t('knowledge_assets.open_run_detail')}
                  </Link>
                </div>
              </div>
            ) : (
              <div className="mt-4 rounded-xl border border-slate-800 bg-slate-950/40 p-4 text-sm text-slate-400">{t('knowledge_assets.no_selection')}</div>
            )}
          </div>

          <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5">
            <div className="flex items-center gap-2">
              <Users2 size={18} className="text-violet-300" />
              <h2 className="text-base font-semibold text-slate-100">{t('knowledge_assets.customer_context_title')}</h2>
            </div>
            <p className="mt-2 text-sm leading-6 text-slate-300">{t('knowledge_assets.customer_context_note')}</p>
            <div className="mt-4 rounded-xl border border-slate-800 bg-slate-950/40 p-4 text-sm text-slate-400">
              {selectedContext === 'customer_side_repo' && contextRows.length === 0
                ? t('knowledge_assets.empty.customer_side_repo')
                : t('knowledge_assets.customer_context_preview')}
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
