import { CheckCircle2, Clock, FileText, Hash, ShieldCheck } from 'lucide-react'
import { useMemo } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { useTranslation } from '../contexts/i18n'
import Badge from '../components/Badge'
import HeaderIcon from '../components/HeaderIcon'
import { useProductionRunsInventory } from '../hooks/useProductionRunsInventory'
import { flattenExecutions, parseMode, parseNormalizedStatuses, resolveExecution, scopedChips } from '../hooks/evidenceSummary'
import { useRunDetailExecutions } from '../hooks/useRunDetailExecutions'

type GateRow = {
  gate: string
  status: string
  file_ref: string
  digest: string
  timestamp: string
}

function statusToBadge(status: string): string {
  if (['FAIL', 'BLOCKED', 'ERROR'].includes(status)) return 'BLOCKED'
  if (['WARN', 'WARNING', 'PARTIAL', 'PENDING', 'NOT_CHECKED', 'UNVALIDATED'].includes(status)) return 'PASS_WITH_WARNINGS'
  if (['PASS', 'OK', 'DONE'].includes(status)) return 'PASS'
  return 'UNKNOWN'
}

export default function GateBoard() {
  const location = useLocation()
  const navigate = useNavigate()
  const { t } = useTranslation()
  const mode = useMemo(() => parseMode(location.search), [location.search])
  const params = useMemo(() => new URLSearchParams(location.search), [location.search])
  const focusChip = params.get('chip') ?? undefined
  const focusRun = params.get('run') ?? undefined
  const focusExecution = params.get('execution') ?? undefined
  const { data, loading, error } = useProductionRunsInventory({ layeredWithRuns: true })

  const selected = useMemo(() => {
    const chips = scopedChips(data, mode)
    const rows = flattenExecutions(chips)
    return resolveExecution(rows, focusChip, focusRun, focusExecution)
  }, [data, mode, focusChip, focusRun, focusExecution])

  const chips = useMemo(() => scopedChips(data, mode), [data, mode])
  const selectedChip = useMemo(
    () => chips.find((c) => c.chip_id === (focusChip ?? selected?.chip_id)) ?? chips[0] ?? null,
    [chips, focusChip, selected],
  )
  const runOptions = selectedChip?.runs ?? []
  const selectedRun = runOptions.find((r) => r.run_id === (focusRun ?? selected?.run_id)) ?? runOptions[0] ?? null
  const { executions: runDetailExecutions } = useRunDetailExecutions(selectedChip?.source_dir ?? '', selectedRun?.run_id ?? '')
  const executionOptions = runDetailExecutions ?? selectedRun?.executions ?? []
  const selectedExecution = executionOptions.find((e) => e.execution_id === (focusExecution ?? selected?.execution_id)) ?? executionOptions[0] ?? null

  function updateScope(nextChip: string, nextRun: string, nextExecution: string) {
    const q = new URLSearchParams()
    q.set('mode', mode)
    q.set('chip', nextChip)
    q.set('run', nextRun)
    q.set('execution', nextExecution)
    navigate(`/flow-map?${q.toString()}`)
  }

  const gateRows = useMemo<GateRow[]>(() => {
    const files = selectedExecution?.files ?? []
    if (!files.length) return []
    const statuses = parseNormalizedStatuses(files)
    return statuses.map((s) => ({
      gate: s.relativePath.split('/')[0] || 'UNKNOWN_GATE',
      status: s.status,
      file_ref: s.relativePath,
      digest: `${s.relativePath}:${s.status}`,
      timestamp: selectedExecution?.execution_id ?? '-',
    }))
  }, [selectedExecution])

  if (loading) return <div className="text-slate-500 animate-pulse font-mono p-8">{t('gate.loading')}</div>
  if (error) return <div className="text-rose-400 bg-rose-950/30 p-6 border border-rose-900 rounded-xl m-8">Error: {error}</div>

  if (!selected) return <div className="text-slate-500 font-mono p-12 text-center bg-slate-900/30 rounded-xl border border-dashed border-slate-800 m-8">No execution in current mode scope.</div>
  if (gateRows.length === 0) return <div className="text-slate-500 font-mono p-12 text-center bg-slate-900/30 rounded-xl border border-dashed border-slate-800 m-8">No normalized gate evidence in selected execution.</div>

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-2 duration-700">
      <div className="flex justify-between items-end border-b border-slate-800/50 pb-6">
        <div>
          <h1 className="text-4xl font-light text-white mb-2 tracking-tight inline-flex items-center gap-2">
            <HeaderIcon name="gate" className="text-cyan-300" size={24} />
            {t('gate.title_v3')}
          </h1>
          <p className="text-slate-400 text-sm max-w-2xl">{t('gate.subtitle_v3')}</p>
          <p className="text-xs text-slate-500 mt-2 font-mono">scope: {selected.chip_id} / {selected.run_id} / {selected.execution_id}</p>
        </div>
        <div className="bg-blue-500/10 border border-blue-500/20 px-3 py-1.5 rounded text-[11px] font-mono font-bold text-blue-400 shadow-xl shadow-blue-500/5">
          evidence source: production-runs
        </div>
      </div>

      <section className="rounded-xl border border-slate-800 bg-slate-900 p-4">
        <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
          <label className="text-xs text-slate-400">
            chip ID
            <select
              className="mt-1 w-full rounded border border-slate-700 bg-slate-950 px-2 py-2 text-sm text-slate-100"
              value={selectedChip?.chip_id ?? ''}
              onChange={(e) => {
                const chip = chips.find((c) => c.chip_id === e.target.value)
                const run = chip?.runs[0]
                const exe = run?.executions[run.executions.length - 1]
                if (chip && run && exe) updateScope(chip.chip_id, run.run_id, exe.execution_id)
              }}
            >
              {chips.map((c) => <option key={c.chip_id} value={c.chip_id}>{c.chip_id}</option>)}
            </select>
          </label>
          <label className="text-xs text-slate-400">
            run ID
            <select
              className="mt-1 w-full rounded border border-slate-700 bg-slate-950 px-2 py-2 text-sm text-slate-100"
              value={selectedRun?.run_id ?? ''}
              onChange={(e) => {
                const run = runOptions.find((r) => r.run_id === e.target.value)
                const exe = run?.executions[run.executions.length - 1]
                if (selectedChip && run && exe) updateScope(selectedChip.chip_id, run.run_id, exe.execution_id)
              }}
            >
              {runOptions.map((r) => <option key={r.run_id} value={r.run_id}>{r.run_id}</option>)}
            </select>
          </label>
          <label className="text-xs text-slate-400">
            execution timestamp
            <select
              className="mt-1 w-full rounded border border-slate-700 bg-slate-950 px-2 py-2 text-sm text-slate-100"
              value={selectedExecution?.execution_id ?? ''}
              onChange={(e) => {
                if (selectedChip && selectedRun) updateScope(selectedChip.chip_id, selectedRun.run_id, e.target.value)
              }}
            >
              {executionOptions.map((x) => <option key={x.execution_id} value={x.execution_id}>{x.execution_id}</option>)}
            </select>
          </label>
        </div>
      </section>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {gateRows.map((row, i) => (
          <div key={`${row.file_ref}-${i}`} className="bg-slate-900 border border-slate-800 rounded-xl p-8 relative overflow-hidden group hover:border-slate-700 transition-all duration-300">
            <div className="absolute top-0 right-0 p-6 opacity-5 pointer-events-none group-hover:opacity-10 transition-opacity">
              <ShieldCheck size={100} className="text-emerald-500" />
            </div>

            <div className="flex justify-between items-start mb-8 border-b border-slate-800 pb-6">
              <div className="space-y-1">
                <span className="text-[10px] text-slate-500 uppercase font-black tracking-widest">{t('gate.gate_label')}</span>
                <h3 className="text-lg font-bold text-slate-100 uppercase tracking-tight">{row.gate.replace(/_/g, ' ')}</h3>
              </div>
              <div className="flex flex-col items-end gap-2">
                <div className="flex items-center gap-2">
                  <CheckCircle2 size={12} className="text-emerald-500" />
                  <Badge label={statusToBadge(row.status)} className="text-[10px]" />
                </div>
                <div className="flex items-center gap-1.5 text-slate-600 font-mono text-[10px]">
                  <Clock size={10} />
                  {row.timestamp}
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <div className="grid grid-cols-1 gap-4">
                <div className="space-y-1">
                  <span className="text-[10px] text-slate-500 uppercase font-bold tracking-widest flex items-center gap-1.5"><FileText size={12} className="text-blue-400" /> {t('gate.path')}</span>
                  <div className="bg-slate-950/80 px-3 py-2 rounded border border-slate-800/80 text-xs font-mono text-slate-400 break-all select-all hover:text-blue-300 transition-colors">{row.file_ref}</div>
                </div>
                <div className="space-y-1">
                  <span className="text-[10px] text-slate-500 uppercase font-bold tracking-widest flex items-center gap-1.5"><Hash size={12} className="text-emerald-400" /> {t('gate.digest')}</span>
                  <div className="bg-slate-950/80 px-3 py-2 rounded border border-slate-800/80 text-[10px] font-mono text-emerald-500/70 break-all select-all">{row.digest}</div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
