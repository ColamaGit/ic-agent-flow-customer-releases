import { BadgeCheck, Clock, FileText, Hash, Shield, UserCheck } from 'lucide-react'
import { useMemo } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { useTranslation } from '../contexts/i18n'
import { useProductionRunsInventory } from '../hooks/useProductionRunsInventory'
import { flattenExecutions, parseMode, resolveExecution, scopedChips } from '../hooks/evidenceSummary'
import { useRunDetailExecutions } from '../hooks/useRunDetailExecutions'

type ReviewRow = {
  key: string
  file_ref: string
  digest: string
  timestamp: string
}

function normalizeSequencePath(path: string) {
  const segs = path.split('/')
  if (segs.length === 0) return path
  segs[0] = segs[0].replace(/^\d+_/, '')
  return segs.join('/')
}

export default function HumanReview() {
  const location = useLocation()
  const navigate = useNavigate()
  const { t } = useTranslation()
  const mode = useMemo(() => parseMode(location.search), [location.search])
  const params = useMemo(() => new URLSearchParams(location.search), [location.search])
  const focusChip = params.get('chip') ?? undefined
  const focusRun = params.get('run') ?? undefined
  const focusExecution = params.get('execution') ?? undefined

  const { data, loading, error } = useProductionRunsInventory({ layeredWithRuns: true })

  const selected = useMemo(() => {
    const chips = scopedChips(data, mode)
    const rows = flattenExecutions(chips)
    return resolveExecution(rows, focusChip, focusRun, focusExecution)
  }, [data, mode, focusChip, focusRun, focusExecution])

  const chips = useMemo(() => scopedChips(data, mode), [data, mode])
  const selectedChip = useMemo(
    () => chips.find((c) => c.chip_id === (focusChip ?? selected?.chip_id)) ?? chips[0] ?? null,
    [chips, focusChip, selected],
  )
  const runOptions = selectedChip?.runs ?? []
  const selectedRun = runOptions.find((r) => r.run_id === (focusRun ?? selected?.run_id)) ?? runOptions[0] ?? null
  const { executions: runDetailExecutions } = useRunDetailExecutions(selectedChip?.source_dir ?? '', selectedRun?.run_id ?? '')
  const executionOptions = runDetailExecutions ?? selectedRun?.executions ?? []
  const selectedExecution = executionOptions.find((e) => e.execution_id === (focusExecution ?? selected?.execution_id)) ?? executionOptions[0] ?? null

  function updateScope(nextChip: string, nextRun: string, nextExecution: string) {
    const q = new URLSearchParams()
    q.set('mode', mode)
    q.set('chip', nextChip)
    q.set('run', nextRun)
    q.set('execution', nextExecution)
    navigate(`/node-io?${q.toString()}`)
  }

  const items = useMemo<ReviewRow[]>(() => {
    if (!selectedExecution) return []
    return selectedExecution.files
      .filter((f) =>
        f.kind === 'file' &&
        (() => {
          const logicalPath = normalizeSequencePath(f.relative_path)
          return /subject_binding\//i.test(logicalPath) || /skill_usage\//i.test(logicalPath) || /decision|adjudication|review|signoff/i.test(logicalPath)
        })(),
      )
      .slice(0, 60)
      .map((f) => ({
        key: f.relative_path.split('/').pop() ?? f.relative_path,
        file_ref: f.relative_path,
        digest: `${f.relative_path}:${f.size_bytes}`,
        timestamp: selectedExecution.execution_id,
      }))
  }, [selectedExecution])
  const architectureSvg = useMemo(() => {
    if (!selectedExecution) return null
    const files = selectedExecution.files.filter((f) => f.kind === 'file')
    const preferred = files.find((f) => normalizeSequencePath(f.relative_path) === 'inputs/graph/architecture_graph.view.svg')
    if (preferred) return preferred
    return files.find((f) => normalizeSequencePath(f.relative_path) === 'inputs/graph/architecture_graph.draft.svg') ?? null
  }, [selectedExecution])
  const architectureSvgDataUrl = useMemo(() => {
    const preview = architectureSvg?.preview_text
    if (!preview || !preview.trim().startsWith('<svg')) return null
    return `data:image/svg+xml;utf8,${encodeURIComponent(preview)}`
  }, [architectureSvg])
  const companionSummary = useMemo(() => {
    const files = (selectedExecution?.files ?? []).map((f) => normalizeSequencePath(f.relative_path))
    const present = new Set(files)
    const preSpec = [
      'inputs/architecture_estimation/pre_spec_bandwidth_proxy.json',
      'inputs/architecture_estimation/pre_spec_power_proxy.json',
      'inputs/architecture_estimation/pre_spec_area_proxy.json',
    ]
    const hierarchy = [
      'inputs/hierarchy/hierarchy_manifest.json',
      'inputs/hierarchy/hierarchy_interface_contracts.json',
      'inputs/hierarchy/hierarchy_partition_report.json',
    ]
    const count = (arr: string[]) => arr.filter((x) => present.has(x)).length
    return { preSpec: `${count(preSpec)}/${preSpec.length}`, hierarchy: `${count(hierarchy)}/${hierarchy.length}` }
  }, [selectedExecution])

  if (loading) return <div className="text-slate-500 animate-pulse font-mono p-8">{t('rev.loading')}</div>
  if (error) return <div className="text-rose-400 bg-rose-950/30 p-6 border border-rose-900 rounded-xl m-8">Error: {error}</div>

  if (!selected) {
    return (
      <div className="text-slate-500 p-8 flex flex-col gap-4">
        <UserCheck className="w-12 h-12 opacity-10" />
        <p>{t('rev.no_records')}</p>
      </div>
    )
  }

  if (items.length === 0) {
    return (
      <div className="text-slate-500 p-8 flex flex-col gap-4">
        <UserCheck className="w-12 h-12 opacity-10" />
        <p>{t('human_review.empty_evidence')}</p>
      </div>
    )
  }

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-2 duration-700">
      <div className="flex justify-between items-end border-b border-slate-800/50 pb-6">
        <div>
          <h1 className="text-4xl font-light text-white mb-2 tracking-tight">{t('rev.title_v3')}</h1>
          <p className="text-slate-400 text-sm max-w-2xl">{t('rev.subtitle_v3')}</p>
          <p className="text-xs text-slate-500 mt-2 font-mono">scope: {selected.chip_id} / {selected.run_id} / {selected.execution_id}</p>
        </div>
        <div className="bg-emerald-500/10 border border-emerald-500/20 px-3 py-1.5 rounded text-[11px] font-mono font-bold text-emerald-400 shadow-xl shadow-emerald-500/5">
          {t('rev.signed_by').toUpperCase()}: evidence-derived
        </div>
      </div>

      <section className="rounded-xl border border-slate-800 bg-slate-900 p-4">
        <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
          <label className="text-xs text-slate-400">
            chip ID
            <select
              className="mt-1 w-full rounded border border-slate-700 bg-slate-950 px-2 py-2 text-sm text-slate-100"
              value={selectedChip?.chip_id ?? ''}
              onChange={(e) => {
                const chip = chips.find((c) => c.chip_id === e.target.value)
                const run = chip?.runs[0]
                const exe = run?.executions[run.executions.length - 1]
                if (chip && run && exe) updateScope(chip.chip_id, run.run_id, exe.execution_id)
              }}
            >
              {chips.map((c) => <option key={c.chip_id} value={c.chip_id}>{c.chip_id}</option>)}
            </select>
          </label>
          <label className="text-xs text-slate-400">
            run ID
            <select
              className="mt-1 w-full rounded border border-slate-700 bg-slate-950 px-2 py-2 text-sm text-slate-100"
              value={selectedRun?.run_id ?? ''}
              onChange={(e) => {
                const run = runOptions.find((r) => r.run_id === e.target.value)
                const exe = run?.executions[run.executions.length - 1]
                if (selectedChip && run && exe) updateScope(selectedChip.chip_id, run.run_id, exe.execution_id)
              }}
            >
              {runOptions.map((r) => <option key={r.run_id} value={r.run_id}>{r.run_id}</option>)}
            </select>
          </label>
          <label className="text-xs text-slate-400">
            execution timestamp
            <select
              className="mt-1 w-full rounded border border-slate-700 bg-slate-950 px-2 py-2 text-sm text-slate-100"
              value={selectedExecution?.execution_id ?? ''}
              onChange={(e) => {
                if (selectedChip && selectedRun) updateScope(selectedChip.chip_id, selectedRun.run_id, e.target.value)
              }}
            >
              {executionOptions.map((x) => <option key={x.execution_id} value={x.execution_id}>{x.execution_id}</option>)}
            </select>
          </label>
        </div>
      </section>

      <section className="rounded-xl border border-slate-800 bg-slate-900 p-4">
        <div className="text-xs uppercase tracking-widest text-slate-500 mb-2">Architecture Graph (SVG)</div>
        {architectureSvg ? (
          <div className="space-y-3">
            <div className="text-xs font-mono text-cyan-300 break-all">{architectureSvg.relative_path}</div>
            {architectureSvgDataUrl ? (
              <div className="rounded border border-slate-800 bg-white p-2 overflow-auto">
                <img src={architectureSvgDataUrl} alt="Architecture graph SVG" className="max-w-full h-auto" />
              </div>
            ) : (
              <div className="text-sm text-amber-300">SVG detected but preview payload is unavailable in inventory.</div>
            )}
          </div>
        ) : (
          <div className="text-sm text-slate-400">No architecture SVG companion found for this execution.</div>
        )}
      </section>
      <section className="rounded-xl border border-slate-800 bg-slate-900 p-4">
        <div className="text-xs uppercase tracking-widest text-slate-500 mb-2">Pre-spec / Hierarchy Companion Coverage</div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
          <div className="rounded border border-slate-800 bg-slate-950 p-3 text-slate-200">Pre-spec estimation: <span className="font-mono text-cyan-300">{companionSummary.preSpec}</span></div>
          <div className="rounded border border-slate-800 bg-slate-950 p-3 text-slate-200">Hierarchy integration: <span className="font-mono text-cyan-300">{companionSummary.hierarchy}</span></div>
        </div>
      </section>

      <div className="space-y-6">
        {items.map((row) => (
          <div key={row.file_ref} className="bg-slate-900 border border-slate-800 rounded-xl p-8 shadow-2xl relative overflow-hidden group hover:border-slate-700 transition-all duration-300">
            <div className="absolute top-0 right-0 p-6 opacity-5 pointer-events-none group-hover:opacity-10 transition-opacity">
              <Shield size={100} className="text-emerald-500" />
            </div>

            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-8 border-b border-slate-800 pb-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-emerald-500/10 flex items-center justify-center border border-emerald-500/20">
                  <BadgeCheck className="text-emerald-500" />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-slate-100 uppercase tracking-tight">{row.key.replace(/_/g, ' ')}</h2>
                  <span className="text-[10px] text-slate-500 font-mono uppercase">ANCHOR: {row.digest.substring(0, 22)}...</span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Clock size={14} className="text-slate-500" />
                <span className="text-xs text-slate-400 font-mono">{row.timestamp}</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
              <div className="space-y-4">
                <div className="space-y-1">
                  <span className="text-[10px] text-slate-500 uppercase font-bold tracking-widest flex items-center gap-1.5"><FileText size={12} className="text-blue-400" /> {t('rev.file_ref')}</span>
                  <div className="bg-slate-950/80 px-3 py-2 rounded border border-slate-800/80 text-xs font-mono text-slate-400 break-all select-all hover:text-blue-300 transition-colors">{row.file_ref}</div>
                </div>
                <div className="space-y-1">
                  <span className="text-[10px] text-slate-500 uppercase font-bold tracking-widest flex items-center gap-1.5"><Hash size={12} className="text-emerald-400" /> {t('rev.digest')}</span>
                  <div className="bg-slate-950/80 px-3 py-2 rounded border border-slate-800/80 text-[10px] font-mono text-emerald-500/70 break-all select-all">{row.digest}</div>
                </div>
              </div>

              <div className="flex flex-col justify-end p-6 bg-emerald-500/5 border border-emerald-500/10 rounded-xl relative">
                <div className="flex items-center gap-3 mb-2">
                  <UserCheck size={18} className="text-emerald-500" />
                  <span className="text-[11px] font-bold text-emerald-500 uppercase tracking-[0.2em]">{t('rev.status')}</span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed italic">"{t('rev.adjudicated_note')}"</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
