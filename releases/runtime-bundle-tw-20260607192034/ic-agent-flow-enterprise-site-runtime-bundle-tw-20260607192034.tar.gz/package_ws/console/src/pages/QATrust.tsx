import { Activity, CheckCircle2, ShieldAlert, Zap } from 'lucide-react'
import { useMemo } from 'react'
import { useLocation } from 'react-router-dom'
import { useTranslation } from '../contexts/i18n'
import Badge from '../components/Badge'
import HeaderIcon from '../components/HeaderIcon'
import { useProductionRunsInventory } from '../hooks/useProductionRunsInventory'
import { flattenExecutions, parseMode, scopedChips, summarizeVerdicts } from '../hooks/evidenceSummary'

export default function QATrust() {
  const { t } = useTranslation()
  const location = useLocation()
  const mode = useMemo(() => parseMode(location.search), [location.search])
  const { data, loading, error } = useProductionRunsInventory({ layeredWithRuns: true })

  const summary = useMemo(() => {
    const chips = scopedChips(data, mode)
    const rows = flattenExecutions(chips)
    return summarizeVerdicts(rows)
  }, [data, mode])

  if (loading) return <div className="text-slate-500 p-6">{t('common.loading')}</div>
  if (error) return <div className="text-rose-400 p-6">{t('common.error')}: {error}</div>

  const cards = [
    { label: t('qa.evidence'), status: summary.pass > 0 ? 'PASS' : 'WARN', icon: CheckCircle2, color: 'text-emerald-400', bg: 'bg-emerald-500/5' },
    { label: t('qa.reval'), status: summary.warn + summary.blocked > 0 ? 'ACTIVE' : 'PASS', icon: Zap, color: 'text-blue-400', bg: 'bg-blue-500/5' },
    { label: t('qa.scenario'), status: summary.unknown > 0 ? 'LIMITED' : 'PASS', icon: Activity, color: 'text-amber-400', bg: 'bg-amber-500/5' },
    { label: t('qa.claim'), status: summary.blocked > 0 ? 'BLOCKED' : summary.warn > 0 ? 'PASS_WITH_WARNINGS' : 'PASS', icon: ShieldAlert, color: 'text-indigo-400', bg: 'bg-indigo-500/5' },
  ]

  const blockers: string[] = []
  if (summary.blocked > 0) blockers.push(`blocked executions: ${summary.blocked}`)
  if (summary.warn > 0) blockers.push(`warn executions: ${summary.warn}`)
  if (summary.unknown > 0) blockers.push(`unknown executions: ${summary.unknown}`)
  if (blockers.length === 0) blockers.push('no active trust blockers in current mode scope')

  return (
    <div className="space-y-5">
      <div className="border-b border-slate-800/50 pb-4">
        <h1 className="text-3xl font-semibold tracking-tight text-white inline-flex items-center gap-2">
          <HeaderIcon name="qa" className="text-cyan-300" size={22} />
          {t('qa_trust.title')}
        </h1>
        <p className="text-sm text-slate-400">{t('qa_trust.subtitle')}</p>
        <p className="mt-1 text-xs text-slate-500">evidence source: production_runs_inventory.json (mode-scoped)</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        {cards.map((card, idx) => (
          <div key={idx} className={`${card.bg} border border-slate-800 rounded-xl p-4 flex items-center justify-between`}>
            <div>
              <div className="text-sm text-slate-400 uppercase tracking-wide">{card.label}</div>
              <div className="mt-1"><Badge label={card.status.toUpperCase()} /></div>
            </div>
            <card.icon className={`w-8 h-8 ${card.color} opacity-70`} />
          </div>
        ))}
      </div>

      <div className="rounded-xl border border-slate-800 bg-slate-900 p-5">
        <h2 className="text-base font-semibold text-slate-100">{t('qa_trust.blockers_title')}</h2>
        <ul className="mt-3 list-disc list-inside text-slate-300 space-y-1">
          {blockers.map((b) => <li key={b} className="font-mono text-sm">{b}</li>)}
        </ul>
      </div>
    </div>
  )
}
