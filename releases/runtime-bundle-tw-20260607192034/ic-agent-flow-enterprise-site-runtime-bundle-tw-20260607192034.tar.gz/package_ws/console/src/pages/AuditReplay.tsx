import { FileCode2, FileJson2, FileText } from 'lucide-react'
import { useMemo, useState } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { useTranslation } from '../contexts/i18n'
import { useProductionRunsInventory } from '../hooks/useProductionRunsInventory'
import { flattenExecutions, parseMode, resolveExecution, scopedChips } from '../hooks/evidenceSummary'

function normalizeSequencePath(path: string) {
  const segs = path.split('/')
  if (segs.length === 0) return path
  segs[0] = segs[0].replace(/^\d+_/, '')
  return segs.join('/')
}

function iconForFile(name: string) {
  if (name.endsWith('.json')) return <FileJson2 size={14} className="text-cyan-300" />
  if (name.endsWith('.md') || name.endsWith('.log')) return <FileCode2 size={14} className="text-blue-300" />
  return <FileText size={14} className="text-slate-300" />
}

export default function AuditReplay() {
  const { t } = useTranslation()
  const location = useLocation()
  const navigate = useNavigate()
  const params = useMemo(() => new URLSearchParams(location.search), [location.search])
  const mode = useMemo(() => parseMode(location.search), [location.search])
  const requestedChip = params.get('chip') ?? ''
  const requestedRun = params.get('run') ?? ''
  const requestedExecution = params.get('execution') ?? ''
  const { data, loading, error } = useProductionRunsInventory({ layeredWithRuns: true })
  const resolvedScope = useMemo(() => {
    const chips = scopedChips(data, mode)
    const rows = flattenExecutions(chips)
    return resolveExecution(rows, requestedChip, requestedRun, requestedExecution)
  }, [data, mode, requestedChip, requestedRun, requestedExecution])
  const effectiveChipId = requestedChip || resolvedScope?.chip_id || ''
  const effectiveRunId = requestedRun || resolvedScope?.run_id || ''
  const effectiveExecutionId = requestedExecution || resolvedScope?.execution_id || ''
  const chips = useMemo(() => scopedChips(data, mode), [data, mode])
  const selectedChip = useMemo(() => {
    if (!chips.length) return null
    return chips.find((c) => c.chip_id === effectiveChipId) ?? chips[0]
  }, [chips, effectiveChipId])
  const runOptions = useMemo(() => selectedChip?.runs ?? [], [selectedChip])
  const selectedRun = useMemo(() => {
    if (!runOptions.length) return null
    return runOptions.find((r) => r.run_id === effectiveRunId) ?? runOptions[0]
  }, [runOptions, effectiveRunId])
  const executionOptions = useMemo(() => {
    if (!selectedRun) return []
    return [...selectedRun.executions].sort((a, b) => b.execution_id.localeCompare(a.execution_id))
  }, [selectedRun])
  const selectedExecution = useMemo(() => {
    if (!executionOptions.length) return null
    return executionOptions.find((e) => e.execution_id === effectiveExecutionId) ?? executionOptions[0]
  }, [executionOptions, effectiveExecutionId])
  const setScope = (chip: string, run: string, execution: string) => {
    const q = new URLSearchParams()
    q.set('mode', mode)
    if (chip) q.set('chip', chip)
    if (run) q.set('run', run)
    if (execution) q.set('execution', execution)
    navigate(`/audit-replay?${q.toString()}`)
  }
  const focusChip = resolvedScope?.chip_id ?? ''
  const focusRun = resolvedScope?.run_id ?? ''
  const focusExecution = resolvedScope?.execution_id ?? ''

  const focusFiles = useMemo(() => {
    const execution = resolvedScope?.execution
    if (!execution) return []
    return execution.files
      .filter((f) => {
        if (f.kind !== 'file') return false
        const logicalPath = normalizeSequencePath(f.relative_path)
        return /subject_binding\//.test(logicalPath) || /skill_usage\//.test(logicalPath) || /normalized\..*\.json$/i.test(logicalPath) || /readiness_report/i.test(logicalPath)
      })
      .slice(0, 80)
  }, [resolvedScope])
  const [selectedPath, setSelectedPath] = useState('')
  const defaultSelectedPath = useMemo(
    () => focusFiles.find((f) => f.kind === 'file' && f.preview_text)?.relative_path ?? '',
    [focusFiles],
  )
  const effectiveSelectedPath = selectedPath || defaultSelectedPath
  const selectedFile = useMemo(
    () => focusFiles.find((f) => f.relative_path === effectiveSelectedPath && f.kind === 'file') ?? null,
    [focusFiles, effectiveSelectedPath],
  )

  if (loading) return <div className="text-slate-500 font-mono text-sm animate-pulse p-8">{t('common.loading')}</div>
  if (error) return <div className="text-rose-400 p-6">{t('common.error')}: {error}</div>

  return (
    <div className="space-y-6">
      <div className="border-b border-slate-800/50 pb-5">
        <h1 className="text-3xl font-semibold tracking-tight text-white">{t('nav.audit_replay')}</h1>
        <p className="text-sm text-slate-400 mt-1">{t('audit_replay.subtitle')}</p>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
        <label className="rounded-xl border border-slate-800 bg-slate-900 p-4">
          <div className="text-xs uppercase tracking-widest text-slate-500 mb-2">{t('run_explorer.chip_id')}</div>
          <select
            className="w-full rounded-md border border-slate-700 bg-slate-950 px-3 py-2 text-slate-200"
            value={selectedChip?.chip_id ?? ''}
            onChange={(e) => {
              const chip = chips.find((c) => c.chip_id === e.target.value)
              const run = chip?.runs[0]
              const exec = run ? [...run.executions].sort((a, b) => b.execution_id.localeCompare(a.execution_id))[0] : null
              setScope(chip?.chip_id ?? '', run?.run_id ?? '', exec?.execution_id ?? '')
            }}
          >
            {chips.map((chip) => (
              <option key={chip.chip_id} value={chip.chip_id}>
                {chip.chip_id} ({chip.source_dir})
              </option>
            ))}
          </select>
        </label>
        <label className="rounded-xl border border-slate-800 bg-slate-900 p-4">
          <div className="text-xs uppercase tracking-widest text-slate-500 mb-2">{t('run_explorer.run_id')}</div>
          <select
            className="w-full rounded-md border border-slate-700 bg-slate-950 px-3 py-2 text-slate-200"
            value={selectedRun?.run_id ?? ''}
            onChange={(e) => {
              const run = runOptions.find((r) => r.run_id === e.target.value)
              const exec = run ? [...run.executions].sort((a, b) => b.execution_id.localeCompare(a.execution_id))[0] : null
              setScope(selectedChip?.chip_id ?? '', run?.run_id ?? '', exec?.execution_id ?? '')
            }}
          >
            {runOptions.map((run) => (
              <option key={run.run_id} value={run.run_id}>{run.run_id}</option>
            ))}
          </select>
        </label>
        <label className="rounded-xl border border-slate-800 bg-slate-900 p-4">
          <div className="text-xs uppercase tracking-widest text-slate-500 mb-2">{t('run_explorer.execution_ts')}</div>
          <select
            className="w-full rounded-md border border-slate-700 bg-slate-950 px-3 py-2 text-slate-200"
            value={selectedExecution?.execution_id ?? ''}
            onChange={(e) => setScope(selectedChip?.chip_id ?? '', selectedRun?.run_id ?? '', e.target.value)}
          >
            {executionOptions.map((execution) => (
              <option key={execution.execution_id} value={execution.execution_id}>{execution.execution_id}</option>
            ))}
          </select>
        </label>
      </div>

      {focusChip && focusRun && focusExecution ? (
        <section className="space-y-3 rounded-xl border border-cyan-900/50 bg-cyan-950/20 p-4">
          <div className="flex flex-col gap-2 lg:flex-row lg:items-center lg:justify-between">
            <div className="min-w-0">
              <div className="text-xs uppercase tracking-wider text-cyan-300">{t('audit_replay.focused_context')}</div>
              <div className="font-mono text-xs text-cyan-100 break-all">{focusChip} / {focusRun} / {focusExecution}</div>
            </div>
            <div className="flex gap-2 shrink-0">
              <Link to={`/run/${encodeURIComponent(focusChip)}?mode=${mode}&run=${encodeURIComponent(focusRun)}&execution=${encodeURIComponent(focusExecution)}`} className="rounded border border-cyan-700/50 bg-cyan-900/20 px-2 py-1 text-xs text-cyan-200 hover:bg-cyan-900/40">{t('audit_replay.open_run_evidence')}</Link>
              <Link to={`/decision-inbox?mode=${mode}&chip=${encodeURIComponent(focusChip)}&run=${encodeURIComponent(focusRun)}&execution=${encodeURIComponent(focusExecution)}`} className="rounded border border-indigo-700/50 bg-indigo-900/20 px-2 py-1 text-xs text-indigo-200 hover:bg-indigo-900/40">{t('audit_replay.open_decision_inbox')}</Link>
            </div>
          </div>
          <div className="rounded-lg border border-slate-800 bg-slate-950/70 p-3">
            <div className="text-xs text-slate-400 mb-2">{t('audit_replay.evidence_files')} ({focusFiles.length})</div>
            {focusFiles.length === 0 ? (
              <div className="text-xs text-slate-500">{t('audit_replay.no_replay_files')}</div>
            ) : (
              <div className="space-y-2">
                <div className="text-xs text-slate-500">{t('run_explorer.structure_hint')}</div>
                <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
                  <div className="rounded-lg border border-slate-800 bg-slate-900 p-2 max-h-72 overflow-y-auto">
                    <div className="space-y-1">
                      {focusFiles.map((f) => {
                        const active = effectiveSelectedPath === f.relative_path
                        return (
                          <button
                            key={f.relative_path}
                            type="button"
                            className={`w-full text-left rounded px-2 py-1 text-xs font-mono break-all ${
                              active ? 'bg-cyan-500/15 text-cyan-200' : 'text-slate-300 hover:bg-slate-800'
                            }`}
                            onClick={() => setSelectedPath(f.relative_path)}
                          >
                            <span className="inline-flex items-center gap-2">
                              {iconForFile(f.relative_path)}
                              <span>{f.relative_path}</span>
                            </span>
                          </button>
                        )
                      })}
                    </div>
                  </div>
                  <div className="rounded-lg border border-slate-800 bg-slate-900 p-3 min-h-[220px]">
                    {!selectedFile ? (
                      <div className="text-xs text-slate-500">{t('run_explorer.select_file')}</div>
                    ) : (
                      <div className="space-y-2">
                        <div className="text-xs text-slate-500 break-all">
                          {t('run_explorer.path')}: <span className="font-mono text-slate-400">{selectedFile.relative_path}</span>
                        </div>
                        {/\.(md|json|log)$/i.test(selectedFile.relative_path) && selectedFile.preview_text ? (
                          <pre className="text-xs text-slate-200 whitespace-pre-wrap break-words max-h-56 overflow-y-auto">
                            {selectedFile.preview_text}
                          </pre>
                        ) : (
                          <div className="text-xs text-slate-500">{t('run_explorer.preview_not_supported')}</div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        </section>
      ) : (
        <section className="rounded-xl border border-amber-900/50 bg-amber-950/20 p-4 text-xs text-amber-200">
          {t('audit_replay.no_scope')}
        </section>
      )}
    </div>
  )
}
