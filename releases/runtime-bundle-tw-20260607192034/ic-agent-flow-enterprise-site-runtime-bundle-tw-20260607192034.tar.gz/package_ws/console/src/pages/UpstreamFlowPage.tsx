import { useEffect, useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import FileFamilyExplorer, { type FileFamilyEntry } from '../components/FileFamilyExplorer'
import HeaderIcon from '../components/HeaderIcon'
import UpstreamTruthFlowBoard from '../components/UpstreamTruthFlowBoard'
import type { UpstreamTruthFlowNode } from '../components/UpstreamTruthFlowBoard'
import { useTranslation } from '../contexts/i18n'

type UpstreamChipOption = {
  chip_id: string
  scope_type?: string
  source_dir?: string
}

type UpstreamContext = {
  status: string
  chip_id: string
  scope_type?: string
  upstream_operation_id?: string
  review_package?: {
    status?: string
    intake_session_id?: string
    source_session_ref?: string
  }
  builder_handoff?: {
    handoff_status?: string
  }
  adjudication_record?: {
    status?: string
    decision_outcome?: string
    decision_rationale?: string
    authority_signer?: string
  } | null
  upstream_truth_flow?: UpstreamTruthFlowNode[]
  upstream_node_status?: UpstreamTruthFlowNode[]
}

const remainingNodeIds = new Set(['graph_draft_check', 'graph_validation', 'freeze', 'generation_plan', 'rtl_generation', 'v09_handoff_preflight'])

function sessionIdOf(context: UpstreamContext): string {
  return context.review_package?.intake_session_id
    || context.review_package?.source_session_ref?.split('/').filter(Boolean).pop()
    || '-'
}

function buildHandoffPrompt(context: UpstreamContext, nodes: UpstreamTruthFlowNode[]): string {
  const chipId = context.chip_id
  const sessionId = sessionIdOf(context)
  const missingFiles = nodes.flatMap((node) => node.missing_files ?? [])
  return [
    'Task: Continue PRD v1.0 upstream truth flow toward PRD v0.9 (Codex CLI GPT-5.5 execution contract)',
    '',
      'Execution profile:',
      '- model_hint: gpt-5.5',
      '- mode: local codex cli agent',
      '- policy: fail-closed, machine-readable outputs only',
      '- operator_runbook: package_ws/docs/governance/ops/prd-v0.9-routine-b-operator-runbook.v0.1.md',
      '',
      'Scope:',
    '- scope_type: CHIP_UPSTREAM',
    `- chip_id: ${chipId}`,
    `- intake_session_id: ${sessionId}`,
    `- upstream_operation_id: ${context.upstream_operation_id ?? '-'}`,
    `- adjudication_status: ${context.adjudication_record?.status ?? 'NOT_RECORDED'}`,
    `- builder_handoff_status: ${context.builder_handoff?.handoff_status ?? '-'}`,
    '',
    'Current remaining PRD v1.0 nodes:',
    ...nodes.map((node) => `- ${node.node_id}: ${node.status} -> next_action=${node.next_action ?? '-'}`),
    '',
    'Missing refs to prepare or close:',
    ...(missingFiles.length ? missingFiles.map((ref) => `- ${ref}`) : ['- none']),
    '',
    'Preflight checks (must pass before mutations):',
    '1. Resolve all canonical refs and fail if any required ref is missing.',
    '2. Verify chip_id/session_id in refs match scope values exactly.',
    '3. Verify adjudication record status is DECISION_RECORDED before freeze-path mutations.',
    '3.1 Enforce PASS criteria for every upstream node: required JSON records + full node output files must exist, and every previous upstream node must already be PASS.',
    '3.2 If a previous node is not PASS, fix that previous node first; do not advance or mark later nodes as complete.',
    '4. OpenAI execution preflight (required for real graph generation):',
    '   - Use repo virtualenv python: .venv/bin/python',
    '   - Ensure OPENAI_API_KEY is loaded (script supports .env fallback but runtime value must exist)',
    '   - Ensure openai package is importable in .venv',
    '   - Execute Route-A real call (no --openai-test-text) and require route_a_execution_mode=remote_openai + orchestration.status=DRAFT_SAVED',
    '   - If execution_mode is local_fallback or synthetic_backfill, stop fail-closed and emit blocker instead of pseudo-pass',
    '4.1 Generate or refresh chips/<chip_id>/governance/upstream_alignment_map.json from current upstream truth; JSON is the agent routing contract and upstream_alignment_map.md must be generated from JSON only.',
    '',
    'Required behavior:',
    '1. Do not create run_id.',
    '2. Do not create artifacts/production-runs.',
    '3. Stay in chips/<chip_id>/ CHIP_UPSTREAM scope.',
    '4. Generate or refine the real canonical graph candidate at chips/<chip_id>/architecture/architecture_graph.json from the adjudicated requirements; architecture_graph.draft.json is only the intake scaffold.',
    '4.1 Materialize graph companion views for human review under chips/<chip_id>/architecture/: architecture_graph.md, architecture_graph.mmd, architecture_graph.draft.dot (companions do not replace canonical JSON).',
    '5. Preserve graph-builder limits: the OpenAI/local AI graph builder may construct/refine graph JSON, but validators establish graph legality and human authority controls freeze.',
    '6. Materialize full Graph Validation node outputs under chips/<chip_id>/architecture/:',
    '   - validation/graph_validation_result.json',
    '   - validation/validator_run_record.json',
    '   - graph_issue.json (or equivalent issue list object)',
    '   - interface_binding_record.json (or equivalent binding snapshot)',
    '7. Do not create requirement_freeze_record or graph_freeze_record without explicit authority transition.',
    '8. If transition is valid, materialize full Freeze node outputs under chips/<chip_id>/governance/freeze/:',
    '   - requirement_freeze_record.json',
    '   - graph_freeze_record.json',
    '   - freeze_summary.md',
    '9. Do not create graph_to_generation_plan until freeze outputs are valid.',
    '10. After freeze, materialize full Generation Plan node outputs under chips/<chip_id>/generation/:',
    '   - graph_to_generation_plan.json',
    '   - generation_plan.md',
    '11. After generation plan is ready, materialize full RTL node outputs under chips/<chip_id>/rtl/:',
    '   - rtl_generation_request.json',
    '   - rtl_generation_record.json',
    '   - rtl_manifest.json',
    '   - candidate RTL files (*.v / *.sv)',
    '12. Generated RTL is a candidate input for PRD v0.9 Routine-B; it is not release truth until downstream evidence and human review close.',
    '12. When RTL candidate is ready, prepare a bounded PRD v0.9 handoff summary for runner execution.',
    '13. PRD v0.9 runner must snapshot chips/<chip_id>/ outputs into run-local inputs/; generate_sequence prefixes may render that folder as 01_inputs/ in artifacts/production-runs.',
    '14. After any upstream execution change, regenerate upstream_alignment_map.json/md so the local AI agent can route files, console surfaces, and PRD refs without re-tracing code.',
    '',
    'Completion criteria:',
    '- Overall PASS is sequential: a node can PASS only when its own required JSON records and full node outputs exist, and every previous upstream node is PASS.',
    '- Graph Validation full outputs exist and are internally consistent.',
    '- Freeze full outputs exist only after validation pass + authority transition.',
    '- Generation Plan full outputs exist only after freeze outputs exist.',
    '- RTL full outputs exist only after generation plan exists.',
    '- Before PRD v0.9 handoff, generate chips/<chip_id>/governance/v09_handoff_preflight_manifest.json and require status=READY_FOR_V09_HANDOFF.',
    '- v09 handoff preflight missing_sources must be empty before runner execution.',
    '- After PRD v0.9 runner execution, review readiness_report.v0.2.md and deep-dive every yellow/red item before claiming Routine-B closeout.',
    '- No downstream run artifacts created in this phase.',
    '',
    'Fail-closed rules:',
    '- If any node cannot be completed, stop and emit blockers with exact missing files and corrective action.',
    '- If any previous node is not PASS, mark later nodes as blocked by dependency and solve the previous node first.',
    '- If v09_handoff_preflight_manifest.json reports missing_sources, do root-cause remediation first: classify missing family/node, inspect producer prompt/contract/generator/mapping/checker, fix the root cause, regenerate outputs, rerun upstream_node_output_check, then regenerate the manifest.',
    '- Backfilling a missing file without fixing the producer or contract gap is not closeout.',
    '- Never infer human approval from UI state; use machine-readable adjudication record only.',
    '- Never overwrite immutable evidence snapshots.',
    '- Do not claim graph generation success unless route_a_openai_worker_audit.json shows provider=openai, response_type=text, success=true.',
    '- Do not claim PRD v0.9 closeout until yellow/red readiness items are dispositioned with root-cause classification and closure artifacts.',
    '',
    'Key refs:',
    `- chips/${chipId}/specs/requirement_item_adjudication_record.json`,
    `- chips/${chipId}/architecture/architecture_graph.draft.json`,
    `- chips/${chipId}/architecture/architecture_graph.json`,
    `- chips/${chipId}/architecture/builder_validation_handoff.json`,
    `- chips/${chipId}/architecture/validation/graph_validation_result.json`,
    `- chips/${chipId}/architecture/validation/validator_run_record.json`,
    `- chips/${chipId}/governance/freeze/requirement_freeze_record.json`,
    `- chips/${chipId}/governance/freeze/graph_freeze_record.json`,
    `- chips/${chipId}/generation/graph_to_generation_plan.json`,
    `- chips/${chipId}/rtl/rtl_generation_request.json`,
    `- chips/${chipId}/rtl/rtl_generation_record.json`,
    `- chips/${chipId}/rtl/<generated RTL candidate files>`,
  ].join('\n')
}

export default function UpstreamFlowPage() {
  const { t } = useTranslation()
  const [searchParams, setSearchParams] = useSearchParams()
  const chipId = (searchParams.get('chip') || '').trim()
  const [chipOptions, setChipOptions] = useState<UpstreamChipOption[]>([])
  const [chipOptionsLoading, setChipOptionsLoading] = useState(true)
  const [chipOptionsError, setChipOptionsError] = useState('')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [context, setContext] = useState<UpstreamContext | null>(null)
  const [upstreamFiles, setUpstreamFiles] = useState<FileFamilyEntry[]>([])

  useEffect(() => {
    let cancelled = false
    async function loadChips() {
      setChipOptionsLoading(true)
      setChipOptionsError('')
      try {
        const response = await fetch('/api/intake/chips', { cache: 'no-store' })
        const payload = await response.json()
        if (!response.ok) throw new Error(payload?.error ?? `http_${response.status}`)
        if (!cancelled) {
          setChipOptions(Array.isArray(payload?.chips) ? payload.chips : [])
        }
      } catch (fetchError) {
        if (!cancelled) {
          setChipOptions([])
          setChipOptionsError(fetchError instanceof Error ? fetchError.message : 'unknown_error')
        }
      } finally {
        if (!cancelled) setChipOptionsLoading(false)
      }
    }
    void loadChips()
    return () => {
      cancelled = true
    }
  }, [])

  useEffect(() => {
    let cancelled = false
    async function load() {
      if (!chipId) {
        setLoading(false)
        setError('')
        setContext(null)
        return
      }
      setLoading(true)
      setError('')
      try {
        const response = await fetch(`/api/intake/adjudication?chip_id=${encodeURIComponent(chipId)}`)
        const payload = await response.json()
        if (!response.ok) throw new Error(payload?.error ?? `http_${response.status}`)
        if (!cancelled) setContext(payload)
      } catch (fetchError) {
        if (!cancelled) setError(fetchError instanceof Error ? fetchError.message : 'unknown_error')
      } finally {
        if (!cancelled) setLoading(false)
      }
    }
    void load()
    return () => {
      cancelled = true
    }
  }, [chipId])

  useEffect(() => {
    let cancelled = false
    async function loadFiles() {
      if (!chipId) {
        setUpstreamFiles([])
        return
      }
      try {
        const response = await fetch(`/api/intake/upstream-files?chip_id=${encodeURIComponent(chipId)}`, { cache: 'no-store' })
        const payload = await response.json()
        if (!response.ok) throw new Error(payload?.error ?? `http_${response.status}`)
        if (!cancelled) setUpstreamFiles(Array.isArray(payload?.files) ? payload.files : [])
      } catch {
        if (!cancelled) setUpstreamFiles([])
      }
    }
    void loadFiles()
    return () => {
      cancelled = true
    }
  }, [chipId])

  function selectChip(nextChipId: string) {
    if (!nextChipId) return
    const next = new URLSearchParams(searchParams)
    next.set('chip', nextChipId)
    setSearchParams(next)
  }

  const remainingNodes = useMemo(() => {
    const sourceNodes = context?.upstream_node_status ?? context?.upstream_truth_flow ?? []
    return sourceNodes.filter((node) => remainingNodeIds.has(node.node_id))
  }, [context])
  const handoffPrompt = context ? buildHandoffPrompt(context, remainingNodes) : ''

  if (loading) return <div className="p-8 text-sm text-slate-400">{t('common.loading')}</div>
  if (!chipId) {
    return (
      <div className="space-y-7">
        <header className="rounded-xl border border-cyan-500/30 bg-gradient-to-br from-cyan-500/10 via-slate-900 to-slate-950 p-7 shadow-lg shadow-cyan-500/10">
          <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-cyan-400/40 bg-cyan-500/15 px-3 py-1 text-sm font-semibold tracking-wide text-cyan-300">
            <HeaderIcon name="upstream" size={14} />
            {t('upstream_flow.badge')}
          </div>
          <h1 className="inline-flex items-center gap-3 text-3xl font-bold text-white">
            <HeaderIcon name="upstream" size={24} className="text-cyan-300" />
            <span>{t('upstream_flow.title')}</span>
          </h1>
          <p className="mt-3 max-w-5xl text-base leading-7 text-slate-300">{t('upstream_flow.subtitle')}</p>
        </header>

        <section className="rounded-xl border border-slate-800 bg-slate-900/70 p-6">
          <div className="max-w-2xl space-y-4">
            <div>
              <h2 className="text-lg font-semibold text-white">{t('upstream_flow.select_chip_title')}</h2>
              <p className="mt-2 text-sm leading-6 text-slate-300">{t('upstream_flow.select_chip_subtitle')}</p>
            </div>
            <label className="block text-sm text-slate-300">
              <div className="mb-2 font-semibold text-slate-400">{t('upstream_flow.select_chip_label')}</div>
              <select
                aria-label={t('upstream_flow.select_chip_label')}
                defaultValue=""
                onChange={(e) => selectChip(e.target.value)}
                disabled={chipOptionsLoading || chipOptions.length === 0}
                className="w-full rounded-lg border border-slate-700 bg-slate-950 px-4 py-3 text-base text-slate-100 outline-none focus:border-cyan-400 disabled:cursor-not-allowed disabled:text-slate-500"
              >
                <option value="">{t('upstream_flow.select_chip_placeholder')}</option>
                {chipOptions.map((chip) => (
                  <option key={chip.chip_id} value={chip.chip_id}>
                    {chip.chip_id}
                  </option>
                ))}
              </select>
            </label>
            {chipOptionsLoading && <div className="text-sm text-slate-400">{t('common.loading')}</div>}
            {!chipOptionsLoading && chipOptionsError && (
              <div className="text-sm text-rose-300">{t('common.error')}: {chipOptionsError}</div>
            )}
            {!chipOptionsLoading && !chipOptionsError && chipOptions.length === 0 && (
              <div className="text-sm text-slate-400">{t('upstream_flow.no_chip_options')}</div>
            )}
          </div>
        </section>
      </div>
    )
  }
  if (error) return <div className="p-8 text-sm text-rose-300">{t('common.error')}: {error}</div>
  if (!context) return <div className="p-8 text-sm text-slate-400">{t('upstream_flow.no_context')}</div>

  const adjudicationRecorded = context.adjudication_record?.status === 'DECISION_RECORDED'

  return (
    <div className="space-y-7">
      <header className="rounded-xl border border-cyan-500/30 bg-gradient-to-br from-cyan-500/10 via-slate-900 to-slate-950 p-7 shadow-lg shadow-cyan-500/10">
        <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-cyan-400/40 bg-cyan-500/15 px-3 py-1 text-sm font-semibold tracking-wide text-cyan-300">
          <HeaderIcon name="upstream" size={14} />
          {t('upstream_flow.badge')}
        </div>
        <h1 className="inline-flex items-center gap-3 text-3xl font-bold text-white">
          <HeaderIcon name="upstream" size={24} className="text-cyan-300" />
          <span>{t('upstream_flow.title')}</span>
        </h1>
        <p className="mt-3 max-w-5xl text-base leading-7 text-slate-300">{t('upstream_flow.subtitle')}</p>
      </header>

      <section className="grid gap-4 lg:grid-cols-[1fr_1fr_1fr]">
        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4 text-sm leading-6 text-slate-300">
          <div><span className="text-slate-500">scope_type:</span> {context.scope_type ?? 'CHIP_UPSTREAM'}</div>
          <div><span className="text-slate-500">chip_id:</span> {context.chip_id}</div>
          <div><span className="text-slate-500">upstream_operation_id:</span> {context.upstream_operation_id ?? '-'}</div>
        </div>
        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4 text-sm leading-6 text-slate-300">
          <div><span className="text-slate-500">adjudication_status:</span> {context.adjudication_record?.status ?? 'NOT_RECORDED'}</div>
          <div><span className="text-slate-500">review_package:</span> {context.review_package?.status ?? '-'}</div>
          <div><span className="text-slate-500">handoff_status:</span> {context.builder_handoff?.handoff_status ?? '-'}</div>
        </div>
        <div className="rounded-xl border border-amber-500/30 bg-amber-500/10 p-4 text-sm leading-6 text-amber-100">
          <div className="font-semibold text-amber-200">{t('upstream_flow.boundary_title')}</div>
          <div>{adjudicationRecorded ? t('upstream_flow.boundary_ready') : t('upstream_flow.boundary_blocked')}</div>
        </div>
      </section>

      <UpstreamTruthFlowBoard chipId={context.chip_id} nodes={remainingNodes} />

      <FileFamilyExplorer
        title={t('upstream_files.title')}
        subtitle={t('upstream_files.subtitle')}
        files={upstreamFiles}
      />

      <section className="grid gap-7 xl:grid-cols-[1fr_1fr]">
        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-6">
          <h2 className="mb-3 text-lg font-semibold text-cyan-300">{t('upstream_flow.prepare_title')}</h2>
          <div className="space-y-3 text-sm leading-6 text-slate-300">
            <p>{t('upstream_flow.prepare_note')}</p>
            <ol className="list-decimal space-y-2 pl-5">
              <li>{t('upstream_flow.step_graph_validation')}</li>
              <li>{t('upstream_flow.step_real_graph')}</li>
              <li>{t('upstream_flow.step_freeze')}</li>
              <li>{t('upstream_flow.step_generation_plan')}</li>
              <li>{t('upstream_flow.step_rtl_generation')}</li>
              <li>{t('upstream_flow.step_run_inputs')}</li>
              <li>{t('upstream_flow.step_v09')}</li>
            </ol>
          </div>
        </div>
        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-6">
          <h2 className="mb-3 text-lg font-semibold text-cyan-300">{t('upstream_flow.handoff_title')}</h2>
          <textarea
            aria-label={t('upstream_flow.handoff_title')}
            readOnly
            value={handoffPrompt}
            className="h-96 w-full resize-y rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 font-mono text-xs leading-5 text-slate-200 outline-none"
          />
        </div>
      </section>
    </div>
  )
}
