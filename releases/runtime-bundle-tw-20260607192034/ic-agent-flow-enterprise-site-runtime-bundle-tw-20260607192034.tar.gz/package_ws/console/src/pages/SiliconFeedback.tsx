import { ChevronDown, ChevronRight, FileCode2, FileJson2, FileText } from 'lucide-react'
import { useEffect, useMemo, useState } from 'react'
import type { ReactNode } from 'react'
import { useLocation, useNavigate, useParams } from 'react-router-dom'
import { parseMode, sortChipsForMode } from '../hooks/evidenceSummary'
import { useProductionRunsInventory } from '../hooks/useProductionRunsInventory'
import { useRunDetailExecutions } from '../hooks/useRunDetailExecutions'
import { useTranslation } from '../contexts/i18n'
type FileEntry = { relative_path: string; kind: 'file' | 'dir'; preview_text?: string | null; size_bytes?: number }
type TreeNode = { name: string; path: string; kind: 'dir' | 'file'; children: TreeNode[]; preview_text?: string | null; size_bytes?: number }

function normalizeSequencePath(path: string) {
  return path
    .split('/')
    .map((seg) => seg.replace(/^\d+_/, ''))
    .join('/')
}

function parseArtifactJson(files: FileEntry[], logicalPath: string) {
  const normalizedLogicalPath = normalizeSequencePath(logicalPath)
  const found = files.find(
    (f) =>
      f.kind === 'file' &&
      (f.relative_path === logicalPath || normalizeSequencePath(f.relative_path) === normalizedLogicalPath),
  )
  if (!found?.preview_text) return null
  try {
    return JSON.parse(found.preview_text) as Record<string, unknown>
  } catch {
    return null
  }
}

function buildTree(fileList: FileEntry[]): TreeNode[] {
  const root: TreeNode = { name: '/', path: '', kind: 'dir', children: [] }
  const nodeMap = new Map<string, TreeNode>([['', root]])
  const sorted = [...fileList].sort((a, b) => a.relative_path.localeCompare(b.relative_path))
  for (const item of sorted) {
    const segs = item.relative_path.split('/').filter(Boolean)
    let currentPath = ''
    let parent = root
    for (let i = 0; i < segs.length; i += 1) {
      const seg = segs[i]
      currentPath = currentPath ? `${currentPath}/${seg}` : seg
      const isLeaf = i === segs.length - 1
      const kind: 'dir' | 'file' = isLeaf ? item.kind : 'dir'
      if (!nodeMap.has(currentPath)) {
        const node: TreeNode = { name: seg, path: currentPath, kind, children: [], preview_text: isLeaf ? item.preview_text ?? null : null, size_bytes: isLeaf ? item.size_bytes : 0 }
        nodeMap.set(currentPath, node)
        parent.children.push(node)
      }
      parent = nodeMap.get(currentPath)!
    }
  }
  const sortNodes = (nodes: TreeNode[]) => {
    nodes.sort((a, b) => (a.kind !== b.kind ? (a.kind === 'dir' ? -1 : 1) : a.name.localeCompare(b.name)))
    nodes.forEach((n) => sortNodes(n.children))
  }
  sortNodes(root.children)
  return root.children
}

function iconForFile(name: string) {
  if (name.endsWith('.json')) return <FileJson2 size={14} className="text-cyan-300" />
  if (name.endsWith('.md') || name.endsWith('.log')) return <FileCode2 size={14} className="text-blue-300" />
  return <FileText size={14} className="text-slate-300" />
}

function resolveActionCommandContext(resolvedRoot: string | undefined, fallbackRelativeRunDir: string) {
  const normalizedFallback = fallbackRelativeRunDir.replace(/\\/g, '/')
  const source = (resolvedRoot ?? '').trim().replace(/\\/g, '/')
  if (!source) {
    return { scriptPath: 'package_ws/shared-runtime/scripts/apply_v115_decision_action.py', runDirArg: normalizedFallback }
  }
  const repoMarker = '/artifacts/production-runs/'
  const repoIdx = source.lastIndexOf(repoMarker)
  if (repoIdx >= 0) {
    return {
      scriptPath: 'package_ws/shared-runtime/scripts/apply_v115_decision_action.py',
      runDirArg: source.slice(repoIdx + 1),
    }
  }
  const releaseMarker = '/production-runs/'
  const releaseIdx = source.lastIndexOf(releaseMarker)
  if (releaseIdx >= 0) {
    const sourceRunDir = source.slice(releaseIdx + 1)
    if (normalizedFallback.startsWith('artifacts/production-runs/')) {
      return {
        scriptPath: 'scripts/apply_v115_decision_action.py',
        runDirArg: normalizedFallback,
      }
    }
    return {
      scriptPath: 'scripts/apply_v115_decision_action.py',
      runDirArg: sourceRunDir,
    }
  }
  return { scriptPath: 'scripts/apply_v115_decision_action.py', runDirArg: normalizedFallback }
}

export default function SiliconFeedback() {
  const { bundleId } = useParams<{ bundleId: string }>()
  const location = useLocation()
  const navigate = useNavigate()
  const { t } = useTranslation()
  const mode = useMemo(() => parseMode(location.search), [location.search])
  const searchParams = useMemo(() => new URLSearchParams(location.search), [location.search])
  const requestedRunId = searchParams.get('run') ?? ''
  const requestedExecutionId = searchParams.get('execution') ?? ''
  const { data, loading, error } = useProductionRunsInventory({ layeredWithRuns: true })

  const chips = useMemo(() => sortChipsForMode(data?.chips ?? [], mode), [data, mode])
  const [chipSourceDirOverride, setChipSourceDirOverride] = useState('')
  const initialChip = useMemo(() => (!chips.length ? '' : !bundleId ? chips[0].source_dir : chips.find((c) => c.chip_id === bundleId)?.source_dir ?? chips[0].source_dir), [bundleId, chips])
  const selectedChip = chips.find((c) => c.source_dir === (chipSourceDirOverride || initialChip))
  const runs = selectedChip?.runs ?? []
  const [runOverride, setRunOverride] = useState('')
  const runId = runOverride || (requestedRunId && runs.some((r) => r.run_id === requestedRunId) ? requestedRunId : runs[0]?.run_id || '')
  const selectedRun = runs.find((r) => r.run_id === runId)
  const { executions: runDetailExecutions } = useRunDetailExecutions(selectedChip?.source_dir ?? '', selectedRun?.run_id ?? '')
  const executions = runDetailExecutions ?? selectedRun?.executions ?? []
  const [executionOverride, setExecutionOverride] = useState('')
  const executionId = executionOverride || (requestedExecutionId && executions.some((e) => e.execution_id === requestedExecutionId) ? requestedExecutionId : executions[executions.length - 1]?.execution_id || '')

  useEffect(() => {
    if (!selectedChip) return
    const current = new URLSearchParams(location.search)
    const currentMode = current.get('mode') ?? 'team_project'
    const currentRun = current.get('run') ?? ''
    const currentExec = current.get('execution') ?? ''
    const desiredRun = runId || ''
    const desiredExec = executionId || ''
    const pathChip = bundleId ?? ''
    if (pathChip === selectedChip.chip_id && currentMode === mode && currentRun === desiredRun && currentExec === desiredExec) return
    const next = new URLSearchParams()
    next.set('mode', mode)
    if (desiredRun) next.set('run', desiredRun)
    if (desiredExec) next.set('execution', desiredExec)
    navigate(`/silicon-feedback/${encodeURIComponent(selectedChip.chip_id)}?${next.toString()}`, { replace: true })
  }, [bundleId, executionId, location.search, mode, navigate, runId, selectedChip])

  const selectedExecution = executions.find((e) => e.execution_id === executionId)
  const executionFiles = selectedExecution?.files
  const fileList = useMemo(() => executionFiles ?? [], [executionFiles])
  const v115Files = useMemo(
    () =>
      fileList
        .filter((f) => f.kind === 'file' && normalizeSequencePath(f.relative_path).startsWith('dashboard_objects/v115_'))
        .map((f) => ({ ...f, relative_path: normalizeSequencePath(f.relative_path).replace('dashboard_objects/', '') })),
    [fileList],
  )
  const tree = useMemo(() => buildTree(v115Files), [v115Files])
  const defaultSelected = useMemo(() => v115Files.find((f) => f.preview_text)?.relative_path ?? '', [v115Files])
  const [selectedFilePath, setSelectedFilePath] = useState('')
  const [expanded, setExpanded] = useState<Record<string, boolean>>({})
  const [copiedActionId, setCopiedActionId] = useState('')
  const effectiveSelected = selectedFilePath || defaultSelected
  const selectedFile = v115Files.find((f) => f.relative_path === effectiveSelected)

  const decisionInbox = parseArtifactJson(fileList, 'dashboard_objects/v115_silicon_feedback_decision_inbox.json')
  const actionHistory = useMemo(() => {
    const rows: Array<Record<string, string>> = []
    const actionFiles = fileList
      .filter((f) => f.kind === 'file' && normalizeSequencePath(f.relative_path).startsWith('dashboard_objects/v115_action_records/') && f.relative_path.endsWith('.json'))
      .sort((a, b) => b.relative_path.localeCompare(a.relative_path))
    for (const file of actionFiles) {
      if (!file.preview_text) continue
      try {
        const parsed = JSON.parse(file.preview_text) as Record<string, unknown>
        rows.push({ action_id: String(parsed.action_id ?? '-'), actor_role: String(parsed.actor_role ?? '-'), result: String(parsed.result ?? '-'), generated_at: String(parsed.generated_at ?? '-'), notes: String(parsed.notes ?? '-') })
      } catch {
        // ignore
      }
    }
    return rows
  }, [fileList])

  const copyCommand = async (actionId: string, cmd: string) => {
    try {
      await navigator.clipboard.writeText(cmd)
      setCopiedActionId(actionId)
      setTimeout(() => setCopiedActionId(''), 1500)
    } catch {
      setCopiedActionId('')
    }
  }

  const sample = parseArtifactJson(fileList, 'dashboard_objects/v115_silicon_sample_record.json')
  const powerOn = parseArtifactJson(fileList, 'dashboard_objects/v115_power_on_record.json')
  const mismatch = parseArtifactJson(fileList, 'dashboard_objects/v115_silicon_mismatch_record.json')
  const errata = parseArtifactJson(fileList, 'dashboard_objects/v115_silicon_errata_record.json')
  const auditBundle = parseArtifactJson(fileList, 'dashboard_objects/v115_post_tapeout_audit_bundle.json')
  const provenClaim = parseArtifactJson(fileList, 'dashboard_objects/v115_silicon_proven_claim_record.json')
  const ecoDecision = parseArtifactJson(fileList, 'dashboard_objects/v115_eco_decision_record.json')
  const validationResult = parseArtifactJson(fileList, 'dashboard_objects/v115_silicon_validation_result.json')

  const renderTree = (nodes: TreeNode[], depth = 0): ReactNode =>
    nodes.map((node) => {
      const isOpen = expanded[node.path] ?? false
      if (node.kind === 'dir') {
        return (
          <div key={node.path}>
            <button type="button" onClick={() => setExpanded((prev) => ({ ...prev, [node.path]: !isOpen }))} className="w-full flex items-center gap-2 py-1 px-2 text-left hover:bg-slate-800/70 rounded" style={{ paddingLeft: `${depth * 14 + 8}px` }}>
              {isOpen ? <ChevronDown size={14} className="text-slate-400" /> : <ChevronRight size={14} className="text-slate-400" />}
              <span className="text-slate-200 text-xs">{node.name}</span>
            </button>
            {isOpen && <div>{renderTree(node.children, depth + 1)}</div>}
          </div>
        )
      }
      return (
        <button key={node.path} type="button" onClick={() => setSelectedFilePath(node.path)} className={`w-full flex items-center gap-2 py-1 px-2 text-left rounded hover:bg-slate-800/70 ${effectiveSelected === node.path ? 'bg-slate-800/80' : ''}`} style={{ paddingLeft: `${depth * 14 + 8}px` }}>
          {iconForFile(node.name)}
          <span className="text-slate-200 text-xs">{node.name}</span>
        </button>
      )
    })

  if (loading) return <div className="rounded-xl border border-slate-800 bg-slate-900 p-6 text-sm text-slate-300">{t('common.loading')}</div>
  if (error) return <div className="rounded-xl border border-red-900/40 bg-red-950/30 p-6 text-sm text-red-200">{t('common.error')}: {error}</div>

  return (
    <div className="space-y-5">
      <section className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
        <h2 className="text-lg font-semibold text-slate-100">{t('silicon_feedback.title')}</h2>
        <p className="mt-1 text-xs text-slate-400">{t('silicon_feedback.subtitle')}</p>
        <div className="mt-4 grid gap-3 md:grid-cols-3">
          <select value={selectedChip?.source_dir ?? ''} onChange={(e) => { setChipSourceDirOverride(e.target.value); setRunOverride(''); setExecutionOverride('') }} className="rounded border border-slate-700 bg-slate-950 px-2 py-2 text-sm text-slate-200">{chips.map((chip) => <option key={chip.source_dir} value={chip.source_dir}>{chip.chip_id}</option>)}</select>
          <select value={runId} onChange={(e) => { setRunOverride(e.target.value); setExecutionOverride('') }} className="rounded border border-slate-700 bg-slate-950 px-2 py-2 text-sm text-slate-200">{runs.map((run) => <option key={run.run_id} value={run.run_id}>{run.run_id}</option>)}</select>
          <select value={executionId} onChange={(e) => setExecutionOverride(e.target.value)} className="rounded border border-slate-700 bg-slate-950 px-2 py-2 text-sm text-slate-200">{executions.map((exec) => <option key={exec.execution_id} value={exec.execution_id}>{exec.execution_id}</option>)}</select>
        </div>
      </section>

      {/* 雙層驗證與核准狀態邏輯計算 */}
      {(() => {
        // 1. Evidence / Claim Status
        const getEvidenceStatus = () => {
          if (provenClaim?.status) {
            return String(provenClaim.status).toUpperCase()
          }
          if (validationResult?.overall_verdict) {
            return validationResult.overall_verdict === 'PASS' ? 'VALIDATION_PASS' : 'VALIDATION_FAIL'
          }
          return 'NOT_AVAILABLE'
        }
        const evidenceStatus = getEvidenceStatus()

        // 2. Authority Approval Status (與 RC-1 判定對齊)
        const getApprovalStatus = () => {
          const isExploratory = !decisionInbox && !ecoDecision
          if (isExploratory) {
            return 'NOT_APPLICABLE'
          }
          if (!provenClaim && !ecoDecision && !validationResult) {
            return 'UNKNOWN_SOURCE_MISSING'
          }
          if (provenClaim?.status === 'SILICON_PROVEN_BOUNDED') {
            if (ecoDecision?.decision === 'APPROVED') {
              return 'APPROVED'
            }
            if (ecoDecision?.decision === 'HOLD' || ecoDecision?.decision === 'REJECTED') {
              return 'NOT_APPROVED'
            }
            return 'EVIDENCE_SUPPORTED_PENDING_APPROVAL'
          }
          if (provenClaim?.status === 'BLOCKED' || ecoDecision?.decision === 'REJECTED' || validationResult?.overall_verdict === 'FAIL') {
            return 'NOT_APPROVED'
          }
          return 'PENDING_REVIEW'
        }
        const approvalStatus = getApprovalStatus()

        const getEvidenceTone = (status: string) => {
          if (status === 'SILICON_PROVEN_BOUNDED' || status === 'VALIDATION_PASS') {
            return 'border-emerald-500/30 bg-emerald-500/10 text-emerald-400'
          }
          if (status === 'BLOCKED' || status === 'VALIDATION_FAIL') {
            return 'border-rose-500/30 bg-rose-500/10 text-rose-400'
          }
          return 'border-slate-700 bg-slate-800 text-slate-300'
        }

        const getApprovalTone = (status: string) => {
          if (status === 'APPROVED') {
            return 'border-emerald-500/30 bg-emerald-500/10 text-emerald-400'
          }
          if (status === 'EVIDENCE_SUPPORTED_PENDING_APPROVAL' || status === 'PENDING_REVIEW') {
            return 'border-amber-500/30 bg-amber-500/10 text-amber-400'
          }
          if (status === 'NOT_APPROVED') {
            return 'border-rose-500/30 bg-rose-500/10 text-rose-400'
          }
          if (status === 'NOT_APPLICABLE') {
            return 'border-slate-700 bg-slate-800 text-slate-400'
          }
          return 'border-rose-500/20 bg-rose-950/20 text-rose-300 animate-pulse'
        }

        return (
          <section className="rounded-xl border border-slate-800 bg-slate-900/70 p-5 space-y-4">
            <div>
              <h3 className="text-sm font-semibold uppercase tracking-[0.06em] text-slate-400">
                {t('silicon_feedback.panel_title')}
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                {t('silicon_feedback.panel_subtitle')}
              </p>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              {/* 第一層: Evidence / Claim Status */}
              <div className="rounded-lg border border-slate-800 bg-slate-950/40 p-4 flex items-center justify-between gap-4">
                <div className="space-y-1">
                  <span className="text-xs text-slate-500 uppercase tracking-wider block">
                    {t('silicon_feedback.evidence_status')}
                  </span>
                  <span className="text-xs font-mono text-slate-300">
                    Validation: {String(validationResult?.overall_verdict ?? 'N/A')} · ECO: {String(ecoDecision?.decision ?? 'N/A')}
                  </span>
                </div>
                <div>
                  <span className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-semibold ${getEvidenceTone(evidenceStatus)}`}>
                    {evidenceStatus}
                  </span>
                </div>
              </div>

              {/* 第二層: Authority Approval Status */}
              <div className="rounded-lg border border-slate-800 bg-slate-950/40 p-4 flex items-center justify-between gap-4">
                <div className="space-y-1">
                  <span className="text-xs text-slate-500 uppercase tracking-wider block">
                    {t('silicon_feedback.approval_status')}
                  </span>
                  <span className="text-xs font-mono text-slate-300">
                    Release Gate: {provenClaim?.status === 'SILICON_PROVEN_BOUNDED' ? 'BOUNDED' : 'UNFINISHED'}
                  </span>
                </div>
                <div>
                  <span className={`inline-flex items-center gap-1.5 rounded-full border px-3.5 py-1 text-xs font-semibold ${getApprovalTone(approvalStatus)}`}>
                    {approvalStatus}
                  </span>
                </div>
              </div>
            </div>

            {/* 阻斷原因與說明展示 (RC-5 select-text & trace-linked) */}
            {approvalStatus === 'NOT_APPROVED' && (
              <div className="rounded-lg border border-rose-500/20 bg-rose-950/20 p-4 text-xs text-rose-200 space-y-2 select-text">
                <div className="font-semibold flex items-center gap-1.5">
                  <span>{t('silicon_feedback.why_blocked')}:</span>
                </div>
                <ul className="list-disc list-inside pl-2 space-y-1.5 font-mono">
                  <li className="selection:bg-rose-500/40 selection:text-white">
                    <span className="text-slate-400">Proven Claim Boundary Status:</span> <span className="text-rose-300 font-semibold">{String(provenClaim?.status ?? 'NOT_AVAILABLE')}</span>
                    {!!provenClaim?.notes && <span className="text-slate-300 ml-1">— {String(provenClaim.notes)}</span>}
                  </li>
                  <li className="selection:bg-rose-500/40 selection:text-white">
                    <span className="text-slate-400">ECO Authority Decision:</span> <span className="text-amber-300 font-semibold">{String(ecoDecision?.decision ?? 'NOT_EVALUATED')}</span>
                    {!!ecoDecision?.notes && <span className="text-slate-300 ml-1">— {String(ecoDecision.notes)}</span>}
                  </li>
                  <li className="selection:bg-rose-500/40 selection:text-white">
                    <span className="text-slate-400">Silicon Validation Verdict:</span> <span className="text-rose-300 font-semibold">{String(validationResult?.overall_verdict ?? 'NOT_AVAILABLE')}</span>
                    {!!validationResult?.notes && <span className="text-slate-300 ml-1">— {String(validationResult.notes)}</span>}
                  </li>
                </ul>
                <div className="pt-1">
                  <button
                    type="button"
                    onClick={() => navigate(`/run/${encodeURIComponent(selectedChip?.chip_id ?? '')}?run=${encodeURIComponent(runId)}&execution=${encodeURIComponent(executionId)}&mode=${mode}`)}
                    className="inline-flex rounded border border-rose-500/30 bg-rose-500/10 px-2.5 py-1 text-[11px] font-medium text-rose-300 hover:bg-rose-500/20 transition-colors"
                  >
                    Trace-Link to Execution Run Detail
                  </button>
                </div>
              </div>
            )}

            {/* ================================================================
                Actionable Remediation Panel (AC1-AC6)
                當 NOT_APPROVED 時顯示完整阻斷鏈與補救指引
                ================================================================ */}
            {approvalStatus === 'NOT_APPROVED' && (() => {
              // 計算 Blocker Chain（由根本原因到下游影響排序）
              type BlockerItem = {
                seq: number
                level: string
                blocker_id: string
                source_file: string
                current_value: string
                blocker_meaning: string
                required_next_action: string
                resolution_tier: string
              }
              const ecoCandidate = parseArtifactJson(fileList, 'dashboard_objects/v115_eco_candidate_record.json')
              const blockerReasons = (provenClaim?.blocking_reasons as string[] | undefined) ?? []
              const ecoDecisionVal = String(ecoDecision?.decision ?? 'SOURCE_FILE_UNRESOLVED')
              const ecoSourceMode = String(ecoDecision?.source_mode ?? '')
              const ecoCandidateReason = String(ecoCandidate?.reason ?? '')

              const blockerChain: BlockerItem[] = []

              // Blocker 1: ECO Authority Gap (根本原因)
              if (!ecoDecision) {
                blockerChain.push({
                  seq: 1,
                  level: t('silicon_feedback.level_eco_gap'),
                  blocker_id: 'ECO_SOURCE_MISSING',
                  source_file: 'v115_eco_decision_record.json',
                  current_value: t('silicon_feedback.source_file_unresolved'),
                  blocker_meaning: 'ECO decision record is missing entirely — treated as data-pipeline defect. Cannot determine if ECO was evaluated.',
                  required_next_action: 'Verify that v115_eco_decision_record.json was generated for this execution. Re-run the post-tapeout pipeline if missing.',
                  resolution_tier: t('silicon_feedback.tier_eco_authority'),
                })
              } else if (ecoDecisionVal === 'NOT_EVALUATED') {
                blockerChain.push({
                  seq: 1,
                  level: t('silicon_feedback.level_eco_gap'),
                  blocker_id: 'ECO_NOT_EVALUATED',
                  source_file: 'v115_eco_decision_record.json',
                  current_value: `decision: ${ecoDecisionVal}${ecoSourceMode ? ` · source_mode: ${ecoSourceMode}` : ''}${ecoCandidateReason ? ` · candidate_reason: "${ecoCandidateReason}"` : ''}`,
                  blocker_meaning: 'ECO authority decision has not been evaluated. Silicon validation already passed but ECO closure is incomplete. The authority has not determined whether the ECO is accepted, rejected, or on hold.',
                  required_next_action: 'Perform ECO authority review. An ECO_AUTHORITY must evaluate the ECO candidate and record a formal decision (APPROVED / REJECTED / HOLD) in v115_eco_decision_record.json. Do NOT leave as NOT_EVALUATED or assume it auto-passes.',
                  resolution_tier: t('silicon_feedback.tier_eco_authority'),
                })
              } else if (ecoDecisionVal === 'REJECTED' || ecoDecisionVal === 'HOLD') {
                blockerChain.push({
                  seq: 1,
                  level: t('silicon_feedback.level_eco_gap'),
                  blocker_id: `ECO_${ecoDecisionVal}`,
                  source_file: 'v115_eco_decision_record.json',
                  current_value: `decision: ${ecoDecisionVal}`,
                  blocker_meaning: `ECO authority decision is ${ecoDecisionVal}. The proven claim boundary cannot be unblocked until ECO is resolved.`,
                  required_next_action: ecoDecisionVal === 'REJECTED' ? 'Address the ECO rejection reason, update the design, and re-submit for ECO authority review.' : 'ECO is on hold. Resolve the hold condition and obtain a final ECO decision before proceeding.',
                  resolution_tier: t('silicon_feedback.tier_eco_authority'),
                })
              }

              // Blocker 2: Proven Claim Boundary Blocked (中層)
              if (provenClaim?.status === 'BLOCKED') {
                blockerChain.push({
                  seq: blockerChain.length + 1,
                  level: t('silicon_feedback.level_claim_blocked'),
                  blocker_id: 'PROVEN_CLAIM_BLOCKED',
                  source_file: 'v115_silicon_proven_claim_record.json',
                  current_value: `status: BLOCKED · blocking_reasons: [${blockerReasons.join(', ')}]${provenClaim?.authoritative === false ? ' · authoritative: false' : ''}`,
                  blocker_meaning: 'The proven claim boundary is blocked because one or more prerequisite conditions are not met: ECO decision is incomplete and/or final authority review is pending. The claim class "SILICON_PROVEN_BOUNDED" cannot be finalized.',
                  required_next_action: 'Do NOT manually unblock this record. Unblock only after: (1) ECO authority closure is confirmed, (2) final authority review is completed. Then re-run the v1.15 post-tapeout pipeline to regenerate this record.',
                  resolution_tier: t('silicon_feedback.tier_evidence'),
                })
              } else if (!provenClaim) {
                blockerChain.push({
                  seq: blockerChain.length + 1,
                  level: t('silicon_feedback.level_claim_blocked'),
                  blocker_id: 'PROVEN_CLAIM_MISSING',
                  source_file: 'v115_silicon_proven_claim_record.json',
                  current_value: t('silicon_feedback.source_file_unresolved'),
                  blocker_meaning: 'Proven claim record is missing entirely — treated as data-pipeline defect.',
                  required_next_action: 'Verify that v115_silicon_proven_claim_record.json was generated for this execution.',
                  resolution_tier: t('silicon_feedback.tier_evidence'),
                })
              }

              // Blocker 3: Release Gate Unfinished (下游影響)
              blockerChain.push({
                seq: blockerChain.length + 1,
                level: t('silicon_feedback.level_release_unfinished'),
                blocker_id: 'RELEASE_GATE_UNFINISHED',
                source_file: 'authority/decision/audit record (if present)',
                current_value: 'Release Gate: UNFINISHED',
                blocker_meaning: 'No formal authority closure exists for this run. The authority approval gate cannot be completed until all upstream blockers (ECO + claim boundary) are resolved.',
                required_next_action: 'Human authority (RELEASE_AUTHORITY role) must formally approve, hold, request more evidence, or reject. This action cannot be automated and requires explicit authority closure.',
                resolution_tier: t('silicon_feedback.tier_authority'),
              })

              // Supporting Evidence: Validation PASS (AC3 — 不得被隱藏)
              type SupportItem = { source_file: string; current_value: string; meaning: string }
              const supportingEvidence: SupportItem[] = []
              const validationVerdict = String(validationResult?.overall_verdict ?? 'SOURCE_FILE_UNRESOLVED')
              if (validationVerdict === 'PASS') {
                supportingEvidence.push({
                  source_file: 'v115_silicon_validation_result.json',
                  current_value: `overall_verdict: PASS`,
                  meaning: 'Silicon validation has already passed. This is NOT the blocker. Use as supporting evidence for claim and authority closure. No validation fix is needed.',
                })
              }
              if ((ecoDecisionVal === 'NOT_EVALUATED' || !ecoDecision) && provenClaim?.claim_class) {
                supportingEvidence.push({
                  source_file: 'v115_silicon_proven_claim_record.json',
                  current_value: `claim_class: ${String(provenClaim.claim_class)}`,
                  meaning: 'The intended claim class is SILICON_PROVEN_BOUNDED. This can be finalized once ECO and authority closure are complete.',
                })
              }

              const tierColor: Record<string, string> = {
                [t('silicon_feedback.tier_eco_authority')]: 'border-amber-500/30 bg-amber-950/20 text-amber-200',
                [t('silicon_feedback.tier_evidence')]: 'border-rose-500/25 bg-rose-950/15 text-rose-200',
                [t('silicon_feedback.tier_authority')]: 'border-purple-500/25 bg-purple-950/15 text-purple-200',
              }
              const tierBadge: Record<string, string> = {
                [t('silicon_feedback.tier_eco_authority')]: 'bg-amber-500/20 text-amber-300 border-amber-500/30',
                [t('silicon_feedback.tier_evidence')]: 'bg-rose-500/20 text-rose-300 border-rose-500/30',
                [t('silicon_feedback.tier_authority')]: 'bg-purple-500/20 text-purple-300 border-purple-500/30',
              }

              return (
                <div className="rounded-lg border border-slate-700/60 bg-slate-900/60 p-5 space-y-5">
                  {/* Panel 標題 */}
                  <div className="border-b border-slate-700/40 pb-3">
                    <div className="flex items-start gap-2">
                      <span className="text-[11px] font-bold uppercase tracking-[0.1em] text-rose-400 bg-rose-500/10 border border-rose-500/20 rounded px-2 py-0.5">ROOT CAUSE</span>
                      <div>
                        <h4 className="text-sm font-semibold text-slate-100">{t('silicon_feedback.remediation_title')}</h4>
                        <p className="text-[11px] text-slate-400 mt-0.5">{t('silicon_feedback.remediation_subtitle')}</p>
                      </div>
                    </div>
                  </div>

                  {/* Blocker Chain */}
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-semibold uppercase tracking-wider text-slate-300">{t('silicon_feedback.blocker_chain_title')}</span>
                      <span className="text-[10px] text-slate-500 italic">{t('silicon_feedback.blocker_chain_note')}</span>
                    </div>
                    {blockerChain.map((item) => (
                      <div key={item.blocker_id} className={`rounded-lg border p-3.5 space-y-2.5 select-text ${tierColor[item.resolution_tier] ?? 'border-slate-700 bg-slate-800 text-slate-200'}`}>
                        {/* 標頭行 */}
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-slate-700/70 text-slate-200 text-[10px] font-bold shrink-0">{item.seq}</span>
                          <span className="text-[11px] font-bold uppercase tracking-wide text-current">{item.level}</span>
                          <span className={`inline-flex items-center rounded border px-1.5 py-0.5 text-[9px] font-mono font-semibold ${tierBadge[item.resolution_tier] ?? 'bg-slate-700 text-slate-300 border-slate-600'}`}>{item.resolution_tier}</span>
                          <span className="text-[10px] font-mono text-current/70 ml-auto">{item.blocker_id}</span>
                        </div>
                        {/* 詳情 Grid */}
                        <div className="grid gap-1.5 text-[11px]">
                          <div className="flex gap-2">
                            <span className="text-current/50 w-28 shrink-0 font-medium">{t('silicon_feedback.col_source_file')}</span>
                            <span className="font-mono text-current break-all">{item.source_file}</span>
                          </div>
                          <div className="flex gap-2">
                            <span className="text-current/50 w-28 shrink-0 font-medium">{t('silicon_feedback.col_current_value')}</span>
                            <span className="font-mono text-current/90 break-all">{item.current_value}</span>
                          </div>
                          <div className="flex gap-2">
                            <span className="text-current/50 w-28 shrink-0 font-medium">{t('silicon_feedback.col_meaning')}</span>
                            <span className="text-current/80 leading-relaxed">{item.blocker_meaning}</span>
                          </div>
                          <div className="flex gap-2 pt-0.5 border-t border-current/10">
                            <span className="text-current/50 w-28 shrink-0 font-semibold">{t('silicon_feedback.col_next_action')}</span>
                            <span className="text-current font-medium leading-relaxed">{item.required_next_action}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Supporting Evidence (AC3 — PASS validation 不得被隱藏) */}
                  {supportingEvidence.length > 0 && (
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-semibold uppercase tracking-wider text-emerald-400">{t('silicon_feedback.supporting_evidence_title')}</span>
                        <span className="text-[10px] text-slate-500 italic">{t('silicon_feedback.supporting_evidence_note')}</span>
                      </div>
                      {supportingEvidence.map((item, idx) => (
                        <div key={idx} className="rounded-lg border border-emerald-500/20 bg-emerald-950/10 p-3 space-y-1.5 text-[11px] select-text">
                          <div className="flex items-center gap-2">
                            <span className="inline-flex items-center gap-1 rounded border border-emerald-500/30 bg-emerald-500/15 px-1.5 py-0.5 text-[9px] font-semibold text-emerald-300">✓ PASS</span>
                            <span className="font-mono text-emerald-300">{item.source_file}</span>
                          </div>
                          <div className="flex gap-2">
                            <span className="text-emerald-400/60 w-28 shrink-0">{t('silicon_feedback.col_current_value')}</span>
                            <span className="font-mono text-emerald-300/80">{item.current_value}</span>
                          </div>
                          <div className="flex gap-2">
                            <span className="text-emerald-400/60 w-28 shrink-0">{t('silicon_feedback.col_meaning')}</span>
                            <span className="text-emerald-200/80 leading-relaxed">{item.meaning}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Next Suggested Action 總結 */}
                  <div className="rounded-lg border border-amber-500/20 bg-amber-950/10 p-3.5 space-y-1.5">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-amber-400">{t('silicon_feedback.suggested_action_title')}</span>
                    <p className="text-[11px] text-amber-200/80 leading-relaxed">
                      Open ECO authority decision review → complete ECO evaluation → confirm authority closure → then re-run / refresh v1.15 post-tapeout feedback status.
                      Validation is already PASS and does not need to be re-run.
                    </p>
                    <div className="flex gap-2 pt-1 flex-wrap">
                      <button
                        type="button"
                        onClick={() => navigate(`/run/${encodeURIComponent(selectedChip?.chip_id ?? '')}?run=${encodeURIComponent(runId)}&execution=${encodeURIComponent(executionId)}&mode=${mode}`)}
                        className="inline-flex rounded border border-amber-500/30 bg-amber-500/10 px-2.5 py-1 text-[11px] font-medium text-amber-300 hover:bg-amber-500/20 transition-colors"
                      >
                        Trace-Link to Execution Run Detail
                      </button>
                      <button
                        type="button"
                        onClick={() => navigate(`/artifacts?chip=${encodeURIComponent(selectedChip?.chip_id ?? '')}&run=${encodeURIComponent(runId)}&execution=${encodeURIComponent(executionId)}&mode=${mode}`)}
                        className="inline-flex rounded border border-slate-600 bg-slate-800/50 px-2.5 py-1 text-[11px] font-medium text-slate-300 hover:bg-slate-700/50 transition-colors"
                      >
                        {t('silicon_feedback.trace_evidence_vault')}
                      </button>
                    </div>
                  </div>
                </div>
              )
            })()}

            {/* 缺審查對象 / UNKNOWN_SOURCE_MISSING */}
            {approvalStatus === 'UNKNOWN_SOURCE_MISSING' && (
              <div className="rounded-lg border border-rose-500/20 bg-rose-950/25 p-4 text-xs text-rose-300 space-y-2 select-text">
                <div className="font-semibold text-rose-400">UNKNOWN_SOURCE_MISSING</div>
                <p className="text-slate-400">This run is designated for silicon feedback audit but is missing required v1.15 authority approval / proven claim objects.</p>
              </div>
            )}

            {/* Approved 狀態展示 */}
            {approvalStatus === 'APPROVED' && (
              <div className="rounded-lg border border-emerald-500/20 bg-emerald-950/10 p-4 text-xs text-emerald-200 space-y-1.5 select-text">
                <div className="font-semibold text-emerald-300">{t('silicon_feedback.approved_note')}: Approved for Production Release</div>
                <p className="text-slate-400">{t('silicon_feedback.approved_desc')}</p>
                {!!provenClaim?.notes && <p className="font-mono text-emerald-400 mt-1">— Note: {String(provenClaim.notes)}</p>}
              </div>
            )}
          </section>
        )
      })()}

      <section className="rounded-xl border border-slate-800 bg-slate-900/70">
        <div className="border-b border-slate-800 p-4 text-sm text-slate-300">Left: v1.15 object tree · Right: file preview (.md/.json/.log)</div>
        <div className="grid grid-cols-1 lg:grid-cols-2 min-h-[44vh]">
          <div className="border-r border-slate-800 p-3 overflow-auto">{tree.length ? renderTree(tree) : <div className="text-xs text-slate-400">NOT_AVAILABLE</div>}</div>
          <div className="p-3 overflow-auto">
            {selectedFile?.preview_text ? <pre className="text-xs text-slate-200 whitespace-pre-wrap break-words">{selectedFile.preview_text}</pre> : <div className="text-xs text-slate-400">NOT_AVAILABLE</div>}
          </div>
        </div>
      </section>

      <section className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
        <h3 className="text-sm font-semibold text-slate-100">{t('silicon_feedback.summary')}</h3>
        <div className="mt-3 grid gap-3 md:grid-cols-4">
          <div className="rounded border border-slate-800 bg-slate-950/50 p-3 text-xs text-slate-300">{t('silicon_feedback.sample_id')}: <span className="font-mono text-slate-100">{String(sample?.sample_id ?? 'NOT_AVAILABLE')}</span></div>
          <div className="rounded border border-slate-800 bg-slate-950/50 p-3 text-xs text-slate-300">{t('silicon_feedback.power_on')}: <span className="font-mono text-slate-100">{String(powerOn?.result ?? 'NOT_AVAILABLE')}</span></div>
          <div className="rounded border border-slate-800 bg-slate-950/50 p-3 text-xs text-slate-300">mismatch: <span className="font-mono text-slate-100">{String(mismatch?.status ?? 'NOT_AVAILABLE')}</span></div>
          <div className="rounded border border-slate-800 bg-slate-950/50 p-3 text-xs text-slate-300">{t('silicon_feedback.audit_status')}: <span className="font-mono text-slate-100">{String(auditBundle?.reconstruction_status ?? 'NOT_AVAILABLE')}</span></div>
        </div>
        <div className="mt-2 text-xs text-slate-300">{t('silicon_feedback.governance')}: <span className="font-mono text-slate-100">{String(errata?.status ?? 'NOT_AVAILABLE')}</span></div>
      </section>

      <section className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
        <h3 className="text-sm font-semibold text-slate-100">Silicon Feedback Decision Inbox</h3>
        <div className="mt-3 overflow-x-auto">
          <table className="min-w-full text-left text-xs">
            <thead className="bg-slate-900 text-slate-300"><tr><th className="px-2 py-2">{t('signoff.decision_action')}</th><th className="px-2 py-2">{t('signoff.decision_role')}</th><th className="px-2 py-2">{t('signoff.decision_reason')}</th><th className="px-2 py-2">{t('signoff.decision_command')}</th><th className="px-2 py-2">{t('silicon_feedback.action_button')}</th></tr></thead>
            <tbody>
              {((decisionInbox?.items as Array<Record<string, unknown>> | undefined) ?? []).map((item, idx) => {
                const actionId = String(item.action_id ?? '-')
                const role = String(item.required_role ?? '-')
                const reason = String(item.reason ?? '-')
                const fallbackRunDir = `artifacts/production-runs/${selectedChip?.source_dir}/${runId}/${executionId}`
                const actionCtx = resolveActionCommandContext(selectedExecution?.resolved_root ?? fallbackRunDir, fallbackRunDir)
                const cmd = `python3 ${actionCtx.scriptPath} --run-dir ${actionCtx.runDirArg} --action-id ${actionId} --actor-role ${role}`
                return <tr key={`${actionId}-${idx}`} className="border-t border-slate-800"><td className="px-2 py-2 text-slate-200 font-mono">{actionId}</td><td className="px-2 py-2 text-slate-300">{role}</td><td className="px-2 py-2 text-slate-300">{reason}</td><td className="px-2 py-2 text-cyan-300 font-mono break-all">{cmd}</td><td className="px-2 py-2"><button type="button" onClick={() => void copyCommand(actionId, cmd)} className="rounded border border-cyan-700/60 bg-cyan-900/20 px-2 py-1 text-[11px] text-cyan-200 hover:bg-cyan-900/40">{copiedActionId === actionId ? t('silicon_feedback.copied') : t('silicon_feedback.copy_cmd')}</button></td></tr>
              })}
              {(((decisionInbox?.items as Array<Record<string, unknown>> | undefined) ?? []).length === 0) && <tr><td className="px-2 py-3 text-slate-400" colSpan={5}>NO_PENDING_ACTIONS</td></tr>}
            </tbody>
          </table>
        </div>
        <h4 className="mt-4 text-xs font-semibold uppercase tracking-wide text-slate-300">{t('signoff.action_history_title')}</h4>
        <div className="mt-2 overflow-x-auto">
          <table className="min-w-full text-left text-xs">
            <thead className="bg-slate-900 text-slate-300"><tr><th className="px-2 py-2">{t('signoff.decision_action')}</th><th className="px-2 py-2">{t('signoff.decision_role')}</th><th className="px-2 py-2">{t('signoff.history_result')}</th><th className="px-2 py-2">{t('signoff.history_time')}</th><th className="px-2 py-2">{t('signoff.history_notes')}</th></tr></thead>
            <tbody>
              {actionHistory.map((row, idx) => <tr key={`${row.action_id}-${idx}`} className="border-t border-slate-800"><td className="px-2 py-2 text-slate-200 font-mono">{row.action_id}</td><td className="px-2 py-2 text-slate-300">{row.actor_role}</td><td className="px-2 py-2 text-slate-300">{row.result}</td><td className="px-2 py-2 text-slate-400 font-mono">{row.generated_at}</td><td className="px-2 py-2 text-slate-300">{row.notes}</td></tr>)}
              {actionHistory.length === 0 && <tr><td colSpan={5} className="px-2 py-3 text-slate-400">NO_ACTION_HISTORY</td></tr>}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  )
}
