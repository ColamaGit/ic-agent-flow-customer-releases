import { Link, Outlet, NavLink, useLocation, useParams, useNavigate } from 'react-router-dom'
import { Building2, Gauge, Languages, UserRound, UsersRound } from 'lucide-react'
import { useTranslation } from '../contexts/i18n'
import { useEffect, useMemo, useState } from 'react'
import HeaderIcon, { type HeaderIconKey } from '../components/HeaderIcon'
import { useProductionRunsInventory } from '../hooks/useProductionRunsInventory'

const navIconClass =
  'icon-hint group relative inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-lg border text-slate-400 transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cyan-300'

const hintClass =
  'header-hint pointer-events-none absolute left-1/2 top-[calc(100%+8px)] z-40 -translate-x-1/2 whitespace-nowrap rounded-md border border-slate-700 bg-slate-900 px-2.5 py-1 text-[13px] font-medium tracking-[0.02em] text-slate-100 shadow-lg'

const activeToneClass = {
  cyan: 'border-cyan-400/40 bg-cyan-500/10 text-cyan-300',
  blue: 'border-blue-400/40 bg-blue-500/10 text-blue-300',
  indigo: 'border-indigo-400/40 bg-indigo-500/10 text-indigo-300',
  orange: 'border-orange-400/40 bg-orange-500/10 text-orange-300',
  violet: 'border-violet-400/40 bg-violet-500/10 text-violet-300',
  emerald: 'border-emerald-400/40 bg-emerald-500/10 text-emerald-300',
} as const

type NavItem = {
  to: string
  label: string
  iconKey: HeaderIconKey
  tone: keyof typeof activeToneClass
}

type NavGroup = {
  labelKey: string
  items: NavItem[]
}

type CanonicalRouteMeta = {
  groupKey: string
  pageKey: string
  activeChip: string
  activeRun: string
}

type OperatingMode = 'solo_eval' | 'team_project' | 'enterprise_site'

function parseMode(search: string): OperatingMode {
  const params = new URLSearchParams(search)
  const candidate = params.get('mode')
  if (candidate === 'solo_eval' || candidate === 'enterprise_site') return candidate
  return 'team_project'
}

function canonicalMeta(pathname: string, bundleId?: string): CanonicalRouteMeta {
  if (pathname.startsWith('/console')) {
    return { groupKey: 'group.console_home', pageKey: 'page.console_home', activeChip: 'SN2025', activeRun: 'RUN-20260430-001' }
  }
  if (pathname.startsWith('/intake')) {
    return { groupKey: 'group.activation_intake', pageKey: 'page.intake', activeChip: 'SN2025', activeRun: 'N/A' }
  }
  if (pathname.startsWith('/requirement-adjudication')) {
    return { groupKey: 'group.activation_intake', pageKey: 'page.requirement_adjudication', activeChip: 'SN2025', activeRun: 'N/A' }
  }
  if (pathname.startsWith('/upstream-flow')) {
    return { groupKey: 'group.activation_intake', pageKey: 'page.upstream_flow', activeChip: 'SN2025', activeRun: 'N/A' }
  }
  if (pathname.startsWith('/package-readiness')) {
    return { groupKey: 'group.decision_authority', pageKey: 'page.package_readiness', activeChip: 'SN2025', activeRun: 'RUN-20260430-001' }
  }
  if (pathname.startsWith('/package-builds')) {
    return { groupKey: 'group.decision_authority', pageKey: 'page.package_builds', activeChip: 'SN2025', activeRun: 'N/A' }
  }
  if (pathname.startsWith('/authority-plane') || pathname.startsWith('/authority')) {
    return { groupKey: 'group.decision_authority', pageKey: 'page.authority_plane', activeChip: 'SN2025', activeRun: 'RUN-20260430-001' }
  }
  if (pathname.startsWith('/signoff')) {
    return { groupKey: 'group.decision_authority', pageKey: 'page.signoff', activeChip: 'SN2025', activeRun: 'RUN-20260430-001' }
  }
  if (pathname.startsWith('/tapeout-package')) {
    return { groupKey: 'group.decision_authority', pageKey: 'page.tapeout_package', activeChip: 'SN2025', activeRun: 'RUN-20260430-001' }
  }
  if (pathname.startsWith('/silicon-feedback')) {
    return { groupKey: 'group.decision_authority', pageKey: 'page.silicon_feedback', activeChip: 'SN2025', activeRun: 'RUN-20260430-001' }
  }
  if (pathname.startsWith('/flow-map') || pathname.startsWith('/verdicts/')) {
    return { groupKey: 'group.flow_run', pageKey: 'page.flow_map', activeChip: 'SN2025', activeRun: bundleId ?? 'RUN-20260430-001' }
  }
  if (pathname.startsWith('/run-detail') || pathname.startsWith('/run/')) {
    return { groupKey: 'group.flow_run', pageKey: 'page.run_detail', activeChip: 'SN2025', activeRun: bundleId ?? 'RUN-20260430-001' }
  }
  if (pathname.startsWith('/node-io') || pathname.startsWith('/checkpoint/')) {
    return { groupKey: 'group.flow_run', pageKey: 'page.node_io', activeChip: 'SN2025', activeRun: bundleId ?? 'RUN-20260430-001' }
  }
  if (pathname.startsWith('/decision-inbox')) {
    return { groupKey: 'group.decision_authority', pageKey: 'page.decision_inbox', activeChip: 'SN2025', activeRun: 'RUN-20260430-001' }
  }
  if (pathname.startsWith('/qa-trust')) {
    return { groupKey: 'group.qa_trust', pageKey: 'page.qa_trust', activeChip: 'SN2025', activeRun: 'RUN-20260430-001' }
  }
  if (pathname.startsWith('/qa-strategy') || pathname.startsWith('/qa')) {
    return { groupKey: 'group.qa_trust', pageKey: 'page.qa_strategy', activeChip: 'SN2025', activeRun: 'RUN-20260430-001' }
  }
  if (pathname.startsWith('/downstream-decisions')) {
    return { groupKey: 'group.decision_authority', pageKey: 'page.downstream_decisions', activeChip: 'SN2025', activeRun: 'RUN-20260430-001' }
  }
  if (pathname.startsWith('/artifacts') || pathname.startsWith('/qa')) {
    return { groupKey: 'group.evidence_artifacts', pageKey: 'page.artifacts', activeChip: 'SN2025', activeRun: 'RUN-20260430-001' }
  }
  if (pathname.startsWith('/knowledge-assets')) {
    return { groupKey: 'group.knowledge_assets', pageKey: 'page.knowledge_assets', activeChip: 'SN2025', activeRun: 'RUN-20260430-001' }
  }
  if (pathname.startsWith('/audit-replay')) {
    return { groupKey: 'group.audit_replay', pageKey: 'page.audit_replay', activeChip: 'SN2025', activeRun: 'RUN-20260430-001' }
  }
  if (pathname.startsWith('/style-guide')) {
    return { groupKey: 'group.audit_replay', pageKey: 'page.style_guide', activeChip: 'SN2025', activeRun: 'RUN-20260430-001' }
  }
  return { groupKey: 'group.console_home', pageKey: 'page.console_home', activeChip: 'SN2025', activeRun: 'RUN-20260430-001' }
}

export default function MainLayout() {
  const { bundleId } = useParams()
  const location = useLocation()
  const navigate = useNavigate()
  const [isCustomerPackage, setIsCustomerPackage] = useState(false)
  const [activeHintKey, setActiveHintKey] = useState<string | null>(null)
  const { lang, setLang, t } = useTranslation()
  const isIntakeRoute = location.pathname.startsWith('/intake')
  const isDevRuntime = import.meta.env.DEV
  const releaseProfile = import.meta.env.VITE_RELEASE_PROFILE as OperatingMode | undefined
  const queryMode = useMemo(() => parseMode(location.search), [location.search])
  const effectiveMode: OperatingMode = !isDevRuntime && releaseProfile ? releaseProfile : queryMode

  useEffect(() => {
    fetch('/api/intake/options')
      .then((res) => {
        if (!res.ok) throw new Error()
        return res.json()
      })
      .then((data) => {
        if (data?.is_customer_package) {
          setIsCustomerPackage(true)
        }
        const params = new URLSearchParams(location.search)
        if (!params.has('mode')) {
          const backendMode = data?.package_mode
          if (backendMode === 'solo_eval' || backendMode === 'enterprise_site' || backendMode === 'team_project') {
            params.set('mode', backendMode)
            navigate({ pathname: location.pathname, search: params.toString() }, { replace: true })
          }
        }
      })
      .catch(() => {
        // Fallback if API is offline
      })
  }, [location.pathname, location.search, navigate])
  // RC-H1/H3/H4/H5 Fix: load live inventory to drive header status lights and context fields
  const { data: inventory } = useProductionRunsInventory({ layeredSummaryOnly: true })
  const firstChip = inventory?.chips?.[0]
  const activeId = bundleId || firstChip?.runs?.[0]?.run_id || 'latest'
  const execTotals = useMemo(
    () =>
      (inventory?.chips ?? []).reduce(
        (acc, chip) => ({
          pass: acc.pass + Number(chip.verdict_summary?.pass ?? 0),
          warn: acc.warn + Number(chip.verdict_summary?.warn ?? 0),
          blocked: acc.blocked + Number(chip.verdict_summary?.blocked ?? 0),
          unknown: acc.unknown + Number(chip.verdict_summary?.unknown ?? 0),
        }),
        { pass: 0, warn: 0, blocked: 0, unknown: 0 }
      ),
    [inventory]
  )

  const navGroups: NavGroup[] = [
    {
      labelKey: 'group.console_home',
      items: [
        { to: '/console', label: t('nav.console_home'), iconKey: 'dashboard', tone: 'cyan' },
      ],
    },
    {
      labelKey: 'group.activation_intake',
      items: [
        { to: '/intake', label: t('nav.intake'), iconKey: 'policy', tone: 'cyan' },
        { to: '/requirement-adjudication', label: t('nav.requirement_adjudication'), iconKey: 'decision', tone: 'emerald' },
        { to: '/upstream-flow', label: t('nav.upstream_flow'), iconKey: 'upstream', tone: 'cyan' },
      ],
    },
    {
      labelKey: 'group.flow_run',
      items: [
        { to: '/flow-map', label: t('nav.flow_map'), iconKey: 'flow', tone: 'cyan' },
        { to: '/run-detail', label: t('nav.run_detail'), iconKey: 'report', tone: 'orange' },
        { to: '/node-io', label: t('nav.node_io'), iconKey: 'evidence', tone: 'blue' },
      ],
    },
    {
      labelKey: 'group.evidence_artifacts',
      items: [{ to: '/artifacts', label: t('nav.artifacts'), iconKey: 'evidence', tone: 'indigo' }],
    },
    {
      labelKey: 'group.qa_trust',
      items: [
        { to: '/qa-trust', label: t('nav.qa_trust'), iconKey: 'qa', tone: 'blue' },
        { to: '/qa-strategy', label: t('nav.qa_strategy'), iconKey: 'trust', tone: 'blue' },
      ],
    },
    {
      labelKey: 'group.decision_authority',
      items: [
        { to: '/downstream-decisions', label: t('nav.downstream_decisions'), iconKey: 'gate', tone: 'emerald' },
        { to: '/decision-inbox', label: t('nav.decision_inbox'), iconKey: 'decision', tone: 'emerald' },
        { to: '/signoff', label: t('nav.signoff'), iconKey: 'trust', tone: 'orange' },
        { to: '/tapeout-package', label: t('nav.tapeout_package'), iconKey: 'package', tone: 'orange' },
        { to: '/silicon-feedback', label: t('nav.silicon_feedback'), iconKey: 'report', tone: 'orange' },
        { to: '/package-readiness', label: t('nav.package_readiness'), iconKey: 'package', tone: 'violet' },
        { to: '/authority-plane', label: t('nav.authority_plane'), iconKey: 'lock', tone: 'violet' },
      ],
    },
    {
      labelKey: 'group.audit_replay',
      items: [
        { to: '/audit-replay', label: t('nav.audit_replay'), iconKey: 'audit', tone: 'blue' },
        // NOTE: The "Package Builds" registry is strictly a development-repo operator visibility tool.
        // It must never be shown or accessible in any production/customer deployment package.
        ...(isDevRuntime && !isCustomerPackage ? [{ to: '/package-builds', label: t('nav.package_builds'), iconKey: 'package' as HeaderIconKey, tone: 'violet' as const }] : []),
        { to: '/style-guide', label: t('nav.style_guide'), iconKey: 'settings', tone: 'blue' },
      ],
    },
    {
      labelKey: 'group.knowledge_assets',
      items: [{ to: '/knowledge-assets', label: t('nav.knowledge_assets'), iconKey: 'knowledge', tone: 'cyan' }],
    },
  ]
  const routeMeta = canonicalMeta(location.pathname, bundleId)
  const scopeParams = useMemo(() => new URLSearchParams(location.search), [location.search])
  const scopedChip = scopeParams.get('chip') || firstChip?.chip_id || routeMeta.activeChip
  const scopedRun = scopeParams.get('run') || firstChip?.runs?.[0]?.run_id || routeMeta.activeRun

  // RC-H1 Fix: statusItems now derived from live inventory verdict_summary
  const statusItems = [
    {
      label: t('qa.evidence'),
      value: execTotals.blocked > 0 ? t('status.limited') : t('status.healthy'),
      tone: execTotals.blocked > 0 ? 'warn' : 'pass',
      href: '',
    },
    {
      label: t('qa.scenario'),
      value: execTotals.blocked > 0 || execTotals.unknown > 0 ? t('status.limited') : t('status.healthy'),
      tone: execTotals.blocked > 0 || execTotals.unknown > 0 ? 'warn' : 'pass',
      href: '/qa-trust',
    },
    {
      label: t('qa.claim'),
      value: execTotals.blocked > 0 ? t('status.limited') : t('status.healthy'),
      tone: execTotals.blocked > 0 ? 'warn' : 'pass',
      href: '',
    },
    {
      label: t('qa.reval'),
      value: execTotals.blocked > 0 ? t('status.active') : t('status.healthy'),
      tone: execTotals.blocked > 0 ? 'info' : 'pass',
      href: '/decision-inbox',
    },
  ]
  const badgeItems = [
    { text: 'PASS', tone: 'ok', verdict: 'PASS', scope: 'Post-v1.9 3-chip closeout', coverage: 'Selected governance gates passed', notCovered: 'Signoff/tapeout authority' },
    { text: 'APPROVED_CANONICAL', tone: 'ok', verdict: 'APPROVED_CANONICAL', scope: 'PRD v1.9 canonical pack', coverage: 'Canonical source/scope/schema frozen', notCovered: 'Runtime execution verdict' },
    { text: 'PASS_WITH_WARNINGS', tone: 'warn', verdict: 'PASS_WITH_WARNINGS', scope: 'Post-v1.9 3-chip closeout', coverage: 'G1~G9 + governed real-run chain', notCovered: 'Signoff/tapeout authority' },
    { text: 'REAL_RUN', tone: 'info', verdict: 'REAL_RUN', scope: 'SN2025/UART/ASYNC_FIFO runs', coverage: 'Execution produced real artifacts under governed runtime', notCovered: 'Formal production certification' },
    { text: 'CONDITIONAL_READY', tone: 'neutral', verdict: 'CONDITIONAL_READY', scope: 'Digital-only readiness interpretation', coverage: 'Bounded release readiness with warnings policy', notCovered: 'Unconditional production readiness' },
    { text: 'G1~G9 PASS', tone: 'ok', verdict: 'G1~G9 PASS', scope: 'Readiness compiler gates', coverage: 'Gate presence/consistency/traceability checks', notCovered: 'Business release approval' },
    { text: 'GOVERNED', tone: 'neutral', verdict: 'GOVERNED', scope: 'Execution + decision boundary', coverage: 'Policy-bound, auditable, traceable flow', notCovered: 'Autonomous authority override' },
    { text: 'FAIL_CLOSED', tone: 'neutral', verdict: 'FAIL_CLOSED', scope: 'Guardrail behavior', coverage: 'Invalid/missing evidence blocks progression', notCovered: 'Automatic recovery without review' },
  ] as const
  const breadcrumbText =
    routeMeta.groupKey === 'group.console_home' && routeMeta.pageKey === 'page.console_home'
      ? t('nav.console_home')
      : `${t('nav.console_home')} > ${t(routeMeta.groupKey)} > ${t(routeMeta.pageKey)}`
  const modeSwitchItems = [
    { mode: 'solo_eval' as OperatingMode, icon: UserRound, label: t('mode_switch.solo_eval') },
    { mode: 'team_project' as OperatingMode, icon: UsersRound, label: t('mode_switch.team_project') },
    { mode: 'enterprise_site' as OperatingMode, icon: Building2, label: t('mode_switch.enterprise_site') },
  ]
  const withMode = (path: string) => `${path}?mode=${effectiveMode}`

  return (
    <div className="min-h-screen bg-slate-950 font-sans text-slate-300">
      <header className="sticky top-0 z-30 border-b border-slate-800 bg-slate-950/95 backdrop-blur">
        <div className="flex min-h-16 items-center gap-3 px-3 md:px-4">
          <div className="flex min-w-0 items-center gap-3">
            <Link to={withMode('/console')} className="icaf-logo-wrap" aria-label={t('nav.console_home')}>
              <svg viewBox="0 0 64 64" className="icaf-logo-mark" aria-hidden="true">
                <rect x="16" y="14" width="32" height="36" rx="7" className="chip-core" />
                <path d="M8 22h8M8 30h8M8 38h8M8 46h8M48 22h8M48 30h8M48 38h8M48 46h8" className="pin-line" />
                <path d="M22 20v-6M30 20v-6M38 20v-6M22 56v-6M30 56v-6M38 56v-6" className="pin-line" />
                <circle cx="41.5" cy="33.5" r="2.8" className="node-dot" />
                <path d="M23 27h11" className="arrow-green" />
                <path d="M30.5 24.5 34 27l-3.5 2.5" className="arrow-green" />
                <path d="M34 40H23" className="arrow-amber" />
                <path d="M26.5 37.5 23 40l3.5 2.5" className="arrow-amber" />
              </svg>
            </Link>
            <div className="min-w-0">
              <div className="truncate text-[15px] font-bold uppercase tracking-[0.14em] text-white">
                ic-agent-flow
              </div>
              <div className="truncate text-[13px] tracking-[0.08em] text-cyan-300">console • Bundle: {activeId}</div>
            </div>
          </div>

          <nav className="ml-auto flex items-center gap-3 overflow-visible py-1" aria-label="Primary">
            {navGroups.map((group) => (
              <div key={group.labelKey} className="flex items-center gap-1.5 border-r border-slate-800 pr-2 last:border-r-0 last:pr-0">
                {group.items.map((item) => {
                  return (
                    <NavLink
                      key={item.to}
                      to={withMode(item.to)}
                      data-route-key={item.to}
                      aria-label={item.label}
                      className={({ isActive }) =>
                        `${navIconClass} ${
                          isActive
                            ? activeToneClass[item.tone]
                            : 'border-slate-800 bg-slate-900 hover:border-slate-700 hover:bg-slate-800 hover:text-slate-100'
                        }`
                      }
                    >
                      <HeaderIcon name={item.iconKey} size={18} />
                    </NavLink>
                  )
                })}
              </div>
            ))}
          </nav>

          <div className="hidden items-center gap-2 border-l border-slate-800 pl-4 xl:flex">
            {statusItems.map((item) => (
              <div
                key={item.label}
                className="group relative inline-flex h-11 w-7 items-center justify-center"
                aria-label={`${item.label}: ${item.value}`}
                onMouseEnter={() => setActiveHintKey(`status:${item.label}`)}
                onMouseLeave={() => setActiveHintKey((prev) => (prev === `status:${item.label}` ? null : prev))}
              >
                {item.href ? (
                  <NavLink to={withMode(item.href)} className={`status-light ${item.tone}`} aria-label={`${item.label}: ${item.value}`} />
                ) : (
                  <span className={`status-light ${item.tone}`} aria-hidden="true" />
                )}
                <span className={`${hintClass} ${activeHintKey === `status:${item.label}` ? 'visible opacity-100' : 'invisible opacity-0'}`}>{`${item.label}: ${item.value}`}</span>
              </div>
            ))}
          </div>

          <button
            onClick={() => setLang(lang === 'en' ? 'zh-tw' : 'en')}
            className="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-lg border border-slate-800 bg-slate-900 text-slate-400 transition-colors hover:border-slate-700 hover:text-slate-100 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cyan-300"
            aria-label="Toggle language"
          >
            <Languages size={18} aria-hidden="true" />
          </button>
        </div>

        <div className="border-t border-slate-900 px-4 py-2 md:px-6">
          <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-[14px]">
            <div className="font-medium text-slate-200">
              {breadcrumbText}
            </div>
            <div className="text-slate-500">{t('common.customer')}: <span className="font-mono text-slate-300">{inventory?.workspace_id ?? 'N/A'}</span></div>
            <div className="text-slate-500">{t('common.site')}: <span className="font-mono text-slate-300">taipei-lab</span></div>
            <div className="text-slate-500">{t('common.mode')}: <span className="font-mono text-cyan-300">{effectiveMode}</span></div>
            <div className="text-slate-500">{t('common.role')}: <span className="font-mono text-slate-300">customer_approver</span></div>
            <div className="text-slate-500">{t('common.active_chip')}: <span className="font-mono text-slate-300">{scopedChip}</span></div>
            <div className="text-slate-500">{t('common.active_run')}: <span className="font-mono text-slate-300">{scopedRun}</span></div>
            {isDevRuntime ? (
              <div className="ml-auto inline-flex items-center gap-1 rounded-md border border-slate-800 bg-slate-900/70 p-1">
                {modeSwitchItems.map((item) => {
                  const Icon = item.icon
                  const active = effectiveMode === item.mode
                  return (
                    <NavLink
                      key={item.mode}
                      to={withMode('/console').replace(`mode=${effectiveMode}`, `mode=${item.mode}`)}
                      className={`icon-hint group relative inline-flex h-8 w-8 items-center justify-center rounded border ${
                        active
                          ? 'border-cyan-500/60 bg-cyan-500/15 text-cyan-300'
                          : 'border-slate-800 bg-slate-900 text-slate-400 hover:border-slate-700 hover:text-slate-100'
                      }`}
                      aria-label={item.label}
                    >
                      <Icon size={14} aria-hidden="true" />
                    </NavLink>
                  )
                })}
              </div>
            ) : (
              <div className="ml-auto rounded-md border border-slate-800 bg-slate-900/70 px-2 py-1 text-xs text-slate-400">
                {t('mode_switch.release_locked')}: <span className="font-mono text-cyan-300">{effectiveMode}</span>
              </div>
            )}
          </div>
        </div>

        <div className="border-t border-slate-900 px-4 py-2 md:px-6">
          <div className="flex flex-wrap gap-2">
            {badgeItems.map((badge) => (
              <div key={badge.text} className="group relative">
                <span className={`icaf-badge ${badge.tone}`}>{badge.text}</span>
                <div className="badge-meta-card">
                  <div><span className="badge-meta-label">Verdict:</span> {badge.verdict}</div>
                  <div><span className="badge-meta-label">Scope:</span> {badge.scope}</div>
                  <div><span className="badge-meta-label">Coverage:</span> {badge.coverage}</div>
                  <div><span className="badge-meta-label">Not Covered:</span> {badge.notCovered}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2 overflow-x-auto border-t border-slate-900 px-4 py-2 md:px-6 xl:hidden">
          <Gauge size={14} className="shrink-0 text-slate-500" aria-hidden="true" />
          {statusItems.map((item) => (
            <div
              key={item.label}
              className="group relative inline-flex h-8 w-5 shrink-0 items-center justify-center"
              aria-label={`${item.label}: ${item.value}`}
              onMouseEnter={() => setActiveHintKey(`status-mobile:${item.label}`)}
              onMouseLeave={() => setActiveHintKey((prev) => (prev === `status-mobile:${item.label}` ? null : prev))}
            >
              {item.href ? (
                <NavLink to={withMode(item.href)} className={`status-light ${item.tone}`} aria-label={`${item.label}: ${item.value}`} />
              ) : (
                <span className={`status-light ${item.tone}`} aria-hidden="true" />
              )}
              <span className={`${hintClass} ${activeHintKey === `status-mobile:${item.label}` ? 'visible opacity-100' : 'invisible opacity-0'}`}>{`${item.label}: ${item.value}`}</span>
            </div>
          ))}
        </div>
      </header>

      <main className={`console-content bg-slate-950 ${isIntakeRoute ? 'p-2 md:p-2' : 'p-2 md:p-2'}`}>
        <div className={isIntakeRoute ? 'mx-auto max-w-[98vw]' : 'mx-auto max-w-[98vw]'}>
          <Outlet context={{ bundleId: activeId }} />
        </div>
      </main>
    </div>
  )
}
