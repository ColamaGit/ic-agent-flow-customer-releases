import { Suspense, lazy } from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import MainLayout from './layouts/MainLayout'
import { LanguageProvider } from './contexts/i18n'

const RunDetail = lazy(() => import('./pages/RunDetail'))
const GateBoard = lazy(() => import('./pages/GateBoard'))
const HumanReview = lazy(() => import('./pages/HumanReview'))
const RequirementIntake = lazy(() => import('./pages/RequirementIntake'))
const RequirementAdjudicationPage = lazy(() => import('./pages/RequirementAdjudicationPage'))
const UpstreamFlowPage = lazy(() => import('./pages/UpstreamFlowPage'))
const ConsoleHome = lazy(() => import('./pages/ConsoleHome'))
const KnowledgeAssetCenter = lazy(() => import('./pages/KnowledgeAssetCenter'))
const DecisionInbox = lazy(() => import('./pages/DecisionInbox'))
const AuditReplay = lazy(() => import('./pages/AuditReplay'))
const ArtifactInventory = lazy(() => import('./pages/ArtifactInventory'))
const QATrust = lazy(() => import('./pages/QATrust'))
const PackageReadiness = lazy(() => import('./pages/PackageReadiness'))
const StyleGuide = lazy(() => import('./pages/StyleGuide'))
const HumanAuthorityPage = lazy(() => import('./pages/HumanAuthorityPage'))
const QADashboard = lazy(() => import('./pages/QADashboard'))
const SignoffReadiness = lazy(() => import('./pages/SignoffReadiness'))
const TapeoutPackage = lazy(() => import('./pages/TapeoutPackage'))
const SiliconFeedback = lazy(() => import('./pages/SiliconFeedback'))
const PackageBuildRegistry = lazy(() => import('./pages/PackageBuildRegistry'))
const PackageBuildDetail = lazy(() => import('./pages/PackageBuildDetail'))
const DownstreamDecisionControlTower = lazy(() => import('./pages/DownstreamDecisionControlTower'))

function App() {
  return (
    <LanguageProvider>
      <BrowserRouter>
        <Suspense fallback={<div className="p-6 text-sm text-slate-400">Loading...</div>}>
          <Routes>
            <Route path="/" element={<MainLayout />}>
              <Route index element={<Navigate to="/console" replace />} />
              <Route path="console" element={<ConsoleHome />} />
              <Route path="flow-map" element={<GateBoard />} />
              <Route path="node-io" element={<HumanReview />} />
              <Route path="artifacts" element={<ArtifactInventory />} />
              <Route path="knowledge-assets" element={<KnowledgeAssetCenter />} />
              <Route path="qa-trust" element={<QATrust />} />
              <Route path="qa-strategy" element={<QADashboard />} />
              <Route path="downstream-decisions" element={<DownstreamDecisionControlTower />} />
              <Route path="downstream-decision-control" element={<DownstreamDecisionControlTower />} />
              <Route path="run-detail" element={<RunDetail />} />
              <Route path="package-readiness" element={<PackageReadiness />} />
              <Route path="authority-plane" element={<HumanAuthorityPage />} />
              <Route path="signoff" element={<SignoffReadiness />} />
              <Route path="signoff-readiness" element={<SignoffReadiness />} />
              <Route path="signoff/:bundleId" element={<SignoffReadiness />} />
              <Route path="tapeout-package" element={<TapeoutPackage />} />
              <Route path="tapeout-package/:bundleId" element={<TapeoutPackage />} />
              <Route path="silicon-feedback" element={<SiliconFeedback />} />
              <Route path="silicon-feedback/:bundleId" element={<SiliconFeedback />} />
              <Route path="decision-inbox" element={<DecisionInbox />} />
              <Route path="audit-replay" element={<AuditReplay />} />
              <Route path="style-guide" element={<StyleGuide />} />
              <Route path="package-builds" element={<PackageBuildRegistry />} />
              <Route path="package-builds/:buildId" element={<PackageBuildDetail />} />
              <Route path="run/:bundleId" element={<RunDetail />} />
              <Route path="verdicts/:bundleId" element={<GateBoard />} />
              <Route path="checkpoint/:bundleId" element={<HumanReview />} />
              <Route path="authority" element={<Navigate to="/authority-plane" replace />} />
              <Route path="qa" element={<Navigate to="/qa-strategy" replace />} />
              <Route path="intake" element={<RequirementIntake />} />
              <Route path="requirement-adjudication" element={<RequirementAdjudicationPage />} />
              <Route path="upstream-flow" element={<UpstreamFlowPage />} />
            </Route>
          </Routes>
        </Suspense>
      </BrowserRouter>
    </LanguageProvider>
  )
}

export default App
