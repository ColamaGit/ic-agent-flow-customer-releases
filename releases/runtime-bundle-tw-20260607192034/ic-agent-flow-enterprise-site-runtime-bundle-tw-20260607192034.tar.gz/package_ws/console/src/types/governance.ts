export interface EvidenceMetadata {
  file_ref: string;
  digest: string;
  timestamp: string;
}

export interface BundleMetadata {
  name?: string;
  version?: string;
  chip_id?: string;
  workspace_id?: string;
}

export interface BundleData {
  metadata?: BundleMetadata;
  phase?: string;
  verification?: string;
  readiness?: string;
  evidence_registry?: Record<string, EvidenceMetadata>;
}

export interface PortfolioData {
  workspace_id: string;
  chips: Array<{
    chip_id: string;
    phase: string;
    verification: string;
    readiness: string;
  }>;
}
