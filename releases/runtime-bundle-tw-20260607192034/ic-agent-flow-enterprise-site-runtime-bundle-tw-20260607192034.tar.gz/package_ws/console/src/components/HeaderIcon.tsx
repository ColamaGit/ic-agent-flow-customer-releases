import {
  LayoutGrid,
  GitBranch,
  Cpu,
  FileCheck2,
  Fence,
  FileBadge2,
  FileBarChart2,
 FileSearch2,
 TriangleAlert,
 CircleX,
 CircleCheck,
 CircleMinus,
 PlayCircle,
 UserCircle2,
  Package,
  Rocket,
  Settings,
  User,
  Lock,
  Clock3,
  BookOpen,
  Route,
  Diamond,
  ShieldCheck,
  BadgeCheck,
  Waypoints,
  type LucideIcon,
} from 'lucide-react'

export type HeaderIconKey =
  | 'dashboard' | 'flow' | 'chip' | 'policy' | 'gate' | 'evidence'
  | 'report' | 'audit' | 'warning' | 'error' | 'pass' | 'block'
  | 'runtime' | 'profile' | 'package' | 'release' | 'settings' | 'user'
  | 'lock' | 'clock' | 'route' | 'decision' | 'qa' | 'trust' | 'upstream' | 'knowledge'

const iconMap: Record<HeaderIconKey, LucideIcon> = {
  dashboard: LayoutGrid,
  flow: GitBranch,
  chip: Cpu,
  policy: FileCheck2,
  gate: Fence,
  evidence: FileBadge2,
  report: FileBarChart2,
  audit: FileSearch2,
  warning: TriangleAlert,
  error: CircleX,
  pass: CircleCheck,
  block: CircleMinus,
  runtime: PlayCircle,
  profile: UserCircle2,
  package: Package,
  release: Rocket,
  settings: Settings,
  user: User,
  lock: Lock,
  clock: Clock3,
  route: Route,
  decision: Diamond,
  qa: ShieldCheck,
  trust: BadgeCheck,
  upstream: Waypoints,
  knowledge: BookOpen,
}

type Props = {
  name: HeaderIconKey
  className?: string
  size?: number
}

export default function HeaderIcon({ name, className = '', size = 18 }: Props) {
  const Icon = iconMap[name]
  return <Icon size={size} className={className} aria-hidden="true" />
}
