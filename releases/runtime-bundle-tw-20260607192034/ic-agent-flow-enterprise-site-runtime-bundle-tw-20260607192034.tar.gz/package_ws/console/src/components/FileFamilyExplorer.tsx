import { ChevronDown, ChevronRight, FileCode2, FileJson2, FileText, FolderTree } from 'lucide-react'
import type { ReactNode } from 'react'
import { useMemo, useState } from 'react'
import { useTranslation } from '../contexts/i18n'
import { inferredMeaningUsage } from './fileFamilyInference'

export type FileFamilyEntry = {
  relative_path: string
  file_name?: string
  kind: 'file' | 'dir'
  meaning?: string | null
  usage?: string | null
  preview_text?: string | null
  size_bytes?: number
}

type TreeNode = {
  name: string
  path: string
  kind: 'dir' | 'file'
  children: TreeNode[]
  meaning?: string | null
  usage?: string | null
  preview_text?: string | null
  size_bytes?: number
}

function humanSize(size = 0) {
  if (size < 1024) return `${size} B`
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`
  return `${(size / (1024 * 1024)).toFixed(1)} MB`
}

function buildTree(fileList: FileFamilyEntry[]): TreeNode[] {
  const root: TreeNode = { name: '/', path: '', kind: 'dir', children: [] }
  const nodeMap = new Map<string, TreeNode>([['', root]])
  const sorted = [...fileList].sort((a, b) => a.relative_path.localeCompare(b.relative_path))

  for (const item of sorted) {
    const segs = item.relative_path.split('/').filter(Boolean)
    let currentPath = ''
    let parent = root
    for (let i = 0; i < segs.length; i += 1) {
      const seg = segs[i]
      currentPath = currentPath ? `${currentPath}/${seg}` : seg
      const isLeaf = i === segs.length - 1
      const kind: 'dir' | 'file' = isLeaf ? item.kind : 'dir'
      if (!nodeMap.has(currentPath)) {
        const node: TreeNode = {
          name: seg,
          path: currentPath,
          kind,
          children: [],
          meaning: isLeaf ? item.meaning ?? null : null,
          usage: isLeaf ? item.usage ?? null : null,
          preview_text: isLeaf ? item.preview_text ?? null : null,
          size_bytes: isLeaf ? item.size_bytes ?? 0 : 0,
        }
        nodeMap.set(currentPath, node)
        parent.children.push(node)
      }
      parent = nodeMap.get(currentPath)!
    }
  }

  const sortNodes = (nodes: TreeNode[]) => {
    nodes.sort((a, b) => {
      if (a.kind !== b.kind) return a.kind === 'dir' ? -1 : 1
      return a.name.localeCompare(b.name)
    })
    nodes.forEach((node) => sortNodes(node.children))
  }
  sortNodes(root.children)
  return root.children
}

function iconForFile(name: string) {
  if (name.endsWith('.json')) return <FileJson2 size={14} className="text-cyan-300" />
  if (/\.(md|log|sv|v|sdc)$/i.test(name)) return <FileCode2 size={14} className="text-blue-300" />
  return <FileText size={14} className="text-slate-300" />
}

function defaultSelectedPath(files: FileFamilyEntry[]) {
  return files.find((file) => file.kind === 'file' && file.preview_text)?.relative_path ?? ''
}


export default function FileFamilyExplorer({
  title,
  subtitle,
  files,
  showHeader = true,
}: {
  title: string
  subtitle: string
  files: FileFamilyEntry[]
  showHeader?: boolean
}) {
  const { t } = useTranslation()
  const tree = useMemo(() => buildTree(files), [files])
  const [selectedFilePath, setSelectedFilePath] = useState('')
  const [expandedDirs, setExpandedDirs] = useState<Record<string, boolean>>({})
  const effectiveSelectedPath = selectedFilePath || defaultSelectedPath(files)
  const selectedFile = files.find((file) => file.kind === 'file' && file.relative_path === effectiveSelectedPath)
  const selectedMeaningUsage = selectedFile ? inferredMeaningUsage(selectedFile.relative_path) : null

  const toggleDir = (path: string) => {
    setExpandedDirs((prev) => ({ ...prev, [path]: !prev[path] }))
  }

  const renderTree = (nodes: TreeNode[], depth = 0): ReactNode[] => nodes.map((node) => {
    const isDir = node.kind === 'dir'
    const isOpen = Boolean(expandedDirs[node.path])
    const isSelected = selectedFile?.relative_path === node.path
    return (
      <div key={node.path}>
        <button
          type="button"
          aria-expanded={isDir ? isOpen : undefined}
          onClick={() => (isDir ? toggleDir(node.path) : setSelectedFilePath(node.path))}
          className={`flex w-full cursor-pointer items-center gap-2 rounded px-2 py-1 text-left text-xs transition-colors ${isDir ? 'text-slate-300 hover:bg-slate-800' : 'hover:bg-slate-800'} ${isSelected ? 'bg-cyan-500/15 text-cyan-200' : 'text-slate-200'}`}
          style={{ paddingLeft: 8 + depth * 14 }}
        >
          {isDir ? (
            isOpen ? <ChevronDown size={14} className="shrink-0 text-slate-400" /> : <ChevronRight size={14} className="shrink-0 text-slate-400" />
          ) : (
            <span className="w-[14px] shrink-0" />
          )}
          {isDir ? <FolderTree size={14} className="shrink-0 text-indigo-300" /> : iconForFile(node.name)}
          <span className="truncate">{node.name}</span>
        </button>
        {isDir && isOpen && node.children.length > 0 && <div>{renderTree(node.children, depth + 1)}</div>}
      </div>
    )
  })

  return (
    <section className="rounded-xl border border-slate-800 bg-slate-900/70 overflow-hidden">
      {showHeader && (
        <div className="border-b border-slate-800 p-4">
          <h2 className="inline-flex items-center gap-2 text-base font-semibold text-slate-100">
            <FolderTree size={18} className="text-indigo-300" />
            {title}
          </h2>
          <p className="mt-2 text-sm leading-6 text-slate-400">{subtitle}</p>
        </div>
      )}
      <div className="grid min-h-[42vh] grid-cols-1 lg:grid-cols-2">
        <div className="border-r border-slate-800">
          <div className="border-b border-slate-800 px-3 py-2 text-xs uppercase tracking-widest text-slate-500">{t('run_explorer.file_tree')}</div>
          <div className="max-h-[48vh] overflow-auto p-2">
            {tree.length > 0 ? renderTree(tree) : <div className="p-2 text-sm text-slate-500">{t('run_explorer.no_files')}</div>}
          </div>
        </div>
        <div>
          <div className="border-b border-slate-800 px-3 py-2 text-xs uppercase tracking-widest text-slate-500">{t('run_explorer.preview')}</div>
          <div className="max-h-[48vh] overflow-auto p-3">
            {!selectedFile && <div className="text-sm text-slate-500">{t('run_explorer.select_file')}</div>}
            {selectedFile && (
              <div className="space-y-3">
                <div className="rounded border border-slate-800 bg-slate-950 p-2">
                  <div className="grid gap-2 text-xs sm:grid-cols-2">
                    <div>
                      <div className="mb-1 text-slate-400">{t('run_explorer.path')}</div>
                      <div className="break-all font-mono text-cyan-300">{selectedFile.relative_path}</div>
                    </div>
                    <div>
                      <div className="mb-1 text-slate-400">{t('run_explorer.size')}</div>
                      <div className="font-mono text-cyan-300">{humanSize(selectedFile.size_bytes)}</div>
                    </div>
                    <div className="sm:col-span-2">
                      <div className="mb-1 text-slate-400">{t('run_explorer.meaning')}</div>
                      <div className="text-slate-200">{selectedFile.meaning ?? selectedMeaningUsage?.meaning ?? t('run_explorer.meaning_not_available')}</div>
                    </div>
                    <div className="sm:col-span-2">
                      <div className="mb-1 text-slate-400">{t('run_explorer.usage')}</div>
                      <div className="text-slate-200">{selectedFile.usage ?? selectedMeaningUsage?.usage ?? t('run_explorer.usage_not_available')}</div>
                    </div>
                  </div>
                </div>
                {selectedFile.preview_text ? (
                  <pre className="overflow-auto whitespace-pre-wrap rounded border border-slate-800 bg-slate-950 p-3 text-xs text-slate-200">
                    {selectedFile.preview_text}
                  </pre>
                ) : (
                  <div className="text-sm text-slate-500">{t('run_explorer.preview_not_supported')}</div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  )
}
