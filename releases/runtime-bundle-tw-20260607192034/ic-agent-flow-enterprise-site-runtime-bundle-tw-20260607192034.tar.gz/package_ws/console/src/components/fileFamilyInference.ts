export function stripOrderingPrefix(segment: string) {
  return segment.replace(/^\d+_/, '')
}

export function logicalArtifactPath(relativePath: string) {
  return relativePath.split('/').filter(Boolean).map(stripOrderingPrefix).join('/')
}

function inferredRunMeaningUsage(relativePath: string): { meaning: string; usage: string } | null {
  const logicalPath = logicalArtifactPath(relativePath)
  const name = logicalPath.split('/').pop() ?? logicalPath

  if (name === 'RUN_STRUCTURE_EXPLAINED.md') {
    return {
      meaning: 'Human-readable map of this production-run folder.',
      usage: 'Use it to understand how PRD v1.0 upstream snapshots, PRD v0.9 execution evidence, reports, dashboard objects, and package/readiness surfaces are laid out for this run.',
    }
  }
  if (logicalPath.startsWith('inputs/spec/')) {
    return {
      meaning: 'Run-local PRD v1.0 requirement/spec snapshot consumed by this execution.',
      usage: 'Confirms what upstream spec truth was copied from chips/<chip_id>/ into the immutable run input plane; do not treat this file as the canonical upstream truth owner.',
    }
  }
  if (logicalPath.startsWith('inputs/graph/')) {
    if (name === 'graph_to_generation_plan.json') {
      return {
        meaning: 'PRD v1.0 graph-to-generation plan snapshot.',
        usage: 'Bridges frozen graph truth into RTL generation and PRD v0.9 Routine-B execution planning; this is the key handoff artifact before runner input assembly.',
      }
    }
    return {
      meaning: 'Run-local PRD v1.0 graph handoff snapshot.',
      usage: 'Used to audit the graph, validation, freeze, and generation-plan objects consumed by this run; canonical editable graph truth remains under chips/<chip_id>/.',
    }
  }
  if (logicalPath.startsWith('inputs/design/rtl/') || logicalPath.startsWith('inputs/rtl/')) {
    if (/\.(v|sv)$/i.test(name)) {
      return {
        meaning: 'Run-local RTL candidate consumed or prepared for PRD v0.9 Routine-B.',
        usage: 'Use it to inspect exactly what RTL was handed to lint/sim/synthesis stages; it is execution input evidence, not automatic upstream promotion.',
      }
    }
    return {
      meaning: 'Run-local RTL generation/candidate support artifact.',
      usage: 'Supports the bridge from PRD v1.0 frozen graph/generation plan into PRD v0.9 execution inputs.',
    }
  }
  if (logicalPath.startsWith('dashboard_objects/')) {
    return {
      meaning: 'Derived console object for this run.',
      usage: 'Feeds Run Detail, readiness, signoff, tapeout, or Agent Trust panels; it is a dashboard surface derived from evidence, not a canonical truth source.',
    }
  }
  if (logicalPath.endsWith('governance/upstream_alignment_map.json')) {
    return {
      meaning: 'Agent routing map for upstream chip truth.',
      usage: 'Use this JSON contract to route chip files to upstream nodes, console surfaces, and PRD references; generate the Markdown companion from this JSON only.',
    }
  }
  if (logicalPath.endsWith('governance/upstream_alignment_map.md')) {
    return {
      meaning: 'Human-readable agent routing map companion.',
      usage: 'Review companion generated from upstream_alignment_map.json only; do not hand-edit or treat it as authoritative input.',
    }
  }
  if (logicalPath.startsWith('reports/') || logicalPath.includes('readiness_report')) {
    return {
      meaning: 'Formal report/readiness family artifact for this run.',
      usage: 'Use it to inspect machine-readable or human-readable readiness, signoff, tapeout, skill, and feedback conclusions backed by run-local evidence refs.',
    }
  }
  if (/^(v\d|h\d|power_ir_|dft_|esd_|io_)/i.test(logicalPath)) {
    return {
      meaning: 'PRD v0.9 Routine-B execution-stage evidence.',
      usage: 'Represents output, logs, metrics, or normalized evidence from one runner stage; use with reports to judge PASS/BLOCKED/WARNING status.',
    }
  }
  return null
}

export function inferredMeaningUsage(relativePath: string): { meaning: string; usage: string } {
  const runMeaningUsage = inferredRunMeaningUsage(relativePath)
  if (runMeaningUsage) return runMeaningUsage

  const name = relativePath.split('/').pop() ?? relativePath
  if (name === 'template_resolution_record.json') {
    return {
      meaning: 'Template selection or deferral decision record.',
      usage: 'Explains whether intake used, auto-resolved, deferred, or blocked template use before chip upstream truth continues.',
    }
  }
  if (name === 'requirement_item_adjudication_record.json') {
    return {
      meaning: 'Machine-readable human adjudication decision.',
      usage: 'Local AI agents may resume only after this record is valid for scope, authority, target refs, and freshness.',
    }
  }
  if (name === 'graph_validation_result.json') {
    return {
      meaning: 'Graph validation verdict record.',
      usage: 'Determines whether graph freeze can proceed or whether blockers must be resolved before PRD v0.9 handoff.',
    }
  }
  if (name === 'graph_to_generation_plan.json') {
    return {
      meaning: 'Bounded graph-to-generation plan.',
      usage: 'Handoff plan from frozen v1.0 truth toward RTL candidate generation and PRD v0.9 Routine-B preparation.',
    }
  }
  if (name === 'v09_handoff_preflight_manifest.json') {
    return {
      meaning: 'PRD v0.9 handoff preflight manifest.',
      usage: 'Confirms upstream truth is ready for PRD v0.9 runner execution after RTL Generation; missing sources require root-cause remediation before handoff.',
    }
  }
  if (/\.sdc$/i.test(name)) {
    return {
      meaning: 'Constraint candidate file.',
      usage: 'Snapshot as timing/physical constraint context when the downstream runner prepares design inputs.',
    }
  }
  if (/\.(v|sv)$/i.test(name)) {
    return {
      meaning: 'Generated or approved RTL candidate file.',
      usage: 'Consumed as candidate RTL input by PRD v0.9 Routine-B after upstream gates are satisfied.',
    }
  }
  return {
    meaning: 'Chip upstream support file.',
    usage: 'Supports PRD v1.0 upstream review, evidence, or handoff context inside chips/<chip_id>/.',
  }
}
