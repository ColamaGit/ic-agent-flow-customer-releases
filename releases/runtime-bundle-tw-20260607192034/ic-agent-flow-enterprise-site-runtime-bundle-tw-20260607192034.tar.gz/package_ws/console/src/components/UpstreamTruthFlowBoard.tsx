import { ChevronDown, ChevronRight, FileCheck2 } from 'lucide-react'
import { useState } from 'react'
import { useTranslation } from '../contexts/i18n'

export type UpstreamTruthFlowNode = {
  node_id: string
  scope_type?: string
  status: string
  expected_files?: string[]
  existing_files?: string[]
  missing_files?: string[]
  validated_object_refs?: string[]
  missing_object_refs?: string[]
  reason?: string
  next_action?: string | null
  manifest_detail?: {
    manifest_ref?: string | null
    manifest_status?: string | null
    ready_for_v09_handoff?: boolean | null
    missing_sources?: string[]
    root_cause_required?: boolean | null
    verification_source_lane?: {
      required_by_policy?: boolean | null
      source_family?: string | null
      source_root?: string | null
      logical_input_root?: string | null
      physical_01_inputs_root?: string | null
      consumer_stages?: string[]
      expected_files?: string[]
      missing_files?: string[]
      materialized?: boolean | null
    } | null
    run_topology_policy?: {
      prefix_counts_are_topology_dependent?: boolean | null
      fixed_highest_prefix_is_not_authoritative?: boolean | null
      reports_dir_must_follow_materialized_topology?: boolean | null
    } | null
    alignment_map_detail?: {
      json_ref?: string | null
      md_ref?: string | null
      alignment_status?: string | null
      execution_handoff_status?: string | null
      item_count?: number | null
      source_digest_bundle?: string | null
      surface_aliases?: {
        dashboard_objects?: {
          canonical?: string | null
          legacy?: string[]
          status?: string | null
          notes?: string | null
        }
      }
      latest_run_ref?: string | null
      latest_readiness_ref?: string | null
      open_blockers?: string[]
    } | null
    upstream_node_output_check?: {
      ref?: string | null
      status?: string | null
    }
    source_coverage_groups?: Array<{
      source_family: string
      expected_files: string[]
      missing_files: string[]
    }>
  } | null
}

function toChipRelativePath(chipId: string, rawPath: string): string {
  const normalized = String(rawPath ?? '').replace(/\\/g, '/')
  const marker = `/chips/${chipId}/`
  const idx = normalized.indexOf(marker)
  if (idx >= 0) return normalized.slice(idx + marker.length)
  const prefix = `chips/${chipId}/`
  if (normalized.startsWith(prefix)) return normalized.slice(prefix.length)
  return normalized
}

function nodeLabel(nodeId: string, t: (key: string) => string) {
  const key = `upstream_board.node.${nodeId}`
  const translated = t(key)
  return translated === key ? nodeId : translated
}

function statusClass(status: string) {
  const normalized = status.toUpperCase()
  if (normalized === 'PASS') return 'border-emerald-500/40 bg-emerald-500/10 text-emerald-200'
  if (normalized.includes('REVIEW')) return 'border-amber-500/40 bg-amber-500/10 text-amber-200'
  if (normalized === 'WARN' || normalized.includes('CONDITION')) return 'border-amber-500/40 bg-amber-500/10 text-amber-200'
  if (normalized === 'NOT_CREATED') return 'border-slate-600 bg-slate-950 text-slate-300'
  if (normalized.includes('BLOCK') || normalized.includes('FAIL')) return 'border-rose-500/40 bg-rose-500/10 text-rose-200'
  return 'border-cyan-500/40 bg-cyan-500/10 text-cyan-200'
}

function statusLabel(node: UpstreamTruthFlowNode, t: (key: string) => string) {
  const nodeId = node.node_id
  const status = node.status
  const normalized = status.toUpperCase()
  if (nodeId === 'requirement_adjudication' && (normalized === 'HUMAN_REVIEW_REQUIRED' || normalized === 'PENDING')) {
    return t('upstream_board.status.human_signoff_gate')
  }
  if (nodeId === 'freeze' && node.reason === 'freeze_records_conditional') {
    return t('upstream_board.status.frozen_with_conditions')
  }
  return status
}

function translatedOrDefault(t: (key: string) => string, key: string, fallback: string) {
  const translated = t(key)
  return translated === key ? fallback : translated
}

function DetailRow({
  rowTestId,
  valueTestId,
  label,
  value,
}: {
  rowTestId: string
  valueTestId: string
  label: string
  value: string
}) {
  return (
    <div data-testid={rowTestId} className="rounded border border-cyan-500/10 bg-slate-950/40 px-3 py-2">
      <div className="text-[11px] font-semibold uppercase tracking-wider text-cyan-200">{label}</div>
      <div data-testid={valueTestId} className="mt-1 break-all font-mono text-xs leading-5 text-cyan-100">
        {value}
      </div>
    </div>
  )
}

function isV09HandoffPreflight(nodeId: string) {
  return nodeId === 'v09_handoff_preflight'
}

function diagnosticText(node: UpstreamTruthFlowNode, t: (key: string) => string, kind: 'why' | 'fix') {
  const reason = node.reason || 'unknown'
  const fallback =
    kind === 'why'
      ? `${node.status}: ${reason}`
      : node.next_action
        ? `Continue with ${node.next_action} after closing this gate.`
        : 'Review this gate evidence and update the required upstream object files.'
  return translatedOrDefault(t, `upstream_board.diagnostic.${kind}.${reason}`, fallback)
}

export default function UpstreamTruthFlowBoard({
  chipId,
  nodes,
}: {
  chipId: string
  nodes: UpstreamTruthFlowNode[]
}) {
  const { t } = useTranslation()
  const [expandedNodes, setExpandedNodes] = useState<Record<string, boolean>>({})
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({})

  const toggleNode = (nodeId: string) => {
    setExpandedNodes((prev) => ({ ...prev, [nodeId]: !prev[nodeId] }))
  }

  const toggleSection = (nodeId: string, sectionId: string) => {
    const key = `${nodeId}:${sectionId}`
    setExpandedSections((prev) => ({ ...prev, [key]: !prev[key] }))
  }

  return (
    <section data-testid="upstream-truth-flow-board" className="rounded-xl border border-slate-800 bg-slate-900/70 p-5">
      <div className="mb-3 flex items-center gap-2 text-sm font-semibold uppercase tracking-wider text-cyan-300">
        <FileCheck2 size={16} />
        {t('upstream_board.title')}
      </div>
      <div className="mb-4 rounded border border-cyan-800/60 bg-slate-950/60 px-3 py-2 text-xs leading-5 text-cyan-100">
        {t('upstream_board.scope_note').replace('{chip_id}', chipId)}
      </div>
      <div className="mb-4 rounded border border-emerald-700/50 bg-emerald-950/20 px-3 py-2 text-xs leading-5 text-emerald-100">
        {t('upstream_board.pass_criteria')}
      </div>
      <div
        data-testid="upstream-truth-flow-board-nodes"
        className="grid gap-3 md:grid-cols-2 xl:grid-cols-3"
      >
        {nodes.map((node) => {
          const existingRefs = node.existing_files ?? node.validated_object_refs ?? []
          const missingRefs = node.missing_files ?? node.missing_object_refs ?? []
          const explicitExpectedRefs = node.expected_files ?? []
          const expectedRefs = explicitExpectedRefs.length ? explicitExpectedRefs : [...existingRefs, ...missingRefs]
          const expectedCount = expectedRefs.length
          const missingCount = missingRefs.length
          const isPass = node.status.toUpperCase() === 'PASS'
          const manifestDetail = node.manifest_detail ?? null
          const manifestMissingSources = manifestDetail?.missing_sources ?? []
          const isV09Node = isV09HandoffPreflight(node.node_id)
          const isNodeExpanded = expandedNodes[node.node_id] ?? false
          const isSectionExpanded = (sectionId: string) => expandedSections[`${node.node_id}:${sectionId}`] ?? false
          return (
            <div key={node.node_id} className="rounded-lg border border-slate-700 bg-slate-950/70 p-3">
              <div className="flex items-start justify-between gap-3">
                {isV09Node ? (
                  <button
                    type="button"
                    data-testid={`upstream-node-toggle-${node.node_id}`}
                    onClick={() => toggleNode(node.node_id)}
                    className="min-w-0 flex flex-1 items-start gap-2 text-left"
                  >
                    <span className="mt-0.5 text-slate-400">
                      {isNodeExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                    </span>
                    <span className="min-w-0">
                      <span className="block text-sm font-semibold text-white">{nodeLabel(node.node_id, t)}</span>
                      <span className="mt-1 block text-xs text-slate-500">{node.scope_type ?? 'CHIP_UPSTREAM'}</span>
                    </span>
                  </button>
                ) : (
                  <div className="min-w-0">
                    <div className="text-sm font-semibold text-white">{nodeLabel(node.node_id, t)}</div>
                    <div className="mt-1 text-xs text-slate-500">{node.scope_type ?? 'CHIP_UPSTREAM'}</div>
                  </div>
                )}
                <span className={`shrink-0 rounded border px-2 py-1 text-[11px] font-semibold ${statusClass(node.status)}`}>
                  {statusLabel(node, t)}
                </span>
              </div>
              {isV09Node && (
                <div className="mt-3 rounded border border-cyan-500/20 bg-cyan-950/20 p-3 text-xs text-cyan-100">
                  <div className="font-semibold text-cyan-200">{t('upstream_board.v09.scope_label')}: CHIP_UPSTREAM</div>
                  <div>{t('upstream_board.v09.meaning_label')}: {t('upstream_board.v09.meaning')}</div>
                  <div>{t('upstream_board.v09.runner_boundary')}</div>
                </div>
              )}
              {(!isV09Node || isNodeExpanded) && <div className="mt-3 space-y-2 text-xs text-slate-400">
                <div>{t('upstream_board.expected_files')}: {expectedCount}</div>
                <ul className="space-y-1">
                  {expectedRefs.length > 0 ? expectedRefs.map((path) => (
                    <li key={`expected-${node.node_id}-${path}`} className="break-all font-mono text-[11px] text-slate-300">
                      - {toChipRelativePath(chipId, path)}
                    </li>
                  )) : (
                    <li className="font-mono text-[11px] text-slate-500">- none</li>
                  )}
                </ul>
                <div>{t('upstream_board.missing_files')}: {missingCount}</div>
                <ul className="space-y-1">
                  {missingRefs.length > 0 ? missingRefs.map((path) => (
                    <li key={`missing-${node.node_id}-${path}`} className="break-all font-mono text-[11px] text-amber-200/90">
                      - {toChipRelativePath(chipId, path)}
                    </li>
                  )) : (
                    <li className="font-mono text-[11px] text-slate-500">- none</li>
                  )}
                </ul>
                <div>{t('upstream_board.next_action')}: {node.next_action ?? '-'}</div>
              </div>}
              {isV09Node && isNodeExpanded && manifestDetail && (
                <div className="mt-3 space-y-3 rounded-lg border border-cyan-500/20 bg-cyan-950/20 p-3 text-xs text-cyan-100">
                  <div className="rounded border border-cyan-500/15 bg-slate-950/50">
                    <button type="button" data-testid="v09-section-toggle-manifest_overview" onClick={() => toggleSection(node.node_id, 'manifest_overview')} className="flex w-full items-center justify-between px-3 py-2 text-left">
                      <span className="font-semibold text-cyan-200">Manifest Overview</span>
                      {isSectionExpanded('manifest_overview') ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                    </button>
                    {isSectionExpanded('manifest_overview') && (
                      <div data-testid="v09-section-body-manifest_overview" className="space-y-2 border-t border-cyan-500/15 px-3 py-2">
                        <DetailRow
                          rowTestId="v09-manifest-row-manifest_ref"
                          valueTestId="v09-manifest-value-manifest_ref"
                          label={t('upstream_board.v09.manifest_ref')}
                          value={manifestDetail.manifest_ref ?? '-'}
                        />
                        <DetailRow
                          rowTestId="v09-manifest-row-manifest_status"
                          valueTestId="v09-manifest-value-manifest_status"
                          label={t('upstream_board.v09.manifest_status')}
                          value={manifestDetail.manifest_status ?? '-'}
                        />
                        <DetailRow
                          rowTestId="v09-manifest-row-upstream_check"
                          valueTestId="v09-manifest-value-upstream_check"
                          label={t('upstream_board.v09.upstream_check')}
                          value={manifestDetail.upstream_node_output_check?.status ?? '-'}
                        />
                        <DetailRow
                          rowTestId="v09-manifest-row-checker_ref"
                          valueTestId="v09-manifest-value-checker_ref"
                          label={t('upstream_board.v09.checker_ref')}
                          value={manifestDetail.upstream_node_output_check?.ref ?? '-'}
                        />
                        <DetailRow
                          rowTestId="v09-manifest-row-root_cause_required"
                          valueTestId="v09-manifest-value-root_cause_required"
                          label={t('upstream_board.v09.root_cause_required')}
                          value={manifestDetail.root_cause_required ? 'true' : 'false'}
                        />
                      </div>
                    )}
                  </div>
                  {manifestDetail.verification_source_lane && (
                    <div className="rounded border border-cyan-500/15 bg-slate-950/50">
                      <button type="button" data-testid="v09-section-toggle-verification_source_lane" onClick={() => toggleSection(node.node_id, 'verification_source_lane')} className="flex w-full items-center justify-between px-3 py-2 text-left">
                        <span className="font-semibold text-cyan-200">{t('upstream_board.v09.verification_lane_title')}</span>
                        {isSectionExpanded('verification_source_lane') ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                      </button>
                      {isSectionExpanded('verification_source_lane') && (
                        <div data-testid="v09-section-body-verification_source_lane" className="space-y-2 border-t border-cyan-500/15 px-3 py-2">
                          <div className="mt-1 text-cyan-100">
                            {t('upstream_board.v09.verification_lane_required')}: {manifestDetail.verification_source_lane.required_by_policy ? 'true' : 'false'}
                          </div>
                          <div className="mt-1 text-cyan-100">
                            {t('upstream_board.v09.verification_lane_source_root')}: <span className="font-mono">{manifestDetail.verification_source_lane.source_root ?? '-'}</span>
                          </div>
                          <div className="mt-1 text-cyan-100">
                            {t('upstream_board.v09.verification_lane_consumers')}: <span className="font-mono">{(manifestDetail.verification_source_lane.consumer_stages ?? []).length > 0 ? manifestDetail.verification_source_lane.consumer_stages!.join(', ') : '-'}</span>
                          </div>
                          <div className="mt-1 text-cyan-100">
                            {t('upstream_board.expected_files')}: {manifestDetail.verification_source_lane.expected_files?.length ?? 0}
                          </div>
                          <ul className="mt-1 space-y-1">
                            {(manifestDetail.verification_source_lane.expected_files ?? []).length > 0 ? manifestDetail.verification_source_lane.expected_files!.map((path) => (
                              <li key={`verification-expected-${path}`} className="break-all font-mono text-[11px] text-cyan-50/90">
                                - {toChipRelativePath(chipId, path)}
                              </li>
                            )) : (
                              <li className="font-mono text-[11px] text-slate-400">- none</li>
                            )}
                          </ul>
                          <div className="mt-2 text-amber-200">
                            {t('upstream_board.missing_files')}: {manifestDetail.verification_source_lane.missing_files?.length ?? 0}
                          </div>
                          <ul className="mt-1 space-y-1">
                            {(manifestDetail.verification_source_lane.missing_files ?? []).length > 0 ? manifestDetail.verification_source_lane.missing_files!.map((path) => (
                              <li key={`verification-missing-${path}`} className="break-all font-mono text-[11px] text-amber-200/90">
                                - {toChipRelativePath(chipId, path)}
                              </li>
                            )) : (
                              <li className="font-mono text-[11px] text-slate-400">- none</li>
                            )}
                          </ul>
                          <div className="mt-1 text-cyan-200">
                            {t('upstream_board.v09.verification_lane_materialized')}: {manifestDetail.verification_source_lane.materialized ? 'true' : 'false'}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                  {manifestDetail.run_topology_policy && (
                    <div className="rounded border border-cyan-500/15 bg-slate-950/50">
                      <button type="button" data-testid="v09-section-toggle-run_topology_policy" onClick={() => toggleSection(node.node_id, 'run_topology_policy')} className="flex w-full items-center justify-between px-3 py-2 text-left">
                        <span className="font-semibold text-cyan-200">{t('upstream_board.v09.run_topology_title')}</span>
                        {isSectionExpanded('run_topology_policy') ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                      </button>
                      {isSectionExpanded('run_topology_policy') && (
                        <div data-testid="v09-section-body-run_topology_policy" className="space-y-2 border-t border-cyan-500/15 px-3 py-2">
                          <div className="mt-1 text-cyan-100">
                            {t('upstream_board.v09.topology_dependent_prefixes')}: {manifestDetail.run_topology_policy.prefix_counts_are_topology_dependent ? 'true' : 'false'}
                          </div>
                          <div className="mt-1 text-cyan-100">
                            {t('upstream_board.v09.topology_prefix_authority')}: {manifestDetail.run_topology_policy.fixed_highest_prefix_is_not_authoritative ? 'true' : 'false'}
                          </div>
                          <div className="mt-1 text-cyan-100">
                            {t('upstream_board.v09.topology_reports_policy')}: {manifestDetail.run_topology_policy.reports_dir_must_follow_materialized_topology ? 'true' : 'false'}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                  {manifestDetail.alignment_map_detail && (
                    <div className="rounded border border-cyan-500/15 bg-slate-950/50">
                      <button type="button" data-testid="v09-section-toggle-alignment_map_detail" onClick={() => toggleSection(node.node_id, 'alignment_map_detail')} className="flex w-full items-center justify-between px-3 py-2 text-left">
                        <span className="font-semibold text-cyan-200">{t('upstream_board.v09.alignment_map_title')}</span>
                        {isSectionExpanded('alignment_map_detail') ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                      </button>
                      {isSectionExpanded('alignment_map_detail') && (
                        <div data-testid="v09-section-body-alignment_map_detail" className="space-y-2 border-t border-cyan-500/15 px-3 py-2">
                          <div className="mt-1 text-cyan-100">
                            {t('upstream_board.v09.alignment_map_json_ref')}: <span className="font-mono">{manifestDetail.alignment_map_detail.json_ref ?? '-'}</span>
                          </div>
                          <div className="mt-1 text-cyan-100">
                            {t('upstream_board.v09.alignment_map_md_ref')}: <span className="font-mono">{manifestDetail.alignment_map_detail.md_ref ?? '-'}</span>
                          </div>
                          <div className="mt-1 text-cyan-100">
                            {t('upstream_board.v09.alignment_map_status')}: {manifestDetail.alignment_map_detail.alignment_status ?? '-'}
                          </div>
                          <div className="mt-1 text-cyan-100">
                            {t('upstream_board.v09.alignment_map_handoff_status')}: {manifestDetail.alignment_map_detail.execution_handoff_status ?? '-'}
                          </div>
                          <div className="mt-1 text-cyan-100">
                            {t('upstream_board.v09.alignment_map_items')}: {manifestDetail.alignment_map_detail.item_count ?? 0}
                          </div>
                          <div className="mt-1 text-cyan-100">
                            {t('upstream_board.v09.alignment_map_surface_canonical')}: <span className="font-mono">{manifestDetail.alignment_map_detail.surface_aliases?.dashboard_objects?.canonical ?? '-'}</span>
                          </div>
                          <div className="mt-1 text-cyan-100">
                            {t('upstream_board.v09.alignment_map_surface_legacy')}: <span className="font-mono">{(manifestDetail.alignment_map_detail.surface_aliases?.dashboard_objects?.legacy ?? []).length > 0 ? manifestDetail.alignment_map_detail.surface_aliases!.dashboard_objects!.legacy!.join(', ') : '-'}</span>
                          </div>
                          <div className="mt-1 text-cyan-100">
                            {t('upstream_board.v09.alignment_map_open_blockers')}: <span className="font-mono">{(manifestDetail.alignment_map_detail.open_blockers ?? []).length > 0 ? manifestDetail.alignment_map_detail.open_blockers!.join(', ') : t('upstream_board.v09.none')}</span>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                  <div className="rounded border border-cyan-500/15 bg-slate-950/50">
                    <button type="button" data-testid="v09-section-toggle-source_coverage_groups" onClick={() => toggleSection(node.node_id, 'source_coverage_groups')} className="flex w-full items-center justify-between px-3 py-2 text-left">
                      <span className="font-semibold text-cyan-200">{t('upstream_board.v09.source_coverage_title')}</span>
                      {isSectionExpanded('source_coverage_groups') ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                    </button>
                    {isSectionExpanded('source_coverage_groups') && (
                      <div data-testid="v09-section-body-source_coverage_groups" className="mt-2 space-y-2 border-t border-cyan-500/15 px-3 py-2">
                        {(manifestDetail.source_coverage_groups ?? []).length > 0 ? manifestDetail.source_coverage_groups!.map((group) => (
                          <div key={group.source_family} className="rounded border border-cyan-500/15 bg-slate-950/50 p-2">
                            <div className="font-semibold text-cyan-100">{group.source_family}</div>
                            <div className="mt-1 text-cyan-200">
                              {t('upstream_board.expected_files')}: {group.expected_files.length}
                            </div>
                            <ul className="mt-1 space-y-1">
                              {group.expected_files.length > 0 ? group.expected_files.map((path) => (
                                <li key={`${group.source_family}-expected-${path}`} className="break-all font-mono text-[11px] text-cyan-50/90">
                                  - {toChipRelativePath(chipId, path)}
                                </li>
                              )) : (
                                <li className="font-mono text-[11px] text-slate-400">- none</li>
                              )}
                            </ul>
                            <div className="mt-2 text-amber-200">
                              {t('upstream_board.missing_files')}: {group.missing_files.length}
                            </div>
                            <ul className="mt-1 space-y-1">
                              {group.missing_files.length > 0 ? group.missing_files.map((path) => (
                                <li key={`${group.source_family}-missing-${path}`} className="break-all font-mono text-[11px] text-amber-200/90">
                                  - {toChipRelativePath(chipId, path)}
                                </li>
                              )) : (
                                <li className="font-mono text-[11px] text-slate-400">- none</li>
                              )}
                            </ul>
                          </div>
                        )) : (
                          <div className="rounded border border-cyan-500/15 bg-slate-950/50 p-2 text-slate-300">
                            {t('upstream_board.v09.source_coverage_not_available')}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                  <div className="rounded border border-cyan-500/15 bg-slate-950/50">
                    <button type="button" data-testid="v09-section-toggle-readiness_summary" onClick={() => toggleSection(node.node_id, 'readiness_summary')} className="flex w-full items-center justify-between px-3 py-2 text-left">
                      <span className="font-semibold text-cyan-200">Readiness Summary</span>
                      {isSectionExpanded('readiness_summary') ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                    </button>
                    {isSectionExpanded('readiness_summary') && (
                      <div data-testid="v09-section-body-readiness_summary" className="space-y-2 border-t border-cyan-500/15 px-3 py-2">
                        <div>
                          <span className="font-semibold text-cyan-200">{t('upstream_board.v09.missing_sources')}: </span>
                          <span className="font-mono text-amber-200">{manifestMissingSources.length > 0 ? manifestMissingSources.map((path) => toChipRelativePath(chipId, path)).join(', ') : t('upstream_board.v09.none')}</span>
                        </div>
                        <div className="rounded border border-cyan-500/15 bg-slate-950/50 p-2 text-cyan-100">
                          {manifestDetail.ready_for_v09_handoff
                            ? t('upstream_board.v09.ready')
                            : t('upstream_board.v09.not_ready')}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}
              {!isPass && (
                <div className="mt-3 space-y-2 rounded-lg border border-amber-500/30 bg-amber-950/20 p-3 text-xs text-amber-100">
                  <div>
                    <span className="font-semibold text-amber-200">{t('upstream_board.diagnostic.why_label')}: </span>
                    {diagnosticText(node, t, 'why')}
                  </div>
                  <div>
                    <span className="font-semibold text-amber-200">{t('upstream_board.diagnostic.fix_label')}: </span>
                    {diagnosticText(node, t, 'fix')}
                  </div>
                  {missingCount > 0 && (
                    <div className="rounded border border-amber-500/20 bg-slate-950/50 p-2">
                      <div className="font-semibold text-amber-200">{t('upstream_board.diagnostic.file_issue_label')}</div>
                      <div className="mt-1 text-amber-100">
                        {t('upstream_board.diagnostic.file_issue')
                          .replace('{count}', String(missingCount))
                          .replace('{node}', nodeLabel(node.node_id, t))}
                      </div>
                      <div className="mt-1 text-amber-100">{t('upstream_board.diagnostic.file_fix')}</div>
                    </div>
                  )}
                </div>
              )}
            </div>
          )
        })}
      </div>
    </section>
  )
}
