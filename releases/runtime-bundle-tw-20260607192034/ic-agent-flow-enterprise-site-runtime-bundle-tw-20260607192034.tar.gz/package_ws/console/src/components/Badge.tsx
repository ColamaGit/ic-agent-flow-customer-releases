type BadgeTone = 'ok' | 'warn' | 'block' | 'info' | 'neutral'

type BadgeProps = {
  label: string
  className?: string
}

function normalizeTone(label: string): BadgeTone {
  const key = label.trim().toUpperCase()
  if (key === 'PASS' || key === 'READY' || key === 'OK' || key === 'HEALTHY' || key === 'ANCHORED' || key === 'APPROVED') return 'ok'
  if (key === 'PASS_WITH_WARNINGS' || key === 'WARN' || key === 'WARNING' || key === 'LIMITED' || key === 'HOLD' || key === 'REQUEST_MORE_EVIDENCE') return 'warn'
  if (key === 'BLOCKED' || key === 'FAIL' || key === 'ERROR' || key === 'REJECTED') return 'block'
  if (key === 'INFO' || key === 'PENDING' || key === 'ACTIVE' || key === 'ESCALATED') return 'info'
  return 'neutral'
}

export default function Badge({ label, className = '' }: BadgeProps) {
  const tone = normalizeTone(label)
  return <span className={`icaf-badge ${tone} ${className}`.trim()}>{label}</span>
}
