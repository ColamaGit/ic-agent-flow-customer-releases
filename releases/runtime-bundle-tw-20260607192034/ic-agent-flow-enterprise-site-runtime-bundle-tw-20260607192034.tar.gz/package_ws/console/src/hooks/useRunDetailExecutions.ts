import { useEffect, useState } from 'react'
import type { ProductionRunExecution } from './useProductionRunsInventory'

type LayeredRunDetailResponse = {
  schema_version: string
  source_dir: string
  run_id: string
  executions: ProductionRunExecution[]
}

export function useRunDetailExecutions(sourceDir: string, runId: string) {
  const [executions, setExecutions] = useState<ProductionRunExecution[] | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let cancelled = false
    if (!sourceDir || !runId) {
      queueMicrotask(() => {
        if (cancelled) return
        setExecutions(null)
        setLoading(false)
        setError(null)
      })
      return
    }
    queueMicrotask(() => {
      if (cancelled) return
      setLoading(true)
      setError(null)
      setExecutions(null)
    })

    fetch(`/api/portfolio/chips/${encodeURIComponent(sourceDir)}/runs/${encodeURIComponent(runId)}?_ts=${Date.now()}`, {
      cache: 'no-store',
    })
      .then((res) => {
        if (!res.ok) throw new Error(`Failed to load run detail (${res.status})`)
        return res.json()
      })
      .then((json: LayeredRunDetailResponse) => {
        if (cancelled) return
        setExecutions(json.executions ?? [])
      })
      .catch((err) => {
        if (cancelled) return
        setError(err instanceof Error ? err.message : String(err))
        setExecutions(null)
      })
      .finally(() => {
        if (cancelled) return
        setLoading(false)
      })

    return () => {
      cancelled = true
    }
  }, [runId, sourceDir])

  return { executions, loading, error }
}
