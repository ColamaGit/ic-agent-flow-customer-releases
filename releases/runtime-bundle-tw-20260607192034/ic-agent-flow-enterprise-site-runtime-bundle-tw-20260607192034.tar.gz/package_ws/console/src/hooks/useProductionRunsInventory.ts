import { useEffect, useState } from 'react'

export interface ProductionRunExecutionFile {
  relative_path: string
  kind: 'file' | 'dir'
  size_bytes: number
  preview_text?: string | null
  is_virtual?: boolean
  virtual_kind?: 'dashboard_decision_projection'
  projection_source?: 'latest_signoff_status' | 'latest_tapeout_status' | 'latest_silicon_status'
  source_decision_record_ref?: string
  canonical_domain_record_rewritten?: boolean
  projection_generated_from?: 'layered_inventory_l1' | 'layered_inventory_l2' | 'dashboard_decision_action_binding'
}

export interface ProductionRunExecution {
  execution_id: string
  resolved_root: string
  files: ProductionRunExecutionFile[]
  verdict?: 'PASS' | 'WARN' | 'BLOCKED' | 'UNKNOWN'
  evidence_verdict?: 'PASS' | 'WARN' | 'BLOCKED' | 'UNKNOWN'
  decision_disposition?: string
  effective_dashboard_status?: 'PASS' | 'WARN' | 'BLOCKED' | 'UNKNOWN'
  effective_dashboard_status_reason?: string
  technical_evidence_rewritten?: boolean
  file_count?: number
  fail_closed_blockers?: string[]
}

export interface ProductionRunTask {
  run_id: string
  executions: ProductionRunExecution[]
}

export interface ProductionRunChip {
  chip_id: string
  source_dir: string
  runs: ProductionRunTask[]
  verdict_summary?: {
    pass: number
    warn: number
    blocked: number
    unknown: number
    total: number
  }
  evidence_verdict_summary?: {
    pass: number
    warn: number
    blocked: number
    unknown: number
    total: number
  }
  effective_dashboard_summary?: {
    pass: number
    warn: number
    blocked: number
    unknown: number
    total: number
  }
}

export interface ProductionRunsInventory {
  workspace_id: string
  timestamp: string
  chips: ProductionRunChip[]
}

type UseProductionRunsInventoryOptions = {
  layeredSummaryOnly?: boolean
  layeredWithRuns?: boolean
}

type LayeredChipsResponse = {
  schema_version: string
  workspace_id: string
  timestamp: string
  chips: Array<{
    chip_id: string
    source_dir: string
    run_count: number
    latest_run_id?: string | null
    latest_execution_id?: string | null
    verdict_summary?: {
      pass?: number
      warn?: number
      blocked?: number
      unknown?: number
      total?: number
    }
    evidence_verdict_summary?: {
      pass?: number
      warn?: number
      blocked?: number
      unknown?: number
      total?: number
    }
    effective_dashboard_summary?: {
      pass?: number
      warn?: number
      blocked?: number
      unknown?: number
      total?: number
    }
    latest_signoff_status?: string
    latest_tapeout_status?: string
    latest_silicon_status?: string
    latest_execution_fail_closed_blockers?: string[]
  }>
}

type LayeredRunsResponse = {
  schema_version: string
  source_dir: string
  runs: Array<{
    run_id: string
    execution_count: number
    executions: Array<{
      execution_id: string
      resolved_root: string
      file_count: number
      verdict: 'PASS' | 'WARN' | 'BLOCKED' | 'UNKNOWN'
      evidence_verdict?: 'PASS' | 'WARN' | 'BLOCKED' | 'UNKNOWN'
      decision_disposition?: string
      effective_dashboard_status?: 'PASS' | 'WARN' | 'BLOCKED' | 'UNKNOWN'
      effective_dashboard_status_reason?: string
      technical_evidence_rewritten?: boolean
      fail_closed_blockers?: string[]
    }>
  }>
}

function normalizeLayeredToInventory(layered: LayeredChipsResponse): ProductionRunsInventory {
  return {
    workspace_id: layered.workspace_id,
    timestamp: layered.timestamp,
    chips: (layered.chips || []).map((chip) => {
      const runId = chip.latest_run_id ?? ''
      const executionId = chip.latest_execution_id ?? ''

      const virtualFiles: Array<ProductionRunExecutionFile> = []
      if (chip.latest_signoff_status) {
        virtualFiles.push({
          relative_path: '21_dashboard_objects/final_tapeout_readiness_record.json',
          kind: 'file',
          size_bytes: 100,
          preview_text: JSON.stringify({ status: chip.latest_signoff_status }),
          is_virtual: true,
          virtual_kind: 'dashboard_decision_projection',
          projection_source: 'latest_signoff_status',
          source_decision_record_ref: '21_dashboard_objects/downstream_decision_action_binding.json',
          canonical_domain_record_rewritten: false,
          projection_generated_from: 'layered_inventory_l1',
        })
      }
      if (chip.latest_tapeout_status) {
        virtualFiles.push({
          relative_path: '21_dashboard_objects/tapeout_package_manifest.json',
          kind: 'file',
          size_bytes: 100,
          preview_text: JSON.stringify({ status: chip.latest_tapeout_status }),
          is_virtual: true,
          virtual_kind: 'dashboard_decision_projection',
          projection_source: 'latest_tapeout_status',
          source_decision_record_ref: '21_dashboard_objects/downstream_decision_action_binding.json',
          canonical_domain_record_rewritten: false,
          projection_generated_from: 'layered_inventory_l1',
        })
      }
      if (chip.latest_silicon_status) {
        virtualFiles.push({
          relative_path: '21_dashboard_objects/v115_silicon_proven_claim_record.json',
          kind: 'file',
          size_bytes: 100,
          preview_text: JSON.stringify({ status: chip.latest_silicon_status }),
          is_virtual: true,
          virtual_kind: 'dashboard_decision_projection',
          projection_source: 'latest_silicon_status',
          source_decision_record_ref: '21_dashboard_objects/downstream_decision_action_binding.json',
          canonical_domain_record_rewritten: false,
          projection_generated_from: 'layered_inventory_l1',
        })
      }

      return {
        chip_id: chip.chip_id,
        source_dir: chip.source_dir,
        verdict_summary: {
          pass: Number(chip.verdict_summary?.pass ?? 0),
          warn: Number(chip.verdict_summary?.warn ?? 0),
          blocked: Number(chip.verdict_summary?.blocked ?? 0),
          unknown: Number(chip.verdict_summary?.unknown ?? 0),
          total: Number(chip.verdict_summary?.total ?? 0),
        },
        evidence_verdict_summary: {
          pass: Number(chip.evidence_verdict_summary?.pass ?? 0),
          warn: Number(chip.evidence_verdict_summary?.warn ?? 0),
          blocked: Number(chip.evidence_verdict_summary?.blocked ?? 0),
          unknown: Number(chip.evidence_verdict_summary?.unknown ?? 0),
          total: Number(chip.evidence_verdict_summary?.total ?? 0),
        },
        effective_dashboard_summary: {
          pass: Number(chip.effective_dashboard_summary?.pass ?? 0),
          warn: Number(chip.effective_dashboard_summary?.warn ?? 0),
          blocked: Number(chip.effective_dashboard_summary?.blocked ?? 0),
          unknown: Number(chip.effective_dashboard_summary?.unknown ?? 0),
          total: Number(chip.effective_dashboard_summary?.total ?? 0),
        },
        runs: runId
          ? [
              {
                run_id: runId,
                executions: executionId
                  ? [
                      {
                        execution_id: executionId,
                        resolved_root: `artifacts/production-runs/${chip.source_dir}/${runId}/${executionId}`,
                        files: virtualFiles,
                        fail_closed_blockers: chip.latest_execution_fail_closed_blockers ?? [],
                      },
                    ]
                  : [],
              },
            ]
          : [],
      }
    }),
  }
}

export function useProductionRunsInventory(options: UseProductionRunsInventoryOptions = {}) {
  const { layeredSummaryOnly = false, layeredWithRuns = false } = options
  const [data, setData] = useState<ProductionRunsInventory | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [reloadToken, setReloadToken] = useState(0)

  useEffect(() => {
    if (layeredSummaryOnly) {
      fetch(`/api/portfolio/chips?_ts=${Date.now()}`, { cache: 'no-store' })
        .then((res) => {
          if (!res.ok) throw new Error(`Failed to load layered chip summary (${res.status})`)
          return res.json()
        })
        .then((json: LayeredChipsResponse) => {
          setData(normalizeLayeredToInventory(json))
          setLoading(false)
        })
        .catch((err) => {
          setError(err.message)
          setLoading(false)
        })
      return
    }

    if (layeredWithRuns) {
      fetch(`/api/portfolio/chips?_ts=${Date.now()}`, { cache: 'no-store' })
        .then((res) => {
          if (!res.ok) throw new Error(`Failed to load layered chip summary (${res.status})`)
          return res.json()
        })
        .then(async (json: LayeredChipsResponse) => {
          const chipsWithRuns = await Promise.all(
            (json.chips || []).map(async (chip) => {
              try {
                const res = await fetch(`/api/portfolio/chips/${encodeURIComponent(chip.source_dir)}/runs?_ts=${Date.now()}`, {
                  cache: 'no-store',
                })
                if (!res.ok) throw new Error(`Failed to load layered runs (${res.status})`)
                const runJson = (await res.json()) as LayeredRunsResponse
                return {
                  chip_id: chip.chip_id,
                  source_dir: chip.source_dir,
                  verdict_summary: {
                    pass: Number(chip.verdict_summary?.pass ?? 0),
                    warn: Number(chip.verdict_summary?.warn ?? 0),
                    blocked: Number(chip.verdict_summary?.blocked ?? 0),
                    unknown: Number(chip.verdict_summary?.unknown ?? 0),
                    total: Number(chip.verdict_summary?.total ?? 0),
                  },
                  evidence_verdict_summary: {
                    pass: Number(chip.evidence_verdict_summary?.pass ?? 0),
                    warn: Number(chip.evidence_verdict_summary?.warn ?? 0),
                    blocked: Number(chip.evidence_verdict_summary?.blocked ?? 0),
                    unknown: Number(chip.evidence_verdict_summary?.unknown ?? 0),
                    total: Number(chip.evidence_verdict_summary?.total ?? 0),
                  },
                  effective_dashboard_summary: {
                    pass: Number(chip.effective_dashboard_summary?.pass ?? 0),
                    warn: Number(chip.effective_dashboard_summary?.warn ?? 0),
                    blocked: Number(chip.effective_dashboard_summary?.blocked ?? 0),
                    unknown: Number(chip.effective_dashboard_summary?.unknown ?? 0),
                    total: Number(chip.effective_dashboard_summary?.total ?? 0),
                  },
                  runs: (runJson.runs || []).map((run) => ({
                    run_id: run.run_id,
                    executions: (run.executions || []).map((execution) => {
                      const isLatest = chip.latest_execution_id === execution.execution_id
                      const virtualFiles: Array<ProductionRunExecutionFile> = []
                      if (isLatest) {
                        if (chip.latest_signoff_status) {
                          virtualFiles.push({
                            relative_path: '21_dashboard_objects/final_tapeout_readiness_record.json',
                            kind: 'file',
                            size_bytes: 100,
                            preview_text: JSON.stringify({ status: chip.latest_signoff_status }),
                            is_virtual: true,
                            virtual_kind: 'dashboard_decision_projection',
                            projection_source: 'latest_signoff_status',
                            source_decision_record_ref: '21_dashboard_objects/downstream_decision_action_binding.json',
                            canonical_domain_record_rewritten: false,
                            projection_generated_from: 'layered_inventory_l2',
                          })
                        }
                        if (chip.latest_tapeout_status) {
                          virtualFiles.push({
                            relative_path: '21_dashboard_objects/tapeout_package_manifest.json',
                            kind: 'file',
                            size_bytes: 100,
                            preview_text: JSON.stringify({ status: chip.latest_tapeout_status }),
                            is_virtual: true,
                            virtual_kind: 'dashboard_decision_projection',
                            projection_source: 'latest_tapeout_status',
                            source_decision_record_ref: '21_dashboard_objects/downstream_decision_action_binding.json',
                            canonical_domain_record_rewritten: false,
                            projection_generated_from: 'layered_inventory_l2',
                          })
                        }
                        if (chip.latest_silicon_status) {
                          virtualFiles.push({
                            relative_path: '21_dashboard_objects/v115_silicon_proven_claim_record.json',
                            kind: 'file',
                            size_bytes: 100,
                            preview_text: JSON.stringify({ status: chip.latest_silicon_status }),
                            is_virtual: true,
                            virtual_kind: 'dashboard_decision_projection',
                            projection_source: 'latest_silicon_status',
                            source_decision_record_ref: '21_dashboard_objects/downstream_decision_action_binding.json',
                            canonical_domain_record_rewritten: false,
                            projection_generated_from: 'layered_inventory_l2',
                          })
                        }
                      }
                      return {
                        execution_id: execution.execution_id,
                        resolved_root: execution.resolved_root,
                        file_count: execution.file_count,
                        verdict: execution.verdict,
                        evidence_verdict: execution.evidence_verdict,
                        decision_disposition: execution.decision_disposition,
                        effective_dashboard_status: execution.effective_dashboard_status,
                        effective_dashboard_status_reason: execution.effective_dashboard_status_reason,
                        technical_evidence_rewritten: execution.technical_evidence_rewritten,
                        files: virtualFiles,
                        fail_closed_blockers: execution.fail_closed_blockers ?? [],
                      }
                    }),
                  })),
                }
              } catch {
                return {
                  chip_id: chip.chip_id,
                  source_dir: chip.source_dir,
                  verdict_summary: {
                    pass: Number(chip.verdict_summary?.pass ?? 0),
                    warn: Number(chip.verdict_summary?.warn ?? 0),
                    blocked: Number(chip.verdict_summary?.blocked ?? 0),
                    unknown: Number(chip.verdict_summary?.unknown ?? 0),
                    total: Number(chip.verdict_summary?.total ?? 0),
                  },
                  evidence_verdict_summary: {
                    pass: Number(chip.verdict_summary?.pass ?? 0),
                    warn: Number(chip.verdict_summary?.warn ?? 0),
                    blocked: Number(chip.verdict_summary?.blocked ?? 0),
                    unknown: Number(chip.verdict_summary?.unknown ?? 0),
                    total: Number(chip.verdict_summary?.total ?? 0),
                  },
                  effective_dashboard_summary: {
                    pass: Number(chip.verdict_summary?.pass ?? 0),
                    warn: Number(chip.verdict_summary?.warn ?? 0),
                    blocked: Number(chip.verdict_summary?.blocked ?? 0),
                    unknown: Number(chip.verdict_summary?.unknown ?? 0),
                    total: Number(chip.verdict_summary?.total ?? 0),
                  },
                  runs: [],
                }
              }
            }),
          )
          setData({
            workspace_id: json.workspace_id,
            timestamp: json.timestamp,
            chips: chipsWithRuns,
          })
          setLoading(false)
        })
        .catch((err) => {
          setError(err.message)
          setLoading(false)
        })
      return
    }

    fetch(`/portfolio/summaries/production_runs_inventory.json?_ts=${Date.now()}`, { cache: 'no-store' })
      .then((res) => {
        if (!res.ok) throw new Error(`Failed to load production-runs inventory (${res.status})`)
        return res.json()
      })
      .then((json: ProductionRunsInventory) => {
        setData(json)
        setLoading(false)
      })
      .catch((err) => {
        setError(err.message)
        setLoading(false)
      })
  }, [layeredSummaryOnly, layeredWithRuns, reloadToken])

  const reload = () => setReloadToken((x) => x + 1)
  return { data, loading, error, reload }
}
