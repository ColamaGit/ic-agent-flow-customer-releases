import { useState, useEffect } from 'react'
import type { ProductionRunsInventory } from './useProductionRunsInventory'
import { sortChipsForMode, type OperatingMode } from './evidenceSummary'

export interface PortfolioChip {
  chip_id: string
  phase: string
  verification: string
  readiness: string
  updated_at: string
  source_dir?: string
  task_count?: number
  latest_task_id?: string | null
  latest_run_id?: string | null
  resolved_root?: string
}

export interface PortfolioData {
  workspace_id: string
  timestamp: string
  chip_count: number
  chips: PortfolioChip[]
}

interface LayeredChipSummary {
  chip_id: string
  source_dir: string
  run_count: number
  latest_run_id?: string | null
  latest_execution_id?: string | null
}

interface LayeredChipsResponse {
  schema_version: string
  workspace_id: string
  timestamp: string
  chip_count: number
  chips: LayeredChipSummary[]
}

function filterByMode(chips: PortfolioChip[], mode: OperatingMode) {
  return sortChipsForMode(chips, mode)
}

function toPortfolioFromInventory(inventory: ProductionRunsInventory): PortfolioData {
  const chips: PortfolioChip[] = (inventory.chips || []).map((chip) => {
    const runCount = chip.runs.length
    const latestRun = chip.runs[runCount - 1]
    const latestExec = latestRun?.executions[latestRun.executions.length - 1]
    return {
      chip_id: chip.chip_id,
      source_dir: chip.source_dir,
      phase: 'Production Runs',
      verification: runCount > 0 ? 'Observed' : 'Pending',
      readiness: runCount > 0 ? 'N/A' : 'Unknown',
      updated_at: inventory.timestamp,
      task_count: runCount,
      latest_task_id: latestRun?.run_id ?? null,
      latest_run_id: latestExec?.execution_id ?? null,
      resolved_root: latestExec?.resolved_root ?? `artifacts/production-runs/${chip.source_dir}`,
    }
  })
  return {
    workspace_id: inventory.workspace_id,
    timestamp: inventory.timestamp,
    chip_count: chips.length,
    chips,
  }
}

function toPortfolioFromLayeredChips(layered: LayeredChipsResponse): PortfolioData {
  const chips: PortfolioChip[] = (layered.chips || []).map((chip) => ({
    chip_id: chip.chip_id,
    source_dir: chip.source_dir,
    phase: 'Production Runs',
    verification: chip.run_count > 0 ? 'Observed' : 'Pending',
    readiness: chip.run_count > 0 ? 'N/A' : 'Unknown',
    updated_at: layered.timestamp,
    task_count: chip.run_count,
    latest_task_id: chip.latest_run_id ?? null,
    latest_run_id: chip.latest_execution_id ?? null,
    resolved_root: `artifacts/production-runs/${chip.source_dir}`,
  }))
  return {
    workspace_id: layered.workspace_id,
    timestamp: layered.timestamp,
    chip_count: chips.length,
    chips,
  }
}

export function usePortfolioData(mode: OperatingMode = 'team_project') {
  const [data, setData] = useState<PortfolioData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    // Bridged path via /public/portfolio symlink.
    // Prefer production-runs inventory generated from artifacts/production-runs.
    const layeredPreferred = '/api/portfolio/chips'
    const preferred = '/portfolio/summaries/production_runs_inventory.json'
    const fallback = '/portfolio/summaries/portfolio_status.json'

    fetch(layeredPreferred)
      .then((res) => {
        if (!res.ok) throw new Error('Failed to load layered chip inventory')
        return res.json()
      })
      .then((json: LayeredChipsResponse) => {
        if (!json?.schema_version?.startsWith('production-runs-layer1-chips')) {
          throw new Error('invalid layered chip inventory')
        }
        return toPortfolioFromLayeredChips(json)
      })
      .catch(() =>
        fetch(preferred)
          .then((res) => {
            if (!res.ok) throw new Error('Failed to load production-runs inventory')
            return res.json()
          })
          .then((json: ProductionRunsInventory) => toPortfolioFromInventory(json)),
      )
      .catch(() => fetch(fallback).then((res) => {
        if (!res.ok) throw new Error('Failed to load Portfolio Registry')
        return res.json()
      }))
      .then((json: PortfolioData) => {
        const normalized = json
        const filtered = filterByMode(normalized.chips || [], mode)
        setData({
          ...normalized,
          chip_count: filtered.length,
          chips: filtered,
        })
        setLoading(false)
      })
      .catch((err) => {
        setError(err.message)
        setLoading(false)
      })
  }, [mode])

  return { data, loading, error }
}
