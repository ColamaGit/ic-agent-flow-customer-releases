import { useState, useEffect } from 'react'
import type { BundleData, PortfolioData } from '../types/governance'

function parseLooseYaml(text: string): Record<string, unknown> {
  const obj: Record<string, unknown> = {}
  for (const rawLine of text.split('\n')) {
    const line = rawLine.trim()
    if (!line || line.startsWith('#')) continue
    const idx = line.indexOf(':')
    if (idx <= 0) continue
    const key = line.slice(0, idx).trim()
    const value = line.slice(idx + 1).trim()
    obj[key] = value
  }
  return obj
}

function normalizeManifest(bundleId: string, payload: Record<string, unknown>) {
  const phase = String(payload.phase_state ?? payload.phase ?? 'Initialization')
  const verification = String(payload.verification_state ?? payload.verification ?? 'Pending')
  const readiness = String(payload.readiness_state ?? payload.readiness ?? 'Unknown')
  return {
    metadata: {
      name: String(payload.chip_name ?? payload.chip_id ?? bundleId),
      version: String(payload.chip_program_version ?? 'v0.1.0'),
    },
    phase,
    verification,
    readiness,
    evidence_registry: {},
  }
}

export function useBundleData(bundleId: string) {
  const [data, setData] = useState<BundleData & PortfolioData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    // Bridged path via /public/chips symlink
    const fileToFetch = bundleId === 'latest' 
        ? '/portfolio/summaries/portfolio_status.json' 
        : `/chips/${bundleId}/chip_program_manifest.yaml`
    
    fetch(fileToFetch)
      .then(async (res) => {
        if (!res.ok) throw new Error(`Failed to load Evidence Bundle (${res.status})`)
        const text = await res.text()
        if (text.trimStart().startsWith('<!doctype') || text.trimStart().startsWith('<html')) {
          throw new Error(`Invalid bundle reference '${bundleId}' (received HTML fallback)`)
        }
        try {
          const json = JSON.parse(text) as Record<string, unknown>
          return normalizeManifest(bundleId, json)
        } catch {
          const yamlObj = parseLooseYaml(text)
          if (Object.keys(yamlObj).length === 0) {
            throw new Error(`Unsupported bundle manifest format for '${bundleId}'`)
          }
          return normalizeManifest(bundleId, yamlObj)
        }
      })
      .then((normalized) => {
        setData(normalized as BundleData & PortfolioData)
        setLoading(false)
      })
      .catch(err => {
        setError(err.message)
        setLoading(false)
      })
  }, [bundleId])

  return { data, loading, error }
}
