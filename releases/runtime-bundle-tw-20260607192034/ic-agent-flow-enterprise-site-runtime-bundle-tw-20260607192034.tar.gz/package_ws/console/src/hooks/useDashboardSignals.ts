import { useMemo } from 'react'
import { useProductionRunsInventory } from './useProductionRunsInventory'

export type CardGateStatus = 'PASS' | 'PASS_WITH_WARNINGS' | 'BLOCKED' | 'PENDING'

export type DashboardSignals = {
  package: { status: CardGateStatus; blockers: number }
  decision: { status: CardGateStatus; blockers: number }
  flow: { status: CardGateStatus; blockers: number }
  evidence: { status: CardGateStatus; blockers: number }
}

const DEFAULT_SIGNALS: DashboardSignals = {
  package: { status: 'PENDING', blockers: 0 },
  decision: { status: 'PENDING', blockers: 0 },
  flow: { status: 'PENDING', blockers: 0 },
  evidence: { status: 'PENDING', blockers: 0 },
}

/**
 * useDashboardSignals
 *
 * Wave-2 refactor (2026-05-27): previously depended on /dashboard/v1.7/*.json
 * static files that were never generated and never placed in public/.
 * Now derives all gate signals directly from the live layered inventory
 * endpoint (/api/portfolio/chips) which is always up-to-date.
 *
 * Signal mapping:
 *  - flow / evidence / package: BLOCKED if any blocked exec, PASS_WITH_WARNINGS
 *    if any unknown, PASS otherwise.
 *  - decision: PASS if 0 blockers, PENDING if 1-2, BLOCKED if >2.
 *
 * The `mode` parameter is preserved in the signature for API compatibility;
 * signals currently reflect the global portfolio (all chips, all modes).
 */
export function useDashboardSignals(mode: 'solo_eval' | 'team_project' | 'enterprise_site') {
  // Suppress unused-var lint for mode — kept for callers' API stability
  void mode

  const { data: inventory, loading } = useProductionRunsInventory({ layeredSummaryOnly: true })

  const signals: DashboardSignals = useMemo(() => {
    if (!inventory || inventory.chips.length === 0) return DEFAULT_SIGNALS

    const totals = inventory.chips.reduce(
      (acc, chip) => ({
        pass: acc.pass + Number(chip.verdict_summary?.pass ?? 0),
        warn: acc.warn + Number(chip.verdict_summary?.warn ?? 0),
        blocked: acc.blocked + Number(chip.verdict_summary?.blocked ?? 0),
        unknown: acc.unknown + Number(chip.verdict_summary?.unknown ?? 0),
      }),
      { pass: 0, warn: 0, blocked: 0, unknown: 0 }
    )

    const totalBlocked = totals.blocked
    const totalUnknown = totals.unknown

    const flowStatus: CardGateStatus =
      totalBlocked > 0 ? 'BLOCKED' : totalUnknown > 0 ? 'PASS_WITH_WARNINGS' : 'PASS'

    const evidenceStatus: CardGateStatus =
      totalBlocked > 0 ? 'BLOCKED' : totalUnknown > 0 ? 'PASS_WITH_WARNINGS' : 'PASS'

    const decisionBlockers = totalBlocked
    const decisionStatus: CardGateStatus =
      decisionBlockers === 0 ? 'PASS' : decisionBlockers <= 2 ? 'PENDING' : 'BLOCKED'

    const packageStatus: CardGateStatus =
      totalBlocked > 0 ? 'BLOCKED' : totalUnknown > 0 ? 'PASS_WITH_WARNINGS' : 'PASS'

    return {
      package: { status: packageStatus, blockers: totalBlocked },
      decision: { status: decisionStatus, blockers: decisionBlockers },
      flow: { status: flowStatus, blockers: totalBlocked + totalUnknown },
      evidence: { status: evidenceStatus, blockers: totalBlocked },
    }
  }, [inventory])

  return { signals, loading }
}
