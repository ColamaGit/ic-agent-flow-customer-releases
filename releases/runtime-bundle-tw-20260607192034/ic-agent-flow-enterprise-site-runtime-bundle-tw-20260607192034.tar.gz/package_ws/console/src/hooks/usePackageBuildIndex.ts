import { useEffect, useState } from 'react'

export type PackageBuildRow = {
  build_id: string
  build_timestamp: string
  bundle_id?: string
  package_name: string
  package_variant: string
  runtime_delivery_mode: string
  source_disclosure_mode: string
  release_artifact_class: string
  build_verdict: string
  release_claim: string
  package_artifact_ref: string
  audit_record_ref: string
  customer_safe_manifest_ref: string
  source_leak_scan_verdict: string
  internal_path_leak_scan_verdict: string
  signature_verdict: string
  extract_validation_verdict: string
  created_by?: string
  git_ref?: string
  notes?: string[]
}

export type PackageBuildIndex = {
  schema_version: string
  generated_at: string
  builds: PackageBuildRow[]
}

const CANDIDATE_PATHS = [
  '/portfolio/summaries/package-builds/package_build_index.json',
  '/artifacts/package-builds/package_build_index.json',
]

export function usePackageBuildIndex() {
  const [data, setData] = useState<PackageBuildIndex | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let cancelled = false
    ;(async () => {
      for (const path of CANDIDATE_PATHS) {
        try {
          const res = await fetch(path)
          if (!res.ok) continue
          const payload = (await res.json()) as PackageBuildIndex
          if (!payload || !Array.isArray(payload.builds)) continue
          if (!cancelled) {
            setData(payload)
            setLoading(false)
            setError(null)
          }
          return
        } catch {
          // try next
        }
      }
      if (!cancelled) {
        setError('Failed to load package_build_index.json')
        setLoading(false)
      }
    })()
    return () => {
      cancelled = true
    }
  }, [])

  return { data, loading, error }
}
