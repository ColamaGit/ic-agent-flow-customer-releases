import { useEffect, useState } from 'react'

export type CustomerPackageFolderRow = {
  bundle_id: string
  folder_ref: string
  gz_files: string[]
}

export type CustomerPackageFoldersIndex = {
  schema_version: string
  generated_at: string
  bundles: CustomerPackageFolderRow[]
}

const CANDIDATE_PATHS = [
  '/portfolio/summaries/package-builds/customer_package_folders_selectable_index.json',
  '/artifacts/package-builds/customer_package_folders_selectable_index.json',
  '/portfolio/summaries/package-builds/customer_package_folders_index.json',
  '/artifacts/package-builds/customer_package_folders_index.json',
]

export function useCustomerPackageFolders() {
  const [data, setData] = useState<CustomerPackageFoldersIndex | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let cancelled = false
    ;(async () => {
      for (const path of CANDIDATE_PATHS) {
        try {
          const res = await fetch(path)
          if (!res.ok) continue
          const payload = (await res.json()) as CustomerPackageFoldersIndex
          if (!payload || !Array.isArray(payload.bundles)) continue
          if (!cancelled) {
            setData(payload)
            setError(null)
            setLoading(false)
          }
          return
        } catch {
          // continue
        }
      }
      if (!cancelled) {
        setError('Failed to load customer_package_folders_index.json')
        setLoading(false)
      }
    })()
    return () => {
      cancelled = true
    }
  }, [])

  return { data, loading, error }
}
