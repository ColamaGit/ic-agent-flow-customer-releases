import type { ProductionRunChip, ProductionRunExecution, ProductionRunExecutionFile, ProductionRunsInventory } from './useProductionRunsInventory'

export type OperatingMode = 'solo_eval' | 'team_project' | 'enterprise_site'
export type Verdict = 'PASS' | 'WARN' | 'BLOCKED' | 'UNKNOWN'
type ChipLike = { chip_id: string }

export type ExecutionRef = {
  chip_id: string
  run_id: string
  execution_id: string
  execution: ProductionRunExecution
}

export function parseMode(search: string): OperatingMode {
  const params = new URLSearchParams(search)
  const candidate = params.get('mode')
  if (candidate === 'solo_eval' || candidate === 'enterprise_site') return candidate
  return 'team_project'
}

export function modeSeedChipOrder(mode: OperatingMode): string[] {
  if (mode === 'solo_eval') return ['SN2025']
  if (mode === 'enterprise_site') return ['SN2025', 'UART', 'ASYNC_FIFO']
  return ['SN2025', 'UART']
}

export function sortChipsForMode<T extends ChipLike>(chips: T[], mode: OperatingMode): T[] {
  const preferredOrder = modeSeedChipOrder(mode)
  const orderIndex = new Map(preferredOrder.map((chipId, idx) => [chipId, idx]))
  return [...chips].sort((a, b) => {
    const aRank = orderIndex.get(a.chip_id) ?? Number.MAX_SAFE_INTEGER
    const bRank = orderIndex.get(b.chip_id) ?? Number.MAX_SAFE_INTEGER
    if (aRank !== bRank) return aRank - bRank
    return a.chip_id.localeCompare(b.chip_id)
  })
}

export function scopedChips(inventory: ProductionRunsInventory | null, mode: OperatingMode): ProductionRunChip[] {
  if (!inventory?.chips) return []
  return sortChipsForMode(inventory.chips, mode)
}

export function parseNormalizedStatuses(files: ProductionRunExecutionFile[]): Array<{ relativePath: string; status: string }> {
  const statuses: Array<{ relativePath: string; status: string }> = []
  for (const file of files) {
    if (file.kind !== 'file') continue
    if (!/normalized\..*\.json$/i.test(file.relative_path)) continue
    const preview = file.preview_text ?? ''
    if (!preview.trim().startsWith('{')) continue
    try {
      const parsed = JSON.parse(preview) as { status?: string }
      if (parsed.status) statuses.push({ relativePath: file.relative_path, status: String(parsed.status).toUpperCase() })
    } catch {
      // ignore invalid preview json
    }
  }
  return statuses
}

export function classifyExecution(files: ProductionRunExecutionFile[]): Verdict {
  const statuses = parseNormalizedStatuses(files).map((s) => s.status)
  let passTokenInLog = false
  for (const file of files) {
    if (file.kind !== 'file') continue
    const preview = file.preview_text ?? ''
    if (/raw\.log$/i.test(file.relative_path) && /REAL_RUN_PASS|_PASS\b| PASS\b/i.test(preview)) {
      passTokenInLog = true
      break
    }
  }
  if (statuses.some((s) => ['FAIL', 'BLOCKED', 'ERROR'].includes(s))) return 'BLOCKED'
  if (statuses.some((s) => ['NOT_CHECKED', 'WARNING', 'WARN', 'PENDING', 'UNVALIDATED', 'PARTIAL'].includes(s))) return 'WARN'
  if (statuses.some((s) => ['PASS', 'OK', 'DONE'].includes(s)) || passTokenInLog) return 'PASS'
  return 'UNKNOWN'
}

export function flattenExecutions(chips: ProductionRunChip[]): ExecutionRef[] {
  const rows: ExecutionRef[] = []
  for (const chip of chips) {
    for (const run of chip.runs) {
      for (const execution of run.executions) {
        rows.push({ chip_id: chip.chip_id, run_id: run.run_id, execution_id: execution.execution_id, execution })
      }
    }
  }
  return rows.sort((a, b) => b.execution_id.localeCompare(a.execution_id))
}

export function summarizeVerdicts(rows: ExecutionRef[]) {
  let pass = 0
  let warn = 0
  let blocked = 0
  let unknown = 0
  for (const row of rows) {
    const v = classifyExecution(row.execution.files)
    if (v === 'PASS') pass += 1
    else if (v === 'WARN') warn += 1
    else if (v === 'BLOCKED') blocked += 1
    else unknown += 1
  }
  return { pass, warn, blocked, unknown, total: pass + warn + blocked + unknown }
}

export function resolveExecution(rows: ExecutionRef[], chip?: string, run?: string, execution?: string): ExecutionRef | null {
  if (chip && run && execution) {
    const exact = rows.find((r) => r.chip_id === chip && r.run_id === run && r.execution_id === execution)
    if (exact) return exact
  }
  return rows[0] ?? null
}
