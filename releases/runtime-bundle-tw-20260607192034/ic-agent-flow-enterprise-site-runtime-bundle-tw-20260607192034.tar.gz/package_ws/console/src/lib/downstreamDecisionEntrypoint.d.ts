export type DownstreamDecisionEntrypointInput = {
  sessionId: string
  actorId: string
  role: string
  chipId: string
  runId: string
  dateTime: string
  gateFamily: string
  actionName: string
  targetObjectRefs: string[]
  sourceEvidenceRefs: string[]
  formalObjectRefs: string[]
  readinessStatus?: 'EVIDENCE_READY' | 'WARN' | 'BLOCKED'
  decisionStatus?: 'PENDING' | 'APPROVED' | 'REJECTED' | 'HOLD' | 'REQUEST_MORE_EVIDENCE'
}

export type DownstreamDecisionEntrypoint = {
  entrypointId: string
  backendBindingState: 'UNBOUND' | 'BOUND'
  liveSubmissionEnabled: boolean
  readinessDimension: 'EVIDENCE_READY' | 'WARN' | 'BLOCKED'
  decisionDimension: 'PENDING' | 'APPROVED' | 'REJECTED' | 'HOLD' | 'REQUEST_MORE_EVIDENCE'
  decisionContextRef: string
  allowedSubmissionActions: string[]
  actionRequest: {
    action_request_id: string
    type: 'dashboard_action_request'
    schema_version: '1.8.0'
    session_id: string
    action_name: string
    actor_id: string
    role: string
    target_object_refs: string[]
    source_evidence_refs: string[]
    decision_context_ref: string
    requested_at: string
  }
  formalObjectRefs: string[]
  submissionHint: string
}

export declare function buildDownstreamDecisionActionEntrypoint(
  input: DownstreamDecisionEntrypointInput,
): DownstreamDecisionEntrypoint
