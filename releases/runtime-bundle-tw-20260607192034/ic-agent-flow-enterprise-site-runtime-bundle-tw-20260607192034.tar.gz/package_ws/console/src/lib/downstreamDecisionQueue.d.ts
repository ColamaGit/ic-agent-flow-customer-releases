export type DownstreamGateLike = {
  formalDecisionRef?: string
}

export type DownstreamDecisionFileLike = {
  kind: 'file' | 'dir'
  relative_path: string
  preview_text?: string | null
}

export type FormalDecisionQueueItemLike = {
  formal_decision_ref?: string
  decision_type?: string
  status?: string
}

export type FormalDecisionQueueLike = {
  queue_id?: string | null
  dashboard_version?: string | null
  items?: FormalDecisionQueueItemLike[]
}

export declare function readFormalDecisionQueue(files: DownstreamDecisionFileLike[]): FormalDecisionQueueLike | null
export declare function resolveDecisionStatusFromFormalQueue(
  gate: DownstreamGateLike,
  files: DownstreamDecisionFileLike[],
): 'PENDING' | 'APPROVED' | 'REJECTED' | 'HOLD' | 'REQUEST_MORE_EVIDENCE'
export declare function getGateFormalDecisionRef(
  gateFamily: string,
): string | null
