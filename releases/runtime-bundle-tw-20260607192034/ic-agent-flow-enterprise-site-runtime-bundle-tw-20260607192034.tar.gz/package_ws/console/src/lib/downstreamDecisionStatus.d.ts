export type EvidenceStatus = 'PASS' | 'PASS_WITH_WARNINGS' | 'BLOCKED' | 'MISSING' | 'STALE'
export type GateStatus = 'PASS' | 'PASS_WITH_WARNINGS' | 'BLOCKED' | 'NOT_APPLICABLE'
export type DecisionStatus = 'NOT_REQUESTED' | 'PENDING' | 'APPROVED' | 'APPROVED_WITH_CONDITIONS' | 'HELD' | 'REJECTED' | 'MORE_EVIDENCE_REQUESTED' | 'HOLD' | 'REQUEST_MORE_EVIDENCE'
export type AuthorityStatus = 'OPEN' | 'CLOSED' | 'BLOCKED' | 'NOT_REQUIRED'

export type DecisionState = {
  evidence_status: EvidenceStatus
  gate_status: GateStatus
  decision_status: DecisionStatus
  authority_status: AuthorityStatus
}

export function mapReadinessToEvidenceStatus(readinessStatus: string): EvidenceStatus
export function mapReadinessToGateStatus(readinessStatus: string): GateStatus
export function resolveAuthorityStatus(input: {
  backendBindingState?: string
  liveSubmissionEnabled?: boolean
  decisionStatus?: string
}): AuthorityStatus
export function buildDecisionState(input: {
  readinessStatus?: string
  decisionStatus?: string
  backendBindingState?: string
  liveSubmissionEnabled?: boolean
}): DecisionState
