import type { OperatingMode } from '../hooks/evidenceSummary'
import { scopedChips } from '../hooks/evidenceSummary'
import type { ProductionRunChip, ProductionRunExecutionFile, ProductionRunsInventory } from '../hooks/useProductionRunsInventory'

export type AssetContext = 'development_repo' | 'customer_side_repo' | 'shared_packs'

export type ScopeClass =
  | 'CHIP_BOUND'
  | 'PROJECT_BOUND'
  | 'PLATFORM_LINE'
  | 'RELEASE_LINE'
  | 'CUSTOMER_SITE'
  | 'CROSS_LINE'
  | 'NOT_FLOW_BOUND'
  | 'UNKNOWN'

export type ChipBindingMode =
  | 'specific_chip'
  | 'chip_set'
  | 'all_supported_chips'
  | 'not_chip_bound'

export type SourceOccurrence = {
  chip_id: string
  run_id: string
  execution_id: string
  source_dir: string
  registry_ref: string
  manifest_ref: string
}

export type KnowledgeAssetRow = {
  // Identity
  asset_id: string
  asset_identity_key: string
  registry_id: string
  registry_ref: string
  asset_type: string
  asset_family: string

  // Scope & chip binding
  scope_level: string
  scope_class: ScopeClass
  flow_scope: string[]
  chip_binding_mode: ChipBindingMode
  applies_to_chips: string[]
  chip_set: string[]

  // Context (derived from scope + promotion)
  context: AssetContext

  // Provenance (canonical from first / representative occurrence)
  chip_id: string
  source_dir: string
  run_id: string
  execution_id: string
  source_run_ref: string
  manifest_ref: string

  // Evidence & alignment (from representative occurrence)
  alignment_status: string
  execution_handoff_status: string
  canonical_registry_refs: string[]
  non_canonical_notice: boolean

  // Classification
  source_event_type: string
  asset_origin_class: string
  priority_class: string
  source_fix_ref: string
  consumption_targets: string[]
  release_eligibility: Record<string, unknown>

  // Lifecycle
  promotion_status: string
  promotion_recommendation: string
  authority_line: string

  // Content
  summary: string
  reusable_lesson: string[]

  // Evidence refs (union from all occurrences)
  source_event_refs: string[]
  evidence_refs: string[]
  chip_evidence_refs: string[]

  // Source occurrences (full list from all chips/runs)
  source_occurrences: SourceOccurrence[]
  occurrence_count: number

  notes: string
}

// Aggregated inventory stats (computed from all rows, not just filtered)
export type KnowledgeInventoryStats = {
  unique_asset_count: number
  total_source_occurrences: number
  chip_bound_count: number
  platform_line_count: number
  release_line_count: number
  cross_line_count: number
  not_flow_bound_count: number
  chip_occurrence_map: Record<string, { occurrences: number; asset_ids: Set<string> }>
}

type ParsedAlignmentManifest = {
  type?: string
  alignment_status?: string
  execution_handoff_status?: string
  canonical_registry_refs?: string[]
  non_canonical_notice?: boolean
}

type ParsedAlignmentRow = {
  registry_id?: string
  registry_ref?: string
  asset_id?: string
  asset_type?: string
  asset_family?: string
  scope_level?: string
  source_event_type?: string
  flow_scope?: string[] | string
  asset_origin_class?: string
  priority_class?: string
  source_fix_ref?: string
  consumption_targets?: string[] | string
  release_eligibility?: Record<string, unknown>
  promotion_status?: string
  promotion_recommendation?: string
  authority_line?: string
  summary?: string
  reusable_lesson?: string[]
  source_event_refs?: string[]
  evidence_refs?: string[]
  chip_evidence_refs?: string[]
  chip_set?: string[]
  notes?: string
}

type ParsedAlignmentMapping = {
  type?: string
  scope?: {
    chip_id?: string
    run_id?: string
    execution?: string
  }
  rows?: ParsedAlignmentRow[]
}

function normalizeSequencePath(path: string) {
  const segs = path.split('/')
  if (segs.length === 0) return path
  segs[0] = segs[0].replace(/^\d+_/, '')
  return segs.join('/')
}

function findPreviewJson<T>(files: ProductionRunExecutionFile[], logicalPath: string): { filePath: string; data: T } | null {
  const found = files.find((file) => file.kind === 'file' && normalizeSequencePath(file.relative_path) === logicalPath)
  if (!found?.preview_text) return null
  try {
    return { filePath: found.relative_path, data: JSON.parse(found.preview_text) as T }
  } catch {
    return null
  }
}

function deriveContext(scopeLevel: string, promotionStatus: string): AssetContext {
  const normalizedScope = scopeLevel.toLowerCase()
  const normalizedPromotion = promotionStatus.toLowerCase()
  if (normalizedScope.includes('customer')) return 'customer_side_repo'
  if (normalizedScope.includes('shared') || normalizedPromotion.includes('shared') || normalizedPromotion.includes('promoted')) {
    return 'shared_packs'
  }
  return 'development_repo'
}

/**
 * Derive scope_class from flow_scope array.
 * Priority: CHIP_BOUND > specific chip scope > PLATFORM_LINE > RELEASE_LINE > CROSS_LINE > NOT_FLOW_BOUND
 */
function deriveScopeClass(flowScope: string[]): ScopeClass {
  if (!flowScope || flowScope.length === 0) return 'NOT_FLOW_BOUND'
  const scopes = flowScope.map((s) => s.toUpperCase())
  if (scopes.some((s) => s === 'CHIP_BOUND')) return 'CHIP_BOUND'
  if (scopes.some((s) => s === 'PROJECT_BOUND')) return 'PROJECT_BOUND'
  if (scopes.some((s) => s === 'CUSTOMER_SITE')) return 'CUSTOMER_SITE'
  if (scopes.some((s) => s === 'PLATFORM_LINE')) return 'PLATFORM_LINE'
  if (scopes.some((s) => s === 'RELEASE_LINE')) return 'RELEASE_LINE'
  if (scopes.some((s) => s === 'CROSS_LINE')) return 'CROSS_LINE'
  if (scopes.some((s) => s === 'NOT_FLOW_BOUND')) return 'NOT_FLOW_BOUND'
  // has flow scope values but none match known classes → treat as chip-context unknown
  return 'CHIP_BOUND'
}

/**
 * Derive chip binding mode from scope_class and chip_set size.
 */
function deriveChipBindingMode(scopeClass: ScopeClass, chipSet: string[]): ChipBindingMode {
  if (scopeClass === 'NOT_FLOW_BOUND' || scopeClass === 'PLATFORM_LINE' || scopeClass === 'RELEASE_LINE' || scopeClass === 'CROSS_LINE') {
    return 'not_chip_bound'
  }
  if (scopeClass === 'CUSTOMER_SITE') return 'not_chip_bound'
  if (chipSet.length === 0) return 'specific_chip'
  if (chipSet.length === 1) return 'specific_chip'
  // chip_set has multiple entries → could be chip_set or all_supported
  return 'chip_set'
}

function normalizeStringList(value: string[] | string | undefined): string[] {
  if (Array.isArray(value)) return value.map((item) => String(item).trim()).filter(Boolean)
  if (typeof value === 'string' && value.trim()) return [value.trim()]
  return []
}

function latestKnowledgeExecution(chip: ProductionRunChip) {
  const executions: Array<{
    run_id: string
    execution_id: string
    files: ProductionRunExecutionFile[]
  }> = []

  for (const run of chip.runs) {
    for (const execution of run.executions) {
      executions.push({
        run_id: run.run_id,
        execution_id: execution.execution_id,
        files: execution.files ?? [],
      })
    }
  }

  executions.sort((a, b) => {
    const byExecution = b.execution_id.localeCompare(a.execution_id)
    if (byExecution !== 0) return byExecution
    return b.run_id.localeCompare(a.run_id)
  })

  for (const execution of executions) {
    const manifest = findPreviewJson<ParsedAlignmentManifest>(execution.files, 'reports/knowledge_backflow_alignment_manifest.v1.1_v1.2.json')
    const mapping = findPreviewJson<ParsedAlignmentMapping>(execution.files, 'reports/knowledge_backflow_alignment_mapping.v1.1_v1.2.json')
    if (manifest && mapping?.data.rows && mapping.data.rows.length > 0) {
      return { execution, manifest, mapping }
    }
  }

  return null
}

/**
 * Compute the asset identity key for deduplication.
 * For non-chip-bound assets: identity is asset_id alone.
 * For chip-bound assets: identity is asset_id + chip_id (per-chip).
 */
function assetIdentityKey(assetId: string, chipId: string, scopeClass: ScopeClass): string {
  if (scopeClass === 'NOT_FLOW_BOUND' || scopeClass === 'PLATFORM_LINE' || scopeClass === 'RELEASE_LINE' || scopeClass === 'CROSS_LINE') {
    return assetId
  }
  if (scopeClass === 'CUSTOMER_SITE' || scopeClass === 'PROJECT_BOUND') {
    return assetId
  }
  // CHIP_BOUND or UNKNOWN → per-chip identity
  return `${assetId}::${chipId}`
}

export function extractKnowledgeAssetRows(inventory: ProductionRunsInventory | null, mode: OperatingMode): KnowledgeAssetRow[] {
  const chips = scopedChips(inventory, mode)

  // Map from identity_key → KnowledgeAssetRow (for dedup)
  const assetMap = new Map<string, KnowledgeAssetRow>()

  for (const chip of chips) {
    const latest = latestKnowledgeExecution(chip)
    if (!latest) continue

    const { execution, manifest, mapping } = latest
    const scope = mapping.data.scope ?? {}
    const runId = String(scope.run_id ?? execution.run_id)
    const executionId = String(scope.execution ?? execution.execution_id)
    const sourceRunRef = `artifacts/production-runs/${chip.source_dir}/${runId}/${executionId}`

    for (const row of mapping.data.rows ?? []) {
      const assetId = String(row.asset_id ?? '').trim()
      const registryId = String(row.registry_id ?? '').trim()
      if (!assetId || !registryId) continue

      const scopeLevel = String(row.scope_level ?? 'unknown')
      const promotionStatus = String(row.promotion_status ?? 'candidate')
      const flowScope = normalizeStringList(row.flow_scope)
      const chipSet = Array.isArray(row.chip_set) ? row.chip_set.map((s) => String(s)) : []

      const scopeClass = deriveScopeClass(flowScope)
      const chipBindingMode = deriveChipBindingMode(scopeClass, chipSet)
      const identityKey = assetIdentityKey(assetId, chip.chip_id, scopeClass)

      const occurrence: SourceOccurrence = {
        chip_id: chip.chip_id,
        run_id: runId,
        execution_id: executionId,
        source_dir: chip.source_dir,
        registry_ref: String(row.registry_ref ?? ''),
        manifest_ref: manifest.filePath,
      }

      if (assetMap.has(identityKey)) {
        // Merge occurrence into existing row
        const existing = assetMap.get(identityKey)!
        existing.source_occurrences.push(occurrence)
        existing.occurrence_count += 1
        // Union evidence refs
        for (const ref of Array.isArray(row.source_event_refs) ? row.source_event_refs.map(String) : []) {
          if (!existing.source_event_refs.includes(ref)) existing.source_event_refs.push(ref)
        }
        for (const ref of Array.isArray(row.evidence_refs) ? row.evidence_refs.map(String) : []) {
          if (!existing.evidence_refs.includes(ref)) existing.evidence_refs.push(ref)
        }
        for (const ref of Array.isArray(row.chip_evidence_refs) ? row.chip_evidence_refs.map(String) : []) {
          if (!existing.chip_evidence_refs.includes(ref)) existing.chip_evidence_refs.push(ref)
        }
        // Track chip applicability
        if (!existing.applies_to_chips.includes(chip.chip_id)) {
          existing.applies_to_chips.push(chip.chip_id)
        }
      } else {
        // First occurrence → create canonical row
        const context = deriveContext(scopeLevel, promotionStatus)
        const appliesTo = chipBindingMode === 'not_chip_bound' ? [] : [chip.chip_id]

        assetMap.set(identityKey, {
          asset_id: assetId,
          asset_identity_key: identityKey,
          registry_id: registryId,
          registry_ref: String(row.registry_ref ?? ''),
          asset_type: String(row.asset_type ?? 'candidate_knowledge_asset'),
          asset_family: String(row.asset_family ?? 'unknown'),

          scope_level: scopeLevel,
          scope_class: scopeClass,
          flow_scope: flowScope,
          chip_binding_mode: chipBindingMode,
          applies_to_chips: appliesTo,
          chip_set: chipSet,
          context,

          chip_id: chip.chip_id,
          source_dir: chip.source_dir,
          run_id: runId,
          execution_id: executionId,
          source_run_ref: sourceRunRef,
          manifest_ref: manifest.filePath,

          alignment_status: String(manifest.data.alignment_status ?? 'UNKNOWN'),
          execution_handoff_status: String(manifest.data.execution_handoff_status ?? 'UNKNOWN'),
          canonical_registry_refs: Array.isArray(manifest.data.canonical_registry_refs) ? manifest.data.canonical_registry_refs.map(String) : [],
          non_canonical_notice: Boolean(manifest.data.non_canonical_notice),

          source_event_type: String(row.source_event_type ?? 'unknown'),
          asset_origin_class: String(row.asset_origin_class ?? ''),
          priority_class: String(row.priority_class ?? ''),
          source_fix_ref: String(row.source_fix_ref ?? ''),
          consumption_targets: normalizeStringList(row.consumption_targets),
          release_eligibility: row.release_eligibility && typeof row.release_eligibility === 'object' ? row.release_eligibility : {},

          promotion_status: promotionStatus,
          promotion_recommendation: String(row.promotion_recommendation ?? 'REVIEW'),
          authority_line: String(row.authority_line ?? 'PRD v1.1 knowledge flywheel'),

          summary: String(row.summary ?? ''),
          reusable_lesson: Array.isArray(row.reusable_lesson) ? row.reusable_lesson.map(String) : [],

          source_event_refs: Array.isArray(row.source_event_refs) ? row.source_event_refs.map(String) : [],
          evidence_refs: Array.isArray(row.evidence_refs) ? row.evidence_refs.map(String) : [],
          chip_evidence_refs: Array.isArray(row.chip_evidence_refs) ? row.chip_evidence_refs.map(String) : [],

          source_occurrences: [occurrence],
          occurrence_count: 1,

          notes: String(row.notes ?? ''),
        })
      }
    }
  }

  const rows = Array.from(assetMap.values())

  return rows.sort((a, b) => {
    const contextRank = (ctx: AssetContext) => ({ development_repo: 0, shared_packs: 1, customer_side_repo: 2 }[ctx] ?? 99)
    const rankDelta = contextRank(a.context) - contextRank(b.context)
    if (rankDelta !== 0) return rankDelta
    const familyDelta = a.asset_family.localeCompare(b.asset_family)
    if (familyDelta !== 0) return familyDelta
    return a.asset_id.localeCompare(b.asset_id)
  })
}

/**
 * Compute inventory stats from a full (unfiltered) row set.
 */
export function computeInventoryStats(rows: KnowledgeAssetRow[]): KnowledgeInventoryStats {
  const chip_occurrence_map: Record<string, { occurrences: number; asset_ids: Set<string> }> = {}

  for (const row of rows) {
    for (const occ of row.source_occurrences) {
      if (!chip_occurrence_map[occ.chip_id]) {
        chip_occurrence_map[occ.chip_id] = { occurrences: 0, asset_ids: new Set() }
      }
      chip_occurrence_map[occ.chip_id].occurrences += 1
      chip_occurrence_map[occ.chip_id].asset_ids.add(row.asset_id)
    }
  }

  return {
    unique_asset_count: rows.length,
    total_source_occurrences: rows.reduce((sum, r) => sum + r.occurrence_count, 0),
    chip_bound_count: rows.filter((r) => r.scope_class === 'CHIP_BOUND').length,
    platform_line_count: rows.filter((r) => r.scope_class === 'PLATFORM_LINE').length,
    release_line_count: rows.filter((r) => r.scope_class === 'RELEASE_LINE').length,
    cross_line_count: rows.filter((r) => r.scope_class === 'CROSS_LINE').length,
    not_flow_bound_count: rows.filter((r) => r.scope_class === 'NOT_FLOW_BOUND' || r.flow_scope.length === 0).length,
    chip_occurrence_map,
  }
}
