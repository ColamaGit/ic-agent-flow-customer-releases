import assert from 'node:assert/strict'
import test from 'node:test'
import { inferredMeaningUsage, logicalArtifactPath, stripOrderingPrefix } from '../src/components/fileFamilyInference'

test('stripOrderingPrefix removes numeric prefix only', () => {
  assert.equal(stripOrderingPrefix('22_dashboard_objects'), 'dashboard_objects')
  assert.equal(stripOrderingPrefix('dashboard_objects'), 'dashboard_objects')
})

test('logicalArtifactPath normalizes ordered folders', () => {
  const p = logicalArtifactPath('22_dashboard_objects/agent_trust_panel_view.json')
  assert.equal(p, 'dashboard_objects/agent_trust_panel_view.json')
})

test('inferredMeaningUsage returns run-execution metadata for ordered report path', () => {
  const { meaning, usage } = inferredMeaningUsage('22_reports/readiness_report.json')
  assert.match(meaning, /Formal report\/readiness family artifact/)
  assert.match(usage, /readiness/i)
})

test('inferredMeaningUsage returns upstream adjudication metadata', () => {
  const { meaning, usage } = inferredMeaningUsage('chips/quad_uart/specs/requirement_item_adjudication_record.json')
  assert.match(meaning, /Machine-readable human adjudication decision/)
  assert.match(usage, /resume/i)
})

test('inferredMeaningUsage falls back to upstream support text', () => {
  const { meaning, usage } = inferredMeaningUsage('chips/quad_uart/specs/unknown_support.json')
  assert.match(meaning, /Chip upstream support file/)
  assert.match(usage, /PRD v1\.0 upstream/)
})
