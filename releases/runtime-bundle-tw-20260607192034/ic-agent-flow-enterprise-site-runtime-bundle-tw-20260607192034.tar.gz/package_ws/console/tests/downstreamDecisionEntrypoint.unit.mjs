import assert from 'node:assert/strict'
import test from 'node:test'

import { buildDownstreamDecisionActionEntrypoint } from '../src/lib/downstreamDecisionEntrypoint.js'

test('buildDownstreamDecisionActionEntrypoint uses formal decision context and keeps submission disabled', () => {
  const entrypoint = buildDownstreamDecisionActionEntrypoint({
    sessionId: 'session-001',
    actorId: 'alice',
    role: 'QA Owner',
    chipId: 'quad_uart',
    runId: 'T-QUAD-UART',
    dateTime: '2026-05-23T18:20:23+08:00',
    gateFamily: 'QA_TRUST_GATE',
    actionName: 'request_more_evidence',
    targetObjectRefs: ['icaf://artifact/downstream/qa-trust'],
    sourceEvidenceRefs: ['icaf://artifact/downstream/evidence.json'],
    formalObjectRefs: ['icaf://artifact/downstream/reentry.json'],
  })

  assert.equal(entrypoint.decisionContextRef, 'governance://decision/downstream/qa-trust')
  assert.equal(entrypoint.actionRequest.action_name, 'request_more_evidence')
  assert.equal(entrypoint.actionRequest.role, 'QA Owner')
  assert.equal(entrypoint.liveSubmissionEnabled, false)
  assert.equal(entrypoint.readinessDimension, 'EVIDENCE_READY')
  assert.equal(entrypoint.decisionDimension, 'PENDING')
})
