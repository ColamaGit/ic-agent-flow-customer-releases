import assert from 'node:assert/strict'
import test from 'node:test'

import { buildDecisionState, mapReadinessToEvidenceStatus, resolveAuthorityStatus } from '../src/lib/downstreamDecisionStatus.js'

test('mapReadinessToEvidenceStatus separates evidence readiness from approval', () => {
  assert.equal(mapReadinessToEvidenceStatus('EVIDENCE_READY'), 'PASS')
  assert.equal(mapReadinessToEvidenceStatus('WARN'), 'PASS_WITH_WARNINGS')
  assert.equal(mapReadinessToEvidenceStatus('BLOCKED'), 'BLOCKED')
})

test('resolveAuthorityStatus treats backend binding as authority lifecycle diagnostic', () => {
  assert.equal(resolveAuthorityStatus({ backendBindingState: 'UNBOUND', liveSubmissionEnabled: false }), 'BLOCKED')
  assert.equal(resolveAuthorityStatus({ backendBindingState: 'BOUND', liveSubmissionEnabled: true }), 'OPEN')
  assert.equal(resolveAuthorityStatus({ backendBindingState: 'BOUND', liveSubmissionEnabled: true, decisionStatus: 'APPROVED' }), 'CLOSED')
})

test('buildDecisionState keeps file PASS distinct from human decision', () => {
  const state = buildDecisionState({
    readinessStatus: 'EVIDENCE_READY',
    decisionStatus: 'PENDING',
    backendBindingState: 'BOUND',
    liveSubmissionEnabled: true,
  })

  assert.equal(state.evidence_status, 'PASS')
  assert.equal(state.gate_status, 'PASS')
  assert.equal(state.decision_status, 'PENDING')
  assert.equal(state.authority_status, 'OPEN')
})
