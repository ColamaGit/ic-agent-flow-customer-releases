import assert from 'node:assert/strict'
import test from 'node:test'

import { readFormalDecisionQueue, resolveDecisionStatusFromFormalQueue } from '../src/lib/downstreamDecisionQueue.js'

test('readFormalDecisionQueue reads only formal queue paths', () => {
  const files = [
    {
      kind: 'file',
      relative_path: 'dashboard/v1.8/human_decision_queue.json',
      preview_text: JSON.stringify({
        queue_id: 'human-decision-queue-v1.8',
        dashboard_version: 'v1_8',
        items: [
          {
            formal_decision_ref: 'governance://decision/downstream/qa-trust',
            decision_type: 'approve',
            status: 'approved',
          },
        ],
      }),
    },
    {
      kind: 'file',
      relative_path: 'reports/decision_like_noise.json',
      preview_text: JSON.stringify({
        status: 'approved',
        formal_decision_ref: 'governance://decision/downstream/qa-trust',
      }),
    },
  ]

  const queue = readFormalDecisionQueue(files)

  assert.equal(queue?.queue_id, 'human-decision-queue-v1.8')
  assert.equal(queue?.dashboard_version, 'v1_8')
  assert.equal(queue?.items?.length, 1)
})

test('resolveDecisionStatusFromFormalQueue ignores heuristic-looking files and reads formal queue status', () => {
  const gate = {
    family: 'QA_TRUST_GATE',
    formalDecisionRef: 'governance://decision/downstream/qa-trust',
  }

  const files = [
    {
      kind: 'file',
      relative_path: 'reports/decision_like_noise.json',
      preview_text: JSON.stringify({
        status: 'approved',
        formal_decision_ref: 'governance://decision/downstream/qa-trust',
      }),
    },
    {
      kind: 'file',
      relative_path: 'dashboard_objects/decision_queue.json',
      preview_text: JSON.stringify({
        items: [
          {
            formal_decision_ref: 'governance://decision/downstream/qa-trust',
            decision_type: 'approve',
            status: 'approved',
          },
        ],
      }),
    },
  ]

  assert.equal(resolveDecisionStatusFromFormalQueue(gate, files), 'APPROVED')
})

test('resolveDecisionStatusFromFormalQueue defaults to pending when no formal queue exists', () => {
  const gate = {
    family: 'SIGNOFF_READINESS_GATE',
    formalDecisionRef: 'governance://decision/downstream/signoff-readiness',
  }

  const files = [
    {
      kind: 'file',
      relative_path: 'reports/decision_like_noise.json',
      preview_text: JSON.stringify({
        status: 'approved',
        formal_decision_ref: 'governance://decision/downstream/signoff-readiness',
      }),
    },
  ]

  assert.equal(resolveDecisionStatusFromFormalQueue(gate, files), 'PENDING')
})
