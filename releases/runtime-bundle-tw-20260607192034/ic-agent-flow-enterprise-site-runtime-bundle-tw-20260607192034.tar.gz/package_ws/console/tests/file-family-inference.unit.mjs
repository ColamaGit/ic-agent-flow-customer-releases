import test from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import ts from 'typescript'
import vm from 'node:vm'
import { createRequire } from 'node:module'

const cjsRequire = createRequire(import.meta.url)

function loadInferenceModule() {
  const tsPath = resolve(process.cwd(), 'src/components/fileFamilyInference.ts')
  const source = readFileSync(tsPath, 'utf-8')
  const transpiled = ts.transpileModule(source, {
    compilerOptions: {
      module: ts.ModuleKind.CommonJS,
      target: ts.ScriptTarget.ES2020,
    },
    fileName: tsPath,
  }).outputText
  const moduleObj = { exports: {} }
  const sandbox = { module: moduleObj, exports: moduleObj.exports, require: cjsRequire, console }
  vm.runInNewContext(transpiled, sandbox, { filename: tsPath })
  return sandbox.module.exports
}

const { logicalArtifactPath, inferredMeaningUsage } = loadInferenceModule()

test('logicalArtifactPath strips numeric ordering prefixes', () => {
  assert.equal(logicalArtifactPath('22_dashboard_objects/path_leak_scan_report.json'), 'dashboard_objects/path_leak_scan_report.json')
  assert.equal(logicalArtifactPath('01_inputs/graph/graph_to_generation_plan.json'), 'inputs/graph/graph_to_generation_plan.json')
})

test('inferredMeaningUsage provides explicit generation-plan meaning for run-local graph handoff', () => {
  const row = inferredMeaningUsage('01_inputs/graph/graph_to_generation_plan.json')
  assert.match(row.meaning, /graph-to-generation plan/i)
  assert.match(row.usage, /RTL generation/i)
})

test('inferredMeaningUsage marks dashboard objects as derived-only', () => {
  const row = inferredMeaningUsage('22_dashboard_objects/signoff_gap_record.json')
  assert.match(row.meaning, /Derived console object/i)
  assert.match(row.usage, /not a canonical truth source/i)
})

test('inferredMeaningUsage recognizes upstream alignment map as agent routing contract', () => {
  const row = inferredMeaningUsage('chips/quad_uart/governance/upstream_alignment_map.json')
  assert.match(row.meaning, /agent routing map|derived alignment index/i)
  assert.match(row.usage, /generate the Markdown companion from this JSON only/i)
})
