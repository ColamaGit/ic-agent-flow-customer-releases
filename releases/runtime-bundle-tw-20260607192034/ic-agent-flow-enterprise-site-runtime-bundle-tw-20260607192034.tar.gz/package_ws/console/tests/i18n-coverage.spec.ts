import { expect, test } from '@playwright/test'

test('run explorer page supports language toggle i18n', async ({ page }) => {
  await page.goto('/run/async-fifo-v0.1?mode=enterprise_site')
  await expect(page.getByRole('heading', { name: 'Run Artifact Explorer' })).toBeVisible()
  await expect(page.getByText('Execution Timestamp', { exact: true })).toBeVisible()

  await page.getByRole('button', { name: /toggle language/i }).click()
  await expect(page.getByRole('heading', { name: '執行產物瀏覽器' })).toBeVisible()
  await expect(page.getByText('執行時間戳', { exact: true })).toBeVisible()
})

test('artifact page source column supports i18n', async ({ page }) => {
  await page.goto('/artifacts?mode=enterprise_site')
  await expect(page.getByRole('columnheader', { name: 'Source' })).toBeVisible()

  await page.getByRole('button', { name: /toggle language/i }).click()
  await expect(page.getByRole('columnheader', { name: '來源' })).toBeVisible()
})
