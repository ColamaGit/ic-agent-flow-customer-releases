import { expect, test } from '@playwright/test'

const inventoryFixture = {
  workspace_id: 'ws-test',
  timestamp: '2026-05-08T19:00:00+08:00',
  chips: [
    {
      chip_id: 'ASYNC_FIFO',
      source_dir: 'artifacts/production-runs/async-fifo-v0.1',
      runs: [
        {
          run_id: 'T-FIFO-001',
          executions: [
            {
              execution_id: '20260507-061543',
              resolved_root: '/tmp/run-a',
              files: [
                { relative_path: '01_subject_binding/manifest_binding_record.json', kind: 'file', size_bytes: 120 },
                { relative_path: '01_subject_binding/re_entry_record.v0.1.json', kind: 'file', size_bytes: 80 },
              ],
            },
            {
              execution_id: '20260507-173846',
              resolved_root: '/tmp/run-b',
              files: [
                { relative_path: '01_skill_usage/skill_usage_summary.md', kind: 'file', size_bytes: 320 },
                { relative_path: '01_subject_binding/decision_package.v0.1.json', kind: 'file', size_bytes: 150 },
              ],
            },
          ],
        },
      ],
    },
  ],
}

test.describe('QA-007 dynamic E2E for HumanReview page', () => {
  test('node-io supports run-style scope and selector-driven replay context updates', async ({ page }) => {
    await page.route('**/portfolio/summaries/production_runs_inventory.json', async (route) => {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify(inventoryFixture),
      })
    })

    const initial = '/node-io?mode=enterprise_site&chip=ASYNC_FIFO&run=T-FIFO-001&execution=20260507-061543'
    await page.goto(initial)

    const combos = page.getByRole('combobox')
    await expect(combos).toHaveCount(3)
    await expect(combos.nth(0)).toHaveValue('ASYNC_FIFO')
    await expect(combos.nth(1)).toHaveValue('T-FIFO-001')
    await expect(combos.nth(2)).toHaveValue('20260507-061543')

    await expect(page.locator('main')).toContainText(/scope:\s*ASYNC_FIFO\s*\/\s*T-FIFO-001\s*\/\s*20260507-061543/i)
    await expect(page.locator('main')).toContainText(/subject_binding/i)

    await combos.nth(2).selectOption('20260507-173846')
    await expect(page).toHaveURL(/\/node-io\?mode=enterprise_site&chip=ASYNC_FIFO&run=T-FIFO-001&execution=20260507-173846/)
    await expect(page.locator('main')).toContainText(/scope:\s*ASYNC_FIFO\s*\/\s*T-FIFO-001\s*\/\s*20260507-173846/i)
    await expect(page.locator('main')).toContainText(/skill_usage|decision_package/i)

    const mainText = await page.locator('main').innerText()
    expect(mainText).not.toContain('nav.')
    expect(mainText).not.toContain('rev.')
    expect(mainText).not.toContain('undefined')
  })
})
