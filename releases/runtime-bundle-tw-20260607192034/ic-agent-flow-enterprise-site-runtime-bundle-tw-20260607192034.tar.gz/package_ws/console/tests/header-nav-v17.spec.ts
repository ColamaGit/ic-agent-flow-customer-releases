import { expect, test } from '@playwright/test'

test('console header shows v1.7 primary navigation and no legacy nav labels', async ({ page }) => {
  await page.goto('/')

  const nav = page.locator('header nav[aria-label="Primary"]')
  await expect(nav).toBeVisible()

  const expectedRoutes = [
    '/console',
    '/intake',
    '/upstream-flow',
    '/flow-map',
    '/node-io',
    '/artifacts',
    '/qa-trust',
    '/run-detail',
    '/package-readiness',
    '/decision-inbox',
    '/audit-replay',
  ]

  for (const route of expectedRoutes) {
    await expect(nav.locator(`a[data-route-key="${route}"]`)).toBeVisible()
  }

  const legacyRoutes = [
    '/qa',
    '/authority',
  ]

  for (const route of legacyRoutes) {
    await expect(nav.locator(`a[href="${route}"]`)).toHaveCount(0)
  }
})
