import { defineConfig } from '@playwright/test'

export default defineConfig({
  testDir: './tests',
  timeout: 30_000,
  testMatch: /static-dashboard.*\.spec\.ts/,
  use: {
    headless: true,
  },
})
