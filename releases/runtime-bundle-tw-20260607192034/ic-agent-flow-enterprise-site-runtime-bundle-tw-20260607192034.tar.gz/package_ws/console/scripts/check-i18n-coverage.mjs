import fs from 'node:fs'
import path from 'node:path'

const root = path.resolve(process.cwd(), 'src', 'pages')
const files = fs.readdirSync(root).filter((f) => f.endsWith('.tsx')).map((f) => path.join(root, f))

const violations = []

const ignoredLineHints = [
  "import ",
  "className=",
  "http://",
  "https://",
  "mode=",
  "aria-",
  "console.log",
]

function shouldIgnoreLine(line) {
  return ignoredLineHints.some((hint) => line.includes(hint))
}

const jsxTextRegex = />\s*([A-Za-z][^<{]*)\s*</g
const attrTextRegex = /(placeholder|title)\s*=\s*"([^"]*[A-Za-z][^"]*)"/g

for (const file of files) {
  const src = fs.readFileSync(file, 'utf8')
  const lines = src.split('\n')

  for (let i = 0; i < lines.length; i += 1) {
    const line = lines[i]
    if (shouldIgnoreLine(line)) continue

    let match
    while ((match = jsxTextRegex.exec(line)) !== null) {
      const txt = match[1].trim()
      if (!txt) continue
      if (txt.includes('{') || txt.includes('}')) continue
      violations.push(`${path.relative(process.cwd(), file)}:${i + 1} hardcoded JSX text: "${txt}"`)
    }
    while ((match = attrTextRegex.exec(line)) !== null) {
      const txt = match[2].trim()
      if (!txt) continue
      if (txt.startsWith('text-') || txt.startsWith('bg-') || txt.startsWith('border-')) continue
      violations.push(`${path.relative(process.cwd(), file)}:${i + 1} hardcoded attribute text: "${txt}"`)
    }
  }
}

if (violations.length > 0) {
  console.error('[i18n-check] Found non-i18n strings in src/pages:')
  for (const v of violations) console.error(`- ${v}`)
  process.exit(1)
}

console.log('[i18n-check] PASS: no hardcoded visible English strings detected in src/pages')
