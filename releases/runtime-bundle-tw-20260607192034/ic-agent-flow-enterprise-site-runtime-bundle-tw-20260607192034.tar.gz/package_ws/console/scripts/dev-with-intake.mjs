import { spawn } from 'node:child_process'
import { execSync } from 'node:child_process'
import process from 'node:process'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import crypto from 'node:crypto'

function run(name, command, args, options = {}) {
  const child = spawn(command, args, {
    stdio: 'inherit',
    shell: false,
    ...options,
  })

  child.on('error', (error) => {
    console.error(`[${name}] failed to start:`, error)
  })

  return child
}

const scriptDir = path.dirname(fileURLToPath(import.meta.url))
const consoleRoot = path.resolve(scriptDir, '..')
const repoRoot = path.resolve(scriptDir, '../../..')
const intakeApiScript = path.resolve(scriptDir, '../../deployment/runtime/intake_api_server.py')
const intakeOptionsUrl = 'http://127.0.0.1:8787/api/intake/options'
let intake = null
let consoleDev = null
let shuttingDown = false

function shutdown(code = 0) {
  if (shuttingDown) return
  shuttingDown = true

  for (const child of [consoleDev, intake]) {
    if (!child) continue
    if (!child.killed) {
      child.kill('SIGTERM')
    }
  }

  setTimeout(() => {
    for (const child of [consoleDev, intake]) {
      if (!child) continue
      if (!child.killed) {
        child.kill('SIGKILL')
      }
    }
    process.exit(code)
  }, 1000)
}

async function waitForIntakeOptions(expectedBootToken, timeoutMs = 90000) {
  const startedAt = Date.now()
  let lastObserved = 'no_response_yet'
  while (Date.now() - startedAt < timeoutMs) {
    try {
      const response = await fetch(intakeOptionsUrl)
      if (response.status === 200) {
        const payload = await response.json().catch(() => ({}))
        if (payload?.server_boot_token === expectedBootToken) {
          return
        }
        lastObserved = `status=200 token_mismatch expected=${expectedBootToken} actual=${String(payload?.server_boot_token ?? '<missing>')}`
      } else {
        lastObserved = `status=${response.status}`
      }
    } catch (error) {
      lastObserved = `fetch_error=${error instanceof Error ? error.message : String(error)}`
    }
    await new Promise((resolve) => setTimeout(resolve, 500))
  }
  throw new Error(`timeout waiting for ${intakeOptionsUrl} -> 200 (waited=${timeoutMs}ms, last_observed=${lastObserved})`)
}

function listListeningPids(port) {
  try {
    const out = execSync(`lsof -nP -iTCP:${port} -sTCP:LISTEN -t`, {
      encoding: 'utf-8',
      stdio: ['ignore', 'pipe', 'ignore'],
    }).trim()
    if (!out) return []
    return out
      .split('\n')
      .map((line) => Number(line.trim()))
      .filter((pid) => Number.isInteger(pid) && pid > 0)
  } catch {
    return []
  }
}

function readCommandLine(pid) {
  try {
    return execSync(`ps -p ${pid} -o command=`, {
      encoding: 'utf-8',
      stdio: ['ignore', 'pipe', 'ignore'],
    }).trim()
  } catch {
    return ''
  }
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

async function ensureFreshIntakePort() {
  const pids = listListeningPids(8787)
  if (pids.length === 0) return

  for (const pid of pids) {
    const cmd = readCommandLine(pid)
    const isIntakeApi = cmd.includes('intake_api_server.py')
    if (!isIntakeApi) {
      throw new Error(`port 8787 already in use by non-intake process (pid=${pid}): ${cmd || '<unknown>'}`)
    }
    console.log(`[dev:with-intake] stopping stale intake-api pid=${pid}`)
    try {
      process.kill(pid, 'SIGTERM')
    } catch {
      // process may already exit between list and kill
    }
  }

  const deadline = Date.now() + 5000
  while (Date.now() < deadline) {
    if (listListeningPids(8787).length === 0) return
    await sleep(100)
  }
  throw new Error('failed to release port 8787 from stale intake-api process')
}

async function main() {
  await ensureFreshIntakePort()
  const bootToken = `dev-with-intake-${crypto.randomUUID()}`

  intake = run(
    'intake-api',
    'python3',
    [intakeApiScript, '--host', '127.0.0.1', '--port', '8787', '--boot-token', bootToken],
    {
    cwd: repoRoot,
    },
  )

  intake.on('exit', (code) => {
    if ((code ?? 0) !== 0) {
      console.error(`[intake-api] exited with code ${code ?? 1}`)
      shutdown(code ?? 1)
    }
  })

  await waitForIntakeOptions(bootToken)
  console.log(`[intake-api] readiness check PASS (fresh instance): ${intakeOptionsUrl}`)

  consoleDev = run('console-dev', 'npm', ['run', 'dev:frontend'], {
    cwd: consoleRoot,
  })
  consoleDev.on('exit', (code) => {
    shutdown(code ?? 0)
  })
}

process.on('SIGINT', () => shutdown(0))
process.on('SIGTERM', () => shutdown(0))

main().catch((error) => {
  console.error(`[dev:with-intake] startup precheck failed: ${error instanceof Error ? error.message : String(error)}`)
  shutdown(1)
})
