import { defineConfig } from '@playwright/test'

export default defineConfig({
  testDir: './tests',
  testMatch: /v1\.8-(live-action-backend|rbac-negative|audit-replay|package-extract)\.spec\.ts/,
  timeout: 30_000,
  use: {
    baseURL: 'http://127.0.0.1:8797',
    headless: true,
  },
  webServer: {
    command: 'python3 ../shared-runtime/scripts/intake_api_server.py --host 127.0.0.1 --port 8797 --boot-token v18-live-playwright',
    port: 8797,
    reuseExistingServer: false,
    timeout: 120_000,
  },
})
