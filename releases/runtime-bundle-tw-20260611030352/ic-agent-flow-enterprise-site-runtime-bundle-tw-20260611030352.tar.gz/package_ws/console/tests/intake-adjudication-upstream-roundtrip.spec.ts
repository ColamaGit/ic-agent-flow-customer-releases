import { expect, test } from '@playwright/test'

test('cross-page roundtrip: intake -> adjudication -> upstream flow', async ({ page }) => {
  await page.route('**/api/intake/options', async (route) => {
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        templates_root: 'templates',
        templates: [{ name: 'UART Protocol', path: 'templates/UART Protocol' }],
      }),
    })
  })

  await page.route('**/api/intake', async (route) => {
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        status: 'ok',
        scope_type: 'CHIP_UPSTREAM',
        chip_id: 'quad_uart',
        intake_session_id: 'INTAKE-quad_uart-20260520-120000',
        bootstrap_mode: 'TEMPLATE_BASED',
        upstream_operation_id: 'UOP-INTAKE-quad_uart-20260520-120000',
      }),
    })
  })

  await page.route('**/api/intake/adjudication?chip_id=quad_uart', async (route) => {
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        status: 'ok',
        chip_id: 'quad_uart',
        scope_type: 'CHIP_UPSTREAM',
        review_package: { status: 'PENDING_HUMAN_ADJUDICATION', intake_session_id: 'INTAKE-quad_uart-20260520-120000' },
        builder_handoff: { handoff_status: 'PENDING_HUMAN_ADJUDICATION' },
        requirement_item: { requirement_items: [] },
        adjudication_template: { conditions_suggested: [] },
        adjudication_record: null,
        upstream_truth_flow: [],
      }),
    })
  })

  await page.goto('/intake')
  await page.locator('input').first().fill('quad uart')
  await page.locator('textarea').first().fill('quad uart in one chip and with high speed Tx/Rx')
  await page.getByRole('button', { name: /Execute Intake|執行 Intake/ }).click()

  const nextLink = page.getByRole('link', { name: /Start Requirement Adjudication|開始 Requirement Adjudication/ })
  await expect(nextLink).toHaveAttribute('href', /requirement-adjudication\?chip=quad_uart/)
  await nextLink.click()

  await expect(page).toHaveURL(/\/requirement-adjudication\?chip=quad_uart/)
  const flowLink = page.getByRole('link', { name: /Open Upstream Truth Flow|開啟上游真值流程/ })
  await expect(flowLink).toBeVisible()
  await flowLink.click()

  await expect(page).toHaveURL(/\/upstream-flow\?chip=quad_uart/)
  await expect(page.getByRole('heading', { name: /Upstream Truth Flow|上游真值流程/ })).toBeVisible()
  await expect(page.getByText(/scope_type:\s*CHIP_UPSTREAM/).first()).toBeVisible()
})
