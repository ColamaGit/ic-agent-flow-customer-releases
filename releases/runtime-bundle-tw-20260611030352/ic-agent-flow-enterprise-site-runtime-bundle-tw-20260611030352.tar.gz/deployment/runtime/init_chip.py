import argparse
import json
import os
import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Optional

# TZ Alignment: Taiwan Time (UTC+8)
tz_tw = timezone(timedelta(hours=8))


def _find_repo_root(start: Path) -> Path:
    """Walk upward from start until a bundle root marker is found.
    Supports both 'workspace' (dev repo) and 'package_ws' (customer bundle) layouts.
    """
    for candidate in [start, *start.parents]:
        if (candidate / "templates").exists() and (
            (candidate / "workspace").exists() or (candidate / "package_ws").exists()
        ):
            return candidate
    return Path.cwd()


def _repo_root_from_workspace_path(workspace_path: str) -> Path:
    workspace_manifest = Path(workspace_path)
    if not workspace_manifest.is_absolute():
        workspace_manifest = (Path.cwd() / workspace_manifest).resolve()
    else:
        workspace_manifest = workspace_manifest.resolve()

    # Support both dev-repo layout ('workspace') and customer bundle layout ('package_ws')
    if workspace_manifest.parent.name in {"workspace", "package_ws"}:
        return workspace_manifest.parent.parent
    # Fallback: walk upward looking for bundle markers (layout-agnostic)
    return _find_repo_root(workspace_manifest)


def _default_production_intent(chip_id: str, template_path: Optional[str]) -> dict:
    template_name = os.path.basename(template_path) if template_path else ""
    template_key = template_name.lower()
    is_uart = "uart" in template_key or "uart" in chip_id.lower()

    bringup_plan = "bounded-bringup-intent-uart" if is_uart else "bounded-bringup-intent-sn2025"
    packaging_doc = "bounded-packaging-lab-notes-uart" if is_uart else "bounded-packaging-lab-notes-sn2025"
    packaging_assumption = (
        "bounded digital shuttle packaging with UART IO exposure"
        if is_uart
        else "bare-die or bounded digital shuttle packaging"
    )
    packaging_notes = (
        "Package assumptions, UART IO exposure, bench prerequisites, and loopback smoke-test handoff notes documented for operator use"
        if is_uart
        else "Package assumptions, power/reset exposure, bench prerequisites, and smoke-test handoff notes documented for operator use"
    )

    return {
        "schema_version": "production-intent.v0.1",
        "chip_id": chip_id,
        "pad_ring": {
            "status": "PARTIAL",
            "library_name": "bounded-pad-intent-nangate45",
            "integration_done": False,
            "notes": "Pad-ring direction documented for next physical-integration step; current flow remains bare-core",
        },
        "dft": {
            "status": "PARTIAL",
            "strategy_name": "bounded-dft-intent-yosys",
            "tool_capability_present": False,
            "notes": "DFT intent documented; current Yosys build has no native scan insertion pass",
        },
        "bringup": {
            "status": "DONE",
            "plan_name": bringup_plan,
            "lab_flow_defined": False,
            "notes": "Bringup sequence documented for next lab phase; execution checklist not yet closed",
        },
        "esd": {
            "status": "PARTIAL",
            "strategy_name": "bounded-esd-intent-nangate45",
            "integration_done": False,
            "notes": "ESD protection strategy documented for next integration step; ESD cells not yet instantiated in layout",
        },
        "packaging_lab_notes": {
            "status": "DONE",
            "document_name": packaging_doc,
            "package_assumption": packaging_assumption,
            "notes": packaging_notes,
        },
    }

def init_chip(
    chip_id: str,
    template_path: Optional[str],
    workspace_path: str = "package_ws/workspace_manifest.yaml",
    bootstrap_mode: str = "TEMPLATE_BASED",
    bootstrap_note: Optional[str] = None,
):
    print(
        f"Initializing chip '{chip_id}' "
        f"(mode={bootstrap_mode}, template={template_path if template_path else 'null'})..."
    )
    
    # Simple YAML subset reader (works for our manifests)
    def load_simple_yaml(path):
        data = {}
        with open(path, 'r') as f:
            for line in f:
                if ":" in line and not line.strip().startswith("-"):
                    k, v = line.split(":", 1)
                    data[k.strip()] = v.strip().strip('"')
        return data

    repo_root = _repo_root_from_workspace_path(workspace_path)
    workspace_manifest_path = Path(workspace_path)
    if not workspace_manifest_path.is_absolute():
        workspace_manifest_path = (Path.cwd() / workspace_manifest_path).resolve()
    else:
        workspace_manifest_path = workspace_manifest_path.resolve()

    # 1. Define Chip Directory (anchored to repo root)
    chip_dir = repo_root / "chips" / chip_id
    chip_dir_ref = f"chips/{chip_id}"
    if chip_dir.exists():
        print(f"Error: Chip directory '{chip_dir_ref}' already exists.")
        return
    
    # 2. Create Skeleton Folders
    folders = [
        "specs", "rtl", "constraints", "netlists", "layout", 
        "verification", "eco", "approvals", "evidence", "qa", "dashboards"
    ]
    for folder in folders:
        (chip_dir / folder).mkdir(parents=True, exist_ok=True)
    
    # 3. Create Chip Manifest (as JSON-formatted YAML)
    chip_manifest = {
        "schema_version": "chip-program-manifest.v0.1",
        "chip_id": chip_id,
        "chip_name": chip_id.replace("-", " ").title(),
        "chip_program_version": "v0.1.0",
        "derived_from_template_ref": template_path,
        "bootstrap_mode": bootstrap_mode,
        "workspace_ref": workspace_manifest_path.as_posix(),
        "phase_state": "Initialization",
        "verification_state": "Pending",
        "readiness_state": "Low",
        "evidence_root_ref": f"chips/{chip_id}/evidence/",
        "created_at": datetime.now(tz_tw).isoformat(),
        "updated_at": datetime.now(tz_tw).isoformat()
    }
    
    if bootstrap_note:
        chip_manifest["bootstrap_note"] = bootstrap_note

    manifest_path = chip_dir / "chip_program_manifest.yaml"
    with manifest_path.open("w", encoding="utf-8") as f:
        # JSON is valid YAML!
        json.dump(chip_manifest, f, indent=2)

    # 3.1 Materialize production intent baseline so readiness production rows
    # are deterministic in both package-local and repo-local runtime.
    production_intent_path = chip_dir / "production_intent.json"
    if not production_intent_path.exists():
        with production_intent_path.open("w", encoding="utf-8") as f:
            json.dump(_default_production_intent(chip_id=chip_id, template_path=template_path), f, indent=2)
    
    # 4. Update Workspace Manifest (JSON-formatted YAML expected)
    with workspace_manifest_path.open("r", encoding="utf-8") as f:
        workspace_manifest = json.load(f)

    active_chip_programs = workspace_manifest.setdefault("active_chip_programs", [])
    manifest_ref = f"chips/{chip_id}/chip_program_manifest.yaml"
    if manifest_ref not in active_chip_programs:
        active_chip_programs.append(manifest_ref)
    workspace_manifest["updated_at"] = datetime.now(tz_tw).isoformat()
    with workspace_manifest_path.open("w", encoding="utf-8") as f:
        json.dump(workspace_manifest, f, indent=2)
    
    print(f"Successfully initialized chip '{chip_id}' at {chip_dir_ref}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Initialize chip workspace from template or blank scaffold."
    )
    parser.add_argument("chip_id", help="Target chip id.")
    parser.add_argument(
        "template_path",
        nargs="?",
        default=None,
        help="Optional template path. Omit for BLANK_SCAFFOLD mode.",
    )
    parser.add_argument(
        "--workspace-manifest-path",
        default="package_ws/workspace_manifest.yaml",
        help="Path to workspace manifest.",
    )
    parser.add_argument(
        "--bootstrap-mode",
        choices=["TEMPLATE_BASED", "BLANK_SCAFFOLD"],
        default=None,
        help="Bootstrap mode. Defaults to TEMPLATE_BASED if template path is given, otherwise BLANK_SCAFFOLD.",
    )
    parser.add_argument(
        "--bootstrap-note",
        default=None,
        help="Optional bootstrap note persisted in chip manifest.",
    )
    args = parser.parse_args()

    bootstrap_mode = args.bootstrap_mode
    if not bootstrap_mode:
        bootstrap_mode = "TEMPLATE_BASED" if args.template_path else "BLANK_SCAFFOLD"

    if bootstrap_mode == "TEMPLATE_BASED" and not args.template_path:
        print("Error: TEMPLATE_BASED mode requires template_path.")
        sys.exit(1)

    init_chip(
        chip_id=args.chip_id,
        template_path=args.template_path,
        workspace_path=args.workspace_manifest_path,
        bootstrap_mode=bootstrap_mode,
        bootstrap_note=args.bootstrap_note,
    )
