"""H1 staged decomposition placeholder (yosys synth)."""
