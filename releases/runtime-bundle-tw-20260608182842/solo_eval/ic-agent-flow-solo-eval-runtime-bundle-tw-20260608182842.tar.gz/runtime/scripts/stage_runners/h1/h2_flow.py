from __future__ import annotations

import json
import os
import shutil
from typing import Any, Dict, List


def run_h_stage_flow_and_flatten(
    *,
    run_dir: str,
    chip_id: str,
    task_id: str,
    inputs_rtl_dir: str,
    top_module: str,
    toolchain_resolution: Dict[str, Any],
) -> List[Dict[str, Any]]:
    from run_real_eda import run_real_eda as _run_real_eda

    h_stage_log = _run_real_eda(
        run_dir,
        chip_id,
        task_id,
        inputs_rtl_dir,
        top_module,
        workspace_id=f"ws-{chip_id}",
        toolchain_resolution=toolchain_resolution,
    )

    # Flatten nested sub-runs so downstream consumers can resolve stable stage-local paths.
    for _stage in ("h1_yosys", "h2_openroad", "h5_opensta", "h4_klayout", "h3_netgen"):
        _stage_dir = os.path.join(run_dir, _stage)
        if not os.path.isdir(_stage_dir):
            continue
        _inner_dirs = [d for d in os.listdir(_stage_dir) if os.path.isdir(os.path.join(_stage_dir, d))]
        if _inner_dirs:
            _inner_dirs_sorted = sorted(
                _inner_dirs,
                key=lambda d: os.path.getmtime(os.path.join(_stage_dir, d)),
                reverse=True,
            )
            _inner = os.path.join(_stage_dir, _inner_dirs_sorted[0])
            for _f in os.listdir(_inner):
                _dst = os.path.join(_stage_dir, _f)
                if not os.path.exists(_dst):
                    shutil.move(os.path.join(_inner, _f), _stage_dir)
            try:
                os.rmdir(_inner)
            except OSError:
                pass

        # Normalize report refs after flatten to stable stage-local path.
        _normalized_map = {
            "h3_netgen": "normalized.lvs.meta.json",
            "h2_openroad": "normalized.drc.meta.json",
            "h1_yosys": "normalized.netlist.meta.json",
            "h5_opensta": "normalized.sta.meta.json",
            "h4_klayout": "normalized.drc.meta.json",
        }
        _normalized_name = _normalized_map.get(_stage)
        if _normalized_name:
            _normalized_path = os.path.join(_stage_dir, _normalized_name)
            if os.path.exists(_normalized_path):
                try:
                    with open(_normalized_path, "r", encoding="utf-8") as _nf:
                        _norm = json.load(_nf)
                    if isinstance(_norm, dict) and _stage == "h3_netgen":
                        _norm["report_ref"] = os.path.join(_stage_dir, "comp.out")
                        with open(_normalized_path, "w", encoding="utf-8") as _wf:
                            json.dump(_norm, _wf, indent=2, ensure_ascii=False)
                except Exception:
                    pass
        print(f"  ✅ [{_stage}] Flattened to run_dir")

    return h_stage_log
