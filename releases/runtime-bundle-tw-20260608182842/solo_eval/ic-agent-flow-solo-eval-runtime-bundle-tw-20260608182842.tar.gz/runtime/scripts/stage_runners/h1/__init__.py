"""ARCH-GAP-001 decomposition placeholder package."""
