#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import shutil
from typing import Any, Callable, Dict, List

from ic_agent_flow.governance.cdc_rdc_analysis_capability import (
    CdcRdcAnalysisCapabilityBoundary,
    CdcRdcAnalysisRequest,
)
from ic_agent_flow.governance.cdc_signoff_lite_capability import (
    CdcSignoffLiteCapabilityBoundary,
    CdcSignoffLiteRequest,
)
from ic_agent_flow.registry.scenario_registry import Disposition


def _flatten_single_nested_run(output_dir: str) -> None:
    if not os.path.isdir(output_dir):
        return
    inner_dirs = [d for d in os.listdir(output_dir) if os.path.isdir(os.path.join(output_dir, d))]
    if not inner_dirs:
        return
    inner = os.path.join(output_dir, inner_dirs[0])
    for name in os.listdir(inner):
        shutil.move(os.path.join(inner, name), output_dir)
    os.rmdir(inner)


def _load_json_if_exists(path: str) -> Dict[str, Any]:
    if not os.path.exists(path):
        return {}
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return data if isinstance(data, dict) else {}


def run_v3_cdc_and_v3b_signoff(
    *,
    base_dir: str,
    run_dir: str,
    chip_id: str,
    task_id: str,
    inputs_rtl_dir: str,
    top_module: str,
    write_rdc_review_artifact: Callable[[str], str | None],
) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []

    cdc_req = CdcRdcAnalysisRequest(
        workspace_id=f"ws-{chip_id}",
        chip_id=chip_id,
        task_id=task_id,
        decision_context_ref=f"decision://{task_id}/formal-release",
        contract_name="cdc_rdc_structural_contract",
        contract_version="v0.1",
        rtl_path=inputs_rtl_dir,
        top_module=top_module,
        output_root=os.path.join(run_dir, "v3_cdc_rdc"),
    )
    cdc_resp = CdcRdcAnalysisCapabilityBoundary().execute(cdc_req)
    v3_out = os.path.join(run_dir, "v3_cdc_rdc")
    _flatten_single_nested_run(v3_out)
    cdc_meta = _load_json_if_exists(os.path.join(v3_out, "normalized.cdc.meta.json"))
    rdc_meta = _load_json_if_exists(os.path.join(v3_out, "normalized.rdc.meta.json"))
    rdc_review_ref = write_rdc_review_artifact(run_dir)
    rows.append(
        {
            "stage": "v3_cdc_rdc",
            "output_dir": v3_out,
            "status": "PASS" if cdc_resp.disposition == Disposition.PASS else "FAIL",
            "cdc_status": cdc_meta.get("status"),
            "rdc_status": rdc_meta.get("status"),
            "rdc_review_ref": rdc_review_ref,
            "detail": cdc_resp.reason,
        }
    )

    ws_name = "package_ws" if os.path.exists(os.path.join(base_dir, "package_ws")) else "workspace"
    prop_pack = os.path.join(
        base_dir,
        ws_name,
        "shared-runtime",
        "governance_assets",
        "cdc_signoff_lite",
        "default_cdc_lite_properties.sv",
    )
    v3b_req = CdcSignoffLiteRequest(
        workspace_id=f"ws-{chip_id}",
        chip_id=chip_id,
        task_id=task_id,
        decision_context_ref=f"decision://{task_id}/formal-release",
        contract_name="cdc_signoff_lite_contract",
        contract_version="v0.1",
        rtl_path=inputs_rtl_dir,
        top_module=top_module,
        property_pack_path=prop_pack,
        output_root=os.path.join(run_dir, "v3b_cdc_signoff_lite"),
    )
    v3b_resp = CdcSignoffLiteCapabilityBoundary().execute(v3b_req)
    v3b_out = os.path.join(run_dir, "v3b_cdc_signoff_lite")
    _flatten_single_nested_run(v3b_out)
    v3b_meta = _load_json_if_exists(os.path.join(v3b_out, "normalized.cdc_signoff_lite.meta.json"))
    rows.append(
        {
            "stage": "v3b_cdc_signoff_lite",
            "output_dir": v3b_out,
            "status": v3b_meta.get("status", "FAIL"),
            "claim_class": v3b_meta.get("claim_class"),
            "detail": v3b_resp.reason,
        }
    )
    return rows
