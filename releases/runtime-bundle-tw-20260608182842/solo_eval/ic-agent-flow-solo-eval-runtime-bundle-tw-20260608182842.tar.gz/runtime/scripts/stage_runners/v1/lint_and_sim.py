from __future__ import annotations

import json
import os
import shutil
from typing import Any, Dict, List, Optional

from ic_agent_flow.registry.scenario_registry import Disposition
from ic_agent_flow.governance.verilator_lint_capability import (
    VerilatorLintMcpCapabilityBoundary,
    VerilatorLintMcpCapabilityRequest,
)
from ic_agent_flow.governance.verilator_sim_capability import (
    VerilatorSimMcpCapabilityBoundary,
    VerilatorSimMcpCapabilityRequest,
)


def _resolve_sim_testbench(chip_id: str, inputs_rtl_dir: str) -> Optional[Dict[str, str]]:
    rtl_path = os.path.abspath(inputs_rtl_dir)
    rtl_parent = os.path.basename(os.path.dirname(rtl_path))
    if rtl_parent == "design":
        inputs_dir = os.path.dirname(os.path.dirname(rtl_path))
    else:
        inputs_dir = os.path.dirname(rtl_path)
    verification_tb_dir = os.path.join(inputs_dir, "verification", "tb")
    def _candidate(path: str, top: str, design_top: str) -> Dict[str, str]:
        return {
            "testbench_path": path,
            "testbench_top": top,
            "top_module": design_top,
        }
    if chip_id == "quad_uart":
        for candidate in (
            os.path.join(verification_tb_dir, "quad_uart_tb.sv"),
            os.path.join(inputs_rtl_dir, "quad_uart_tb.sv"),
        ):
            if os.path.exists(candidate):
                return _candidate(candidate, "quad_uart_tb", "quad_uart_top")
        return None
    if chip_id == "test-chip-02":
        for candidate in (
            os.path.join(inputs_rtl_dir, "top_tb.v"),
            os.path.join(verification_tb_dir, "top_tb.v"),
        ):
            if os.path.exists(candidate):
                return _candidate(candidate, "top_tb", "top")
        return None
    if chip_id == "uart-controller-v0.1":
        for candidate in (
            os.path.join(inputs_rtl_dir, "UART_Top_tb.v"),
            os.path.join(verification_tb_dir, "UART_Top_tb.v"),
        ):
            if os.path.exists(candidate):
                return _candidate(candidate, "UART_Top_tb", "UART_Top")
        return None
    if chip_id == "async-fifo-v0.1":
        for candidate in (
            os.path.join(inputs_rtl_dir, "testbench.sv"),
            os.path.join(verification_tb_dir, "testbench.sv"),
        ):
            if os.path.exists(candidate):
                return _candidate(candidate, "asynchronous_fifo_tb", "asynchronous_fifo")
        return None
    return None


def _resolve_sim_timeout_sec(chip_id: str) -> int:
    # test-chip-02 compile path is heavier and has repeatedly hit the 60s compile cap
    # (compile timeout uses max(timeout_sec * 4, 60) in verilator_sim_capability).
    if chip_id == "test-chip-02":
        return 45
    if chip_id == "quad_uart":
        return 30
    return 15


def _flatten_single_nested_run(stage_dir: str) -> None:
    if not os.path.isdir(stage_dir):
        return
    inner_dirs = [d for d in os.listdir(stage_dir) if os.path.isdir(os.path.join(stage_dir, d))]
    if not inner_dirs:
        return
    inner = os.path.join(stage_dir, inner_dirs[0])
    for f in os.listdir(inner):
        src = os.path.join(inner, f)
        dst = os.path.join(stage_dir, f)
        if os.path.exists(dst):
            continue
        shutil.move(src, dst)
    try:
        os.rmdir(inner)
    except OSError:
        pass


def run_v1_v2_lint_and_sim(
    *,
    run_dir: str,
    chip_id: str,
    task_id: str,
    inputs_rtl_dir: str,
    verilator_bin: str,
) -> List[Dict[str, Any]]:
    assembly: List[Dict[str, Any]] = []

    lint_req = VerilatorLintMcpCapabilityRequest(
        workspace_id=f"ws-{chip_id}",
        chip_id=chip_id,
        task_id=task_id,
        decision_context_ref=f"decision://{task_id}/formal-release",
        contract_name="verilator_lint_contract",
        contract_version="v0.1",
        rtl_path=inputs_rtl_dir,
        top_module="top" if chip_id == "test-chip-02" else ("UART_Top" if "uart" in chip_id else "asynchronous_fifo"),
        output_root=os.path.join(run_dir, "v1_verilator_lint"),
        verilator_bin=verilator_bin,
    )
    lint_boundary = VerilatorLintMcpCapabilityBoundary()
    lint_resp = lint_boundary.execute(lint_req)

    v1_out = os.path.join(run_dir, "v1_verilator_lint")
    _flatten_single_nested_run(v1_out)

    assembly.append(
        {
            "stage": "v1_verilator_lint",
            "output_dir": v1_out,
            "status": "PASS" if lint_resp.disposition == Disposition.PASS else "WARN" if lint_resp.warning_count > 0 else "FAIL",
            "warning_count": lint_resp.warning_count,
            "error_count": lint_resp.error_count,
        }
    )

    sim_cfg = _resolve_sim_testbench(chip_id, inputs_rtl_dir)
    if sim_cfg and os.path.exists(sim_cfg["testbench_path"]):
        sim_req = VerilatorSimMcpCapabilityRequest(
            workspace_id=f"ws-{chip_id}",
            chip_id=chip_id,
            task_id=task_id,
            decision_context_ref=f"decision://{task_id}/formal-release",
            contract_name="verilator_sim_contract",
            contract_version="v0.1",
            rtl_path=inputs_rtl_dir,
            top_module=sim_cfg["top_module"],
            testbench_path=sim_cfg["testbench_path"],
            testbench_top=sim_cfg["testbench_top"],
            timeout_sec=_resolve_sim_timeout_sec(chip_id),
            output_root=os.path.join(run_dir, "v2_verilator_sim"),
            verilator_bin=verilator_bin,
        )
        sim_boundary = VerilatorSimMcpCapabilityBoundary()
        sim_resp = sim_boundary.execute(sim_req)

        v2_out = os.path.join(run_dir, "v2_verilator_sim")
        _flatten_single_nested_run(v2_out)

        sim_meta_path = os.path.join(v2_out, "normalized.sim.meta.json")
        sim_meta = None
        if os.path.exists(sim_meta_path):
            with open(sim_meta_path, "r", encoding="utf-8") as f:
                sim_meta = json.load(f)
        assembly.append(
            {
                "stage": "v2_verilator_sim",
                "output_dir": v2_out,
                "status": (sim_meta or {}).get("status", "FAIL" if sim_resp.disposition != Disposition.PASS else "UNKNOWN"),
                "warning_count": (sim_meta or {}).get("warning_count", 0),
                "error_count": (sim_meta or {}).get("error_count", 0),
                "detail": sim_resp.reason,
            }
        )
    else:
        assembly.append(
            {
                "stage": "v2_verilator_sim",
                "output_dir": os.path.join(run_dir, "v2_verilator_sim"),
                "status": "SKIPPED",
                "detail": "skipped: no chip-scoped testbench available",
            }
        )

    return assembly
