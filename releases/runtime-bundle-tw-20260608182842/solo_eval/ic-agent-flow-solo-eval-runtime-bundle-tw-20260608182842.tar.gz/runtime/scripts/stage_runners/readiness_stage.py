from __future__ import annotations


def run_readiness_stage(run_dir: str) -> int:
    """Compile v0.2 readiness report for a run directory.

    Kept as a dedicated stage module so runner orchestration can remain thin.
    """
    from generate_readiness_report import compile_report

    return compile_report(run_dir)
