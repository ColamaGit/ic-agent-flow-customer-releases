#!/usr/bin/env python3
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


def stage_contract_profile(stage: str) -> Tuple[Optional[str], Optional[str]]:
    mapping = {
        "v1_verilator_lint": ("verilator_lint", "capability_profile://verilator_lint/v0.1"),
        "v2_verilator_sim": ("verilator_sim", "capability_profile://verilator_sim/v0.1"),
        "v3_cdc_rdc": ("cdc_rdc_analysis", "capability_profile://cdc_rdc_analysis/v0.1"),
        "v3b_cdc_signoff_lite": ("cdc_signoff_lite", "capability_profile://cdc_signoff_lite/v0.1"),
        "v4_yosys_lec": ("yosys_lec", "capability_profile://yosys_lec/v0.1"),
        "h1_yosys": ("yosys_synth", "capability_profile://yosys_synth/v0.1"),
        "h2_openroad": ("openroad_execute", "capability_profile://openroad_execute/v0.1"),
        "h5_opensta": ("opensta_timing", "capability_profile://opensta_timing/v0.1"),
        "h3_netgen": ("netgen_lvs", "capability_profile://netgen_lvs/v0.1"),
        "h4_klayout": ("klayout_drc", "capability_profile://klayout_drc/v0.1"),
    }
    return mapping.get(stage, (None, None))


def normalized_status_for_stage(stage_dir: str) -> str:
    candidates = [
        "normalized.lint.meta.json",
        "normalized.sim.meta.json",
        "normalized.cdc.meta.json",
        "normalized.cdc_signoff_lite.meta.json",
        "normalized.lec.meta.json",
        "normalized.netlist.meta.json",
        "normalized.drc.meta.json",
        "normalized.sta.meta.json",
        "normalized.lvs.meta.json",
    ]
    for name in candidates:
        path = os.path.join(stage_dir, name)
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                meta = json.load(f)
            return str(meta.get("status", "UNKNOWN"))
    return "UNKNOWN"


def hydrate_stage_evidence_refs(stage: str, stage_dir: str, evidence_bundle: Dict) -> Dict:
    stage_path = Path(stage_dir)
    raw_refs = evidence_bundle.get("raw_refs")
    normalized_refs = evidence_bundle.get("normalized_refs")
    if not isinstance(raw_refs, list):
        raw_refs = []
    if not isinstance(normalized_refs, list):
        normalized_refs = []

    expected_raw = {
        "v1_verilator_lint": ["verilator_lint.raw.log"],
        "v2_verilator_sim": ["verilator_compile.raw.log", "verilator_run.raw.log", "verilator_coverage.raw.log"],
        "v3_cdc_rdc": ["structural_analysis.raw.json"],
        "v3b_cdc_signoff_lite": ["sby.raw.log"],
        "v4_yosys_lec": ["yosys_lec.raw.log"],
        "h1_yosys": ["yosys.raw.log"],
        "h2_openroad": ["openroad.raw.log"],
        "h5_opensta": ["opensta.raw.log"],
        "h3_netgen": ["netgen.raw.log"],
        "h4_klayout": ["klayout.raw.log"],
    }.get(stage, [])
    expected_normalized = {
        "v1_verilator_lint": ["normalized.lint.meta.json"],
        "v2_verilator_sim": ["normalized.sim.meta.json"],
        "v3_cdc_rdc": ["normalized.cdc.meta.json"],
        "v3b_cdc_signoff_lite": ["normalized.cdc_signoff_lite.meta.json"],
        "v4_yosys_lec": ["normalized.lec.meta.json"],
        "h1_yosys": ["normalized.netlist.meta.json"],
        "h2_openroad": ["normalized.drc.meta.json"],
        "h5_opensta": ["normalized.sta.meta.json"],
        "h3_netgen": ["normalized.lvs.meta.json"],
        "h4_klayout": ["normalized.drc.meta.json"],
    }.get(stage, [])

    for name in expected_raw:
        path = stage_path / name
        if path.exists():
            rel = f"{stage}/{name}"
            if rel not in raw_refs:
                raw_refs.append(rel)
    for name in expected_normalized:
        path = stage_path / name
        if path.exists():
            rel = f"{stage}/{name}"
            if rel not in normalized_refs:
                normalized_refs.append(rel)

    if "lineage_ref" not in evidence_bundle:
        lineage_path = stage_path / "lineage.json"
        if lineage_path.exists():
            evidence_bundle["lineage_ref"] = f"{stage}/lineage.json"
    evidence_bundle["raw_refs"] = raw_refs
    evidence_bundle["normalized_refs"] = normalized_refs
    return evidence_bundle


def augment_capability_contract_artifacts(run_dir: str, task_id: str, now_iso: str) -> Dict[str, str]:
    stage_dirs = [
        "v1_verilator_lint",
        "v2_verilator_sim",
        "v3_cdc_rdc",
        "v3b_cdc_signoff_lite",
        "v4_yosys_lec",
        "h1_yosys",
        "h2_openroad",
        "h5_opensta",
        "h3_netgen",
        "h4_klayout",
    ]
    decision_package_ref = "subject_binding/decision_package.v0.1.json"
    reentry_record_ref = "subject_binding/re_entry_record.v0.1.json"
    blocked_status = {"FAIL", "ERROR", "INTEGRITY_DRIFT", "SKIPPED"}
    contract_refs: Dict[str, str] = {}

    for stage in stage_dirs:
        stage_dir = os.path.join(run_dir, stage)
        input_manifest_path = os.path.join(stage_dir, "input_manifest.json")
        evidence_bundle_path = os.path.join(stage_dir, "evidence_bundle.json")
        if not os.path.exists(input_manifest_path) or not os.path.exists(evidence_bundle_path):
            continue
        with open(input_manifest_path, "r", encoding="utf-8") as f:
            input_manifest = json.load(f)

        capability_id, profile_ref = stage_contract_profile(stage)
        if capability_id:
            input_manifest.setdefault("capability_id", capability_id)
        if profile_ref:
            input_manifest.setdefault("capability_profile_ref", profile_ref)
        input_manifest.setdefault("decision_context_ref", f"decision://{task_id}/formal-release")
        input_manifest.setdefault("task_id", task_id)
        input_manifest["generated_at"] = now_iso
        with open(input_manifest_path, "w", encoding="utf-8") as f:
            json.dump(input_manifest, f, indent=2)

        with open(evidence_bundle_path, "r", encoding="utf-8") as f:
            evidence_bundle = json.load(f)
        evidence_bundle = hydrate_stage_evidence_refs(stage, stage_dir, evidence_bundle)
        with open(evidence_bundle_path, "w", encoding="utf-8") as f:
            json.dump(evidence_bundle, f, indent=2)
        capability_verdict = normalized_status_for_stage(stage_dir)
        blocking_reasons = [f"{stage}:{capability_verdict}"] if capability_verdict in blocked_status else []
        re_entry_recommendation = "request_more_evidence" if blocking_reasons else "none"

        output_envelope = {
            "capability_id": input_manifest.get("capability_id"),
            "capability_profile_ref": input_manifest.get("capability_profile_ref"),
            "capability_verdict": capability_verdict,
            "capability_blocking_reasons": blocking_reasons,
            "re_entry_recommendation": re_entry_recommendation,
            "raw_artifact_refs": evidence_bundle.get("raw_refs", []),
            "normalized_output_ref": (evidence_bundle.get("normalized_refs") or [None])[0],
            "lineage_ref": evidence_bundle.get("lineage_ref"),
            "decision_package_ref": decision_package_ref,
            "re_entry_record_ref": reentry_record_ref,
            "generated_at": now_iso,
        }
        output_envelope_path = os.path.join(stage_dir, "output_envelope.json")
        with open(output_envelope_path, "w", encoding="utf-8") as f:
            json.dump(output_envelope, f, indent=2)

        lineage_path = os.path.join(stage_dir, "lineage.json")
        if os.path.exists(lineage_path):
            with open(lineage_path, "r", encoding="utf-8") as f:
                lineage = json.load(f)
            lineage["output_envelope_ref"] = output_envelope_path
            with open(lineage_path, "w", encoding="utf-8") as f:
                json.dump(lineage, f, indent=2)

        contract_refs[stage] = output_envelope_path
    return contract_refs


def write_route_b_decision_package(run_dir: str, task_id: str, now_iso: str) -> str:
    stage_dirs = [
        "v1_verilator_lint",
        "v2_verilator_sim",
        "v3_cdc_rdc",
        "v3b_cdc_signoff_lite",
        "v4_yosys_lec",
        "h1_yosys",
        "h2_openroad",
        "h5_opensta",
        "h3_netgen",
        "h4_klayout",
    ]
    candidate_decisions = ["proceed", "request_more_evidence", "reject"]
    blocking_rows = []
    for stage in stage_dirs:
        bundle_path = os.path.join(run_dir, stage, "evidence_bundle.json")
        if not os.path.exists(bundle_path):
            continue
        status = normalized_status_for_stage(os.path.join(run_dir, stage))
        if status in {"FAIL", "ERROR", "INTEGRITY_DRIFT", "SKIPPED"}:
            blocking_rows.append(f"{stage}:{status}")

    payload = {
        "decision_context_ref": f"decision://{task_id}/formal-release",
        "decision_state": "PRE_DECISION",
        "decision_outcome": None,
        "candidate_decisions": candidate_decisions,
        "consumed_evidence_refs": [],
        "blocking_rows": blocking_rows,
        "generated_at": now_iso,
    }
    out_path = os.path.join(run_dir, "subject_binding", "decision_package.v0.1.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)
    return out_path


def write_route_b_reentry_record(run_dir: str, task_id: str, now_iso: str) -> str:
    decision_package_path = os.path.join(run_dir, "subject_binding", "decision_package.v0.1.json")
    blocking_rows: list[str] = []
    decision_context_ref = f"decision://{task_id}/formal-release"
    if os.path.exists(decision_package_path):
        with open(decision_package_path, "r", encoding="utf-8") as f:
            decision_package = json.load(f)
        decision_context_ref = decision_package.get("decision_context_ref", decision_context_ref)
        raw_blocking_rows = decision_package.get("blocking_rows", [])
        if isinstance(raw_blocking_rows, list):
            blocking_rows = [str(row) for row in raw_blocking_rows if str(row).strip()]

    if blocking_rows:
        payload = {
            "decision_context_ref": decision_context_ref,
            "reentry_state": "REENTRY_REQUESTED",
            "trigger_type": "capability_blocked",
            "source_decision_ref": decision_package_path,
            "supersedes_ref": decision_package_path,
            "carry_forward_issue_refs": blocking_rows,
            "re_entry_scope": {
                "blocked_stages": blocking_rows,
            },
            "generated_at": now_iso,
        }
    else:
        payload = {
            "decision_context_ref": decision_context_ref,
            "reentry_state": "NO_REENTRY",
            "trigger_type": None,
            "source_decision_ref": None,
            "supersedes_ref": None,
            "carry_forward_issue_refs": [],
            "re_entry_scope": None,
            "generated_at": now_iso,
        }
    out_path = os.path.join(run_dir, "subject_binding", "re_entry_record.v0.1.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)
    return out_path


def enforce_route_b_contract_fail_closed(run_dir: str) -> None:
    stage_dirs = [
        "v1_verilator_lint",
        "v2_verilator_sim",
        "v3_cdc_rdc",
        "v3b_cdc_signoff_lite",
        "v4_yosys_lec",
        "h1_yosys",
        "h2_openroad",
        "h5_opensta",
        "h3_netgen",
        "h4_klayout",
    ]
    capability_reentry_required = False
    for stage in stage_dirs:
        stage_dir = os.path.join(run_dir, stage)
        input_manifest_path = os.path.join(stage_dir, "input_manifest.json")
        evidence_bundle_path = os.path.join(stage_dir, "evidence_bundle.json")
        output_envelope_path = os.path.join(stage_dir, "output_envelope.json")
        if not os.path.exists(input_manifest_path) or not os.path.exists(evidence_bundle_path):
            continue

        with open(input_manifest_path, "r", encoding="utf-8") as f:
            input_manifest = json.load(f)
        if not input_manifest.get("capability_id") or not input_manifest.get("capability_profile_ref"):
            raise RuntimeError("route_b_contract_invalid:missing_capability_envelope_fields")

        if not os.path.exists(output_envelope_path):
            raise RuntimeError("route_b_contract_invalid:missing_output_envelope")
        with open(output_envelope_path, "r", encoding="utf-8") as f:
            output_envelope = json.load(f)
        for required_field in (
            "capability_id",
            "capability_profile_ref",
            "capability_verdict",
            "capability_blocking_reasons",
            "raw_artifact_refs",
            "normalized_output_ref",
            "decision_package_ref",
            "re_entry_record_ref",
        ):
            if required_field not in output_envelope:
                raise RuntimeError(f"route_b_contract_invalid:output_envelope_missing_{required_field}")
        if output_envelope.get("re_entry_recommendation") == "request_more_evidence":
            capability_reentry_required = True
        if output_envelope.get("capability_blocking_reasons"):
            capability_reentry_required = True

        with open(evidence_bundle_path, "r", encoding="utf-8") as f:
            evidence_bundle = json.load(f)
        if not evidence_bundle.get("raw_refs") or not evidence_bundle.get("normalized_refs"):
            raise RuntimeError("route_b_contract_invalid:missing_raw_normalized_mapping")

    decision_package_path = os.path.join(run_dir, "subject_binding", "decision_package.v0.1.json")
    if not os.path.exists(decision_package_path):
        raise RuntimeError("route_b_contract_invalid:missing_decision_package")
    with open(decision_package_path, "r", encoding="utf-8") as f:
        dp = json.load(f)
    candidate_decisions = dp.get("candidate_decisions") or []
    decision_state = dp.get("decision_state", "PRE_DECISION")
    decision_outcome = dp.get("decision_outcome")

    if decision_outcome is not None and decision_outcome not in candidate_decisions:
        raise RuntimeError("route_b_contract_invalid:decision_outcome_not_in_candidate_set")
    if decision_state == "PRE_DECISION" and decision_outcome is not None:
        raise RuntimeError("route_b_contract_invalid:pre_decision_state_with_outcome")
    if decision_state != "PRE_DECISION" and not decision_outcome:
        raise RuntimeError("route_b_contract_invalid:decision_state_without_outcome")
    if decision_state != "PRE_DECISION" and not dp.get("consumed_evidence_refs"):
        raise RuntimeError("route_b_contract_invalid:decision_outcome_missing_consumed_evidence_refs")

    reentry_path = os.path.join(run_dir, "subject_binding", "re_entry_record.v0.1.json")
    if not os.path.exists(reentry_path):
        raise RuntimeError("route_b_contract_invalid:missing_re_entry_record")
    with open(reentry_path, "r", encoding="utf-8") as f:
        reentry = json.load(f)
    reentry_state = reentry.get("reentry_state", "NO_REENTRY")
    if decision_outcome == "request_more_evidence" and reentry_state == "NO_REENTRY":
        raise RuntimeError("route_b_contract_invalid:re_entry_required_for_request_more_evidence")
    if capability_reentry_required and reentry_state == "NO_REENTRY":
        raise RuntimeError("route_b_contract_invalid:re_entry_required_for_capability_blocked")
    if reentry_state != "NO_REENTRY":
        if not reentry.get("supersedes_ref"):
            raise RuntimeError("route_b_contract_invalid:re_entry_missing_supersedes_ref")
        carry_forward_issue_refs = reentry.get("carry_forward_issue_refs")
        if not isinstance(carry_forward_issue_refs, list) or not carry_forward_issue_refs:
            raise RuntimeError("route_b_contract_invalid:re_entry_missing_carry_forward_issue_refs")
