"""Stage runner modules for governed pipeline decomposition.

This package is introduced under ARCH-GAP-001 to keep orchestration and
per-stage execution separated.
"""
