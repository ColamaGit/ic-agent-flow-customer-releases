#!/usr/bin/env python3
from __future__ import annotations

import os
from typing import Callable, Dict, List


def run_post_h_flow_actions(
    *,
    run_dir: str,
    task_id: str,
    write_timing_exception_review_artifact: Callable[[str], str | None],
    augment_capability_contract_artifacts: Callable[[str, str], Dict[str, str]],
    write_route_b_decision_package: Callable[[str, str], str],
    write_route_b_reentry_record: Callable[[str, str], str],
    enforce_route_b_contract_fail_closed: Callable[[str], None],
) -> List[Dict]:
    rows: List[Dict] = []

    timing_review_ref = write_timing_exception_review_artifact(run_dir)
    if timing_review_ref:
        rows.append(
            {
                "stage": "timing_exception_review",
                "output_dir": os.path.dirname(timing_review_ref),
                "status": "DONE",
                "review_ref": timing_review_ref,
                "detail": "bounded timing exception review artifact emitted",
            }
        )

    contract_refs = augment_capability_contract_artifacts(run_dir, task_id)
    decision_package_ref = write_route_b_decision_package(run_dir, task_id)
    reentry_record_ref = write_route_b_reentry_record(run_dir, task_id)
    enforce_route_b_contract_fail_closed(run_dir)
    rows.append(
        {
            "stage": "route_b_b0_contract_materialization",
            "output_dir": os.path.join(run_dir, "subject_binding"),
            "status": "DONE",
            "detail": "capability envelope + decision package + re-entry record materialized and fail-closed validated",
            "contract_ref_count": len(contract_refs),
            "decision_package_ref": decision_package_ref,
            "reentry_record_ref": reentry_record_ref,
        }
    )

    return rows
