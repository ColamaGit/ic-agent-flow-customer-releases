import hashlib
import json
import os
import argparse
from datetime import datetime, timezone, timedelta
from pathlib import Path

tz_tw = timezone(timedelta(hours=8))

REPO_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_PRODUCTION_RUNS_DIR = REPO_ROOT / "artifacts" / "production-runs"
DEFAULT_OUT_JSON = REPO_ROOT / "workspace" / "portfolio" / "summaries" / "production_runs_inventory.json"
DEFAULT_CACHE_JSON = REPO_ROOT / "workspace" / "portfolio" / "summaries" / "production_runs_inventory.cache.json"
DEFAULT_LAYERED_ROOT = REPO_ROOT / "workspace" / "portfolio" / "summaries" / "layered_inventory"
CACHE_VERSION = 2

CHIP_ALIAS = {
    "test-chip-02": "SN2025",
    "uart-controller-v0.1": "UART",
    "async-fifo-v0.1": "ASYNC_FIFO",
}

PREVIEW_SUFFIXES = {".md", ".json", ".log", ".svg"}
MAX_PREVIEW_BYTES = 64 * 1024

# Knowledge / skill backflow mapping files are consumed by the console via JSON.parse().
# If they exceed MAX_PREVIEW_BYTES the preview_text is truncated mid-JSON, causing a
# parse failure that silently drops the entire chip from Knowledge Asset Center.
# These specific files require a higher limit to guarantee valid JSON in the snapshot.
EXTENDED_PREVIEW_BYTES = 256 * 1024
_EXTENDED_PREVIEW_STEMS = (
    "knowledge_backflow_alignment_mapping",
    "skill_backflow_report_mapping",
)


def _preview_limit(path: Path) -> int:
    """Return the preview byte limit for *path*.

    Files whose stem starts with a name in ``_EXTENDED_PREVIEW_STEMS`` use the
    extended limit so that the console can always JSON.parse() them without
    hitting a mid-byte truncation boundary.
    """
    stem = path.stem
    for prefix in _EXTENDED_PREVIEW_STEMS:
        if stem.startswith(prefix):
            return EXTENDED_PREVIEW_BYTES
    return MAX_PREVIEW_BYTES


def build_preview_text(path: Path):
    """Return preview text for *path*, or None if the file should not be previewed."""
    if path.suffix.lower() not in PREVIEW_SUFFIXES:
        return None
    try:
        limit = _preview_limit(path)
        raw = path.read_bytes()[:limit]
        return raw.decode("utf-8", errors="replace")
    except Exception:
        return None


def collect_execution_files(execution_dir: Path) -> list[dict]:
    files: list[dict] = []
    for root, dirnames, filenames in os.walk(execution_dir, topdown=True, followlinks=False):
        root_path = Path(root)
        dirnames[:] = sorted(name for name in dirnames if not (root_path / name).is_symlink())
        filenames = sorted(name for name in filenames if not (root_path / name).is_symlink())

        if root_path != execution_dir:
            rel_dir = root_path.relative_to(execution_dir).as_posix()
            files.append(
                {
                    "relative_path": rel_dir,
                    "kind": "dir",
                    "size_bytes": 0,
                }
            )

        for filename in filenames:
            node = root_path / filename
            try:
                rel = node.relative_to(execution_dir).as_posix()
                files.append(
                    {
                        "relative_path": rel,
                        "kind": "file",
                        "size_bytes": node.stat().st_size,
                        "preview_text": build_preview_text(node),
                    }
                )
            except FileNotFoundError:
                continue
            except OSError:
                continue
    return files


def _execution_cache_key(production_runs_dir: Path, execution_dir: Path) -> str:
    return execution_dir.relative_to(production_runs_dir).as_posix()


def _execution_cache_signature(execution_dir: Path) -> str:
    digest = hashlib.sha256()
    for root, dirnames, filenames in os.walk(execution_dir, topdown=True, followlinks=False):
        root_path = Path(root)
        dirnames[:] = sorted(name for name in dirnames if not (root_path / name).is_symlink())
        for filename in sorted(name for name in filenames if not (root_path / name).is_symlink()):
            node = root_path / filename
            try:
                stat = node.stat()
                rel = node.relative_to(execution_dir).as_posix()
            except (FileNotFoundError, OSError):
                continue
            digest.update(rel.encode("utf-8"))
            digest.update(str(stat.st_size).encode("ascii"))
            digest.update(str(stat.st_mtime_ns).encode("ascii"))
    return digest.hexdigest()


def build_inventory_with_cache(production_runs_dir: Path, cache_payload: dict | None = None) -> tuple[dict, dict, dict]:
    cache_payload = cache_payload or {}
    cached_executions = cache_payload.get("executions", {}) if cache_payload.get("cache_version") == CACHE_VERSION else {}
    next_cache = {"cache_version": CACHE_VERSION, "executions": {}}
    stats = {"scanned_execution_count": 0, "reused_execution_count": 0}

    chips = []
    if production_runs_dir.exists():
        for chip_dir in sorted([d for d in production_runs_dir.iterdir() if d.is_dir()], key=lambda p: p.name):
            task_dirs = sorted([d for d in chip_dir.iterdir() if d.is_dir()], key=lambda p: p.name)
            runs = []
            for task_dir in task_dirs:
                execution_dirs = sorted([d for d in task_dir.iterdir() if d.is_dir()], key=lambda p: p.name)
                executions = []
                for execution_dir in execution_dirs:
                    cache_key = _execution_cache_key(production_runs_dir, execution_dir)
                    signature = _execution_cache_signature(execution_dir)
                    cached = cached_executions.get(cache_key)
                    if cached and cached.get("signature") == signature:
                        files = cached.get("files", [])
                        stats["reused_execution_count"] += 1
                    else:
                        files = collect_execution_files(execution_dir)
                        stats["scanned_execution_count"] += 1
                    next_cache["executions"][cache_key] = {
                        "signature": signature,
                        "files": files,
                    }
                    executions.append(
                        {
                            "execution_id": execution_dir.name,
                            "resolved_root": f"artifacts/production-runs/{chip_dir.name}/{task_dir.name}/{execution_dir.name}",
                            "files": files,
                        }
                    )
                runs.append(
                    {
                        "run_id": task_dir.name,
                        "executions": executions,
                    }
                )
            chips.append(
                {
                    "chip_id": CHIP_ALIAS.get(chip_dir.name, chip_dir.name.upper()),
                    "source_dir": chip_dir.name,
                    "runs": runs,
                }
            )

    return {
        "workspace_id": "ic-agent-flow-ws-01",
        "timestamp": datetime.now(tz_tw).isoformat(),
        "chips": chips,
    }, next_cache, stats


def build_inventory(production_runs_dir: Path) -> dict:
    payload, _cache, _stats = build_inventory_with_cache(production_runs_dir)
    return payload


def _extract_latest_decision_disposition(files: list[dict]) -> tuple[str, str]:
    import json
    from datetime import datetime
    try:
        from zoneinfo import ZoneInfo
        tz_taipei = ZoneInfo("Asia/Taipei")
    except ImportError:
        tz_taipei = None

    candidates = []

    for file in files:
        if file.get("kind") != "file":
            continue
        rel_path = str(file.get("relative_path", ""))
        preview = str(file.get("preview_text") or "")
        if not preview.strip().startswith("{"):
            continue

        try:
            parsed = json.loads(preview)
        except Exception:
            continue

        weight = None
        disposition = None
        timestamp = None

        # 1. decision_action_result_record / dashboard_action_result_record
        if rel_path.endswith("decision_action_result_record.json") or rel_path.endswith("dashboard_action_result_record.json"):
            weight = 1
            disposition = parsed.get("decision_status_after") or parsed.get("result_status")
            timestamp = parsed.get("updated_at") or parsed.get("action_at") or parsed.get("timestamp")
        # 2. downstream_decision_action_binding
        elif rel_path.endswith("downstream_decision_action_binding.json"):
            weight = 2
            disposition = parsed.get("decision_status_after")
            timestamp = parsed.get("updated_at") or parsed.get("action_at") or parsed.get("timestamp")
        # 3. human_decision_queue items
        elif rel_path.endswith("human_decision_queue.json"):
            items = []
            if isinstance(parsed, list):
                items = parsed
            elif isinstance(parsed, dict):
                items = parsed.get("items") or []
            for item in items:
                item_disp = item.get("decision_status_after") or item.get("status")
                item_ts = item.get("updated_at") or item.get("action_at") or item.get("timestamp")
                if item_disp:
                    candidates.append({
                        "weight": 3,
                        "disposition": str(item_disp).upper(),
                        "timestamp": str(item_ts) if item_ts else None
                    })
            continue

        if weight and disposition:
            candidates.append({
                "weight": weight,
                "disposition": str(disposition).upper(),
                "timestamp": str(timestamp) if timestamp else None
            })

    if not candidates:
        return "PENDING", "TECHNICAL_EVIDENCE"

    def get_ts_val(cand):
        ts = cand.get("timestamp")
        if not ts:
            return datetime.min.replace(tzinfo=tz_taipei) if tz_taipei else datetime.min
        try:
            # Simple ISO conversion
            return datetime.fromisoformat(ts)
        except Exception:
            return datetime.min.replace(tzinfo=tz_taipei) if tz_taipei else datetime.min

    # Sort primarily by timestamp descending, and secondarily by weight ascending
    candidates_sorted = sorted(candidates, key=lambda c: (get_ts_val(c), -c["weight"]), reverse=True)
    best = candidates_sorted[0]

    disp = best["disposition"]
    if disp in {"APPROVED", "PASS", "OK"}:
        return "APPROVED", "HUMAN_DECISION_APPROVED"
    elif disp in {"APPROVED_WITH_CONDITIONS", "CONDITIONAL_PASS"}:
        return "APPROVED_WITH_CONDITIONS", "HUMAN_DECISION_APPROVED_WITH_CONDITIONS"
    elif disp in {"WAIVED", "WAIVER"}:
        return "WAIVED", "HUMAN_DECISION_WAIVED_WITH_RISK"

    return disp, f"HUMAN_DECISION_{disp}"


def _extract_fail_closed_blockers(files: list[dict], evidence_verdict: str) -> list[str]:
    if evidence_verdict != "BLOCKED":
        return []

    blockers = []
    seen_blockers = set()

    def add_blocker(msg: str):
        # 實施絕對物理路徑去敏防禦，屏蔽開發者本機敏感路徑
        clean_msg = msg.strip().replace("/customer-home/imac", "")
        if clean_msg and clean_msg not in seen_blockers:
            seen_blockers.add(clean_msg)
            blockers.append(clean_msg)

    for file in files:
        if file.get("kind") != "file":
            continue
        rel_path = str(file.get("relative_path", ""))
        preview = str(file.get("preview_text") or "")
        if not preview.strip().startswith("{"):
            continue

        try:
            parsed = json.loads(preview)

            # 1. pipeline_assembly_log.json
            if rel_path.endswith("pipeline_assembly_log.json"):
                for stage in parsed.get("assembly_log", []):
                    if stage.get("status") == "FAIL":
                        stage_name = stage.get("stage", "unknown")
                        stage_detail = stage.get("detail", "Failed without detail")
                        add_blocker(f"[{stage_name}] {stage_detail}")

            # 2. enterprise_certification_gate_results.json
            elif rel_path.endswith("enterprise_certification_gate_results.json"):
                if parsed.get("overall_verdict") != "PASS":
                    for cp in parsed.get("authority_checkpoints", []):
                        if cp.get("status") != "PASS":
                            missing = cp.get("missing_refs", [])
                            missing_str = f" (missing: {', '.join(missing)})" if missing else ""
                            add_blocker(f"[{cp.get('id', 'unknown')}] {cp.get('title', 'Failed checkpoint')}{missing_str}")

            # 3. EDA Preflight Gate
            elif rel_path.endswith("environment_adjudication.json") or rel_path.endswith("normalized_toolchain_resolution_record.json"):
                if parsed.get("status") not in {"PASS", "OK"}:
                    add_blocker(f"[eda_preflight] Resolving resolution failed: {parsed.get('reason') or parsed.get('status') or 'unresolved preflight'}")

            # 4. Smoke Run Gate
            elif rel_path.endswith("normalized.sim.meta.json"):
                if parsed.get("status") not in {"PASS", "OK"}:
                    add_blocker(f"[smoke_run] Simulator failed: {parsed.get('detail') or parsed.get('reason') or 'smoke simulation fail'}")

            # 5. Evidence Complete Gate
            elif rel_path.endswith("readiness_report_manifest.v0.2.json"):
                if parsed.get("completeness_status") == "INCOMPLETE" or parsed.get("status") == "BLOCKED":
                    for err in parsed.get("validation_errors", []):
                        add_blocker(f"[evidence_integrity] {err}")

            # 6. Sign-off Decision Gate
            elif rel_path.endswith("final_tapeout_readiness_record.json"):
                if parsed.get("status") in {"BLOCKED", "INVALID"}:
                    add_blocker(f"[signoff_gate] {parsed.get('status_reason') or 'final tapeout readiness blocked'}")

        except Exception:
            pass

    # 兜底防禦：如果被判定為 BLOCKED，但沒有成功解析出 any 具體阻斷原因
    if not blockers:
        blockers.append("BLOCKED_REASON_SOURCE_MISSING")

    return blockers


def _classify_execution_with_decision_projection(files: list[dict]) -> dict:
    statuses: list[str] = []
    pass_token_in_log = False

    for file in files:
        if file.get("kind") != "file":
            continue
        rel_path = str(file.get("relative_path", ""))
        preview = str(file.get("preview_text") or "")
        if "normalized." in rel_path and rel_path.endswith(".json") and preview.strip().startswith("{"):
            try:
                parsed = json.loads(preview)
                status = str(parsed.get("status", "")).upper()
                if status:
                    statuses.append(status)
            except Exception:
                continue
        if rel_path.endswith("raw.log") and any(token in preview for token in ("REAL_RUN_PASS", "_PASS", " PASS")):
            pass_token_in_log = True

    decision_disposition, reason = _extract_latest_decision_disposition(files)

    if any(status in {"FAIL", "BLOCKED", "ERROR"} for status in statuses):
        evidence_verdict = "BLOCKED"
    elif any(status in {"NOT_CHECKED", "WARNING", "WARN", "PENDING", "UNVALIDATED", "PARTIAL"} for status in statuses):
        evidence_verdict = "WARN"
    elif any(status in {"PASS", "OK"} for status in statuses) or pass_token_in_log:
        evidence_verdict = "PASS"
    else:
        evidence_verdict = "UNKNOWN"

    if decision_disposition == "APPROVED":
        effective_dashboard_status = "PASS"
    elif decision_disposition == "APPROVED_WITH_CONDITIONS":
        effective_dashboard_status = "WARN"  # APPROVED_WITH_CONDITIONS mapped to WARN
    elif decision_disposition == "WAIVED":
        effective_dashboard_status = "WARN"  # WAIVER is not PASS! WAIVED mapped to WARN
    elif decision_disposition == "PENDING":
        effective_dashboard_status = evidence_verdict
    else:
        effective_dashboard_status = evidence_verdict

    fail_closed_blockers = _extract_fail_closed_blockers(files, evidence_verdict)

    return {
        "verdict": evidence_verdict,                               # Keep legacy alias as technical truth
        "evidence_verdict": evidence_verdict,
        "decision_disposition": decision_disposition,
        "effective_dashboard_status": effective_dashboard_status,
        "effective_dashboard_status_reason": reason,
        "technical_evidence_rewritten": False,
        "status_signals": statuses,
        "fail_closed_blockers": fail_closed_blockers
    }


def _classify_execution(files: list[dict]) -> dict:
    # Retained legacy _classify_execution wrapper for safety
    res = _classify_execution_with_decision_projection(files)
    # Legacy wrapper returnedPASS for APPROVED for compat
    if res["decision_disposition"] == "APPROVED":
        return {"verdict": "PASS", "status_signals": res["status_signals"]}
    return {"verdict": res["verdict"], "status_signals": res["status_signals"]}


def build_layered_inventory(payload: dict) -> tuple[dict, dict[str, dict], dict[str, dict]]:
    chips_l1: list[dict] = []
    l2_runs_by_source_dir: dict[str, dict] = {}
    l3_run_details_by_key: dict[str, dict] = {}

    for chip in payload.get("chips", []):
        source_dir = str(chip.get("source_dir", ""))
        chip_id = str(chip.get("chip_id", source_dir.upper()))
        runs = chip.get("runs", [])
        l2_runs: list[dict] = []
        chip_verdict_summary = {"pass": 0, "warn": 0, "blocked": 0, "unknown": 0, "total": 0}

        signoff_status = "NOT_AVAILABLE"
        tapeout_status = "NOT_AVAILABLE"
        silicon_status = "NOT_AVAILABLE"

        raw_latest_run = runs[-1] if runs else None
        raw_latest_exec = raw_latest_run["executions"][-1] if raw_latest_run and raw_latest_run["executions"] else None
        if raw_latest_exec:
            for file in raw_latest_exec.get("files", []):
                rel_path = str(file.get("relative_path", ""))
                preview = str(file.get("preview_text") or "")
                if rel_path.endswith("final_tapeout_readiness_record.json") and preview.strip().startswith("{"):
                    try:
                        signoff_status = json.loads(preview).get("status", "NOT_AVAILABLE")
                    except Exception:
                        pass
                elif rel_path.endswith("tapeout_package_manifest.json") and preview.strip().startswith("{"):
                    try:
                        tapeout_status = json.loads(preview).get("status", "NOT_AVAILABLE")
                    except Exception:
                        pass
                elif rel_path.endswith("v115_silicon_proven_claim_record.json") and preview.strip().startswith("{"):
                    try:
                        silicon_status = json.loads(preview).get("status", "NOT_AVAILABLE")
                    except Exception:
                        pass

        chip_evidence_summary = {"pass": 0, "warn": 0, "blocked": 0, "unknown": 0, "total": 0}
        chip_effective_summary = {"pass": 0, "warn": 0, "blocked": 0, "unknown": 0, "total": 0}

        for run in runs:
            run_id = str(run.get("run_id", ""))
            executions = run.get("executions", [])
            execution_summaries: list[dict] = []

            # 使用 canonical execution_id (YYYYMMDD-HHMMSS) 降序排序，保證最晚(最新)時間的執行排在最前面
            executions_sorted = sorted(executions, key=lambda e: e.get("execution_id", ""), reverse=True)
            for execution in executions_sorted:
                execution_id = str(execution.get("execution_id", ""))
                resolved_root = str(execution.get("resolved_root", ""))
                files = execution.get("files", [])
                classified = _classify_execution_with_decision_projection(files)
                verdict = classified["verdict"]
                ev = classified["evidence_verdict"]
                eds = classified["effective_dashboard_status"]

                # 1. Increment legacy/evidence summary
                if ev == "PASS":
                    chip_evidence_summary["pass"] += 1
                elif ev == "WARN":
                    chip_evidence_summary["warn"] += 1
                elif ev == "BLOCKED":
                    chip_evidence_summary["blocked"] += 1
                else:
                    chip_evidence_summary["unknown"] += 1
                chip_evidence_summary["total"] += 1

                # 2. Increment effective summary
                if eds == "PASS":
                    chip_effective_summary["pass"] += 1
                elif eds == "WARN":
                    chip_effective_summary["warn"] += 1
                elif eds == "BLOCKED":
                    chip_effective_summary["blocked"] += 1
                else:
                    chip_effective_summary["unknown"] += 1
                chip_effective_summary["total"] += 1

                execution_summaries.append(
                    {
                        "execution_id": execution_id,
                        "resolved_root": resolved_root,
                        "file_count": len(files),
                        "verdict": verdict,  # remains technical truth (evidence_verdict)
                        "evidence_verdict": ev,
                        "decision_disposition": classified["decision_disposition"],
                        "effective_dashboard_status": eds,
                        "effective_dashboard_status_reason": classified["effective_dashboard_status_reason"],
                        "technical_evidence_rewritten": classified["technical_evidence_rewritten"],
                        "fail_closed_blockers": classified.get("fail_closed_blockers", [])
                    }
                )

            l2_runs.append(
                {
                    "run_id": run_id,
                    "execution_count": len(executions),
                    "executions": execution_summaries,
                }
            )
            l3_run_details_by_key[f"{source_dir}:{run_id}"] = {
                "schema_version": "production-runs-layer3-run-detail.v1",
                "workspace_id": payload.get("workspace_id", "ic-agent-flow-ws-01"),
                "timestamp": payload.get("timestamp"),
                "chip_id": chip_id,
                "source_dir": source_dir,
                "run_id": run_id,
                "executions": executions,
            }

        latest_run = l2_runs[-1] if l2_runs else None
        # 由於 executions 已降序排列，最新執行應為 index 0 而非 -1，以避免 INCIDENTAL 陣列排序猜測
        latest_exec = latest_run["executions"][0] if latest_run and latest_run["executions"] else None
        chips_l1.append(
            {
                "chip_id": chip_id,
                "source_dir": source_dir,
                "run_count": len(l2_runs),
                "latest_run_id": latest_run["run_id"] if latest_run else None,
                "latest_execution_id": latest_exec["execution_id"] if latest_exec else None,
                "verdict_summary": chip_evidence_summary,  # verdict_summary defined as legacy alias of evidence_verdict_summary
                "evidence_verdict_summary": chip_evidence_summary,
                "effective_dashboard_summary": chip_effective_summary,
                "latest_signoff_status": signoff_status,
                "latest_tapeout_status": tapeout_status,
                "latest_silicon_status": silicon_status,
                "latest_execution_fail_closed_blockers": latest_exec.get("fail_closed_blockers", []) if latest_exec else []
            }
        )
        l2_runs_by_source_dir[source_dir] = {
            "schema_version": "production-runs-layer2-runs.v1",
            "workspace_id": payload.get("workspace_id", "ic-agent-flow-ws-01"),
            "timestamp": payload.get("timestamp"),
            "chip_id": chip_id,
            "source_dir": source_dir,
            "runs": l2_runs,
        }

    l1_payload = {
        "schema_version": "production-runs-layer1-chips.v1",
        "workspace_id": payload.get("workspace_id", "ic-agent-flow-ws-01"),
        "timestamp": payload.get("timestamp"),
        "chip_count": len(chips_l1),
        "chips": chips_l1,
    }
    return l1_payload, l2_runs_by_source_dir, l3_run_details_by_key


def write_layered_inventory(layered_root: Path, l1_payload: dict, l2_runs_by_source_dir: dict[str, dict], l3_run_details_by_key: dict[str, dict]) -> None:
    layered_root.mkdir(parents=True, exist_ok=True)
    (layered_root / "chips.json").write_text(json.dumps(l1_payload, indent=2), encoding="utf-8")

    l2_dir = layered_root / "runs"
    l2_dir.mkdir(parents=True, exist_ok=True)
    for source_dir, payload in l2_runs_by_source_dir.items():
        (l2_dir / f"{source_dir}.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    l3_dir = layered_root / "details"
    l3_dir.mkdir(parents=True, exist_ok=True)
    for key, payload in l3_run_details_by_key.items():
        source_dir, run_id = key.split(":", 1)
        chip_dir = l3_dir / source_dir
        chip_dir.mkdir(parents=True, exist_ok=True)
        (chip_dir / f"{run_id}.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")


def load_cache(cache_json: Path) -> dict | None:
    try:
        if not cache_json.exists():
            return None
        return json.loads(cache_json.read_text(encoding="utf-8"))
    except Exception:
        return None


def save_cache(cache_json: Path, cache_payload: dict) -> None:
    cache_json.parent.mkdir(parents=True, exist_ok=True)
    cache_json.write_text(json.dumps(cache_payload, indent=2), encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate production-runs inventory for console artifact explorer.")
    parser.add_argument(
        "--artifacts-root",
        default=str(DEFAULT_PRODUCTION_RUNS_DIR),
        help="Path to artifacts/production-runs root. Supports package-extract locations.",
    )
    parser.add_argument(
        "--output",
        default=str(DEFAULT_OUT_JSON),
        help="Output json path (default: package_ws/portfolio/summaries/production_runs_inventory.json).",
    )
    parser.add_argument(
        "--cache-file",
        default=str(DEFAULT_CACHE_JSON),
        help="Optional cache json path for reusing unchanged execution listings.",
    )
    parser.add_argument(
        "--layered-root",
        default=str(DEFAULT_LAYERED_ROOT),
        help="Output directory for layered inventory shards (L1/L2/L3).",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    production_runs_dir = Path(args.artifacts_root).resolve()
    out_json = Path(args.output).resolve()
    cache_json = Path(args.cache_file).resolve()
    layered_root = Path(args.layered_root).resolve()

    cache_payload = load_cache(cache_json)
    payload, next_cache, stats = build_inventory_with_cache(production_runs_dir, cache_payload)
    out_json.parent.mkdir(parents=True, exist_ok=True)
    out_json.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    save_cache(cache_json, next_cache)
    l1_payload, l2_runs_by_source_dir, l3_run_details_by_key = build_layered_inventory(payload)
    write_layered_inventory(layered_root, l1_payload, l2_runs_by_source_dir, l3_run_details_by_key)
    print(f"Wrote {out_json}")
    print(f"Wrote layered inventory root: {layered_root}")
    print(f"Inventory source: {production_runs_dir}")
    print(
        "Inventory cache stats: "
        f"scanned={stats['scanned_execution_count']} "
        f"reused={stats['reused_execution_count']}"
    )


if __name__ == "__main__":
    main()
