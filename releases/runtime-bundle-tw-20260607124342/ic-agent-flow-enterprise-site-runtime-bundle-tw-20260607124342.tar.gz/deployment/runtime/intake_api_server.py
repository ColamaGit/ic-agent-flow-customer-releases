#!/usr/bin/env python3
from __future__ import annotations

import argparse
import base64
import fcntl
import hashlib
import json
import os
import re
import subprocess
import tempfile
import sys
from datetime import datetime, timezone, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Dict
from urllib.parse import parse_qs, urlparse
from uuid import uuid4

from run_requirement_intake import discover_templates, run_requirement_intake
from intake_api_http import handle_get_request, handle_post_request


REQUIRED_FIELDS = ("chip_id", "prompt_text")
TZ_TW = timezone(timedelta(hours=8))


def _tw_stamp() -> str:
    return datetime.now(TZ_TW).strftime("%Y%m%d-%H%M%S")


def _find_repo_root(start: Path) -> Path:
    for candidate in [start, *start.parents]:
        if (candidate / "templates").exists() and (candidate / "workspace").exists():
            return candidate
    # fallback: current working directory
    return Path.cwd()


REPO_ROOT = _find_repo_root(Path(__file__).resolve())
DEFAULT_TEMPLATES_ROOT = (REPO_ROOT / "templates").as_posix()
DEFAULT_WORKSPACE_MANIFEST = (REPO_ROOT / "workspace" / "workspace_manifest.yaml").as_posix()
DEFAULT_LAYERED_INVENTORY_ROOT = REPO_ROOT / "workspace" / "portfolio" / "summaries" / "layered_inventory"
SHARED_RUNTIME_LIB = REPO_ROOT / "workspace" / "shared-runtime" / "lib"
SERVER_BOOT_TOKEN = f"intake-{uuid4().hex}"
SERVER_STARTED_AT = datetime.now(TZ_TW).isoformat()


def get_current_package_mode() -> str:
    manifest_path = REPO_ROOT / "runtime" / "package_capabilities" / "customer_mode_entitlement_manifest.v1.json"
    if manifest_path.exists():
        try:
            with open(manifest_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                return data.get("mode", "team_project")
        except Exception:
            pass
    return "team_project"

if str(SHARED_RUNTIME_LIB) not in __import__("sys").path:
    __import__("sys").path.insert(0, str(SHARED_RUNTIME_LIB))

from ic_agent_flow.governance.v10_freeze_to_plan import (
    REQUIRED_FREEZE_PRECONDITIONS,
    REQUIRED_GENERATION_PLAN_FIELDS,
)
from ic_agent_flow.dashboard.downstream_decision_backend import (
    build_dashboard_action_bundle,
    build_console_decision_write_record,
    build_downstream_decision_entrypoint_preview,
)
from ic_agent_flow.dashboard.live_console_action_records import (
    append_console_action_records,
    resolve_console_action_record_ref,
    resolve_console_actions_dir,
)
from ic_agent_flow.dashboard.decision_queue_item import build_decision_queue_item_v18
from ic_agent_flow.governance.upstream_alignment_map import _relative_ref, ensure_upstream_alignment_map


def _materialize_inline_attachments(chip_id: str, inline_items: list[dict]) -> list[str]:
    if not inline_items:
        return []
    root = Path(tempfile.gettempdir()) / "ic-agent-flow-intake-uploads" / chip_id / _tw_stamp()
    root.mkdir(parents=True, exist_ok=True)

    paths: list[str] = []
    for item in inline_items:
        filename = str(item.get("filename", "")).strip()
        content_base64 = str(item.get("content_base64", "")).strip()
        if not filename or not content_base64:
            raise ValueError("invalid_attachments_inline")
        decoded = base64.b64decode(content_base64, validate=True)
        out = root / filename
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(decoded)
        paths.append(out.as_posix())
    return paths


def process_intake_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    for field in REQUIRED_FIELDS:
        value = payload.get(field)
        if not isinstance(value, str) or not value.strip():
            raise ValueError(f"missing_field:{field}")

    no_match_action = str(payload.get("no_match_action", "B")).upper()
    if no_match_action not in {"B", "C"}:
        raise ValueError("invalid_no_match_action")

    attachment_paths = payload.get("attachment_paths", [])
    if not isinstance(attachment_paths, list) or not all(isinstance(x, str) for x in attachment_paths):
        raise ValueError("invalid_attachment_paths")

    attachments_inline = payload.get("attachments_inline", [])
    if attachments_inline and not isinstance(attachments_inline, list):
        raise ValueError("invalid_attachments_inline")

    inline_paths = _materialize_inline_attachments(payload["chip_id"], attachments_inline)
    merged_attachment_paths = attachment_paths + inline_paths

    record = run_requirement_intake(
        chip_id=payload["chip_id"],
        prompt_text=payload["prompt_text"],
        attachment_paths=merged_attachment_paths,
        no_match_action=no_match_action,
        workspace_manifest_path=str(payload.get("workspace_manifest_path", DEFAULT_WORKSPACE_MANIFEST)),
        templates_root=str(payload.get("templates_root", DEFAULT_TEMPLATES_ROOT)),
        template_override_ref=payload.get("template_override_ref"),
    )
    if record.get("status") != "PENDING_TEMPLATE":
        chip_root = REPO_ROOT / "chips" / str(record.get("chip_id", payload["chip_id"]))
        if chip_root.exists():
            _ensure_human_review_companions(chip_root)
    return record


def _normalize_chip_alias(value: str) -> str:
    normalized = []
    last_was_sep = False
    for char in value.strip().lower():
        if char.isalnum():
            normalized.append(char)
            last_was_sep = False
        elif not last_was_sep:
            normalized.append("_")
            last_was_sep = True
    return "".join(normalized).strip("_")


def _chip_alias_matches(candidate_name: str, alias: str) -> bool:
    candidate = _normalize_chip_alias(candidate_name)
    normalized_alias = _normalize_chip_alias(alias)
    if not normalized_alias:
        return False
    if candidate == normalized_alias:
        return True
    return normalized_alias in candidate.split("_")


def _resolve_chip_root(chip_id_raw: str) -> Path:
    chip_id = str(chip_id_raw).strip()
    if not chip_id:
        raise ValueError("missing_field:chip_id")
    chip_root = (REPO_ROOT / "chips" / chip_id).resolve()
    allowed_root = (REPO_ROOT / "chips").resolve()
    if not str(chip_root).startswith(str(allowed_root)):
        raise ValueError("chip_root_out_of_scope")
    if chip_root.exists():
        return chip_root

    chips_root = allowed_root
    candidates = []
    if chips_root.exists():
        candidates = [
            child.resolve()
            for child in chips_root.iterdir()
            if child.is_dir() and _chip_alias_matches(child.name, chip_id)
        ]

    if len(candidates) == 1:
        return candidates[0]
    if len(candidates) > 1:
        raise ValueError(f"AMBIGUOUS_CHIP_ALIAS:{chip_id}")
    raise FileNotFoundError(f"CHIP_ALIAS_NOT_FOUND:{chip_id}")


def _read_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _write_json(path: Path, payload: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def _atomic_write_json(path: Path, payload: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + f".tmp.{uuid4().hex}")
    try:
        tmp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        os.replace(tmp, path)
    finally:
        if tmp.exists():
            tmp.unlink()


def _fingerprint_adjudication_payload(
    *,
    chip_id: str,
    decision_outcome: str,
    decision_rationale: str,
    authority_signer: str,
    conditions: list[str],
) -> str:
    canonical = {
        "chip_id": chip_id,
        "decision_outcome": decision_outcome,
        "decision_rationale": decision_rationale,
        "authority_signer": authority_signer,
        "conditions": conditions,
    }
    data = json.dumps(canonical, ensure_ascii=False, sort_keys=True).encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def _write_markdown(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content.rstrip() + "\n", encoding="utf-8")


def _format_md_list(items: Any, fallback: str = "- none") -> list[str]:
    if not isinstance(items, list) or not items:
        return [fallback]
    lines: list[str] = []
    for item in items:
        if isinstance(item, dict):
            label = item.get("requirement_id") or item.get("id") or item.get("title") or "item"
            title = item.get("title") or item.get("description") or ""
            ambiguity = item.get("ambiguity_status") or item.get("status")
            suffix = f" — {title}" if title and title != label else ""
            ambiguity_suffix = f" (`{ambiguity}`)" if ambiguity else ""
            lines.append(f"- `{label}`{suffix}{ambiguity_suffix}")
        else:
            lines.append(f"- {item}")
    return lines


def _safe_read_json(path: Path) -> Dict[str, Any]:
    if not path.exists():
        return {}
    return _read_json(path)


def _load_layered_l1_payload() -> Dict[str, Any]:
    path = DEFAULT_LAYERED_INVENTORY_ROOT / "chips.json"
    if not path.exists():
        raise FileNotFoundError(f"missing_layered_inventory:{path.as_posix()}")
    payload = _read_json(path)
    if "chips" in payload and isinstance(payload["chips"], list):
        for chip in payload["chips"]:
            source_dir = chip.get("source_dir", "")
            if not source_dir:
                continue
            try:
                l2_path = DEFAULT_LAYERED_INVENTORY_ROOT / "runs" / f"{source_dir}.json"
                if not l2_path.exists():
                    continue
                l2_payload = _read_json(l2_path)
                valid_runs = []
                verdict_summary = {"pass": 0, "warn": 0, "blocked": 0, "unknown": 0, "total": 0}
                evidence_verdict_summary = {"pass": 0, "warn": 0, "blocked": 0, "unknown": 0, "total": 0}
                effective_dashboard_summary = {"pass": 0, "warn": 0, "blocked": 0, "unknown": 0, "total": 0}
                latest_run_id = None
                latest_execution_id = None
                if "runs" in l2_payload and isinstance(l2_payload["runs"], list):
                    for run in l2_payload["runs"]:
                        if "executions" in run and isinstance(run["executions"], list):
                            valid_execs = []
                            for ex in run["executions"]:
                                resolved_root_str = ex.get("resolved_root", "")
                                if resolved_root_str:
                                    exec_dir = REPO_ROOT / resolved_root_str
                                    if exec_dir.exists() and exec_dir.is_dir():
                                        valid_execs.append(ex)

                                        # Legacy alias summary
                                        v = str(ex.get("verdict", "")).lower()
                                        if v in verdict_summary:
                                            verdict_summary[v] += 1
                                        else:
                                            verdict_summary["unknown"] += 1
                                        verdict_summary["total"] += 1

                                        # Evidence technical summary
                                        ev = str(ex.get("evidence_verdict") or ex.get("verdict", "")).lower()
                                        if ev in evidence_verdict_summary:
                                            evidence_verdict_summary[ev] += 1
                                        else:
                                            evidence_verdict_summary["unknown"] += 1
                                        evidence_verdict_summary["total"] += 1

                                        # Effective dashboard summary
                                        eds = str(ex.get("effective_dashboard_status") or ex.get("verdict", "")).lower()
                                        if eds in effective_dashboard_summary:
                                            effective_dashboard_summary[eds] += 1
                                        else:
                                            effective_dashboard_summary["unknown"] += 1
                                        effective_dashboard_summary["total"] += 1

                            if valid_execs:
                                run["executions"] = valid_execs
                                run["execution_count"] = len(valid_execs)
                                valid_runs.append(run)
                                latest_run_id = run.get("run_id")
                                latest_execution_id = valid_execs[-1].get("execution_id") if valid_execs else None
                chip["run_count"] = len(valid_runs)
                chip["latest_run_id"] = latest_run_id
                chip["latest_execution_id"] = latest_execution_id
                chip["verdict_summary"] = verdict_summary
                chip["evidence_verdict_summary"] = evidence_verdict_summary
                chip["effective_dashboard_summary"] = effective_dashboard_summary
            except Exception:
                pass
    return payload


def _load_layered_l2_payload(source_dir: str) -> Dict[str, Any]:
    path = DEFAULT_LAYERED_INVENTORY_ROOT / "runs" / f"{source_dir}.json"
    if not path.exists():
        raise FileNotFoundError(f"missing_layered_inventory:{path.as_posix()}")
    payload = _read_json(path)
    if "runs" in payload and isinstance(payload["runs"], list):
        for run in payload["runs"]:
            if "executions" in run and isinstance(run["executions"], list):
                valid_execs = []
                for ex in run["executions"]:
                    resolved_root_str = ex.get("resolved_root", "")
                    if resolved_root_str:
                        exec_dir = REPO_ROOT / resolved_root_str
                        if exec_dir.exists() and exec_dir.is_dir():
                            valid_execs.append(ex)
                run["executions"] = valid_execs
                run["execution_count"] = len(valid_execs)
    return payload


def _load_layered_l3_payload(source_dir: str, run_id: str) -> Dict[str, Any]:
    path = DEFAULT_LAYERED_INVENTORY_ROOT / "details" / source_dir / f"{run_id}.json"
    if not path.exists():
        raise FileNotFoundError(f"missing_layered_inventory:{path.as_posix()}")
    payload = _read_json(path)
    if "executions" in payload and isinstance(payload["executions"], list):
        valid_execs = []
        for ex in payload["executions"]:
            resolved_root_str = ex.get("resolved_root", "")
            if resolved_root_str:
                exec_dir = REPO_ROOT / resolved_root_str
                if exec_dir.exists() and exec_dir.is_dir():
                    valid_execs.append(ex)
        payload["executions"] = valid_execs
    return payload



def process_portfolio_chips_payload() -> Dict[str, Any]:
    return _load_layered_l1_payload()


def process_portfolio_chip_runs_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    source_dir = str(payload.get("source_dir", "")).strip()
    if not source_dir:
        raise ValueError("missing_field:source_dir")
    return _load_layered_l2_payload(source_dir)


def process_portfolio_run_detail_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    source_dir = str(payload.get("source_dir", "")).strip()
    run_id = str(payload.get("run_id", "")).strip()
    if not source_dir:
        raise ValueError("missing_field:source_dir")
    if not run_id:
        raise ValueError("missing_field:run_id")
    return _load_layered_l3_payload(source_dir, run_id)


def resolve_portfolio_inventory_route(request_path: str) -> Dict[str, str]:
    parsed_path = urlparse(request_path).path
    if parsed_path == "/api/portfolio/chips":
        return {"layer": "chips"}
    if parsed_path.startswith("/api/portfolio/chips/") and "/runs/" in parsed_path:
        segments = [seg for seg in parsed_path.split("/") if seg]
        if len(segments) != 6:
            raise ValueError("invalid_portfolio_detail_path")
        return {"layer": "run_detail", "source_dir": segments[3], "run_id": segments[5]}
    if parsed_path.startswith("/api/portfolio/chips/") and parsed_path.endswith("/runs"):
        segments = [seg for seg in parsed_path.split("/") if seg]
        if len(segments) != 5:
            raise ValueError("invalid_portfolio_runs_path")
        return {"layer": "chip_runs", "source_dir": segments[3]}
    raise ValueError("not_portfolio_inventory_route")


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _sha256_json(payload: Dict[str, Any]) -> str:
    return _sha256_bytes(json.dumps(payload, sort_keys=True, ensure_ascii=False).encode("utf-8"))


def _existing_companion_bundle_hash(path: Path) -> str | None:
    if not path.exists():
        return None
    text = path.read_text(encoding="utf-8", errors="ignore")
    match = re.search(r"source_hash_bundle:\s*`([0-9a-f]{64})`", text)
    return match.group(1) if match else None


def _write_markdown_companion_with_hash_guard(
    *,
    output_md_path: Path,
    body_markdown: str,
    source_payloads: Dict[str, Dict[str, Any]],
    companion_kind: str,
) -> None:
    source_ref_hashes = {ref: _sha256_json(payload) for ref, payload in source_payloads.items()}
    source_hash_bundle = _sha256_json(source_ref_hashes)
    prev_bundle = _existing_companion_bundle_hash(output_md_path)
    hash_sidecar_path = output_md_path.with_suffix(output_md_path.suffix + ".hash.json")
    if prev_bundle == source_hash_bundle and hash_sidecar_path.exists():
        return

    generated_at = datetime.now(TZ_TW).isoformat()
    stale_detected = prev_bundle is not None and prev_bundle != source_hash_bundle

    header_lines = [
        "> Companion Hash Guard",
        f"- schema_version: `upstream-markdown-companion-hash-guard.v1.0`",
        f"- companion_kind: `{companion_kind}`",
        f"- source_hash_algo: `sha256(stable_json)`",
        f"- source_hash_bundle: `{source_hash_bundle}`",
        f"- generated_at: `{generated_at}`",
    ]
    for ref, digest in source_ref_hashes.items():
        header_lines.append(f"- source_ref_hash `{ref}`: `{digest}`")

    content = "\n".join(header_lines + ["", body_markdown.rstrip(), ""])
    _write_markdown(output_md_path, content)
    _atomic_write_json(
        hash_sidecar_path,
        {
            "schema_version": "upstream-markdown-companion-hash-guard.v1.0",
            "companion_kind": companion_kind,
            "source_hash_algo": "sha256(stable_json)",
            "source_hash_bundle": source_hash_bundle,
            "source_ref_hashes": source_ref_hashes,
            "generated_at": generated_at,
            "stale_detected_before_regen": stale_detected,
            "companion_ref": output_md_path.as_posix(),
        },
    )


def _ensure_human_review_companions(chip_root: Path) -> None:
    specs_dir = chip_root / "specs"
    architecture_dir = chip_root / "architecture"
    requirement_item_path = specs_dir / "requirement_item.json"
    review_package_path = specs_dir / "requirement_item_review_package.json"
    adjudication_template_path = specs_dir / "requirement_item_adjudication_record.template.json"
    adjudication_record_path = specs_dir / "requirement_item_adjudication_record.json"
    handoff_path = architecture_dir / "builder_validation_handoff.json"
    if not requirement_item_path.exists() or not review_package_path.exists() or not handoff_path.exists():
        return

    requirement_item = _safe_read_json(requirement_item_path)
    review_package = _safe_read_json(review_package_path)
    adjudication_template = _safe_read_json(adjudication_template_path)
    adjudication_record = _safe_read_json(adjudication_record_path)
    handoff = _safe_read_json(handoff_path)
    decision_source = adjudication_record or adjudication_template
    requirement_lines = _format_md_list(requirement_item.get("requirement_items"))
    candidate_decisions = _format_md_list(review_package.get("candidate_decisions"))
    suggested_conditions = _format_md_list(decision_source.get("conditions_suggested"))
    conditions = _format_md_list(decision_source.get("conditions"))
    authority_boundary = handoff.get("authority_boundary", {})
    authority_lines = _format_md_list(
        [f"{key}: {value}" for key, value in authority_boundary.items()] if isinstance(authority_boundary, dict) else []
    )
    review_body = "\n".join(
        [
            "# Human Review Companion — Requirement Item",
            "",
            "> Derived human-readable companion. Canonical machine truth remains in JSON files.",
            "",
            f"- chip_id: `{chip_root.name}`",
            f"- scope_type: `CHIP_UPSTREAM`",
            f"- review_status: `{review_package.get('status', 'UNKNOWN')}`",
            f"- intake_session_id: `{review_package.get('intake_session_id', 'UNKNOWN')}`",
            f"- requirement_item_ref: `{review_package.get('requirement_item_ref', requirement_item_path.as_posix())}`",
            f"- builder_handoff_ref: `{review_package.get('builder_handoff_ref', handoff_path.as_posix())}`",
            "",
            "## What Human Should Judge",
            "",
            "- Are the requirement items specific enough to be verified?",
            "- Are ambiguity, missing evidence, and acceptance criteria still open?",
            "- Should the decision be approve, approve_with_conditions, request_more_evidence, or reject?",
            "- This review does not create graph validation, freeze, generation plan, RTL, or production-run evidence.",
            "",
            "## Requirement Items",
            "",
            *requirement_lines,
            "",
            "## Candidate Decisions",
            "",
            *candidate_decisions,
            "",
            "## Next Step",
            "",
            "- Use the Requirement Adjudication page to write `requirement_item_adjudication_record.json`.",
            "- After adjudication, continue in Upstream Truth Flow for graph validation, freeze, generation plan, and RTL generation handoff.",
        ]
    )
    _write_markdown_companion_with_hash_guard(
        output_md_path=specs_dir / "requirement_item_review_package.md",
        body_markdown=review_body,
        source_payloads={
            requirement_item_path.as_posix(): requirement_item,
            review_package_path.as_posix(): review_package,
        },
        companion_kind="requirement_item_review_package",
    )

    adjudication_body = "\n".join(
        [
            "# Human Adjudication Guide",
            "",
            "> Derived human-readable companion. The authority record is `requirement_item_adjudication_record.json`.",
            "",
            f"- chip_id: `{chip_root.name}`",
            f"- scope_type: `CHIP_UPSTREAM`",
            f"- adjudication_status: `{decision_source.get('status', 'PENDING_DECISION')}`",
            f"- decision_outcome: `{decision_source.get('decision_outcome', None)}`",
            f"- authority_signer: `{decision_source.get('authority_signer', None)}`",
            f"- needs_reentry: `{decision_source.get('needs_reentry', False)}`",
            "",
            "## Decision Options",
            "",
            "- `approve`: requirement/spec review is sufficient to continue.",
            "- `approve_with_conditions`: continue, but keep explicit conditions attached.",
            "- `request_more_evidence`: stop and ask local AI/repo agent to fill missing evidence.",
            "- `reject`: stop this upstream path.",
            "",
            "## Suggested Conditions",
            "",
            *suggested_conditions,
            "",
            "## Recorded Conditions",
            "",
            *conditions,
            "",
            "## Authority Boundary",
            "",
            "- Writing adjudication records requirements/spec judgment only.",
            "- It must not create `run_id`, `artifacts/production-runs`, graph validation, freeze, generation plan, RTL generation, or tapeout/readiness claims.",
        ]
    )
    _write_markdown_companion_with_hash_guard(
        output_md_path=specs_dir / "requirement_item_adjudication_guide.md",
        body_markdown=adjudication_body,
        source_payloads={
            adjudication_template_path.as_posix(): adjudication_template,
            adjudication_record_path.as_posix(): adjudication_record,
            review_package_path.as_posix(): review_package,
        },
        companion_kind="requirement_item_adjudication_guide",
    )

    handoff_body = "\n".join(
        [
            "# Builder Validation Handoff — Human Companion",
            "",
            "> Derived human-readable companion. Canonical handoff state remains in `builder_validation_handoff.json`.",
            "",
            f"- chip_id: `{chip_root.name}`",
            f"- scope_type: `CHIP_UPSTREAM`",
            f"- handoff_status: `{handoff.get('handoff_status', 'UNKNOWN')}`",
            f"- graph_draft_ref: `{handoff.get('graph_draft_ref', '')}`",
            f"- requirement_item_ref: `{handoff.get('requirement_item_ref', '')}`",
            f"- adjudication_record_ref: `{handoff.get('adjudication_record_ref', '')}`",
            "",
            "## Authority Boundary",
            "",
            *authority_lines,
            "",
            "## Next Agent Handoff",
            "",
            "- Local AI/repo agent may resume only after a valid machine-readable decision record exists.",
            "- If `handoff_status` is `PENDING_VALIDATION`, proceed to bounded graph generation/refinement and graph validation.",
            "- If `handoff_status` is `REQUEST_MORE_EVIDENCE`, collect missing evidence and return to human adjudication.",
            "- If `handoff_status` is `REJECTED`, do not continue this PRD v1.0 path.",
            "- This handoff remains `CHIP_UPSTREAM`; production-run evidence starts only after freeze and generation-plan/RTL handoff are ready.",
        ]
    )
    _write_markdown_companion_with_hash_guard(
        output_md_path=architecture_dir / "builder_validation_handoff.md",
        body_markdown=handoff_body,
        source_payloads={
            handoff_path.as_posix(): handoff,
            review_package_path.as_posix(): review_package,
        },
        companion_kind="builder_validation_handoff",
    )


def _copy_json_if_source_exists(source: Path, target: Path) -> None:
    if target.exists() or not source.exists():
        return
    _write_json(target, _read_json(source))


def _template_verdict_from_session_record(record: Dict[str, Any]) -> str:
    template_matching = record.get("template_matching", {})
    selected_mode = str(template_matching.get("selection_mode", "")).upper() if isinstance(template_matching, dict) else ""
    if selected_mode == "MANUAL_OVERRIDE":
        return "TEMPLATE_SELECTED"
    if str(record.get("template_match_result", "")).upper() == "MATCHED":
        return "TEMPLATE_AUTO_RESOLVED"
    return "TEMPLATE_DEFERRED"


def _backfill_template_resolution_record(path: Path, intake_session_record: Dict[str, Any]) -> Dict[str, Any]:
    template_matching = intake_session_record.get("template_matching", {})
    if not isinstance(template_matching, dict):
        template_matching = {}
    payload = {
        "schema_version": "template-resolution-record.v1.0",
        "scope_type": "CHIP_UPSTREAM",
        "upstream_operation_id": intake_session_record.get("upstream_operation_id"),
        "intake_session_id": intake_session_record.get("intake_session_id"),
        "chip_id": intake_session_record.get("chip_id"),
        "verdict": _template_verdict_from_session_record(intake_session_record),
        "template_ref": intake_session_record.get("template_ref"),
        "bootstrap_mode": intake_session_record.get("bootstrap_mode"),
        "resolver": template_matching,
        "created_at": intake_session_record.get("created_at"),
        "backfilled_from": path.with_name("intake_session_record.json").as_posix(),
        "backfilled_at": datetime.now(TZ_TW).isoformat(),
    }
    _write_json(path, payload)
    return payload


def _flow_node(
    node_id: str,
    required_files: list[Path],
    next_action: str | None = None,
    expected_files: list[Path] | None = None,
) -> Dict[str, Any]:
    gate_files = required_files
    display_files = expected_files if expected_files is not None else required_files
    gate_existing_files = [path.as_posix() for path in gate_files if path.exists()]
    gate_missing_files = [path.as_posix() for path in gate_files if not path.exists()]
    display_existing_files = [path.as_posix() for path in display_files if path.exists()]
    display_missing_files = [path.as_posix() for path in display_files if not path.exists()]
    status = "PASS" if gate_files and not gate_missing_files else "NOT_CREATED"
    if node_id == "requirement_adjudication" and gate_missing_files:
        status = "HUMAN_REVIEW_REQUIRED"
    return {
        "node_id": node_id,
        "scope_type": "CHIP_UPSTREAM",
        "status": status,
        "expected_files": [path.as_posix() for path in display_files],
        "existing_files": display_existing_files,
        "missing_files": display_missing_files,
        "gate_expected_files": [path.as_posix() for path in gate_files],
        "gate_existing_files": gate_existing_files,
        "gate_missing_files": gate_missing_files,
        "next_action": next_action,
    }


def _status_from_legacy(node: Dict[str, Any]) -> str:
    status = str(node.get("status", "")).upper()
    if status == "PASS":
        return "PASS"
    if status in {"NOT_CREATED", "HUMAN_REVIEW_REQUIRED"}:
        return "PENDING"
    return "ERROR"


def _validate_upstream_node(
    *,
    chip_root: Path,
    node: Dict[str, Any],
) -> Dict[str, Any]:
    node_id = str(node["node_id"])
    existing_refs = list(node.get("existing_files", []))
    missing_refs = list(node.get("missing_files", []))
    status = _status_from_legacy(node)
    reason = "legacy_file_surface"
    schema_validation_result = "NOT_EVALUATED"
    authority_binding_result = "NOT_EVALUATED"
    freshness_result = "NOT_EVALUATED"

    if node_id == "requirement_adjudication":
        record_path = chip_root / "specs" / "requirement_item_adjudication_record.json"
        if not record_path.exists():
            status = "HUMAN_REVIEW_REQUIRED"
            reason = "adjudication_record_missing"
            authority_binding_result = "MISSING"
        else:
            record = _safe_read_json(record_path)
            record_status = str(record.get("status", "")).upper()
            outcome = str(record.get("decision_outcome", "")).lower()
            if record_status != "DECISION_RECORDED":
                status = "FAIL"
                reason = "adjudication_status_not_decision_recorded"
                authority_binding_result = "INVALID"
            elif outcome in {"approve", "approve_with_conditions"}:
                status = "PASS"
                reason = "adjudication_approved"
                authority_binding_result = "BOUND"
            elif outcome == "request_more_evidence":
                status = "WARN"
                reason = "adjudication_request_more_evidence"
                authority_binding_result = "REENTRY"
            elif outcome == "reject":
                status = "FAIL"
                reason = "adjudication_rejected"
                authority_binding_result = "REJECTED"
            else:
                status = "FAIL"
                reason = "adjudication_outcome_invalid"
                authority_binding_result = "INVALID"
            schema_validation_result = "BEST_EFFORT_JSON"
            freshness_result = "PRESENT"

    if node_id == "graph_validation":
        validation_path = chip_root / "architecture" / "validation" / "graph_validation_result.json"
        validator_path = chip_root / "architecture" / "validation" / "validator_run_record.json"
        if validation_path.exists() and validator_path.exists():
            result = _safe_read_json(validation_path)
            verdict = str(result.get("verdict", "")).upper()
            if verdict in {"PASS"}:
                status = "PASS"
                reason = "graph_validation_pass"
            elif verdict in {"PASS_WITH_WARNINGS", "WARN", "WARNING"}:
                status = "WARN"
                reason = "graph_validation_warning"
            elif verdict in {"FAIL", "INVALID", "BLOCKED"}:
                status = "FAIL"
                reason = "graph_validation_failed"
            else:
                status = "FAIL"
                reason = "graph_validation_unknown_verdict"
            required_families = result.get("required_validator_families")
            if not isinstance(required_families, list) or not required_families:
                if status == "PASS":
                    status = "WARN"
                reason = "graph_validation_required_validator_families_missing"
            schema_validation_result = "MACHINE_ENFORCED_MINIMAL"
            freshness_result = "PRESENT"
        elif validation_path.exists() and not validator_path.exists():
            status = "FAIL"
            reason = "graph_validation_missing_validator_run_record"
            schema_validation_result = "MACHINE_ENFORCED_MINIMAL"

    if node_id == "freeze":
        req_freeze = _safe_read_json(chip_root / "governance" / "freeze" / "requirement_freeze_record.json")
        graph_freeze = _safe_read_json(chip_root / "governance" / "freeze" / "graph_freeze_record.json")
        if req_freeze and graph_freeze:
            req_state = str(req_freeze.get("freeze_state", "") or req_freeze.get("status", "")).upper()
            graph_state = str(graph_freeze.get("freeze_state", "") or graph_freeze.get("status", "")).upper()
            if req_state == "FROZEN" and graph_state == "FROZEN":
                status = "PASS"
                reason = "freeze_records_frozen"
            elif req_state in {"CONDITIONAL_FREEZE", "FROZEN_WITH_CONDITIONS"} or graph_state in {
                "CONDITIONAL_FREEZE",
                "FROZEN_WITH_CONDITIONS",
            }:
                status = "WARN"
                reason = "freeze_records_conditional"
            else:
                status = "FAIL"
                reason = "freeze_state_invalid"
            eligibility = graph_freeze.get("freeze_eligibility") or {}
            missing = [key for key in REQUIRED_FREEZE_PRECONDITIONS if eligibility.get(key) is not True]
            if missing:
                if status == "PASS":
                    status = "WARN"
                reason = "freeze_eligibility_incomplete"
            authority_binding_result = "BOUND"
            schema_validation_result = "MACHINE_ENFORCED_MINIMAL"
            freshness_result = "PRESENT"

    if node_id == "generation_plan":
        plan = _safe_read_json(chip_root / "generation" / "graph_to_generation_plan.json")
        if plan:
            machine = bool(plan.get("machine_consumable", False))
            missing_plan_fields = [key for key in REQUIRED_GENERATION_PLAN_FIELDS if not plan.get(key)]
            freeze_ref = str(plan.get("graph_freeze_record_ref", "")).strip()
            if machine and not missing_plan_fields and freeze_ref:
                status = "PASS"
                reason = "generation_plan_machine_consumable"
            else:
                status = "FAIL"
                if not freeze_ref:
                    reason = "generation_plan_missing_graph_freeze_ref"
                elif missing_plan_fields:
                    reason = "generation_plan_missing_required_fields"
                else:
                    reason = "generation_plan_not_machine_consumable"
            schema_validation_result = "MACHINE_ENFORCED_MINIMAL"
            freshness_result = "PRESENT"

    if node_id == "v09_handoff_preflight":
        manifest = _safe_read_json(chip_root / "governance" / "v09_handoff_preflight_manifest.json")
        if manifest:
            manifest_status = str(manifest.get("status", "")).upper()
            missing_sources = manifest.get("missing_sources", [])
            upstream_check = manifest.get("upstream_node_output_check", {})
            upstream_check_status = str(upstream_check.get("status", "")).upper()
            root_cause_required = bool(manifest.get("root_cause_required"))
            if (
                manifest_status == "READY_FOR_V09_HANDOFF"
                and not missing_sources
                and upstream_check_status == "PASS"
                and not root_cause_required
            ):
                status = "PASS"
                reason = "v09_handoff_ready"
                authority_binding_result = "BOUND"
            elif missing_sources:
                status = "FAIL"
                reason = "v09_handoff_missing_sources"
                authority_binding_result = "BLOCKED"
            elif upstream_check_status != "PASS":
                status = "FAIL"
                reason = "v09_handoff_upstream_not_pass"
                authority_binding_result = "BLOCKED"
            elif root_cause_required:
                status = "FAIL"
                reason = "v09_handoff_root_cause_required"
                authority_binding_result = "BLOCKED"
            else:
                status = "FAIL"
                reason = "v09_handoff_manifest_not_ready"
                authority_binding_result = "BLOCKED"
            schema_validation_result = "MACHINE_ENFORCED_MINIMAL"
            freshness_result = "PRESENT"
        else:
            status = "NOT_CREATED"
            reason = "v09_handoff_manifest_missing"
            authority_binding_result = "MISSING"
        manifest_detail = _v09_handoff_preflight_detail(chip_root)
    else:
        manifest_detail = None

    if node_id not in {"requirement_adjudication"} and missing_refs and status == "PASS":
        status = "FAIL"
        reason = "node_output_contract_missing"

    return {
        "node_id": node_id,
        "scope_type": "CHIP_UPSTREAM",
        "status": status,
        "reason": reason,
        "expected_files": node.get("expected_files", []),
        "existing_files": existing_refs,
        "missing_files": missing_refs,
        "validated_object_refs": existing_refs,
        "missing_object_refs": missing_refs,
        "schema_validation_result": schema_validation_result,
        "authority_binding_result": authority_binding_result,
        "freshness_result": freshness_result,
        "next_action": node.get("next_action"),
        "legacy_status": node.get("status"),
        "manifest_detail": manifest_detail,
    }


def process_upstream_node_status_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    chip_root = _resolve_chip_root(str(payload.get("chip_id", "")))
    _ensure_legacy_requirement_adjudication_sidecars(chip_root)
    review_package = _safe_read_json(chip_root / "specs" / "requirement_item_review_package.json")
    flow_nodes = _build_upstream_truth_flow(chip_root, review_package or {})
    authoritative = [_validate_upstream_node(chip_root=chip_root, node=node) for node in flow_nodes]
    # Enforce sequential gate dependency:
    # a node can be PASS only if all previous nodes are PASS.
    prior_node_id = None
    prior_is_pass = True
    for node in authoritative:
        current_status = str(node.get("status", "")).upper()
        if prior_node_id is not None and not prior_is_pass and current_status == "PASS":
            node["status"] = "BLOCKED"
            node["reason"] = "previous_node_not_pass"
            node["dependency_blocker"] = prior_node_id
        prior_is_pass = str(node.get("status", "")).upper() == "PASS"
        prior_node_id = str(node.get("node_id", ""))
    return {
        "status": "ok",
        "scope_type": "CHIP_UPSTREAM",
        "chip_id": chip_root.name,
        "upstream_node_status": authoritative,
    }


def _preview_text(path: Path, max_bytes: int = 65536) -> str | None:
    if path.suffix.lower() not in {".json", ".md", ".txt", ".yaml", ".yml", ".sv", ".v", ".sdc", ".log"}:
        return None
    data = path.read_bytes()
    if len(data) > max_bytes:
        data = data[:max_bytes]
    return data.decode("utf-8", errors="replace")


def _file_meaning_usage(relative_path: str) -> tuple[str, str]:
    name = Path(relative_path).name
    if name == "chip_program_manifest.yaml":
        return (
            "Chip workspace bootstrap manifest.",
            "Used to identify the chip program scaffold and upstream workspace metadata.",
        )
    if name == "production_intent.json":
        return (
            "Chip-level production intent record.",
            "Used to preserve high-level intent before downstream execution planning.",
        )
    if name == "intake_session_record.json":
        return (
            "Captured Requirement Intake session record.",
            "Used to restore the intake prompt, chip id, template resolution context, and upstream operation anchor.",
        )
    if name == "template_resolution_record.json":
        return (
            "Template selection or deferral decision record.",
            "Used to explain whether the intake used a template, auto-resolved one, deferred template use, or blocked.",
        )
    if name == "requirement_item.json":
        return (
            "Canonical requirement item draft or reviewed requirement pack.",
            "Used as the upstream requirement truth candidate for human adjudication and later spec completion.",
        )
    if name == "requirement_item_review_package.json":
        return (
            "Human review package for requirement adjudication.",
            "Used by the Requirement Adjudication page to show review status, missing evidence, and suggested conditions.",
        )
    if name == "requirement_item_review_package.md":
        return (
            "Human-readable requirement review companion.",
            "Used by Requirement Adjudication and Upstream Truth Flow to help humans review requirement items without reading raw JSON first.",
        )
    if name == "requirement_item_adjudication_record.template.json":
        return (
            "Pre-filled adjudication template.",
            "Used as an operator starting point; it is not an approval record until written as the final adjudication record.",
        )
    if name == "requirement_item_adjudication_guide.md":
        return (
            "Human-readable adjudication decision guide.",
            "Summarizes decision options, suggested conditions, recorded decision state, and authority boundaries for the human gate.",
        )
    if name == "requirement_item_adjudication_record.json":
        return (
            "Machine-readable human adjudication decision.",
            "Used by local AI agents as the legal resume gate after validating scope, target refs, and authority.",
        )
    if name == "builder_validation_handoff.json":
        return (
            "Requirement-to-graph handoff state.",
            "Used to tell the upstream graph builder whether it can proceed toward graph validation or needs more evidence.",
        )
    if name == "builder_validation_handoff.md":
        return (
            "Human-readable builder handoff companion.",
            "Explains the current handoff status and next local AI/repo agent action without replacing builder_validation_handoff.json.",
        )
    if name == "architecture_graph.draft.json":
        return (
            "Architecture graph draft scaffold.",
            "Used as intake-time structure only; it must not be treated as frozen architecture truth.",
        )
    if name == "architecture_graph.json":
        return (
            "Canonical architecture graph candidate.",
            "Used for graph validation and freeze after bounded graph generation/refinement.",
        )
    if name == "graph_validation_result.json":
        return (
            "Graph validation verdict record.",
            "Used to decide whether graph freeze can proceed or blockers must be resolved.",
        )
    if name == "validator_run_record.json":
        return (
            "Graph validator execution trace.",
            "Used as evidence backing graph_validation_result.",
        )
    if name == "requirement_freeze_record.json":
        return (
            "Authority-bearing requirement freeze record.",
            "Used to prove requirements are frozen before generation planning.",
        )
    if name == "graph_freeze_record.json":
        return (
            "Authority-bearing graph freeze record.",
            "Used to prove graph truth is frozen before generation planning.",
        )
    if name == "graph_to_generation_plan.json":
        return (
            "Bounded graph-to-generation plan.",
            "Used to authorize downstream RTL candidate generation and PRD v0.9 handoff preparation.",
        )
    if name == "rtl_generation_request.json":
        return (
            "Bounded RTL generation request.",
            "Used to instruct local AI/OpenAI generation using approved v1.0 upstream truth only.",
        )
    if name == "rtl_generation_record.json":
        return (
            "Machine-readable RTL generation result/audit record.",
            "Used to explain what RTL candidate was generated, from which inputs, and with what non-claims.",
        )
    if name == "v09_handoff_preflight_manifest.json":
        return (
            "PRD v0.9 handoff preflight manifest.",
            "Used to confirm upstream truth is ready for PRD v0.9 runner execution after RTL Generation; missing sources trigger root-cause remediation before handoff.",
        )
    if name == "upstream_alignment_map.json":
        return (
            "Chip-scoped agent routing map.",
            "Used by the local AI agent and console to route upstream files, console surfaces, and PRD references; JSON is canonical and the Markdown companion is generated from it.",
        )
    if name == "upstream_alignment_map.md":
        return (
            "Human-readable agent routing map companion.",
            "Generated from upstream_alignment_map.json only; use it as a review companion, not as authority input.",
        )
    if Path(relative_path).suffix.lower() in {".v", ".sv"}:
        return (
            "Generated or approved RTL candidate file.",
            "Consumed as candidate RTL input by PRD v0.9 Routine-B after upstream gates are satisfied.",
        )
    if Path(relative_path).suffix.lower() == ".sdc":
        return (
            "Constraint candidate file.",
            "Used as timing/physical constraint input when the downstream runner snapshots design inputs.",
        )
    return (
        "Chip upstream support file.",
        "Used as supporting context or evidence within the CHIP_UPSTREAM workspace.",
    )


def _v09_handoff_preflight_detail(chip_root: Path) -> Dict[str, Any]:
    manifest_path = chip_root / "governance" / "v09_handoff_preflight_manifest.json"
    manifest = _safe_read_json(manifest_path)
    upstream_check = manifest.get("upstream_node_output_check", {}) if isinstance(manifest, dict) else {}
    entries = manifest.get("entries", []) if isinstance(manifest, dict) else []
    verification_lane = manifest.get("verification_source_lane", {}) if isinstance(manifest, dict) else {}
    if isinstance(manifest, dict) and not verification_lane:
        verification_entries = [
            entry for entry in entries
            if isinstance(entry, dict) and str(entry.get("source_family", "")).strip() == "verification_tb"
        ]
        verification_lane = {
            "required_by_policy": bool(verification_entries),
            "source_family": "verification_tb",
            "source_root": "verification/tb",
            "logical_input_root": "inputs/verification/tb",
            "physical_01_inputs_root": "01_inputs/verification/tb",
            "consumer_stages": ["v2_verilator_sim", "h10_power_ir_dynamic"],
            "expected_files": [
                str(entry.get("physical_01_inputs_path", ""))
                for entry in verification_entries
                if str(entry.get("physical_01_inputs_path", "")).strip()
            ],
            "missing_files": [
                str(entry.get("physical_01_inputs_path", ""))
                for entry in verification_entries
                if str(entry.get("physical_01_inputs_path", "")).strip() and not bool(entry.get("exists"))
            ],
            "materialized": all(bool(entry.get("exists")) for entry in verification_entries) if verification_entries else False,
        }
    run_topology_policy = manifest.get("run_topology_policy", {}) if isinstance(manifest, dict) else {}
    grouped: dict[str, dict[str, list[str]]] = {}

    for entry in entries if isinstance(entries, list) else []:
        if not isinstance(entry, dict):
            continue
        family = str(entry.get("source_family", "unknown")).strip() or "unknown"
        physical = str(entry.get("physical_01_inputs_path", "")).strip()
        if family not in grouped:
            grouped[family] = {"expected_files": [], "missing_files": []}
        if physical:
            grouped[family]["expected_files"].append(physical)
            if not entry.get("exists"):
                grouped[family]["missing_files"].append(physical)

    source_coverage_groups = [
        {
            "source_family": family,
            "expected_files": sorted(dict.fromkeys(payload["expected_files"])),
            "missing_files": sorted(dict.fromkeys(payload["missing_files"])),
        }
        for family, payload in sorted(grouped.items(), key=lambda item: item[0])
    ]
    missing_sources = [str(item) for item in manifest.get("missing_sources", [])] if isinstance(manifest, dict) else []
    alignment_map = ensure_upstream_alignment_map(chip_dir=chip_root)
    try:
        manifest_ref = manifest_path.relative_to(chip_root.parent.parent).as_posix()
    except ValueError:
        manifest_ref = manifest_path.as_posix()
    return {
        "manifest_ref": manifest_ref,
        "manifest_status": str(manifest.get("status", "MISSING")).upper() if isinstance(manifest, dict) else "MISSING",
        "ready_for_v09_handoff": bool(
            isinstance(manifest, dict)
            and str(manifest.get("status", "")).upper() == "READY_FOR_V09_HANDOFF"
            and not missing_sources
            and str(upstream_check.get("status", "")).upper() == "PASS"
            and not bool(manifest.get("root_cause_required"))
        ),
        "missing_sources": missing_sources,
        "root_cause_required": bool(manifest.get("root_cause_required")) if isinstance(manifest, dict) else False,
        "upstream_node_output_check": {
            "ref": upstream_check.get("ref"),
            "status": str(upstream_check.get("status", "MISSING")).upper() if isinstance(upstream_check, dict) else "MISSING",
        },
        "verification_source_lane": verification_lane if isinstance(verification_lane, dict) else {},
        "run_topology_policy": run_topology_policy if isinstance(run_topology_policy, dict) else {},
        "source_coverage_groups": source_coverage_groups,
        "alignment_map_detail": {
            "json_ref": _relative_ref(chip_root / "governance" / "upstream_alignment_map.json", chip_root.parent.parent),
            "md_ref": _relative_ref(chip_root / "governance" / "upstream_alignment_map.md", chip_root.parent.parent),
            "alignment_status": alignment_map.get("alignment_status"),
            "execution_handoff_status": alignment_map.get("execution_handoff_status"),
            "item_count": len(alignment_map.get("items", [])) if isinstance(alignment_map.get("items"), list) else 0,
            "source_digest_bundle": alignment_map.get("source_digest_bundle"),
            "surface_aliases": alignment_map.get("surface_aliases", {}),
            "latest_run_ref": alignment_map.get("latest_run_ref"),
            "latest_readiness_ref": alignment_map.get("latest_readiness_ref"),
            "open_blockers": alignment_map.get("open_blockers", []),
        },
    }


def _file_entry(path: Path, base: Path) -> Dict[str, Any]:
    stat = path.stat()
    relative_path = path.relative_to(base).as_posix()
    meaning, usage = _file_meaning_usage(relative_path)
    return {
        "relative_path": relative_path,
        "file_name": path.name,
        "kind": "file",
        "size_bytes": stat.st_size,
        "meaning": meaning,
        "usage": usage,
        "preview_text": _preview_text(path),
    }


def _upstream_file_paths(chip_root: Path) -> list[Path]:
    allowed_dirs = [
        "specs",
        "architecture",
        "governance",
        "generation",
        "rtl",
        "constraints",
    ]
    paths: list[Path] = []
    for dirname in allowed_dirs:
        root = chip_root / dirname
        if not root.exists():
            continue
        for path in root.rglob("*"):
            # Fail-closed: do not follow symlinked files/dirs in upstream file-family API.
            if path.is_symlink():
                continue
            if path.is_file():
                paths.append(path)
    for root_file in ["chip_program_manifest.yaml", "production_intent.json"]:
        candidate = chip_root / root_file
        if candidate.is_file():
            paths.append(candidate)
    return sorted(set(paths), key=lambda path: path.relative_to(chip_root).as_posix())


def _latest_intake_session_id(chip_root: Path, review_package: Dict[str, Any]) -> str:
    intake_session_id = str(review_package.get("intake_session_id", "")).strip()
    if intake_session_id:
        return intake_session_id
    intake_root = chip_root / "specs" / "intake"
    if not intake_root.exists():
        return "unknown"
    sessions = sorted([path.name for path in intake_root.iterdir() if path.is_dir()])
    return sessions[-1] if sessions else "unknown"


def _build_upstream_truth_flow(
    chip_root: Path,
    review_package: Dict[str, Any],
    intake_session_id: str | None = None,
) -> list[Dict[str, Any]]:
    specs_dir = chip_root / "specs"
    architecture_dir = chip_root / "architecture"
    rtl_dir = chip_root / "rtl"
    session_id = intake_session_id or _latest_intake_session_id(chip_root, review_package)
    intake_dir = specs_dir / "intake" / session_id
    rtl_candidate_files = sorted(
        [path for pattern in ("*.v", "*.sv") for path in rtl_dir.glob(pattern) if path.is_file()],
        key=lambda path: path.as_posix(),
    )
    rtl_contract_files = [
        rtl_dir / "rtl_generation_request.json",
        rtl_dir / "rtl_generation_record.json",
        rtl_dir / "rtl_file_manifest.json",
        *(rtl_candidate_files or [rtl_dir / "<generated RTL candidate files>.v"]),
    ]
    v09_handoff_manifest = chip_root / "governance" / "v09_handoff_preflight_manifest.json"
    intake_expected_files = [
        intake_dir / "intake_session_record.json",
        intake_dir / "prompt.txt",
        intake_dir / "template_resolution_record.json",
        specs_dir / "requirement_item.json",
    ]
    attachment_manifest = intake_dir / "attachments" / "attachment_manifest.json"
    if attachment_manifest.exists():
        intake_expected_files.append(attachment_manifest)
    return [
        _flow_node(
            "requirement_intake",
            [
                intake_dir / "intake_session_record.json",
                intake_dir / "template_resolution_record.json",
                specs_dir / "requirement_item.json",
            ],
            "requirement_adjudication",
            intake_expected_files,
        ),
        _flow_node(
            "requirement_adjudication",
            [
                specs_dir / "requirement_item_review_package.json",
                specs_dir / "requirement_item_adjudication_record.template.json",
                specs_dir / "requirement_item_adjudication_record.json",
            ],
            "graph_draft_check",
            [
                specs_dir / "requirement_item.json",
                specs_dir / "requirement_item_review_package.json",
                specs_dir / "requirement_item_adjudication_record.template.json",
                specs_dir / "requirement_item_adjudication_record.json",
                specs_dir / "design_spec.json",
                specs_dir / "spec_completeness_report.json",
                chip_root / "governance" / "freeze" / "requirement_freeze_record.json",
            ],
        ),
        _flow_node(
            "graph_draft_check",
            [
                architecture_dir / "architecture_graph.draft.json",
                architecture_dir / "builder_validation_handoff.json",
            ],
            "graph_validation",
            [
                architecture_dir / "architecture_graph.draft.json",
                architecture_dir / "builder_validation_handoff.json",
                architecture_dir / "route_a_lineage_record.json",
                architecture_dir / "route_a_openai_worker_audit.json",
                architecture_dir / "route_a_openai_e2e_report.json",
                architecture_dir / "architecture_graph.json",
                architecture_dir / "architecture_graph.md",
                architecture_dir / "architecture_graph.mmd",
                architecture_dir / "architecture_graph.draft.dot",
                architecture_dir / "architecture_graph.view.md",
                architecture_dir / "architecture_graph.view.dot",
                architecture_dir / "architecture_graph.view.svg",
                architecture_dir / "promotion_adjudication_record.json",
                architecture_dir / "hierarchy" / "hierarchy_manifest.json",
                architecture_dir / "hierarchy" / "hierarchy_interface_contracts.json",
                architecture_dir / "hierarchy" / "hierarchy_partition_report.json",
                architecture_dir / "hierarchy" / "top_integration_claim_record.json",
            ],
        ),
        _flow_node(
            "graph_validation",
            [
                architecture_dir / "validation" / "graph_validation_result.json",
                architecture_dir / "validation" / "validator_run_record.json",
            ],
            "freeze",
            [
                architecture_dir / "validation" / "graph_validation_result.json",
                architecture_dir / "validation" / "validator_run_record.json",
                architecture_dir / "graph_issue.json",
                architecture_dir / "interface_binding_record.json",
            ],
        ),
        _flow_node(
            "freeze",
            [
                chip_root / "governance" / "freeze" / "requirement_freeze_record.json",
                chip_root / "governance" / "freeze" / "graph_freeze_record.json",
            ],
            "generation_plan",
            [
                chip_root / "governance" / "freeze" / "requirement_freeze_record.json",
                chip_root / "governance" / "freeze" / "graph_freeze_record.json",
                chip_root / "governance" / "freeze" / "freeze_decision_record.json",
                architecture_dir / "architecture_graph.frozen.json",
            ],
        ),
        _flow_node(
            "generation_plan",
            [
                chip_root / "generation" / "graph_to_generation_plan.json",
            ],
            "rtl_generation",
            [
                chip_root / "generation" / "graph_to_generation_plan.json",
                chip_root / "generation" / "generation_plan_record.json",
            ],
        ),
        _flow_node(
            "rtl_generation",
            [
                rtl_dir / "rtl_generation_request.json",
                rtl_dir / "rtl_generation_record.json",
            ],
            "v09_handoff_preflight",
            rtl_contract_files,
        ),
        _flow_node(
            "v09_handoff_preflight",
            [v09_handoff_manifest],
            "runner_execution",
            [v09_handoff_manifest],
        ),
    ]


def _legacy_prompt_from_requirement_item(requirement_item: Dict[str, Any]) -> str:
    items = requirement_item.get("requirement_items", [])
    if isinstance(items, list) and items:
        titles = [
            str(item.get("title", "")).strip()
            for item in items
            if isinstance(item, dict) and str(item.get("title", "")).strip()
        ]
        if titles:
            return "; ".join(titles[:5])
    return f"{requirement_item.get('chip_id', 'chip')} upstream requirements"


def _ensure_legacy_intake_session(chip_root: Path, requirement_item: Dict[str, Any]) -> str:
    specs_dir = chip_root / "specs"
    intake_root = specs_dir / "intake"
    existing_sessions = sorted(path for path in intake_root.iterdir() if path.is_dir()) if intake_root.exists() else []
    if existing_sessions:
        return existing_sessions[-1].name

    session_id = f"INTAKE-{chip_root.name}-legacy"
    intake_dir = intake_root / session_id
    prompt_text = _legacy_prompt_from_requirement_item(requirement_item)
    prompt_path = intake_dir / "prompt.txt"
    prompt_path.parent.mkdir(parents=True, exist_ok=True)
    prompt_path.write_text(prompt_text, encoding="utf-8")
    created_at = datetime.now(TZ_TW).isoformat()
    intake_session_record = {
        "scope_type": "CHIP_UPSTREAM",
        "upstream_operation_id": f"UOP-{session_id}",
        "intake_session_id": session_id,
        "chip_id": chip_root.name,
        "prompt_text": prompt_text,
        "template_match_result": "LEGACY_COMPATIBILITY",
        "template_ref": None,
        "bootstrap_mode": "LEGACY_COMPATIBILITY",
        "created_at": created_at,
        "backfilled_from": (specs_dir / "requirement_item.json").as_posix(),
    }
    _write_json(intake_dir / "intake_session_record.json", intake_session_record)
    _write_json(
        intake_dir / "template_resolution_record.json",
        {
            "schema_version": "template-resolution-record.v1.0",
            "scope_type": "CHIP_UPSTREAM",
            "upstream_operation_id": f"UOP-{session_id}",
            "intake_session_id": session_id,
            "chip_id": chip_root.name,
            "verdict": "TEMPLATE_DEFERRED",
            "template_ref": None,
            "bootstrap_mode": "LEGACY_COMPATIBILITY",
            "resolver": {"selection_mode": "LEGACY_COMPATIBILITY"},
            "created_at": created_at,
            "backfilled_from": (specs_dir / "requirement_item.json").as_posix(),
        },
    )
    return session_id


def _ensure_legacy_requirement_adjudication_sidecars(chip_root: Path) -> None:
    specs_dir = chip_root / "specs"
    architecture_dir = chip_root / "architecture"
    requirement_item_path = specs_dir / "requirement_item.json"
    handoff_path = architecture_dir / "builder_validation_handoff.json"
    if not requirement_item_path.exists() or not handoff_path.exists():
        return

    requirement_item = _read_json(requirement_item_path)
    session_id = _ensure_legacy_intake_session(chip_root, requirement_item)
    intake_dir = specs_dir / "intake" / session_id
    review_package_path = specs_dir / "requirement_item_review_package.json"
    template_path = specs_dir / "requirement_item_adjudication_record.template.json"
    created_at = datetime.now(TZ_TW).isoformat()

    if not review_package_path.exists():
        _write_json(
            review_package_path,
            {
                "schema_version": "requirement-item-review-package.v1.0",
                "chip_id": chip_root.name,
                "intake_session_id": session_id,
                "requirement_item_ref": requirement_item_path.as_posix(),
                "source_session_ref": intake_dir.as_posix(),
                "builder_handoff_ref": handoff_path.as_posix(),
                "candidate_decisions": ["approve", "approve_with_conditions", "request_more_evidence", "reject"],
                "authority_required": True,
                "status": "PENDING_HUMAN_ADJUDICATION",
                "created_at": created_at,
                "backfilled_from": requirement_item_path.as_posix(),
            },
        )

    if not template_path.exists():
        _write_json(
            template_path,
            {
                "schema_version": "requirement-item-adjudication-record.v1.0",
                "chip_id": chip_root.name,
                "intake_session_id": session_id,
                "review_package_ref": review_package_path.as_posix(),
                "requirement_item_ref": requirement_item_path.as_posix(),
                "decision_outcome": None,
                "decision_rationale": None,
                "authority_signer": None,
                "conditions": [],
                "conditions_suggested": [
                    "Review legacy upstream truth before continuing PRD v1.0 gates.",
                    "Confirm graph validation, freeze, and generation plan evidence are still applicable.",
                    "Preserve CHIP_UPSTREAM scope and do not create run evidence from this adjudication action.",
                ],
                "needs_reentry": False,
                "status": "PENDING_DECISION",
                "created_at": created_at,
                "backfilled_from": requirement_item_path.as_posix(),
            },
        )

    _copy_json_if_source_exists(
        architecture_dir / "graph_validation_result.json",
        architecture_dir / "validation" / "graph_validation_result.json",
    )
    _copy_json_if_source_exists(
        architecture_dir / "validator_run_record.json",
        architecture_dir / "validation" / "validator_run_record.json",
    )
    _copy_json_if_source_exists(
        specs_dir / "requirement_freeze_record.json",
        chip_root / "governance" / "freeze" / "requirement_freeze_record.json",
    )
    _copy_json_if_source_exists(
        architecture_dir / "graph_freeze_record.json",
        chip_root / "governance" / "freeze" / "graph_freeze_record.json",
    )
    _copy_json_if_source_exists(
        architecture_dir / "graph_to_generation_plan.json",
        chip_root / "generation" / "graph_to_generation_plan.json",
    )
    # Companion markdown regeneration is performed by caller paths that need it.


def _derive_upstream_operation_id(chip_root: Path, review_package: Dict[str, Any]) -> str:
    session_id = _latest_intake_session_id(chip_root, review_package)
    if session_id != "unknown":
        return f"UOP-{session_id}"
    return f"UOP-{chip_root.name}-requirement_adjudication"


def process_upstream_chip_inventory_payload() -> Dict[str, Any]:
    chips_root = REPO_ROOT / "chips"
    chips: list[Dict[str, Any]] = []
    if chips_root.exists():
        for child in sorted((path for path in chips_root.iterdir() if path.is_dir()), key=lambda path: path.name):
            _ensure_legacy_requirement_adjudication_sidecars(child)
            specs_dir = child / "specs"
            architecture_dir = child / "architecture"
            required = [
                specs_dir / "requirement_item.json",
                specs_dir / "requirement_item_review_package.json",
                specs_dir / "requirement_item_adjudication_record.template.json",
                architecture_dir / "builder_validation_handoff.json",
            ]
            chips.append(
                {
                    "chip_id": child.name,
                    "scope_type": "CHIP_UPSTREAM",
                    "source_dir": f"chips/{child.name}",
                    "requirement_adjudication_ready": all(path.exists() for path in required),
                    "missing_requirement_adjudication_refs": [
                        path.relative_to(REPO_ROOT).as_posix() if path.is_absolute() else path.as_posix()
                        for path in required
                        if not path.exists()
                    ],
                }
            )
    return {
        "status": "ok",
        "scope_type": "CHIP_UPSTREAM",
        "chips_root": "chips",
        "chips": chips,
    }


def process_upstream_file_family_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    chip_root = _resolve_chip_root(str(payload.get("chip_id", "")))
    _ensure_legacy_requirement_adjudication_sidecars(chip_root)
    _ensure_human_review_companions(chip_root)
    ensure_upstream_alignment_map(chip_dir=chip_root)
    files = [_file_entry(path, chip_root) for path in _upstream_file_paths(chip_root)]
    return {
        "status": "ok",
        "scope_type": "CHIP_UPSTREAM",
        "chip_id": chip_root.name,
        "source_dir": f"chips/{chip_root.name}",
        "files": files,
    }


def process_intake_session_context_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    chip_root = _resolve_chip_root(str(payload.get("chip_id", "")))
    requested_intake_session_id = str(payload.get("intake_session_id", "")).strip()
    if not requested_intake_session_id:
        raise ValueError("missing_field:intake_session_id")

    intake_root = (chip_root / "specs" / "intake").resolve()
    requested_intake_dir = (intake_root / requested_intake_session_id).resolve()
    if not str(requested_intake_dir).startswith(str(intake_root)):
        raise ValueError("intake_session_out_of_scope")
    if requested_intake_dir.exists():
        intake_session_id = requested_intake_session_id
        intake_dir = requested_intake_dir
    else:
        if not intake_root.exists():
            raise FileNotFoundError(f"missing_required_artifact:{requested_intake_dir.as_posix()}")
        session_dirs = sorted(path for path in intake_root.iterdir() if path.is_dir())
        if not session_dirs:
            raise FileNotFoundError(f"missing_required_artifact:{requested_intake_dir.as_posix()}")
        intake_dir = session_dirs[-1]
        intake_session_id = intake_dir.name

    intake_session_record_path = intake_dir / "intake_session_record.json"
    template_resolution_path = intake_dir / "template_resolution_record.json"
    if not intake_session_record_path.exists():
        raise FileNotFoundError(f"missing_required_artifact:{intake_session_record_path.as_posix()}")
    intake_session_record = _read_json(intake_session_record_path)
    if not template_resolution_path.exists():
        template_resolution_record = _backfill_template_resolution_record(template_resolution_path, intake_session_record)
    else:
        template_resolution_record = _read_json(template_resolution_path)

    review_package_path = chip_root / "specs" / "requirement_item_review_package.json"
    review_package = _read_json(review_package_path) if review_package_path.exists() else {"intake_session_id": intake_session_id}
    _ensure_human_review_companions(chip_root)

    return {
        "status": "ok",
        "scope_type": "CHIP_UPSTREAM",
        "chip_id": chip_root.name,
        "requested_intake_session_id": requested_intake_session_id,
        "intake_session_id": intake_session_id,
        "intake_session_record": intake_session_record,
        "template_resolution_record": template_resolution_record,
        "upstream_truth_flow": _build_upstream_truth_flow(chip_root, review_package, intake_session_id),
    }


def process_requirement_adjudication_context_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    chip_root = _resolve_chip_root(str(payload.get("chip_id", "")))
    _ensure_legacy_requirement_adjudication_sidecars(chip_root)
    specs_dir = chip_root / "specs"
    architecture_dir = chip_root / "architecture"

    requirement_item_path = specs_dir / "requirement_item.json"
    review_package_path = specs_dir / "requirement_item_review_package.json"
    adjudication_template_path = specs_dir / "requirement_item_adjudication_record.template.json"
    adjudication_record_path = specs_dir / "requirement_item_adjudication_record.json"
    handoff_path = architecture_dir / "builder_validation_handoff.json"

    for required in [requirement_item_path, review_package_path, adjudication_template_path, handoff_path]:
        if not required.exists():
            raise FileNotFoundError(f"missing_required_artifact:{required.as_posix()}")

    _ensure_human_review_companions(chip_root)
    review_package = _read_json(review_package_path)
    legacy_flow = _build_upstream_truth_flow(chip_root, review_package)
    authoritative_flow = [_validate_upstream_node(chip_root=chip_root, node=node) for node in legacy_flow]
    return {
        "status": "ok",
        "scope_type": "CHIP_UPSTREAM",
        "upstream_operation_id": _derive_upstream_operation_id(chip_root, review_package),
        "chip_id": chip_root.name,
        "requirement_item": _read_json(requirement_item_path),
        "review_package": review_package,
        "adjudication_template": _read_json(adjudication_template_path),
        "builder_handoff": _read_json(handoff_path),
        "adjudication_record": _read_json(adjudication_record_path) if adjudication_record_path.exists() else None,
        "upstream_truth_flow": legacy_flow,
        "upstream_node_status": authoritative_flow,
    }


def _adjudication_status(decision_outcome: str) -> str:
    return {
        "approve": "ADJUDICATED_APPROVED",
        "approve_with_conditions": "ADJUDICATED_APPROVED_WITH_CONDITIONS",
        "request_more_evidence": "ADJUDICATED_REQUEST_MORE_EVIDENCE",
        "reject": "ADJUDICATED_REJECTED",
    }[decision_outcome]


def _handoff_status_for_decision(decision_outcome: str) -> str:
    return {
        "approve": "PENDING_VALIDATION",
        "approve_with_conditions": "PENDING_VALIDATION",
        "request_more_evidence": "REQUEST_MORE_EVIDENCE",
        "reject": "REJECTED",
    }[decision_outcome]


def process_requirement_adjudication_submit_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    chip_root = _resolve_chip_root(str(payload.get("chip_id", "")))
    decision_outcome = str(payload.get("decision_outcome", "")).strip().lower()
    decision_rationale = str(payload.get("decision_rationale", "")).strip()
    authority_signer = str(payload.get("authority_signer", "")).strip()
    conditions = payload.get("conditions", [])
    idempotency_key = str(payload.get("idempotency_key", "")).strip()
    write_session_id = str(payload.get("write_session_id", "")).strip() or f"WS-{uuid4().hex[:12]}"

    allowed = {"approve", "approve_with_conditions", "request_more_evidence", "reject"}
    if decision_outcome not in allowed:
        raise ValueError("invalid_decision_outcome")
    if not decision_rationale:
        raise ValueError("missing_field:decision_rationale")
    if not authority_signer:
        raise ValueError("missing_field:authority_signer")
    if not isinstance(conditions, list) or not all(isinstance(item, str) for item in conditions):
        raise ValueError("invalid_conditions")

    specs_dir = chip_root / "specs"
    architecture_dir = chip_root / "architecture"
    template_path = specs_dir / "requirement_item_adjudication_record.template.json"
    review_package_path = specs_dir / "requirement_item_review_package.json"
    handoff_path = architecture_dir / "builder_validation_handoff.json"
    output_path = specs_dir / "requirement_item_adjudication_record.json"

    for required in [template_path, review_package_path, handoff_path]:
        if not required.exists():
            raise FileNotFoundError(f"missing_required_artifact:{required.as_posix()}")

    normalized_conditions = [item.strip() for item in conditions if item.strip()]
    payload_fingerprint = _fingerprint_adjudication_payload(
        chip_id=chip_root.name,
        decision_outcome=decision_outcome,
        decision_rationale=decision_rationale,
        authority_signer=authority_signer,
        conditions=normalized_conditions,
    )

    lock_path = chip_root / "governance" / "locks" / "requirement_adjudication.lock"
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    with lock_path.open("a+", encoding="utf-8") as lock_file:
        fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX)

        template_payload = _read_json(template_path)
        review_package = _read_json(review_package_path)
        handoff = _read_json(handoff_path)
        existing_record = _read_json(output_path) if output_path.exists() else {}

        if existing_record:
            existing_status = str(existing_record.get("status", "")).upper()
            existing_outcome = str(existing_record.get("decision_outcome", "")).lower()
            existing_fingerprint = str(existing_record.get("idempotency_fingerprint", "")).strip()
            existing_idempotency_key = str(existing_record.get("idempotency_key", "")).strip()
            if idempotency_key and existing_idempotency_key == idempotency_key:
                if existing_fingerprint == payload_fingerprint:
                    return {
                        "status": "ok",
                        "chip_id": chip_root.name,
                        "adjudication_record_ref": output_path.as_posix(),
                        "review_package_status": review_package.get("status", ""),
                        "handoff_status": handoff.get("handoff_status", ""),
                        "idempotent_replay": True,
                    }
                raise ValueError("idempotency_conflict:mismatched_payload")
            if existing_status == "DECISION_RECORDED" and existing_outcome != decision_outcome:
                raise ValueError("adjudication_conflict:decision_already_recorded")

        now = datetime.now(TZ_TW).isoformat()
        record_version = int(existing_record.get("record_version", 0) or 0) + 1
        record_payload = {
            **template_payload,
            "decision_outcome": decision_outcome,
            "decision_rationale": decision_rationale,
            "authority_signer": authority_signer,
            "conditions": normalized_conditions,
            "needs_reentry": decision_outcome == "request_more_evidence",
            "status": "DECISION_RECORDED",
            "decided_at": now,
            "record_version": record_version,
            "write_session_id": write_session_id,
            "idempotency_key": idempotency_key or None,
            "idempotency_fingerprint": payload_fingerprint,
        }

        review_package["status"] = _adjudication_status(decision_outcome)
        review_package["adjudication_record_ref"] = output_path.as_posix()
        review_package["updated_at"] = now
        review_package["write_session_id"] = write_session_id
        review_package["record_version"] = record_version

        handoff["handoff_status"] = _handoff_status_for_decision(decision_outcome)
        handoff["adjudication_record_ref"] = output_path.as_posix()
        handoff["updated_at"] = now
        handoff["write_session_id"] = write_session_id
        handoff["record_version"] = record_version

        # Write ordering for partial-write safety:
        # 1) derived states first; 2) authority decision record last.
        _atomic_write_json(review_package_path, review_package)
        _atomic_write_json(handoff_path, handoff)
        _atomic_write_json(output_path, record_payload)

        _ensure_human_review_companions(chip_root)

    return {
        "status": "ok",
        "chip_id": chip_root.name,
        "adjudication_record_ref": output_path.as_posix(),
        "review_package_status": review_package["status"],
        "handoff_status": handoff["handoff_status"],
        "record_version": record_payload["record_version"],
        "write_session_id": record_payload["write_session_id"],
        "idempotency_key": record_payload.get("idempotency_key"),
    }


def _resolve_run_dir(run_dir_raw: str) -> Path:
    run_dir = Path(run_dir_raw)
    if not run_dir.is_absolute():
        run_dir = (REPO_ROOT / run_dir).resolve()
    else:
        run_dir = run_dir.resolve()
    roots = [
        (REPO_ROOT / "artifacts" / "production-runs").resolve(),
        REPO_ROOT.resolve(),
    ]
    run_dir_posix = run_dir.as_posix()
    if not any(str(run_dir).startswith(str(root)) for root in roots) and "/artifacts/production-runs/" not in run_dir_posix:
        raise ValueError("run_dir_out_of_scope")
    return run_dir


def _resolve_console_run_dir(run_dir_raw: str, *, console_state_root: str | None = None) -> Path:
    try:
        return _resolve_run_dir(run_dir_raw)
    except ValueError:
        if not console_state_root:
            raise
        run_dir = Path(run_dir_raw)
        if not run_dir.is_absolute():
            raise
        return run_dir.resolve()


def _resolve_dashboard_objects_dir(run_dir: Path) -> Path:
    prefixed_dirs = sorted(
        child for child in run_dir.iterdir() if child.is_dir() and child.name.endswith("_dashboard_objects")
    )
    if len(prefixed_dirs) == 1:
        return prefixed_dirs[0]
    if len(prefixed_dirs) > 1:
        names = ", ".join(path.name for path in prefixed_dirs)
        raise FileNotFoundError(f"multiple *_dashboard_objects found under run_dir: {run_dir} ({names})")

    legacy = run_dir / "dashboard_objects"
    if legacy.exists():
        return legacy

    raise FileNotFoundError(f"dashboard_objects not found under run_dir: {run_dir}")


def _optional_dashboard_objects_dir(run_dir: Path) -> Path | None:
    try:
        return _resolve_dashboard_objects_dir(run_dir)
    except FileNotFoundError:
        return None


def _save_json(path: Path, payload: Dict[str, Any]) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def _load_json_if_exists(path: Path) -> Dict[str, Any] | None:
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def _decision_write_mapping(action_name: str) -> tuple[str, str] | None:
    mapping = {
        "approve_trust_gate": ("approve", "APPROVED"),
        "approve_handoff_package": ("approve_package_release", "APPROVED"),
        "approve_with_waivers": ("approve_with_conditions", "APPROVED"),
        "approve_eco_candidate": ("approve_with_conditions", "APPROVED"),
        "sign_contract_section": ("approve_with_conditions", "APPROVED"),
        "accept_errata": ("approve_activation", "APPROVED"),
        "promote_skill": ("approve", "APPROVED"),
        "adopt": ("approve", "APPROVED"),
        "unblock_release": ("approve", "APPROVED"),
        "hold_for_evidence": ("hold", "HOLD"),
        "hold": ("hold", "HOLD"),
        "mark_local_only": ("hold", "HOLD"),
        "defer": ("hold", "HOLD"),
        "request_more_evidence": ("request_more_evidence", "REQUEST_MORE_EVIDENCE"),
        "reject_claim_scope": ("reject", "REJECTED"),
        "reject": ("reject", "REJECTED"),
        "reject_skill": ("reject", "REJECTED"),
        "block_release": ("block_release", "HOLD"),
    }
    return mapping.get(action_name)


def _refresh_portfolio_inventory_if_repo_scoped(run_dir: Path) -> None:
    production_runs_root = (REPO_ROOT / "artifacts" / "production-runs").resolve()
    try:
        run_dir.resolve().relative_to(production_runs_root)
    except Exception:
        return

    script = REPO_ROOT / "workspace" / "shared-runtime" / "scripts" / "generate_production_runs_inventory.py"
    subprocess.run([sys.executable, str(script)], cwd=REPO_ROOT, check=True, capture_output=True, text=True)


def _upsert_formal_decision_queue_projection(
    *,
    out_dir: Path,
    formal_decision_ref: str,
    decision_type: str,
    decision_status_after: str,
    authority_role: str,
    profile: str,
    chip_id: str,
    run_id: str,
    artifact_refs: list[str],
) -> Dict[str, Any]:
    queue_path = out_dir / "human_decision_queue.json"
    queue = _load_json_if_exists(queue_path) or {
        "queue_id": "human-decision-queue-v1.8",
        "type": "human_decision_queue",
        "schema_version": "1.8.0",
        "dashboard_version": "v1_8",
        "items": [],
    }
    if not isinstance(queue.get("items"), list):
        queue["items"] = []

    new_item = build_decision_queue_item_v18(
        decision_type=decision_type,
        authority_role=authority_role,
        formal_decision_ref=formal_decision_ref,
        artifact_refs=artifact_refs,
        profile=profile if profile in {"solo_eval", "team_project", "enterprise_site"} else "team_project",
        chip_id=chip_id,
        run_id=run_id,
    )
    new_item["status"] = {
        "APPROVED": "approved",
        "REJECTED": "rejected",
        "HOLD": "blocked",
        "REQUEST_MORE_EVIDENCE": "blocked",
    }.get(decision_status_after, "pending")

    updated_items: list[Dict[str, Any]] = []
    replaced = False
    for item in queue["items"]:
        if item.get("formal_decision_ref") == formal_decision_ref:
            updated_items.append(new_item)
            replaced = True
        else:
            updated_items.append(item)
    if not replaced:
        updated_items.append(new_item)
    queue["items"] = updated_items
    queue["pending_count"] = len([item for item in updated_items if item.get("status") == "pending"])
    queue["dashboard_version"] = "v1_8"
    _save_json(queue_path, queue)
    return queue


def _require_string(payload: Dict[str, Any], field: str) -> str:
    value = str(payload.get(field, "")).strip()
    if not value:
        raise ValueError(f"missing_field:{field}")
    return value


def _require_string_list(payload: Dict[str, Any], field: str) -> list[str]:
    value = payload.get(field, [])
    if not isinstance(value, list) or not all(isinstance(item, str) and item.strip() for item in value):
        raise ValueError(f"invalid_field:{field}")
    return [item.strip() for item in value]


def _build_downstream_decision_state_refs(*, chip_id: str, run_id: str, date_time: str, gate_family: str, action_name: str) -> tuple[str, str]:
    before_state_ref = f"icaf://state/downstream/{chip_id}/{run_id}/{date_time}/{gate_family}/before"
    after_state_ref = f"icaf://state/downstream/{chip_id}/{run_id}/{date_time}/{gate_family}/{action_name}"
    return before_state_ref, after_state_ref


MINIMAL_CONSOLE_ACTIONS = {"approve", "approve_with_conditions", "hold", "request_more_evidence"}
CONSOLE_RBAC = {
    "Viewer": set(),
    "Reviewer": {"hold", "request_more_evidence"},
    "Approver": MINIMAL_CONSOLE_ACTIONS,
    "Auditor": set(),
    "Admin": set(),
}


def _decision_status_after(action_name: str) -> str:
    return {
        "approve": "APPROVED",
        "approve_with_conditions": "APPROVED_WITH_CONDITIONS",
        "hold": "HELD",
        "request_more_evidence": "MORE_EVIDENCE_REQUESTED",
    }[action_name]


def _console_action_id(action_name: str, session_id: str) -> str:
    return f"act_{datetime.now(TZ_TW).strftime('%Y%m%d_%H%M%S_%f')}_{session_id}_{action_name}".replace("-", "_")


def _build_console_scope_ref(scope: Dict[str, Any]) -> str:
    return "icaf://state/console/{chip_id}/{run_id}/{date_time}/{node_id}".format(
        chip_id=scope["chip_id"],
        run_id=scope["run_id"],
        date_time=scope["date_time"],
        node_id=scope["node_id"],
    )


def process_console_action_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    action_name = _require_string(payload, "action_name")
    actor = _require_string(payload, "actor")
    role = _require_string(payload, "role")
    session_id = _require_string(payload, "session_id")
    run_dir_raw = _require_string(payload, "run_dir")
    scope = payload.get("scope")
    if not isinstance(scope, dict):
        raise ValueError("invalid_field:scope")
    for field in ["mode", "profile", "chip_id", "run_id", "date_time", "node_id"]:
        if not str(scope.get(field, "")).strip():
            raise ValueError(f"missing_scope_field:{field}")
    target_object_refs = _require_string_list(payload, "target_object_refs")
    source_evidence_refs = _require_string_list(payload, "source_evidence_refs")
    requested_evidence = payload.get("requested_evidence", [])
    if requested_evidence and not isinstance(requested_evidence, list):
        raise ValueError("invalid_field:requested_evidence")

    console_state_root = payload.get("console_state_root") or os.environ.get("ICAF_CONSOLE_STATE_ROOT")
    run_dir = _resolve_console_run_dir(run_dir_raw, console_state_root=str(console_state_root) if console_state_root else None)
    action_id = _console_action_id(action_name, session_id)
    before_state = {
        "decision_status": str(payload.get("decision_status", "NOT_REQUESTED")),
        "authority_status": "OPEN",
    }
    after_state = {
        "decision_status": _decision_status_after(action_name) if action_name in MINIMAL_CONSOLE_ACTIONS else before_state["decision_status"],
        "authority_status": "OPEN",
    }
    scope_ref = _build_console_scope_ref(scope)
    decision_context_ref = f"governance://decision/{scope['chip_id']}/{scope['run_id']}/{scope['date_time']}/{scope['node_id']}"
    allowed_for_role = CONSOLE_RBAC.get(role, set())
    deny_reason = None
    if action_name not in MINIMAL_CONSOLE_ACTIONS:
        deny_reason = "ACTION_NOT_ALLOWED"
    elif action_name not in allowed_for_role:
        deny_reason = "ROLE_NOT_ALLOWED"

    request_record = {
        "action_request_id": f"dashboard-action-request::{action_id}",
        "type": "dashboard_action_request",
        "schema_version": "1.8.0",
        "session_id": session_id,
        "action_name": action_name,
        "actor_id": actor,
        "role": role,
        "target_object_refs": target_object_refs,
        "source_evidence_refs": source_evidence_refs,
        "decision_context_ref": decision_context_ref,
        "requested_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
    }
    authorization_record = {
        "authorization_id": f"dashboard-authorization::{action_id}",
        "type": "dashboard_action_authorization_record",
        "schema_version": "1.8.0",
        "action_request_id": request_record["action_request_id"],
        "session_id": session_id,
        "actor_id": actor,
        "role": role,
        "decision": "DENY" if deny_reason else "ALLOW",
        "policy_flags": [deny_reason] if deny_reason else [],
        "evaluated_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
    }

    if deny_reason:
        append_result = append_console_action_records(
            run_dir=run_dir,
            action_id=action_id,
            records={"dashboard_action_authorization_record": authorization_record},
            console_state_root=Path(console_state_root) if console_state_root else None,
        )
        return {
            "status": "DENIED",
            "action_id": action_id,
            "authorization_verdict": "DENY",
            "deny_reason": deny_reason,
            "produced_records": append_result["records"],
        }

    audit_record = {
        "audit_record_id": f"dashboard-audit::{action_id}",
        "type": "dashboard_action_audit_record",
        "schema_version": "1.8.0",
        "action_request_id": request_record["action_request_id"],
        "authorization_id": authorization_record["authorization_id"],
        "session_id": session_id,
        "actor_id": actor,
        "before_state_ref": f"{scope_ref}/before",
        "after_state_ref": f"{scope_ref}/{action_name}",
        "artifact_refs": source_evidence_refs,
        "recorded_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
    }
    result_record = {
        "action_result_id": f"dashboard-result::{action_id}",
        "type": "dashboard_action_result_record",
        "schema_version": "1.8.0",
        "action_request_id": request_record["action_request_id"],
        "authorization_id": authorization_record["authorization_id"],
        "audit_record_id": audit_record["audit_record_id"],
        "result_status": "SUCCESS",
        "formal_object_refs": target_object_refs,
        "completed_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
    }
    records: dict[str, dict[str, Any]] = {
        "dashboard_action_request": request_record,
        "dashboard_action_authorization_record": authorization_record,
        "dashboard_action_audit_record": audit_record,
        "dashboard_action_result_record": result_record,
    }
    if action_name == "request_more_evidence":
        records["reentry_request_record"] = {
            "record_type": "reentry_request_record",
            "record_id": f"reentry::{action_id}",
            "action_id": action_id,
            "scope": scope,
            "requested_evidence": [str(item) for item in requested_evidence] or ["additional_evidence"],
            "reason": str(payload.get("comment", "More evidence requested.")).strip() or "More evidence requested.",
            "status": "OPEN",
            "created_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        }

    append_result = append_console_action_records(
        run_dir=run_dir,
        action_id=action_id,
        records=records,
        console_state_root=Path(console_state_root) if console_state_root else None,
    )
    return {
        "status": "ACCEPTED",
        "action_id": action_id,
        "produced_records": append_result["records"],
        "before_state": before_state,
        "after_state": after_state,
    }


def process_console_decision_state_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    run_dir_raw = _require_string(payload, "run_dir")
    scope = {
        "chip_id": _require_string(payload, "chip_id"),
        "run_id": _require_string(payload, "run_id"),
        "date_time": _require_string(payload, "date_time"),
        "node_id": _require_string(payload, "node_id"),
        "mode": _require_string(payload, "mode"),
        "profile": _require_string(payload, "profile"),
    }
    console_state_root = payload.get("console_state_root") or os.environ.get("ICAF_CONSOLE_STATE_ROOT")
    run_dir = _resolve_console_run_dir(run_dir_raw, console_state_root=str(console_state_root) if console_state_root else None)
    actions_dir = resolve_console_actions_dir(
        run_dir=run_dir,
        console_state_root=Path(console_state_root) if console_state_root else None,
    )
    index_path = actions_dir / "action_chain_index.json"
    source_refs = {"evidence_refs": [], "decision_record_refs": [], "audit_record_refs": []}
    state = {
        **scope,
        "evidence_status": "MISSING",
        "gate_status": "BLOCKED",
        "decision_status": "NOT_REQUESTED",
        "authority_status": "OPEN",
        "available_actions": ["approve", "approve_with_conditions", "hold", "request_more_evidence"],
        "disabled_actions": [],
        "source_refs": source_refs,
    }
    if not index_path.exists():
        return state

    index = json.loads(index_path.read_text(encoding="utf-8"))
    actions = index.get("actions", [])
    if not actions:
        return state
    latest = None
    for entry in reversed(actions):
        records_for_entry = entry.get("records", {})
        if records_for_entry.get("dashboard_action_request") and records_for_entry.get("dashboard_action_result_record"):
            latest = entry
            break
    if latest is None:
        return state
    records = latest.get("records", {})
    request_ref = records.get("dashboard_action_request")
    audit_ref = records.get("dashboard_action_audit_record")
    result_ref = records.get("dashboard_action_result_record")
    if request_ref:
        request_record = json.loads(
            resolve_console_action_record_ref(request_ref, actions_dir).read_text(encoding="utf-8")
        )
        action_name = str(request_record.get("action_name", ""))
        source_refs["evidence_refs"] = list(request_record.get("source_evidence_refs", []))
        if action_name in MINIMAL_CONSOLE_ACTIONS:
            state["decision_status"] = _decision_status_after(action_name)
            state["evidence_status"] = "PASS"
            state["gate_status"] = "PASS"
    if result_ref:
        source_refs["decision_record_refs"].append(result_ref)
    if audit_ref:
        source_refs["audit_record_refs"].append(audit_ref)
    if state["decision_status"] in {"APPROVED", "APPROVED_WITH_CONDITIONS"}:
        state["authority_status"] = "CLOSED"
    return state


def process_console_audit_replay_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    run_dir_raw = _require_string(payload, "run_dir")
    scope = {
        "chip_id": _require_string(payload, "chip_id"),
        "run_id": _require_string(payload, "run_id"),
        "date_time": _require_string(payload, "date_time"),
        "node_id": _require_string(payload, "node_id"),
    }
    action_id = str(payload.get("action_id", "")).strip()
    console_state_root = payload.get("console_state_root") or os.environ.get("ICAF_CONSOLE_STATE_ROOT")
    run_dir = _resolve_console_run_dir(run_dir_raw, console_state_root=str(console_state_root) if console_state_root else None)
    actions_dir = resolve_console_actions_dir(
        run_dir=run_dir,
        console_state_root=Path(console_state_root) if console_state_root else None,
    )
    index_path = actions_dir / "action_chain_index.json"
    if not index_path.exists():
        return {"replay_status": "BROKEN", "scope": scope, "events": [], "can_reconstruct": False, "missing_records": ["icaf://console-actions/action_chain_index.json"]}
    index = json.loads(index_path.read_text(encoding="utf-8"))
    actions = index.get("actions", [])
    selected = None
    for entry in actions:
        if action_id and entry.get("action_id") == action_id:
            selected = entry
            break
    if selected is None and actions:
        selected = actions[-1]
    if selected is None:
        return {"replay_status": "BROKEN", "scope": scope, "events": [], "can_reconstruct": False, "missing_records": ["action_chain_index.actions"]}

    records = selected.get("records", {})
    required_sequence = [
        ("dashboard_action_request", "ACTION_REQUESTED"),
        ("dashboard_action_authorization_record", "AUTHORIZED"),
        ("dashboard_action_audit_record", "AUDIT_RECORDED"),
    ]
    if "reentry_request_record" in records:
        required_sequence.append(("reentry_request_record", "REENTRY_CREATED"))
    required_sequence.append(("dashboard_action_result_record", "STATE_UPDATED"))

    events: list[dict[str, str]] = []
    missing: list[str] = []
    for record_key, event_type in required_sequence:
        record_ref = records.get(record_key)
        record_path = resolve_console_action_record_ref(record_ref, actions_dir) if record_ref else None
        if not record_ref or record_path is None or not record_path.exists():
            missing.append(record_ref or record_key)
            continue
        events.append({"event_type": event_type, "record_ref": record_ref})

    return {
        "replay_status": "BROKEN" if missing else "REPLAYABLE",
        "scope": scope,
        "events": events,
        "can_reconstruct": not missing,
        "missing_records": missing,
    }


def process_downstream_decision_entrypoint_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    run_dir_raw = _require_string(payload, "run_dir")
    session_id = _require_string(payload, "session_id")
    actor_id = _require_string(payload, "actor_id")
    role = _require_string(payload, "role")
    action_name = _require_string(payload, "action_name")
    chip_id = _require_string(payload, "chip_id")
    run_id = _require_string(payload, "run_id")
    date_time = _require_string(payload, "date_time")
    gate_family = _require_string(payload, "gate_family")
    required_role = _require_string(payload, "required_role")
    decision_context_ref = _require_string(payload, "decision_context_ref")
    source_evidence_refs = _require_string_list(payload, "source_evidence_refs")
    target_object_refs = _require_string_list(payload, "target_object_refs")
    formal_object_refs = _require_string_list(payload, "formal_object_refs")
    readiness_status = _require_string(payload, "readiness_status")
    decision_status = _require_string(payload, "decision_status")
    allowed_actions = _require_string_list(payload, "allowed_actions")

    run_dir = _resolve_run_dir(run_dir_raw)
    backend_binding_state = "BOUND" if _optional_dashboard_objects_dir(run_dir) is not None else "UNBOUND"
    return build_downstream_decision_entrypoint_preview(
        backend_binding_state=backend_binding_state,
        live_submission_enabled=backend_binding_state == "BOUND",
        session_id=session_id,
        action_name=action_name,
        actor_id=actor_id,
        role=role,
        target_object_refs=target_object_refs,
        source_evidence_refs=source_evidence_refs,
        decision_context_ref=decision_context_ref,
        formal_object_refs=formal_object_refs,
        readiness_status=readiness_status,
        decision_status=decision_status,
    )


def process_downstream_decision_action_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    run_dir_raw = _require_string(payload, "run_dir")
    session_id = _require_string(payload, "session_id")
    actor_id = _require_string(payload, "actor_id")
    role = _require_string(payload, "role")
    action_name = _require_string(payload, "action_name")
    chip_id = _require_string(payload, "chip_id")
    run_id = _require_string(payload, "run_id")
    date_time = _require_string(payload, "date_time")
    gate_family = _require_string(payload, "gate_family")
    required_role = _require_string(payload, "required_role")
    decision_context_ref = _require_string(payload, "decision_context_ref")
    source_evidence_refs = _require_string_list(payload, "source_evidence_refs")
    target_object_refs = _require_string_list(payload, "target_object_refs")
    formal_object_refs = _require_string_list(payload, "formal_object_refs")
    readiness_status = _require_string(payload, "readiness_status")
    decision_status = _require_string(payload, "decision_status")
    allowed_actions = _require_string_list(payload, "allowed_actions")
    package_mode = str(payload.get("package_mode", "team_project")).strip() or "team_project"

    run_dir = _resolve_run_dir(run_dir_raw)
    out_dir = _optional_dashboard_objects_dir(run_dir)
    if out_dir is None:
        raise FileNotFoundError(f"dashboard_objects not found under run_dir: {run_dir}")

    before_state_ref, after_state_ref = _build_downstream_decision_state_refs(
        chip_id=chip_id,
        run_id=run_id,
        date_time=date_time,
        gate_family=gate_family,
        action_name=action_name,
    )
    artifact_refs = list(source_evidence_refs)

    bundle = build_dashboard_action_bundle(
        session_id=session_id,
        action_name=action_name,
        actor_id=actor_id,
        role=role,
        target_object_refs=target_object_refs,
        source_evidence_refs=source_evidence_refs,
        decision_context_ref=decision_context_ref,
        required_role=required_role,
        allowed_actions=allowed_actions,
        before_state_ref=before_state_ref,
        after_state_ref=after_state_ref,
        formal_object_refs=formal_object_refs,
        artifact_refs=artifact_refs,
        read_only=False,
    )
    decision_mapping = _decision_write_mapping(action_name)
    decision_status_after_effective = decision_status
    decision_type_effective = None
    if decision_mapping is not None:
        decision_type_effective, decision_status_after_effective = decision_mapping

    _save_json(out_dir / "dashboard_action_request.json", bundle["request"])
    _save_json(out_dir / "dashboard_action_authorization_record.json", bundle["authorization"])
    if bundle.get("fail_closed"):
        _save_json(out_dir / "dashboard_fail_closed_record.json", bundle["fail_closed"])
    _save_json(out_dir / "dashboard_action_audit_record.json", bundle["audit"])
    _save_json(out_dir / "dashboard_action_result_record.json", bundle["result"])
    _save_json(out_dir / "dashboard_replay_trace.json", bundle["replay"])
    _save_json(
        out_dir / "downstream_decision_action_binding.json",
        {
            "type": "downstream_decision_action_binding",
            "schema_version": "1.8.0",
            "session_id": session_id,
            "chip_id": chip_id,
            "run_id": run_id,
            "date_time": date_time,
            "gate_family": gate_family,
            "decision_context_ref": decision_context_ref,
            "action_request_ref": bundle["request"]["action_request_id"],
            "authorization_ref": bundle["authorization"]["authorization_id"],
            "audit_ref": bundle["audit"]["audit_record_id"],
            "result_ref": bundle["result"]["action_result_id"],
            "replay_ref": bundle["replay"]["replay_trace_id"],
            "status": bundle["result"]["result_status"],
            "backend_binding_state": "BOUND",
            "readiness_status": readiness_status,
            "decision_status": decision_status,
            "decision_status_after": decision_status_after_effective,
            "package_mode": package_mode,
        },
    )

    decision_write = None
    if decision_mapping is not None and decision_type_effective is not None:
        decision_write = build_console_decision_write_record(
            action_request_id=bundle["request"]["action_request_id"],
            formal_decision_ref=decision_context_ref,
            decision_status_before=decision_status,
            decision_status_after=decision_status_after_effective,
            decision_type=decision_type_effective,
            decision_projection_ref=f"icaf://artifact/{out_dir.relative_to(run_dir)}/human_decision_queue.json",
            projection_consumer_refs=[
                "icaf://surface/console/downstream-decision-control-tower",
                "icaf://read-model/console/decision-queue",
            ],
        )
        _save_json(out_dir / "console_decision_write_record.json", decision_write)
        _upsert_formal_decision_queue_projection(
            out_dir=out_dir,
            formal_decision_ref=decision_context_ref,
            decision_type=decision_type_effective,
            decision_status_after=decision_status_after_effective,
            authority_role=required_role,
            profile=package_mode,
            chip_id=chip_id,
            run_id=run_id,
            artifact_refs=[*formal_object_refs, *source_evidence_refs],
        )
        _refresh_portfolio_inventory_if_repo_scoped(run_dir)
    return {
        "status": "ok",
        "backend_binding_state": "BOUND",
        "live_submission_enabled": True,
        "run_dir": run_dir.as_posix(),
        "bundle": bundle,
        "decision_write": decision_write,
    }


def process_agent_trust_action_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    run_dir_raw = str(payload.get("run_dir", "")).strip()
    binding_id = str(payload.get("binding_id", "")).strip()
    action = str(payload.get("action", "")).strip().lower()
    actor_role = str(payload.get("actor_role", "")).strip().upper()
    session_id = str(payload.get("session_id", "")).strip()

    if not run_dir_raw:
        raise ValueError("missing_field:run_dir")
    if not binding_id:
        raise ValueError("missing_field:binding_id")
    if not action:
        raise ValueError("missing_field:action")
    if not actor_role:
        raise ValueError("missing_field:actor_role")
    if not session_id:
        raise ValueError("missing_field:session_id")

    allowed_actions = {"approve", "reject", "rerun", "waive", "request_more_evidence"}
    if action not in allowed_actions:
        raise ValueError("invalid_action")

    if actor_role in {"READ_ONLY", "VIEWER", "OBSERVER"}:
        raise PermissionError("rbac_blocked:read_only_role")
    if actor_role not in {"RELEASE_AUTHORITY", "TAPEOUT_AUTHORITY", "SIGNOFF_APPROVER"}:
        raise PermissionError("rbac_blocked:unsupported_role")

    run_dir = _resolve_run_dir(run_dir_raw)
    out_dir = _resolve_dashboard_objects_dir(run_dir)

    from ic_agent_flow.dashboard.agent_trust_panel_actions import apply_agent_trust_panel_action

    apply_agent_trust_panel_action(
        out_dir,
        binding_id=binding_id,
        action=action,
        actor_role=actor_role,
    )
    result_record_path = out_dir / "dashboard_action_result_record.json"
    result_record = json.loads(result_record_path.read_text(encoding="utf-8")) if result_record_path.exists() else {}
    return {
        "status": "ok",
        "session_id": session_id,
        "actor_role": actor_role,
        "action": action,
        "binding_id": binding_id,
        "run_dir": run_dir.as_posix(),
        "result_record": result_record,
    }



PREFLIGHT_CACHE: Dict[str, Dict[str, Any]] = {}

def process_console_sync_folders_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    package_builds_dir = REPO_ROOT / "workspace" / "portfolio" / "summaries" / "package-builds"
    artifacts_builds_dir = REPO_ROOT / "artifacts" / "package-builds"

    package_builds_dir.mkdir(parents=True, exist_ok=True)
    artifacts_builds_dir.mkdir(parents=True, exist_ok=True)

    portfolio_index_path = package_builds_dir / "customer_package_folders_index.json"
    artifacts_index_path = artifacts_builds_dir / "customer_package_folders_index.json"

    index_data = {}
    if portfolio_index_path.exists():
        index_data = _safe_read_json(portfolio_index_path)
    elif artifacts_index_path.exists():
        index_data = _safe_read_json(artifacts_index_path)

    if not isinstance(index_data, dict) or "bundles" not in index_data:
        index_data = {
            "schema_version": "v1.17.customer-package-folders-index.v1",
            "generated_at": datetime.now(TZ_TW).isoformat(),
            "bundles": []
        }

    existing_bundles = {b["bundle_id"]: b for b in index_data.get("bundles", []) if "bundle_id" in b}
    previous_count = len(existing_bundles)

    cust_packages_dir = REPO_ROOT / "distribution" / "customer-packages"
    physical_bundles: Dict[str, list[str]] = {}

    if cust_packages_dir.exists():
        for item in cust_packages_dir.iterdir():
            if item.is_dir() and (item.name.startswith("runtime-bundle-tw-") or item.name.startswith("runtime-bundle-")):
                gz_files = [f.name for f in item.iterdir() if f.is_file() and f.name.endswith(".tar.gz")]
                physical_bundles[item.name] = gz_files

    updated_bundles = []

    for bid, gz_files in physical_bundles.items():
        if bid in existing_bundles:
            b_item = existing_bundles[bid]
            b_item["gz_files"] = sorted(gz_files)
            b_item["physical_retained"] = (len(gz_files) > 0)
            updated_bundles.append(b_item)
        else:
            b_item = {
                "bundle_id": bid,
                "folder_ref": f"distribution/customer-packages/{bid}",
                "gz_files": sorted(gz_files),
                "physical_retained": (len(gz_files) > 0)
            }
            updated_bundles.append(b_item)

    for bid, b_item in existing_bundles.items():
        if bid not in physical_bundles:
            b_item["physical_retained"] = False
            updated_bundles.append(b_item)

    updated_bundles.sort(key=lambda x: x.get("bundle_id", ""), reverse=True)
    index_data["bundles"] = updated_bundles
    index_data["generated_at"] = datetime.now(TZ_TW).isoformat()

    _atomic_write_json(portfolio_index_path, index_data)
    _atomic_write_json(artifacts_index_path, index_data)

    selectable_bundles = [b for b in updated_bundles if b.get("physical_retained") is True and len(b.get("gz_files", [])) > 0]
    selectable_index_data = {
        "schema_version": "v1.17.customer-package-folders-selectable-index.v1",
        "generated_at": index_data["generated_at"],
        "bundles": selectable_bundles
    }

    portfolio_selectable_path = package_builds_dir / "customer_package_folders_selectable_index.json"
    artifacts_selectable_path = artifacts_builds_dir / "customer_package_folders_selectable_index.json"

    _atomic_write_json(portfolio_selectable_path, selectable_index_data)
    _atomic_write_json(artifacts_selectable_path, selectable_index_data)

    physical_retained_count = len(selectable_bundles)
    stale_removed_or_marked_count = len(updated_bundles) - physical_retained_count

    reconciliation_report = {
        "verdict": "PASS",
        "reconciliation_report": {
            "previous_count": previous_count,
            "physical_retained_count": physical_retained_count,
            "stale_removed_or_marked_count": stale_removed_or_marked_count,
            "generated_at": index_data["generated_at"]
        }
    }

    portfolio_report_path = package_builds_dir / "customer_package_folders_reconciliation_report.json"
    artifacts_report_path = artifacts_builds_dir / "customer_package_folders_reconciliation_report.json"

    _atomic_write_json(portfolio_report_path, reconciliation_report)
    _atomic_write_json(artifacts_report_path, reconciliation_report)

    return reconciliation_report

def process_console_publish_preflight_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    bundle_id = str(payload.get("bundle_id", "")).strip()
    mode = str(payload.get("mode", "")).strip()

    if not bundle_id or ".." in bundle_id or "/" in bundle_id or "\\" in bundle_id:
        raise ValueError("DIRECTORY_TRAVERSAL_DETECTED")

    allowed_modes = {"enterprise_site", "solo_eval", "team_project"}
    if mode not in allowed_modes:
        raise ValueError("INVALID_MODE")

    cust_packages_dir = REPO_ROOT / "distribution" / "customer-packages"
    bundle_dir = cust_packages_dir / bundle_id

    if not bundle_dir.exists() or not bundle_dir.is_dir():
        return {
            "verdict": "BLOCKED",
            "preflight_id": "",
            "bundle_id": bundle_id,
            "resolved_file_count": 0,
            "resolved_file_digests": {},
            "preflight_digest": "",
            "target_repo_alias": "ic-agent-flow-customer-releases",
            "target_relative_dir": f"releases/{bundle_id}",
            "expires_at": "",
            "blocked_reasons": ["STALE_INDEX_OR_PHYSICAL_MISSING"]
        }

    gz_filename = f"ic-agent-flow-{mode.replace('_', '-')}-{bundle_id}.tar.gz"
    gz_file_path = bundle_dir / gz_filename

    if not gz_file_path.exists():
        gz_filename_alt = f"ic-agent-flow-{mode}-{bundle_id}.tar.gz"
        gz_file_path_alt = bundle_dir / gz_filename_alt
        if gz_file_path_alt.exists():
            gz_file_path = gz_file_path_alt
            gz_filename = gz_filename_alt

    if not gz_file_path.exists():
        return {
            "verdict": "BLOCKED",
            "preflight_id": "",
            "bundle_id": bundle_id,
            "resolved_file_count": 0,
            "resolved_file_digests": {},
            "preflight_digest": "",
            "target_repo_alias": "ic-agent-flow-customer-releases",
            "target_relative_dir": f"releases/{bundle_id}",
            "expires_at": "",
            "blocked_reasons": ["MODE_MISMATCH_OR_FILE_MISSING"]
        }

    # Guard: if this variant's gz already published to customer-releases, block preflight
    TARGET_REPO_ROOT = Path(os.environ.get("ICAF_TEST_CUSTOMER_RELEASES_ROOT", "/customer-home/imac/Documents/Code/ic-agent-flow-customer-releases"))
    already_published_gz = TARGET_REPO_ROOT / "releases" / bundle_id / gz_filename
    if already_published_gz.exists():
        return {
            "verdict": "BLOCKED",
            "preflight_id": "",
            "bundle_id": bundle_id,
            "resolved_file_count": 0,
            "resolved_file_digests": {},
            "preflight_digest": "",
            "target_repo_alias": "ic-agent-flow-customer-releases",
            "target_relative_dir": f"releases/{bundle_id}",
            "expires_at": "",
            "blocked_reasons": [f"VARIANT_ALREADY_PUBLISHED: {gz_filename} already exists in releases/{bundle_id}/"]
        }

    resolved_files: list[Path] = [gz_file_path]

    manifest_name = f"{mode}.manifest.json"
    manifest_path = bundle_dir / manifest_name
    if manifest_path.exists():
        resolved_files.append(manifest_path)

    checksum_name = f"{mode}.checksums.json"
    checksum_path = bundle_dir / checksum_name
    if checksum_path.exists():
        resolved_files.append(checksum_path)

    resolved_file_digests = {}
    for fp in resolved_files:
        fn_lower = fp.name.lower()
        if "internal_only" in fn_lower or "proprietary_secret" in fn_lower:
            continue
        h = hashlib.sha256(fp.read_bytes()).hexdigest()
        resolved_file_digests[fp.name] = h

    canonical_str = json.dumps(resolved_file_digests, sort_keys=True, ensure_ascii=False)
    preflight_digest = hashlib.sha256(canonical_str.encode("utf-8")).hexdigest()

    preflight_id = f"pf_tw_{datetime.now(TZ_TW).strftime('%Y%m%d_%H%M%S')}_{uuid4().hex[:6]}"
    expires_at = datetime.now(TZ_TW) + timedelta(minutes=10)

    preflight_record = {
        "verdict": "PASS",
        "preflight_id": preflight_id,
        "bundle_id": bundle_id,
        "mode": mode,
        "resolved_file_count": len(resolved_file_digests),
        "resolved_file_digests": resolved_file_digests,
        "preflight_digest": preflight_digest,
        "target_repo_alias": "ic-agent-flow-customer-releases",
        "target_relative_dir": f"releases/{bundle_id}",
        "expires_at": expires_at.isoformat(),
        "blocked_reasons": []
    }

    PREFLIGHT_CACHE[preflight_id] = preflight_record
    return preflight_record

def process_console_publish_to_customer_releases_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    bundle_id = str(payload.get("bundle_id", "")).strip()
    mode = str(payload.get("mode", "")).strip()
    preflight_id = str(payload.get("preflight_id", "")).strip()
    preflight_digest = str(payload.get("preflight_digest", "")).strip()

    TARGET_REPO_ROOT = Path(os.environ.get("ICAF_TEST_CUSTOMER_RELEASES_ROOT", "/customer-home/imac/Documents/Code/ic-agent-flow-customer-releases"))

    if not bundle_id or ".." in bundle_id or "/" in bundle_id or "\\" in bundle_id:
        raise ValueError("DIRECTORY_TRAVERSAL_DETECTED")

    if not TARGET_REPO_ROOT.exists():
        return {
            "verdict": "BLOCKED",
            "error": "TARGET_REPO_MISSING",
            "blocked_reasons": ["TARGET_REPO_MISSING"]
        }

    TARGET_RELEASES_DIR = TARGET_REPO_ROOT / "releases"
    TARGET_RELEASES_DIR.mkdir(parents=True, exist_ok=True)

    lock_file_path = TARGET_RELEASES_DIR / f".publish_{bundle_id}.lock"
    try:
        lock_fd = os.open(lock_file_path.as_posix(), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.close(lock_fd)
    except FileExistsError:
        return {
            "verdict": "BLOCKED",
            "error": "CONCURRENT_PUBLISH_BLOCKED",
            "blocked_reasons": ["CONCURRENT_PUBLISH_BLOCKED"]
        }

    tmp_staging_dir = TARGET_RELEASES_DIR / f".tmp_{bundle_id}"
    final_target_dir = TARGET_RELEASES_DIR / bundle_id

    def emit_failure_audit(reason_str: str) -> None:
        fail_record = {
            "schema_version": "v1.17.customer-publish-failure-audit.v1",
            "generated_at": datetime.now(TZ_TW).isoformat(),
            "bundle_id": bundle_id,
            "mode": mode,
            "preflight_id": preflight_id,
            "error_reason": reason_str,
            "lock_state": "ACTIVE_DURING_FAILURE",
            "staging_dir": f"releases/.tmp_{bundle_id}"
        }
        failed_dir = REPO_ROOT / "artifacts" / "customer-release-staging" / "failed-staging"
        failed_dir.mkdir(parents=True, exist_ok=True)
        fail_audit_path = failed_dir / f"failed_{bundle_id}_{datetime.now(TZ_TW).strftime('%Y%m%d_%H%M%S')}.json"
        _atomic_write_json(fail_audit_path, fail_record)

    try:
        if preflight_id not in PREFLIGHT_CACHE:
            emit_failure_audit("PREFLIGHT_NOT_FOUND")
            return {
                "verdict": "BLOCKED",
                "error": "PREFLIGHT_NOT_FOUND",
                "blocked_reasons": ["PREFLIGHT_NOT_FOUND"]
            }

        pf_cache = PREFLIGHT_CACHE[preflight_id]

        expires_at_dt = datetime.fromisoformat(pf_cache["expires_at"])
        if datetime.now(TZ_TW) > expires_at_dt:
            emit_failure_audit("PREFLIGHT_EXPIRED")
            return {
                "verdict": "BLOCKED",
                "error": "PREFLIGHT_EXPIRED",
                "blocked_reasons": ["PREFLIGHT_EXPIRED"]
            }

        if pf_cache["preflight_digest"] != preflight_digest:
            emit_failure_audit("PREFLIGHT_STALE")
            return {
                "verdict": "BLOCKED",
                "error": "PREFLIGHT_STALE",
                "blocked_reasons": ["PREFLIGHT_STALE"]
            }

        cust_packages_dir = REPO_ROOT / "distribution" / "customer-packages"
        bundle_dir = cust_packages_dir / bundle_id

        recalced_digests = {}
        for fname, expected_hash in pf_cache["resolved_file_digests"].items():
            fpath = bundle_dir / fname
            if not fpath.exists():
                emit_failure_audit("STALE_INDEX_OR_PHYSICAL_MISSING")
                return {
                    "verdict": "BLOCKED",
                    "error": "STALE_INDEX_OR_PHYSICAL_MISSING",
                    "blocked_reasons": ["STALE_INDEX_OR_PHYSICAL_MISSING"]
                }
            h = hashlib.sha256(fpath.read_bytes()).hexdigest()
            recalced_digests[fname] = h

        canonical_str = json.dumps(recalced_digests, sort_keys=True, ensure_ascii=False)
        recalced_digest = hashlib.sha256(canonical_str.encode("utf-8")).hexdigest()

        if recalced_digest != preflight_digest:
            emit_failure_audit("PREFLIGHT_STALE")
            return {
                "verdict": "BLOCKED",
                "error": "PREFLIGHT_STALE",
                "blocked_reasons": ["PREFLIGHT_STALE"]
            }

        if tmp_staging_dir.exists():
            emit_failure_audit("TMP_COLLISION_BLOCKED")
            return {
                "verdict": "BLOCKED",
                "error": "TMP_COLLISION_BLOCKED",
                "blocked_reasons": ["TMP_COLLISION_BLOCKED"]
            }

        # Variant-level guard: allow appending a new variant into an existing bundle dir.
        # Only block if the specific variant gz file is already present (idempotency guard).
        for fname in pf_cache["resolved_file_digests"]:
            dest_check = final_target_dir / fname
            if dest_check.exists():
                emit_failure_audit(f"VARIANT_ALREADY_PUBLISHED: {fname}")
                return {
                    "verdict": "BLOCKED",
                    "error": "VARIANT_ALREADY_PUBLISHED",
                    "blocked_reasons": [f"VARIANT_ALREADY_PUBLISHED: {fname} already exists in releases/{bundle_id}/"]
                }

        # Prepare final_target_dir (may already exist from a prior variant publish)
        final_target_dir.mkdir(parents=True, exist_ok=True)

        published_files = []
        for fname, fhash in recalced_digests.items():
            src_file = bundle_dir / fname
            dest_file = final_target_dir / fname
            dest_file.write_bytes(src_file.read_bytes())

            published_files.append({
                "filename": fname,
                "relative_path": f"releases/{bundle_id}/{fname}",
                "sha256": fhash
            })

        publish_manifest = {
            "schema_version": "v1.17.customer-publish-manifest.v1",
            "bundle_id": bundle_id,
            "mode": mode,
            "published_files": published_files,
            "preflight_id": preflight_id,
            "preflight_digest": preflight_digest,
            "generated_at": datetime.now(TZ_TW).isoformat()
        }

        publish_audit_record = {
            "schema_version": "v1.17.customer-publish-audit-record.v1",
            "generated_at": datetime.now(TZ_TW).isoformat(),
            "bundle_id": bundle_id,
            "mode": mode,
            "preflight_id": preflight_id,
            "operator_role": "RELEASE_OPERATOR",
            "lock_acquired": True,
            "atomic_staging_folder": f"releases/{bundle_id}",
            "atomic_rename_target": f"releases/{bundle_id}",
            "git_commit_performed": False,
            "git_push_performed": False,
            "published_files_count": len(published_files)
        }

        # Write manifest and audit record using variant-scoped filenames to avoid collisions
        manifest_fname = f"publish_manifest.{mode}.json"
        audit_fname = f"publish_audit_record.{mode}.json"
        _write_json(final_target_dir / manifest_fname, publish_manifest)
        _write_json(final_target_dir / audit_fname, publish_audit_record)

        return {
            "verdict": "PASS",
            "bundle_id": bundle_id,
            "published_file_count": len(published_files) + 2,
            "target_repo_alias": "ic-agent-flow-customer-releases",
            "target_relative_dir": f"releases/{bundle_id}",
            "manifest_relative_path": f"releases/{bundle_id}/publish_manifest.{mode}.json",
            "audit_record_relative_path": f"releases/{bundle_id}/publish_audit_record.{mode}.json",
            "git_status": {
                "commit_created": False,
                "push_performed": False
            }
        }

    except Exception as e:
        emit_failure_audit(f"EXCEPTION_CAUGHT: {str(e)}")
        if tmp_staging_dir.exists():
            try:
                import shutil
                shutil.rmtree(tmp_staging_dir)
            except Exception:
                pass
        raise e

    finally:
        if lock_file_path.exists():
            try:
                lock_file_path.unlink()
            except Exception:
                pass

class IntakeApiHandler(BaseHTTPRequestHandler):
    def do_GET(self) -> None:  # noqa: N802
        status, payload = handle_get_request(
            self.path,
            {
                "resolve_portfolio_inventory_route": resolve_portfolio_inventory_route,
                "process_portfolio_run_detail_payload": process_portfolio_run_detail_payload,
                "process_portfolio_chip_runs_payload": process_portfolio_chip_runs_payload,
                "process_portfolio_chips_payload": process_portfolio_chips_payload,
                "process_requirement_adjudication_context_payload": process_requirement_adjudication_context_payload,
                "process_upstream_chip_inventory_payload": process_upstream_chip_inventory_payload,
                "process_intake_session_context_payload": process_intake_session_context_payload,
                "process_upstream_file_family_payload": process_upstream_file_family_payload,
                "process_upstream_node_status_payload": process_upstream_node_status_payload,
                "build_options_payload": lambda: {
                    "templates_root": DEFAULT_TEMPLATES_ROOT,
                    "templates": discover_templates(DEFAULT_TEMPLATES_ROOT),
                    "server_boot_token": SERVER_BOOT_TOKEN,
                    "server_started_at": SERVER_STARTED_AT,
                    "package_mode": get_current_package_mode(),
                    "is_customer_package": (REPO_ROOT / "runtime" / "package_capabilities" / "customer_mode_entitlement_manifest.v1.json").exists(),
                },
                "process_downstream_decision_entrypoint_payload": process_downstream_decision_entrypoint_payload,
                "process_console_decision_state_payload": process_console_decision_state_payload,
                "process_console_audit_replay_payload": process_console_audit_replay_payload,
            },
        )
        self._send_json(status, payload)

    def do_POST(self) -> None:  # noqa: N802
        status, payload = handle_post_request(
            self.path,
            self.headers,
            self.rfile.read,
            {
                "process_intake_payload": process_intake_payload,
                "process_requirement_adjudication_submit_payload": process_requirement_adjudication_submit_payload,
                "process_agent_trust_action_payload": process_agent_trust_action_payload,
                "process_console_action_payload": process_console_action_payload,
                "process_downstream_decision_entrypoint_payload": process_downstream_decision_entrypoint_payload,
                "process_downstream_decision_action_payload": process_downstream_decision_action_payload,
                "process_console_sync_folders_payload": process_console_sync_folders_payload,
                "process_console_publish_preflight_payload": process_console_publish_preflight_payload,
                "process_console_publish_to_customer_releases_payload": process_console_publish_to_customer_releases_payload,
            },
        )
        self._send_json(status, payload)

    def log_message(self, format: str, *args) -> None:  # noqa: A003
        # keep local intake server quiet by default
        return

    def _send_json(self, status: int, payload: Dict[str, Any]) -> None:
        body = json.dumps(payload, indent=2).encode("utf-8")
        try:
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            # Client disconnected before response write completed.
            return


def serve(host: str, port: int) -> None:
    httpd = ThreadingHTTPServer((host, port), IntakeApiHandler)
    print(f"Intake API server listening on http://{host}:{port}/api/intake")
    httpd.serve_forever()


def main() -> None:
    parser = argparse.ArgumentParser(description="Requirement intake API server")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8787)
    parser.add_argument("--boot-token", default=None)
    args = parser.parse_args()
    global SERVER_BOOT_TOKEN
    if args.boot_token:
        SERVER_BOOT_TOKEN = str(args.boot_token)
    serve(args.host, args.port)


if __name__ == "__main__":
    main()
