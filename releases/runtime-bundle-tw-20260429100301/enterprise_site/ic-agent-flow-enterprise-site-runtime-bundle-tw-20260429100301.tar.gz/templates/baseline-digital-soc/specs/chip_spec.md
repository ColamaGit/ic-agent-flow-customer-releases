# Chip Specification: Baseline Digital SoC

## 1. Overview
This is a baseline digital SoC template for IC-Agent-Flow. It provides the minimum viable structure for agent-guided design and verification.

## 2. Target Parameters
- **Process**: Generic 7nm
- **Clock Frequency**: 1GHz
- **Interface**: 8-bit Parallel Data
- **Power Target**: <10mW (Idle)

## 3. Evidence Requirements
- **LINT**: 0 Errors, <5 Warnings.
- **CDC**: Clean for all domain crossings.
- **Timing**: Setup/Hold met for 1GHz target.
