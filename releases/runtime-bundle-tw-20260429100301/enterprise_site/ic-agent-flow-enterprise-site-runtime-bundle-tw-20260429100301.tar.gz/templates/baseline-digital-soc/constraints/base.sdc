# Baseline SDC Constraints

# Create Clock
create_clock -name sys_clk -period 1.0 [get_ports clk]

# Input/Output Delays
set_input_delay 0.2 [all_inputs] -clock sys_clk
set_output_delay 0.2 [all_outputs] -clock sys_clk

# Design DRC
set_max_fanout 32 [current_design]
set_max_transition 0.1 [current_design]
