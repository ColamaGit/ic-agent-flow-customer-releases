`timescale 1ns/1ps

module top_tb;
    reg clk;
    reg rst_n;
    reg [7:0] data_in;
    wire [7:0] data_out;

    top dut (
        .clk(clk),
        .rst_n(rst_n),
        .data_in(data_in),
        .data_out(data_out)
    );

    always #5 clk = ~clk;

    initial begin
        clk = 1'b0;
        rst_n = 1'b0;
        data_in = 8'h00;

        #12;
        rst_n = 1'b1;
        data_in = 8'hA5;

        #10;
        assert (data_out === 8'hA5)
            else begin
                $display("SN2025_ASSERT_FAIL expected=A5 got=%02h", data_out);
                $fatal(1);
            end
        if (data_out !== 8'hA5) begin
            $display("SN2025_SIM_FAIL expected=A5 got=%02h", data_out);
            $fatal(1);
        end

        $display("SN2025_SIM_PASS");
        $finish;
    end

    initial begin
        #100;
        $display("SN2025_SIM_TIMEOUT");
        $fatal(1);
    end
endmodule
