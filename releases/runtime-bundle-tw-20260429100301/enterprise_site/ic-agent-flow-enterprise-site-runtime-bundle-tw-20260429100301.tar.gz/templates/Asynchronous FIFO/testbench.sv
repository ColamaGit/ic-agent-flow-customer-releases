// Code your testbench here
// or browse Examples
module asynchronous_fifo_tb;

  parameter DATA_WIDTH = 8;

  wire [DATA_WIDTH-1:0] data_out;
  wire full;
  wire empty;
  reg [DATA_WIDTH-1:0] data_in;
  reg w_en, wclock, wreset;
  reg r_en, rclock, rreset;
 

  reg [DATA_WIDTH-1:0] expected_q[$];
  reg [DATA_WIDTH-1:0] expected_data;

  asynchronous_fifo as_fifo (wclock, wreset,rclock, rreset,w_en,r_en,data_in,data_out,full,empty);
  always #10 wclock = ~wclock;
  always #35 rclock = ~rclock;
  
  initial begin
    wclock = 1'b0; wreset = 1'b0;
    w_en = 1'b0;
    data_in = 0;
    repeat(4) @(posedge wclock);
    wreset = 1'b1;

    for (int idx = 0; idx < 4; idx++) begin
      @(posedge wclock);
      w_en = 1'b1;
      case (idx)
        0: data_in = 8'h11;
        1: data_in = 8'h22;
        2: data_in = 8'h33;
        default: data_in = 8'h44;
      endcase
      expected_q.push_back(data_in);
    end
    @(posedge wclock);
    w_en = 1'b0;
  end
  
  initial begin
    rclock = 1'b0;
    rreset = 1'b0;
    r_en = 1'b0;

    repeat(4) @(posedge rclock);
    rreset = 1'b1;
    repeat(8) @(posedge rclock);

    repeat (4) begin
      wait (!empty);
      expected_data = expected_q.pop_front();
      #1;
      assert (data_out === expected_data)
        else $error("ASYNC_FIFO_ASSERT_FAIL expected=%h got=%h", expected_data, data_out);
      if (data_out !== expected_data) begin
        $error("Time = %0t: Comparison Failed: expected wr_data = %h, rd_data = %h", $time, expected_data, data_out);
      end else begin
        $display("Time = %0t: Comparison Passed: wr_data = %h and rd_data = %h", $time, expected_data, data_out);
      end

      @(posedge rclock);
      r_en = 1'b1;
      @(posedge rclock);
      r_en = 1'b0;
    end

    $display("ASYNC_FIFO_SIM_PASS");
    $finish;
  end

  initial begin
    repeat (120) @(posedge wclock);
    $error("ASYNC FIFO simulation watchdog timeout");
    $finish;
  end

  initial begin 
    $dumpfile("dump.vcd"); 
    $dumpvars;
  end

endmodule
