# Async FIFO chip-scoped constraints

create_clock -name wclk -period 2.0 [get_ports wclock]
create_clock -name rclk -period 3.5 [get_ports rclock]
set_clock_groups -asynchronous -group [get_clocks wclk] -group [get_clocks rclk]
set_input_delay 0.2 [get_ports {data_in[*] w_en}] -clock wclk
set_input_delay 0.2 [get_ports {r_en}] -clock rclk
set_output_delay 0.2 [get_ports {data_out[*] empty}] -clock rclk
set_output_delay 0.2 [get_ports {full}] -clock wclk
set_false_path -from [get_ports {wreset rreset}]
set_max_fanout 32 [current_design]
set_max_transition 0.20 [current_design]
