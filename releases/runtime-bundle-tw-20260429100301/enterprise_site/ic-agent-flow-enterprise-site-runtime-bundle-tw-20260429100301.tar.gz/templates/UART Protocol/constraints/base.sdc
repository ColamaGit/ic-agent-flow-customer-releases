# UART chip-scoped constraints

create_clock -name sys_clk -period 1.0 [get_ports clk]
set_input_delay 0.2 [get_ports {sel[*] TX_start TX_DATA[*]}] -clock sys_clk
set_output_delay 0.2 [get_ports {stop_error parity_error RX_dataout[*]}] -clock sys_clk
set_false_path -from [get_ports reset]
set_max_fanout 32 [current_design]
set_max_transition 0.15 [current_design]
