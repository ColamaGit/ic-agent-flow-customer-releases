#!/usr/bin/env python3
from __future__ import annotations

import argparse
import importlib.util
import json
import os
import subprocess
import sys
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator


ENV_OVERRIDE_MAP = {
    "verilator_bin": "ICAF_VERILATOR_BIN",
    "yosys_bin": "ICAF_YOSYS_BIN",
    "openroad_bin": "ICAF_OPENROAD_BIN",
    "netgen_bin": "ICAF_NETGEN_BIN",
    "klayout_python_bin": "ICAF_KLAYOUT_PYTHON_BIN",
    "nangate45_root": "ICAF_NANGATE45_ROOT",
    "nangate45_lib_path": "ICAF_NANGATE45_LIB_PATH",
    "nangate45_tech_lef_path": "ICAF_NANGATE45_TECH_LEF_PATH",
    "nangate45_stdcell_lef_path": "ICAF_NANGATE45_STDCELL_LEF_PATH",
    "nangate45_tracks_path": "ICAF_NANGATE45_TRACKS_PATH",
}


def _parse_yaml_scalar(raw: str) -> Any:
    value = raw.strip()
    if value in {"null", "~"}:
        return None
    if value.lower() == "true":
        return True
    if value.lower() == "false":
        return False
    if value.isdigit():
        return int(value)
    return value


def _parse_simple_yaml(path: Path) -> dict[str, Any]:
    lines = path.read_text(encoding="utf-8").splitlines()
    tokens: list[tuple[int, str]] = []
    for line in lines:
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        indent = len(line) - len(line.lstrip(" "))
        tokens.append((indent, stripped))

    def parse_block(start: int, indent: int) -> tuple[Any, int]:
        container: Any = None
        i = start
        while i < len(tokens):
            line_indent, text = tokens[i]
            if line_indent < indent:
                break
            if line_indent > indent:
                raise ValueError(f"Unexpected indentation at {path}:{i + 1}")
            if text.startswith("- "):
                if container is None:
                    container = []
                if not isinstance(container, list):
                    raise ValueError(f"Mixed mapping/list structure at {path}:{i + 1}")
                item_text = text[2:].strip()
                if not item_text:
                    child, next_index = parse_block(i + 1, indent + 2)
                    container.append(child)
                    i = next_index
                    continue
                container.append(_parse_yaml_scalar(item_text))
                i += 1
                continue
            if container is None:
                container = {}
            if not isinstance(container, dict):
                raise ValueError(f"Mixed mapping/list structure at {path}:{i + 1}")
            if ":" not in text:
                raise ValueError(f"Malformed YAML line at {path}:{i + 1}")
            key, raw_value = text.split(":", 1)
            key = key.strip()
            raw_value = raw_value.strip()
            if raw_value:
                container[key] = _parse_yaml_scalar(raw_value)
                i += 1
                continue
            next_indent = tokens[i + 1][0] if i + 1 < len(tokens) else None
            if next_indent is None or next_indent <= indent:
                container[key] = {}
                i += 1
                continue
            child, next_index = parse_block(i + 1, indent + 2)
            container[key] = child
            i = next_index
        return container if container is not None else {}, i

    parsed, _ = parse_block(0, 0)
    if not isinstance(parsed, dict):
        raise ValueError(f"Root YAML object must be a mapping: {path}")
    return parsed


def _deployment_profile_path(repo_root: Path, deployment_profile: str | None) -> Path | None:
    if not deployment_profile:
        return None
    path = repo_root / "deployment" / "profiles" / deployment_profile / "profile.yaml"
    if path.exists():
        return path
    return None


def _load_deployment_profile_config(repo_root: Path, deployment_profile: str | None) -> dict[str, Any]:
    path = _deployment_profile_path(repo_root, deployment_profile)
    if not path:
        return {}
    return _parse_simple_yaml(path)


def _parse_override(text: str) -> tuple[str, str]:
    if "=" not in text:
        raise ValueError(f"override must use key=value form: {text}")
    key, value = text.split("=", 1)
    key = key.strip()
    value = value.strip()
    if not key or not value:
        raise ValueError(f"override must use key=value form: {text}")
    if key not in ENV_OVERRIDE_MAP:
        raise ValueError(f"unsupported override key: {key}")
    return key, value


def _resolve_internal_runner_path(repo_root: Path) -> Path:
    runner_path = repo_root / "workspace" / "shared-runtime" / "scripts" / "governance_pipeline_runner.py"
    if not runner_path.exists():
        raise FileNotFoundError(
            "repo-compatible layout not found; internal governed runner is unavailable. "
            "Use a site-bound or release-bound rerun entrypoint for packaged installs without workspace/ paths."
        )
    return runner_path


def _load_runner_module(repo_root: Path):
    runner_path = _resolve_internal_runner_path(repo_root)
    spec = importlib.util.spec_from_file_location("customer_local_governance_runner", runner_path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def _resolve_release_runtime_entrypoint(
    repo_root: Path,
    deployment_profile: str | None,
    explicit_entrypoint: str | None = None,
) -> Path | None:
    if explicit_entrypoint:
        return (repo_root / explicit_entrypoint).resolve() if not Path(explicit_entrypoint).is_absolute() else Path(explicit_entrypoint)
    profile_data = _load_deployment_profile_config(repo_root, deployment_profile)
    configured = profile_data.get("customer_local_rerun", {}).get("release_runtime_entrypoint")
    if not configured:
        return None
    return (repo_root / configured).resolve() if not Path(configured).is_absolute() else Path(configured)


def _invoke_release_runtime_entrypoint(entrypoint: Path, payload: dict[str, Any], env: dict[str, str]) -> dict[str, Any]:
    if not entrypoint.exists():
        raise FileNotFoundError(f"release-bound runtime entrypoint not found: {entrypoint}")
    proc = subprocess.run(
        [sys.executable, str(entrypoint), json.dumps(payload, ensure_ascii=True)],
        capture_output=True,
        text=True,
        check=True,
        env=env,
        cwd=payload["repo_root"],
    )
    return json.loads(proc.stdout)


@contextmanager
def _temporary_environment(deployment_profile: str | None, overrides: dict[str, str] | None) -> Iterator[None]:
    saved: dict[str, str | None] = {}
    try:
        if deployment_profile is not None:
            key = "ICAF_DEPLOYMENT_PROFILE"
            saved[key] = os.environ.get(key)
            os.environ[key] = deployment_profile
        for override_key, override_value in (overrides or {}).items():
            env_key = ENV_OVERRIDE_MAP[override_key]
            saved[env_key] = os.environ.get(env_key)
            os.environ[env_key] = override_value
        yield
    finally:
        for key, old_value in saved.items():
            if old_value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = old_value


def run_customer_local_readiness(
    repo_root: Path,
    chip_id: str,
    task_id: str,
    rtl_src: Path,
    chip_name: str,
    rtl_function: str,
    deployment_profile: str | None = None,
    overrides: dict[str, str] | None = None,
    technology_context: str = "SKY130 / OpenLane baseline",
    release_runtime_entrypoint: str | None = None,
) -> dict[str, str]:
    repo_root = repo_root.resolve()
    rtl_src = rtl_src.resolve()
    if not rtl_src.exists():
        raise FileNotFoundError(f"rtl source not found: {rtl_src}")
    resolved_entrypoint = _resolve_release_runtime_entrypoint(
        repo_root=repo_root,
        deployment_profile=deployment_profile,
        explicit_entrypoint=release_runtime_entrypoint,
    )

    with _temporary_environment(deployment_profile, overrides):
        env = dict(os.environ)
        if resolved_entrypoint:
            result = _invoke_release_runtime_entrypoint(
                resolved_entrypoint,
                {
                    "repo_root": str(repo_root),
                    "chip_id": chip_id,
                    "task_id": task_id,
                    "rtl_src": str(rtl_src),
                    "chip_name": chip_name,
                    "rtl_function": rtl_function,
                    "deployment_profile": deployment_profile or "",
                    "technology_context": technology_context,
                },
                env,
            )
        else:
            runner_mod = _load_runner_module(repo_root)
            run_dir = runner_mod.run_governed_pipeline(
                chip_id=chip_id,
                task_id=task_id,
                rtl_src=str(rtl_src),
                chip_name=chip_name,
                rtl_function=rtl_function,
                technology_context=technology_context,
            )
            run_path = Path(run_dir)
            result = {
                "status": "PASS",
                "run_dir": str(run_path),
                "readiness_report": str(run_path / "readiness_report.v0.2.md"),
                "readiness_manifest": str(run_path / "readiness_report_manifest.v0.2.json"),
            }

    run_path = Path(result["run_dir"])
    report_path = Path(result["readiness_report"])
    manifest_path = Path(result["readiness_manifest"])
    if not report_path.exists() or not manifest_path.exists():
        raise FileNotFoundError(f"expected readiness artifacts missing under run dir: {run_path}")

    result["repo_root"] = str(repo_root)
    result["deployment_profile"] = deployment_profile or ""
    result["release_runtime_entrypoint"] = str(resolved_entrypoint) if resolved_entrypoint else ""
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-root", default=".")
    parser.add_argument("--chip-id", required=True)
    parser.add_argument("--task-id", required=True)
    parser.add_argument("--rtl-src", required=True)
    parser.add_argument("--chip-name", required=True)
    parser.add_argument("--rtl-function", required=True)
    parser.add_argument("--deployment-profile")
    parser.add_argument("--release-runtime-entrypoint")
    parser.add_argument("--technology-context", default="SKY130 / OpenLane baseline")
    parser.add_argument(
        "--override",
        action="append",
        default=[],
        help="customer-local override in key=value form",
    )
    args = parser.parse_args()

    overrides = dict(_parse_override(text) for text in args.override)
    result = run_customer_local_readiness(
        repo_root=Path(args.repo_root),
        chip_id=args.chip_id,
        task_id=args.task_id,
        rtl_src=Path(args.rtl_src),
        chip_name=args.chip_name,
        rtl_function=args.rtl_function,
        deployment_profile=args.deployment_profile,
        overrides=overrides,
        technology_context=args.technology_context,
        release_runtime_entrypoint=args.release_runtime_entrypoint,
    )
    print(json.dumps(result, ensure_ascii=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
