#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path


def run_healthcheck(install_root: Path) -> dict[str, str]:
    receipt_path = install_root / "installation_receipt.json"
    if not receipt_path.exists():
        raise FileNotFoundError(f"missing installation receipt: {receipt_path}")

    receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
    runtime_mode = receipt.get("runtime_mode", "source_overlay")
    if runtime_mode == "offline_wheelhouse":
        python_bin = install_root / ".venv" / "bin" / "python"
        if not python_bin.exists():
            raise FileNotFoundError(f"missing python binary: {python_bin}")
        subprocess.run(
            [str(python_bin), "-c", "import ic_agent_flow; print('ic_agent_flow import ok')"],
            check=True,
        )
    else:
        source_root = install_root / "runtime" / "source"
        if not source_root.exists():
            raise FileNotFoundError(f"missing runtime source: {source_root}")
        subprocess.run(
            [
                "python3",
                "-c",
                "import sys; sys.path.insert(0, r'%s'); import ic_agent_flow; print('ic_agent_flow import ok')"
                % source_root,
            ],
            check=True,
        )

    profile_path = install_root / "deployment" / "profiles" / "airgap-local" / "profile.yaml"
    if not profile_path.exists():
        raise FileNotFoundError(f"missing deployment profile: {profile_path}")

    return {
        "status": "PASS",
        "install_root": str(install_root),
        "runtime_mode": str(runtime_mode),
        "wheel_count": str(receipt.get("wheel_count", "0")),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--install-root", required=True)
    args = parser.parse_args()

    result = run_healthcheck(Path(args.install_root).resolve())
    print(json.dumps(result, ensure_ascii=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
