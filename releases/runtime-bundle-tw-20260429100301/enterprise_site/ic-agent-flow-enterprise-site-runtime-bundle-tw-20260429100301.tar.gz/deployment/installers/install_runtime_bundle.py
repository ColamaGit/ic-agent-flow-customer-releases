#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path


def _utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _copy_tree(src: Path, dst: Path) -> None:
    if not src.exists():
        return
    shutil.copytree(src, dst, dirs_exist_ok=True)


def install_bundle(bundle_root: Path, install_root: Path, python_bin: str = "python3") -> Path:
    wheelhouse = bundle_root / "runtime" / "wheelhouse"
    runtime_source = bundle_root / "runtime" / "source"
    wheels = sorted(wheelhouse.glob("*.whl")) if wheelhouse.exists() else []

    install_root.mkdir(parents=True, exist_ok=True)
    runtime_mode = "source_overlay"
    if wheels:
        venv_dir = install_root / ".venv"
        subprocess.run([python_bin, "-m", "venv", str(venv_dir)], check=True)
        pip_bin = venv_dir / "bin" / "pip"
        if not pip_bin.exists():
            raise FileNotFoundError(f"missing pip in venv: {pip_bin}")

        subprocess.run(
            [
                str(pip_bin),
                "install",
                "--no-index",
                "--find-links",
                str(wheelhouse),
                "ic-agent-flow",
            ],
            check=True,
        )
        runtime_mode = "offline_wheelhouse"
    else:
        if not runtime_source.exists():
            raise FileNotFoundError("missing runtime/source payload for source overlay mode")
        _copy_tree(runtime_source, install_root / "runtime" / "source")

    _copy_tree(bundle_root / "product", install_root / "product")
    _copy_tree(bundle_root / "deployment" / "profiles", install_root / "deployment" / "profiles")

    receipt = {
        "installed_at": _utc_now(),
        "bundle_root": str(bundle_root),
        "install_root": str(install_root),
        "python_bin": python_bin,
        "runtime_mode": runtime_mode,
        "wheel_count": len(wheels),
        "status": "SUCCESS",
    }
    receipt_path = install_root / "installation_receipt.json"
    receipt_path.write_text(json.dumps(receipt, ensure_ascii=True, indent=2) + "\n", encoding="utf-8")
    return receipt_path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bundle-root", required=True)
    parser.add_argument("--install-root", required=True)
    parser.add_argument("--python-bin", default="python3")
    args = parser.parse_args()

    receipt = install_bundle(
        bundle_root=Path(args.bundle_root).resolve(),
        install_root=Path(args.install_root).resolve(),
        python_bin=args.python_bin,
    )
    print(f"Installation completed: {receipt}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
