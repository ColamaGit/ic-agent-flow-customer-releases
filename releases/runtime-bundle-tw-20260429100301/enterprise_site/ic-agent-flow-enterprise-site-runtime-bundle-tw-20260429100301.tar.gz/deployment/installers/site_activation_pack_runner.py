#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def _utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _write_json(path: Path, payload: dict[str, Any]) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=True, indent=2) + "\n", encoding="utf-8")
    return str(path)


def _sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _which_or_empty(binary: str) -> str:
    resolved = shutil.which(binary)
    return resolved or ""


def build_eda_toolchain_binding_manifest(
    *,
    site_id: str,
    profile_ref: str,
    output_path: Path,
    toolchain_profile_id: str = "default-local-host",
) -> dict[str, Any]:
    bindings = []
    for tool_id, tool_type, binary in [
        ("verilator_v1", "h0_v1_verilator", "verilator"),
        ("verilator_v2", "h0_v2_verilator", "verilator"),
        ("yosys_h1", "h1_yosys", "yosys"),
        ("openroad_h2", "h2_openroad", "openroad"),
        ("klayout_h4", "h4_klayout", "klayout"),
        ("netgen_h3", "h3_netgen", "netgen"),
    ]:
        exe = _which_or_empty(binary)
        bindings.append(
            {
                "tool_id": tool_id,
                "tool_type": tool_type,
                "resolution_mode": "local_binary",
                "executable_ref": exe or f"missing:{binary}",
                "resolved_version": "detected" if exe else "not_detected",
                "license_env_keys": ["LM_LICENSE_FILE"] if tool_type in {"h2_openroad", "h4_klayout", "h3_netgen"} else [],
                "adapter_policy_ref": "eda_tool_adapter_policy.v0.1/default",
            }
        )

    payload = {
        "id": f"eda-binding-{site_id}",
        "type": "eda_toolchain_binding_manifest",
        "version": "0.1",
        "site_id": site_id,
        "profile_ref": profile_ref,
        "toolchain_profile_id": toolchain_profile_id,
        "tool_bindings": bindings,
        "redaction_policy_ref": "eda_license_env_redaction_policy.v0.1/default",
        "generated_at": _utc_now(),
        "digest": _sha256_text(json.dumps(bindings, sort_keys=True)),
        "signature": {"algorithm": "sha256", "key_id": "local-dev-key"},
    }
    _write_json(output_path, payload)
    return payload


def build_eda_toolchain_preflight_report(
    *,
    site_id: str,
    profile_ref: str,
    binding_manifest_path: Path,
    output_path: Path,
) -> dict[str, Any]:
    binding_payload = json.loads(binding_manifest_path.read_text(encoding="utf-8"))
    checks = []
    present_count = 0
    for row in binding_payload.get("tool_bindings", []):
        ok = not str(row.get("executable_ref", "")).startswith("missing:")
        if ok:
            present_count += 1
        checks.append(
            {
                "check_id": f"tool_present:{row.get('tool_id','unknown')}",
                "status": "PASS" if ok else "WARN",
                "evidence_ref": str(binding_manifest_path),
                "detail": row.get("executable_ref", ""),
            }
        )
    if present_count == 0:
        verdict = "BLOCKED"
        blocked_reasons = ["no_tool_resolved"]
    elif present_count < len(checks):
        verdict = "PASS_WITH_WARNINGS"
        blocked_reasons = []
    else:
        verdict = "PASS"
        blocked_reasons = []

    payload = {
        "id": f"eda-preflight-{site_id}",
        "type": "eda_toolchain_preflight_report",
        "version": "0.1",
        "site_id": site_id,
        "profile_ref": profile_ref,
        "binding_manifest_ref": str(binding_manifest_path),
        "verdict": verdict,
        "checks": checks,
        "blocked_reasons": blocked_reasons,
        "generated_at": _utc_now(),
    }
    _write_json(output_path, payload)
    return payload


def build_backend_secret_binding_record(
    *,
    site_id: str,
    profile_ref: str,
    backend_provider: str,
    output_path: Path,
    binding_mode: str = "env_var",
) -> dict[str, Any]:
    if backend_provider == "openai":
        secret_refs = [
            {"secret_name": "OPENAI_API_KEY", "secret_ref": "env:OPENAI_API_KEY", "required": True, "redacted": True},
            {"secret_name": "OPENAI_MODEL", "secret_ref": "env:OPENAI_MODEL", "required": False, "redacted": False},
        ]
    else:
        secret_refs = [{"secret_name": "BACKEND_API_KEY", "secret_ref": "env:BACKEND_API_KEY", "required": True, "redacted": True}]

    payload = {
        "id": f"backend-secret-binding-{site_id}",
        "type": "backend_secret_binding_record",
        "version": "0.1",
        "site_id": site_id,
        "profile_ref": profile_ref,
        "backend_provider": backend_provider,
        "binding_mode": binding_mode,
        "secret_refs": secret_refs,
        "routing_policy_ref": f"routing-policy/{profile_ref}",
        "generated_at": _utc_now(),
    }
    _write_json(output_path, payload)
    return payload


def build_backend_secret_preflight_report(
    *,
    site_id: str,
    profile_ref: str,
    binding_record_path: Path,
    output_path: Path,
    openai_mode: str,
) -> dict[str, Any]:
    payload = json.loads(binding_record_path.read_text(encoding="utf-8"))
    provider = payload.get("backend_provider", "")
    required_env = "OPENAI_API_KEY" if provider == "openai" else "BACKEND_API_KEY"
    has_key = bool(os.environ.get(required_env))
    blocked_by_profile = profile_ref == "airgap_local" and provider == "openai"
    routing_allowed = not blocked_by_profile

    if not has_key or not routing_allowed:
        verdict = "BLOCKED"
    elif openai_mode == "live":
        verdict = "PASS"
    else:
        verdict = "PASS_WITH_WARNINGS"

    checks = [
        {"check_id": f"secret_present:{required_env}", "status": "PASS" if has_key else "FAIL", "detail": "value redacted"},
        {"check_id": "routing_allowed_by_profile", "status": "PASS" if routing_allowed else "FAIL", "detail": profile_ref},
    ]
    if openai_mode != "live":
        checks.append({"check_id": "openai_mode_live", "status": "WARN", "detail": openai_mode})

    report = {
        "id": f"backend-secret-preflight-{site_id}",
        "type": "backend_secret_preflight_report",
        "version": "0.1",
        "site_id": site_id,
        "profile_ref": profile_ref,
        "binding_record_ref": str(binding_record_path),
        "verdict": verdict,
        "routing_allowed": routing_allowed,
        "blocked_by_profile": blocked_by_profile,
        "checks": checks,
        "generated_at": _utc_now(),
    }
    _write_json(output_path, report)
    return report


def _file_contains_secret(path: Path, secret_value: str) -> bool:
    if not secret_value:
        return False
    if path.stat().st_size > 2 * 1024 * 1024:
        return False
    try:
        data = path.read_text(encoding="utf-8", errors="ignore")
    except Exception:  # noqa: BLE001
        return False
    return secret_value in data


def build_secret_redaction_verification_report(
    *,
    binding_record_path: Path,
    scan_root: Path,
    output_path: Path,
) -> dict[str, Any]:
    binding = json.loads(binding_record_path.read_text(encoding="utf-8"))
    provider = binding.get("backend_provider", "")
    secret_key = "OPENAI_API_KEY" if provider == "openai" else "BACKEND_API_KEY"
    secret_value = os.environ.get(secret_key, "")

    findings = []
    leakage_detected = False
    if secret_value:
        for path in scan_root.rglob("*"):
            if not path.is_file():
                continue
            if _file_contains_secret(path, secret_value):
                leakage_detected = True
                findings.append({"scope": str(path), "status": "FAIL", "detail": "secret literal detected"})
                if len(findings) >= 10:
                    break

    if not findings:
        findings = [
            {"scope": "package_artifact", "status": "PASS", "detail": "no literal secret detected"},
            {"scope": "runtime_log", "status": "PASS", "detail": "no literal secret detected"},
            {"scope": "support_bundle", "status": "PASS", "detail": "no literal secret detected"},
            {"scope": "readiness_report", "status": "PASS", "detail": "no literal secret detected"},
        ]

    report = {
        "id": f"secret-redaction-verification-{binding.get('site_id','site')}",
        "type": "secret_redaction_verification_report",
        "version": "0.1",
        "binding_record_ref": str(binding_record_path),
        "target_scopes": ["package_artifact", "runtime_log", "support_bundle", "readiness_report"],
        "verdict": "BLOCKED" if leakage_detected else "PASS",
        "secret_leakage_detected": leakage_detected,
        "findings": findings,
        "generated_at": _utc_now(),
    }
    _write_json(output_path, report)
    return report


def build_enterprise_site_activation_pack_manifest(
    *,
    runtime_bundle_ref: str,
    output_path: Path,
) -> dict[str, Any]:
    payload = {
        "id": "enterprise-activation-pack-default",
        "type": "enterprise_site_activation_pack_manifest",
        "version": "0.1",
        "runtime_bundle_ref": runtime_bundle_ref,
        "activation_pack_id": "enterprise-site-default",
        "target_mode": "enterprise_site",
        "required_roles": ["operator", "reviewer", "approver", "auditor", "security_owner", "release_board"],
        "approval_quorum": {"min_approvers": 2, "mandatory_roles": ["approver", "auditor"]},
        "required_records": [
            "customer_site_activation",
            "site_runtime_manifest",
            "eda_toolchain_binding_manifest",
            "eda_toolchain_preflight_report",
            "backend_secret_binding_record",
            "backend_secret_preflight_report",
            "secret_redaction_verification_report",
        ],
        "claim_boundary": "enterprise activation requires quorum and governed preflight evidence",
        "generated_at": _utc_now(),
    }
    _write_json(output_path, payload)
    return payload


def materialize_p2_contracts(
    *,
    output_root: Path,
    site_id: str,
    profile_ref: str,
    backend_provider: str,
    runtime_bundle_ref: str,
    scan_root: Path,
    openai_mode: str,
) -> dict[str, str]:
    output_root.mkdir(parents=True, exist_ok=True)
    eda_binding = output_root / "eda_toolchain_binding_manifest.json"
    eda_preflight = output_root / "eda_toolchain_preflight_report.json"
    secret_binding = output_root / "backend_secret_binding_record.json"
    secret_preflight = output_root / "backend_secret_preflight_report.json"
    secret_redaction = output_root / "secret_redaction_verification_report.json"
    enterprise_pack = output_root / "enterprise_site_activation_pack_manifest.json"

    build_eda_toolchain_binding_manifest(site_id=site_id, profile_ref=profile_ref, output_path=eda_binding)
    build_eda_toolchain_preflight_report(
        site_id=site_id,
        profile_ref=profile_ref,
        binding_manifest_path=eda_binding,
        output_path=eda_preflight,
    )
    build_backend_secret_binding_record(
        site_id=site_id,
        profile_ref=profile_ref,
        backend_provider=backend_provider,
        output_path=secret_binding,
    )
    build_backend_secret_preflight_report(
        site_id=site_id,
        profile_ref=profile_ref,
        binding_record_path=secret_binding,
        output_path=secret_preflight,
        openai_mode=openai_mode,
    )
    build_secret_redaction_verification_report(
        binding_record_path=secret_binding,
        scan_root=scan_root,
        output_path=secret_redaction,
    )
    build_enterprise_site_activation_pack_manifest(runtime_bundle_ref=runtime_bundle_ref, output_path=enterprise_pack)
    return {
        "eda_toolchain_binding_manifest_ref": str(eda_binding),
        "eda_toolchain_preflight_report_ref": str(eda_preflight),
        "backend_secret_binding_record_ref": str(secret_binding),
        "backend_secret_preflight_report_ref": str(secret_preflight),
        "secret_redaction_verification_report_ref": str(secret_redaction),
        "enterprise_site_activation_pack_manifest_ref": str(enterprise_pack),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-root", required=True)
    parser.add_argument("--site-id", required=True)
    parser.add_argument("--profile-ref", required=True)
    parser.add_argument("--backend-provider", default="openai")
    parser.add_argument("--runtime-bundle-ref", required=True)
    parser.add_argument("--scan-root", required=True)
    parser.add_argument("--openai-mode", default="live")
    args = parser.parse_args()

    refs = materialize_p2_contracts(
        output_root=Path(args.output_root).resolve(),
        site_id=args.site_id,
        profile_ref=args.profile_ref,
        backend_provider=args.backend_provider,
        runtime_bundle_ref=args.runtime_bundle_ref,
        scan_root=Path(args.scan_root).resolve(),
        openai_mode=args.openai_mode,
    )
    print(json.dumps(refs, ensure_ascii=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
