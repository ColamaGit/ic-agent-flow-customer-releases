#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

# Allow running as a direct script from repo or extracted package roots.
_THIS_FILE = Path(__file__).resolve()
_REPO_ROOT = _THIS_FILE.parents[2]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from deployment.installers.site_activation_pack_runner import (
    build_backend_secret_binding_record,
    build_backend_secret_preflight_report,
    build_eda_toolchain_binding_manifest,
    build_eda_toolchain_preflight_report,
    build_secret_redaction_verification_report,
)


def _parse_simple_yaml(text: str) -> dict[str, Any]:
    payload: dict[str, Any] = {}
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        payload[key.strip()] = value.strip().strip("'\"")
    return payload


def _load_config(path: Path) -> dict[str, Any]:
    text = path.read_text(encoding="utf-8")
    try:
        obj = json.loads(text)
        if isinstance(obj, dict):
            return obj
    except json.JSONDecodeError:
        pass
    return _parse_simple_yaml(text)


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=True, indent=2) + "\n", encoding="utf-8")


def _run_site_bind_eda(args: argparse.Namespace) -> dict[str, Any]:
    config = _load_config(Path(args.config)) if args.config else {}
    site_id = args.site_id or config.get("site_id", "site-default")
    profile_ref = args.profile_ref or config.get("profile_ref", "customer_managed_vpc")
    toolchain_profile_id = args.toolchain_profile_id or config.get("toolchain_profile_id", "default-local-host")
    output_root = Path(args.output_root).resolve()
    output_root.mkdir(parents=True, exist_ok=True)

    binding_path = output_root / "eda_toolchain_binding_manifest.json"
    payload = build_eda_toolchain_binding_manifest(
        site_id=site_id,
        profile_ref=profile_ref,
        output_path=binding_path,
        toolchain_profile_id=toolchain_profile_id,
    )
    result = {
        "command": "site bind-eda",
        "site_id": site_id,
        "profile_ref": profile_ref,
        "toolchain_profile_id": toolchain_profile_id,
        "binding_manifest_ref": str(binding_path),
        "tool_bindings": len(payload.get("tool_bindings", [])),
    }
    _write_json(output_root / "site_bind_eda_result.json", result)
    return result


def _run_site_preflight_eda(args: argparse.Namespace) -> dict[str, Any]:
    config = _load_config(Path(args.config)) if args.config else {}
    site_id = args.site_id or config.get("site_id", "site-default")
    profile_ref = args.profile_ref or config.get("profile_ref", "customer_managed_vpc")
    output_root = Path(args.output_root).resolve()
    output_root.mkdir(parents=True, exist_ok=True)

    if args.binding_manifest:
        binding_path = Path(args.binding_manifest).resolve()
    else:
        binding_path = output_root / "eda_toolchain_binding_manifest.json"
    if not binding_path.exists():
        raise FileNotFoundError(f"binding_manifest_not_found: {binding_path}")

    report_path = output_root / "eda_toolchain_preflight_report.json"
    report = build_eda_toolchain_preflight_report(
        site_id=site_id,
        profile_ref=profile_ref,
        binding_manifest_path=binding_path,
        output_path=report_path,
    )
    result = {
        "command": "site preflight-eda",
        "site_id": site_id,
        "profile_ref": profile_ref,
        "binding_manifest_ref": str(binding_path),
        "preflight_report_ref": str(report_path),
        "verdict": report.get("verdict", "BLOCKED"),
    }
    _write_json(output_root / "site_preflight_eda_result.json", result)
    return result


def _resolve_binding_record(args: argparse.Namespace, output_root: Path) -> Path:
    if getattr(args, "binding_record", None):
        return Path(args.binding_record).resolve()
    return output_root / "backend_secret_binding_record.json"


def _run_site_secrets_init(args: argparse.Namespace) -> dict[str, Any]:
    config = _load_config(Path(args.config)) if args.config else {}
    site_id = args.site_id or config.get("site_id", "site-default")
    profile_ref = args.profile_ref or config.get("profile_ref", "customer_managed_vpc")
    backend_provider = args.backend or config.get("backend_provider", "openai")
    output_root = Path(args.output_root).resolve()
    output_root.mkdir(parents=True, exist_ok=True)

    binding_path = output_root / "backend_secret_binding_record.json"
    binding = build_backend_secret_binding_record(
        site_id=site_id,
        profile_ref=profile_ref,
        backend_provider=backend_provider,
        output_path=binding_path,
    )
    result = {
        "command": "site secrets init",
        "site_id": site_id,
        "profile_ref": profile_ref,
        "backend_provider": backend_provider,
        "binding_record_ref": str(binding_path),
        "required_secret_names": [row.get("secret_name", "") for row in binding.get("secret_refs", []) if row.get("required")],
    }
    _write_json(output_root / "site_secrets_init_result.json", result)
    return result


def _run_site_secrets_verify(args: argparse.Namespace) -> dict[str, Any]:
    output_root = Path(args.output_root).resolve()
    output_root.mkdir(parents=True, exist_ok=True)
    binding_path = _resolve_binding_record(args, output_root)
    if not binding_path.exists():
        raise FileNotFoundError(f"binding_record_not_found: {binding_path}")
    scan_root = Path(args.scan_root).resolve() if args.scan_root else output_root

    redaction_path = output_root / "secret_redaction_verification_report.json"
    report = build_secret_redaction_verification_report(
        binding_record_path=binding_path,
        scan_root=scan_root,
        output_path=redaction_path,
    )
    result = {
        "command": "site secrets verify",
        "binding_record_ref": str(binding_path),
        "scan_root": str(scan_root),
        "redaction_report_ref": str(redaction_path),
        "verdict": report.get("verdict", "BLOCKED"),
    }
    _write_json(output_root / "site_secrets_verify_result.json", result)
    return result


def _run_site_backend_preflight(args: argparse.Namespace) -> dict[str, Any]:
    config = _load_config(Path(args.config)) if args.config else {}
    site_id = args.site_id or config.get("site_id", "site-default")
    profile_ref = args.profile_ref or config.get("profile_ref", "customer_managed_vpc")
    output_root = Path(args.output_root).resolve()
    output_root.mkdir(parents=True, exist_ok=True)
    binding_path = _resolve_binding_record(args, output_root)
    if not binding_path.exists():
        raise FileNotFoundError(f"binding_record_not_found: {binding_path}")

    preflight_path = output_root / "backend_secret_preflight_report.json"
    report = build_backend_secret_preflight_report(
        site_id=site_id,
        profile_ref=profile_ref,
        binding_record_path=binding_path,
        output_path=preflight_path,
        openai_mode=args.openai_mode,
    )
    result = {
        "command": "site backend preflight",
        "site_id": site_id,
        "profile_ref": profile_ref,
        "binding_record_ref": str(binding_path),
        "preflight_report_ref": str(preflight_path),
        "verdict": report.get("verdict", "BLOCKED"),
    }
    _write_json(output_root / "site_backend_preflight_result.json", result)
    return result


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="icaf site CLI (P3/P4 baseline)")
    subparsers = parser.add_subparsers(dest="group", required=True)

    site = subparsers.add_parser("site")
    site_sub = site.add_subparsers(dest="action", required=True)

    bind_eda = site_sub.add_parser("bind-eda")
    bind_eda.add_argument("--config", required=False)
    bind_eda.add_argument("--site-id", required=False)
    bind_eda.add_argument("--profile-ref", required=False)
    bind_eda.add_argument("--toolchain-profile-id", required=False)
    bind_eda.add_argument("--output-root", required=True)
    bind_eda.set_defaults(handler=_run_site_bind_eda)

    preflight_eda = site_sub.add_parser("preflight-eda")
    preflight_eda.add_argument("--config", required=False)
    preflight_eda.add_argument("--site-id", required=False)
    preflight_eda.add_argument("--profile-ref", required=False)
    preflight_eda.add_argument("--binding-manifest", required=False)
    preflight_eda.add_argument("--output-root", required=True)
    preflight_eda.set_defaults(handler=_run_site_preflight_eda)

    secrets = site_sub.add_parser("secrets")
    secrets_sub = secrets.add_subparsers(dest="secrets_action", required=True)

    secrets_init = secrets_sub.add_parser("init")
    secrets_init.add_argument("--config", required=False)
    secrets_init.add_argument("--site-id", required=False)
    secrets_init.add_argument("--profile-ref", required=False)
    secrets_init.add_argument("--backend", required=False, default="openai")
    secrets_init.add_argument("--output-root", required=True)
    secrets_init.set_defaults(handler=_run_site_secrets_init)

    secrets_verify = secrets_sub.add_parser("verify")
    secrets_verify.add_argument("--binding-record", required=False)
    secrets_verify.add_argument("--scan-root", required=False)
    secrets_verify.add_argument("--output-root", required=True)
    secrets_verify.set_defaults(handler=_run_site_secrets_verify)

    backend = site_sub.add_parser("backend")
    backend_sub = backend.add_subparsers(dest="backend_action", required=True)

    backend_preflight = backend_sub.add_parser("preflight")
    backend_preflight.add_argument("--config", required=False)
    backend_preflight.add_argument("--site-id", required=False)
    backend_preflight.add_argument("--profile-ref", required=False)
    backend_preflight.add_argument("--binding-record", required=False)
    backend_preflight.add_argument("--openai-mode", required=False, default="live")
    backend_preflight.add_argument("--output-root", required=True)
    backend_preflight.set_defaults(handler=_run_site_backend_preflight)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    result = args.handler(args)
    print(json.dumps(result, ensure_ascii=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
