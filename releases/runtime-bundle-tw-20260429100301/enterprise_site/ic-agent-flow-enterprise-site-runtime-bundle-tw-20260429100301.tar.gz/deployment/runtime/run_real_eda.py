import os
import shutil
import json
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace

import sys


def _find_repo_root(start_file: str) -> Path:
    for candidate in Path(start_file).resolve().parents:
        if (candidate / "README.md").exists() and (candidate / "deployment").exists():
            return candidate
    return Path(start_file).resolve().parents[2]


BASE_DIR = _find_repo_root(__file__)
sys.path.append(str(BASE_DIR / "workspace" / "shared-runtime" / "lib"))
sys.path.append(str(BASE_DIR / "deployment" / "runtime" / "lib"))

from ic_agent_flow.governance.yosys_mcp_capability import YosysMcpCapabilityBoundary, YosysMcpCapabilityRequest
from ic_agent_flow.governance.openroad_mcp_capability import OpenroadMcpCapabilityBoundary, OpenroadMcpCapabilityRequest
from ic_agent_flow.governance.netgen_mcp_capability import NetgenMcpCapabilityBoundary, NetgenMcpCapabilityRequest
from ic_agent_flow.governance.klayout_drc_capability import KlayoutMcpCapabilityBoundary, KlayoutMcpCapabilityRequest
from ic_agent_flow.registry.scenario_registry import Disposition

def get_tw_time():
    return datetime.now(timezone.utc)


def _templates_root() -> Path:
    return Path(os.environ.get("IC_AGENT_FLOW_TEMPLATES_ROOT", "templates"))

def _resolve_primary_rtl_source(rtl_src, top_module):
    rtl_path = Path(rtl_src)
    if rtl_path.is_file():
        return str(rtl_path)

    if not rtl_path.is_dir():
        return None

    candidates = sorted(list(rtl_path.glob("*.v")) + list(rtl_path.glob("*.sv")))
    filtered = [
        path for path in candidates
        if "testbench" not in path.name.lower()
        and not path.name.lower().endswith("_tb.v")
        and not path.name.lower().endswith("_tb.sv")
    ]
    module_pattern = re.compile(rf"\bmodule\s+{re.escape(top_module)}\b")
    for path in filtered:
        text = path.read_text(encoding="utf-8", errors="ignore")
        if module_pattern.search(text):
            return str(path)

    if filtered:
        return str(filtered[0])
    return None


def _resolve_compare_source(run_dir, rtl_src, top_module):
    snapshot_rtl_dir = Path(run_dir) / "inputs" / "rtl"
    if snapshot_rtl_dir.exists():
        snapshot_source = _resolve_primary_rtl_source(str(snapshot_rtl_dir), top_module)
        if snapshot_source:
            return snapshot_source
    return _resolve_primary_rtl_source(rtl_src, top_module)


def _resolve_rtl_sources_for_yosys(rtl_src, top_module):
    rtl_path = Path(rtl_src)
    primary = _resolve_primary_rtl_source(rtl_src, top_module)
    if primary is None:
        return []

    primary_path = Path(primary)
    primary_text = primary_path.read_text(encoding="utf-8", errors="ignore")
    if "`include" in primary_text or rtl_path.is_file():
        return [primary_path.as_posix()]

    return [
        path.as_posix()
        for path in sorted(list(rtl_path.glob("*.v")) + list(rtl_path.glob("*.sv")))
        if "testbench" not in path.name.lower()
        and not path.name.lower().endswith("_tb.v")
        and not path.name.lower().endswith("_tb.sv")
    ]


def _resolve_lec_rtl_source(run_dir, rtl_src):
    design_rtl_dir = os.path.join(run_dir, "inputs", "design", "rtl")
    if os.path.isdir(design_rtl_dir):
        return design_rtl_dir
    legacy_rtl_dir = os.path.join(run_dir, "inputs", "rtl")
    if os.path.isdir(legacy_rtl_dir):
        return legacy_rtl_dir
    return rtl_src


def _sha256_file(path):
    h = __import__("hashlib").sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def _run_yosys_lec(run_dir, chip_id, task_id, rtl_src, top_module, synth_netlist, yosys_bin, liberty_path):
    out_dir = Path(run_dir) / "v4_yosys_lec"
    out_dir.mkdir(parents=True, exist_ok=True)

    rtl_sources = _resolve_rtl_sources_for_yosys(rtl_src, top_module)
    script_path = out_dir / "yosys_lec.ys"
    raw_log_path = out_dir / "yosys_lec.raw.log"
    normalized_path = out_dir / "normalized.lec.meta.json"
    lineage_path = out_dir / "lineage.json"
    evidence_path = out_dir / "evidence_bundle.json"
    ts = get_tw_time().isoformat()

    if not rtl_sources or not synth_netlist or not Path(synth_netlist).exists():
        normalized = {
            "tool": "yosys",
            "status": "NOT CHECKED",
            "equiv_status": "input_missing",
            "proof_engine": "yosys_equiv_simple",
            "notes": "Yosys LEC skipped because RTL source or synthesized netlist was not available.",
            "generated_at": ts,
        }
        normalized_path.write_text(json.dumps(normalized, indent=2), encoding="utf-8")
        return normalized

    read_rtl_lines = "\n".join(f"read_verilog -sv {src}" for src in rtl_sources)
    liberty_line = f"read_liberty -lib {liberty_path}\n" if liberty_path and Path(liberty_path).exists() else ""
    script = f"""# Auto-generated bounded Yosys equivalence smoke.
{liberty_line}{read_rtl_lines}
prep -top {top_module}
flatten
async2sync
dffunmap
design -stash gold
{liberty_line}read_verilog {synth_netlist}
prep -top {top_module}
flatten
async2sync
dffunmap
design -stash gate
design -copy-from gold -as gold {top_module}
design -copy-from gate -as gate {top_module}
equiv_make gold gate equiv
hierarchy -top equiv
equiv_simple
equiv_status
"""
    script_path.write_text(script, encoding="utf-8")

    proc = subprocess.run(
        [yosys_bin, "-q", "-s", str(script_path)],
        cwd=os.getcwd(),
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=60,
    )
    raw_log_path.write_text(proc.stdout or "", encoding="utf-8")

    passed = proc.returncode == 0
    normalized = {
        "tool": "yosys",
        "status": "PASS" if passed else "PARTIAL",
        "equiv_status": "equivalent" if passed else "not_proved",
        "proof_engine": "yosys_equiv_simple",
        "rtl_source_refs": rtl_sources,
        "synth_netlist_ref": synth_netlist,
        "returncode": proc.returncode,
        "notes": (
            "Yosys bounded equivalence completed for RTL vs synthesized netlist."
            if passed
            else "Yosys equivalence was attempted but did not prove all compare points; inspect raw log."
        ),
        "generated_at": ts,
    }
    normalized_path.write_text(json.dumps(normalized, indent=2), encoding="utf-8")

    lineage = {
        "run_id": f"yosys-lec-{chip_id}-{task_id}",
        "chip_id": chip_id,
        "task_id": task_id,
        "input_refs": rtl_sources + [synth_netlist],
        "output_refs": [str(script_path), str(raw_log_path), str(normalized_path)],
        "generated_at": ts,
    }
    lineage_path.write_text(json.dumps(lineage, indent=2), encoding="utf-8")
    evidence = {
        "lineage_ref": "v4_yosys_lec/lineage.json",
        "raw_refs": ["v4_yosys_lec/yosys_lec.ys", "v4_yosys_lec/yosys_lec.raw.log"],
        "normalized_refs": ["v4_yosys_lec/normalized.lec.meta.json"],
        "digests": {
            "script_sha256": _sha256_file(script_path),
            "raw_log_sha256": _sha256_file(raw_log_path),
            "normalized_sha256": _sha256_file(normalized_path),
        },
        "generated_at": ts,
    }
    evidence_path.write_text(json.dumps(evidence, indent=2), encoding="utf-8")
    return normalized


def _resolve_sdc_path(rtl_src, top_module):
    rtl_path = Path(rtl_src)
    candidate_dirs = []

    if rtl_path.is_dir():
        candidate_dirs.append(rtl_path / "constraints")
        candidate_dirs.append(rtl_path.parent / "constraints")
    elif rtl_path.is_file():
        candidate_dirs.append(rtl_path.parent / "constraints")

    preferred_names = [
        f"{top_module}.sdc",
        "base.sdc",
        "constraint.sdc",
    ]

    for candidate_dir in candidate_dirs:
        if not candidate_dir.exists():
            continue
        for name in preferred_names:
            candidate = candidate_dir / name
            if candidate.exists():
                return candidate.as_posix()
        first_sdc = next(iter(sorted(candidate_dir.glob("*.sdc"))), None)
        if first_sdc is not None:
            return first_sdc.as_posix()

    baseline_sdc = _templates_root() / "baseline-digital-soc" / "constraints" / "base.sdc"
    if baseline_sdc.exists():
        return baseline_sdc.as_posix()
    return None


def _resolved_path(toolchain_resolution, section, key):
    if not toolchain_resolution:
        raise RuntimeError("environment_invalid:missing_toolchain_resolution")
    resolved = toolchain_resolution.get(section, {}).get(key, {})
    path = resolved.get("path")
    if not path:
        raise RuntimeError(f"environment_invalid:unresolved_{section}.{key}")
    if resolved.get("exists") is False:
        raise RuntimeError(f"environment_invalid:missing_resolved_{section}.{key}")
    return path


def run_real_eda(run_dir, chip_id, task_id, rtl_src, top_module, workspace_id=None, toolchain_resolution=None):
    print("  [pipeline] Using REAL EDA tools to synthesis and extract...")
    assembly_log = []
    
    workspace_id = workspace_id or f"ws-{chip_id}"
    decision_context_ref = f"decision://{task_id}/formal-release"
    
    # Paths for EDA
    yosys_bin = _resolved_path(toolchain_resolution, "binaries", "yosys")
    openroad_bin = _resolved_path(toolchain_resolution, "binaries", "openroad")
    netgen_bin = _resolved_path(toolchain_resolution, "binaries", "netgen")
    klayout_python_bin = _resolved_path(toolchain_resolution, "binaries", "klayout_python")
    liberty_path = _resolved_path(toolchain_resolution, "collateral", "liberty_path")
    tech_lef_path = _resolved_path(toolchain_resolution, "collateral", "tech_lef_path")
    stdcell_lef_path = _resolved_path(toolchain_resolution, "collateral", "stdcell_lef_path")
    tracks_path = _resolved_path(toolchain_resolution, "collateral", "tracks_path")
    
    # 1. Yosys
    yosys_boundary = YosysMcpCapabilityBoundary()
    yosys_req = YosysMcpCapabilityRequest(
        workspace_id=workspace_id,
        chip_id=chip_id,
        task_id=task_id,
        decision_context_ref=decision_context_ref,
        contract_name="yosys_synth_contract",
        contract_version="v0.1",
        rtl_path=rtl_src,
        top_module=top_module,
        output_root=os.path.join(run_dir, "h1_yosys"),
        yosys_bin=yosys_bin,
        liberty_path=liberty_path,
    )
    y_resp = yosys_boundary.execute(yosys_req)
    if y_resp.disposition == Disposition.PASS:
        status_y = "PASS"
        y_netlist = y_resp.artifact_paths["netlist_v"]
        y_flat_netlist = y_resp.artifact_paths.get("flat_netlist_v", y_netlist)
    else:
        status_y = "FAIL"
        y_netlist = None
        y_flat_netlist = None
        print(f"YOSYS FAILED: {y_resp.reason}")
    
    assembly_log.append({
        "stage": "h1_yosys",
        "output_dir": os.path.join(run_dir, "h1_yosys"),
        "status": status_y,
        "detail": y_resp.reason
    })

    if status_y == "PASS" and y_flat_netlist:
        try:
            lec_meta = _run_yosys_lec(
                run_dir,
                chip_id,
                task_id,
                _resolve_lec_rtl_source(run_dir, rtl_src),
                top_module,
                y_flat_netlist,
                yosys_bin,
                liberty_path,
            )
        except Exception as exc:
            lec_meta = {
                "status": "PARTIAL",
                "equiv_status": "execution_error",
                "notes": f"Yosys LEC execution raised {type(exc).__name__}: {exc}",
            }
        assembly_log.append({
            "stage": "v4_yosys_lec",
            "output_dir": os.path.join(run_dir, "v4_yosys_lec"),
            "status": lec_meta.get("status", "PARTIAL"),
            "detail": lec_meta.get("notes", "Yosys LEC attempted"),
        })
    
    # 2. OpenROAD
    o_resp = None
    if status_y == "PASS" and y_netlist:
        openroad_boundary = OpenroadMcpCapabilityBoundary()
        sdc_path = _resolve_sdc_path(rtl_src, top_module)

        o_req = OpenroadMcpCapabilityRequest(
            workspace_id=workspace_id,
            chip_id=chip_id,
            task_id=task_id,
            decision_context_ref=decision_context_ref,
            contract_name="openroad_drc_contract",
            contract_version="v0.1",
            top_module=top_module,
            netlist_v_path=y_netlist,
            sdc_path=sdc_path,
            output_root=os.path.join(run_dir, "h2_openroad"),
            openroad_bin=openroad_bin,
            tech_lef_path=tech_lef_path,
            stdcell_lef_path=stdcell_lef_path,
            lib_path=liberty_path,
            tracks_path=tracks_path,
        )
        o_resp = openroad_boundary.execute(o_req)
        status_o = "PASS" if o_resp.disposition == Disposition.PASS else "FAIL"
        if status_o == "FAIL": print(f"OPENROAD FAILED: {o_resp.reason}")
    else:
        status_o = "SKIPPED"
        
    assembly_log.append({
        "stage": "h2_openroad",
        "output_dir": os.path.join(run_dir, "h2_openroad"),
        "status": status_o,
        "detail": o_resp.reason if o_resp else "skipped"
    })
    
    # 3. Klayout (H4)
    status_k = "SKIPPED"
    reason_k = "KLayout DRC skipped: no GDS/DEF artifact produced by H2"
    o_gds = o_resp.artifact_paths.get("gds") if o_resp and getattr(o_resp, "artifact_paths", None) else None
    o_def = o_resp.artifact_paths.get("def") if o_resp and getattr(o_resp, "artifact_paths", None) else None
    if o_resp and o_resp.disposition == Disposition.PASS:
        if (o_gds and Path(o_gds).exists()) or (o_def and Path(o_def).exists()):
            klayout_boundary = KlayoutMcpCapabilityBoundary()
            k_req = KlayoutMcpCapabilityRequest(
                workspace_id=workspace_id,
                chip_id=chip_id,
                task_id=task_id,
                decision_context_ref=decision_context_ref,
                contract_name="klayout_drc_contract",
                contract_version="v0.1",
                def_path=o_def if o_def and Path(o_def).exists() else None,
                gds_path=o_gds if o_gds and Path(o_gds).exists() else None,
                output_root=os.path.join(run_dir, "h4_klayout"),
                python_bin=klayout_python_bin,
            )
            k_resp = klayout_boundary.execute(k_req)
            status_k = "PASS" if k_resp.disposition == Disposition.PASS else "FAIL"
            reason_k = k_resp.reason
        
    assembly_log.append({
        "stage": "h4_klayout",
        "output_dir": os.path.join(run_dir, "h4_klayout"),
        "status": status_k,
        "detail": reason_k
    })
        
    # 4. Netgen (H3)
    n_resp = None
    compare_source = _resolve_compare_source(run_dir, rtl_src, top_module)
    if status_y == "PASS" and y_flat_netlist and compare_source:
        netgen_boundary = NetgenMcpCapabilityBoundary()
        n_req = NetgenMcpCapabilityRequest(
            workspace_id=workspace_id,
            chip_id=chip_id,
            task_id=task_id,
            decision_context_ref=decision_context_ref,
            contract_name="netgen_lvs_contract",
            contract_version="v0.1",
            source_a_path=y_flat_netlist,
            source_a_top=top_module,
            source_b_path=compare_source,
            source_b_top=top_module,
            output_root=os.path.join(run_dir, "h3_netgen"),
            netgen_bin=netgen_bin
        )
        n_resp = netgen_boundary.execute(n_req)
        status_n = "PASS" if n_resp.disposition == Disposition.PASS else "FAIL"
        if status_n == "FAIL": print(f"NETGEN FAILED: {n_resp.reason}")
    else:
        status_n = "SKIPPED"
        if not compare_source:
            n_resp = SimpleNamespace(reason="skipped: no chip-correct RTL compare source resolved")
        
    assembly_log.append({
        "stage": "h3_netgen",
        "output_dir": os.path.join(run_dir, "h3_netgen"),
        "status": status_n,
        "detail": n_resp.reason if n_resp else "skipped"
    })
    
    return assembly_log
