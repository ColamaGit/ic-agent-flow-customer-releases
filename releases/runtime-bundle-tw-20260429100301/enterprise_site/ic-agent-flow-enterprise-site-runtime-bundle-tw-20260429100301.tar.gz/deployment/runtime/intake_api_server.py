#!/usr/bin/env python3
from __future__ import annotations

import importlib.util
import os
from pathlib import Path


def _find_repo_root(start_file: str) -> str:
    for candidate in Path(start_file).resolve().parents:
        if (candidate / "README.md").exists() and (candidate / "workspace").exists():
            return str(candidate)
    return os.path.abspath(os.path.join(os.path.dirname(start_file), "..", ".."))


def _load_shared_api(repo_root: str):
    src = Path(repo_root) / "workspace" / "shared-runtime" / "scripts" / "intake_api_server.py"
    spec = importlib.util.spec_from_file_location("shared_intake_api_server", src)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def process_intake_payload(payload):
    repo_root = _find_repo_root(__file__)
    module = _load_shared_api(repo_root)
    return module.process_intake_payload(payload)


def main() -> None:
    repo_root = _find_repo_root(__file__)
    module = _load_shared_api(repo_root)
    module.main()


if __name__ == "__main__":
    main()
