#!/usr/bin/env python3
from __future__ import annotations

import importlib.util
import os
import sys
from pathlib import Path


def _find_repo_root(start_file: str) -> str:
    for candidate in Path(start_file).resolve().parents:
        if (candidate / "README.md").exists() and (candidate / "workspace").exists():
            return str(candidate)
    return os.path.abspath(os.path.join(os.path.dirname(start_file), "..", ".."))


def _load_shared_runner(repo_root: str):
    src = Path(repo_root) / "workspace" / "shared-runtime" / "scripts" / "run_requirement_intake.py"
    spec = importlib.util.spec_from_file_location("shared_run_requirement_intake", src)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def main() -> None:
    repo_root = _find_repo_root(__file__)
    module = _load_shared_runner(repo_root)
    module.main()


if __name__ == "__main__":
    main()
