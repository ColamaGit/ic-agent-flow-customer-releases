from datetime import datetime, timezone
from uuid import uuid4
from ic_agent_flow.domain.objects import RTLSnapshot, AuthorityClass, Producer, ProducerType
from ic_agent_flow.context.assembler import ContextAssembler
from ic_agent_flow.domain.verification import AdjudicationRecord, AdjudicationAuthority, Decision, Verdict
from ic_agent_flow.domain.verification.evaluator import ContractEvaluator
from ic_agent_flow.domain.governance import (
    ExecutionRunRecord, ReadinessNote, CloseoutBundle, HumanReviewPackage
)
from ic_agent_flow.domain.contracts import Contract, SelectedContracts
from ic_agent_flow.domain.execution import ToolCommand, ExecutionBounds, ToolInvocation
from ic_agent_flow.adapters.tools.mock_simulator import MockSimulator
import os

class BoundedSimulationScenario:
    """E2: Runs asynchronous simulation bounded by ExecutionBounds."""
    
    def __init__(self):
        self.assembler = ContextAssembler()
        self.evaluator = ContractEvaluator()
        self.simulator = MockSimulator("vsim", "2023.1")
    
    def run(self):
        rtl_snap = RTLSnapshot(id=uuid4(), version="v1.0.0", status="stable", authority_class=AuthorityClass.CANONICAL, producer=Producer(id="eng", type=ProducerType.HUMAN), created_at=datetime.now(timezone.utc), files=[{"path": "tb.v", "hash": "tb_abc"}])
        bounds = ExecutionBounds(allowed_tools=["vsim"], forbidden_args=["-random_seed_0"], max_memory_gb=32, timeout_seconds=7200)
        cmd = ToolCommand(tool_name="vsim", version="2023.1", args=["-assert", "-cov"], working_dir="/sim")
        
        manifest = self.assembler.assemble(task_type="bounded-sim", subjects=[rtl_snap], assembler_id="orch")
        
        # 1. Invocation Tracker
        invoc = ToolInvocation(id=uuid4(), version="v1.0.0", authority_class=AuthorityClass.DERIVED, producer=Producer(id="agent", type=ProducerType.AGENT), command=cmd, bounds_applied=bounds, start_time=datetime.now(timezone.utc), created_at=datetime.now(timezone.utc))
        
        # 2. Execution
        sim_res = self.simulator.execute(cmd, bounds)
        invoc.end_time = datetime.now(timezone.utc)
        invoc.result_ref = f"simulation_result:{sim_res.id}"
        
        # 3. Contract Eval
        contracts = SelectedContracts(version="1", contracts=[Contract(id="S-01", name="Coverage", schema_ref="sim.json", description="Cov >= 95 and pass=all")])
        v1 = self.evaluator.evaluate(contracts.contracts[0], sim_res)
        
        # 4. Auth & Closeout
        adjudication = AdjudicationRecord(
            adjudication_id=uuid4(), subject_refs=[f"rtl_snapshot:{rtl_snap.id}"], gate_verdict_refs=[f"gate_verdict:{v1.id}"],
            decision=Decision.PROCEED if v1.verdict == Verdict.PASS else Decision.HOLD,
            decision_rationale="Bounds enforced and sim evaluated.", authority=AdjudicationAuthority(human_id="auto", role="Validator"), approved_at=datetime.now(timezone.utc)
        )
        run_record = ExecutionRunRecord(run_id=uuid4(), timestamp=datetime.now(timezone.utc), producer=Producer(id="ag", type=ProducerType.AGENT), environment="env", task_type="bounded-sim")
        review_package = HumanReviewPackage(
            id=uuid4(), subject_objects=[f"rtl_snapshot:{rtl_snap.id}"], authoritative_evidence_refs=[f"simulation_result:{sim_res.id}"],
            gate_verdict_summary=f"S-01: {v1.verdict}", open_risks=[], downstream_effect="Signoff coverage collected.", created_at=datetime.now(timezone.utc)
        )
        r_note = ReadinessNote(id=uuid4(), current_readiness="RR", target_readiness="BR", claims=["Bounded sim executed"], limitations=[], evidence_delta="", created_at=datetime.now(timezone.utc))
        
        bundle = CloseoutBundle(
            id=uuid4(), task_type="bounded-sim", input_objects=[rtl_snap, invoc], context_manifest=manifest, selected_contracts=contracts,
            execution_run_record=run_record, normalized_artifacts=[sim_res], gate_verdicts=[v1], adjudication_record=adjudication,
            human_review_package=review_package, final_readiness_note=r_note, created_at=datetime.now(timezone.utc)
        )
        
        os.makedirs("artifacts/closeouts", exist_ok=True)
        path = f"artifacts/closeouts/bundle_{bundle.id}.json"
        with open(path, "w") as f: f.write(bundle.model_dump_json(indent=2))
        return path

if __name__ == "__main__":
    s = BoundedSimulationScenario()
    res = s.run()
    print(f"E2 Run Complete: {res}")
