from abc import ABC, abstractmethod
from typing import List, Optional
from ic_agent_flow.infrastructure.job_model import JobRecord, JobStatus

class AbstractScheduler(ABC):
    """
    Base interface for all physical job execution adapters (Local, Slurm, LSF).
    """
    
    @abstractmethod
    async def submit(self, command: List[str], run_id: str, working_dir: str) -> JobRecord:
        """Submit a new async job."""
        pass

    @abstractmethod
    async def poll(self, job_id: str) -> JobRecord:
        """Check the current status and telemetry of a job."""
        pass

    @abstractmethod
    async def cancel(self, job_id: str) -> bool:
        """Terminate a running or queued job."""
        pass

    @abstractmethod
    async def list_jobs(self, run_id: Optional[str] = None) -> List[JobRecord]:
        """List jobs managed by this scheduler, optionally filtered by run_id."""
        pass
