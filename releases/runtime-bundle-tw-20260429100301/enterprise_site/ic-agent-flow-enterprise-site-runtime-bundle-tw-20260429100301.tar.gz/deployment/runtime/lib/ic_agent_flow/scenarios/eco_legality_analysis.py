from datetime import datetime, timezone
from uuid import uuid4
import os
from ic_agent_flow.domain.objects.eco import EcoRequest, RtlDiff, SpareCellInventory, ImpactScope
from ic_agent_flow.domain.objects import AuthorityClass, Producer, ProducerType, RTLSnapshot
from ic_agent_flow.context.assembler import ContextAssembler
from ic_agent_flow.domain.verification import AdjudicationRecord, AdjudicationAuthority, Decision, Verdict
from ic_agent_flow.domain.verification.evaluator import ContractEvaluator
from ic_agent_flow.domain.governance import (
    ExecutionRunRecord, ReadinessNote, CloseoutBundle, HumanReviewPackage
)
from ic_agent_flow.domain.governance.checkpoint import HumanCheckpointRunner, CheckpointPolicy, DecisionEnum
from ic_agent_flow.domain.contracts import Contract, SelectedContracts
from ic_agent_flow.adapters.tools.mock_eco_analyzer import MockEcoAnalyzer

class EcoLegalityScenario:
    """F2: The highly restricted ECO Bounding Loop."""
    
    def __init__(self):
        self.assembler = ContextAssembler()
        self.evaluator = ContractEvaluator()
        self.analyzer = MockEcoAnalyzer()
    
    def run(self, force_illegal=False, timeout_override: int = 10):
        # 0. Base Netlist Context
        netlist_snap = RTLSnapshot(id=uuid4(), version="v1.0.0", status="implemented", authority_class=AuthorityClass.CANONICAL, producer=Producer(id="icc2", type=ProducerType.TOOL), created_at=datetime.now(timezone.utc), files=[])
        
        # 1. Inputs (F1 Domain)
        diff_hash = "long_diff_hash_to_force_illegal" if force_illegal else "short_hash"
        diff = RtlDiff(id=uuid4(), version="v1.0.0", authority_class=AuthorityClass.DERIVED, producer=Producer(id="eng", type=ProducerType.HUMAN), golden_snapshot_ref=str(uuid4()), draft_snapshot_ref=str(uuid4()), diff_hash=diff_hash, changed_modules=["AES_CORE"], created_at=datetime.now(timezone.utc))
        inventory = SpareCellInventory(id=uuid4(), version="v1.0.0", authority_class=AuthorityClass.CANONICAL, producer=Producer(id="icc2", type=ProducerType.TOOL), partition_name="TOP", gate_counts={"NAND2": 5, "INV": 2}, created_at=datetime.now(timezone.utc))
        req = EcoRequest(id=uuid4(), version="v1.0.0", authority_class=AuthorityClass.EPHEMERAL, producer=Producer(id="eng", type=ProducerType.HUMAN), description="Fix logic bug in AES", target_stage="Post-Route", created_at=datetime.now(timezone.utc))
        
        manifest = self.assembler.assemble(task_type="eco-legality", subjects=[req, diff, inventory, netlist_snap], assembler_id="orchestrator")
        
        # 2. Execution (Extracting impact scope)
        impact = self.analyzer.analyze(diff)
        
        # 3. Apply F1 Policy Contracts
        contracts = SelectedContracts(version="1", contracts=[
            Contract(id="ECO-01", name="Locality", schema_ref="eco", description="Max 10 nets"),
            Contract(id="ECO-02", name="Legality", schema_ref="eco", description="Cannot exceed spare cells"),
            Contract(id="ECO-03", name="Equivalence", schema_ref="eco", description="Must trigger formal loop if approved")
        ])
        
        v1 = self.evaluator.evaluate(contracts.contracts[0], impact)
        v2 = self.evaluator.evaluate(contracts.contracts[1], (impact, inventory))
        v3 = self.evaluator.evaluate(contracts.contracts[2], impact)
        verdicts = [v1, v2, v3]
        all_passed = all(v.verdict == Verdict.PASS for v in verdicts)
        
        # 4. Human Review Package Generation (RESTRICTIVE)
        review_package = HumanReviewPackage(
            id=uuid4(), subject_objects=[f"eco_request:{req.id}", f"rtl_diff:{diff.id}"], authoritative_evidence_refs=[f"impact_scope:{impact.id}", f"spare_inventory:{inventory.id}"],
            gate_verdict_summary=f"ECO1(Locality):{v1.verdict}, ECO2(Legality):{v2.verdict}, ECO3(Eq):{v3.verdict}",
            open_risks=[v.rationale for v in verdicts if v.verdict == Verdict.FAILED] or ["ECO inherently risks timing/routing convergence."],
            allowed_decisions=["HOLD", "REJECT", "REQUEST_MORE_EVIDENCE", "APPROVE"], # Approve is last
            downstream_effect="MUST trigger E3: Formal Equivalence BEFORE generating patch if Approved.",
            created_at=datetime.now(timezone.utc)
        )
        
        # 5. Checkpoint Activation (Defaulting to REQUEST_MORE_EVIDENCE for ECOs instead of TIMEOUT_HOLD to demand formal proof)
        policy = CheckpointPolicy(timeout_seconds=timeout_override, default_timeout_decision=DecisionEnum.REQUEST_MORE_EVIDENCE)
        human_decision = HumanCheckpointRunner.execute_checkpoint(review_package, policy)
        
        # 6. Restrictive Adjudication Logic
        # Even if the human says APPROVE, if legality failed, we downgrade them to HOLD. (Fail-Close Law + Law 2)
        if human_decision.decision == DecisionEnum.APPROVE:
            if not all_passed:
                final_decision = Decision.HOLD
                mod_rationale = f"[AGENT OVERRIDE] Human approved, but policies failed. Forcing HOLD. Human rationale: {human_decision.rationale}"
            else:
                final_decision = Decision.PROCEED # The only path to success
                mod_rationale = f"[APPROVED] {human_decision.rationale}"
        else:
            final_decision = Decision.HOLD if human_decision.decision != DecisionEnum.REJECT else Decision.REJECT
            mod_rationale = f"[{human_decision.decision.value}] {human_decision.rationale}"
            
        adjudication = AdjudicationRecord(
            adjudication_id=uuid4(), subject_refs=[f"eco_request:{req.id}"], gate_verdict_refs=[f"gate_verdict:{v.id}" for v in verdicts],
            decision=final_decision, decision_rationale=mod_rationale, authority=AdjudicationAuthority(human_id=human_decision.human_id, role="ECO Owner"), approved_at=human_decision.timestamp
        )

        # 7. Closeout
        run_record = ExecutionRunRecord(run_id=uuid4(), timestamp=datetime.now(timezone.utc), producer=Producer(id="ag", type=ProducerType.AGENT), environment="env", task_type="eco-legality")
        r_note = ReadinessNote(id=uuid4(), current_readiness="CR", target_readiness="TR", claims=["ECO Base Framework Operational"], limitations=["Not writing actual patch"], evidence_delta="", created_at=datetime.now(timezone.utc))
        
        bundle = CloseoutBundle(
            id=uuid4(), task_type="eco-legality", input_objects=[req, diff, inventory, netlist_snap], context_manifest=manifest, selected_contracts=contracts,
            execution_run_record=run_record, normalized_artifacts=[impact], gate_verdicts=verdicts, adjudication_record=adjudication,
            human_review_package=review_package, final_readiness_note=r_note, created_at=datetime.now(timezone.utc)
        )
        
        os.makedirs("artifacts/closeouts", exist_ok=True)
        path = f"artifacts/closeouts/bundle_{bundle.id}.json"
        with open(path, "w") as f: f.write(bundle.model_dump_json(indent=2))
        return {
            "path": path,
            "final_decision": final_decision.value,
            "rationale": mod_rationale,
            "legality_passed": all_passed
        }

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--force-illegal", action="store_true")
    parser.add_argument("--timeout", type=int, default=3)
    args = parser.add_argument("--auto-reject", action="store_true") # Dummy to catch old args maybe
    args = parser.parse_args()

    s = EcoLegalityScenario()
    res = s.run(force_illegal=args.force_illegal, timeout_override=args.timeout)
    print("\n[ECO OUTCOME]")
    print(f"Legality Passed: {res['legality_passed']}")
    print(f"Final Decision: {res['final_decision']}")
    print(f"System Log: {res['rationale']}")
