"""
Collaboration Storage Manager (v0.8, PRD v0.8 Baseline)
======================================================
R4: Implements disk-backed session persistence, checkpointing, and resume logic.
Ensures authority preservation (R3) and stale snapshot detection (R5).
"""
import json
import os
from pathlib import Path
from typing import Optional, Dict, Any, List
from uuid import UUID

from ic_agent_flow.domain.objects.collaboration_objects import (
    CollaborationSession,
    CollaborationSessionState,
    SharedIssueItem,
    CollaborationStepRecord,
    CollaborationJobHandle,
    CollaborationQueueRecord,
    ResourceAllocationRecord,
    CollaborationCheckpointEnvelope
)
from ic_agent_flow.domain.utils.time import get_tw_now


class CollaborationStorageManager:
    """
    Manages the physical storage and retrieval of collaboration sessions.
    Path: chips/<chip_id>/collaboration/<session_id>/
    """

    def __init__(self, workspace_root: str = "."):
        self.workspace_root = Path(workspace_root)

    def _get_session_dir(self, chip_id: str, session_id: UUID) -> Path:
        return self.workspace_root / "chips" / chip_id / "collaboration" / str(session_id)

    def save_session(self, session: CollaborationSession, 
                     issues: List[SharedIssueItem] = None,
                     steps: List[CollaborationStepRecord] = None,
                     job_handles: List[CollaborationJobHandle] = None,
                     queue_records: List[CollaborationQueueRecord] = None,
                     allocations: List[ResourceAllocationRecord] = None,
                     checkpoints: List[CollaborationCheckpointEnvelope] = None):
        """
        R4: Persists ALL session-related runtime objects to disk.
        """
        session_dir = self._get_session_dir(session.chip_id, session.session_id)
        session_dir.mkdir(parents=True, exist_ok=True)

        # 1. Save Session Object
        session_path = session_dir / "session.json"
        with open(session_path, "w") as f:
            f.write(session.model_dump_json(indent=2))

        # 2. Save Issues
        if issues:
            issues_dir = session_dir / "issues"
            issues_dir.mkdir(exist_ok=True)
            for issue in issues:
                with open(issues_dir / f"{issue.issue_id}.json", "w") as f:
                    f.write(issue.model_dump_json(indent=2))

        # 3. Save Steps
        if steps:
            steps_dir = session_dir / "steps"
            steps_dir.mkdir(exist_ok=True)
            for step in steps:
                with open(steps_dir / f"{step.step_id}.json", "w") as f:
                    f.write(step.model_dump_json(indent=2))

        # 4. Save Industrial Runtime Objects (v0.8 Expanded)
        if job_handles:
            h_dir = session_dir / "job_handles"
            h_dir.mkdir(exist_ok=True)
            for h in job_handles:
                with open(h_dir / f"{h.handle_id}.json", "w") as f:
                    f.write(h.model_dump_json(indent=2))

        if queue_records:
            q_dir = session_dir / "queue_records"
            q_dir.mkdir(exist_ok=True)
            for q in queue_records:
                with open(q_dir / f"{q.queue_id}.json", "w") as f:
                    f.write(q.model_dump_json(indent=2))

        if allocations:
            a_dir = session_dir / "allocations"
            a_dir.mkdir(exist_ok=True)
            for a in allocations:
                with open(a_dir / f"{a.allocation_id}.json", "w") as f:
                    f.write(a.model_dump_json(indent=2))

        if checkpoints:
            c_dir = session_dir / "checkpoints"
            c_dir.mkdir(exist_ok=True)
            for c in checkpoints:
                with open(c_dir / f"{c.checkpoint_id}.json", "w") as f:
                    f.write(c.model_dump_json(indent=2))

    def load_session(self, chip_id: str, session_id: UUID) -> Optional[CollaborationSession]:
        """
        Loads a session from disk.
        """
        session_dir = self._get_session_dir(chip_id, session_id)
        session_path = session_dir / "session.json"
        
        if not session_path.exists():
            return None
            
        with open(session_path, "r") as f:
            data = json.load(f)
            return CollaborationSession(**data)

    def validate_snapshot(self, session: CollaborationSession, context: Dict[str, Any]) -> List[str]:
        """
        R5: Stale Snapshot Taxonomy.
        Checks if the loaded session is compatible with the current runtime context.
        """
        violations = []
        
        # 1. Scope Stale
        if session.workspace_id != context.get("workspace_id"):
            violations.append("scope_stale: workspace_id mismatch")
        if session.chip_id != context.get("chip_id"):
            violations.append("scope_stale: chip_id mismatch")
            
        # 2. Authority Stale (Basic check)
        if session.status == CollaborationSessionState.CLOSED:
            violations.append("authority_stale: session is already closed")
            
        return violations

    def rebind_session(self, session: CollaborationSession, context: Dict[str, Any]):
        """
        R3: Authority-preserving Rebind logic.
        Ensures that resume does not change chip scope or authority boundary.
        """
        # Strictly preserve IDs
        if session.chip_id != context.get("chip_id"):
            raise ValueError(f"R3 Violation: Cannot rebind session {session.session_id} to a different chip.")
        
        # update metadata or temporary runtime flags if needed
        session.metadata["last_rebound_at"] = get_tw_now().isoformat()
        session.updated_at = get_tw_now()

    def list_active_sessions(self, chip_id: str = None) -> List[Dict[str, Any]]:
        """
        Utility for R8 (Observatiliby): Lists sessions from disk.
        """
        results = []
        chips_dir = self.workspace_root / "chips"
        
        chip_paths = [chips_dir / chip_id] if chip_id else chips_dir.glob("*")
        
        for chip_path in chip_paths:
            collab_dir = chip_path / "collaboration"
            if not collab_dir.exists():
                continue
                
            for session_dir in collab_dir.iterdir():
                if not session_dir.is_dir():
                    continue
                
                session_path = session_dir / "session.json"
                if session_path.exists():
                    with open(session_path, "r") as f:
                        data = json.load(f)
                        results.append({
                            "session_id": data["session_id"],
                            "chip_id": data["chip_id"],
                            "status": data["status"],
                            "updated_at": data["updated_at"]
                        })
        return results
