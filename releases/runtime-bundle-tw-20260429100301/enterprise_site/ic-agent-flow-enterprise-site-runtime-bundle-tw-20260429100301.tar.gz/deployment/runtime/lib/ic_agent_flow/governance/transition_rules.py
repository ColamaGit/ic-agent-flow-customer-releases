from enum import Enum
from pydantic import BaseModel
from typing import List

class OperationalState(Enum):
    ADMISSION_PENDING = "ADMISSION_PENDING"
    READY_TO_RUN = "READY_TO_RUN"
    RUNNING = "RUNNING"
    WAITING_ON_HUMAN = "WAITING_ON_HUMAN"
    HOLD = "HOLD"
    REENTRY_REQUIRED = "REENTRY_REQUIRED"
    ESCALATED = "ESCALATED"
    FAIL_CLOSED = "FAIL_CLOSED"
    CLOSED = "CLOSED"

class TransitionRule(BaseModel):
    from_state: OperationalState
    to_state: OperationalState
    required_checkpoints: List[str]
    allowed_roles: List[str]

TRANSITION_MATRIX = [
    TransitionRule(
        from_state=OperationalState.ADMISSION_PENDING,
        to_state=OperationalState.READY_TO_RUN,
        required_checkpoints=["SiteQualification"],
        allowed_roles=["GovernanceAdmin"]
    ),
    TransitionRule(
        from_state=OperationalState.RUNNING,
        to_state=OperationalState.WAITING_ON_HUMAN,
        required_checkpoints=["HumanReviewCheckpoint"],
        allowed_roles=["Agent"]
    )
]
