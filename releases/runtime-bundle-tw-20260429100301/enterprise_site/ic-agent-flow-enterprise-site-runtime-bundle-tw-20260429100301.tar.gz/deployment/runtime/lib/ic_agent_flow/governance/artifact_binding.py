import json
from typing import Dict, Any

class ArtifactBinder:
    @staticmethod
    def bind_metadata(artifact_data: Dict[str, Any], envelope_id: str, chip_id: str) -> Dict[str, Any]:
        """
        將 Subject Metadata 注入 Artifact 的 Metadata 字典中
        """
        artifact_data["_governance_metadata"] = {
            "subject_envelope_ref": envelope_id,
            "chip_id": chip_id,
            "binding_timestamp": "2026-04-14T00:00:00Z"
        }
        return artifact_data
