"""
Phase 5B Production Bridge Objects (v0.1)
========================================
Defines the bridge between 5A Hardened Guards and Phase 6 Production Discipline.
Focuses on SOP mapping, Exit Gates, and Governance Metrics.
"""
from __future__ import annotations

from enum import Enum
from typing import List, Dict, Optional, Any
from datetime import datetime
from uuid import uuid4, UUID

from pydantic import BaseModel, Field, UUID4
from ic_agent_flow.domain.objects.deployment_objects import (
    DispositionReasonCode,
    DeploymentStatus,
    DeploymentAuditBundle
)
from ic_agent_flow.domain.utils.time import get_tw_now


class SOPAction(str, Enum):
    """Standardized operational actions for production exceptions."""
    PHYSICAL_ROLLBACK = "PHYSICAL_ROLLBACK"
    HUMAN_ADJUDICATION_REQUIRED = "HUMAN_ADJUDICATION_REQUIRED"
    AUTOMATIC_SUSPEND = "AUTOMATIC_SUSPEND"
    RENEWAL_REQUIRED = "RENEWAL_REQUIRED"
    LOG_ONLY = "LOG_ONLY"


class ProductionExceptionSOP(BaseModel):
    """Mapping of a 5A reason code to a production SOP action."""
    reason_code: DispositionReasonCode
    priority: int = 1 # 1: Critical, 3: Informational
    primary_action: SOPAction
    escalation_required: bool = True
    incident_report_trigger: bool = False


class ProductionReadinessCheckpoint(BaseModel):
    """Explicit Exit Gate for moving from 5A/5B to Phase 6."""
    checkpoint_id: UUID4 = Field(default_factory=uuid4)
    name: str
    is_hardened_baseline_verified: bool
    mandatory_evidence_refs: List[str]
    max_acceptable_rollback_rate: float = 0.05
    max_acceptable_deny_rate: float = 0.10
    
    signed_off_at: Optional[datetime] = None
    signed_off_by: Optional[str] = None


class PeriodicGovernanceReport(BaseModel):
    """A report contract for human authority to monitor 5B/6 operations."""
    report_id: UUID4 = Field(default_factory=uuid4)
    period_start: datetime
    period_end: datetime
    
    total_adjudications: int
    count_by_reason: Dict[DispositionReasonCode, int]
    count_by_status: Dict[DeploymentStatus, int]
    
    notable_incidents: List[str] = []
    recommendation: str = "PROCEED"
    
    created_at: datetime = Field(default_factory=get_tw_now)


# --- Phase 6: Signoff Object Family (v0.1) ---

class SignoffEvidenceEntry(BaseModel):
    """File-level integrity entry for evidence manifest."""
    path: str
    sha256: str


class SignoffEvidenceManifest(BaseModel):
    """Manifest of all hash-verified evidence for a chip release."""
    id: UUID4 = Field(default_factory=uuid4)
    chip_id: str
    evidence_refs: List[str] = []
    evidence_items: List[SignoffEvidenceEntry] = [] # Structured per-file hashes
    digest_chain: str # Aggregate sha256 seal
    created_at: datetime = Field(default_factory=get_tw_now)


class SignoffRiskPackage(BaseModel):
    """Quantified risk view combining technical, governance, and evidence states."""
    id: UUID4 = Field(default_factory=uuid4)
    chip_id: str
    readiness_ladder: int = 1
    technical_risk_summary: str
    governance_risk_summary: str
    technical_violation_ids: List[str] = [] # Structured IDs for automated matching
    missing_evidence_ids: List[str] = []   # Structured IDs for evidence gaps
    risk_level: int = 1 # 1 (Low) to 5 (Critical)
    generated_at: datetime = Field(default_factory=get_tw_now)


class ReleaseGateVerdict(BaseModel):
    """A fail-closed decision record for a formal production gate."""
    id: UUID4 = Field(default_factory=uuid4)
    chip_id: str
    gate_type: str # E.g. "GDS_RELEASE"
    verdict: str   # Reuse DecisionEnum values
    is_fail_closed: bool = True
    adjudicator_role: str # Reuse RoleEnum values
    associated_waiver_ids: List[UUID4] = [] # Linkage to waivers that influenced this verdict
    timestamp: datetime = Field(default_factory=get_tw_now)


class SignoffAuditBundle(BaseModel):
    """The final, replayable audit bundle for a signoff event."""
    id: UUID4 = Field(default_factory=uuid4)
    chip_id: str
    manifest_id: UUID4
    verdict_id: UUID4
    decision_chain: List[str] = [] # References to previous AdjudicationRecords
    audit_digest: str
    closed_at: datetime = Field(default_factory=get_tw_now)


# --- Phase 6: Waiver & Exception Objects ---

class SignoffWaiverRequest(BaseModel):
    """A formal request to waive a specific risk or missing evidence."""
    id: UUID4 = Field(default_factory=uuid4)
    chip_id: str
    risk_id: str
    rationale: str
    requested_by: str # human_id
    created_at: datetime = Field(default_factory=get_tw_now)


class SignoffWaiverRecord(BaseModel):
    """The authority-bearing record of a granted waiver."""
    id: UUID4 = Field(default_factory=uuid4)
    request_id: UUID4
    risk_id: str # The specific risk being waived (from Request)
    decision: str # DecisionEnum
    approver_id: str
    conditions: List[str] = []
    timestamp: datetime = Field(default_factory=get_tw_now)


# --- Phase 6: Rollback & Recovery Objects ---

class RollbackTriggerRecord(BaseModel):
    """Evidence of a gate failure or integrity drift triggering a rollback."""
    id: UUID4 = Field(default_factory=uuid4)
    chip_id: str
    trigger_reason: str
    evidence_failure_ref: str
    triggered_at: datetime = Field(default_factory=get_tw_now)


class RecoveryPlanRecord(BaseModel):
    """Actionable recovery plan issued after a block or rollback."""
    id: UUID4 = Field(default_factory=uuid4)
    trigger_record_id: UUID4
    steps: List[str] = []
    is_validated: bool = False
    created_at: datetime = Field(default_factory=get_tw_now)
