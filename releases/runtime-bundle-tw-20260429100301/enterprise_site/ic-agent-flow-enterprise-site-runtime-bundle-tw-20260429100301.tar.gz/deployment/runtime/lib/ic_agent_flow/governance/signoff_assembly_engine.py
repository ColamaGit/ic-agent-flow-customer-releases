"""
Signoff Assembly Engine (v0.1)
==============================
Logic for automatically assembling evidence from chip directories into 
formal Signoff objects.
"""
from __future__ import annotations

import os
import hashlib
from typing import List
from pathlib import Path

from ic_agent_flow.domain.objects.production_bridge_objects import (
    SignoffEvidenceManifest,
    SignoffEvidenceEntry
)
from ic_agent_flow.domain.utils.time import get_tw_now


class SignoffAssemblyEngine:
    """ 
    Scans chip project directories to materialize official 
    SignoffEvidenceManifests.
    """

    @staticmethod
    def _calculate_file_hash(file_path: str) -> str:
        """Helper to calculate SHA-256 of a file."""
        sha256_hash = hashlib.sha256()
        try:
            with open(file_path, "rb") as f:
                for byte_block in iter(lambda: f.read(4096), b""):
                    sha256_hash.update(byte_block)
            return sha256_hash.hexdigest()
        except FileNotFoundError:
            return "FILE_NOT_FOUND"

    @staticmethod
    def assemble_evidence_manifest(chip_id: str, base_chips_path: str = "chips") -> SignoffEvidenceManifest:
        """
        Walks the chip directory and aggregates all evidence into a manifest.
        Now populates per-file evidence_items for physical integrity checks.
        """
        chip_dir = Path(base_chips_path) / chip_id
        evidence_refs = []
        evidence_items = []
        hash_list = []

        # 1. Scan Skills Evidence
        skills_dir = chip_dir / "evidence" / "skills"
        if skills_dir.exists():
            for skill_run in skills_dir.iterdir():
                if skill_run.is_dir():
                    output_file = skill_run / "output.json"
                    if output_file.exists():
                        rel_path = str(output_file)
                        h = SignoffAssemblyEngine._calculate_file_hash(str(output_file))
                        evidence_refs.append(rel_path)
                        evidence_items.append(SignoffEvidenceEntry(path=rel_path, sha256=h))
                        hash_list.append(h)

        # 2. Scan Exports (Logs)
        exports_dir = chip_dir / "exports"
        if exports_dir.exists():
            for log_file in exports_dir.glob("*.log"):
                rel_path = str(log_file)
                h = SignoffAssemblyEngine._calculate_file_hash(str(log_file))
                evidence_refs.append(rel_path)
                evidence_items.append(SignoffEvidenceEntry(path=rel_path, sha256=h))
                hash_list.append(h)

        # 3. Calculate Aggregate Digest
        aggregate_data = "|".join(sorted(hash_list))
        digest_chain = hashlib.sha256(aggregate_data.encode()).hexdigest()

        return SignoffEvidenceManifest(
            chip_id=chip_id,
            evidence_refs=evidence_refs,
            evidence_items=evidence_items,
            digest_chain=digest_chain,
            created_at=get_tw_now()
        )
