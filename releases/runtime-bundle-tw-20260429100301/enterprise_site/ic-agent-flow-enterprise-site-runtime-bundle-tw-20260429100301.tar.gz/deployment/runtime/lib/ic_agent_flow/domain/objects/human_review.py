"""
Human Review Objects (Phase 3, D3-1 & D3-2)
=============================================
Bridges Phase 2 EvidenceBundleRef into the existing HumanCheckpointRunner
governance infrastructure.

D3-1: HumanReviewPackageBuilder   — builds HumanReviewPackage from EvidenceBundleRef
D3-2: HumanDecisionRecord         — formal record binding HumanDecision to bundle + chip

Authority:
- Agent builds the package (D3-1), human makes the decision (D3-2).
- Agent MUST NOT pre-fill decision. Human MUST sign every record.
- Timeout → TIMEOUT_HOLD (per D3-5 Absence Policy enforced in runner).
"""
from __future__ import annotations

import json
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional

from ic_agent_flow.domain.governance.checkpoint import (
    AuthorityRecord,
    CheckpointPolicy,
    DecisionEnum,
    HumanDecision,
    HumanReviewPackage,
    StageGateType,
)
from ic_agent_flow.domain.objects.evidence_bundle import BundleStatus, EvidenceBundleRef
from ic_agent_flow.domain.objects.triage_result import RiskLevel, TriageRecommendation


class HumanReviewPackageBuilder:
    """
    D3-1: Converts EvidenceBundleRef → HumanReviewPackage.

    This is the canonical bridge between Phase 2 evidence collection
    and Phase 3 human review. The builder is agent-operated; the
    resulting package is handed off to the human reviewer.
    """

    @staticmethod
    def build(bundle: EvidenceBundleRef) -> HumanReviewPackage:
        """
        Build a HumanReviewPackage from an EvidenceBundleRef.
        Requires bundle.status == READY_FOR_REVIEW.
        """
        if bundle.status != BundleStatus.READY_FOR_REVIEW:
            raise ValueError(
                f"Bundle {bundle.bundle_id} is not READY_FOR_REVIEW "
                f"(status={bundle.status.value}). Cannot build review package."
            )

        triage = bundle.triage_result
        sim = triage.simulation_result if triage else None

        # Determine gate type based on risk (PRD Phase 3)
        if triage and triage.risk_level == RiskLevel.CRITICAL:
            gate_type = StageGateType.ARTIFACT_REVIEW
        else:
            gate_type = StageGateType.ARTIFACT_REVIEW

        # Stratified Summary (PRD Phase 3)
        stratified_summary = f"""
[LAYER A: RAW TRUTH]
Chip: {bundle.chip_scope}
Bundle ID: {bundle.bundle_id}
Simulation Verdict: {sim.verdict.value if sim else 'N/A'}
Tests: {sim.tests_passed if sim else 'N/A'}/{sim.tests_run if sim else 'N/A'} passed
Coverage Avg: {sim.coverage.average_pct if sim and sim.coverage else 0.0}%

[LAYER B: SKILL-PRODUCED SUPPORT]
Risk Level: {triage.risk_level.value.upper() if triage else 'UNKNOWN'}
Recommendation: {triage.recommendation.value if triage else 'N/A'}
{triage.cognitive_summary[:500] if triage and triage.cognitive_summary else "No cognitive advisory available."}

[LAYER C: HUMAN DECISION HISTORY]
{bundle.resubmission_history[-1] if bundle.resubmission_history else "Initial submission."}
"""

        # Build open risks (Legacy Support)
        open_risks: List[str] = []
        if triage and triage.risk_indicators:
            for ri in triage.risk_indicators:
                prefix = "🔴" if ri.risk_level == RiskLevel.CRITICAL else "🟡"
                open_risks.append(f"{prefix} [{ri.category}] {ri.description[:100]}")

        # Evidence links (Legacy Support)
        evidence_links: List[str] = []
        if bundle.raw_artifacts:
            for art in bundle.raw_artifacts:
                evidence_links.append(
                    f"{art.kind.value}: {art.file_ref} (SHA256:{art.digest[:12] if art.digest else 'N/A'}...)"
                )

        # Populate Layers
        layer_a = [f"artifact:{art.kind.value}:{art.digest[:8]}" for art in bundle.raw_artifacts]
        layer_b = [f"triage:{triage.triage_id}" if triage else ""]
        layer_c = bundle.resubmission_history

        return HumanReviewPackage(
            subject_ref=f"chip:{bundle.chip_scope}::bundle:{bundle.bundle_id}",
            gate_type=gate_type,
            summary=stratified_summary.strip(),
            layer_a_evidence=[l for l in layer_a if l],
            layer_b_support=[l for l in layer_b if l],
            layer_c_history=layer_c,
            evidence_links=evidence_links,
            open_risks=open_risks,
        )


@dataclass
class HumanDecisionRecord:
    """
    D3-2: Formal Human Decision Record.

    Binds a HumanDecision to the evidence bundle and chip scope.
    This is the immutable, saved evidence of the human's review action.
    Persisted to chips/<chip_scope>/evidence/human_reviews/<record_id>.json
    """
    record_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    bundle_id: str = ""
    chip_scope: str = ""
    task_id: str = ""
    agent_id: str = ""
    package_id: str = ""

    # The actual human decision
    decision: str = ""                         # DecisionEnum value
    rationale: str = ""
    human_id: str = ""
    role_id: Optional[str] = None              # v0.5 Role ID
    is_timeout: bool = False
    conditions: List[str] = field(default_factory=list)
    
    # Skill Integration (PRD Phase 3)
    skill_attachment_refs: List[str] = field(default_factory=list)

    # Triage context snapshot (for audit trail)
    sim_verdict: Optional[str] = None
    risk_level: Optional[str] = None
    recommendation: Optional[str] = None
    critical_failures: int = 0

    # Timestamps
    decided_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    recorded_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    @classmethod
    def from_human_decision(
        cls,
        decision: HumanDecision,
        bundle: EvidenceBundleRef,
        package: HumanReviewPackage,
    ) -> "HumanDecisionRecord":
        """Produce a HumanDecisionRecord from HumanDecision + EvidenceBundleRef."""
        triage = bundle.triage_result
        sim = triage.simulation_result if triage else None
        return cls(
            bundle_id=bundle.bundle_id,
            chip_scope=bundle.chip_scope,
            task_id=bundle.task_id,
            agent_id=bundle.agent_id,
            package_id=str(package.id),
            decision=decision.decision.value,
            rationale=decision.rationale,
            human_id=decision.human_id,
            role_id=decision.role_id.value if decision.role_id else None,
            is_timeout=decision.is_timeout,
            conditions=decision.conditions,
            sim_verdict=sim.verdict.value if sim else None,
            risk_level=triage.risk_level.value if triage else None,
            recommendation=triage.recommendation.value if triage else None,
            critical_failures=triage.critical_failure_count if triage else 0,
            decided_at=decision.timestamp,
        )

    def persist(self, project_root: str) -> str:
        """
        Persist this record to chips/<chip_scope>/evidence/human_reviews/<record_id>.json
        Returns the saved file path.
        """
        reviews_dir = Path(project_root) / "chips" / self.chip_scope / "evidence" / "human_reviews"
        reviews_dir.mkdir(parents=True, exist_ok=True)

        record_path = reviews_dir / f"{self.record_id}.json"
        data = {
            "record_id": self.record_id,
            "bundle_id": self.bundle_id,
            "chip_scope": self.chip_scope,
            "task_id": self.task_id,
            "agent_id": self.agent_id,
            "package_id": self.package_id,
            "decision": self.decision,
            "rationale": self.rationale,
            "human_id": self.human_id,
            "role_id": self.role_id,
            "is_timeout": self.is_timeout,
            "conditions": self.conditions,
            "sim_verdict": self.sim_verdict,
            "risk_level": self.risk_level,
            "recommendation": self.recommendation,
            "critical_failures": self.critical_failures,
            "decided_at": self.decided_at.isoformat(),
            "recorded_at": self.recorded_at.isoformat(),
        }
        record_path.write_text(json.dumps(data, indent=2, ensure_ascii=False))
        return str(record_path)

    @property
    def is_approved(self) -> bool:
        return self.decision in {
            DecisionEnum.APPROVE.value,
            DecisionEnum.APPROVE_WITH_CONDITIONS.value,
        }

    @property
    def is_rejected(self) -> bool:
        return self.decision == DecisionEnum.REJECT.value

    @property
    def is_on_hold(self) -> bool:
        return self.decision in {
            DecisionEnum.HOLD.value,
            DecisionEnum.TIMEOUT_HOLD.value,
        }
