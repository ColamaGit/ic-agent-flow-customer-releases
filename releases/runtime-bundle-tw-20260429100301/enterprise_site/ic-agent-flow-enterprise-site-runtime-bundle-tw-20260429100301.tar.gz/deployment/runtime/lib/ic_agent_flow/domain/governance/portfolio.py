from typing import List, Optional
from pydantic import BaseModel, ConfigDict
from enum import Enum

class ScenarioType(str, Enum):
    READ_ONLY = "read-only"
    BOUNDED_EXECUTION = "bounded-execution"
    VERIFICATION_HEAVY = "verification-heavy"
    HUMAN_GATED = "human-gated"
    ECO_PREP = "eco-prep"
    RESTRICTED_ANALYSIS = "restricted-analysis"

class ObjectFamily(str, Enum):
    RTL = "RTL"
    CONSTRAINTS = "constraint_set"
    REPORTS = "reports"
    ADJUDICATION = "adjudication"
    ECO_OBJECTS = "ECO objects"
    TIER3_OBJECTS = "Tier 3 objects"

class GateType(str, Enum):
    COMPILE = "compile"
    TIMING = "timing"
    SIMULATION = "simulation"
    FORMAL = "formal"
    EQUIVALENCE = "equivalence"
    HUMAN_APPROVAL = "human approval"
    LEGALITY = "legality"

class TierLevel(str, Enum):
    TIER1 = "Tier 1"
    TIER2 = "Tier 2"
    TIER3 = "Tier 3"

class ExecutionStatus(str, Enum):
    ACTIVE = "Active"
    CLOSEOUT = "Closeout"
    PROPOSAL = "Proposal"
    DEPRECATED = "Deprecated"

class ScenarioCard(BaseModel):
    """Formal definition of a governed scenario mapping to the portfolio matrix."""
    scenario_id: str
    scenario_type: ScenarioType
    status: ExecutionStatus
    objective: str
    primary_objects: List[ObjectFamily]
    primary_gates: List[GateType]
    tier: TierLevel
    
    input_objects: List[str]
    contracts_used: List[str]
    output_objects: List[str]
    human_checkpoint_required: bool
    readiness_level: str
    known_gaps: List[str]
    promotion_target: str
    risk_class: str # Will be legacy soon
    async_job_path_used: bool = False
    evidence_preservation_used: bool = True

    model_config = ConfigDict(use_enum_values=True)
