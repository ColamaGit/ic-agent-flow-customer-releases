"""
Audit Completeness Checker (v0.1)
=================================
Final verification layer ensuring that a Signoff Audit Bundle is logically 
complete, physically intact, and identity-consistent.
"""
from __future__ import annotations

import hashlib
from typing import List, Tuple

from ic_agent_flow.domain.objects.production_bridge_objects import (
    SignoffAuditBundle,
    SignoffEvidenceManifest
)


class AuditCompletenessChecker:
    """ 
    Performs the final 'Closed-Loop' verification before a production release.
    Checks physical integrity (file hashes) and logical consistency (authority chain).
    """

    @staticmethod
    def _calculate_file_hash(file_path: str) -> str:
        """Helper to calculate SHA-256 of a file."""
        sha256_hash = hashlib.sha256()
        try:
            with open(file_path, "rb") as f:
                for byte_block in iter(lambda: f.read(4096), b""):
                    sha256_hash.update(byte_block)
            return sha256_hash.hexdigest()
        except FileNotFoundError:
            return "FILE_NOT_FOUND"

    @staticmethod
    def verify_physical_completeness(manifest: SignoffEvidenceManifest) -> Tuple[bool, List[str]]:
        """
        Performs a full physical sweep of all evidence artifacts described in the manifest.
        Now performs a file-by-file Hash verification against expected values.
        """
        failures = []
        
        # 1. Verify individually described items
        for entry in manifest.evidence_items:
            actual_hash = AuditCompletenessChecker._calculate_file_hash(entry.path)
            if actual_hash == "FILE_NOT_FOUND":
                failures.append(f"MISSING_FILE: {entry.path}")
            elif actual_hash != entry.sha256:
                failures.append(f"INTEGRITY_DRIFT: {entry.path} (Expected: {entry.sha256[:8]} Actual: {actual_hash[:8]})")
        
        # 2. Logic: If no failures, physical completeness is satisfied
        is_complete = len(failures) == 0
        return is_complete, failures

    @staticmethod
    def verify_identity_consistency(manifest: SignoffEvidenceManifest, audit_bundle: SignoffAuditBundle) -> bool:
        """
        Ensures the manifest and audit bundle refer to the same chip context.
        """
        return manifest.chip_id == audit_bundle.chip_id

    @staticmethod
    def verify_bundle_seal(audit_bundle: SignoffAuditBundle) -> bool:
        """
        Re-calculates the aggregate audit digest to detect tampering with the bundle structure.
        """
        raw_seal_data = f"{audit_bundle.chip_id}|{audit_bundle.manifest_id}|{audit_bundle.verdict_id}|{','.join(audit_bundle.decision_chain)}"
        expected_digest = hashlib.sha256(raw_seal_data.encode()).hexdigest()
        return audit_bundle.audit_digest == expected_digest
