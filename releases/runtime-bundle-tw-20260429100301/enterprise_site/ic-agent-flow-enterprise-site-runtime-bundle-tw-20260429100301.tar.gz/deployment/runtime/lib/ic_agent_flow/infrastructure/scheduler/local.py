import os
import signal
import subprocess
from datetime import datetime
from typing import List, Optional, Dict
from uuid import uuid4
import asyncio

from ic_agent_flow.infrastructure.job_model import JobRecord, JobStatus, LifecycleEvent
from ic_agent_flow.infrastructure.scheduler.base import AbstractScheduler

class LocalJobAdapter(AbstractScheduler):
    """
    Manages jobs as local OS processes using synchronous Popen with polling.
    Provides a more robust binding for environments with restricted signal handling.
    """
    
    def __init__(self, base_log_dir: str = "artifacts/jobs"):
        self.base_log_dir = base_log_dir
        self._jobs: Dict[str, JobRecord] = {}
        self._processes: Dict[str, subprocess.Popen] = {}
        os.makedirs(self.base_log_dir, exist_ok=True)

    async def submit(self, command: List[str], run_id: str, working_dir: str) -> JobRecord:
        job_id = f"local_{uuid4().hex[:8]}"
        
        job_dir = os.path.join(self.base_log_dir, job_id)
        os.makedirs(job_dir, exist_ok=True)
        stdout_path = os.path.join(job_dir, "stdout.log")
        
        job = JobRecord(
            job_id=job_id,
            run_id=run_id,
            status=JobStatus.SUBMITTED,
            command=command,
            working_dir=working_dir,
            metadata={"stdout": stdout_path}
        )
        job.transition_to(JobStatus.QUEUED, "Job accepted by local adapter")

        try:
            # Open file for output
            f_out = open(stdout_path, "w")
            
            # Start process synchronously (non-blocking call)
            proc = subprocess.Popen(
                command,
                stdout=f_out,
                stderr=subprocess.STDOUT,
                cwd=working_dir,
                start_new_session=True
            )
            
            job.pid = proc.pid
            job.transition_to(JobStatus.RUNNING, f"Process started with PID {proc.pid}")
            self._processes[job_id] = proc
            self._jobs[job_id] = job
            
            return job
            
        except Exception as e:
            job.transition_to(JobStatus.FAILED, f"Failed to launch: {str(e)}")
            self._jobs[job_id] = job
            return job

    async def poll(self, job_id: str) -> JobRecord:
        if job_id not in self._jobs:
            raise ValueError(f"Job {job_id} unknown")
            
        job = self._jobs[job_id]
        proc = self._processes.get(job_id)
        
        if job.status in [JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED]:
            return job

        if proc:
            # Non-blocking poll
            ret = proc.poll()
            if ret is None:
                # Still running
                return job
            
            # Process finished
            job.exit_code = ret
            if ret == 0:
                job.transition_to(JobStatus.COMPLETED, "Process finished successfully")
            else:
                job.transition_to(JobStatus.FAILED, f"Process finished with code {ret}")
            
            # Cleanup
            del self._processes[job_id]
        else:
            # Recovery logic for PID
            try:
                os.kill(job.pid, 0)
            except ProcessLookupError:
                job.transition_to(JobStatus.COMPLETED, "Process no longer found")

        return job

    async def cancel(self, job_id: str) -> bool:
        if job_id not in self._jobs: return False
        job = self._jobs[job_id]
        proc = self._processes.get(job_id)
        
        if job.status in [JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED]:
            return True

        try:
            if proc:
                proc.terminate()
            elif job.pid:
                os.kill(job.pid, signal.SIGTERM)
            job.transition_to(JobStatus.CANCELLED, "Termination signal sent")
            return True
        except:
            return False

    async def list_jobs(self, run_id: Optional[str] = None) -> List[JobRecord]:
        if run_id:
            return [j for j in self._jobs.values() if j.run_id == run_id]
        return list(self._jobs.values())
