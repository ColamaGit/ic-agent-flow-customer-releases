
from pydantic import BaseModel
from typing import List, Optional
from ic_agent_flow.domain.objects.qualification.deployment_qualification import EnvironmentFingerprint
from ic_agent_flow.governance.klayout.compatibility_validator import ToolchainCompatibilityRecord

class QualificationAdjudicationBridge:
    """
    將 Qualification 結果轉譯為 Decision Loop 可消費的 Input
    """
    @staticmethod
    def bridge(
        fingerprint: EnvironmentFingerprint,
        compatibility: ToolchainCompatibilityRecord,
        decision_context_ref: str
    ) -> dict:
        # 轉譯 verdict 為 Decision Loop 可消費語義
        if compatibility.verdict == "SUPPORTED":
            disposition = "AUTO_ADMIT"
        elif compatibility.verdict == "RESTRICTED":
            disposition = "HUMAN_ADJUDICATION_REQUIRED"
        else:
            disposition = "AUTO_BLOCK"
            
        return {
            "disposition": disposition,
            "site_id": fingerprint.site_id,
            "decision_context_ref": decision_context_ref,
            "qualification_summary": {
                "verdict": compatibility.verdict,
                "restrictions": compatibility.restrictions,
                "qualified_at": compatibility.qualified_at
            },
            "system_action": "route_to_human_loop" if disposition == "HUMAN_ADJUDICATION_REQUIRED" else "enforce"
        }
