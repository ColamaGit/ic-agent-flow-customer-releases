"""
Deployment Object Families (v3.1 Legalization)
=============================================
Formally defines the authority-bearing objects for Controlled Production Deployment.
These objects transition 5A from a declarative state to an enforceable object-governed state.
"""
from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import List, Optional, Dict, Any
from uuid import uuid4

from pydantic import BaseModel, Field, UUID4

from ic_agent_flow.domain.governance.checkpoint import DecisionEnum, RoleEnum
from ic_agent_flow.domain.utils.time import get_tw_now


class DeploymentStatus(str, Enum):
    PENDING = "PENDING"
    ACTIVATED = "ACTIVATED"
    BLOCKED = "BLOCKED"
    FAILED = "FAILED"
    REVOKED = "REVOKED"
    ROLLED_BACK = "ROLLED_BACK"
    EXPIRED = "EXPIRED"


class DispositionReasonCode(str, Enum):
    """Standardized reason codes for deployment outcomes (Priority 2)."""
    OK_ADMISSION_GRANTED = "OK_ADMISSION_GRANTED"
    ERR_INTEGRITY_DRIFT = "ERR_INTEGRITY_DRIFT"
    ERR_POLICY_SCOPE_VIOLATION = "ERR_POLICY_SCOPE_VIOLATION"
    ERR_TEMPORAL_EXPIRED = "ERR_TEMPORAL_EXPIRED"
    ERR_FAMILY_UNAUTHORIZED = "ERR_FAMILY_UNAUTHORIZED"
    MANUAL_ROLLBACK_DRILL = "MANUAL_ROLLBACK_DRILL"
    EMERGENCY_REVOCATION = "EMERGENCY_REVOCATION"


class DeploymentPolicy(BaseModel):
    """Enforceable policy object for controlled deployment scope."""
    policy_id: UUID4 = Field(default_factory=uuid4)
    name: str = "default_5a_policy"
    description: str
    allowed_chip_scopes: List[str]
    allowed_skill_families: List[str]
    enforcement_mode: str = "FAIL_CLOSED"
    mac_verification_required: bool = True
    
    # Temporal Hardening (Priority 3)
    valid_from: Optional[datetime] = None
    valid_until: Optional[datetime] = None
    
    created_at: datetime = Field(default_factory=get_tw_now)


class DeploymentAdmissionRecord(BaseModel):
    """Authority-bearing record of a granted deployment admission."""
    admission_id: UUID4 = Field(default_factory=uuid4)
    decision_record_ref: str  # Link to v0.5 DecisionRecord
    adjudicator_id: str  # human_id
    adjudicator_role: RoleEnum
    
    policy_id: UUID4
    target_scope: str
    allowed_task_ids: List[str] = ["*"]
    
    activated_at: datetime = Field(default_factory=get_tw_now)
    expires_at: Optional[datetime] = None
    status: DeploymentStatus = DeploymentStatus.ACTIVATED
    
    metadata: Dict[str, Any] = Field(default_factory=dict)


class DeploymentTargetBinding(BaseModel):
    """Binding of an admission to a specific execution target."""
    binding_id: UUID4 = Field(default_factory=uuid4)
    admission_id: UUID4
    target_id: str  # E.g. simulation_run_id
    workspace_id: str
    bound_at: datetime = Field(default_factory=get_tw_now)


class DeploymentIntegrityResult(BaseModel):
    """Evidence-producing guard result for MAC/Integrity verification."""
    result_id: UUID4 = Field(default_factory=uuid4)
    target_ref: str
    algorithm: str = "HMAC-SHA256"
    expected_mac: str
    actual_mac: str
    is_verified: bool
    
    # R7 Negative Proof Hook
    blocking_reason: Optional[str] = None
    
    verified_at: datetime = Field(default_factory=get_tw_now)


class DeploymentAuditRecord(BaseModel):
    """Auditable trace of a deployment event."""
    event_id: UUID4 = Field(default_factory=uuid4)
    admission_id: Optional[UUID4] = None
    target_id: str
    action: str  # E.g. "START", "BLOCK", "ROLLBACK", "COMPLETE"
    outcome: str
    reason_code: Optional[DispositionReasonCode] = None  # Standardized Logging
    operator_ref: Optional[str] = None  # human_id or system_id
    audit_trail_ref: str
    recorded_at: datetime = Field(default_factory=get_tw_now)


class DeploymentAuditBundle(BaseModel):
    """Aggregated governance bundle for a deployment lifecycle."""
    deployment_bundle_id: UUID4 = Field(default_factory=uuid4)
    admission_record: DeploymentAdmissionRecord
    integrity_results: List[DeploymentIntegrityResult] = []
    audit_records: List[DeploymentAuditRecord] = []
    
    bundle_digest: str  # HMAC-SHA256 seal
    escalation_package_ref: Optional[UUID4] = None  # Link to HumanReviewPackage
    metadata: Dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=get_tw_now)
    closed_at: Optional[datetime] = None
