from __future__ import annotations

import json
import os
import platform
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping


DEFAULT_BINARY_PATHS = {
    "verilator": None,
    "yosys": None,
    "openroad": None,
    "netgen": None,
    "klayout_python": ".venv/bin/python3",
}

DEFAULT_NANGATE45_ROOT = "deployment/collateral/Nangate45"

RUNTIME_OVERRIDE = "runtime_override"
DEPLOYMENT_PROFILE = "deployment_profile"
SITE_OVERLAY = "site_overlay"
ENVIRONMENT_DISCOVERY = "environment_discovery"
BUNDLED_DEFAULT = "bundled_default"


def _parse_yaml_scalar(raw: str) -> Any:
    value = raw.strip()
    if value in {"null", "~"}:
        return None
    if value.lower() == "true":
        return True
    if value.lower() == "false":
        return False
    if value.isdigit():
        return int(value)
    return value


def _parse_simple_yaml(path: Path) -> dict[str, Any]:
    lines = path.read_text(encoding="utf-8").splitlines()
    tokens: list[tuple[int, str]] = []
    for line in lines:
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        indent = len(line) - len(line.lstrip(" "))
        tokens.append((indent, stripped))

    def parse_block(start: int, indent: int) -> tuple[Any, int]:
        container: Any = None
        i = start
        while i < len(tokens):
            line_indent, text = tokens[i]
            if line_indent < indent:
                break
            if line_indent > indent:
                raise ValueError(f"Unexpected indentation at {path}:{i + 1}")

            if text.startswith("- "):
                if container is None:
                    container = []
                if not isinstance(container, list):
                    raise ValueError(f"Mixed mapping/list structure at {path}:{i + 1}")
                item_text = text[2:].strip()
                if not item_text:
                    child, next_index = parse_block(i + 1, indent + 2)
                    container.append(child)
                    i = next_index
                    continue
                if ":" in item_text and not item_text.endswith(":"):
                    key, value = item_text.split(":", 1)
                    container.append({key.strip(): _parse_yaml_scalar(value)})
                else:
                    container.append(_parse_yaml_scalar(item_text))
                i += 1
                continue

            if container is None:
                container = {}
            if not isinstance(container, dict):
                raise ValueError(f"Mixed mapping/list structure at {path}:{i + 1}")
            if ":" not in text:
                raise ValueError(f"Malformed YAML line at {path}:{i + 1}")

            key, raw_value = text.split(":", 1)
            key = key.strip()
            raw_value = raw_value.strip()
            if raw_value:
                container[key] = _parse_yaml_scalar(raw_value)
                i += 1
                continue

            next_indent = tokens[i + 1][0] if i + 1 < len(tokens) else None
            if next_indent is None or next_indent <= indent:
                container[key] = {}
                i += 1
                continue
            child, next_index = parse_block(i + 1, indent + 2)
            container[key] = child
            i = next_index

        return container if container is not None else {}, i

    parsed, _ = parse_block(0, 0)
    if not isinstance(parsed, dict):
        raise ValueError(f"Root YAML object must be a mapping: {path}")
    return parsed


def _deployment_profile_path(profile_id: str | None) -> Path | None:
    if not profile_id:
        return None
    profile_path = Path("deployment") / "profiles" / profile_id / "profile.yaml"
    if profile_path.exists():
        return profile_path
    return None


def _deployment_profile_ref(profile_id: str | None) -> str | None:
    profile_path = _deployment_profile_path(profile_id)
    if profile_path:
        return profile_path.as_posix()
    return None


def _load_deployment_profile(profile_id: str | None) -> dict[str, Any]:
    profile_path = _deployment_profile_path(profile_id)
    if not profile_path:
        return {}
    return _parse_simple_yaml(profile_path)


def _resolve_profile_id(explicit_overrides: Mapping[str, Any]) -> tuple[str | None, str | None]:
    if explicit_overrides.get("deployment_profile"):
        return str(explicit_overrides["deployment_profile"]), RUNTIME_OVERRIDE
    if os.environ.get("ICAF_DEPLOYMENT_PROFILE"):
        return os.environ["ICAF_DEPLOYMENT_PROFILE"], DEPLOYMENT_PROFILE
    return None, None


def _profile_allowed_override(profile_data: Mapping[str, Any], override_key: str) -> bool:
    allowed = set(profile_data.get("toolchain_profile", {}).get("allowed_override_keys", []))
    allowed.update(profile_data.get("collateral_profile", {}).get("allowed_override_keys", []))
    if not allowed:
        return True
    return override_key in allowed


def _resolve_path_binding(
    explicit_overrides: Mapping[str, Any],
    profile_data: Mapping[str, Any],
    profile_value: str | None,
    override_key: str,
    env_key: str,
    command_name: str | None,
    default_path: str | None,
) -> dict[str, Any]:
    if explicit_overrides.get(override_key):
        path = str(explicit_overrides[override_key])
        source = RUNTIME_OVERRIDE
    elif os.environ.get(env_key) and _profile_allowed_override(profile_data, override_key):
        path = os.environ[env_key]
        source = SITE_OVERLAY
    elif profile_value:
        path = profile_value
        source = DEPLOYMENT_PROFILE
    elif command_name:
        discovered = shutil.which(command_name)
        if discovered:
            path = discovered
            source = ENVIRONMENT_DISCOVERY
        else:
            path = default_path
            source = BUNDLED_DEFAULT
    else:
        path = default_path
        source = BUNDLED_DEFAULT
    return {
        "path": path,
        "resolution_source": source,
        "exists": bool(path) and Path(path).exists(),
    }


def _resolve_nangate45_root(explicit_overrides: Mapping[str, Any], profile_data: Mapping[str, Any]) -> dict[str, Any]:
    profile_value = profile_data.get("collateral_profile", {}).get("nangate45_root")
    return _resolve_path_binding(
        explicit_overrides=explicit_overrides,
        profile_data=profile_data,
        profile_value=profile_value,
        override_key="nangate45_root",
        env_key="ICAF_NANGATE45_ROOT",
        command_name=None,
        default_path=DEFAULT_NANGATE45_ROOT,
    )


def _resolve_nangate45_artifact(
    explicit_overrides: Mapping[str, Any],
    profile_data: Mapping[str, Any],
    override_key: str,
    env_key: str,
    profile_value: str | None,
    root_path: str,
    filename: str,
    inherited_source: str,
) -> dict[str, Any]:
    if explicit_overrides.get(override_key):
        path = str(explicit_overrides[override_key])
        source = RUNTIME_OVERRIDE
    elif os.environ.get(env_key) and _profile_allowed_override(profile_data, override_key):
        path = os.environ[env_key]
        source = SITE_OVERLAY
    elif profile_value:
        path = profile_value
        source = DEPLOYMENT_PROFILE
    else:
        path = str(Path(root_path) / filename) if root_path else None
        source = inherited_source
    return {
        "path": path,
        "resolution_source": source,
        "exists": bool(path) and Path(path).exists(),
    }


def _tool_version(tool_path: str | None, version_args: list[str]) -> str:
    if not tool_path:
        return "UNRESOLVED"
    try:
        proc = subprocess.run(
            [tool_path, *version_args],
            capture_output=True,
            text=True,
            timeout=10,
        )
    except Exception:
        return "UNKNOWN"
    output = (proc.stdout or proc.stderr or "").strip().splitlines()
    return output[0] if output else "UNKNOWN"


def _capture_environment_fingerprint(record: Mapping[str, Any]) -> dict[str, Any]:
    binaries = record["binaries"]
    deployment_profile = record["deployment_profile"]
    site_config = record.get("site_config", {})
    fingerprint_policy = record.get("environment_fingerprint_policy", {})
    return {
        "fingerprint_id": (
            f"envfp-{deployment_profile['profile_id'] or 'default'}-{platform.system().lower()}-{platform.machine().lower()}"
        ),
        "selected_profile": deployment_profile["profile_id"],
        "profile_ref": deployment_profile["profile_ref"],
        "site_class": site_config.get("site_class"),
        "environment_class": site_config.get("environment_class"),
        "profile_resolution_basis": fingerprint_policy.get("profile_resolution_basis"),
        "collateral_profile_ref": record.get("collateral_profile", {}).get("profile_id"),
        "host_os": platform.system(),
        "kernel_version": platform.release(),
        "cpu_arch": platform.machine(),
        "tool_versions": {
            "verilator": _tool_version(binaries["verilator"]["path"], ["--version"]),
            "yosys": _tool_version(binaries["yosys"]["path"], ["-V"]),
            "openroad": _tool_version(binaries["openroad"]["path"], ["-version"]),
            "netgen": _tool_version(binaries["netgen"]["path"], ["-batch", "quit"]),
            "klayout_python": _tool_version(binaries["klayout_python"]["path"], ["--version"]),
        },
        "captured_at": datetime.now(timezone.utc).isoformat(),
    }


def _build_environment_adjudication(record: Mapping[str, Any]) -> dict[str, Any]:
    fingerprint = dict(record.get("environment_fingerprint", {}))
    fingerprint_policy = dict(record.get("environment_fingerprint_policy", {}))
    comparability_policy = dict(record.get("comparability_policy", {}))
    binaries = dict(record.get("binaries", {}))
    collateral = dict(record.get("collateral", {}))

    missing_required_fields = [
        field for field in fingerprint_policy.get("required_fields", [])
        if fingerprint.get(field) in (None, "", [], {})
    ]
    unresolved_binaries = [
        name for name, meta in binaries.items()
        if meta.get("exists") is False
    ]
    unresolved_collateral = [
        name for name, meta in collateral.items()
        if meta.get("exists") is False
    ]

    active_invalidation_triggers: list[str] = []
    if (missing_required_fields or unresolved_binaries or unresolved_collateral) and "unresolved_provenance" not in active_invalidation_triggers:
        active_invalidation_triggers.append("unresolved_provenance")

    configured_triggers = comparability_policy.get("invalidation_triggers", [])
    active_invalidation_triggers.extend(
        trigger for trigger in configured_triggers
        if trigger == "unresolved_provenance" and trigger not in active_invalidation_triggers and (
            missing_required_fields or unresolved_binaries or unresolved_collateral
        )
    )

    fail_closed = bool(missing_required_fields or unresolved_binaries or unresolved_collateral)
    verdict_policy = comparability_policy.get("verdict_continuity")
    if fail_closed:
        verdict_continuity_state = "FAIL_CLOSED"
    elif verdict_policy == "requires_exact_environment_fingerprint":
        verdict_continuity_state = "REQUIRES_EXACT_ENVIRONMENT_FINGERPRINT"
    else:
        verdict_continuity_state = "PROFILE_POLICY_UNSPECIFIED"

    return {
        "authority_class": "environment_adjudication_record",
        "selected_profile": record.get("deployment_profile", {}).get("profile_id"),
        "environment_fingerprint_id": fingerprint.get("fingerprint_id"),
        "verdict_continuity_policy": verdict_policy,
        "verdict_continuity_state": verdict_continuity_state,
        "bounded_equivalence_rule": comparability_policy.get("bounded_equivalence_rule"),
        "historical_comparison_allowed": not fail_closed,
        "verdict_continuity_allowed": False if verdict_continuity_state != "PROFILE_POLICY_UNSPECIFIED" else not fail_closed,
        "fail_closed": fail_closed,
        "missing_required_fields": missing_required_fields,
        "unresolved_binaries": unresolved_binaries,
        "unresolved_collateral": unresolved_collateral,
        "active_invalidation_triggers": active_invalidation_triggers,
        "configured_invalidation_triggers": configured_triggers,
        "generated_at": datetime.now(timezone.utc).isoformat(),
    }


def resolve_toolchain_profile(explicit_overrides: Mapping[str, Any] | None = None) -> dict[str, Any]:
    overrides = explicit_overrides or {}
    profile_id, profile_source = _resolve_profile_id(overrides)
    profile_data = _load_deployment_profile(profile_id)
    toolchain_profile = profile_data.get("toolchain_profile", {})
    collateral_profile = profile_data.get("collateral_profile", {})
    customer_local_rerun = profile_data.get("customer_local_rerun", {})
    site_config = profile_data.get("site_config", {})
    environment_fingerprint_policy = profile_data.get("environment_fingerprint_policy", {})
    comparability_policy = profile_data.get("comparability_policy", {})
    nangate45_root = _resolve_nangate45_root(overrides, profile_data)
    record = {
        "authority_class": "normalized_toolchain_resolution_record",
        "deployment_profile": {
            "profile_id": profile_id,
            "profile_ref": _deployment_profile_ref(profile_id),
            "resolution_source": profile_source or BUNDLED_DEFAULT,
        },
        "toolchain_profile": {
            "profile_id": toolchain_profile.get("profile_id"),
            "allowed_override_keys": toolchain_profile.get("allowed_override_keys", []),
        },
        "collateral_profile": {
            "profile_id": collateral_profile.get("profile_id"),
            "allowed_override_keys": collateral_profile.get("allowed_override_keys", []),
        },
        "customer_local_rerun": {
            "release_runtime_entrypoint": customer_local_rerun.get("release_runtime_entrypoint"),
            "artifact_root": customer_local_rerun.get("artifact_root"),
            "result_format": customer_local_rerun.get("result_format"),
        },
        "site_config": {
            "site_class": site_config.get("site_class"),
            "environment_class": site_config.get("environment_class"),
            "override_carrier": site_config.get("override_carrier"),
        },
        "environment_fingerprint_policy": {
            "profile_resolution_basis": environment_fingerprint_policy.get("profile_resolution_basis"),
            "required_fields": environment_fingerprint_policy.get("required_fields", []),
        },
        "comparability_policy": {
            "verdict_continuity": comparability_policy.get("verdict_continuity"),
            "bounded_equivalence_rule": comparability_policy.get("bounded_equivalence_rule"),
            "invalidation_triggers": comparability_policy.get("invalidation_triggers", []),
        },
        "binaries": {
            "verilator": _resolve_path_binding(
                overrides, profile_data, toolchain_profile.get("binaries", {}).get("verilator"),
                "verilator_bin", "ICAF_VERILATOR_BIN", "verilator", DEFAULT_BINARY_PATHS["verilator"],
            ),
            "yosys": _resolve_path_binding(
                overrides, profile_data, toolchain_profile.get("binaries", {}).get("yosys"),
                "yosys_bin", "ICAF_YOSYS_BIN", "yosys", DEFAULT_BINARY_PATHS["yosys"],
            ),
            "openroad": _resolve_path_binding(
                overrides, profile_data, toolchain_profile.get("binaries", {}).get("openroad"),
                "openroad_bin", "ICAF_OPENROAD_BIN", "openroad", DEFAULT_BINARY_PATHS["openroad"],
            ),
            "netgen": _resolve_path_binding(
                overrides, profile_data, toolchain_profile.get("binaries", {}).get("netgen"),
                "netgen_bin", "ICAF_NETGEN_BIN", "netgen", DEFAULT_BINARY_PATHS["netgen"],
            ),
            "klayout_python": _resolve_path_binding(
                overrides, profile_data, toolchain_profile.get("binaries", {}).get("klayout_python"),
                "klayout_python_bin", "ICAF_KLAYOUT_PYTHON_BIN", None, DEFAULT_BINARY_PATHS["klayout_python"],
            ),
        },
        "collateral": {
            "nangate45_root": nangate45_root,
            "liberty_path": _resolve_nangate45_artifact(
                overrides, profile_data,
                "nangate45_lib_path", "ICAF_NANGATE45_LIB_PATH",
                collateral_profile.get("liberty_path"),
                nangate45_root["path"], "Nangate45_typ.lib", nangate45_root["resolution_source"],
            ),
            "tech_lef_path": _resolve_nangate45_artifact(
                overrides, profile_data,
                "nangate45_tech_lef_path", "ICAF_NANGATE45_TECH_LEF_PATH",
                collateral_profile.get("tech_lef_path"),
                nangate45_root["path"], "Nangate45_tech.lef", nangate45_root["resolution_source"],
            ),
            "stdcell_lef_path": _resolve_nangate45_artifact(
                overrides, profile_data,
                "nangate45_stdcell_lef_path", "ICAF_NANGATE45_STDCELL_LEF_PATH",
                collateral_profile.get("stdcell_lef_path"),
                nangate45_root["path"], "Nangate45_stdcell.lef", nangate45_root["resolution_source"],
            ),
            "tracks_path": _resolve_nangate45_artifact(
                overrides, profile_data,
                "nangate45_tracks_path", "ICAF_NANGATE45_TRACKS_PATH",
                collateral_profile.get("tracks_path"),
                nangate45_root["path"], "Nangate45.tracks", nangate45_root["resolution_source"],
            ),
        },
        "generated_at": datetime.now(timezone.utc).isoformat(),
    }
    record["environment_fingerprint"] = _capture_environment_fingerprint(record)
    record["environment_adjudication"] = _build_environment_adjudication(record)
    return record


def write_toolchain_resolution_artifact(run_dir: str | Path, record: Mapping[str, Any]) -> Path:
    out_dir = Path(run_dir) / "toolchain_resolution"
    out_dir.mkdir(parents=True, exist_ok=True)
    normalized_path = out_dir / "normalized_toolchain_resolution_record.json"
    fingerprint_path = out_dir / "environment_fingerprint.json"
    adjudication_path = out_dir / "environment_adjudication.json"
    adjudication = record.get("environment_adjudication")
    if adjudication is None:
        adjudication = _build_environment_adjudication(record)
    normalized_path.write_text(json.dumps(record, indent=2), encoding="utf-8")
    fingerprint_path.write_text(
        json.dumps(record.get("environment_fingerprint", {}), indent=2),
        encoding="utf-8",
    )
    adjudication_path.write_text(
        json.dumps(adjudication, indent=2),
        encoding="utf-8",
    )
    return out_dir
