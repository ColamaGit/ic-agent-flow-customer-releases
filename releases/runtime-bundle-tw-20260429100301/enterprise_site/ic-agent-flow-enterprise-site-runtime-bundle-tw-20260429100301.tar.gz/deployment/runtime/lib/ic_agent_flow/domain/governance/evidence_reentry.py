"""
Evidence Re-entry Runner (v0.5, PRD R4)
========================================
Handles the formal contract for re-entering the runtime after a 
REQUEST_MORE_EVIDENCE decision.
"""
from __future__ import annotations

import logging
from typing import Optional

from ic_agent_flow.domain.objects.decision_objects import EvidenceRequestRecord, RuntimeState
from ic_agent_flow.domain.objects.evidence_bundle import BundleStatus, EvidenceBundleRef

logger = logging.getLogger(__name__)


class EvidenceReentryRunner:
    """
    PRD R4: Evidence Re-entry Runtime Contract.
    Manages the lifecycle of a resubmission task.
    """

    @staticmethod
    def trigger_reentry(
        evidence_request: EvidenceRequestRecord,
        project_root: str,
    ) -> bool:
        """
        Marks the evidence request as in-progress and prepares the system 
        for a targeted re-run.
        Note: In v0.5 baseline, the actual invocation of XceliumTriageScenario 
        happens in the integration layer; this runner manages the governance state.
        """
        logger.info(f"Triggering evidence re-entry for bundle {evidence_request.bundle_id}")
        
        # 1. Update request state
        evidence_request.runtime_state = RuntimeState.IN_PROGRESS
        
        # 2. Log lineage
        logger.info(f"Resubmission Task ID assigned: {evidence_request.resubmission_task_id}")
        
        # In a real system, this would trigger an async workflow. 
        # For our baseline, we provide the hook.
        return True

    @staticmethod
    def complete_reentry(
        evidence_request: EvidenceRequestRecord,
        new_bundle: EvidenceBundleRef,
    ) -> None:
        """
        Links the new bundle to the original evidence request record.
        """
        evidence_request.runtime_state = RuntimeState.SUBMITTED
        evidence_request.submitted_at = new_bundle.created_at
        
        # Link original bundle lineage if possible
        new_bundle.resubmission_history.append(str(evidence_request.request_id))
        logger.info(f"Evidence re-entry complete. New bundle ready: {new_bundle.bundle_id}")
