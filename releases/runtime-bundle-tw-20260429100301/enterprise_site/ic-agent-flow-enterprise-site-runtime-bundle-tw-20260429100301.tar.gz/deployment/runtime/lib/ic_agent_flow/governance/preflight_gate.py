import os
import yaml
import hashlib
from .schemas.subject_binding import ScopeResolutionRecord, ManifestBindingRecord, ExecutionSubjectEnvelope

class PreflightGate:
    @staticmethod
    def resolve_scope(chip_id: str, task_id: str, manifest_path: str):
        if not os.path.exists(manifest_path):
            raise SystemError(f"ERR_INTEGRITY_DRIFT: Manifest missing at {manifest_path}")
        
        with open(manifest_path, 'r') as f:
            manifest_data = yaml.safe_load(f)
            
        if manifest_data.get("chip_id") != chip_id:
            raise SystemError(f"ERR_INTEGRITY_DRIFT: Identity mismatch!")
            
        return True
