import asyncio
import os
from datetime import datetime
from uuid import uuid4
from typing import List, Dict, Any

from ic_agent_flow.domain.objects import RTLSnapshot, AuthorityClass, Producer, ProducerType
from ic_agent_flow.infrastructure.job_model import JobStatus
from ic_agent_flow.infrastructure.scheduler.local import LocalJobAdapter
from ic_agent_flow.infrastructure.storage.object_store import ObjectStore
from ic_agent_flow.infrastructure.storage.artifact_store import ArtifactStore
from ic_agent_flow.infrastructure.storage.evidence_store import EvidenceStore
from ic_agent_flow.infrastructure.storage.retention_engine import RetentionEngine

from ic_agent_flow.domain.governance import (
    ExecutionRunRecord, 
    ReadinessNote, 
    CloseoutBundle
)
from ic_agent_flow.domain.verification import GateVerdict, Verdict, AdjudicationRecord, AdjudicationAuthority, Decision

class AsyncCompileElabScenario:
    """
    Implements Main Line C: Minimal Real Infrastructure Binding.
    Demonstrates the full async lifecycle and tiered storage integration.
    """
    
    def __init__(self):
        self.scheduler = LocalJobAdapter()
        self.objs = ObjectStore()
        self.artifacts = ArtifactStore()
        self.evidence = EvidenceStore()
        self.retention = RetentionEngine()

    async def run(self, rtl_files: List[str], tier: str = "Tier 2"):
        print(f"🚀 [Main Line C] Starting Async Compile Scenario (Tier: {tier})...", flush=True)
        run_id = str(uuid4())
        
        # 1. Store Input Object (Tiered Storage - Layer 1)
        rtl_snap = RTLSnapshot(
            id=uuid4(),
            version="v1.0.0",
            status="stable",
            authority_class=AuthorityClass.CANONICAL,
            producer=Producer(id="eng_alice", type=ProducerType.HUMAN),
            files=[{"path": path, "hash": "abc"} for path in rtl_files],
            created_at=datetime.now()
        )
        obj_path = self.objs.put_object(f"rtl_{rtl_snap.id}", rtl_snap, classification=tier)
        print(f"STORAGE: RTL Snapshot stored in ObjectStore: {obj_path}", flush=True)

        # 2. Submit Async Job (Infrastructure Binding)
        # We use 'ls' which returns immediately to verify the polling loop exit.
        mock_cmd = ["ls", "-la"]
        job = await self.scheduler.submit(mock_cmd, run_id, working_dir=os.getcwd())
        print(f"JOB: Submitted to LocalJobAdapter. Initial Status: {job.status}", flush=True)

        # 3. Async Lifecycle Polling
        print("JOB: Entering lifecycle polling loop...", flush=True)
        while job.status not in [JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED]:
            await asyncio.sleep(1)
            job = await self.scheduler.poll(job.job_id)
            print(f"  > Status Update: {job.status} (JobID: {job.job_id})", flush=True)

        # 4. Artifact Collection (Tiered Storage - Layer 2)
        if job.status == JobStatus.COMPLETED:
            log_path = job.metadata.get("stdout")
            if log_path:
                stored_log = self.artifacts.put_artifact(f"compile_{job.job_id}.log", log_path, classification=tier)
                print(f"STORAGE: Raw log stored in ArtifactStore: {stored_log}")

        # 5. Adjudication & Closeout (Tiered Storage - Layer 3)
        adjudication = AdjudicationRecord(
            adjudication_id=uuid4(),
            subject_refs=[f"rtl_snapshot:{rtl_snap.id}"],
            gate_verdict_refs=[],
            decision=Decision.PROCEED if job.status == JobStatus.COMPLETED else Decision.HOLD,
            decision_rationale=f"Job {job.job_id} reached terminal state {job.status}",
            authority=AdjudicationAuthority(human_id="auto_infra", role="InfrastructureMonitor"),
            approved_at=datetime.now()
        )

        bundle = CloseoutBundle(
            id=uuid4(),
            run_id=run_id,
            task_type="async-compile-elab",
            manifest={"subjects": [str(rtl_snap.id)]},
            adjudication_record=adjudication,
            created_at=datetime.now()
        )

        # 6. Apply Retention Policy
        policy = self.retention.get_policy(tier)
        expiry = self.retention.calculate_expiry(tier, bundle.created_at)
        print(f"POLICY: Tier {tier} Retention -> {policy['retention'].value}. Expiry: {expiry}")

        evidence_path = self.evidence.put_evidence(f"bundle_{run_id}", bundle.model_dump(), classification=tier)
        print(f"STORAGE: Closeout Bundle stored in EvidenceStore: {evidence_path}")

        print(f"\n✅ Async Scenario Complete. Final Job Status: {job.status}")
        return bundle

if __name__ == "__main__":
    scenario = AsyncCompileElabScenario()
    asyncio.run(scenario.run(["top.v", "sub.v"], tier="Tier 2"))
