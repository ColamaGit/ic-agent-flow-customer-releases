from typing import Dict, Any, Optional, List
from uuid import uuid4
from datetime import datetime
from ic_agent_flow.skills.registry import BaseSkill, register_skill
from ic_agent_flow.domain.objects.skill_records import SkillOutputRecord, SkillCognitiveEnvelope
from ic_agent_flow.domain.objects import AuthorityClass, DataClassification, Producer, ProducerType

class EvidenceGapDetectionSkill(BaseSkill):
    """
    FW-3: Evidence Gap Detection Skill.
    Identifies missing artifacts, coverage holes, or verification ambiguities.
    """
    
    def execute(
        self, 
        inputs: Dict[str, Any], 
        cognitive_context: Optional[SkillCognitiveEnvelope] = None
    ) -> SkillOutputRecord:
        # Logic: 
        # 1. Scan inputs for missing artifacts or low metrics
        # 2. Produce structured gap report
        
        gaps: List[Dict[str, Any]] = []
        
        # Example Logic: Check coverage
        coverage = inputs.get("coverage_pct", 100.0)
        target_coverage = inputs.get("target_coverage_pct", 95.0)
        
        if coverage < target_coverage:
            gaps.append({
                "gap_type": "COVERAGE_HOLE",
                "description": f"Overall coverage ({coverage}%) is below target ({target_coverage}%).",
                "severity": "CRITICAL"
            })
            
        # Example Logic: Check for missing log
        if not inputs.get("log_file_present", True):
            gaps.append({
                "gap_type": "MISSING_ARTIFACT",
                "description": "Primary simulation log artifact is missing from the bundle.",
                "severity": "BLOCKER"
            })
            
        advisory_text = "Evidence Gap Analysis: " + (f"{len(gaps)} gaps detected." if gaps else "No significant gaps detected.")
        if cognitive_context:
            advisory_text += f"\nCognitive Analysis: {cognitive_context.raw_response}"

        return SkillOutputRecord(
            id=uuid4(),
            invocation_id=uuid4(),
            version="v0.1.0",
            authority_class=AuthorityClass.ADVISORY,
            classification=DataClassification.INTERNAL_RESTRICTED,
            producer=Producer(id="evidence_gap_detection_skill", type=ProducerType.AGENT),
            created_at=datetime.now(),
            output_type="gap_analysis",
            output_data={
                "advisory_summary": advisory_text,
                "gaps": gaps,
                "requires_reentry": len(gaps) > 0
            },
            decision_attachable=True,
            review_package_eligible=True,
            authority_note="support_only"
        )

# Register the skill
register_skill("evidence_gap_detection", EvidenceGapDetectionSkill)
