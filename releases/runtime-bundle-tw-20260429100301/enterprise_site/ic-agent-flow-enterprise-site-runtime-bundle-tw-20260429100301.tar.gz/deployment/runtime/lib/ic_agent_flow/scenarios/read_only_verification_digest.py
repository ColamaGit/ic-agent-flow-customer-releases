from datetime import datetime, timezone
from uuid import uuid4
from ic_agent_flow.domain.objects import RTLSnapshot, AuthorityClass, Producer, ProducerType
from ic_agent_flow.adapters.parsers.timing_parser import TimingParser
from ic_agent_flow.adapters.parsers.drc_parser import DRCParser
from ic_agent_flow.context.assembler import ContextAssembler
from ic_agent_flow.domain.verification import AdjudicationRecord, AdjudicationAuthority, Decision, Verdict
from ic_agent_flow.domain.verification.evaluator import ContractEvaluator
from ic_agent_flow.domain.governance import (
    ExecutionRunRecord, 
    ReadinessNote, 
    CloseoutBundle, 
    HumanReviewPackage
)
from ic_agent_flow.domain.contracts import Contract, SelectedContracts
import json
import os

class ReadOnlyVerificationDigestScenario:
    """Implements the first anchor scenario: Read-only Verification Digest."""
    
    def __init__(self):
        self.assembler = ContextAssembler()
        self.timing_parser = TimingParser()
        self.drc_parser = DRCParser()
        self.evaluator = ContractEvaluator()
    
    def run(self, rtl_content: str, timing_log: str, drc_log: str):
        # 1. Create initial snapshot (Truth)
        rtl_snap = RTLSnapshot(
            id=uuid4(),
            version="v1.0.0",
            status="stable",
            authority_class=AuthorityClass.CANONICAL,
            producer=Producer(id="human_01", type=ProducerType.HUMAN),
            created_at=datetime.now(timezone.utc),
            files=[{"path": "top.v", "hash": "abc"}]
        )
        
        # 2. Assemble Context (Governance)
        manifest = self.assembler.assemble(
            task_type="read-only-verification-digest",
            subjects=[rtl_snap],
            assembler_id="orchestrator_v1"
        )
        
        # 3. Parse evidence (Adapters)
        timing_obj = self.timing_parser.parse(timing_log, f"rtl_snap:{rtl_snap.id}")
        drc_obj = self.drc_parser.parse(drc_log, f"rtl_snap:{rtl_snap.id}")
        
        # 4. Define Contracts
        contracts = SelectedContracts(
            version="v1.0.0",
            contracts=[
                Contract(id="T-01", name="Timing Compliance", schema_ref="timing_report.schema.json", description="Setup slack must be >= 0"),
                Contract(id="D-01", name="DRC Cleanliness", schema_ref="drc_report.schema.json", description="DRC status must be CLEAN")
            ]
        )
        
        # 5. Evaluate Verdicts (A1 Cleanup: No more hardcoded logic)
        t_verdict = self.evaluator.evaluate(contracts.contracts[0], timing_obj)
        d_verdict = self.evaluator.evaluate(contracts.contracts[1], drc_obj)
        
        # 6. Adjudication (Logic/Judgment)
        all_passed = all(v.verdict == Verdict.PASS for v in [t_verdict, d_verdict])
        
        adjudication = AdjudicationRecord(
            adjudication_id=uuid4(),
            subject_refs=[f"rtl_snapshot:{rtl_snap.id}"],
            gate_verdict_refs=[f"gate_verdict:{t_verdict.id}", f"gate_verdict:{d_verdict.id}"],
            decision=Decision.PROCEED if all_passed else Decision.HOLD,
            decision_rationale="All verification gates passed against contracts." if all_passed else "One or more gates failed or have marginal slack.",
            authority=AdjudicationAuthority(human_id="lead_validator_01", role="Validator"),
            approved_at=datetime.now(timezone.utc)
        )
 
        # 7. Execution Run Record
        run_record = ExecutionRunRecord(
            run_id=uuid4(),
            timestamp=datetime.now(timezone.utc),
            producer=Producer(id="agent_antigravity", type=ProducerType.AGENT),
            environment="local_dev_mac",
            task_type="read-only-verification-digest"
        )
 
        # 8. Human Review Package (A3: Generation)
        review_package = HumanReviewPackage(
            id=uuid4(),
            subject_objects=[f"rtl_snapshot:{rtl_snap.id}"],
            authoritative_evidence_refs=[f"timing_report:{timing_obj.id}", f"drc_report:{drc_obj.id}"],
            gate_verdict_summary=f"Timing: {t_verdict.verdict}, DRC: {d_verdict.verdict}",
            open_risks=[r for r in [t_verdict.rationale if t_verdict.verdict == Verdict.FAILED else None] if r],
            downstream_effect="Unlocks Phase 1 Readability Closeout.",
            created_at=datetime.now(timezone.utc)
        )
 
        # 9. Readiness Note (A4: Documentation)
        readiness_note = ReadinessNote(
            id=uuid4(),
            current_readiness="TR",
            target_readiness="RR",
            claims=["Automated timing and DRC parsing verified", "Contract-driven verdict establishment complete", "Forbidden: BR, VR, PR"],
            limitations=["Manual adjudication still required for marginal cases"],
            evidence_delta="Refactored to shared ContractEvaluator for Line 1 closeout",
            created_at=datetime.now(timezone.utc)
        )
 
        # 10. Assemble Closeout Bundle (A2)
        bundle = CloseoutBundle(
            id=uuid4(),
            task_type="read-only-verification-digest",
            input_objects=[rtl_snap],
            context_manifest=manifest,
            selected_contracts=contracts,
            execution_run_record=run_record,
            normalized_artifacts=[timing_obj, drc_obj],
            gate_verdicts=[t_verdict, d_verdict],
            adjudication_record=adjudication,
            human_review_package=review_package,
            final_readiness_note=readiness_note,
            created_at=datetime.now(timezone.utc)
        )
 
        # Save Bundle
        os.makedirs("artifacts/closeouts", exist_ok=True)
        bundle_path = f"artifacts/closeouts/bundle_{bundle.id}.json"
        with open(bundle_path, "w") as f:
            f.write(bundle.model_dump_json(indent=2))
 
        return {
            "bundle_id": bundle.id,
            "bundle_path": bundle_path,
            "bundle": bundle
        }

if __name__ == "__main__":
    scenario = ReadOnlyVerificationDigestScenario()
    try:
        with open("data/mock_reports/timing/summary.log", "r") as f:
            t_log = f.read()
        with open("data/mock_reports/drc/drc.summary", "r") as f:
            d_log = f.read()
            
        result = scenario.run("module top(); endmodule", t_log, d_log)
        print(f"Scenario run complete.")
        print(f"Bundle ID: {result['bundle_id']}")
        print(f"Final Decision: {result['bundle'].adjudication_record.decision}")
        print(f"Readiness Claim: {result['bundle'].final_readiness_note.target_readiness}")
    except Exception as e:
        print(f"Error details: {e}")
