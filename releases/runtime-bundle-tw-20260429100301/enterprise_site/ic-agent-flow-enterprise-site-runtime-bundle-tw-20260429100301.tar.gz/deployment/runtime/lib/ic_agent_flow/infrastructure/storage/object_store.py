import os
import json
from typing import Any, Dict, Optional
from pydantic import BaseModel

class ObjectStore:
    """
    Tiered Storage - Layer 1: Object Store
    Handles canonical / structured objects (Pydantic models).
    """
    
    def __init__(self, base_path: str = "artifacts/storage/objects"):
        self.base_path = base_path
        os.makedirs(self.base_path, exist_ok=True)

    def put_object(self, object_id: str, data: Any, classification: str = "Internal"):
        """Save a structured object as JSON."""
        # Partition by classification for basic organizational security
        class_dir = os.path.join(self.base_path, classification.replace(" ", "_"))
        os.makedirs(class_dir, exist_ok=True)
        
        target_path = os.path.join(class_dir, f"{object_id}.json")
        
        content = data
        if hasattr(data, "model_dump_json"):
            content = data.model_dump()
            
        with open(target_path, "w") as f:
            json.dump(content, f, indent=2, default=str)
            
        return target_path

    def get_object(self, object_id: str, classification: str = "Internal") -> Optional[Dict[str, Any]]:
        """Retrieve a structured object."""
        target_path = os.path.join(self.base_path, classification.replace(" ", "_"), f"{object_id}.json")
        if not os.path.exists(target_path):
            return None
            
        with open(target_path, "r") as f:
            return json.load(f)
