"""
Decision Attachment Matrix (Phase 3, PRD Hardening)
====================================================
Defines the formal rules for attaching skill outputs to human decision records.
Ensures authority isolation and prevents privilege escalation.
"""
from enum import Enum
from typing import Dict, Set, Optional
from pydantic import BaseModel

from ic_agent_flow.domain.objects import AuthorityClass
from ic_agent_flow.domain.governance.checkpoint import DecisionEnum

class AttachmentPolicy(BaseModel):
    allowed_decisions: Set[DecisionEnum]
    review_package_eligible: bool
    audit_bundle_eligible: bool
    reentry_input_eligible: bool
    forced_authority_class: AuthorityClass
    authority_note: str

# PRD R3.3: Decision Attachment Matrix
ATTACHMENT_MATRIX: Dict[str, AttachmentPolicy] = {
    "triage_advisory": AttachmentPolicy(
        allowed_decisions={DecisionEnum.APPROVE, DecisionEnum.REJECT, DecisionEnum.HOLD, DecisionEnum.REQUEST_MORE_EVIDENCE},
        review_package_eligible=True,
        audit_bundle_eligible=True,
        reentry_input_eligible=True,
        forced_authority_class=AuthorityClass.ADVISORY,
        authority_note="support_only"
    ),
    "gap_analysis": AttachmentPolicy(
        allowed_decisions={DecisionEnum.REQUEST_MORE_EVIDENCE, DecisionEnum.HOLD},
        review_package_eligible=True,
        audit_bundle_eligible=True,
        reentry_input_eligible=True,
        forced_authority_class=AuthorityClass.DERIVED,
        authority_note="not_evidence"
    ),
    "package_summary": AttachmentPolicy(
        allowed_decisions={DecisionEnum.APPROVE, DecisionEnum.REJECT, DecisionEnum.HOLD},
        review_package_eligible=True,
        audit_bundle_eligible=True,
        reentry_input_eligible=False,
        forced_authority_class=AuthorityClass.DERIVED,
        authority_note="derived_only"
    ),
    "cognitive_fragment": AttachmentPolicy(
        allowed_decisions={DecisionEnum.HOLD, DecisionEnum.REQUEST_MORE_EVIDENCE, DecisionEnum.ESCALATE},
        review_package_eligible=True,
        audit_bundle_eligible=True,
        reentry_input_eligible=True,
        forced_authority_class=AuthorityClass.ADVISORY,
        authority_note="with_metadata"
    ),
    "reentry_delta": AttachmentPolicy(
        allowed_decisions={DecisionEnum.REQUEST_MORE_EVIDENCE, DecisionEnum.HOLD},
        review_package_eligible=True,
        audit_bundle_eligible=True,
        reentry_input_eligible=True,
        forced_authority_class=AuthorityClass.ADVISORY,
        authority_note="planning_only"
    ),
    "package": AttachmentPolicy(
        allowed_decisions={DecisionEnum.APPROVE, DecisionEnum.REJECT, DecisionEnum.HOLD, DecisionEnum.REQUEST_MORE_EVIDENCE},
        review_package_eligible=False, # It IS the package assembly
        audit_bundle_eligible=True,
        reentry_input_eligible=False,
        forced_authority_class=AuthorityClass.OPERATIONAL_SUPPORT,
        authority_note="assembly_only"
    )
}

class AttachabilityGuard:
    @staticmethod
    def validate_attachment(output_type: str, decision: DecisionEnum, requested_authority: AuthorityClass) -> Optional[str]:
        """
        Validates if a skill output can be attached to a specific decision.
        Returns None if valid, or an error message if blocked.
        """
        policy = ATTACHMENT_MATRIX.get(output_type)
        if not policy:
            return f"Blocked: Unknown skill output type '{output_type}'"
        
        if decision not in policy.allowed_decisions:
            return f"Blocked: Skill output '{output_type}' cannot be attached to {decision.value} decision."
        
        # Guard 2: Illegal Authority Promotion
        forbidden_classes = {
            AuthorityClass.CANONICAL,
            AuthorityClass.AUTHORITY_BEARING,
            AuthorityClass.VERIFICATION_FINAL
        }
        if requested_authority in forbidden_classes:
            return f"Blocked: Illegal authority promotion to {requested_authority.value} for skill output."
            
        if requested_authority != policy.forced_authority_class:
            # We enforce the matrix's authority class
            pass
            
        return None
