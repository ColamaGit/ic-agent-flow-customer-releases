from typing import Optional, List
from pydantic import BaseModel, ConfigDict
from enum import Enum
from datetime import datetime

class ImpactType(str, Enum):
    NONE = "none"
    MINOR = "minor"
    MAJOR = "major"
    BREAKING = "breaking"

class ImpactAssessment(BaseModel):
    """Formalizes the exact impact of a policy/registry version change."""
    structural_diff: str
    behavioral_impact: str
    migration_requirements: str
    impact_level: ImpactType

class GovernanceAssetRecord(BaseModel):
    """A governed version of a policy, registry, or index."""
    asset_id: str
    asset_type: str  # e.g., 'policy', 'registry', 'contract'
    version: str     # Semver like
    effective_date: datetime
    supersedes_version: Optional[str] = None
    breaking_change: bool
    impact: ImpactAssessment

    model_config = ConfigDict(use_enum_values=True)
