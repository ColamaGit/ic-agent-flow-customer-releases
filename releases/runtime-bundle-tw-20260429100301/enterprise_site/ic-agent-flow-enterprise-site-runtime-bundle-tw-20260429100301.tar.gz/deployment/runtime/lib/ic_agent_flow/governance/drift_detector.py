
from enum import Enum
from typing import Dict, Any

class Disposition(Enum):
    FAIL_CLOSED = "FAIL_CLOSED"
    HOLD = "HOLD"
    ESCALATE = "ESCALATE"

class GovernanceDriftException(Exception):
    def __init__(self, message: str, drift_type: str):
        self.drift_type = drift_type
        super().__init__(message)

class DriftDetector:
    @staticmethod
    def detect_and_handle(error_type: str, context: Dict[str, Any]) -> Disposition:
        """
        根據 drift 類型返回對應處置，並封裝 IncidentAuditBundle
        """
        if error_type == "ERR_INTEGRITY_DRIFT":
            # 必須 FAIL_CLOSED 並升級至 Security/Auditor
            return Disposition.FAIL_CLOSED
        elif error_type == "ERR_PARSER_FAIL":
            return Disposition.HOLD
        elif error_type == "ERR_POLICY_SCOPE_VIOLATION":
            return Disposition.FAIL_CLOSED
        return Disposition.ESCALATE

    @staticmethod
    def create_incident_bundle(error_type: str, context: Dict[str, Any]) -> dict:
        return {
            "incident_type": error_type,
            "context": context,
            "timestamp": "2026-04-13T11:30:00Z"
        }
