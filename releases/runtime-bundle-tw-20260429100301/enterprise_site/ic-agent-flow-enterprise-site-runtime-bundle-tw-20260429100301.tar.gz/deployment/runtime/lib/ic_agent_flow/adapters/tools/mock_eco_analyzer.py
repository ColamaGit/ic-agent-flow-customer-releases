from datetime import datetime, timezone
from uuid import uuid4
from ic_agent_flow.domain.objects.eco import ImpactScope, RtlDiff
from ic_agent_flow.domain.objects import AuthorityClass, Producer, ProducerType

class MockEcoAnalyzer:
    """Simulates an AI or Tool agent identifying the impact of an ECO."""
    
    def analyze(self, diff: RtlDiff, tool_name="ai_eco_agent") -> ImpactScope:
        # Mock analysis logic: generate required gates based on diff hash length
        num_nets = max(1, len(diff.diff_hash) % 15)
        nand_req = len(diff.diff_hash) % 20
        inv_req = len(diff.diff_hash) % 10
        
        return ImpactScope(
            id=uuid4(),
            version="v1.0.0",
            authority_class=AuthorityClass.DERIVED,
            producer=Producer(id=tool_name, type=ProducerType.AGENT),
            base_diff_ref=f"rtl_diff:{diff.id}",
            tainted_nets=[f"net_{i}" for i in range(num_nets)],
            tainted_modules=diff.changed_modules,
            required_gates={"NAND2": nand_req, "INV": inv_req},
            created_at=datetime.now(timezone.utc)
        )
