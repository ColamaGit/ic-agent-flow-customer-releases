from datetime import datetime, timezone
from uuid import uuid4
from ic_agent_flow.domain.objects import AuthorityClass, Producer, ProducerType
from ic_agent_flow.domain.execution import ToolCommand, ExecutionBounds, EquivalenceResult

class MockFormal:
    """Simulates a Formal Equivalence Checker like Formality or Conformal."""
    
    def __init__(self, tool_name: str, version: str):
        self.tool_name = tool_name
        self.version = version
        
    def execute(self, cmd: ToolCommand, bounds: ExecutionBounds) -> EquivalenceResult:
        """Mocks the execution of an equivalence check."""
        
        # 1. Bounds Validation
        if cmd.tool_name not in bounds.allowed_tools:
            return EquivalenceResult(
                id=uuid4(),
                version="v1.0.0",
                authority_class=AuthorityClass.DERIVED,
                producer=Producer(id=self.tool_name, type=ProducerType.AGENT),
                is_equivalent=False,
                metadata={"error": "Tool not in allowed_tools"},
                created_at=datetime.now(timezone.utc)
            )

        # 2. Assume if "-abort_if_hard" is passed, it fails with unmapped points
        if "-abort_if_hard" in cmd.args:
            return EquivalenceResult(
                id=uuid4(),
                version="v1.0.0",
                authority_class=AuthorityClass.DERIVED,
                producer=Producer(id=self.tool_name, type=ProducerType.AGENT),
                is_equivalent=False,
                unmapped_points=5,
                failing_points=2,
                metadata={"runtime_seconds": 1500},
                created_at=datetime.now(timezone.utc)
            )

        # 3. Simulate Success
        return EquivalenceResult(
            id=uuid4(),
            version="v1.0.0",
            authority_class=AuthorityClass.DERIVED,
            producer=Producer(id=self.tool_name, type=ProducerType.AGENT),
            is_equivalent=True,
            unmapped_points=0,
            failing_points=0,
            metadata={"runtime_seconds": 450},
            created_at=datetime.now(timezone.utc)
        )
