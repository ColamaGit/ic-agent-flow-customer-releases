"""
Raw Artifact Reference Set (Phase 2, D2-4)
==========================================
Defines the canonical reference structure for raw tool output artifacts.
Every evidence object MUST reference its raw origin through ArtifactRef.

Authority: DERIVED — ArtifactRef is always produced from a real file system
           artifact and is never created without a referenced source.
"""
from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Optional


class StorageTier(str, Enum):
    """File storage tier classification (aligned with v0.3 three-tier model)."""
    TIER_1_TRANSIENT = "tier_1_transient"           # Short-lived, auto-cleanup
    TIER_2_WORKSPACE = "tier_2_workspace"           # Workspace lifecycle
    TIER_3_PERMANENT = "tier_3_permanent"           # Permanent, WORM


class ArtifactKind(str, Enum):
    """Kind of raw artifact."""
    SIMULATION_LOG = "simulation_log"
    ELABORATION_LOG = "elaboration_log"
    COVERAGE_DB = "coverage_db"
    WAVEFORM = "waveform"
    NETLIST = "netlist"
    TIMING_REPORT = "timing_report"
    GENERIC = "generic"


@dataclass
class ArtifactRef:
    """
    Canonical reference to a raw tool output artifact (D2-4).

    This is the immutable handle to any evidence source.
    Agent must NOT embed raw artifact content — it holds a reference only.
    """
    file_ref: str                               # Absolute or workspace-relative path
    kind: ArtifactKind = ArtifactKind.GENERIC
    tier: StorageTier = StorageTier.TIER_2_WORKSPACE
    digest: Optional[str] = None               # SHA-256 hex digest (computed on demand)
    size_bytes: Optional[int] = None
    chip_scope: Optional[str] = None
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def compute_digest(self) -> str:
        """Compute and cache SHA-256 digest of the referenced file."""
        path = Path(self.file_ref)
        if not path.exists():
            raise FileNotFoundError(f"Artifact not found: {self.file_ref}")

        sha256 = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                sha256.update(chunk)

        self.digest = sha256.hexdigest()
        self.size_bytes = path.stat().st_size
        return self.digest

    def ensure_digest(self) -> "ArtifactRef":
        """Ensure digest is populated. Compute if missing."""
        if self.digest is None:
            self.compute_digest()
        return self

    @classmethod
    def from_path(
        cls,
        path: str,
        kind: ArtifactKind = ArtifactKind.SIMULATION_LOG,
        tier: StorageTier = StorageTier.TIER_2_WORKSPACE,
        chip_scope: Optional[str] = None,
        compute_digest: bool = True,
    ) -> "ArtifactRef":
        """Factory: create ArtifactRef from a filesystem path."""
        ref = cls(
            file_ref=str(Path(path).resolve()),
            kind=kind,
            tier=tier,
            chip_scope=chip_scope,
        )
        if compute_digest:
            ref.compute_digest()
        return ref
