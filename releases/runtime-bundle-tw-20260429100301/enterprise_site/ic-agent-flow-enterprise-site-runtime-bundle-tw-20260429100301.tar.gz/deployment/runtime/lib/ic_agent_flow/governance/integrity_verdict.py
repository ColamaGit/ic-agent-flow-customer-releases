from typing import Dict, Any

class IntegrityVerdictEngine:
    @staticmethod
    def verify_binding(artifact: Dict[str, Any], expected_chip_id: str) -> bool:
        """
        驗證 Artifact 是否正確綁定了預期的 Subject
        """
        metadata = artifact.get("_governance_metadata", {})
        return metadata.get("chip_id") == expected_chip_id
