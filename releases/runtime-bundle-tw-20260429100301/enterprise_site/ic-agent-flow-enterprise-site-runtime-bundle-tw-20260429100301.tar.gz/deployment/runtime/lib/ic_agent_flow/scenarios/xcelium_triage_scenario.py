"""
Xcelium Simulation Evidence Triage Scenario (Phase 2 + Phase 3)
===============================================================
The first complete evidence collection + human review scenario for ic-agent-flow v0.4.

Bounded to: Evidence Collector Agent (evidence_collector_v0.4)
Chip scope: chip_id (resolved from TaskRequest)
Tool surface: Xcelium simulation log

Phase 2 execution (Steps 1-8): Evidence Collection
Phase 3 execution (D3-3 Handoff Protocol):
  - submit_for_review(): builds HumanReviewPackage + invokes HumanCheckpointRunner
  - programmatic_review(): non-interactive review for automated testing

Governance invariants:
- Agent does NOT issue pass/fail verdict
- All evidence MUST have source_artifact provenance
- Cognitive summary is advisory only
- Human Response Absence Policy (D3-5): timeout → TIMEOUT_HOLD (fail-closed)
- AuthorityRecord persisted to chips/<chip_scope>/evidence/human_reviews/
"""
from __future__ import annotations

import os
from datetime import datetime, timezone
from typing import Optional

from dotenv import load_dotenv

from ic_agent_flow.adapters.parsers.xcelium_parser import ParseFailure, XceliumLogParser
from ic_agent_flow.agents.evidence_collector import (
    EVIDENCE_COLLECTOR_IDENTITY,
    EscalationCondition,
)
from ic_agent_flow.cognitive.adapter import CognitiveAdapter
from ic_agent_flow.cognitive.schemas import (
    BackendPolicy,
    CognitiveRequest,
    SensitivityLevel,
)
from ic_agent_flow.domain.objects.artifact_ref import ArtifactKind, ArtifactRef, StorageTier
from ic_agent_flow.domain.objects.evidence_bundle import BundleStatus, EvidenceBundleRef
from ic_agent_flow.domain.objects.simulation_result import SimulationResult
from ic_agent_flow.domain.objects.triage_result import (
    TriageRecommendation,
    VerificationTriageResult,
)
from ic_agent_flow.domain.objects.human_review import (
    HumanDecisionRecord,
    HumanReviewPackageBuilder,
)
from ic_agent_flow.domain.objects.disposition import FinalDispositionRecord
from ic_agent_flow.domain.governance.checkpoint import (
    CheckpointPolicy,
    DecisionEnum,
    HumanCheckpointRunner,
    HumanDecision,
    StageGateType,
    RoleEnum,
)

load_dotenv()


class ScenarioError(Exception):
    """Raised when the scenario cannot proceed due to a hard failure."""
    pass


class XceliumTriageScenario:
    """
    Xcelium Simulation Evidence Triage Scenario.

    Usage:
        scenario = XceliumTriageScenario()
        bundle = scenario.run(
            chip_scope="legacy-chip-v0.1",
            log_path="/path/to/sim.log",
            task_id="task-001",
        )
        print(bundle.to_summary_dict())
    """

    def __init__(self):
        self._parser = XceliumLogParser()
        self._adapter = CognitiveAdapter()
        self._project_root = os.getenv("PROJECT_ROOT", os.getcwd())

    def run_for_chip(
        self,
        chip_scope: str,
        log_filename: str = "xcelium_sim_fail.log",
        task_id: str = "",
        workspace_id: str = "default-workspace",
    ) -> "EvidenceBundleRef":
        """
        Chip-scoped entrypoint (preferred).
        Resolves log path from: PROJECT_ROOT/chips/<chip_scope>/exports/<log_filename>
        Per PRD Scope Annex 2.1: agent reads from chips/<id>/exports/
        """
        log_path = self._resolve_chip_log_path(chip_scope, log_filename)
        return self.run(chip_scope=chip_scope, log_path=log_path, task_id=task_id, workspace_id=workspace_id)

    def _resolve_chip_log_path(self, chip_scope: str, log_filename: str) -> str:
        """
        Canonical chip-scoped log path resolver.
        Path convention: {PROJECT_ROOT}/chips/{chip_scope}/exports/{log_filename}
        Raises ScenarioError if exports/ directory does not exist.
        """
        exports_dir = os.path.join(self._project_root, "chips", chip_scope, "exports")
        if not os.path.isdir(exports_dir):
            raise ScenarioError(
                f"{EscalationCondition.ARTIFACT_MISSING.value}: "
                f"exports/ directory not found for chip '{chip_scope}'. "
                f"Expected: {exports_dir}"
            )
        log_path = os.path.join(exports_dir, log_filename)
        return log_path

    def run(
        self,
        chip_scope: str,
        log_path: str,
        task_id: str = "",
        workspace_id: str = "default-workspace",
    ) -> EvidenceBundleRef:
        """
        Execute the full triage scenario. Always returns EvidenceBundleRef.
        Raises ScenarioError only on unrecoverable input failures.
        """
        agent_id = EVIDENCE_COLLECTOR_IDENTITY.agent_id
        notes = []

        # ── Step 1: Validate inputs ────────────────────────────────────────
        if not chip_scope:
            raise ScenarioError(f"{EscalationCondition.CHIP_SCOPE_UNRESOLVED.value}: chip_scope is required")
        if not log_path:
            raise ScenarioError(f"{EscalationCondition.ARTIFACT_MISSING.value}: log_path is required")

        bundle = EvidenceBundleRef(
            chip_scope=chip_scope,
            workspace_id=workspace_id,
            task_id=task_id,
            agent_id=agent_id,
        )

        # ── Step 2: Create ArtifactRef (D2-4) ─────────────────────────────
        artifact_ref: Optional[ArtifactRef] = None
        try:
            artifact_ref = ArtifactRef.from_path(
                path=log_path,
                kind=ArtifactKind.SIMULATION_LOG,
                tier=StorageTier.TIER_2_WORKSPACE,
                chip_scope=chip_scope,
                compute_digest=True,
            )
            bundle.raw_artifacts.append(artifact_ref)
            notes.append(f"ArtifactRef created: digest={artifact_ref.digest[:12]}..., size={artifact_ref.size_bytes}B")
        except FileNotFoundError as e:
            raise ScenarioError(f"{EscalationCondition.ARTIFACT_MISSING.value}: {e}")

        # ── Step 3: Parse Xcelium log ──────────────────────────────────────
        parse_result = self._parser.parse(log_path)
        if isinstance(parse_result, ParseFailure):
            raise ScenarioError(
                f"{EscalationCondition.PARSE_FAILED.value}: {parse_result.reason}"
            )

        notes.append(
            f"Parsed: verdict={parse_result.verdict.value}, "
            f"tests={parse_result.tests_run}, "
            f"lines={parse_result.raw_lines}"
        )

        # ── Step 4: Normalize to SimulationResult (D2-5) + FailureTaxonomy (D2-7) ─
        sim_result = SimulationResult.from_parser_result(
            parsed=parse_result,
            chip_scope=chip_scope,
            source_artifact=artifact_ref,
            workspace_id=workspace_id,
        )
        notes.append(
            f"SimulationResult: verdict={sim_result.verdict.value}, "
            f"failures={len(sim_result.failure_records)}, "
            f"coverage_avg={sim_result.coverage.average_pct}%"
        )

        # ── Step 5: Invoke Cognitive Backend ──────────────────────────────
        cognitive_summary, cognitive_meta = self._invoke_cognitive(
            sim_result=sim_result,
            chip_scope=chip_scope,
            task_id=task_id,
        )
        notes.append(f"Cognitive: provider={cognitive_meta.get('provider')}, latency={cognitive_meta.get('latency_ms')}ms")

        # ── Step 6: Build VerificationTriageResult (D2-6) ─────────────────
        triage = VerificationTriageResult(
            chip_scope=chip_scope,
            workspace_id=workspace_id,
            task_id=task_id,
            agent_id=agent_id,
            simulation_result=sim_result,
            cognitive_summary=cognitive_summary,
            cognitive_provider=cognitive_meta.get("provider"),
            cognitive_model=cognitive_meta.get("model"),
            cognitive_latency_ms=cognitive_meta.get("latency_ms"),
        )
        triage.compute_risk()
        triage.triage_notes = notes

        notes.append(
            f"Triage: risk={triage.risk_level.value}, "
            f"recommendation={triage.recommendation.value}, "
            f"critical_failures={triage.critical_failure_count}"
        )

        # ── Step 7: Assemble EvidenceBundleRef (D2-8) ─────────────────────
        bundle.triage_result = triage
        bundle.assembly_notes = notes
        bundle.mark_ready()

        return bundle

    # ── Phase 3: Human Review Loop (D3-3 Review Handoff Protocol) ─────────────

    def submit_for_review(
        self,
        bundle: EvidenceBundleRef,
        timeout_seconds: int = 60,
        human_id: str = "local_operator_01",
        role_id: RoleEnum = RoleEnum.OPERATOR,
    ) -> tuple[HumanDecisionRecord, FinalDispositionRecord, DecisionEffect]:
        """
        D3-3 + v0.5: Formal Decision Loop Protocol.
        """
        # 1. Build review package
        package = HumanReviewPackageBuilder.build(bundle)

        # 2. D3-5: Human Response Absence Policy
        policy = CheckpointPolicy(
            timeout_seconds=timeout_seconds,
            default_timeout_decision=DecisionEnum.TIMEOUT_HOLD,
        )

        # 3. RBAC Check (v0.5)
        # We perform a pre-check using the Runner's internal matrix logic
        # and enforce it during execution.

        # 4. Execute checkpoint (interactive CLI)
        decision: HumanDecision = HumanCheckpointRunner.execute_checkpoint(
            package=package,
            policy=policy,
            human_id=human_id,
            role_id=role_id,
        )

        # 5. Build decision record (D3-2 + v0.5 role-binding)
        decision_record = HumanDecisionRecord.from_human_decision(
            decision=decision,
            bundle=bundle,
            package=package,
        )
        # Bind role_id to record (adding manually since it's a new field)
        decision_record.role_id = role_id
        decision_record_path = decision_record.persist(self._project_root)

        # 6. Apply Decision Effect (v0.5 Engine)
        # This replaces the simple v0.4 disposition creation with a governed engine
        from ic_agent_flow.governance.decision_effects import DecisionEffectEngine
        effect = DecisionEffectEngine.apply(
            decision_record=decision_record,
            bundle=bundle,
            project_root=self._project_root,
        )

        # 7. Finalized records from engine
        # In v0.5, FinalDispositionRecord is created inside the engine for APPROVE/REJECT
        # We retrieve the disposition record via standard path for legacy return consistency
        from ic_agent_flow.domain.objects.disposition import FinalDispositionRecord
        # Find the disposition in the effect records if created
        disposition = None
        for path in effect.created_records:
            if "_disposition.json" in str(path):
                # Load or just construct result (for simplicity in v0.5 flow)
                # Here we just re-run v0.4 logic to guarantee return object
                disposition = FinalDispositionRecord.from_decision_record(decision_record, bundle)
                break
        
        if not disposition:
            # For non-closing decisions (HOLD/REENTRY), we still produce a transient disposition 
            # object for legacy API compatibility
            disposition = FinalDispositionRecord.from_decision_record(decision_record, bundle)

        print(f"\n[v0.5 Decision Loop Complete]")
        print(f"  Role: {role_id.value}")
        print(f"  Effect Type: {effect.effect_type}")
        print(f"  New Status: {bundle.status.value}")
        print(f"  Decision Record: {decision_record_path}")

        return decision_record, disposition, effect

    def run_happy_path(
        self, 
        bundle: EvidenceBundleRef, 
        approver_id: str = "lead_approver_01"
    ) -> DecisionEffect:
        """v0.5 Path 1: approve -> CLOSED"""
        _, _, effect = self.submit_for_review(
            bundle=bundle,
            human_id=approver_id,
            role_id=RoleEnum.APPROVER
        )
        return effect

    def run_reentry_path(
        self, 
        bundle: EvidenceBundleRef, 
        reviewer_id: str = "senior_reviewer_01"
    ) -> DecisionEffect:
        """v0.5 Path 2: request_more_evidence -> Re-entry"""
        # Programmatic simulate of M (More Evidence)
        package = HumanReviewPackageBuilder.build(bundle)
        decision = HumanDecision(
            package_id=package.id,
            decision=DecisionEnum.REQUEST_MORE_EVIDENCE,
            rationale="Need coverage breakdown per sub-module.",
            human_id=reviewer_id,
            role_id=RoleEnum.REVIEWER
        )
        dec_rec = HumanDecisionRecord.from_human_decision(decision, bundle, package)
        dec_rec.role_id = RoleEnum.REVIEWER
        
        from ic_agent_flow.governance.decision_effects import DecisionEffectEngine
        effect = DecisionEffectEngine.apply(dec_rec, bundle, self._project_root)
        
        # Trigger actual re-entry logic (Step 4)
        if effect.effect_type == "REENTRY":
            from ic_agent_flow.domain.governance.evidence_reentry import EvidenceReentryRunner
            from ic_agent_flow.domain.objects.decision_objects import EvidenceRequestRecord
            # Simulate EvidenceRequestRecord lookup
            req = EvidenceRequestRecord(
                decision_record_id=dec_rec.record_id,
                bundle_id=bundle.bundle_id,
                chip_scope=bundle.chip_scope,
                requested_by=reviewer_id,
                requested_artifacts=["coverage_breakdown"],
                resubmission_task_id=f"resub-{bundle.task_id}"
            )
            EvidenceReentryRunner.trigger_reentry(req, self._project_root)
            
        return effect

    def _invoke_cognitive(
        self,
        sim_result: SimulationResult,
        chip_scope: str,
        task_id: str,
    ) -> tuple[str, dict]:
        """Invoke cognitive backend for triage summary. Returns (summary, metadata)."""
        prompt = self._build_triage_prompt(sim_result)

        req = CognitiveRequest(
            agent_id=EVIDENCE_COLLECTOR_IDENTITY.agent_id,
            chip_scope=chip_scope,
            task_type="xcelium_simulation_triage",
            prompt=prompt,
            system_context=(
                "You are a bounded IC verification evidence collector agent. "
                "Analyze the simulation evidence and provide a concise structured triage. "
                "Do NOT issue pass/fail verdicts. Do NOT recommend design changes. "
                "Only summarize findings and flag items requiring human review. "
                "Format your response with: 1) Summary 2) Key Concerns 3) Human Review Items"
            ),
            sensitivity=SensitivityLevel.INTERNAL,
            policy=BackendPolicy.REMOTE_ALLOWED_WITH_CONTROLS,
        )

        response = self._adapter.invoke(req)
        audit = self._adapter.last_audit

        meta = {
            "provider": audit.provider.value if audit else "unknown",
            "model": response.model_id,
            "latency_ms": audit.latency_ms if audit else None,
        }

        if response.is_error:
            return f"[COGNITIVE_DEGRADED] {response.error_message}", meta

        return response.content, meta

    def _build_triage_prompt(self, sim: SimulationResult) -> str:
        """Build the triage analysis prompt from SimulationResult."""
        lines = [
            f"Chip: {sim.chip_scope}",
            f"Simulation Verdict: {sim.verdict.value}",
            f"Tests: {sim.tests_passed}/{sim.tests_run} passed, {sim.tests_failed} failed",
            f"Coverage: line={sim.coverage.line_pct}%, branch={sim.coverage.branch_pct}%, avg={sim.coverage.average_pct}%",
            f"Assertions: {sim.assertions.passed}/{sim.assertions.total_checked} passed, {sim.assertions.failed} failed",
            f"Warnings: {sim.warning_count}",
        ]

        if sim.failure_records:
            lines.append("\nFailure Records:")
            for i, f in enumerate(sim.failure_records[:10], 1):
                lines.append(f"  {i}. [{f.severity.value.upper()}] {f.category.value}: {f.message[:120]}")

        if sim.warning_messages:
            lines.append("\nWarnings:")
            for w in sim.warning_messages[:5]:
                lines.append(f"  - {w[:100]}")

        lines.append("\nProvide a concise triage analysis for human reviewer.")
        return "\n".join(lines)
