"""
Verification Triage Result Object (Phase 2, D2-6)
==================================================
The primary evidence output of the Evidence Collector Agent.
Combines structured SimulationResult with Cognitive Backend triage summary.

Authority: DERIVED — produced by evidence_collector agent only.
           Agent may NOT assert verdict or approve waiver.
           All final decisions belong to human reviewer.
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import List, Optional

from ic_agent_flow.domain.objects.failure_taxonomy import FailureRecord, FailureSeverity
from ic_agent_flow.domain.objects.simulation_result import SimulationResult


class TriageRecommendation(str, Enum):
    """
    Triage recommendation from the agent (NOT a decision — human decides).
    This is the agent's informed suggestion to the human reviewer.
    """
    PROCEED_TO_REVIEW = "proceed_to_review"       # Evidence sufficient, send to human
    ESCALATE_CRITICAL = "escalate_critical"       # Critical failures, prioritize
    COLLECT_MORE_EVIDENCE = "collect_more_evidence"  # Insufficient evidence
    RERUN_SIMULATION = "rerun_simulation"         # Simulation incomplete/aborted
    BLOCK_UNTIL_RESOLVED = "block_until_resolved" # Hard blockers present


class RiskLevel(str, Enum):
    """Risk level indicator for the triage package."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class RiskIndicator:
    """A single risk indicator in the triage result."""
    risk_level: RiskLevel
    category: str
    description: str
    evidence_ref: Optional[str] = None    # Points to specific failure record


@dataclass
class VerificationTriageResult:
    """
    Verification Triage Result Object (D2-6).

    The canonical output of the Evidence Collector Agent's triage task.
    This object is submitted for human review — NOT for automatic promotion.

    Key invariants:
    - agent_verdict is ALWAYS absent (agent cannot issue pass/fail)
    - simulation_result MUST have provenance (source_artifact)
    - cognitive_summary is advisory only
    - human_decision is filled in Phase 3
    """
    triage_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    chip_scope: str = ""
    workspace_id: str = "default-workspace"
    task_id: str = ""
    agent_id: str = ""

    # Core evidence (D2-5)
    simulation_result: Optional[SimulationResult] = None

    # Cognitive advisory summary (from Gemini / local backend)
    cognitive_summary: Optional[str] = None
    cognitive_provider: Optional[str] = None
    cognitive_model: Optional[str] = None
    cognitive_latency_ms: Optional[float] = None

    # Triage outputs
    recommendation: TriageRecommendation = TriageRecommendation.PROCEED_TO_REVIEW
    risk_level: RiskLevel = RiskLevel.LOW
    risk_indicators: List[RiskIndicator] = field(default_factory=list)
    critical_failure_count: int = 0
    high_failure_count: int = 0
    requires_human_decision: bool = True    # ALWAYS True in Evidence Collector agent

    # Package metadata
    evidence_complete: bool = False
    triage_notes: List[str] = field(default_factory=list)
    produced_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    # Phase 3 slot — filled by HumanCheckpointRunner
    human_decision: Optional[str] = None
    human_decision_rationale: Optional[str] = None
    human_decision_at: Optional[datetime] = None

    def compute_risk(self) -> None:
        """
        Compute risk level from simulation_result failure records.
        Called after simulation_result is assigned.
        """
        if self.simulation_result is None:
            self.risk_level = RiskLevel.MEDIUM
            self.risk_indicators.append(RiskIndicator(
                risk_level=RiskLevel.MEDIUM,
                category="missing_evidence",
                description="No simulation result available — evidence collection incomplete",
            ))
            self.recommendation = TriageRecommendation.COLLECT_MORE_EVIDENCE
            return

        sim = self.simulation_result
        critical_count = sum(
            1 for f in sim.failure_records if f.severity == FailureSeverity.CRITICAL
        )
        high_count = sum(
            1 for f in sim.failure_records if f.severity == FailureSeverity.HIGH
        )
        self.critical_failure_count = critical_count
        self.high_failure_count = high_count

        # Build risk indicators
        for failure in sim.failure_records:
            self.risk_indicators.append(RiskIndicator(
                risk_level=RiskLevel.CRITICAL if failure.blocks_promotion else RiskLevel.HIGH,
                category=failure.category.value,
                description=failure.message,
                evidence_ref=failure.test_case or failure.assertion_name,
            ))

        # Determine overall risk level
        if critical_count > 0:
            self.risk_level = RiskLevel.CRITICAL
            self.recommendation = TriageRecommendation.ESCALATE_CRITICAL
        elif high_count > 0:
            self.risk_level = RiskLevel.HIGH
            self.recommendation = TriageRecommendation.PROCEED_TO_REVIEW
        elif sim.warning_count > 0:
            self.risk_level = RiskLevel.MEDIUM
            self.recommendation = TriageRecommendation.PROCEED_TO_REVIEW
        else:
            self.risk_level = RiskLevel.LOW
            self.recommendation = TriageRecommendation.PROCEED_TO_REVIEW

        if sim.verdict.value in {"INCOMPLETE", "ELABORATION_ERROR"}:
            self.recommendation = TriageRecommendation.RERUN_SIMULATION

        self.evidence_complete = sim.source_artifact is not None
