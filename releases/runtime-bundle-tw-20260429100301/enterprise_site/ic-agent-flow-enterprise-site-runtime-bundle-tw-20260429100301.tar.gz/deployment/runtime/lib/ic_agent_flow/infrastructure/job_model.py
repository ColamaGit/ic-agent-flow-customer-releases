from enum import Enum
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, ConfigDict
from datetime import datetime
from uuid import UUID

class JobStatus(str, Enum):
    SUBMITTED = "SUBMITTED"
    QUEUED = "QUEUED"
    RUNNING = "RUNNING"
    PARTIAL_OUTPUT_AVAILABLE = "PARTIAL_OUTPUT_AVAILABLE"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    TIMED_OUT = "TIMED_OUT"
    CANCELLED = "CANCELLED"

class LifecycleEvent(BaseModel):
    status: JobStatus
    timestamp: datetime
    message: Optional[str] = None

class JobRecord(BaseModel):
    """
    Minimal functional job record for tracking async lifecycles.
    Used by both Local and Slurm adapters.
    """
    job_id: str
    run_id: str
    status: JobStatus
    history: List[LifecycleEvent] = []
    
    # Tool info
    command: List[str]
    working_dir: str
    exit_code: Optional[int] = None
    
    # Telemetry
    pid: Optional[int] = None
    node_name: Optional[str] = None
    
    metadata: Dict[str, Any] = {}
    
    model_config = ConfigDict(use_enum_values=True)

    def transition_to(self, status: JobStatus, message: Optional[str] = None):
        self.status = status
        self.history.append(LifecycleEvent(
            status=status,
            timestamp=datetime.now(),
            message=message
        ))
