class AliasGovernance:
    _alias_registry = {
        "test-chip-02": "SN2025_Controller_v1",
        "async-fifo-v0.1": "FIFO_Async_Logic_v1"
    }

    @classmethod
    def resolve_label(cls, chip_id: str):
        """
        強制執行 Law 5: Report Labels Are Derived, Not Canonical
        """
        alias = cls._alias_registry.get(chip_id)
        if not alias:
            # 未註冊別名時，強制回退至 Canonical ID
            return chip_id
        return alias

class SurfaceTruthGuard:
    @staticmethod
    def block_illegal_rename(canonical_id: str, proposed_label: str):
        # 禁止未經註冊的自定義改名
        if proposed_label not in AliasGovernance._alias_registry.values() and proposed_label != canonical_id:
            raise PermissionError(f"ERR_INTEGRITY_DRIFT: Illegal rename from {canonical_id} to {proposed_label}")
