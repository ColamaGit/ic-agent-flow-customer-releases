from __future__ import annotations

from enum import Enum
from typing import List

from pydantic import BaseModel


class SummaryEvidenceResult(BaseModel):
    allowed: bool
    disposition: str
    reason: str


def evaluate_summary_evidence(
    summary_only: bool,
    raw_refs: List[str],
    normalized_refs: List[str],
    evidence_refs: List[str],
) -> SummaryEvidenceResult:
    if summary_only:
        return SummaryEvidenceResult(
            allowed=False,
            disposition="FAIL_CLOSED",
            reason="summary-only evidence is forbidden",
        )

    if not raw_refs or not normalized_refs or not evidence_refs:
        return SummaryEvidenceResult(
            allowed=False,
            disposition="FAIL_CLOSED",
            reason="traceability refs incomplete",
        )

    return SummaryEvidenceResult(
        allowed=True,
        disposition="PASS",
        reason="summary remains subordinate to evidence refs",
    )


class AdjudicationAction(str, Enum):
    FAIL_CLOSED = "FAIL_CLOSED"
    HOLD = "HOLD"
    ESCALATE = "ESCALATE"
    REJECT = "REJECT"
    REQUEST_MORE_EVIDENCE = "REQUEST_MORE_EVIDENCE"
    APPROVE_WITH_CONDITIONS = "APPROVE_WITH_CONDITIONS"
    APPROVE = "APPROVE"


class PrecedenceResult(BaseModel):
    final_action: AdjudicationAction
    reason: str


_PRECEDENCE_RANK = {
    AdjudicationAction.FAIL_CLOSED: 1,
    AdjudicationAction.HOLD: 2,
    AdjudicationAction.ESCALATE: 3,
    AdjudicationAction.REJECT: 4,
    AdjudicationAction.REQUEST_MORE_EVIDENCE: 5,
    AdjudicationAction.APPROVE_WITH_CONDITIONS: 6,
    AdjudicationAction.APPROVE: 7,
}


def resolve_adjudication_precedence(actions: List[AdjudicationAction]) -> PrecedenceResult:
    if not actions:
        return PrecedenceResult(final_action=AdjudicationAction.HOLD, reason="no actions provided")

    final_action = sorted(actions, key=lambda a: _PRECEDENCE_RANK[a])[0]
    return PrecedenceResult(
        final_action=final_action,
        reason=f"selected by precedence rank: {_PRECEDENCE_RANK[final_action]}",
    )
