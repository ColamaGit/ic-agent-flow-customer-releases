import json
import os

class ReviewPackageChecker:
    """ Evaluates whether a HumanReviewPackage is decision-ready for human authorities. """

    def __init__(self, artifacts_dir: str = "artifacts"):
        self.artifacts_dir = artifacts_dir

    def check_package(self, package_data: dict) -> dict:
        """ Validates the review package payload. """
        report = {
            "review_package_id": package_data.get("id", "unknown"),
            "subject_refs": package_data.get("subject_ids", []),
            "required_evidence_present": False,
            "risk_summary_quality": package_data.get("risk_summary_quality", "VAGUE"),
            "decision_readiness": False,
            "missing_items": [],
            "qa_verdict": {
                "verdict": "REVIEW_PACKAGE_NOT_DECISION_READY",
                "severity": "CRITICAL",
                "blocking": True,
                "summary": "Default not ready."
            }
        }

        evidence = package_data.get("evidence", [])
        if evidence:
            report["required_evidence_present"] = True
        else:
            report["missing_items"].append("No CloseoutBundle evidence attached.")

        if report["risk_summary_quality"] == "COMPREHENSIVE" and report["required_evidence_present"]:
            report["decision_readiness"] = True
            report["qa_verdict"]["verdict"] = "ACCEPTABLE"
            report["qa_verdict"]["severity"] = "INFO"
            report["qa_verdict"]["blocking"] = False
            report["qa_verdict"]["summary"] = "Package is decision-ready and safe to present to the Human Authority."
        else:
            report["qa_verdict"]["summary"] = "The risk summary is too vague or critical evidence is missing. Rejected to protect human reviewers."

        out_dir = os.path.join(self.artifacts_dir, "qa", "review_package_quality_reports")
        os.makedirs(out_dir, exist_ok=True)
        report_path = os.path.join(out_dir, f"review_package_qa_{report['review_package_id']}.json")
        with open(report_path, 'w') as f:
            json.dump(report, f, indent=2)

        return report
