from typing import List, Optional
from pydantic import BaseModel, Field, UUID4

class ExecutionScope(BaseModel):
    file_read: bool = False
    file_write: bool = False
    tool_execution: bool = False
    network_egress: bool = False
    artifact_visibility: str = "local" # local, project, global

class Contract(BaseModel):
    id: str
    name: str
    schema_ref: str
    description: str
    execution_scope: ExecutionScope

class SelectedContracts(BaseModel):
    contracts: List[Contract]
    version: str
