"""
Collaboration Engine (v0.7, PRD v0.7 Baseline)
==============================================
Core engine for managing the governed lifecycle of multi-agent collaboration.
Enforces Law 2 (Session-First), Law 3 (Issue Continuity), and Law 9 (Deadlock Detection).
"""
from __future__ import annotations

import hashlib
import json
import logging
from typing import List, Optional, Tuple, Dict, Any, Set
from uuid import UUID

from ic_agent_flow.domain.objects.collaboration_objects import (
    CollaborationSession,
    CollaborationSessionState,
    CollaborationStepRecord,
    CollaborationStepState,
    ExternalJobState,
    SharedIssueItem,
    IssueStatus,
    CollaborationConflictRecord,
    CollaborationResolutionRecord,
    CollaborationJobHandle
)
from ic_agent_flow.domain.utils.time import get_tw_now

logger = logging.getLogger(__name__)

class CollaborationEngine:
    """
    Governs multi-agent collaboration sessions and enforces progress-aware rules.
    """

    @staticmethod
    def run_preflight_check(
        workspace_id: str,
        chip_id: str,
        topology_legal: bool,
        agents_role_bound: bool,
        subject_lineage_complete: bool,
        shared_issue_initialized: bool,
        evidence_accessible: bool,
        human_state_compatible: bool
    ) -> List[str]:
        """
        R2: Collaboration Preflight Gate.
        Checks 8 mandatory conditions before session start.
        """
        failures = []
        if not workspace_id: failures.append("workspace_id_unresolved")
        if not chip_id: failures.append("chip_id_unresolved")
        if not topology_legal: failures.append("topology_illegal")
        if not agents_role_bound: failures.append("agents_not_role_bound")
        if not subject_lineage_complete: failures.append("subject_lineage_incomplete")
        if not shared_issue_initialized: failures.append("shared_issue_uninitialized")
        if not evidence_accessible: failures.append("evidence_inaccessible")
        if not human_state_compatible: failures.append("human_checkpoint_incompatible")
        
        return failures

    @staticmethod
    def initiate_session(
        workspace_id: str,
        chip_id: str,
        subject_refs: List[str],
        originating_task_ref: str,
        active_agent_ids: List[str]
    ) -> CollaborationSession:
        """
        PRD 6.2: Formal Collaboration Initiation.
        """
        session = CollaborationSession(
            workspace_id=workspace_id,
            chip_id=chip_id,
            subject_refs=subject_refs,
            active_agent_ids=active_agent_ids,
            originating_task_ref=originating_task_ref,
            status=CollaborationSessionState.OPEN
        )
        return session

    @staticmethod
    def start_step(
        session: CollaborationSession,
        owner_agent_id: str,
        step_type: str,
        input_refs: List[str],
        issue_refs: List[UUID]
    ) -> CollaborationStepRecord:
        """
        Law 4: Explicit Step Ownership.
        """
        step = CollaborationStepRecord(
            session_ref=session.session_id,
            step_owner_agent_id=owner_agent_id,
            step_type=step_type,
            input_refs=input_refs,
            issue_refs=issue_refs,
            status=CollaborationStepState.PENDING
        )
        session.current_step_id = step.step_id
        session.status = CollaborationSessionState.ACTIVE
        session.updated_at = get_tw_now()
        return step

    @staticmethod
    def detect_deadlock(
        session: CollaborationSession,
        step_history: List[CollaborationStepRecord],
        issue_id: UUID,
        threshold: int = 3
    ) -> bool:
        """
        R5: Progress-Aware Deadlock Detection.
        Checks for repeated transfers on the same issue with NO progress delta.
        """
        # Filter steps for this specific issue
        relevant_steps = [s for s in step_history if issue_id in s.issue_refs]
        
        if len(relevant_steps) < threshold:
            return False
            
        # Check for ping-pong pattern (A->B->A->B)
        last_n_steps = relevant_steps[-threshold:]
        owners = [s.step_owner_agent_id for s in last_n_steps]
        
        # Simple ping-pong: if owners alternate and no new evidence was attached to the issue
        # Note: In a real system, we'd check SharedIssueItem.evidence_refs delta
        
        is_repetitive = len(set(owners)) < len(owners)
        
        # Progress-aware: Did output_refs change?
        progress_made = any(len(s.output_refs) > 0 for s in last_n_steps)
        
        if is_repetitive and not progress_made:
            logger.warning(f"Deadlock detected for session {session.session_id} on issue {issue_id}")
            return True
            
        return False

    @staticmethod
    def update_issue(
        issue: SharedIssueItem,
        new_status: IssueStatus,
        reason: str,
        evidence_ref: Optional[str] = None
    ):
        """
        R3: Issue Identity & Continuity.
        """
        issue.update_status(new_status, reason)
        if evidence_ref:
            issue.append_evidence(evidence_ref)
        issue.updated_at = get_tw_now()

    @staticmethod
    def resolve_conflict(
        session: CollaborationSession,
        conflict: CollaborationConflictRecord,
        resolved_by: str,
        decision: str,
        rationale: str
    ) -> CollaborationResolutionRecord:
        """
        Law 8: Formal Conflict Resolution.
        """
        resolution = CollaborationResolutionRecord(
            conflict_ref=conflict.conflict_id,
            resolved_by=resolved_by,
            resolution_decision=decision,
            resolution_rationale=rationale
        )
        conflict.resolution_ref = resolution.resolution_id
        session.status = CollaborationSessionState.ACTIVE
        return resolution

    @staticmethod
    def detect_conflict(
        session: CollaborationSession,
        issue: SharedIssueItem,
        agent_id: str,
        proposed_status: IssueStatus,
        proposed_description: Optional[str] = None
    ) -> Optional[CollaborationConflictRecord]:
        """
        AC5: Conflict Detection Path.
        Checks if a proposed update contradicts existing issue state or consensus.
        """
        # Baseline rule: If proposed status is significantly different from current resolved/blocked state
        if issue.status in [IssueStatus.RESOLVED, IssueStatus.PARTIALLY_RESOLVED] and proposed_status == IssueStatus.BLOCKED:
            logger.warning(f"Conflict detected: Agent {agent_id} proposes BLOCKED on a RESOLVED issue {issue.issue_id}")
            
            conflict = CollaborationConflictRecord(
                session_ref=session.session_id,
                issue_ref=issue.issue_id,
                conflicting_agent_ids=[issue.owner_agent_id or "unknown", agent_id],
                conflict_type="VERDICT_MISMATCH"
            )
            session.conflict_refs.append(conflict.conflict_id)
            session.status = CollaborationSessionState.WAITING_ON_HUMAN
            return conflict
        
        return None

    @staticmethod
    def get_session_metrics(session: CollaborationSession) -> Dict[str, int]:
        """
        Returns basic metrics for the session.
        """
        return {
            "conflict_count": len(session.conflict_refs),
            "active_agent_count": len(session.active_agent_ids)
        }

    @staticmethod
    def validate_session_integrity(session: CollaborationSession) -> bool:
        """
        Validates that the session state is consistent.
        """
        return session.workspace_id is not None and session.session_id is not None

    @staticmethod
    def describe_session_status(
        session: CollaborationSession,
        issues: List[SharedIssueItem],
        conflicts: List[CollaborationConflictRecord] = []
    ) -> Dict[str, Any]:
        """
        AC8: Collaboration Observability Surface.
        Provides the 8 mandatory data points for session inspection.
        """
        # Calculate evidence delta (simplified for baseline)
        evidence_count = sum(len(i.evidence_refs) for i in issues)
        
        # Determine block/deadlock reason
        block_reason = None
        if session.status == CollaborationSessionState.WAITING_ON_HUMAN:
            block_reason = f"Unresolved Conflicts: {len(conflicts)}"
        elif session.status == CollaborationSessionState.BLOCKED:
            block_reason = "System Blocked (Transition failure or Deadlock)"

        report = {
            "session_id": str(session.session_id),
            "status": session.status.value,
            "active_agents": session.active_agent_ids,
            "current_owner": session.active_agent_ids[0] if session.active_agent_ids else None, # Simplified
            "issue_count": len(issues),
            "shared_issues": [
                {"id": str(i.issue_id), "status": i.status.value, "severity": i.severity.value} 
                for i in issues
            ],
            "evidence_delta_count": evidence_count,
            "block_reason": block_reason,
            "pending_human_checkpoints": 1 if session.status in [CollaborationSessionState.WAITING_ON_HUMAN] else 0,
            "approaching_closeout": all(i.status == IssueStatus.RESOLVED for i in issues) and len(issues) > 0
        }
        return report

    # --- v0.8 Runtime Governance Extension ---

    @staticmethod
    def validate_session_transition(session: CollaborationSession, target_state: CollaborationSessionState) -> List[str]:
        """
        R2: Session-level Transition Matrix.
        """
        violations = []
        source = session.status
        
        # forbidden transitions
        if source == CollaborationSessionState.CLOSED:
            violations.append(f"Forbidden: Cannot transition from CLOSED to {target_state}")
            
        if target_state == CollaborationSessionState.ACTIVE:
            if not session.active_agent_ids:
                violations.append("Precondition: ACTIVE requires at least one active agent")
        
        return violations

    @staticmethod
    def classify_failure(error_msg: str) -> Tuple[bool, str]:
        """
        R6: Failure Taxonomy.
        Returns: (is_retryable, failure_class)
        """
        retryable_keywords = ["timeout", "connection refused", "temporary", "retry"]
        msg_lower = error_msg.lower()
        
        if any(kw in msg_lower for kw in retryable_keywords):
            return True, "TRANSPORT_OR_TIMEOUT"
        
        if "permission" in msg_lower or "unauthorized" in msg_lower:
            return False, "AUTHORITY_VIOLATION"
            
        return False, "LOGIC_CRASH"

    @staticmethod
    def get_retry_policy(failure_class: str, retry_count: int, limit: int = 3) -> bool:
        """
        R6: Bounded Retry Law.
        """
        if failure_class != "TRANSPORT_OR_TIMEOUT":
            return False # Only transport failures are retryable in v0.8
            
        return retry_count < limit
    @staticmethod
    def track_and_cleanup_orphans(
        session: CollaborationSession, 
        job_handles: List[CollaborationJobHandle]
    ) -> List[str]:
        """
        R6 / AC7: Orphan Job Detection & Cleanup.
        Identifies RUNNING jobs that are stale (timed out or PID missing).
        """
        cleanups = []
        now = get_tw_now()
        
        for job in job_handles:
            if job.status in [ExternalJobState.RUNNING, ExternalJobState.SUBMITTED]:
                # 1. Timeout Check
                if job.timeout_at < now:
                    job.status = ExternalJobState.ORPHANED
                    job.cleanup_status = "CLEANED"
                    cleanups.append(f"Job {job.handle_id} timed out and marked as ORPHANED.")
                    continue
                
                # 2. Reattach Count Check (Simplified orphan logic)
                if job.reattach_count > 5:
                    job.status = ExternalJobState.ORPHANED
                    job.cleanup_status = "CLEANED"
                    cleanups.append(f"Job {job.handle_id} exceeded reattach limit and marked as ORPHANED.")
        
        if cleanups:
            session.updated_at = now
            
        return cleanups
