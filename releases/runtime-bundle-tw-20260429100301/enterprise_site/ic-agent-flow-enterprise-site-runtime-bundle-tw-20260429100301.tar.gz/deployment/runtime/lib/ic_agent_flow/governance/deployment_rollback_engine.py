"""
Deployment Rollback Engine (v3.4 Hardening)
===========================================
Implements the resilience truth for the controlled deployment guard plane.
Responsible for reverting admission states and generating R8 evidence.
"""
from __future__ import annotations

from typing import Optional
from uuid import UUID

from ic_agent_flow.domain.objects.deployment_objects import (
    DeploymentAdmissionRecord,
    DeploymentAuditBundle,
    DeploymentAuditRecord,
    DeploymentStatus,
    DispositionReasonCode,
)
from ic_agent_flow.domain.utils.time import get_tw_now


class DeploymentRollbackEngine:
    """ Authoritative engine for reversing deployment states in case of governance failure. """

    @staticmethod
    def rollback_admission(
        admission: DeploymentAdmissionRecord, 
        bundle: DeploymentAuditBundle,
        operator_id: str,
        reason: DispositionReasonCode = DispositionReasonCode.MANUAL_ROLLBACK_DRILL
    ) -> DeploymentAuditRecord:
        """
        R8: Physically reverts the admission status and records a rollback event.
        """
        old_status = admission.status
        admission.status = DeploymentStatus.ROLLED_BACK
        
        # Create the rollback audit track
        rollback_record = DeploymentAuditRecord(
            admission_id=admission.admission_id,
            target_id=admission.target_scope,
            action="ROLLBACK",
            outcome=DeploymentStatus.ROLLED_BACK.value,
            reason_code=reason,
            operator_ref=operator_id,
            audit_trail_ref=f"rollback-from-{old_status.value}"
        )
        
        # Append to the bundle if provided
        bundle.audit_records.append(rollback_record)
        bundle.closed_at = get_tw_now()
        
        return rollback_record

    @staticmethod
    def generate_rollback_evidence(bundle: DeploymentAuditBundle) -> dict:
        """
        Produces a serializable evidence object for the R8 closeout.
        """
        return {
            "evidence_type": "ROLLBACK_DRILL_V3.4",
            "deployment_bundle_id": str(bundle.deployment_bundle_id),
            "final_status": DeploymentStatus.ROLLED_BACK.value,
            "audit_trail": [
                {
                    "action": r.action,
                    "outcome": r.outcome,
                    "reason": r.reason_code.value if r.reason_code else None,
                    "at": str(r.recorded_at)
                } 
                for r in bundle.audit_records
            ]
        }
