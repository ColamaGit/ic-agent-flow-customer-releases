from ic_agent_flow.domain.utils.time import get_tw_now
from uuid import uuid4
from ic_agent_flow.domain.objects import RTLSnapshot, AuthorityClass, Producer, ProducerType
from ic_agent_flow.context.assembler import ContextAssembler
from ic_agent_flow.domain.verification import AdjudicationRecord, AdjudicationAuthority, Decision, Verdict
from ic_agent_flow.domain.verification.evaluator import ContractEvaluator
from ic_agent_flow.domain.governance import (
    ExecutionRunRecord, ReadinessNote, CloseoutBundle, HumanReviewPackage
)
from ic_agent_flow.domain.contracts import Contract, SelectedContracts
from ic_agent_flow.domain.execution import ToolCommand, ExecutionBounds, ToolInvocation
from ic_agent_flow.adapters.tools.mock_formal import MockFormal
import os

class FormalEquivalenceScenario:
    """E3: Verification-heavy loop comparing two RTL states."""
    
    def __init__(self):
        self.assembler = ContextAssembler()
        self.evaluator = ContractEvaluator()
        self.formal = MockFormal("formality", "2023.12")
    
    def run(self):
        # Requires TWO inputs for comparison
        rtl_golden = RTLSnapshot(id=uuid4(), version="v1.0.0", status="stable", authority_class=AuthorityClass.CANONICAL, producer=Producer(id="eng", type=ProducerType.HUMAN), created_at=datetime.now(timezone.utc), files=[{"path": "g.v", "hash": "g1"}])
        rtl_eco = RTLSnapshot(id=uuid4(), version="v1.1.0-eco", status="draft", authority_class=AuthorityClass.CANONICAL, producer=Producer(id="agent", type=ProducerType.AGENT), created_at=datetime.now(timezone.utc), files=[{"path": "g_eco.v", "hash": "g2"}])
        
        bounds = ExecutionBounds(allowed_tools=["formality", "conformal"], forbidden_args=["-abort_if_hard"], max_memory_gb=64, timeout_seconds=14400)
        cmd = ToolCommand(tool_name="formality", version="2023.12", args=["-golden", "g.v", "-revised", "g_eco.v"], working_dir="/formal")
        
        manifest = self.assembler.assemble(task_type="formal-lec", subjects=[rtl_golden, rtl_eco], assembler_id="orch")
        
        # 1. Invocation Tracker
        invoc = ToolInvocation(id=uuid4(), version="v1.0.0", authority_class=AuthorityClass.DERIVED, producer=Producer(id="agent", type=ProducerType.AGENT), command=cmd, bounds_applied=bounds, start_time=datetime.now(timezone.utc), created_at=datetime.now(timezone.utc))
        
        # 2. Execution
        eq_res = self.formal.execute(cmd, bounds)
        invoc.end_time = datetime.now(timezone.utc)
        invoc.result_ref = f"equivalence_result:{eq_res.id}"
        
        # 3. Contract Eval
        contracts = SelectedContracts(version="1", contracts=[Contract(id="E-01", name="Equivalence", schema_ref="eq.json", description="Must be 100% equivalent")])
        v1 = self.evaluator.evaluate(contracts.contracts[0], eq_res)
        
        # 4. Auth & Closeout
        adjudication = AdjudicationRecord(
            adjudication_id=uuid4(), subject_refs=[f"rtl_snapshot:{rtl_golden.id}", f"rtl_snapshot:{rtl_eco.id}"], gate_verdict_refs=[f"gate_verdict:{v1.id}"],
            decision=Decision.PROCEED if v1.verdict == Verdict.PASS else Decision.HOLD,
            decision_rationale="Formal check evaluated.", authority=AdjudicationAuthority(human_id="auto", role="Validator"), approved_at=datetime.now(timezone.utc)
        )
        run_record = ExecutionRunRecord(run_id=uuid4(), timestamp=datetime.now(timezone.utc), producer=Producer(id="ag", type=ProducerType.AGENT), environment="env", task_type="formal-lec")
        review_package = HumanReviewPackage(
            id=uuid4(), subject_objects=[f"rtl_snapshot:{rtl_golden.id}", f"rtl_snapshot:{rtl_eco.id}"], authoritative_evidence_refs=[f"equivalence_result:{eq_res.id}"],
            gate_verdict_summary=f"E-01: {v1.verdict}", open_risks=[], downstream_effect="Approves ECO for implementation.", created_at=datetime.now(timezone.utc)
        )
        r_note = ReadinessNote(id=uuid4(), current_readiness="RR", target_readiness="BR", claims=["Formal loop executed"], limitations=[], evidence_delta="", created_at=datetime.now(timezone.utc))
        
        bundle = CloseoutBundle(
            id=uuid4(), task_type="formal-lec", input_objects=[rtl_golden, rtl_eco, invoc], context_manifest=manifest, selected_contracts=contracts,
            execution_run_record=run_record, normalized_artifacts=[eq_res], gate_verdicts=[v1], adjudication_record=adjudication,
            human_review_package=review_package, final_readiness_note=r_note, created_at=datetime.now(timezone.utc)
        )
        
        os.makedirs("artifacts/closeouts", exist_ok=True)
        path = f"artifacts/closeouts/bundle_{bundle.id}.json"
        with open(path, "w") as f: f.write(bundle.model_dump_json(indent=2))
        return path

if __name__ == "__main__":
    s = FormalEquivalenceScenario()
    res = s.run()
    print(f"E3 Run Complete: {res}")
