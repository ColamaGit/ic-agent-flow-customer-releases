from typing import Dict, Any, Optional
from uuid import uuid4
from datetime import datetime
from ic_agent_flow.skills.registry import BaseSkill, register_skill
from ic_agent_flow.domain.objects.skill_records import SkillOutputRecord, SkillCognitiveEnvelope
from ic_agent_flow.domain.objects import AuthorityClass, DataClassification, Producer, ProducerType

class VerificationTriageSkill(BaseSkill):
    """
    FW-1: Analytic triage of verification results.
    Transforms raw simulation counts into high-level advisory insights.
    """
    
    def execute(
        self, 
        inputs: Dict[str, Any], 
        cognitive_context: Optional[SkillCognitiveEnvelope] = None
    ) -> SkillOutputRecord:
        # Inputs expected: sim_verdict, tests_run, tests_passed, etc.
        # Logic: 
        # 1. Analyze raw numbers
        # 2. Incorporate cognitive interpretation (if available)
        # 3. Produce structured advisory
        
        sim_verdict = inputs.get("sim_verdict", "UNKNOWN")
        passed = inputs.get("tests_passed", 0)
        run = inputs.get("tests_run", 0)
        
        advisory_text = f"Verification Triage Result: {sim_verdict}. Pass Rate: {passed}/{run}."
        
        if cognitive_context:
            advisory_text += f"\nCognitive Insight: {cognitive_context.raw_response}"
        
        return SkillOutputRecord(
            id=uuid4(),
            invocation_id=uuid4(), # Will be overwritten by SkillRunner
            version="v0.1.0",
            authority_class=AuthorityClass.ADVISORY,
            classification=DataClassification.INTERNAL_RESTRICTED,
            producer=Producer(id="verification_triage_skill", type=ProducerType.AGENT),
            created_at=datetime.now(),
            output_type="triage_advisory",
            output_data={
                "advisory_summary": advisory_text,
                "risk_mitigation_suggested": sim_verdict != "PASSED",
                "derived_from_cognitive": cognitive_context is not None
            },
            decision_attachable=True,
            review_package_eligible=True,
            authority_note="support_only"
        )

# Register the skill
register_skill("verification_triage", VerificationTriageSkill)
