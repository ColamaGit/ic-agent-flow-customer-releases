"""
Scenario: Minimal Real Infrastructure Binding Execution
Program: I (Minimal Real Binding)
Description: 
Demonstrates the integration of local process scheduling, 3-tier storage,
and classification-driven retention for a real command execution.
"""

import asyncio
import os
from datetime import datetime, timezone
from uuid import uuid4

from ic_agent_flow.domain.execution import ToolInvocation, ToolCommand, ExecutionBounds
from ic_agent_flow.domain.execution.job import JobStatus
from ic_agent_flow.domain.objects import (
    DataClassification, 
    Producer, 
    ProducerType, 
    AuthorityClass
)
from ic_agent_flow.domain.governance import CloseoutBundle, ContextManifest
from ic_agent_flow.infrastructure.scheduler.local import LocalScheduler
from ic_agent_flow.infrastructure.storage.engine import StorageEngine, StorageTier

async def run_real_infra_binding_scenario():
    # Initialize Infrastructure
    scheduler = LocalScheduler()
    storage = StorageEngine()
    
    print("\n--- Step 1: Tool Invocation Definition (Tier 3 HIGHLY SENSITIVE) ---")
    # We define a command that runs a few seconds to observe polling
    test_cmd = ToolCommand(
        tool_name="ls",
        version="1.0",
        args=["-R", "."], # Recursively list to generate some output
        working_dir=".",
        env={}
    )
    
    invocation = ToolInvocation(
        id=uuid4(),
        type="tool_invocation",
        version="v1.0",
        authority_class=AuthorityClass.CANONICAL,
        classification=DataClassification.HIGHLY_SENSITIVE_DESIGN,
        producer=Producer(id="ScenarioRunner", type=ProducerType.AGENT),
        created_at=datetime.now(timezone.utc),
        command=test_cmd,
        bounds_applied=ExecutionBounds(
            allowed_tools=["ls", "grep"],
            forbidden_args=[],
            max_memory_gb=1,
            timeout_seconds=30
        ),
        start_time=datetime.now(timezone.utc)
    )
    
    print(f"INFRA_REQUEST: Submitting ToolInvocation {invocation.id} to LocalScheduler...")
    job = scheduler.submit(invocation)
    print(f"INFRA_STATUS: Job {job.id} started with PID {job.scheduler_id}")
    
    print("\n--- Step 2: Lifecycle Polling (I1) ---")
    # Loop to observe state changes
    for attempt in range(10):
        await asyncio.sleep(0.5) 
        job = scheduler.poll(job)
        print(f"POLL_{attempt}: Status={job.status.value}")
        if job.is_terminal():
            break
            
    print(f"\n--- Step 3: Artifact Collection & Stratification (I3) ---")
    artifacts = scheduler.collect_artifacts(job)
    print(f"INFRA_ASSETS: Collected artifacts -> {artifacts}")
    
    # Stratify - Evidence vs Artifacts
    retention_class = storage.get_retention_class(StorageTier.ARTIFACT, job.classification)
    for art in artifacts:
        storage.apply_retention_logic(art, retention_class)

    print("\n--- Step 4: Governance Closeout & Evidence (I3) ---")
    bundle = CloseoutBundle(
        run_id=str(job.id),
        manifest=ContextManifest(subjects=["infra_binding_test_v1"]),
        verdicts={"I-01": "INFRA_BINDING_PASSED"},
        created_at=datetime.now(timezone.utc)
    )
    
    # Store Evidence
    evidence_path = storage.get_path(StorageTier.EVIDENCE, f"bundle_{bundle.id}.json")
    print(f"INFRA_EVIDENCE: Storing bundle to Evidence Tier -> {evidence_path}")
    storage.apply_retention_logic(evidence_path, storage.get_retention_class(StorageTier.EVIDENCE, job.classification))
    
    print("\n--- Final Status Recap ---")
    print(f"Job ID: {job.id}")
    print(f"PID: {job.scheduler_id}")
    print(f"Classification: {job.classification.value}")
    print(f"Retention: {retention_class.value}")
    print(f"Final Status: {job.status.value}")
    print(f"Evidence Tier: artifacts/closeouts/ (Permanent)")
    print("-" * 60)

if __name__ == "__main__":
    asyncio.run(run_real_infra_binding_scenario())
