"""
Handoff Object Families (v0.6, PRD v0.6 Baseline)
================================================
Defines the formal governance objects for inter-agent handoffs.
Ensures handoffs are formal, traceable, and fail-closed.
"""
from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import List, Optional, Dict, Any
from uuid import uuid4

from pydantic import BaseModel, Field, UUID4

from ic_agent_flow.domain.governance.checkpoint import DecisionEnum, RoleEnum
from ic_agent_flow.domain.utils.time import get_tw_now


class HandoffStatus(str, Enum):
    """The governed states of an inter-agent handoff."""
    REQUESTED = "REQUESTED"
    PENDING_ACCEPTANCE = "PENDING_ACCEPTANCE"
    ACCEPTED = "ACCEPTED"
    REJECTED = "REJECTED"
    RETURNED = "RETURNED"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    ESCALATED = "ESCALATED"


class HandoffFailureType(str, Enum):
    """Specific taxonomy for handoff process failures (Commander R5)."""
    PAYLOAD_INCOMPLETE = "handoff_payload_incomplete"
    SCOPE_MISMATCH = "handoff_scope_mismatch"
    AUTHORITY_MISMATCH = "handoff_authority_mismatch"
    POLICY_BLOCKED = "handoff_policy_blocked"
    TARGET_UNAVAILABLE = "handoff_target_unavailable"
    RETURNED_UNFINISHED = "handoff_returned_unfinished"
    OUTPUT_UNATTACHABLE = "handoff_output_unattachable"
    EVIDENCE_INVALID = "handoff_evidence_invalid"
    INTEGRITY_VIOLATION = "handoff_integrity_violation"
    SYSTEM_ERROR = "handoff_system_error"


class HandoffPayloadManifest(BaseModel):
    """
    Formal manifest of what is being handed off (Commander R2).
    Ensures evidence continuity and traceability.
    """
    manifest_id: UUID4 = Field(default_factory=uuid4)
    workspace_id: str
    chip_id: str
    source_agent_id: str
    target_agent_id: str
    
    # Traceability & Evidence (R2)
    subject_refs: List[str] = []         # Links to what is being triaged/fixed
    evidence_refs: List[str] = []        # Links to raw evidence artifacts
    artifact_refs: List[str] = []        # Links to existing normalized artifacts
    unresolved_issue_ids: List[str] = []  # Detailed IDs of what needs completion
    
    decision_context_ref: Optional[str] = None      # Link to the human decision record
    evidence_request_record_ref: Optional[str] = None # Link to the formal evidence request
    prior_decision_refs: List[str] = []             # Contextual history
    
    requested_outputs: List[str] = []               # What the target agent MUST produce
    authority_class: str = "operational"            # Always operational for agents in v0.6
    
    # Collaboration Integration (v0.7)
    session_ref: Optional[UUID4] = None             # Link to CollaborationSession
    shared_issue_ref: Optional[UUID4] = None        # Link to a specific SharedIssueItem
    
    payload_digest: str                             # HMAC-SHA256 for integrity protection
    metadata: Dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=get_tw_now)


class HandoffRequest(BaseModel):
    """
    Represents the initial request for an inter-agent handoff.
    """
    request_id: UUID4 = Field(default_factory=uuid4)
    source_agent_id: str
    target_agent_id: str
    source_task_id: str
    target_task_type: str  # e.g. "evidence_completion"
    
    workspace_id: str
    chip_id: str
    handoff_reason: str
    
    payload_manifest_ref: str  # Path to the materialized HandoffPayloadManifest
    
    created_at: datetime = Field(default_factory=get_tw_now)


class HandoffRecord(BaseModel):
    """
    The tracking record for a handoff event lifecycle.
    """
    handoff_id: UUID4 = Field(default_factory=uuid4)
    request_id: UUID4
    status: HandoffStatus = HandoffStatus.REQUESTED
    
    workspace_id: str
    chip_id: str
    
    current_payload_manifest_ref: str
    history: List[Dict[str, Any]] = []
    
    created_at: datetime = Field(default_factory=get_tw_now)
    updated_at: datetime = Field(default_factory=get_tw_now)


class HandoffAcceptanceRecord(BaseModel):
    """
    Target agent's formal acceptance of the handoff tasks.
    """
    acceptance_id: UUID4 = Field(default_factory=uuid4)
    handoff_id: UUID4
    target_agent_id: str
    accepted_at: datetime = Field(default_factory=get_tw_now)
    accepted_scope: str  # Formal statement of what is being worked on
    execution_binding_id: Optional[str] = None


class HandoffRejectionRecord(BaseModel):
    """
    Target agent's formal rejection of the handoff (Law 5).
    """
    rejection_id: UUID4 = Field(default_factory=uuid4)
    handoff_id: UUID4
    target_agent_id: str
    rejected_at: datetime = Field(default_factory=get_tw_now)
    rejection_type: HandoffFailureType
    rejection_reason: str
    missing_requirements: List[str] = []


class HandoffReturnRecord(BaseModel):
    """
    First-class return object for unfinished tasks (Commander R1).
    """
    return_id: UUID4 = Field(default_factory=uuid4)
    handoff_id: UUID4
    target_agent_id: str
    returned_at: datetime = Field(default_factory=get_tw_now)
    return_reason: str
    failure_type: HandoffFailureType = HandoffFailureType.RETURNED_UNFINISHED
    partial_outputs: List[str] = []
    remaining_gaps: List[str] = []
