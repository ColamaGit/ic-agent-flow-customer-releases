from __future__ import annotations

from typing import Dict, List, Optional
from uuid import UUID, uuid4

from pydantic import BaseModel, Field

from ic_agent_flow.domain.objects.decision_objects import EvidenceRequestRecord, RuntimeState
from ic_agent_flow.domain.objects.v09_runtime_objects import (
    CheckpointDeltaReport,
    RollbackCandidate,
    RollbackDecisionRecord,
    ToolCheckpoint,
    ToolSession,
    ToolSessionState,
)
from ic_agent_flow.domain.utils.time import get_tw_now
from ic_agent_flow.registry.scenario_registry import Disposition


class GatewayVerdict(BaseModel):
    allowed: bool
    disposition: Disposition
    reason: str


class ToolSessionCreateRequest(BaseModel):
    workspace_id: str
    chip_id: str
    subject_refs: List[str]
    decision_context_ref: str
    task_id: str
    tool_family: str = "open_source_eda"
    contract_name: str = "eda_tool_contract"
    contract_version: str = "v1"


class ReentryResult(BaseModel):
    parent_session_id: str
    child_session_id: str
    resubmission_history_ref: str
    disposition: Disposition


class EDAExecutionGateway:
    """
    First-class runtime boundary for tool execution governance.
    """

    def __init__(self) -> None:
        self._sessions: Dict[str, ToolSession] = {}
        self._session_history: Dict[str, List[str]] = {}

    def create_session(self, request: ToolSessionCreateRequest) -> ToolSession:
        session = ToolSession(
            workspace_id=request.workspace_id,
            chip_id=request.chip_id,
            subject_refs=request.subject_refs,
            decision_context_ref=request.decision_context_ref,
            task_id=request.task_id,
            tool_family=request.tool_family,
            contract_name=request.contract_name,
            contract_version=request.contract_version,
            session_status=ToolSessionState.ATTACHED,
            resume_token=f"resume-{uuid4()}",
        )
        self._sessions[str(session.tool_session_id)] = session
        self._session_history[str(session.tool_session_id)] = ["session_initialized", "attached"]
        return session

    def get_session(self, tool_session_id: str) -> ToolSession:
        return self._sessions[tool_session_id]

    def attach_execution_run(self, tool_session_id: str, run_ref: str) -> None:
        session = self.get_session(tool_session_id)
        session.execution_run_refs.append(run_ref)
        session.session_status = ToolSessionState.RUNNING
        session.updated_at = get_tw_now()
        self._session_history[tool_session_id].append(f"execution_run:{run_ref}")

    def attach_job_handle(self, tool_session_id: str, job_handle_ref: str, waiting: bool = False) -> None:
        session = self.get_session(tool_session_id)
        session.job_handle_refs.append(job_handle_ref)
        session.session_status = ToolSessionState.WAITING_ON_EXTERNAL_JOB if waiting else ToolSessionState.RUNNING
        session.updated_at = get_tw_now()
        self._session_history[tool_session_id].append(f"job_handle:{job_handle_ref}")

    def bind_artifacts(
        self,
        tool_session_id: str,
        raw_artifact_refs: List[str],
        normalized_output_refs: List[str],
        lineage_refs: List[str],
    ) -> GatewayVerdict:
        session = self.get_session(tool_session_id)
        session.artifact_refs.extend(raw_artifact_refs)
        session.normalized_output_refs.extend(normalized_output_refs)
        session.lineage_refs.extend(lineage_refs)
        session.session_status = ToolSessionState.ARTIFACT_PARTIAL_READY
        session.updated_at = get_tw_now()
        self._session_history[tool_session_id].append("artifacts_bound")

        if not session.artifact_refs or not session.normalized_output_refs or not session.lineage_refs:
            return GatewayVerdict(
                allowed=False,
                disposition=Disposition.FAIL_CLOSED,
                reason="raw/normalized/lineage continuity incomplete",
            )

        return GatewayVerdict(allowed=True, disposition=Disposition.PASS, reason="artifact continuity preserved")

    def create_checkpoint(self, tool_session_id: str, label: str, stage: str) -> ToolCheckpoint:
        session = self.get_session(tool_session_id)
        checkpoint = ToolCheckpoint(
            tool_session_id=UUID(tool_session_id),
            checkpoint_label=label,
            stage=stage,
            artifact_refs=list(session.artifact_refs),
            lineage_refs=list(session.lineage_refs),
        )
        session.attach_checkpoint(checkpoint)
        self._session_history[tool_session_id].append(f"checkpoint:{checkpoint.checkpoint_id}")
        return checkpoint

    def create_rollback_candidate(
        self,
        tool_session_id: str,
        target_checkpoint_ref: str,
        reason: str,
        from_checkpoint_ref: Optional[str] = None,
    ) -> RollbackCandidate:
        session = self.get_session(tool_session_id)
        start_ref = from_checkpoint_ref or (session.last_checkpoint_ref or target_checkpoint_ref)
        delta = CheckpointDeltaReport(
            tool_session_id=UUID(tool_session_id),
            from_checkpoint_ref=start_ref,
            to_checkpoint_ref=target_checkpoint_ref,
            delta_summary="degradation_detected",
            degradation_detected=True,
        )
        candidate = RollbackCandidate(
            tool_session_id=UUID(tool_session_id),
            target_checkpoint_ref=target_checkpoint_ref,
            causal_reason=reason,
            delta_report_ref=str(delta.delta_report_id),
        )
        session.session_status = ToolSessionState.ROLLBACK_PENDING
        session.audit_refs.append(f"delta_report:{delta.delta_report_id}")
        self._session_history[tool_session_id].append(f"rollback_candidate:{candidate.rollback_candidate_id}")
        return candidate

    def execute_rollback(
        self,
        tool_session_id: str,
        candidate: RollbackCandidate,
        approved: bool,
        reason: str,
    ) -> RollbackDecisionRecord:
        session = self.get_session(tool_session_id)
        decision = RollbackDecisionRecord(
            tool_session_id=UUID(tool_session_id),
            rollback_candidate_ref=str(candidate.rollback_candidate_id),
            target_checkpoint_ref=candidate.target_checkpoint_ref,
            approved=approved,
            reason=reason,
        )
        session.apply_rollback(decision)
        self._session_history[tool_session_id].append(f"rollback_decision:{decision.rollback_decision_id}")
        return decision

    def resume_session(
        self,
        tool_session_id: str,
        workspace_id: str,
        chip_id: str,
        subject_refs: List[str],
        resume_token: str,
    ) -> GatewayVerdict:
        session = self.get_session(tool_session_id)

        if session.resume_token != resume_token:
            session.session_status = ToolSessionState.STALE_REJECTED
            session.staleness_guard = "mismatched_resume_token"
            return GatewayVerdict(
                allowed=False,
                disposition=Disposition.FAIL_CLOSED,
                reason="resume token mismatch",
            )

        if session.workspace_id != workspace_id or session.chip_id != chip_id:
            session.session_status = ToolSessionState.STALE_REJECTED
            session.staleness_guard = "scope_mismatch"
            return GatewayVerdict(
                allowed=False,
                disposition=Disposition.FAIL_CLOSED,
                reason="workspace/chip scope mismatch",
            )

        if sorted(session.subject_refs) != sorted(subject_refs):
            session.session_status = ToolSessionState.STALE_REJECTED
            session.staleness_guard = "subject_mismatch"
            return GatewayVerdict(
                allowed=False,
                disposition=Disposition.FAIL_CLOSED,
                reason="subject refs mismatch",
            )

        session.session_status = ToolSessionState.RESUMING
        session.updated_at = get_tw_now()
        self._session_history[tool_session_id].append("resume")
        return GatewayVerdict(
            allowed=True,
            disposition=Disposition.PASS,
            reason="resume legal",
        )

    def bind_decision_context(self, tool_session_id: str, decision_context_ref: str) -> GatewayVerdict:
        session = self.get_session(tool_session_id)
        if not decision_context_ref.startswith("decision://"):
            return GatewayVerdict(
                allowed=False,
                disposition=Disposition.FAIL_CLOSED,
                reason="invalid decision loop binding",
            )
        session.decision_context_ref = decision_context_ref
        session.updated_at = get_tw_now()
        self._session_history[tool_session_id].append("decision_context_bound")
        return GatewayVerdict(
            allowed=True,
            disposition=Disposition.PASS,
            reason="decision loop remains unique",
        )

    def enforce_boundary_split(self, tool_payload: Dict[str, str]) -> GatewayVerdict:
        forbidden_keys = {"backend_route", "backend_policy", "model_selection"}
        if forbidden_keys.intersection(tool_payload.keys()):
            return GatewayVerdict(
                allowed=False,
                disposition=Disposition.ESCALATE,
                reason="tool boundary crossed into cognitive backend responsibility",
            )
        return GatewayVerdict(allowed=True, disposition=Disposition.PASS, reason="boundary separation valid")

    def trigger_reentry(
        self,
        tool_session_id: str,
        evidence_request: EvidenceRequestRecord,
        new_artifact_refs: List[str],
        new_normalized_refs: List[str],
    ) -> ReentryResult:
        parent = self.get_session(tool_session_id)
        child = ToolSession(
            workspace_id=parent.workspace_id,
            chip_id=parent.chip_id,
            subject_refs=list(parent.subject_refs),
            decision_context_ref=parent.decision_context_ref,
            task_id=parent.task_id,
            tool_family=parent.tool_family,
            contract_name=parent.contract_name,
            contract_version=parent.contract_version,
            session_status=ToolSessionState.ATTACHED,
            resume_token=f"resume-{uuid4()}",
        )
        child.artifact_refs.extend(new_artifact_refs)
        child.normalized_output_refs.extend(new_normalized_refs)
        child.lineage_refs.extend(parent.lineage_refs)

        evidence_request.runtime_state = RuntimeState.IN_PROGRESS
        child_id = str(child.tool_session_id)
        parent.child_session_refs.append(child_id)
        self._sessions[child_id] = child
        self._session_history[child_id] = [f"child_of:{tool_session_id}"]
        self._session_history[tool_session_id].append(f"reentry_child:{child_id}")

        return ReentryResult(
            parent_session_id=tool_session_id,
            child_session_id=child_id,
            resubmission_history_ref=f"reentry_history:{evidence_request.request_id}",
            disposition=Disposition.PASS,
        )

    def observability(self, tool_session_id: str) -> Dict[str, object]:
        return self.get_session(tool_session_id).observability_snapshot()

    def summary_traceability_verdict(self, tool_session_id: str, summary_only: bool = False) -> GatewayVerdict:
        session = self.get_session(tool_session_id)
        if summary_only:
            return GatewayVerdict(
                allowed=False,
                disposition=Disposition.FAIL_CLOSED,
                reason="summary-only evidence is forbidden",
            )
        if not session.artifact_refs or not session.normalized_output_refs or not session.lineage_refs:
            return GatewayVerdict(
                allowed=False,
                disposition=Disposition.FAIL_CLOSED,
                reason="traceability chain incomplete",
            )
        if not self._session_history.get(tool_session_id):
            return GatewayVerdict(
                allowed=False,
                disposition=Disposition.FAIL_CLOSED,
                reason="session history missing",
            )
        return GatewayVerdict(
            allowed=True,
            disposition=Disposition.PASS,
            reason="summary does not replace evidence",
        )

    def session_history(self, tool_session_id: str) -> List[str]:
        return self._session_history.get(tool_session_id, [])
