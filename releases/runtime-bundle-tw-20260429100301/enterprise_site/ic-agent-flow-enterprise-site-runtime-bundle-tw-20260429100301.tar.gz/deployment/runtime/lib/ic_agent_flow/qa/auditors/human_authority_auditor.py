import json
from pathlib import Path
from typing import Dict, List

class HumanAuthorityAuditor:
    """Suite 4: Human Authority QA Auditor.
    Audits HumanReviewPackage quality and Checkpoint decision records.
    """
    
    def __init__(self, workspace_root: str):
        self.root = Path(workspace_root)
        self.closeouts_path = self.root / "artifacts" / "closeouts"
        
    def audit_review_package(self, bundle_id: str) -> Dict:
        """Verifies if a ReviewPackage within a bundle is decision-ready."""
        results = {
            "auditor": "HumanAuthorityAuditor",
            "check": f"review_package_{bundle_id}",
            "verdict": "ACCEPTABLE",
            "findings": []
        }
        
        # Try to find file
        bundle_file = self.closeouts_path / f"bundle_{bundle_id}.json"
        if not bundle_file.exists():
            matching = list(self.closeouts_path.glob(f"*{bundle_id}*"))
            if matching:
                bundle_file = matching[0]
            else:
                results["verdict"] = "INSUFFICIENT_EVIDENCE"
                results["findings"].append(f"Bundle {bundle_id} not found in {self.closeouts_path}.")
                return results
            
        try:
            with open(bundle_file, 'r') as f:
                bundle = json.load(f)
            
            pkg = bundle.get("human_review_package", {})
            if not pkg:
                results["verdict"] = "INSUFFICIENT_EVIDENCE"
                results["findings"].append("No human_review_package found in bundle.")
                return results

            # Check for required decision-readiness criteria
            if not pkg.get("subject_summary"):
                results["findings"].append("Missing subject summary in package.")
                
            risks = pkg.get("open_risks", [])
            if not risks:
                results["findings"].append("Note: No open risks reported in package.")
            else:
                results["findings"].append(f"Found {len(risks)} open risks requiring human attention.")
                
            # Check adjudication state
            adj = bundle.get("adjudication_record", {})
            if adj.get("decision") == "HOLD":
                results["verdict"] = "ACCEPTABLE_WITH_LIMITATIONS"
                results["findings"].append(f"Adjudication is on HOLD: {adj.get('decision_rationale')}")
                    
        except Exception as e:
            results["verdict"] = "LINEAGE_INCOMPLETE"
            results["findings"].append(f"Parse error: {str(e)}")
            
        return results

if __name__ == "__main__":
    auditor = HumanAuthorityAuditor(".")
    print(json.dumps(auditor.audit_review_package("family-1-formal"), indent=2))
