from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List
from uuid import uuid4

from pydantic import BaseModel

from ic_agent_flow.governance.eda_execution_gateway import EDAExecutionGateway, ToolSessionCreateRequest
from ic_agent_flow.governance.openroad_mcp_capability import (
    OpenroadMcpCapabilityBoundary,
    OpenroadMcpCapabilityRequest,
)
from ic_agent_flow.governance.netgen_mcp_capability import (
    NetgenMcpCapabilityBoundary,
    NetgenMcpCapabilityRequest,
)
from ic_agent_flow.governance.yosys_mcp_capability import YosysMcpCapabilityBoundary, YosysMcpCapabilityRequest
from ic_agent_flow.registry.capability_registry import CapabilityEntry, CapabilityFamily, CapabilityRegistry
from ic_agent_flow.registry.scenario_registry import Disposition


class CapabilityContract(BaseModel):
    capability_name: str
    contract_name: str
    contract_version: str
    parser_name: str
    decision_context_ref: str
    tool_family: str = "open_source_eda"


class CapabilityExecutionRecord(BaseModel):
    capability_name: str
    contract_name: str
    contract_version: str
    tool_session_id: str
    raw_artifact_refs: List[str]
    normalized_output_refs: List[str]
    lineage_refs: List[str]
    evidence_bundle_ref: str
    decision_context_ref: str
    gateway_disposition: Disposition
    gateway_reason: str
    raw_log_path: str | None = None
    netlist_path: str | None = None
    normalized_metadata_path: str | None = None
    input_manifest_path: str | None = None
    lineage_path: str | None = None
    evidence_bundle_path: str | None = None
    tool_version: str | None = None


class ValidationVerdict(BaseModel):
    disposition: Disposition
    reason: str


class BatchExecutionResult(BaseModel):
    records: List[CapabilityExecutionRecord]
    aggregate_disposition: Disposition
    aggregate_reason: str


class H2PrepArtifactResult(BaseModel):
    disposition: Disposition
    aggregate_reason: str
    decision_context_ref: str
    artifact_paths: Dict[str, str]


class YosysExecutionSpec(BaseModel):
    workspace_id: str
    chip_id: str
    task_id: str
    decision_context_ref: str
    contract_name: str
    contract_version: str
    rtl_path: str
    top_module: str
    timeout_sec: int = 120
    output_root: str = "artifacts/v0.9/yosys"
    yosys_bin: str = "yosys"
    run_key: str | None = None


class OpenroadExecutionSpec(BaseModel):
    workspace_id: str
    chip_id: str
    task_id: str
    decision_context_ref: str
    contract_name: str
    contract_version: str
    netlist_v_path: str | None = None
    sdc_path: str | None = None
    timeout_sec: int = 120
    output_root: str = "artifacts/v0.9/openroad"
    openroad_bin: str = "openroad"
    run_key: str | None = None


class NetgenExecutionSpec(BaseModel):
    workspace_id: str
    chip_id: str
    task_id: str
    decision_context_ref: str
    contract_name: str
    contract_version: str
    source_a_path: str
    source_a_top: str
    source_b_path: str
    source_b_top: str
    setup_file: str | None = None
    timeout_sec: int = 120
    output_root: str = "artifacts/v0.9/netgen"
    netgen_bin: str = "netgen"
    run_key: str | None = None


class YosysExecutionResult(BaseModel):
    disposition: Disposition
    reason: str
    record: CapabilityExecutionRecord
    raw_log_path: str | None = None
    netlist_path: str | None = None
    normalized_metadata_path: str | None = None
    input_manifest_path: str | None = None
    lineage_path: str | None = None
    evidence_bundle_path: str | None = None
    boundary_mode: str | None = None
    contract_id: str | None = None


class OpenroadExecutionResult(BaseModel):
    disposition: Disposition
    reason: str
    record: CapabilityExecutionRecord
    raw_log_path: str | None = None
    normalized_metadata_path: str | None = None
    input_manifest_path: str | None = None
    lineage_path: str | None = None
    evidence_bundle_path: str | None = None
    boundary_mode: str | None = None
    contract_id: str | None = None


class NetgenExecutionResult(BaseModel):
    disposition: Disposition
    reason: str
    record: CapabilityExecutionRecord
    raw_log_path: str | None = None
    lvs_report_path: str | None = None
    normalized_metadata_path: str | None = None
    input_manifest_path: str | None = None
    lineage_path: str | None = None
    evidence_bundle_path: str | None = None
    boundary_mode: str | None = None
    contract_id: str | None = None


class CapabilityE2EValidator:
    """
    AC validator for minimal MCP capability path:
    contract -> raw/normalized/lineage -> evidence binding -> decision-loop attach
    """

    def validate(self, record: CapabilityExecutionRecord) -> ValidationVerdict:
        if not record.contract_name or not record.contract_version:
            return ValidationVerdict(
                disposition=Disposition.FAIL_CLOSED,
                reason="capability contract missing",
            )

        if not record.raw_artifact_refs or not record.normalized_output_refs or not record.lineage_refs:
            return ValidationVerdict(
                disposition=Disposition.FAIL_CLOSED,
                reason="traceability chain incomplete (raw/normalized/lineage)",
            )

        if not record.decision_context_ref.startswith("decision://"):
            return ValidationVerdict(
                disposition=Disposition.FAIL_CLOSED,
                reason="decision loop attach invalid",
            )

        if not record.evidence_bundle_ref.startswith("evidence_bundle://"):
            return ValidationVerdict(
                disposition=Disposition.FAIL_CLOSED,
                reason="evidence bundle ref invalid",
            )

        if record.gateway_disposition != Disposition.PASS:
            return ValidationVerdict(
                disposition=Disposition.FAIL_CLOSED,
                reason=f"gateway rejected flow: {record.gateway_reason}",
            )

        return ValidationVerdict(disposition=Disposition.PASS, reason="minimal e2e flow validated")


class YosysSingleCapValidator:
    """
    Validator for H1 real-yosys single-cap closeout:
    runtime execution + schema + traceability + replay-minimum fields.
    """

    @staticmethod
    def _exists(path: str | None) -> bool:
        return bool(path) and Path(path).exists()

    @staticmethod
    def _load_json(path: str) -> dict:
        return json.loads(Path(path).read_text(encoding="utf-8"))

    def validate(self, result: YosysExecutionResult) -> ValidationVerdict:
        if result.disposition != Disposition.PASS or result.record.gateway_disposition != Disposition.PASS:
            return ValidationVerdict(disposition=Disposition.FAIL_CLOSED, reason=f"runtime_failed:{result.reason}")

        for required in [
            result.raw_log_path,
            result.netlist_path,
            result.normalized_metadata_path,
            result.input_manifest_path,
            result.lineage_path,
            result.evidence_bundle_path,
        ]:
            if not self._exists(required):
                return ValidationVerdict(
                    disposition=Disposition.FAIL_CLOSED,
                    reason="artifact_missing:required_path_not_found",
                )

        normalized = self._load_json(result.normalized_metadata_path or "")
        lineage = self._load_json(result.lineage_path or "")
        manifest = self._load_json(result.input_manifest_path or "")

        if not normalized.get("tool_version"):
            return ValidationVerdict(disposition=Disposition.FAIL_CLOSED, reason="schema_invalid:missing_tool_version")
        if not normalized.get("output_refs"):
            return ValidationVerdict(disposition=Disposition.FAIL_CLOSED, reason="schema_invalid:missing_output_refs")
        if lineage.get("decision_context_ref") != result.record.decision_context_ref:
            return ValidationVerdict(
                disposition=Disposition.FAIL_CLOSED,
                reason="traceability_invalid:decision_context_mismatch",
            )
        for replay_field in [
            "run_id",
            "started_at",
            "finished_at",
            "exit_code",
            "duration_ms",
            "command_argv",
            "working_dir",
            "input_manifest_ref",
            "session_id",
            "task_id",
            "workspace_id",
            "chip_id",
        ]:
            if replay_field not in lineage:
                return ValidationVerdict(
                    disposition=Disposition.FAIL_CLOSED,
                    reason=f"replay_minimum_missing:{replay_field}",
                )
        if "rtl_inputs" not in manifest or not manifest["rtl_inputs"]:
            return ValidationVerdict(disposition=Disposition.FAIL_CLOSED, reason="manifest_invalid:rtl_inputs_missing")
        return ValidationVerdict(disposition=Disposition.PASS, reason="real yosys single-cap validated")


class OpenroadSingleCapValidator:
    """
    Validator for H2 real-openroad single-cap closeout.
    """

    @staticmethod
    def _exists(path: str | None) -> bool:
        return bool(path) and Path(path).exists()

    @staticmethod
    def _load_json(path: str) -> dict:
        return json.loads(Path(path).read_text(encoding="utf-8"))

    def validate(self, result: OpenroadExecutionResult) -> ValidationVerdict:
        if result.disposition != Disposition.PASS or result.record.gateway_disposition != Disposition.PASS:
            return ValidationVerdict(disposition=Disposition.FAIL_CLOSED, reason=f"runtime_failed:{result.reason}")

        for required in [
            result.raw_log_path,
            result.normalized_metadata_path,
            result.input_manifest_path,
            result.lineage_path,
            result.evidence_bundle_path,
        ]:
            if not self._exists(required):
                return ValidationVerdict(
                    disposition=Disposition.FAIL_CLOSED,
                    reason="artifact_missing:required_path_not_found",
                )

        normalized = self._load_json(result.normalized_metadata_path or "")
        lineage = self._load_json(result.lineage_path or "")
        manifest = self._load_json(result.input_manifest_path or "")

        if normalized.get("tool") != "openroad":
            return ValidationVerdict(disposition=Disposition.FAIL_CLOSED, reason="schema_invalid:tool_not_openroad")
        if not normalized.get("tool_version"):
            return ValidationVerdict(disposition=Disposition.FAIL_CLOSED, reason="schema_invalid:missing_tool_version")
        if lineage.get("decision_context_ref") != result.record.decision_context_ref:
            return ValidationVerdict(
                disposition=Disposition.FAIL_CLOSED,
                reason="traceability_invalid:decision_context_mismatch",
            )
        if manifest.get("tool") != "openroad":
            return ValidationVerdict(disposition=Disposition.FAIL_CLOSED, reason="manifest_invalid:tool_not_openroad")
        return ValidationVerdict(disposition=Disposition.PASS, reason="real openroad single-cap validated")


class NetgenSingleCapValidator:
    """
    Validator for H3 real-netgen single-cap closeout.
    """

    @staticmethod
    def _exists(path: str | None) -> bool:
        return bool(path) and Path(path).exists()

    @staticmethod
    def _load_json(path: str) -> dict:
        return json.loads(Path(path).read_text(encoding="utf-8"))

    def validate(self, result: NetgenExecutionResult) -> ValidationVerdict:
        if result.disposition != Disposition.PASS or result.record.gateway_disposition != Disposition.PASS:
            return ValidationVerdict(disposition=Disposition.FAIL_CLOSED, reason=f"runtime_failed:{result.reason}")

        for required in [
            result.raw_log_path,
            result.lvs_report_path,
            result.normalized_metadata_path,
            result.input_manifest_path,
            result.lineage_path,
            result.evidence_bundle_path,
        ]:
            if not self._exists(required):
                return ValidationVerdict(
                    disposition=Disposition.FAIL_CLOSED,
                    reason="artifact_missing:required_path_not_found",
                )

        normalized = self._load_json(result.normalized_metadata_path or "")
        if normalized.get("tool") != "netgen":
            return ValidationVerdict(disposition=Disposition.FAIL_CLOSED, reason="schema_invalid:tool_not_netgen")
        if normalized.get("status") not in ["PASS", "PASS_WITH_WARNINGS", "FAIL"]:
            return ValidationVerdict(disposition=Disposition.FAIL_CLOSED, reason="schema_invalid:invalid_lvs_status")
        
        return ValidationVerdict(disposition=Disposition.PASS, reason="real netgen single-cap validated")


class MultiCapabilityE2EValidator:
    """
    Aggregate validator for multi-capability integration on one governed case.
    Ensures each capability path is valid and all paths bind to one decision context.
    """

    def __init__(self) -> None:
        self._single = CapabilityE2EValidator()

    def validate(self, records: List[CapabilityExecutionRecord]) -> ValidationVerdict:
        if not records:
            return ValidationVerdict(
                disposition=Disposition.FAIL_CLOSED,
                reason="no capability execution records",
            )

        for record in records:
            verdict = self._single.validate(record)
            if verdict.disposition != Disposition.PASS:
                return verdict

        context_set = {r.decision_context_ref for r in records}
        if len(context_set) != 1:
            return ValidationVerdict(
                disposition=Disposition.FAIL_CLOSED,
                reason="parallel decision contexts detected across capabilities",
            )

        return ValidationVerdict(
            disposition=Disposition.PASS,
            reason="multi-capability e2e validated with single decision context",
        )


class OpenSourceEDAMinimalE2EFlow:
    def __init__(self, gateway: EDAExecutionGateway, registry: CapabilityRegistry) -> None:
        self.gateway = gateway
        self.registry = registry
        self._profiles: Dict[str, CapabilityContract] = {}

    def register_profile(self, profile_name: str, contract: CapabilityContract) -> None:
        self._profiles[profile_name] = contract

    @staticmethod
    def _sha256_file(path: Path) -> str:
        h = hashlib.sha256()
        with path.open("rb") as f:
            while True:
                chunk = f.read(8192)
                if not chunk:
                    break
                h.update(chunk)
        return h.hexdigest()

    def register_default_profiles(self, shared_decision_context_ref: str) -> None:
        self.register_profile(
            "yosys_synth_compile",
            CapabilityContract(
                capability_name="yosys_synth_compile",
                contract_name="yosys_synth_contract",
                contract_version="v0.1",
                parser_name="yosys_parser",
                decision_context_ref=shared_decision_context_ref,
            ),
        )
        self.register_profile(
            "openroad_drc",
            CapabilityContract(
                capability_name="openroad_drc",
                contract_name="openroad_drc_contract",
                contract_version="v0.1",
                parser_name="drc_parser",
                decision_context_ref=shared_decision_context_ref,
            ),
        )
        self.register_profile(
            "netgen_lvs",
            CapabilityContract(
                capability_name="netgen_lvs",
                contract_name="netgen_lvs_contract",
                contract_version="v0.1",
                parser_name="lvs_parser",
                decision_context_ref=shared_decision_context_ref,
            ),
        )

    def register_contract(self, contract: CapabilityContract) -> None:
        self.registry.register(
            CapabilityEntry(
                name=contract.capability_name,
                version=contract.contract_version,
                family=CapabilityFamily.MCP_CAPABILITY,
                contract_id=f"{contract.contract_name}@{contract.contract_version}",
                metadata={
                    "parser_name": contract.parser_name,
                    "tool_family": contract.tool_family,
                    "decision_context_ref": contract.decision_context_ref,
                },
            )
        )

    @staticmethod
    def build_record(
        capability_name: str,
        contract_name: str,
        contract_version: str,
        tool_session_id: str,
        raw_artifact_refs: List[str],
        normalized_output_refs: List[str],
        lineage_refs: List[str],
        evidence_bundle_ref: str,
        decision_context_ref: str,
        gateway_disposition: Disposition,
        gateway_reason: str,
    ) -> CapabilityExecutionRecord:
        return CapabilityExecutionRecord(
            capability_name=capability_name,
            contract_name=contract_name,
            contract_version=contract_version,
            tool_session_id=tool_session_id,
            raw_artifact_refs=raw_artifact_refs,
            normalized_output_refs=normalized_output_refs,
            lineage_refs=lineage_refs,
            evidence_bundle_ref=evidence_bundle_ref,
            decision_context_ref=decision_context_ref,
            gateway_disposition=gateway_disposition,
            gateway_reason=gateway_reason,
        )

    def execute(
        self,
        contract: CapabilityContract,
        workspace_id: str,
        chip_id: str,
        subject_refs: List[str],
        task_id: str,
        raw_artifact_refs: List[str],
        normalized_output_refs: List[str],
        lineage_refs: List[str],
    ) -> CapabilityExecutionRecord:
        self.register_contract(contract)

        session = self.gateway.create_session(
            ToolSessionCreateRequest(
                workspace_id=workspace_id,
                chip_id=chip_id,
                subject_refs=subject_refs,
                decision_context_ref=contract.decision_context_ref,
                task_id=task_id,
                tool_family=contract.tool_family,
                contract_name=contract.contract_name,
                contract_version=contract.contract_version,
            )
        )
        session_id = str(session.tool_session_id)

        self.gateway.attach_execution_run(session_id, f"run://{contract.capability_name}/1")

        bind_verdict = self.gateway.bind_artifacts(
            session_id,
            raw_artifact_refs=raw_artifact_refs,
            normalized_output_refs=normalized_output_refs,
            lineage_refs=lineage_refs,
        )

        decision_verdict = self.gateway.bind_decision_context(session_id, contract.decision_context_ref)

        final_disposition = Disposition.PASS
        final_reason = "artifact continuity + decision loop attach pass"
        if bind_verdict.disposition != Disposition.PASS:
            final_disposition = bind_verdict.disposition
            final_reason = bind_verdict.reason
        elif decision_verdict.disposition != Disposition.PASS:
            final_disposition = decision_verdict.disposition
            final_reason = decision_verdict.reason

        return self.build_record(
            capability_name=contract.capability_name,
            contract_name=contract.contract_name,
            contract_version=contract.contract_version,
            tool_session_id=session_id,
            raw_artifact_refs=raw_artifact_refs,
            normalized_output_refs=normalized_output_refs,
            lineage_refs=lineage_refs,
            evidence_bundle_ref=f"evidence_bundle://{session_id}",
            decision_context_ref=contract.decision_context_ref,
            gateway_disposition=final_disposition,
            gateway_reason=final_reason,
        )

    def execute_with_profile(
        self,
        profile_name: str,
        workspace_id: str,
        chip_id: str,
        subject_refs: List[str],
        task_id: str,
        raw_artifact_refs: List[str],
        normalized_output_refs: List[str],
        lineage_refs: List[str],
    ) -> CapabilityExecutionRecord:
        if profile_name not in self._profiles:
            raise ValueError(f"unregistered profile: {profile_name}")

        return self.execute(
            contract=self._profiles[profile_name],
            workspace_id=workspace_id,
            chip_id=chip_id,
            subject_refs=subject_refs,
            task_id=task_id,
            raw_artifact_refs=raw_artifact_refs,
            normalized_output_refs=normalized_output_refs,
            lineage_refs=lineage_refs,
        )

    def execute_batch(
        self,
        profile_names: List[str],
        workspace_id: str,
        chip_id: str,
        subject_refs: List[str],
        task_id_prefix: str,
        input_by_profile: Dict[str, Dict[str, List[str]]],
    ) -> BatchExecutionResult:
        records: List[CapabilityExecutionRecord] = []
        for idx, profile_name in enumerate(profile_names, start=1):
            payload = input_by_profile.get(profile_name, {})
            record = self.execute_with_profile(
                profile_name=profile_name,
                workspace_id=workspace_id,
                chip_id=chip_id,
                subject_refs=subject_refs,
                task_id=f"{task_id_prefix}-{idx}",
                raw_artifact_refs=payload.get("raw_artifact_refs", []),
                normalized_output_refs=payload.get("normalized_output_refs", []),
                lineage_refs=payload.get("lineage_refs", []),
            )
            records.append(record)

        aggregate = MultiCapabilityE2EValidator().validate(records)
        return BatchExecutionResult(
            records=records,
            aggregate_disposition=aggregate.disposition,
            aggregate_reason=aggregate.reason,
        )

    def _failed_yosys_result(self, spec: YosysExecutionSpec, reason: str) -> YosysExecutionResult:
        return YosysExecutionResult(
            disposition=Disposition.FAIL_CLOSED,
            reason=reason,
            record=self.build_record(
                capability_name="yosys_synth_compile",
                contract_name=spec.contract_name,
                contract_version=spec.contract_version,
                tool_session_id="",
                raw_artifact_refs=[],
                normalized_output_refs=[],
                lineage_refs=[],
                evidence_bundle_ref="",
                decision_context_ref=spec.decision_context_ref,
                gateway_disposition=Disposition.FAIL_CLOSED,
                gateway_reason=reason,
            ),
        )

    def _failed_openroad_result(self, spec: OpenroadExecutionSpec, reason: str) -> OpenroadExecutionResult:
        return OpenroadExecutionResult(
            disposition=Disposition.FAIL_CLOSED,
            reason=reason,
            record=self.build_record(
                capability_name="openroad_drc",
                contract_name=spec.contract_name,
                contract_version=spec.contract_version,
                tool_session_id="",
                raw_artifact_refs=[],
                normalized_output_refs=[],
                lineage_refs=[],
                evidence_bundle_ref="",
                decision_context_ref=spec.decision_context_ref,
                gateway_disposition=Disposition.FAIL_CLOSED,
                gateway_reason=reason,
            ),
        )

    def _failed_netgen_result(self, spec: NetgenExecutionSpec, reason: str) -> NetgenExecutionResult:
        return NetgenExecutionResult(
            disposition=Disposition.FAIL_CLOSED,
            reason=reason,
            record=self.build_record(
                capability_name="netgen_lvs",
                contract_name=spec.contract_name,
                contract_version=spec.contract_version,
                tool_session_id="",
                raw_artifact_refs=[],
                normalized_output_refs=[],
                lineage_refs=[],
                evidence_bundle_ref="",
                decision_context_ref=spec.decision_context_ref,
                gateway_disposition=Disposition.FAIL_CLOSED,
                gateway_reason=reason,
            ),
        )

    def execute_real_netgen_single_cap(self, spec: NetgenExecutionSpec) -> NetgenExecutionResult:
        boundary = NetgenMcpCapabilityBoundary()
        boundary_resp = boundary.execute(
            NetgenMcpCapabilityRequest(
                workspace_id=spec.workspace_id,
                chip_id=spec.chip_id,
                task_id=spec.task_id,
                decision_context_ref=spec.decision_context_ref,
                contract_name=spec.contract_name,
                contract_version=spec.contract_version,
                source_a_path=spec.source_a_path,
                source_a_top=spec.source_a_top,
                source_b_path=spec.source_b_path,
                source_b_top=spec.source_b_top,
                setup_file=spec.setup_file,
                timeout_sec=spec.timeout_sec,
                output_root=spec.output_root,
                netgen_bin=spec.netgen_bin,
                run_key=spec.run_key,
            )
        )
        if boundary_resp.disposition != Disposition.PASS or not boundary_resp.run_id:
            return self._failed_netgen_result(spec, boundary_resp.reason)

        contract = CapabilityContract(
            capability_name="netgen_lvs",
            contract_name=spec.contract_name,
            contract_version=spec.contract_version,
            parser_name="lvs_parser",
            decision_context_ref=spec.decision_context_ref,
            tool_family="open_source_eda",
        )
        record = self.execute(
            contract=contract,
            workspace_id=spec.workspace_id,
            chip_id=spec.chip_id,
            subject_refs=[
                f"netlist://{Path(spec.source_a_path).as_posix()}",
                f"netlist://{Path(spec.source_b_path).as_posix()}",
            ],
            task_id=spec.task_id,
            raw_artifact_refs=[boundary_resp.artifact_refs["raw_log_ref"]],
            normalized_output_refs=[boundary_resp.artifact_refs["normalized_ref"]],
            lineage_refs=[boundary_resp.artifact_refs["lineage_ref"]],
        )
        record.raw_log_path = boundary_resp.artifact_paths["raw_log"]
        record.normalized_metadata_path = boundary_resp.artifact_paths["normalized_metadata"]
        record.input_manifest_path = boundary_resp.artifact_paths["input_manifest"]
        record.lineage_path = boundary_resp.artifact_paths["lineage"]
        record.evidence_bundle_path = boundary_resp.artifact_paths["evidence_bundle"]
        record.tool_version = boundary_resp.tool_version
        record.evidence_bundle_ref = boundary_resp.artifact_refs["evidence_bundle_ref"]

        lineage_path = Path(record.lineage_path)
        lineage = json.loads(lineage_path.read_text(encoding="utf-8"))
        lineage["session_id"] = record.tool_session_id
        lineage_path.write_text(json.dumps(lineage, indent=2), encoding="utf-8")

        return NetgenExecutionResult(
            disposition=record.gateway_disposition,
            reason=record.gateway_reason,
            record=record,
            raw_log_path=record.raw_log_path,
            lvs_report_path=boundary_resp.artifact_paths["lvs_report"],
            normalized_metadata_path=record.normalized_metadata_path,
            input_manifest_path=record.input_manifest_path,
            lineage_path=record.lineage_path,
            evidence_bundle_path=record.evidence_bundle_path,
            boundary_mode=boundary_resp.boundary_mode,
            contract_id=boundary_resp.contract_id,
        )

    def execute_real_yosys_single_cap(self, spec: YosysExecutionSpec) -> YosysExecutionResult:
        boundary = YosysMcpCapabilityBoundary()
        boundary_resp = boundary.execute(
            YosysMcpCapabilityRequest(
                workspace_id=spec.workspace_id,
                chip_id=spec.chip_id,
                task_id=spec.task_id,
                decision_context_ref=spec.decision_context_ref,
                contract_name=spec.contract_name,
                contract_version=spec.contract_version,
                rtl_path=spec.rtl_path,
                top_module=spec.top_module,
                timeout_sec=spec.timeout_sec,
                output_root=spec.output_root,
                yosys_bin=spec.yosys_bin,
                run_key=spec.run_key,
            )
        )
        if boundary_resp.disposition != Disposition.PASS or not boundary_resp.run_id:
            return self._failed_yosys_result(spec, boundary_resp.reason)

        contract = CapabilityContract(
            capability_name="yosys_synth_compile",
            contract_name=spec.contract_name,
            contract_version=spec.contract_version,
            parser_name="yosys_parser",
            decision_context_ref=spec.decision_context_ref,
            tool_family="open_source_eda",
        )
        record = self.execute(
            contract=contract,
            workspace_id=spec.workspace_id,
            chip_id=spec.chip_id,
            subject_refs=[f"rtl://{Path(spec.rtl_path).as_posix()}"],
            task_id=spec.task_id,
            raw_artifact_refs=[boundary_resp.artifact_refs["raw_log_ref"]],
            normalized_output_refs=[boundary_resp.artifact_refs["normalized_ref"]],
            lineage_refs=[boundary_resp.artifact_refs["lineage_ref"]],
        )
        record.raw_log_path = boundary_resp.artifact_paths["raw_log"]
        record.netlist_path = boundary_resp.artifact_paths["netlist"]
        record.normalized_metadata_path = boundary_resp.artifact_paths["normalized_metadata"]
        record.input_manifest_path = boundary_resp.artifact_paths["input_manifest"]
        record.lineage_path = boundary_resp.artifact_paths["lineage"]
        record.evidence_bundle_path = boundary_resp.artifact_paths["evidence_bundle"]
        record.tool_version = boundary_resp.tool_version
        record.evidence_bundle_ref = boundary_resp.artifact_refs["evidence_bundle_ref"]

        # Write session id back to lineage for replay completeness.
        lineage_path = Path(record.lineage_path)
        lineage = json.loads(lineage_path.read_text(encoding="utf-8"))
        lineage["session_id"] = record.tool_session_id
        lineage_path.write_text(json.dumps(lineage, indent=2), encoding="utf-8")

        return YosysExecutionResult(
            disposition=record.gateway_disposition,
            reason=record.gateway_reason,
            record=record,
            raw_log_path=record.raw_log_path,
            netlist_path=record.netlist_path,
            normalized_metadata_path=record.normalized_metadata_path,
            input_manifest_path=record.input_manifest_path,
            lineage_path=record.lineage_path,
            evidence_bundle_path=record.evidence_bundle_path,
            boundary_mode=boundary_resp.boundary_mode,
            contract_id=boundary_resp.contract_id,
        )

    def execute_real_openroad_single_cap(self, spec: OpenroadExecutionSpec) -> OpenroadExecutionResult:
        boundary = OpenroadMcpCapabilityBoundary()
        boundary_resp = boundary.execute(
            OpenroadMcpCapabilityRequest(
                workspace_id=spec.workspace_id,
                chip_id=spec.chip_id,
                task_id=spec.task_id,
                decision_context_ref=spec.decision_context_ref,
                contract_name=spec.contract_name,
                contract_version=spec.contract_version,
                netlist_v_path=spec.netlist_v_path,
                sdc_path=spec.sdc_path,
                timeout_sec=spec.timeout_sec,
                output_root=spec.output_root,
                openroad_bin=spec.openroad_bin,
                run_key=spec.run_key,
            )
        )
        if boundary_resp.disposition != Disposition.PASS or not boundary_resp.run_id:
            return self._failed_openroad_result(spec, boundary_resp.reason)

        contract = CapabilityContract(
            capability_name="openroad_drc",
            contract_name=spec.contract_name,
            contract_version=spec.contract_version,
            parser_name="drc_parser",
            decision_context_ref=spec.decision_context_ref,
            tool_family="open_source_eda",
        )
        subject_refs = ["layout://minimal-openroad-probe"]
        if spec.netlist_v_path:
            subject_refs = [f"netlist://{Path(spec.netlist_v_path).as_posix()}"]

        record = self.execute(
            contract=contract,
            workspace_id=spec.workspace_id,
            chip_id=spec.chip_id,
            subject_refs=subject_refs,
            task_id=spec.task_id,
            raw_artifact_refs=[boundary_resp.artifact_refs["raw_log_ref"]],
            normalized_output_refs=[boundary_resp.artifact_refs["normalized_ref"]],
            lineage_refs=[boundary_resp.artifact_refs["lineage_ref"]],
        )
        record.raw_log_path = boundary_resp.artifact_paths["raw_log"]
        record.normalized_metadata_path = boundary_resp.artifact_paths["normalized_metadata"]
        record.input_manifest_path = boundary_resp.artifact_paths["input_manifest"]
        record.lineage_path = boundary_resp.artifact_paths["lineage"]
        record.evidence_bundle_path = boundary_resp.artifact_paths["evidence_bundle"]
        record.tool_version = boundary_resp.tool_version
        record.evidence_bundle_ref = boundary_resp.artifact_refs["evidence_bundle_ref"]

        lineage_path = Path(record.lineage_path)
        lineage = json.loads(lineage_path.read_text(encoding="utf-8"))
        lineage["session_id"] = record.tool_session_id
        lineage_path.write_text(json.dumps(lineage, indent=2), encoding="utf-8")

        return OpenroadExecutionResult(
            disposition=record.gateway_disposition,
            reason=record.gateway_reason,
            record=record,
            raw_log_path=record.raw_log_path,
            normalized_metadata_path=record.normalized_metadata_path,
            input_manifest_path=record.input_manifest_path,
            lineage_path=record.lineage_path,
            evidence_bundle_path=record.evidence_bundle_path,
            boundary_mode=boundary_resp.boundary_mode,
            contract_id=boundary_resp.contract_id,
        )


def build_h2_prep_artifacts(output_dir: str | Path) -> H2PrepArtifactResult:
    """
    H2-prep bundle (no real OpenROAD execution yet):
    1) capability contracts
    2) raw/normalized/evidence schema baseline
    3) AC/validator closeout binding
    4) decision-loop attach report (single-context truth guard)
    """
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    flow = OpenSourceEDAMinimalE2EFlow(gateway=EDAExecutionGateway(), registry=CapabilityRegistry())
    decision_context_ref = "decision://ctx-h2-prep"
    flow.register_default_profiles(shared_decision_context_ref=decision_context_ref)

    batch = flow.execute_batch(
        profile_names=["yosys_synth_compile", "openroad_drc", "netgen_lvs"],
        workspace_id="ws-h2-prep",
        chip_id="chip-h2-prep",
        subject_refs=["subject://top"],
        task_id_prefix="task://h2-prep",
        input_by_profile={
            "yosys_synth_compile": {
                "raw_artifact_refs": ["artifact://yosys/raw/h2-prep-1"],
                "normalized_output_refs": ["norm://yosys/netlist-h2-prep-1"],
                "lineage_refs": ["lineage://yosys/h2-prep-1"],
            },
            "openroad_drc": {
                "raw_artifact_refs": ["artifact://openroad/drc/raw-h2-prep-1"],
                "normalized_output_refs": ["norm://openroad/drc-h2-prep-1"],
                "lineage_refs": ["lineage://openroad/drc-h2-prep-1"],
            },
            "netgen_lvs": {
                "raw_artifact_refs": ["artifact://netgen/lvs/raw-h2-prep-1"],
                "normalized_output_refs": ["norm://netgen/lvs-h2-prep-1"],
                "lineage_refs": ["lineage://netgen/lvs-h2-prep-1"],
            },
        },
    )

    contracts_path = out / "mcp_h2_capability_contracts.v0.2.json"
    schema_path = out / "mcp_h2_evidence_schema.v0.2.json"
    ac_binding_path = out / "mcp_h2_ac_validator_binding.v0.2.json"
    report_path = out / "phase6_mcp_multi_cap_batch_report.v0.2.md"

    contracts_path.write_text(
        json.dumps(
            {
                "artifact_id": "mcp-h2-capability-contracts-v0.2",
                "decision_context_ref": decision_context_ref,
                "contracts": [
                    {
                        "capability_name": "yosys_synth_compile",
                        "contract_id": "yosys_synth_contract@v0.1",
                        "parser_name": "yosys_parser",
                        "validator_ref": "CapabilityE2EValidator",
                    },
                    {
                        "capability_name": "openroad_drc",
                        "contract_id": "openroad_drc_contract@v0.1",
                        "parser_name": "drc_parser",
                        "validator_ref": "CapabilityE2EValidator",
                    },
                    {
                        "capability_name": "netgen_lvs",
                        "contract_id": "netgen_lvs_contract@v0.1",
                        "parser_name": "lvs_parser",
                        "validator_ref": "CapabilityE2EValidator",
                    },
                ],
            },
            indent=2,
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )

    schema_path.write_text(
        json.dumps(
            {
                "artifact_id": "mcp-h2-evidence-schema-v0.2",
                "record_schema_version": "v0.2",
                "required_record_fields": [
                    "capability_name",
                    "contract_name",
                    "contract_version",
                    "tool_session_id",
                    "raw_artifact_refs",
                    "normalized_output_refs",
                    "lineage_refs",
                    "evidence_bundle_ref",
                    "decision_context_ref",
                    "gateway_disposition",
                    "gateway_reason",
                ],
                "decision_loop_rule": "all capability records must share one decision_context_ref",
                "summary_policy": "summary-only evidence forbidden; raw/normalized/evidence refs required",
            },
            indent=2,
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )

    ac_binding_path.write_text(
        json.dumps(
            {
                "artifact_id": "mcp-h2-ac-validator-binding-v0.2",
                "command_id": "CMD-H2-MCP-MULTI-CAP-BATCH",
                "ac_mapping": {
                    "AC2": "raw/normalized/lineage chain completeness",
                    "AC3": "capability contract + parser legality",
                    "AC4": "decision-loop attach remains single-truth",
                },
                "validator": {
                    "single_record": "CapabilityE2EValidator",
                    "verdict_source": "MultiCapabilityE2EValidator",
                    "failure_disposition_default": "FAIL_CLOSED",
                },
                "closeout_binding": {
                    "report_path": "workspace/docs/governance/closeout/v0.9/phase6_mcp_multi_cap_batch_report.v0.2.md",
                    "contracts_path": "workspace/docs/governance/closeout/v0.9/mcp_h2_capability_contracts.v0.2.json",
                    "schema_path": "workspace/docs/governance/closeout/v0.9/mcp_h2_evidence_schema.v0.2.json",
                },
            },
            indent=2,
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )

    # H3 Netgen LVS Prep Report (Stub)
    h3_report_path = out / "phase6_netgen_lvs_report.v0.1.md"
    h3_report_path.write_text(
        "# Phase 6 Netgen LVS Real-Run Report v0.1\n\n"
        "- Command ID: `CMD-H3-NETGEN-LVS-E2E`\n"
        "- Status: HOLD\n"
        "- Reason: real-run evidence pending\n",
        encoding="utf-8",
    )

    report_path.write_text(
        "\n".join(
            [
                "# v0.9 Phase H2 MCP Multi-Capability Batch Report v0.2",
                "",
                "- command_id: `CMD-H2-MCP-MULTI-CAP-BATCH`",
                "- mode: `H2-prep` (contract/schema/validator/decision-loop attach)",
                f"- decision_context_ref: `{decision_context_ref}`",
                f"- aggregate_disposition: `{batch.aggregate_disposition.value}`",
                f"- aggregate_reason: `{batch.aggregate_reason}`",
                "",
                "## Capability Contracts",
                "- `yosys_synth_contract@v0.1`",
                "- `openroad_drc_contract@v0.1`",
                "- `netgen_lvs_contract@v0.1`",
                "",
                "## Validator Binding",
                "- single-record: `CapabilityE2EValidator`",
                "- aggregate verdict source: `MultiCapabilityE2EValidator`",
                "- default failure disposition: `FAIL_CLOSED`",
                "",
                "## Evidence",
                f"- `{contracts_path.as_posix()}`",
                f"- `{schema_path.as_posix()}`",
                f"- `{ac_binding_path.as_posix()}`",
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    return H2PrepArtifactResult(
        disposition=batch.aggregate_disposition,
        aggregate_reason=batch.aggregate_reason,
        decision_context_ref=decision_context_ref,
        artifact_paths={
            "contracts": contracts_path.as_posix(),
            "schema": schema_path.as_posix(),
            "ac_binding": ac_binding_path.as_posix(),
            "report": report_path.as_posix(),
            "h3_report": h3_report_path.as_posix(),
        },
    )
