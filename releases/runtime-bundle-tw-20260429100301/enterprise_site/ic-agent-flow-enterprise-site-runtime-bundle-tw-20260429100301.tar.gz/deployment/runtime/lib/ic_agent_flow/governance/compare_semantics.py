class CompareSemanticsContract:
    @staticmethod
    def validate_compare_request(source_a: str, source_b: str, mode: str):
        """
        強制執行 Law 4: Compare-Class Stages 必須宣告主體語義
        """
        if source_a == source_b and mode != "SELF_CHECK":
            raise ValueError("ERR_INTEGRITY_DRIFT: Duplicate compare source invalid without SELF_CHECK mode.")
        
        return {
            "source_role_a": "REFERENCE_NETLIST",
            "source_role_b": "IMPLEMENTED_NETLIST",
            "compare_mode": mode,
            "status": "SEMANTICS_VALIDATED"
        }
