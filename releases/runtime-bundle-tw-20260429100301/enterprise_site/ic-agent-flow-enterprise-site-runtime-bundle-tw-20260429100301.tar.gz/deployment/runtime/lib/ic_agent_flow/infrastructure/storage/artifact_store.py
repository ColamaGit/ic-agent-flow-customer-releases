import os
import shutil
from typing import List, Optional

class ArtifactStore:
    """
    Tiered Storage - Layer 2: Artifact Store
    Handles raw, unstructured outputs (logs, reports, netlists).
    """
    
    def __init__(self, base_path: str = "artifacts/storage/artifacts"):
        self.base_path = base_path
        os.makedirs(self.base_path, exist_ok=True)

    def put_artifact(self, artifact_name: str, source_path: str, classification: str = "Internal"):
        """Move or copy a raw file to the artifact store."""
        class_dir = os.path.join(self.base_path, classification.replace(" ", "_"))
        os.makedirs(class_dir, exist_ok=True)
        
        target_path = os.path.join(class_dir, artifact_name)
        
        # In a real system, we might move (shutil.move) or upload to S3.
        # Here we copy to keep the local workspace clean.
        shutil.copy2(source_path, target_path)
            
        return target_path

    def list_artifacts(self, classification: Optional[str] = None) -> List[str]:
        """List all stored artifacts, optionally filtered by classification."""
        if classification:
            target_dir = os.path.join(self.base_path, classification.replace(" ", "_"))
            if not os.path.exists(target_dir): return []
            return os.listdir(target_dir)
            
        all_artifacts = []
        for root, dirs, files in os.walk(self.base_path):
            all_artifacts.extend(files)
        return all_artifacts
