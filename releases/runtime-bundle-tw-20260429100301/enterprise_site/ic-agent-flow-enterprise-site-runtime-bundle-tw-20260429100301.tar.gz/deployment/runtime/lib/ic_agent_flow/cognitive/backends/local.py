"""
Local Mock Backend Driver (Step 4 — Land one local backend driver)
===================================================================
Provides a deterministic, zero-dependency local backend for:
- fail-closed baseline testing
- offline development
- unit testing without API calls

This backend NEVER makes external network calls.
"""
from __future__ import annotations

import time

from ic_agent_flow.cognitive.schemas import (
    BackendProvider,
    CognitiveRequest,
    CognitiveResponse,
    ResponseType,
)


class LocalMockBackend:
    """
    Local mock backend driver.
    Returns deterministic responses based on task_type for testing.
    Satisfies Law 4 (audit trail) by populating all envelope fields.
    """

    PROVIDER = BackendProvider.LOCAL_MOCK
    MODEL_ID = "local-mock-v0.1"

    def invoke(self, request: CognitiveRequest) -> CognitiveResponse:
        """Invoke the local mock backend. Always succeeds unless explicitly configured to fail."""
        start = time.monotonic()

        content = self._generate_response(request)

        latency = (time.monotonic() - start) * 1000

        return CognitiveResponse(
            request_id=request.request_id,
            response_type=ResponseType.TEXT,
            content=content,
            provider=self.PROVIDER,
            model_id=self.MODEL_ID,
            usage_input_tokens=len(request.prompt.split()),
            usage_output_tokens=len(content.split()),
            raw_metadata={"latency_ms": round(latency, 2), "mode": "local_mock"},
        )

    def _generate_response(self, request: CognitiveRequest) -> str:
        """Generate deterministic mock response based on task_type."""
        task = request.task_type.lower()

        if "triage" in task or "simulation" in task:
            return (
                "[LOCAL MOCK] Simulation evidence triage complete. "
                "Detected 2 warnings, 0 errors. "
                "Coverage: 94.2%. "
                "Recommendation: Proceed to human review for warning assessment."
            )
        elif "parse" in task:
            return (
                "[LOCAL MOCK] Log parsing complete. "
                "Extracted 104 test cases: 104 PASS, 0 FAIL. "
                "No critical violations detected."
            )
        elif "summary" in task:
            return (
                "[LOCAL MOCK] Summary generated. "
                f"Task: {request.task_type}, Chip: {request.chip_scope}. "
                "Evidence collected and structured successfully."
            )
        else:
            return (
                f"[LOCAL MOCK] Generic response for task_type='{request.task_type}' "
                f"on chip_scope='{request.chip_scope}'. "
                "This is a local mock backend response."
            )
