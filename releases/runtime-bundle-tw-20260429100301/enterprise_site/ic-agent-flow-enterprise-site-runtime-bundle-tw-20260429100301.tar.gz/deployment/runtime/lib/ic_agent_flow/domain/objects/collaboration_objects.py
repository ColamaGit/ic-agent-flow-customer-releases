"""
Collaboration Object Families (v0.7, PRD v0.7 Baseline)
======================================================
Defines the first-class governance objects for bounded multi-agent collaboration.
Ensures session continuity, shared issue tracking, and conflict governance.
"""
from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import List, Optional, Dict, Any
from uuid import uuid4

from pydantic import BaseModel, Field, UUID4

from ic_agent_flow.domain.governance.checkpoint import DecisionEnum, RoleEnum
from ic_agent_flow.domain.utils.time import get_tw_now


class CollaborationSessionState(str, Enum):
    """
    R1: Top-level lifecycle states for a collaboration session.
    """
    OPEN = "OPEN"
    ACTIVE = "ACTIVE"
    WAITING_ON_AGENT = "WAITING_ON_AGENT"
    WAITING_ON_HUMAN = "WAITING_ON_HUMAN"
    BLOCKED = "BLOCKED"
    ESCALATED = "ESCALATED"
    CLOSED = "CLOSED"


class CollaborationStepState(str, Enum):
    """
    R1: Lifecycle states for an individual collaboration step.
    """
    PENDING = "PENDING"
    READY = "READY"
    RUNNING = "RUNNING"
    SUSPENDED = "SUSPENDED"
    RESUMING = "RESUMING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    RETURNED = "RETURNED"


class ExternalJobState(str, Enum):
    """
    R1: States for an external process or asynchronous unit of work.
    """
    QUEUED = "QUEUED"
    SUBMITTED = "SUBMITTED"
    RUNNING = "RUNNING"
    WAITING_ON_EXTERNAL_JOB = "WAITING_ON_EXTERNAL_JOB"
    TIMED_OUT = "TIMED_OUT"
    CANCELLED = "CANCELLED"
    ORPHANED = "ORPHANED"
    REATTACHED = "REATTACHED"
    EXITED = "EXITED"
    FAILED = "FAILED"


class IssueSeverity(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"
    BLOCKER = "BLOCKER"


class IssueStatus(str, Enum):
    OPEN = "OPEN"
    IN_PROGRESS = "IN_PROGRESS"
    PARTIALLY_RESOLVED = "PARTIALLY_RESOLVED"
    RESOLVED = "RESOLVED"
    BLOCKED = "BLOCKED"
    ESCALATED = "ESCALATED"


class SharedIssueItem(BaseModel):
    """
    Representation of an unresolved issue shared within a collaboration session.
    Ensures continuity across different agents.
    """
    issue_id: UUID4 = Field(default_factory=uuid4)
    session_ref: UUID4
    issue_type: str  # e.g., "TIMING_VIOLATION", "MISSING_LOG"
    description: str
    owner_agent_id: Optional[str] = None
    status: IssueStatus = IssueStatus.OPEN
    severity: IssueSeverity = IssueSeverity.MEDIUM
    
    # R3: Continuity & Identity
    parent_issue_id: Optional[UUID4] = None  # Link for Split semantics
    evidence_refs: List[str] = []
    artifact_refs: List[str] = []
    
    next_required_action: Optional[str] = None
    created_at: datetime = Field(default_factory=get_tw_now)
    updated_at: datetime = Field(default_factory=get_tw_now)

    def update_status(self, new_status: IssueStatus, reason: str):
        self.status = new_status
        self.updated_at = get_tw_now()
        # History would be tracked in a separate log or the session metadata

    def append_evidence(self, evidence_ref: str):
        if evidence_ref not in self.evidence_refs:
            self.evidence_refs.append(evidence_ref)
            self.updated_at = get_tw_now()


class CollaborationSession(BaseModel):
    """
    The formal lifecycle container for a bounded multi-agent collaboration.
    """
    session_id: UUID4 = Field(default_factory=uuid4)
    workspace_id: str
    chip_id: str
    subject_refs: List[str] = []         # Initial bundles/tasks that started this
    active_agent_ids: List[str] = []
    
    status: CollaborationSessionState = CollaborationSessionState.OPEN
    originating_task_ref: Optional[str] = None
    
    # R2: Runtime Objects
    job_handle_ref: Optional[UUID4] = None
    queue_record_ref: Optional[UUID4] = None
    resource_record_ref: Optional[UUID4] = None
    pending_checkpoint_ref: Optional[UUID4] = None  # R4: Checkpoint Envelope
    
    current_step_id: Optional[UUID4] = None
    step_history_refs: List[str] = []    # Refs to CollaborationStepRecord files
    conflict_refs: List[UUID4] = []      # Links to CollaborationConflictRecord (AC5)
    
    # Industrialization Fields (v0.8)
    priority: int = 100                  # Lower is higher (0-255)
    timeout_seconds: int = 3600          # Default 1 hour
    retry_limit: int = 3                 # Max retries for failed steps
    
    metadata: Dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=get_tw_now)
    updated_at: datetime = Field(default_factory=get_tw_now)
    closed_at: Optional[datetime] = None


class CollaborationStepRecord(BaseModel):
    """
    Record of an individual step within a collaboration session.
    """
    step_id: UUID4 = Field(default_factory=uuid4)
    session_ref: UUID4
    step_owner_agent_id: str
    step_type: str  # e.g., "TRIAGE", "COMPLETION", "FOLLOW_UP"
    
    input_refs: List[str] = []
    output_refs: List[str] = []
    issue_refs: List[UUID4] = []         # Links to SharedIssueItem in the session
    
    status: CollaborationStepState = CollaborationStepState.PENDING
    handoff_ref: Optional[UUID4] = None  # Link to the underlying HandoffRecord if this step was initiated via handoff
    
    started_at: datetime = Field(default_factory=get_tw_now)
    ended_at: Optional[datetime] = None
    
    # Industrialization Fields (v0.8)
    job_handle_ref: Optional[UUID4] = None  # Link to ExternalJob
    retry_count: int = 0
    error_message: Optional[str] = None
    
    metadata: Dict[str, Any] = Field(default_factory=dict)


class CollaborationConflictRecord(BaseModel):
    """
    Formal record of an unresolved disagreement between agents.
    """
    conflict_id: UUID4 = Field(default_factory=uuid4)
    session_ref: UUID4
    issue_ref: UUID4
    conflicting_agent_ids: List[str]
    
    conflict_type: str                   # e.g., "VERDICT_MISMATCH"
    conflict_payload_refs: List[str] = []
    
    detected_at: datetime = Field(default_factory=get_tw_now)
    resolution_ref: Optional[UUID4] = None


class CollaborationAuditBundle(BaseModel):
    """
    R7: Aggregated governance bundle for a closed collaboration session.
    Enables full chain-of-custody replay and audit.
    """
    audit_bundle_id: UUID4 = Field(default_factory=uuid4)
    session_id: UUID4
    workspace_id: str
    chip_id: str
    
    # R7: The 8 Mandatory Replay Elements
    open_reason: str
    participating_agent_ids: List[str]
    issue_evolution_refs: List[str] = []   # Links to historical states of SharedIssueRegister
    evidence_evolution_refs: List[str] = [] # Links to EvidenceBundle versions
    ownership_transfer_history: List[Dict[str, Any]] = []
    conflict_resolution_refs: List[str] = []
    human_checkpoint_refs: List[str] = []
    final_disposition_ref: str
    
    bundle_digest: str  # HMAC-SHA256 integrity anchor
    created_at: datetime = Field(default_factory=get_tw_now)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class CollaborationResolutionRecord(BaseModel):
    """
    Formal record of resolution after a conflict adjudication.
    """
    resolution_id: UUID4 = Field(default_factory=uuid4)
    conflict_ref: UUID4
    resolved_by: str                     # human_id or high-authority agent
    
    resolution_decision: str
    resolution_rationale: str
    
    resolved_at: datetime = Field(default_factory=get_tw_now)


# R2: New Industrialization Objects (v0.8)

class CollaborationJobHandle(BaseModel):
    """
    R2: Explicit handle for an asynchronous collaboration task.
    Enables reattach, cancellation, and external monitoring.
    """
    handle_id: UUID4 = Field(default_factory=uuid4)
    session_ref: UUID4
    external_job_id: Optional[str] = None  # e.g., Slurm JobID, PID
    status: ExternalJobState = ExternalJobState.SUBMITTED
    timeout_at: datetime
    is_cancellable: bool = True
    
    # R6: Lifecycle adapter
    cleanup_status: str = "PENDING"      # PENDING, CLEANED, FAILED
    reattach_count: int = 0
    
    metadata: Dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=get_tw_now)


class CollaborationQueueRecord(BaseModel):
    """
    R2: Formal record of a session's position in the runtime queue.
    """
    queue_id: UUID4 = Field(default_factory=uuid4)
    session_ref: UUID4
    priority_class: int = 100
    queue_name: str = "default"
    
    waited_since: datetime = Field(default_factory=get_tw_now)
    estimated_start: Optional[datetime] = None
    
    # R7: Queue Fairness Attributes
    fairness_class: int = 0              # To prevent starvation
    requeue_reason: Optional[str] = None
    checkpoint_blocking_mode: bool = False


class ResourceAllocationRecord(BaseModel):
    """
    R2: Formal allocation of resources to a collaboration session.
    """
    allocation_id: UUID4 = Field(default_factory=uuid4)
    session_ref: UUID4
    resource_class: str  # e.g., "CPU_MINIMAL", "GPU_HEAVY", "MIXED"
    
    concurrency_slot: int = 1
    memory_limit_mb: Optional[int] = None
    
    allocated_at: datetime = Field(default_factory=get_tw_now)
    released_at: Optional[datetime] = None
    
    # R6: Allocation Governance
    lease_start: datetime = Field(default_factory=get_tw_now)
    lease_expiry: Optional[datetime] = None
    revocation_reason: Optional[str] = None
    checkpoint_hold_impact: bool = False


# R4: Checkpoint Envelope

class CollaborationCheckpointEnvelope(BaseModel):
    """
    R4: Formal envelope for a required human or system checkpoint.
    Ensures that checkpoints are not bypassed during resume/retry.
    """
    checkpoint_id: UUID4 = Field(default_factory=uuid4)
    session_ref: UUID4
    checkpoint_type: str                 # e.g., "HUMAN_APPROVAL", "EVIDENCE_VALIDATION"
    required_role: RoleEnum
    
    required_evidence_refs: List[str] = []
    decision_options: List[str] = []     # e.g., ["APPROVE", "REJECT", "RETRY"]
    
    stall_timeout_policy: str = "BLOCK"  # BLOCK, ESCALATE, FAIL
    non_response_effect: str = "HOLD"    # absence of response != approval
    
    status: str = "PENDING"              # PENDING, SATISFIED, FAILED
    created_at: datetime = Field(default_factory=get_tw_now)
    resolved_at: Optional[datetime] = None


# R8: Branch Runtime Objects [RESERVED]

class BranchRuntimeRecord(BaseModel):
    """
    R8: Placeholder for bounded parallel branch governance.
    Reserved for future baseline expansion.
    """
    branch_id: UUID4 = Field(default_factory=uuid4)
    session_ref: UUID4
    parent_branch_id: Optional[UUID4] = None
    
    branch_owner_agent_id: str
    branch_status: str = "PENDING"
    
    created_at: datetime = Field(default_factory=get_tw_now)
    metadata: Dict[str, Any] = Field(default_factory=dict)
