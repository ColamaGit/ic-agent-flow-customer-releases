import re
from datetime import datetime
from uuid import uuid4
from ic_agent_flow.domain.objects import TimingReport, AuthorityClass, Producer, ProducerType

class TimingParser:
    """Parses a mock Synopsys PrimeTime timing report into a TimingReport object."""
    
    def parse(self, content: str, source_id: str) -> TimingReport:
        # Extract slack
        slack_match = re.search(r"slack \((MET|VIOLATED)\)\s+(-?\d+\.\d+)", content)
        slack_val = float(slack_match.group(2)) if slack_match else 0.0
        
        # Extract endpoint
        endpoint_match = re.search(r"Endpoint:\s+(\S+)", content)
        endpoint = endpoint_match.group(1) if endpoint_match else "unknown"
        
        report = TimingReport(
            id=uuid4(),
            type="timing_report",
            version="v1.0.0",
            authority_class=AuthorityClass.DERIVED,
            producer=Producer(id="timing_summarizer_v1", type=ProducerType.TOOL),
            created_at=datetime.utcnow(),
            summary={
                "setup_slack": slack_val,
                "hold_slack": 0.0,  # Mock
                "violations_count": 0 if slack_val >= 0 else 1
            },
            paths=[{
                "endpoint": endpoint,
                "slack": slack_val,
                "vignette": "Critical path from PrimeTime log"
            }],
            input_refs=[source_id]
        )
        return report
