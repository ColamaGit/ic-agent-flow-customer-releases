class DecisionIntakeGuard:
    @staticmethod
    def validate_intake(evidence_bundle: dict):
        """
        強制執行 Law 6: 決策迴圈僅能消費 Subject-Valid 證據
        """
        if "subject_envelope" not in evidence_bundle:
            raise PermissionError("ERR_INTEGRITY_DRIFT: Missing subject binding. Intake BLOCKED.")
        
        return True

class ReentryContinuityGuard:
    @staticmethod
    def validate_rerun(old_envelope_id: str, new_envelope_id: str):
        """
        強制執行 Law 7: 重入必須保持主體連續性
        """
        if old_envelope_id != new_envelope_id:
            raise ValueError("ERR_INTEGRITY_DRIFT: Illegal subject rebinding during re-entry.")
        return True
