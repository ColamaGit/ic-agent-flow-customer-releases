"""
Production Readiness Evaluator (v0.1)
=====================================
Implements the Phase 5A -> 5B -> 6 Exit Gate verification logic.
Evaluates 5A objects (Audit Bundles, Hardening Proofs) against 5B Readiness Checkpoints.
"""
from __future__ import annotations

from typing import List, Tuple, Optional
from datetime import datetime

from ic_agent_flow.domain.objects.deployment_objects import (
    DeploymentAuditBundle,
    DeploymentStatus
)
from ic_agent_flow.domain.objects.production_bridge_objects import (
    ProductionReadinessCheckpoint,
    SOPAction
)


class ProductionReadinessEvaluator:
    """ Authoritative evaluator for determining if a chip is ready for Phase 6 Production. """

    @staticmethod
    def evaluate_5a_evidence(
        checkpoint: ProductionReadinessCheckpoint,
        bundles: List[DeploymentAuditBundle]
    ) -> Tuple[bool, List[str]]:
        """
        Exit Gate Verification: Checks if 5A evidence meets the Phase 6 entry criteria.
        """
        rejection_reasons = []
        
        # 1. Verify Hardened Baseline Status
        if not checkpoint.is_hardened_baseline_verified:
            rejection_reasons.append("Hardened baseline not yet verified by Human Authority.")

        # 2. Check Mandatory Evidence Refs
        # In a real scenario, this would check physical existence of files listed in bundles
        total_adjudications = len(bundles)
        if total_adjudications == 0:
            rejection_reasons.append("No 5A adjudication evidence found.")
            
        # 3. Metric Threshold: Rollback Rate
        rollback_count = sum(
            1 for b in bundles 
            if any(r.outcome == DeploymentStatus.ROLLED_BACK.value for r in b.audit_records)
        )
        rollback_rate = rollback_count / total_adjudications if total_adjudications > 0 else 0
        if rollback_rate > checkpoint.max_acceptable_rollback_rate:
            rejection_reasons.append(f"Rollback rate ({rollback_rate:.2%}) exceeds threshold ({checkpoint.max_acceptable_rollback_rate:.2%}).")

        # 4. Metric Threshold: Deny Rate
        deny_count = sum(
            1 for b in bundles 
            if any(r.outcome in [DeploymentStatus.BLOCKED.value, DeploymentStatus.FAILED.value] for r in b.audit_records)
        )
        deny_rate = deny_count / total_adjudications if total_adjudications > 0 else 0
        if deny_rate > checkpoint.max_acceptable_deny_rate:
            rejection_reasons.append(f"Deny/Failure rate ({deny_rate:.2%}) exceeds threshold ({checkpoint.max_acceptable_deny_rate:.2%}).")

        is_ready = len(rejection_reasons) == 0
        return is_ready, rejection_reasons

    @staticmethod
    def generate_governance_verdict(is_ready: bool, reasons: List[str]) -> str:
        """ Translates technical evaluation into a governance-level verdict. """
        if is_ready:
            return "GO_PRODUCTION_PHASE_6"
        else:
            return f"HOLD_BRIDGE_PHASE_5B: {'; '.join(reasons)}"
