import os
import json
from typing import List, Optional
from uuid import uuid4
from ic_agent_flow.domain.governance.readiness import ReadinessEntry, ReadinessLevel, SubjectType, ClaimStatus
from ic_agent_flow.domain.governance.checkpoint import AuthorityRecord, DecisionEnum, StageGateType
from ic_agent_flow.domain.utils.time import get_tw_now

# We simulate a persistable database (JSON) here.
DEFAULT_REGISTRY_PATH = "artifacts/governance_registry.json"

class ReadinessRegistry:
    """Manages the persistable, auditable Readiness entries for the system."""
    
    def __init__(self, db_path: str = DEFAULT_REGISTRY_PATH):
        self.db_path = db_path
        self._entries: List[ReadinessEntry] = []
        self._load()
        
    def _load(self):
        if os.path.exists(self.db_path):
            with open(self.db_path, "r") as f:
                try:
                    data = json.load(f)
                    self._entries = [ReadinessEntry(**item) for item in data]
                except (json.JSONDecodeError, TypeError):
                    self._entries = []
        else:
            self._entries = []
            
    def _save(self):
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        with open(self.db_path, "w") as f:
            json.dump([e.model_dump(mode="json") for e in self._entries], f, indent=2)

    def query_active(self, subject_type: SubjectType, subject_id: str) -> Optional[ReadinessEntry]:
        """Finds the single ACTIVE claim for the given subject."""
        for entry in self._entries:
            if (entry.subject_type == subject_type and 
                entry.subject_id == subject_id and 
                entry.status == ClaimStatus.ACTIVE):
                return entry
        return None

    def propose_claim(self, subject_id: str, subject_type: str, evidence_link: str):
        """Creates a PROPOSED claim in the registry."""
        # Check if already exists
        existing = self.select_proposed(subject_id)
        if existing:
            return existing
            
        new_entry = ReadinessEntry(
            id=uuid4(),
            subject_id=subject_id,
            subject_type=subject_type.lower(), # Ensure lowercase
            claimed_level=ReadinessLevel.CONTRACTED_READY,
            scope="Scenario Execution",
            entry_criteria_refs=["scenario-launch"],
            evidence_refs=[evidence_link],
            review_refs=[],
            known_gaps=[],
            forbidden_claims=[],
            status=ClaimStatus.PROPOSED,
            approved_by="Pending",
            approved_at=get_tw_now()
        )
        self._entries.append(new_entry)
        self._save()
        return new_entry

    def approve_claim(self, claim: ReadinessEntry):
        """
        Approves a claim, automatically superseding any previous active claim 
        for the same SubjectType + SubjectId.
        """
        existing = self.query_active(claim.subject_type, claim.subject_id)
        if existing:
            existing.status = ClaimStatus.SUPERSEDED
            if claim.previous_level is None:
                claim.previous_level = existing.claimed_level
                
        claim.status = ClaimStatus.ACTIVE
        self._save()

    def select_proposed(self, subject_id: str) -> Optional[ReadinessEntry]:
        """Finds a proposed claim for the given subject."""
        for entry in self._entries:
            if entry.subject_id == subject_id and entry.status == ClaimStatus.PROPOSED:
                return entry
        return None

    def process_authority_record(self, subject_id: str, record: AuthorityRecord):
        """
        Updates the registry based on a formal human decision.
        """
        proposed = self.select_proposed(subject_id)
        
        if record.decision == DecisionEnum.APPROVE:
            if proposed:
                proposed.approved_by = record.approver
                proposed.approved_at = record.created_at
                self.approve_claim(proposed)
        
        elif record.decision == DecisionEnum.REJECT:
            if proposed:
                proposed.status = ClaimStatus.REVOKED
                self._save()
        
        return True
