from abc import ABC, abstractmethod
from typing import Dict, Any, Type, Optional
from ic_agent_flow.domain.contracts.skill_contract import EDAAgentSkillContract
from ic_agent_flow.domain.objects.skill_records import SkillOutputRecord, SkillCognitiveEnvelope

class BaseSkill(ABC):
    """
    Abstract Base Class for all EDA Agent Skills.
    Skills are bounded, interpretation-focused components.
    """
    
    def __init__(self, contract: EDAAgentSkillContract):
        self.contract = contract

    @abstractmethod
    def execute(
        self, 
        inputs: Dict[str, Any], 
        cognitive_context: Optional[SkillCognitiveEnvelope] = None
    ) -> SkillOutputRecord:
        """
        Execute the skill logic.
        Inputs are provided as a dictionary.
        Cognitive context is injected by the SkillRunner if required.
        """
        pass

# Static Registry of Skill Implementations (Option A)
# Key: skill_name, Value: Class reference
REGISTERED_FIRST_WAVE_SKILLS: Dict[str, Type[BaseSkill]] = {}

def register_skill(skill_name: str, skill_cls: Type[BaseSkill]):
    """Explicitly register a skill to the allowlist."""
    REGISTERED_FIRST_WAVE_SKILLS[skill_name] = skill_cls

def get_skill_implementation(skill_name: str) -> Optional[Type[BaseSkill]]:
    """Retrieve skill class from the static registry."""
    return REGISTERED_FIRST_WAVE_SKILLS.get(skill_name)
