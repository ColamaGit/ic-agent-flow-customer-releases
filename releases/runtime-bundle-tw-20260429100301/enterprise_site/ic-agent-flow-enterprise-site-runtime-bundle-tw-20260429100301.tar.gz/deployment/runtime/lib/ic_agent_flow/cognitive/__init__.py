"""
IC Agent Flow — Cognitive Backend Adapter Layer
================================================
v0.4 Multi-Backend Cognitive Adapter Strategy v0.1

Law 1: Agent identity is provider-independent.
Law 2: Backend taxonomy split: model_style | managed_agent_style.
Law 3: All responses MUST be normalized before entering agent decision chain.
Law 4: Audit record MUST be provider-agnostic.
Law 5: Routing is policy-driven; no implicit cross-provider fallback.
"""
from ic_agent_flow.cognitive.adapter import CognitiveAdapter
from ic_agent_flow.cognitive.schemas import (
    CognitiveRequest,
    CognitiveResponse,
    BackendSelection,
    CognitiveAuditRecord,
    BackendCategory,
    BackendPolicy,
    BackendProvider,
    SensitivityLevel,
    ResponseType,
)

__all__ = [
    "CognitiveAdapter",
    "CognitiveRequest",
    "CognitiveResponse",
    "BackendSelection",
    "CognitiveAuditRecord",
    "BackendCategory",
    "BackendPolicy",
    "BackendProvider",
    "SensitivityLevel",
    "ResponseType",
]
