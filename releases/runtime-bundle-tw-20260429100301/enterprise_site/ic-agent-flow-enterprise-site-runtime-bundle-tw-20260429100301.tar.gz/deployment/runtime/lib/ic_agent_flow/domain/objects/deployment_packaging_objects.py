"""
Deployment packaging object family for customer-deployable delivery line (v0.2).
"""
from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import List, Optional
from uuid import uuid4

from pydantic import UUID4, BaseModel, Field

from ic_agent_flow.domain.utils.time import get_tw_now


class ObjectStatus(str, Enum):
    DRAFT = "DRAFT"
    ACTIVE = "ACTIVE"
    DEPRECATED = "DEPRECATED"
    REVOKED = "REVOKED"


class AuthorityClass(str, Enum):
    SYSTEM = "system"
    OPERATOR = "operator"
    SECURITY = "security"
    RELEASE_MANAGER = "release_manager"


class KeyLifecycle(str, Enum):
    ACTIVE = "ACTIVE"
    ROTATING = "ROTATING"
    REVOKED = "REVOKED"


class VerifierAuthority(str, Enum):
    SECURITY = "security"
    RELEASE_MANAGER = "release_manager"


class GateVerdict(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    HOLD = "HOLD"


class ExportClass(str, Enum):
    INTERNAL_SUPPORT = "internal_support"
    CUSTOMER_SHAREABLE = "customer_shareable"
    AUDITOR_ONLY = "auditor_only"


class RedactionLevel(str, Enum):
    NONE = "none"
    METADATA_ONLY = "metadata_only"
    PARTIAL_CONTENT = "partial_content"
    STRICT_REDACTED = "strict_redacted"


class ArtifactRef(BaseModel):
    ref: str
    digest: str


class SignatureBlock(BaseModel):
    key_id: str
    algorithm: str
    signed_at: datetime = Field(default_factory=get_tw_now)
    trust_root_ref: str
    verifier_authority: VerifierAuthority
    key_lifecycle: KeyLifecycle
    rotation_deadline: Optional[datetime] = None


class DeliveryObjectBase(BaseModel):
    id: UUID4 = Field(default_factory=uuid4)
    type: str
    version: str
    status: ObjectStatus
    authority_class: AuthorityClass
    producer: str  # service_id@version
    input_refs: List[str] = Field(default_factory=list)
    artifact_refs: List[ArtifactRef] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=get_tw_now)
    digest: str
    signature: SignatureBlock


class ProductManifest(DeliveryObjectBase):
    type: str = "product_manifest"
    components: List[str]
    api_surface_version: str
    policy_set_version: str


class DeploymentProfile(DeliveryObjectBase):
    type: str = "deployment_profile"
    network_policy: str
    backend_policy: str
    storage_policy: str
    audit_policy: str
    capability_set: List[str]
    forbidden_capabilities: List[str]
    enabled_adapters: List[str] = Field(default_factory=list)


class RuntimeDistributionBundle(DeliveryObjectBase):
    type: str = "runtime_distribution_bundle"
    bundle_version: str
    product_manifest_ref: str
    profile_ref: str
    sbom_ref: str
    checksum_set_ref: str
    source_paths: List[str] = Field(default_factory=list)


class CustomerDeploymentManifest(DeliveryObjectBase):
    type: str = "customer_deployment_manifest"
    site_id: str
    installed_bundle_ref: str
    profile_ref: str
    install_record_ref: str
    effective_policy_refs: List[str]


class SitePolicyOverlay(DeliveryObjectBase):
    type: str = "site_policy_overlay"
    base_profile_ref: str
    override_keys: List[str]
    justification: str
    approval_record_ref: str


class UpgradePackage(DeliveryObjectBase):
    type: str = "upgrade_package"
    from_version: str
    to_version: str
    precheck_rules: List[str]
    migration_steps: List[str]
    postcheck_rules: List[str]


class RollbackPackage(DeliveryObjectBase):
    type: str = "rollback_package"
    target_version: str
    rollback_trigger_conditions: List[str]
    state_restore_refs: List[str]


class InstallationRecord(DeliveryObjectBase):
    type: str = "installation_record"
    site_id: str
    installed_bundle_ref: str
    profile_ref: str
    environment_fingerprint: str
    policy_fingerprint: str
    verifier: str
    result: str


class UpgradeRecord(DeliveryObjectBase):
    type: str = "upgrade_record"
    site_id: str
    from_version: str
    to_version: str
    upgrade_package_ref: str
    precheck_result: str
    postcheck_result: str
    verifier: str
    result: str


class RollbackRecord(DeliveryObjectBase):
    type: str = "rollback_record"
    site_id: str
    from_version: str
    target_version: str
    rollback_package_ref: str
    restore_scope: str
    verifier: str
    result: str


class SupportAuditBundle(DeliveryObjectBase):
    type: str = "support_audit_bundle"
    incident_id: str
    time_window: str
    included_logs: List[str]
    redaction_policy: str
    export_reason: str
    export_class: ExportClass
    included_object_allowlist: List[str]
    prohibited_object_denylist: List[str]
    redaction_level: RedactionLevel


class CutoverApprovalRecord(DeliveryObjectBase):
    type: str = "cutover_approval_record"
    migration_id: str
    target_bundle_ref: str
    target_profile_ref: str
    approval_roles: List[VerifierAuthority]
    approved_by: List[str]
    approval_notes: str


class GateEvidenceRefSet(BaseModel):
    id: UUID4 = Field(default_factory=uuid4)
    type: str = "gate_evidence_ref_set"
    gate_id: str
    evidence_refs: List[str] = Field(default_factory=list)
    subject_ref: str
    run_ref: str
    generated_at: datetime = Field(default_factory=get_tw_now)


class GateFailureRecord(BaseModel):
    id: UUID4 = Field(default_factory=uuid4)
    type: str = "gate_failure_record"
    gate_id: str
    gate_name: str
    verdict: GateVerdict = GateVerdict.FAIL
    blocking_reasons: List[str] = Field(default_factory=list)
    evidence_refs: List[str] = Field(default_factory=list)
    subject_ref: str
    run_ref: str
    generated_at: datetime = Field(default_factory=get_tw_now)


class GateResult(BaseModel):
    id: UUID4 = Field(default_factory=uuid4)
    type: str = "gate_result"
    gate_id: str
    gate_name: str
    verdict: GateVerdict
    blocking_reasons: List[str] = Field(default_factory=list)
    evidence_refs: List[str] = Field(default_factory=list)
    subject_ref: str
    run_ref: str
    generated_at: datetime = Field(default_factory=get_tw_now)
    failure_record_ref: Optional[str] = None
    evidence_ref_set_ref: Optional[str] = None
