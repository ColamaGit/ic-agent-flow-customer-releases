from datetime import datetime, timezone
from uuid import uuid4
from ic_agent_flow.domain.objects import RTLSnapshot, AuthorityClass, Producer, ProducerType
from ic_agent_flow.adapters.parsers.drc_parser import DRCParser
from ic_agent_flow.adapters.parsers.misc_parsers import LintParser, CDCParser
from ic_agent_flow.context.assembler import ContextAssembler
from ic_agent_flow.domain.verification import AdjudicationRecord, AdjudicationAuthority, Decision, Verdict
from ic_agent_flow.domain.verification.evaluator import ContractEvaluator
from ic_agent_flow.domain.governance import (
    ExecutionRunRecord, ReadinessNote, CloseoutBundle, HumanReviewPackage
)
from ic_agent_flow.domain.contracts import Contract, SelectedContracts
import os

class MultiReportNormalizationScenario:
    """E1: Normalizes multiple static reports (Lint, CDC, DRC) into a single unified truth chain."""
    
    def __init__(self):
        self.assembler = ContextAssembler()
        self.evaluator = ContractEvaluator()
        self.lint = LintParser()
        self.cdc = CDCParser()
        self.drc = DRCParser()
    
    def run(self):
        rtl_snap = RTLSnapshot(id=uuid4(), version="v1.0.0", status="stable", authority_class=AuthorityClass.CANONICAL, producer=Producer(id="human_01", type=ProducerType.HUMAN), created_at=datetime.now(timezone.utc), files=[{"path": "top.v", "hash": "abc"}])
        manifest = self.assembler.assemble(task_type="multi-report-norm", subjects=[rtl_snap], assembler_id="orchestrator_v1")
        
        # 1. Parse all reports
        l_obj = self.lint.parse("mock log", f"rtl_snap:{rtl_snap.id}")
        c_obj = self.cdc.parse("mock log", f"rtl_snap:{rtl_snap.id}")
        d_obj = self.drc.parse("mock log", f"rtl_snap:{rtl_snap.id}")
        
        # 2. Select Contracts
        contracts = SelectedContracts(version="v1.0.0", contracts=[
            Contract(id="L-01", name="Lint Check", schema_ref="report.json", description="Lint cleanly"),
            Contract(id="L-01", name="CDC Check", schema_ref="report.json", description="CDC cleanly"), # Reusing logic for mock
            Contract(id="D-01", name="DRC Check", schema_ref="drc.json", description="DRC cleanly")
        ])
        
        # 3. Evaluate Matrix (E1 Core Test: Matrix Evaluation)
        v_l = self.evaluator.evaluate(contracts.contracts[0], l_obj)
        v_c = self.evaluator.evaluate(contracts.contracts[1], c_obj)
        v_d = self.evaluator.evaluate(contracts.contracts[2], d_obj)
        verdicts = [v_l, v_c, v_d]
        
        all_passed = all(v.verdict == Verdict.PASS for v in verdicts)
        
        # 4. Adjudication & Packaging
        adjudication = AdjudicationRecord(
            adjudication_id=uuid4(), subject_refs=[f"rtl_snapshot:{rtl_snap.id}"],
            gate_verdict_refs=[f"gate_verdict:{v.id}" for v in verdicts],
            decision=Decision.PROCEED if all_passed else Decision.HOLD,
            decision_rationale="Portfolio evaluation unified.",
            authority=AdjudicationAuthority(human_id="auto_val", role="Validator"),
            approved_at=datetime.now(timezone.utc)
        )
 
        run_record = ExecutionRunRecord(run_id=uuid4(), timestamp=datetime.now(timezone.utc), producer=Producer(id="agent", type=ProducerType.AGENT), environment="env", task_type="multi-report")
 
        review_package = HumanReviewPackage(
            id=uuid4(), subject_objects=[f"rtl_snapshot:{rtl_snap.id}"],
            authoritative_evidence_refs=[f"lint:{l_obj.id}", f"cdc:{c_obj.id}", f"drc:{d_obj.id}"],
            gate_verdict_summary=f"LINT: {v_l.verdict}, CDC: {v_c.verdict}, DRC: {v_d.verdict}",
            open_risks=[r for v in verdicts for r in [v.rationale] if v.verdict == Verdict.FAILED],
            downstream_effect="Proceeds to execution phase.",
            created_at=datetime.now(timezone.utc)
        )
 
        readiness_note = ReadinessNote(id=uuid4(), current_readiness="RR", target_readiness="BR", claims=["Multi-report ingestion verified"], limitations=[], evidence_delta="None", created_at=datetime.now(timezone.utc))
 
        bundle = CloseoutBundle(
            id=uuid4(), task_type="multi-report", input_objects=[rtl_snap], context_manifest=manifest, selected_contracts=contracts,
            execution_run_record=run_record, normalized_artifacts=[l_obj, c_obj, d_obj], gate_verdicts=verdicts,
            adjudication_record=adjudication, human_review_package=review_package, final_readiness_note=readiness_note, created_at=datetime.now(timezone.utc)
        )
        
        os.makedirs("artifacts/closeouts", exist_ok=True)
        path = f"artifacts/closeouts/bundle_{bundle.id}.json"
        with open(path, "w") as f: f.write(bundle.model_dump_json(indent=2))
        return path

if __name__ == "__main__":
    s = MultiReportNormalizationScenario()
    res = s.run()
    print(f"E1 Run Complete: {res}")
