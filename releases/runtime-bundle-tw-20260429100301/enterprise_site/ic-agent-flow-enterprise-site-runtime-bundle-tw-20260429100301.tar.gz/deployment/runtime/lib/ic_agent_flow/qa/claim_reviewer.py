import json
import os

class ClaimReviewer:
    """ Evaluates whether a ReadinessClaim is correctly scaled to its Evidence. """

    def __init__(self, artifacts_dir: str = "artifacts"):
        self.artifacts_dir = artifacts_dir

    def review_claim(self, claim_data: dict, validation_report: dict) -> dict:
        """ Reviews the raw claim object against the QA Scenario report. """
        report = {
            "claim_id": claim_data.get("id", "unknown"),
            "subject_id": claim_data.get("subject_id", "project"),
            "claimed_level": claim_data.get("level", "UNKNOWN"),
            "scope": claim_data.get("scope", "ALL"),
            "evidence_refs": claim_data.get("evidence", []),
            "gaps_disclosed": len(claim_data.get("limitations", [])) > 0,
            "forbidden_claims_checked": True,
            "misalignment_found": False,
            "qa_verdict": {
                "verdict": "ACCEPTABLE",
                "severity": "INFO",
                "blocking": False,
                "summary": "Claim is accurately scoped."
            }
        }

        claim_scope = report["scope"]
        validation_boundary = validation_report.get("claim_boundary", "")

        # Very basic check: If the scenario bounds are narrower than the claim
        if claim_scope == "ALL" and validation_boundary != "ALL":
            report["misalignment_found"] = True
            report["qa_verdict"]["verdict"] = "CLAIM_SCOPE_TOO_BROAD"
            report["qa_verdict"]["severity"] = "CRITICAL"
            report["qa_verdict"]["blocking"] = True
            report["qa_verdict"]["summary"] = f"Claiming {claim_scope} but validation is bounded to {validation_boundary}."

        out_dir = os.path.join(self.artifacts_dir, "qa", "claim_reviews")
        os.makedirs(out_dir, exist_ok=True)
        report_path = os.path.join(out_dir, f"claim_qa_{report['claim_id']}.json")
        with open(report_path, 'w') as f:
            json.dump(report, f, indent=2)

        return report
