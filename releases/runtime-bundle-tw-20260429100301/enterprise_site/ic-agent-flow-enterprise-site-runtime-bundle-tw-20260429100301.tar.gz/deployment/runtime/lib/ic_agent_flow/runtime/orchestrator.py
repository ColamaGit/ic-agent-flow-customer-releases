"""
Minimum Run Coordinator / Orchestrator (Phase 1, D1-4 Summary)
==============================================================
Connects task intake → chip scope resolution → cognitive backend → state transitions.

This is the first real orchestrator in ic-agent-flow.
It does NOT manage multi-agent coordination (v0.4 scope restriction).
It manages ONE agent run at a time, fail-closed.
"""
from __future__ import annotations

import os
import uuid
from datetime import datetime, timezone
from typing import Optional

from dotenv import load_dotenv

from ic_agent_flow.agents import (
    EVIDENCE_COLLECTOR_IDENTITY,
    EVIDENCE_COMPLETION_AGENT_IDENTITY,
    DECISION_FOLLOWUP_AGENT_IDENTITY,
    EscalationCondition,
)
from ic_agent_flow.governance.handoff_engine import InterAgentHandoffEngine
from ic_agent_flow.governance.collaboration_engine import CollaborationEngine
from ic_agent_flow.governance.collaboration_storage import CollaborationStorageManager
from ic_agent_flow.runtime.queue_manager import CollaborationQueueManager
from ic_agent_flow.domain.objects.handoff_objects import HandoffRecord, HandoffPayloadManifest
from ic_agent_flow.domain.objects.collaboration_objects import (
    CollaborationSession,
    CollaborationSessionState,
    CollaborationStepRecord,
    CollaborationStepState,
    ExternalJobState,
    SharedIssueItem,
    IssueStatus,
    CollaborationJobHandle
)
from ic_agent_flow.domain.objects.evidence_bundle import EvidenceBundleRef
from ic_agent_flow.domain.objects.task import TaskRequest, TaskStatus
from ic_agent_flow.domain.objects import Producer, ProducerType
from ic_agent_flow.domain.objects.skill_records import SkillInvocationRecord
from ic_agent_flow.domain.utils.time import get_tw_now
from ic_agent_flow.runtime.run_state import AgentRunState, RunState, RunResult
from ic_agent_flow.cognitive.adapter import CognitiveAdapter
from ic_agent_flow.cognitive.schemas import CognitiveRequest, SensitivityLevel, BackendPolicy
from ic_agent_flow.registry.capability_registry import CapabilityRegistry
from ic_agent_flow.runtime.skill_runner import SkillRunner

class MinimalOrchestrator:
    """
    Run Coordinator for v0.6.
    Supports single-agent runs and governed inter-agent handoffs.
    """

    def __init__(self, capability_registry: Optional[CapabilityRegistry] = None, adapter: Optional[CognitiveAdapter] = None):
        self._adapter = adapter or CognitiveAdapter()
        self._capability_registry = capability_registry or CapabilityRegistry()
        self._skill_runner = SkillRunner(self._capability_registry)
        
        # v0.8 Industrialization Components
        self._storage = CollaborationStorageManager()
        self._queue = CollaborationQueueManager(capacity_slots=2)

    def run(self, task: TaskRequest, agent_id: str = EVIDENCE_COLLECTOR_IDENTITY.agent_id) -> RunResult:
        """Execute one bounded agent run."""
        state = AgentRunState(
            agent_id=agent_id,
            chip_scope=task.chip_id,
            task_id=task.task_id,
        )

        cognitive_output: Optional[str] = None
        audit_json: Optional[dict] = None

        try:
            self._validate_task(task, state)
            if state.is_terminal:
                return RunResult(state=state, task=task)

            self._resolve_chip_scope(task, state)
            if state.is_terminal:
                return RunResult(state=state, task=task)

            state.transition(RunState.RUNNING, f"Agent {agent_id} invoking cognitive backend")
            cognitive_output = self._invoke_cognitive(task, state, agent_id)
            if state.is_terminal:
                return RunResult(state=state, task=task, cognitive_output=cognitive_output)

            state.transition(RunState.TRIAGE_READY, "Cognitive output collected, triage ready")
            self._run_skills(task, state, cognitive_output)

            state.transition(RunState.COMPLETED, f"Agent {agent_id} execution complete")

            if self._adapter.last_audit:
                audit_json = self._adapter.last_audit.model_dump()

        except Exception as e:
            if not state.is_terminal:
                state.fail(f"Unexpected orchestrator error: {e}")
            if self._adapter.last_audit:
                audit_json = self._adapter.last_audit.model_dump()

        task.status = (
            TaskStatus.COMPLETED if state.current_state == RunState.COMPLETED else TaskStatus.FAILED
        )

        return RunResult(
            state=state,
            task=task,
            cognitive_output=cognitive_output,
            audit_json=audit_json
        )

    def run_handoff(self, record: HandoffRecord, manifest: HandoffPayloadManifest) -> RunResult:
        """
        PRD 6.4/6.5: Executes a formal inter-agent handoff flow.
        """
        target_agent_id = manifest.target_agent_id
        task = TaskRequest(
            task_id=f"handoff-{record.handoff_id}",
            chip_id=manifest.chip_id,
            task_type="evidence_completion",
            description=f"Handoff from {manifest.source_agent_id}: {manifest.unresolved_issue_ids}"
        )
        
        state = AgentRunState(
            agent_id=target_agent_id,
            chip_scope=task.chip_id,
            task_id=task.task_id
        )

        try:
            # 1. Precondition Check (Law 2)
            failures = InterAgentHandoffEngine.validate_preconditions(record, manifest, "evidence_completer")
            if failures:
                InterAgentHandoffEngine.reject_handoff(record, target_agent_id, failures[0], "Precondition check failed")
                state.fail(f"Handoff rejected: {failures[0]}")
                return RunResult(state=state, task=task)

            # 2. Accept Handoff
            InterAgentHandoffEngine.accept_handoff(record, target_agent_id, "Accepted completion task")
            state.transition(RunState.CONTEXT_RESOLVED, "Handoff accepted, scope resolved")
            state.transition(RunState.RUNNING, "Execution starting")

            # 3. Execution (Simulated)
            cog_output = self._invoke_cognitive(task, state, target_agent_id)
            
            # 4. Produce New Bundle with Lineage (R4)
            new_bundle = EvidenceBundleRef(
                chip_scope=manifest.chip_id,
                task_id=task.task_id,
                agent_id=target_agent_id,
                parent_bundle_id=manifest.subject_refs[0] if manifest.subject_refs else None,
                prior_bundle_refs=manifest.prior_decision_refs
            )
            # Linkage logic would go here in full impl
            
            # 5. Complete Handoff
            state.transition(RunState.TRIAGE_READY, "Completion logic executed, triage ready")
            InterAgentHandoffEngine.complete_handoff(record, target_agent_id, new_bundle.bundle_id)
            state.transition(RunState.COMPLETED, "Handoff completion artifact produced")

        except Exception as e:
            InterAgentHandoffEngine.return_handoff(record, target_agent_id, f"Execution error: {e}")
            state.fail(f"Handoff return: {e}")

        return RunResult(state=state, task=task)

    def run_collaboration_session(
        self, 
        session: CollaborationSession, 
        issues: List[SharedIssueItem]
    ) -> List[RunResult]:
        """
        PRD 6.2 / v0.8: Executes a governed multi-agent collaboration loop.
        Supports R1-R9 Industrialization requirements.
        """
        results = []
        step_history = []
        
        # 1. Preflight Check (R2)
        failures = CollaborationEngine.run_preflight_check(
            workspace_id=session.workspace_id,
            chip_id=session.chip_id,
            topology_legal=True,
            agents_role_bound=True,
            subject_lineage_complete=True,
            shared_issue_initialized=len(issues) > 0,
            evidence_accessible=True,
            human_state_compatible=True
        )
        
        if failures:
            session.status = CollaborationSessionState.BLOCKED
            self._storage.save_session(session, issues)
            print(f"  [Orchestrator] Preflight failed: {failures}")
            return results

        # 2. Queueing (R7)
        print(f"  [Orchestrator] Enqueueing session {session.session_id}")
        session.status = CollaborationSessionState.ACTIVE # Simplified transition to Active
        q_record = self._queue.enqueue(session.session_id, priority_class=session.priority)
        
        # 3. Iterative Substrate
        runtime_jobs = []
        runtime_queues = [q_record]
        runtime_allocations = []
        runtime_checkpoints = []

        # 3.1 Resource Allocation (R7) - Allocate once for the activation phase
        alloc = self._queue.try_allocate(session.session_id)
        if not alloc:
            print(f"  [Orchestrator] Resource capacity reached. Session {session.session_id} remains in queue.")
            # Update storage with current queue state before suspension
            self._storage.save_session(
                session, issues, step_history, 
                job_handles=runtime_jobs, 
                queue_records=runtime_queues,
                checkpoints=runtime_checkpoints
            )
            return results

        runtime_allocations.append(alloc)

        for agent_id in session.active_agent_ids:
            # 3.2 Deadlock Monitor (R5 logic from v0.7)
            if issues and CollaborationEngine.detect_deadlock(session, step_history, issues[0].issue_id):
                session.status = CollaborationSessionState.BLOCKED
                break
            
            # 3.3 Persistence Checkpoint (R4)
            print(f"  [Orchestrator] Saving checkpoint before step start")
            self._storage.save_session(
                session, issues, step_history,
                job_handles=runtime_jobs,
                queue_records=runtime_queues,
                allocations=runtime_allocations
            )
                
            # 3.4 Execute Step (Simulated Async/Submit)
            step = CollaborationEngine.start_step(
                session=session,
                owner_agent_id=agent_id,
                step_type="TRIAGE",
                input_refs=session.subject_refs,
                issue_refs=[i.issue_id for i in issues]
            )
            step.status = CollaborationStepState.RUNNING
            
            # R2: Async Job Model (Submit)
            job_handle = CollaborationJobHandle(
                session_ref=session.session_id,
                timeout_at=get_tw_now() # Mocked timeout
            )
            step.job_handle_ref = job_handle.handle_id
            runtime_jobs.append(job_handle)
            
            # Execute (Simulated blocking for baseline, but state is non-blocking aware)
            task = TaskRequest(
                task_id=f"step-{step.step_id}",
                chip_id=session.chip_id,
                task_type=step.step_type,
                description=f"Industrial Collaboration Step"
            )
            
            res = self.run(task, agent_id=agent_id)
            results.append(res)
            
            # 3.5 Reattach / Finalize logic
            if res.is_success:
                step.status = CollaborationStepState.COMPLETED
                job_handle.status = ExternalJobState.EXITED
                if issues:
                    # R3: Evidence Continuity - Generate physical evidence index for the step
                    evidence_ref = f"bundle-{agent_id}-{uuid.uuid4().hex[:8]}"
                    CollaborationEngine.update_issue(issues[0], IssueStatus.IN_PROGRESS, "Step success", evidence_ref=evidence_ref)
            else:
                step.status = CollaborationStepState.FAILED
                job_handle.status = ExternalJobState.FAILED
                
            step.ended_at = get_tw_now()
            step_history.append(step)
            
        # 3.6 Release Resource (R7)
        self._queue.release(session.session_id)
            
        # 4. Final Disposition
        if session.status not in [CollaborationSessionState.BLOCKED]:
            session.status = CollaborationSessionState.CLOSED if all(r.is_success for r in results) else CollaborationSessionState.ACTIVE
            
        session.updated_at = get_tw_now()
        self._storage.save_session(
            session, issues, step_history,
            job_handles=runtime_jobs,
            queue_records=runtime_queues,
            allocations=runtime_allocations,
            checkpoints=runtime_checkpoints
        ) # Final Save (R10)
        return results

    def resume_session(self, chip_id: str, session_id: uuid.UUID) -> List[RunResult]:
        """
        R3/R4: Resumes a session from disk.
        Ensures Authority Preservation and Rebind.
        """
        session = self._storage.load_session(chip_id, session_id)
        if not session:
            raise ValueError(f"Session {session_id} not found in chip {chip_id}")
            
        # R5: Stale Detection
        context = {"workspace_id": session.workspace_id, "chip_id": chip_id}
        violations = self._storage.validate_snapshot(session, context)
        if violations:
            raise ValueError(f"R5 Stale Snapshot detected: {violations}")
            
        # R3: Rebind
        self._storage.rebind_session(session, context)
        
        print(f"  [Orchestrator] Resuming session {session_id} (Status: {session.status})")
        # In this baseline, we just re-run from current state (Simplified for AC)
        # Real impl would pick up issues and steps from storage
        return self.run_collaboration_session(session, [])

    def _invoke_cognitive(self, task: TaskRequest, state: AgentRunState, agent_id: str) -> Optional[str]:
        """Invoke the cognitive backend with agent-specific context."""
        req = CognitiveRequest(
            agent_id=agent_id,
            chip_scope=task.chip_id,
            task_type=task.task_type,
            prompt=self._build_prompt(task),
            system_context=f"You are the {agent_id}. Follow your mission and prohibitions.",
            sensitivity=SensitivityLevel.INTERNAL,
            policy=BackendPolicy.REMOTE_ALLOWED_WITH_CONTROLS,
        )
        response = self._adapter.invoke(req)
        return response.content if not response.is_error else f"Error: {response.error_message}"

    def _validate_task(self, task: TaskRequest, state: AgentRunState) -> None:
        """Validate task fields. Fail-closed if required fields are missing."""
        if not task.chip_id:
            state.fail(EscalationCondition.CHIP_SCOPE_UNRESOLVED.value)
            return
        if not task.task_type:
            state.fail("task_type is required")
            return

    def _resolve_chip_scope(self, task: TaskRequest, state: AgentRunState) -> None:
        """
        Resolve chip scope from workspace registry.
        v0.4 minimal: checks that chip_id references a known chip directory.
        """
        # Use PROJECT_ROOT env var, or auto-detect from cwd
        project_root = os.getenv("PROJECT_ROOT", os.getcwd())
        chips_dir = os.path.join(project_root, "chips")
        chip_path = os.path.join(chips_dir, task.chip_id)

        if not os.path.isdir(chip_path):
            state.escalate(
                f"{EscalationCondition.CHIP_SCOPE_UNRESOLVED.value}: "
                f"chip_id='{task.chip_id}' not found in chips/ directory "
                f"(searched: {chip_path})."
            )
            return

        state.transition(RunState.CONTEXT_RESOLVED, f"Chip scope resolved: {task.chip_id}")

    def _build_prompt(self, task: TaskRequest) -> str:
        context_parts = []
        if task.description:
            context_parts.append(f"Task description: {task.description}")
        if task.metadata:
            context_parts.append(f"Context: {task.metadata}")

        context_str = "\n".join(context_parts) if context_parts else "No additional context."

        return (
            f"Perform a simulation evidence triage for chip '{task.chip_id}'.\n"
            f"Task type: {task.task_type}\n"
            f"{context_str}\n\n"
            "Analyze available simulation evidence and provide:\n"
            "1. Summary of findings\n"
            "2. List of any warnings or concerns\n"
            "3. Recommendation for human review (if needed)\n"
            "Keep response concise and structured."
        )

    def _run_skills(self, task: TaskRequest, state: AgentRunState, cognitive_output: Optional[str]) -> None:
        """Execute first-wave skills if applicable."""
        print(f"  [SkillRunner] Executing triage skill for task={task.task_id}...")
        
        # 1. Create invocation
        invocation = SkillInvocationRecord(
            invocation_id=uuid.uuid4(),
            skill_name="verification_triage",
            skill_version="v0.1.0",
            workspace_id="default",
            chip_id=task.chip_id,
            task_id=task.task_id,
            input_refs=[],
            invoker=Producer(id=state.agent_id, type=ProducerType.AGENT)
        )
        
        # 2. Prepare inputs
        # In a real system, we'd parse task metadata or artifacts.
        # For the baseline, we pass the cognitive output and basic verdict.
        inputs = {
            "sim_verdict": "FAILED", # Mocked
            "tests_run": 100,
            "tests_passed": 95,
            "cognitive_summary": cognitive_output
        }
        
        # 3. Run Skill
        try:
            output = self._skill_runner.run_skill(invocation, inputs)
            print(f"  [SkillRunner] Skill completed successfully. Output ref saved.")
        except Exception as e:
            print(f"  [WARN] Skill execution failed: {e}")
            # We don't necessarily fail the whole orchestrator run if skills fail (degraded mode)
            # but we record it.
