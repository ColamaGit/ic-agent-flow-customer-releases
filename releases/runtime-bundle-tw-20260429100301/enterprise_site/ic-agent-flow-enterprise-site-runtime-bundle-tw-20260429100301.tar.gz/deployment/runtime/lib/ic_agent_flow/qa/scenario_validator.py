import json
import os
import uuid
from typing import Dict, Any

class ScenarioValidator:
    """ Evaluates whether a Scenario family meets the 1+2+1 QA standard. """

    def __init__(self, artifacts_dir: str = "artifacts"):
        self.artifacts_dir = artifacts_dir

    def evaluate_1_plus_2_plus_1(self, scenario_id: str, results: Dict[str, bool]) -> Dict[str, Any]:
        """
        results should contain:
        - "golden_passed"
        - "security_negative_passed"
        - "evidence_negative_passed"
        - "recovery_passed"
        """
        report = {
            "scenario_id": scenario_id,
            "validation_mode": "REAL_BINDING",
            "run_refs": [str(uuid.uuid4()) for _ in range(4)],
            "golden_path_passed": results.get("golden_passed", False),
            "negative_paths_passed": results.get("security_negative_passed", False) and results.get("evidence_negative_passed", False),
            "recovery_path_passed": results.get("recovery_passed", False),
            "known_gaps": [],
            "claim_boundary": "TIER_3_ELEVATION",
            "qa_verdict": {
                "verdict": "SCENARIO_NOT_SUFFICIENTLY_VALIDATED",
                "severity": "WARNING",
                "blocking": True,
                "summary": "Default fail-closed."
            }
        }

        # Determine Verdict
        if report["golden_path_passed"] and report["negative_paths_passed"] and report["recovery_path_passed"]:
            report["qa_verdict"]["verdict"] = "ACCEPTABLE"
            report["qa_verdict"]["severity"] = "INFO"
            report["qa_verdict"]["blocking"] = False
            report["qa_verdict"]["summary"] = "All 1+2+1 requirements met. Scenario is fully validated for governance environments."
        elif report["golden_path_passed"] and not report["negative_paths_passed"]:
            report["qa_verdict"]["verdict"] = "SCENARIO_NOT_SUFFICIENTLY_VALIDATED"
            report["qa_verdict"]["summary"] = "Runs properly under golden conditions, but fails to prevent/report adversarial boundary breaches."
        else:
            report["qa_verdict"]["verdict"] = "INSUFFICIENT_EVIDENCE"
            report["qa_verdict"]["summary"] = "Core golden path failed or unexecuted."

        out_dir = os.path.join(self.artifacts_dir, "qa", "scenario_validation_reports")
        os.makedirs(out_dir, exist_ok=True)
        report_path = os.path.join(out_dir, f"scenario_qa_{scenario_id}.json")
        with open(report_path, 'w') as f:
            json.dump(report, f, indent=2)

        return report
