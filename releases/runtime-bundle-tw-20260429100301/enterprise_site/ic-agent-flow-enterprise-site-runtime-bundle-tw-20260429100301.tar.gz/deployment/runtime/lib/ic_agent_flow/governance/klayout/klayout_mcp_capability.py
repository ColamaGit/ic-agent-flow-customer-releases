
import os
import subprocess
from ic_agent_flow.governance.mcp_capability_base import MCPCapabilityBase

class KLayoutDRCCapability(MCPCapabilityBase):
    def __init__(self, klayout_path="/usr/local/bin/klayout"):
        self.klayout_path = klayout_path
        self.contract_id = "klayout_drc_contract@v0.1"

    def execute(self, gds_path, drc_rules_path, output_xml):
        """
        執行 KLayout DRC 檢查
        """
        if not os.path.exists(gds_path):
            raise FileNotFoundError(f"GDS file not found: {gds_path}")
            
        cmd = [
            self.klayout_path,
            "-b",  # Batch mode
            "-r", drc_rules_path,
            "-rd", f"input={gds_path}",
            "-rd", f"report={output_xml}",
            gds_path
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            raise RuntimeError(f"KLayout DRC failed: {result.stderr}")
            
        return {"output_xml": output_xml, "status": "PASS"}
