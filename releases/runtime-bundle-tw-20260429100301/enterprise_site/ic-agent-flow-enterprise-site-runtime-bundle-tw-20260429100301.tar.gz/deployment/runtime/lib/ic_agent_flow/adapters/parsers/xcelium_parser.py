"""
Xcelium Simulation Log Parser (Phase 2, D2-3)
==============================================
Parses Cadence Xcelium simulation logs into structured SimulationParseResult objects.

Supports Xcelium 20.x, 21.x, 22.x, 23.x output formats.
Handles both PASS and FAIL scenarios with partial output.

Fail-closed: returns ParseFailure object on unrecoverable parse errors.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import List, Optional


# ── Result Enums ──────────────────────────────────────────────────────────────

class SimulationVerdict(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    INCOMPLETE = "INCOMPLETE"   # Simulation did not finish
    ELABORATION_ERROR = "ELABORATION_ERROR"
    UNKNOWN = "UNKNOWN"


# ── Parsed Data Structures ────────────────────────────────────────────────────

@dataclass
class TestCaseResult:
    name: str
    result: str        # "PASS" | "FAIL" | "ERROR"
    assertions: int = 0
    failures: int = 0
    sim_time_ns: Optional[float] = None


@dataclass
class AssertionSummary:
    total_checked: int = 0
    passed: int = 0
    failed: int = 0
    vacuous: int = 0


@dataclass
class CoverageReport:
    line_pct: Optional[float] = None
    branch_pct: Optional[float] = None
    fsm_pct: Optional[float] = None
    toggle_pct: Optional[float] = None
    functional_pct: Optional[float] = None

    @property
    def average_pct(self) -> Optional[float]:
        values = [v for v in [
            self.line_pct, self.branch_pct,
            self.fsm_pct, self.toggle_pct, self.functional_pct
        ] if v is not None]
        return round(sum(values) / len(values), 2) if values else None


@dataclass
class ParseWarning:
    severity: str
    location: str
    message: str


@dataclass
class SimulationParseResult:
    """
    Structured output of Xcelium log parsing.
    This is the normalized form consumed by the Evidence Collector Agent.
    """
    verdict: SimulationVerdict
    tests_run: int = 0
    tests_passed: int = 0
    tests_failed: int = 0
    test_cases: List[TestCaseResult] = field(default_factory=list)
    assertions: AssertionSummary = field(default_factory=AssertionSummary)
    coverage: CoverageReport = field(default_factory=CoverageReport)
    warnings: List[ParseWarning] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    sim_cpu_seconds: Optional[float] = None
    chip_scope: Optional[str] = None
    seed: Optional[int] = None
    xcelium_version: Optional[str] = None
    parse_warnings: List[str] = field(default_factory=list)   # Parser's own warnings
    raw_lines: int = 0

    @property
    def has_failures(self) -> bool:
        return self.tests_failed > 0 or bool(self.errors)

    @property
    def coverage_adequate(self, threshold: float = 80.0) -> bool:
        avg = self.coverage.average_pct
        return avg is not None and avg >= threshold


@dataclass
class ParseFailure:
    """Returned when the log cannot be parsed at all."""
    reason: str
    raw_lines_read: int = 0


# ── Parser ────────────────────────────────────────────────────────────────────

class XceliumLogParser:
    """
    Parses Cadence Xcelium simulation log files.

    Usage:
        parser = XceliumLogParser()
        result = parser.parse("/path/to/sim.log")
        # result is SimulationParseResult or ParseFailure
    """

    # Regex patterns
    _VERSION_RE = re.compile(r"Cadence Xcelium Parallel Simulator -- Version\s+(\S+)")
    _SIM_START_RE = re.compile(r"XCELIUM_SIM_START:\s+chip=(\S+)\s+seed=(\d+)")
    _SIM_END_RE = re.compile(r"XCELIUM_SIM_END:\s+(PASS|FAIL|INCOMPLETE)")
    _TESTS_SUMMARY_RE = re.compile(r"Tests run\s*:\s*(\d+)")
    _TESTS_PASSED_RE = re.compile(r"Tests passed\s*:\s*(\d+)")
    _TESTS_FAILED_RE = re.compile(r"Tests failed\s*:\s*(\d+)")
    _CPU_TIME_RE = re.compile(r"Simulation CPU time:\s+([\d.]+) seconds")
    _TESTCASE_RE = re.compile(r"TEST CASE:\s+(\S+)")
    _TC_RESULT_RE = re.compile(
        r"(PASS|FAIL|ERROR):\s+(\S+)\s+\[assertions=(\d+)(?:,\s*failures=(\d+))?(?:,\s*time=[\d.]+ns)?\]"
    )
    _COVERAGE_LINE_RE = re.compile(r"Line Coverage\s*:\s*([\d.]+)%")
    _COVERAGE_BRANCH_RE = re.compile(r"Branch Coverage\s*:\s*([\d.]+)%")
    _COVERAGE_FSM_RE = re.compile(r"FSM Coverage\s*:\s*([\d.]+)%")
    _COVERAGE_TOGGLE_RE = re.compile(r"Toggle Coverage\s*:\s*([\d.]+)%")
    _COVERAGE_FUNC_RE = re.compile(r"Functional Cov\s*:\s*([\d.]+)%")
    _ASSERT_TOTAL_RE = re.compile(r"Total assertions checked\s*:\s*(\d+)")
    _ASSERT_PASSED_RE = re.compile(r"Assertions passed\s*:\s*(\d+)")
    _ASSERT_FAILED_RE = re.compile(r"Assertions failed\s*:\s*(\d+)")
    _ASSERT_VAC_RE = re.compile(r"Assertions vacuous\s*:\s*(\d+)")
    _WARNING_RE = re.compile(r"ncelab:\s+\*W,(\w+)\s+\(([^)]+)\):\s+(.+)")
    _ERROR_MSG_RE = re.compile(r"ncelab:\s+\*E,(\w+).*?:\s+(.+)")
    _ELAB_FAIL_RE = re.compile(r"Elaboration failed")

    def parse(self, log_path: str) -> SimulationParseResult | ParseFailure:
        """
        Parse an Xcelium log file.

        Returns:
            SimulationParseResult on success (even partial)
            ParseFailure if the file cannot be read or is empty
        """
        path = Path(log_path)
        if not path.exists():
            return ParseFailure(reason=f"Log file not found: {log_path}")

        try:
            lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        except Exception as e:
            return ParseFailure(reason=f"Cannot read log file: {e}")

        if not lines:
            return ParseFailure(reason="Log file is empty")

        return self._parse_lines(lines, log_path)

    def parse_text(self, text: str) -> SimulationParseResult | ParseFailure:
        """Parse raw log text (useful for testing with fixtures)."""
        lines = text.splitlines()
        if not lines:
            return ParseFailure(reason="Empty text provided")
        return self._parse_lines(lines, source="<text>")

    def _parse_lines(self, lines: list[str], source: str) -> SimulationParseResult:
        result = SimulationParseResult(verdict=SimulationVerdict.UNKNOWN, raw_lines=len(lines))
        current_tc: Optional[str] = None

        for line in lines:
            line = line.strip()
            if not line:
                continue

            # Version
            m = self._VERSION_RE.search(line)
            if m:
                result.xcelium_version = m.group(1)
                continue

            # Simulation start metadata
            m = self._SIM_START_RE.search(line)
            if m:
                result.chip_scope = m.group(1)
                result.seed = int(m.group(2))
                continue

            # Elaboration failure
            if self._ELAB_FAIL_RE.search(line):
                result.verdict = SimulationVerdict.ELABORATION_ERROR
                result.errors.append("Elaboration failed — simulation aborted")
                continue

            # Simulation end verdict
            m = self._SIM_END_RE.search(line)
            if m:
                verdict_str = m.group(1)
                result.verdict = SimulationVerdict(verdict_str)
                continue

            # Test summary counts
            m = self._TESTS_SUMMARY_RE.search(line)
            if m:
                result.tests_run = int(m.group(1))
                continue
            m = self._TESTS_PASSED_RE.search(line)
            if m:
                result.tests_passed = int(m.group(1))
                continue
            m = self._TESTS_FAILED_RE.search(line)
            if m:
                result.tests_failed = int(m.group(1))
                continue

            # CPU time
            m = self._CPU_TIME_RE.search(line)
            if m:
                result.sim_cpu_seconds = float(m.group(1))
                continue

            # Test case results
            m = self._TC_RESULT_RE.search(line)
            if m:
                tc_name = m.group(2)
                tc_result = m.group(1)
                assertions = int(m.group(3))
                failures = int(m.group(4)) if m.group(4) else 0
                result.test_cases.append(TestCaseResult(
                    name=tc_name,
                    result=tc_result,
                    assertions=assertions,
                    failures=failures,
                ))
                continue

            # Coverage
            m = self._COVERAGE_LINE_RE.search(line)
            if m:
                result.coverage.line_pct = float(m.group(1)); continue
            m = self._COVERAGE_BRANCH_RE.search(line)
            if m:
                result.coverage.branch_pct = float(m.group(1)); continue
            m = self._COVERAGE_FSM_RE.search(line)
            if m:
                result.coverage.fsm_pct = float(m.group(1)); continue
            m = self._COVERAGE_TOGGLE_RE.search(line)
            if m:
                result.coverage.toggle_pct = float(m.group(1)); continue
            m = self._COVERAGE_FUNC_RE.search(line)
            if m:
                result.coverage.functional_pct = float(m.group(1)); continue

            # Assertions
            m = self._ASSERT_TOTAL_RE.search(line)
            if m:
                result.assertions.total_checked = int(m.group(1)); continue
            m = self._ASSERT_PASSED_RE.search(line)
            if m:
                result.assertions.passed = int(m.group(1)); continue
            m = self._ASSERT_FAILED_RE.search(line)
            if m:
                result.assertions.failed = int(m.group(1)); continue
            m = self._ASSERT_VAC_RE.search(line)
            if m:
                result.assertions.vacuous = int(m.group(1)); continue

            # Warnings from elaborator
            m = self._WARNING_RE.search(line)
            if m:
                result.warnings.append(ParseWarning(
                    severity="WARNING",
                    location=m.group(2),
                    message=m.group(3).strip(),
                ))
                continue

            # Errors
            m = self._ERROR_MSG_RE.search(line)
            if m:
                result.errors.append(f"[{m.group(1)}] {m.group(2).strip()}")
                continue

        # Post-processing: if verdict still UNKNOWN but we have test results
        if result.verdict == SimulationVerdict.UNKNOWN:
            if result.test_cases:
                result.verdict = (
                    SimulationVerdict.PASS
                    if result.tests_failed == 0 and not result.errors
                    else SimulationVerdict.FAIL
                )
                result.parse_warnings.append(
                    "Verdict inferred from test case results (XCELIUM_SIM_END not found)"
                )
            else:
                result.parse_warnings.append(
                    "Could not determine simulation verdict — log may be incomplete"
                )

        return result
