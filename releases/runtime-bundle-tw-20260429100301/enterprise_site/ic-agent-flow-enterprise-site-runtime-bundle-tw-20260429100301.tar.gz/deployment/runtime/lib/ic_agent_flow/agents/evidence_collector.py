"""
v0.4 First Bounded Agent — Evidence Collector / Verification Triage Agent
=========================================================================
Agent Identity Definition (Phase 1, D1-1)

This is the first formal agent in ic-agent-flow.
Its role is bounded, chip-scoped, and strictly evidence-producing.
It does NOT produce pass verdicts, does NOT accept waivers, and
does NOT continue if chip scope is unresolved.
"""
from __future__ import annotations

from enum import Enum
from typing import List

from pydantic import BaseModel


# ── Agent Identity Constants ───────────────────────────────────────────────────

AGENT_ID = "evidence_collector_v0.4"
AGENT_NAME = "Evidence Collector / Verification Triage Agent"
AGENT_ROLE = "evidence_collector"
AGENT_VERSION = "v0.4.0"

AGENT_MISSION = (
    "Collect raw tool outputs from IC design verification runs, "
    "normalize them into structured evidence objects, "
    "perform initial triage, and prepare human review packages. "
    "This agent does NOT adjudicate design quality or approve releases."
)


# ── Capability Taxonomy ────────────────────────────────────────────────────────

class AgentCapability(str, Enum):
    RECEIVE_CHIP_SCOPED_TASK = "receive_chip_scoped_task"
    RESOLVE_CONTEXT_MANIFEST = "resolve_context_manifest"
    INVOKE_READ_ONLY_CONTRACTS = "invoke_read_only_contracts"
    COLLECT_TOOL_OUTPUTS = "collect_tool_outputs"
    PARSE_AND_NORMALIZE_LOGS = "parse_and_normalize_logs"
    BUILD_ARTIFACT_LINEAGE = "build_artifact_lineage"
    GENERATE_TRIAGE_SUMMARY = "generate_triage_summary"
    SUBMIT_HUMAN_REVIEW_PACKAGE = "submit_human_review_package"
    ESCALATE_ON_AMBIGUITY = "escalate_on_ambiguity"
    INVOKE_COGNITIVE_BACKEND = "invoke_cognitive_backend"


class ProhibitedAction(str, Enum):
    ISSUE_PASS_VERDICT = "issue_pass_verdict"
    BYPASS_VERIFICATION = "bypass_required_verification"
    ACCEPT_WAIVER_FOR_HUMAN = "accept_waiver_or_exception_for_human"
    USE_PROSE_AS_PROMOTION_BASIS = "use_prose_summary_as_promotion_basis"
    EXECUTE_WITHOUT_CHIP_SCOPE = "execute_without_resolved_chip_scope"
    MODIFY_DESIGN_ARTIFACTS = "modify_design_artifacts"
    ESCALATE_OWN_AUTHORITY = "escalate_own_authority_class"


class EscalationCondition(str, Enum):
    CHIP_SCOPE_UNRESOLVED = "chip_scope_unresolved"
    ARTIFACT_MISSING = "artifact_missing"
    PARSE_FAILED = "parse_failed"
    EVIDENCE_INCOMPLETE = "evidence_incomplete"
    AMBIGUOUS_SUBJECT_BINDING = "ambiguous_subject_binding"
    AUTHORITY_INSUFFICIENT = "authority_insufficient"
    COGNITIVE_BACKEND_FAILED = "cognitive_backend_failed"


# ── Agent Identity Contract ────────────────────────────────────────────────────

class AgentIdentity(BaseModel):
    """
    Formal Agent Identity record — the runtime-loadable identity of this agent.
    This is what the orchestrator uses to validate task assignment and enforce constraints.
    """
    agent_id: str = AGENT_ID
    agent_name: str = AGENT_NAME
    role: str = AGENT_ROLE
    version: str = AGENT_VERSION
    mission: str = AGENT_MISSION

    may: List[AgentCapability] = list(AgentCapability)
    may_not: List[ProhibitedAction] = list(ProhibitedAction)
    escalation_conditions: List[EscalationCondition] = list(EscalationCondition)

    output_contracts: List[str] = [
        "execution_run",
        "artifact_ref_set",
        "simulation_result",
        "verification_triage_result",
        "evidence_bundle_ref",
        "human_review_package",
        "escalation_record",
        "cognitive_invocation_audit_record",
    ]

    def can_do(self, capability: AgentCapability) -> bool:
        return capability in self.may

    def is_prohibited(self, action: ProhibitedAction) -> bool:
        return action in self.may_not

    def should_escalate(self, condition: EscalationCondition) -> bool:
        return condition in self.escalation_conditions


# Singleton — load once, use everywhere
EVIDENCE_COLLECTOR_IDENTITY = AgentIdentity()
