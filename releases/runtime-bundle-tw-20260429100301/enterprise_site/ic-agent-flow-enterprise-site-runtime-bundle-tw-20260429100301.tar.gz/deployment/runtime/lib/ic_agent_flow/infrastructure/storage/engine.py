import os
import shutil
from enum import Enum
from typing import Optional, Dict, List
from uuid import UUID
from datetime import datetime, timedelta
from ic_agent_flow.domain.objects import DataClassification

class StorageTier(str, Enum):
    OBJECT = "object"     # Canonical JSONs (metadata)
    ARTIFACT = "artifact" # EDA Outputs (logs, waves) -> HEAVY
    EVIDENCE = "evidence" # bundles, review packages -> PERMANENT

class RetentionClass(str, Enum):
    EPHEMERAL = "ephemeral" # Cache, 1 hour
    PROJECT_LIFECYCLE = "project_lifecycle" # 1 year
    PERMANENT = "permanent" # 10 years (Legal)

class StorageEngine:
    """
    Handles path resolution, directory management, and retention policy
    for the 3-tier storage architecture.
    """
    
    def __init__(self, root_dir: str = "artifacts"):
        self.root = root_dir
        self.paths = {
            StorageTier.OBJECT: os.path.join(self.root, "objects"),
            StorageTier.ARTIFACT: os.path.join(self.root, "raw"),
            StorageTier.EVIDENCE: os.path.join(self.root, "closeouts")
        }
        self._ensure_dirs()
        
    def _ensure_dirs(self):
        for path in self.paths.values():
            os.makedirs(path, exist_ok=True)
            
    def get_retention_class(self, tier: StorageTier, classification: DataClassification) -> RetentionClass:
        """
        Maps Tier + Classification to a Retention Class.
        Logic:
        - Evidence is always PERMANENT.
        - Highly Sensitive Artifacts are EPHEMERAL (Clean up after closeout).
        - Internal Artifacts are PROJECT_LIFECYCLE.
        """
        if tier == StorageTier.EVIDENCE:
            return RetentionClass.PERMANENT
            
        if classification == DataClassification.HIGHLY_SENSITIVE_DESIGN:
            return RetentionClass.EPHEMERAL
            
        return RetentionClass.PROJECT_LIFECYCLE

    def get_path(self, tier: StorageTier, filename: Optional[str] = None) -> str:
        """Returns the absolute or relative path for a specific tier."""
        base = self.paths.get(tier)
        return os.path.join(base, filename) if filename else base
        
    def resolve_object_path(self, object_id: UUID, obj_type: str) -> str:
        """Standardized naming for JSON objects: <type>_<uuid>.json"""
        filename = f"{obj_type}_{object_id}.json"
        return self.get_path(StorageTier.OBJECT, filename)
        
    def resolve_artifact_path(self, job_id: UUID, artifact_name: str) -> str:
        """Standardized naming for job artifacts: job_<job_id>_<name>"""
        filename = f"job_{job_id}_{artifact_name}"
        return self.get_path(StorageTier.ARTIFACT, filename)

    def apply_retention_logic(self, path: str, retention: RetentionClass):
        """
        Mock implementation of retention enforcement.
        In a real system, this would register the path in a GC tracker.
        """
        print(f"STORAGE_ACL: Applying {retention.value} policy to {path}")
        if retention == RetentionClass.PERMANENT:
            # Mock 'immutable' flag
            print(f"STORAGE_LOCK: Path {path} marked as IMMUTABLE/EVIDENCE.")
