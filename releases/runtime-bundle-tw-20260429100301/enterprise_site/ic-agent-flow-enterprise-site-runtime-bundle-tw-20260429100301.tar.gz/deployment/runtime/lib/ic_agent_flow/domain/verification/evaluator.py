from datetime import datetime, timezone
from uuid import uuid4
from typing import Any, Optional
from ic_agent_flow.domain.objects import Producer
from ic_agent_flow.domain.security.guard import SecurityGuard, SecurityViolation
from ic_agent_flow.domain.verification import GateVerdict, Verdict
from ic_agent_flow.domain.contracts import Contract

class ContractEvaluator:
    """Evaluates domain objects against contracts to issue standardized verdicts."""
    
    @staticmethod
    def evaluate(contract: Contract, subject: Any, producer: Optional[Producer] = None) -> GateVerdict:
        """Issues a verdict by matching subject data against contract rules."""
        rationale = f"Evaluated against contract {contract.id} ({contract.name}). "
        verdict_status = Verdict.PASS
        
        # Security Guard Check (Short-circuit on IP violation)
        try:
            subjects = list(subject) if isinstance(subject, tuple) else [subject]
            SecurityGuard.check_access(subjects, contract)
            if producer:
                SecurityGuard.check_producer(subjects, producer)
        except SecurityViolation as e:
            return GateVerdict(
                id=uuid4(),
                subject_ref=str(subject), # Simplified for error
                verdict=Verdict.FAILED,
                gate_type="security_policy_gate",
                evidence_refs=[],
                created_at=datetime.now(timezone.utc),
                rationale=f"SECURITY VIOLATION: {str(e)}"
            )
        except Exception as e:
             # Handle missing classification gracefully in this MVP if needed, 
             # but check_access handles getattr defaults.
             pass
        
        # Line 1: Timing Compliance
        if contract.id == "T-01": 
            slack = subject.summary.get("setup_slack", -1.0)
            if slack < 0:
                verdict_status = Verdict.FAILED
                rationale += f"Setup slack is negative: {slack}ns."
            else:
                rationale += f"Setup slack is positive: {slack}ns."
        
        # Line 1: DRC Cleanliness
        elif contract.id == "D-01":
            status = subject.status
            if status != "CLEAN":
                verdict_status = Verdict.FAILED
                rationale += f"DRC status is {status}, not CLEAN."
            else:
                rationale += "DRC status is CLEAN."
                
        # Line 2: Compilation Status
        elif contract.id == "C-01":
            if subject.status != "SUCCESS" or subject.error_count > 0:
                verdict_status = Verdict.FAILED
                rationale += f"Status is {subject.status}, errors={subject.error_count}."
            else:
                rationale += "Status is SUCCESS, errors=0."
        
        # Line 2: Warning Limit
        elif contract.id == "C-02":
            if subject.warning_count >= 5:
                verdict_status = Verdict.FAILED
                rationale += f"Warnings {subject.warning_count} exceed limit of 5."
            else:
                rationale += f"Warnings {subject.warning_count} within limit."

        # Program E: Lint & CDC
        elif contract.id == "L-01":
            if subject.status != "CLEAN" or subject.error_count > 0:
                verdict_status = Verdict.FAILED
                rationale += f"Lint status is {subject.status}, errors={subject.error_count}."
            else:
                rationale += "Lint status is CLEAN."

        # Program E: Simulation Coverage
        elif contract.id == "S-01":
            if subject.coverage_score < 95.0 or subject.fail_count > 0:
                verdict_status = Verdict.FAILED
                rationale += f"Coverage {subject.coverage_score}% < 95% or has fails."
            else:
                rationale += f"Coverage {subject.coverage_score}% >= 95%."
                
        # Program E: Equivalence Check
        elif contract.id == "E-01":
            if not getattr(subject, "is_equivalent", False):
                verdict_status = Verdict.FAILED
                rationale += f"RTL is NOT equivalent. unmapped={subject.unmapped_points}."
            else:
                rationale += "RTL states are fully equivalent."
                
        # Program F: ECO Locality
        elif contract.id == "ECO-01":
            # subject is ImpactScope
            if len(subject.tainted_nets) > 10:
                verdict_status = Verdict.FAILED
                rationale += f"Tainted nets ({len(subject.tainted_nets)}) exceeds locality limit of 10."
            else:
                rationale += f"Tainted nets ({len(subject.tainted_nets)}) within locality bounds."
                
        # Program F: ECO Legality (Spare Cell Checking)
        elif contract.id == "ECO-02":
            # subject is a tuple of (ImpactScope, SpareCellInventory) in this simplified mock
            impact, inventory = subject
            for cell_type, required_count in impact.required_gates.items():
                available = inventory.gate_counts.get(cell_type, 0)
                if required_count > available:
                    verdict_status = Verdict.FAILED
                    rationale += f"Legality violation: {cell_type} requires {required_count} but only {available} available. "
            if verdict_status == Verdict.PASS:
                rationale += "Spare cell budget is sufficient."
                
        # Program F: ECO Equivalence Requirement
        elif contract.id == "ECO-03":
            # This gate is a structural constraint: the downstream_effect MUST mandate Equivalence.
            rationale += "Equivalence check MUST be bound to downstream adjudication."

                
        subject_ref_str = ""
        if isinstance(subject, tuple):
            subject_ref_str = f"compound:[{','.join([f'{s.type}:{s.id}' for s in subject])}]"
        else:
            subject_ref_str = f"{subject.type}:{subject.id}"

        return GateVerdict(
            id=uuid4(),
            subject_ref=subject_ref_str,
            verdict=verdict_status,
            gate_type="contract_evaluation_gate",
            evidence_refs=[subject_ref_str],
            created_at=datetime.now(timezone.utc),
            rationale=rationale
        )
