from typing import Dict, Any, Optional, List
from uuid import uuid4
from datetime import datetime
from ic_agent_flow.skills.registry import BaseSkill, register_skill
from ic_agent_flow.domain.objects.skill_records import SkillOutputRecord, SkillCognitiveEnvelope
from ic_agent_flow.domain.objects import AuthorityClass, DataClassification, Producer, ProducerType

class ReentryDeltaBuilderSkill(BaseSkill):
    """
    FW-4: Reentry Delta Builder Skill.
    Transforms identified gaps into a proposed execution plan for resubmission.
    """
    
    def execute(
        self, 
        inputs: Dict[str, Any], 
        cognitive_context: Optional[SkillCognitiveEnvelope] = None
    ) -> SkillOutputRecord:
        # Inputs expected: gaps (from FW-3), original_task_id, etc.
        # Logic: 
        # 1. Analyze gaps
        # 2. Suggest tool-path adjustments (e.g. more seeds, longer runtime)
        
        gaps = inputs.get("gaps", [])
        proposed_deltas: List[str] = []
        
        for gap in gaps:
            gap_type = gap.get("gap_type")
            if gap_type == "COVERAGE_HOLE":
                proposed_deltas.append("Increase seed count by 2x for random regression.")
            elif gap_type == "MISSING_ARTIFACT":
                proposed_deltas.append("Verify tool export path and re-run with TRACE_ENABLED=1.")
            else:
                proposed_deltas.append(f"Generic mitigation for {gap_type}")

        advisory_text = "Re-entry Delta Plan: " + (", ".join(proposed_deltas) if proposed_deltas else "No deltas required.")
        if cognitive_context:
            advisory_text += f"\nCognitive Strategy: {cognitive_context.raw_response}"

        return SkillOutputRecord(
            id=uuid4(),
            invocation_id=uuid4(),
            version="v0.1.0",
            authority_class=AuthorityClass.ADVISORY,
            classification=DataClassification.INTERNAL_RESTRICTED,
            producer=Producer(id="reentry_delta_builder_skill", type=ProducerType.AGENT),
            created_at=datetime.now(),
            output_type="reentry_delta",
            output_data={
                "advisory_summary": advisory_text,
                "proposed_deltas": proposed_deltas,
                "target_task_id": inputs.get("original_task_id", "t-unknown")
            },
            decision_attachable=True,
            review_package_eligible=True,
            authority_note="support_only"
        )

# Register the skill
register_skill("reentry_delta_builder", ReentryDeltaBuilderSkill)
