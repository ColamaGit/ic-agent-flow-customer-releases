from enum import Enum
from typing import Dict, List, Optional
from datetime import datetime, timedelta

class RetentionPolicy(Enum):
    PERMANENT = "Permanent"
    EXPIRING_90D = "Expiring (90D)"
    SCRATCH_30D = "Scratch (30D)"
    IMMEDIATE_DELETION = "Immediate Deletion"

class RetentionEngine:
    """
    Enforces compliance between Classification and Storage retention behavior.
    """
    
    POLICY_MAP = {
        "Tier 3": {
            "retention": RetentionPolicy.PERMANENT,
            "egress_allowed": False,
            "visibility": ["Lead", "Auditor"]
        },
        "Tier 2": {
            "retention": RetentionPolicy.EXPIRING_90D,
            "egress_allowed": True,
            "visibility": ["Engineer", "Lead"]
        },
        "Tier 1": {
            "retention": RetentionPolicy.SCRATCH_30D,
            "egress_allowed": True,
            "visibility": ["Public", "Engineer"]
        }
    }

    def get_policy(self, tier: str) -> Dict:
        """Get the specific policy for a given security tier."""
        return self.POLICY_MAP.get(tier, self.POLICY_MAP["Tier 1"])

    def calculate_expiry(self, tier: str, created_at: datetime) -> Optional[datetime]:
        """Determine when a stored object should expire."""
        policy = self.get_policy(tier)
        
        if policy["retention"] == RetentionPolicy.PERMANENT:
            return None
        elif policy["retention"] == RetentionPolicy.EXPIRING_90D:
            return created_at + timedelta(days=90)
        elif policy["retention"] == RetentionPolicy.SCRATCH_30D:
            return created_at + timedelta(days=30)
            
        return created_at

    def validate_egress(self, tier: str, target_destination: str) -> bool:
        """Check if egress is allowed (blocking Tier 3 by default)."""
        policy = self.get_policy(tier)
        if not policy["egress_allowed"] and "external" in target_destination.lower():
            print(f"COMPLIANCE_ERROR: Egress forbidden for {tier} artifacts.")
            return False
        return True
