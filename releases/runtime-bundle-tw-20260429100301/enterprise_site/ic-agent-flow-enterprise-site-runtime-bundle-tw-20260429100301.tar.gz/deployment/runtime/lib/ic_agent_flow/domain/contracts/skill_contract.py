from enum import Enum
from typing import List, Dict, Any
from pydantic import BaseModel, Field
from ..objects import AuthorityClass

class SkillFamily(str, Enum):
    INTERPRETATION = "interpretation"
    TRIAGE = "triage"
    PACKAGING = "packaging"
    GAP_ANALYSIS = "gap_analysis"
    FOLLOWUP = "followup"
    ECO_ASSIST = "eco_assist"

class EDAAgentSkillContract(BaseModel):
    skill_name: str
    skill_version: str
    skill_family: SkillFamily
    purpose: str
    scope_requirements: List[str] = Field(
        default_factory=lambda: ["workspace_id", "chip_id", "task_id"]
    )
    input_schema: Dict[str, Any]
    output_schema: Dict[str, Any]
    allowed_dependencies: List[str] = Field(
        default_factory=lambda: ["canonical_objects", "normalized_outputs", "mcp_artifacts"]
    )
    cognitive_backend_requirement: bool = False
    authority_class: AuthorityClass = AuthorityClass.DERIVED
    decision_loop_compatibility: bool = True
    
    def model_post_init(self, __context: Any) -> None:
        """
        Enforce Design Law 3: Skill Must Not Own Tool Exposure.
        Enforce Design Law 5: Skill Must Respect Cognitive Adapter Boundary.
        """
        if "raw_tool_access" in self.allowed_dependencies or "shell_access" in self.allowed_dependencies:
            raise ValueError("EDA Agent Skill Contract Violation: Direct tool access is forbidden (Law 3).")
        
        # Law 5 is handled by cognitive_backend_requirement flag + runtime adapter
