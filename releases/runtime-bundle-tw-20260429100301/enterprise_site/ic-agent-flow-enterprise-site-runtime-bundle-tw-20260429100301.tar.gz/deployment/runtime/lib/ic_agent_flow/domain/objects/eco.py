from datetime import datetime
from uuid import UUID
from typing import List, Dict, Any, Optional
from pydantic import Field
from ic_agent_flow.domain.objects import BaseObject

class EcoRequest(BaseObject):
    type: str = "eco_request"
    description: str
    target_stage: str
    priority: str = "HIGH"

class RtlDiff(BaseObject):
    type: str = "rtl_diff"
    golden_snapshot_ref: str
    draft_snapshot_ref: str
    diff_hash: str
    changed_modules: List[str]
    metadata: Dict[str, Any] = Field(default_factory=dict)

class SpareCellInventory(BaseObject):
    type: str = "spare_cell_inventory"
    partition_name: str
    gate_counts: Dict[str, int] # e.g. {"NAND2": 5, "INV": 10}
    metadata: Dict[str, Any] = Field(default_factory=dict)

class LegalityChecklist(BaseObject):
    """
    Checklist for ECO legality and feasibility.
    Part of Scenario C: Restricted ECO Readiness Prep.
    """
    type: str = "legality_checklist"
    spare_cells_available: bool
    timing_closure_likely: bool
    conformance_to_eco_rules: bool
    critical_violations: List[str] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)

class ImpactScope(BaseObject):
    type: str = "impact_scope"
    base_diff_ref: str
    tainted_nets: List[str]
    tainted_modules: List[str]
    required_gates: Dict[str, int]
    locality_score: float = Field(default=1.0, description="1.0 = highly localized, 0.0 = widely spread")
    estimated_routes_affected: int = 0
    metadata: Dict[str, Any] = Field(default_factory=dict)
