from typing import List
from datetime import datetime
from ic_agent_flow.context.manifest import ContextManifest
from ic_agent_flow.domain.objects import BaseObject

class ContextAssembler:
    """Assembles a cognitive boundary for a task based on Design Laws."""
    
    def assemble(self, task_type: str, subjects: List[BaseObject], assembler_id: str) -> ContextManifest:
        subject_refs = [f"{s.type}:{s.id}" for s in subjects]
        
        manifest = ContextManifest(
            task_type=task_type,
            subject_refs=subject_refs,
            assembly_time=datetime.utcnow(),
            assembler=assembler_id,
            applied_governance_versions={
                "CONTRACT-CORE": "1.0.0",
                "CONTRACT-ECO": "1.0.0",
                "CHECKPOINT-HITL": "1.0.0"
            }
        )
        return manifest
