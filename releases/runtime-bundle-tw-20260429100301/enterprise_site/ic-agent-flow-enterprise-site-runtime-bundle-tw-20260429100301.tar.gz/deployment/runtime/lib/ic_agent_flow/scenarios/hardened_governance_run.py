import asyncio
import os
from uuid import uuid4
from datetime import datetime, timedelta

from ic_agent_flow.domain.governance.checkpoint import (
    HumanReviewPackage, StageGateType, DecisionEnum, 
    HumanCheckpointRunner, CheckpointPolicy, AuthorityRecord
)
from ic_agent_flow.domain.governance.events import (
    emit_governance_event, LaunchGateRequest, StallEvent
)
from ic_agent_flow.domain.governance.registry import ReadinessRegistry
from ic_agent_flow.domain.utils.time import get_tw_now

async def run_hardened_governance_flow():
    print("🚀 Initializing Hardened Governance Verification...")
    registry = ReadinessRegistry()
    run_id = uuid4()
    
    # 1. Emit Launch Gate Request (Standardized Schema)
    launch_req = LaunchGateRequest(
        run_id=run_id,
        subject_ref="restricted-high-value-eco",
        intent_summary="Verify ECO legality for Tier 3 High-Value IP.",
        security_tier="Tier 3",
        requested_by="automated_orchestrator_01"
    )
    emit_governance_event(launch_req)
    
    # 2. Generate Human Review Package
    package = HumanReviewPackage(
        subject_ref="restricted-high-value-eco",
        gate_type=StageGateType.LAUNCH_APPROVAL,
        summary="Automated agent requesting bounded execution for ECO impact analysis on sensitive IP.",
        open_risks=["Potential for timing slack violation", "Tier 3 IP Boundary access"],
        evidence_links=["lineage://audit/intent_v1.0.json"]
    )
    
    # 3. Emit Stall Event (Standardized Schema)
    stall = StallEvent(
        package_id=package.id,
        reason="Awaiting Human Authorization for Tier 3 Execution",
        severity="CRITICAL",
        timeout_at=get_tw_now() + timedelta(seconds=60)
    )
    emit_governance_event(stall)
    
    # 4. Execute Human Checkpoint (Interactive logic)
    print("\n>>> STALL DETECTED: System paused for Human Review.")
    print(">>> (In a real run, this would be picked up by the Console MVP)")
    
    policy = CheckpointPolicy(timeout_seconds=30)
    decision = HumanCheckpointRunner.execute_checkpoint(package, policy)
    
    # 5. Record Decision & Update Registry
    record = AuthorityRecord(
        gate_type=package.gate_type,
        decision=decision.decision,
        rationale=decision.rationale,
        approver=decision.human_id,
        subject_refs=[package.subject_ref],
        evidence_refs=package.evidence_links
    )
    
    print(f"\nFinal Verdict: {decision.decision.value}")
    
    # Update registry (Simulated)
    registry.process_authority_record(package.subject_ref, record)
    
    print("\n✅ Verification Flow Complete.")

if __name__ == "__main__":
    asyncio.run(run_hardened_governance_flow())
