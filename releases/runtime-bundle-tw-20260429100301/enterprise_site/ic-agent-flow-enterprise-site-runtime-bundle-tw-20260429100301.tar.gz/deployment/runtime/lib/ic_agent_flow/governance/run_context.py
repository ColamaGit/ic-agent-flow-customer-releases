import os
from datetime import datetime

class RunContextFactory:
    @staticmethod
    def get_run_dir(chip_id: str, task_id: str) -> str:
        timestamp = datetime.utcnow().strftime("%Y%m%d-%H%M%S")
        # 修正：物理執行與 Artifacts 存放在 artifacts/runs/，符合治理與資料平面分離
        run_dir = os.path.join("artifacts", "runs", chip_id, task_id, timestamp)
        
        if os.path.exists(run_dir):
            raise FileExistsError(f"ERR_RUN_COLLISION: Directory already exists {run_dir}")
        
        os.makedirs(run_dir, exist_ok=True)
        return run_dir
