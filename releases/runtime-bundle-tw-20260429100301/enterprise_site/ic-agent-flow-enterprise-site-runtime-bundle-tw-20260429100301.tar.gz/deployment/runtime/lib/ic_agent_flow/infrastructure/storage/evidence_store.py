import os
import json
from typing import Any, Dict, Optional

class EvidenceStore:
    """
    Tiered Storage - Layer 3: Evidence Store
    High-integrity store for signoff-relevant data.
    Implements evidence permanence controls.
    """
    
    def __init__(self, base_path: str = "artifacts/storage/evidence"):
        self.base_path = base_path
        os.makedirs(self.base_path, exist_ok=True)

    def put_evidence(self, evidence_id: str, bundle_data: Dict[str, Any], classification: str = "Internal"):
        """Save high-integrity evidence (e.g., CloseoutBundle)."""
        class_dir = os.path.join(self.base_path, classification.replace(" ", "_"))
        os.makedirs(class_dir, exist_ok=True)
        
        target_path = os.path.join(class_dir, f"{evidence_id}.bundle.json")
        
        # Simulation of permanence: If file exists, we don't overwrite easily
        if os.path.exists(target_path) and classification == "Tier 3":
            # In real system, this would be a WORM (Write Once Read Many) policy error.
            print(f"INFRA_WARNING: Attempting to overwrite Tier 3 evidence {evidence_id}. Blocking.")
            return target_path
            
        with open(target_path, "w") as f:
            json.dump(bundle_data, f, indent=2, default=str)
            
        return target_path

    def get_evidence(self, evidence_id: str, classification: str = "Internal") -> Optional[Dict[str, Any]]:
        target_path = os.path.join(self.base_path, classification.replace(" ", "_"), f"{evidence_id}.bundle.json")
        if not os.path.exists(target_path): return None
            
        with open(target_path, "r") as f:
            return json.load(f)
