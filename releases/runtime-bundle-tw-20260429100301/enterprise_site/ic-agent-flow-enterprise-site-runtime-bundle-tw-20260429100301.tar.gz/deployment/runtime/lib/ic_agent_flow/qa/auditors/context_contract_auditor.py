import json
from pathlib import Path
from typing import Dict, List

class ContextContractAuditor:
    """Suite 3: Context & Contract QA Auditor.
    Audits ContextAssembler, Capability usage, Ambiguity stalls, and Contract escalation.
    """
    
    def __init__(self, workspace_root: str):
        self.root = Path(workspace_root)
        self.closeouts_path = self.root / "artifacts" / "closeouts"
        
    def audit_context_integrity(self, bundle_id: str) -> Dict:
        """Checks if ContextManifest for a run contains both SUBJECT and EVIDENCE."""
        results = {
            "auditor": "ContextContractAuditor",
            "check": f"context_integrity_{bundle_id}",
            "verdict": "ACCEPTABLE",
            "findings": []
        }
        
        # Try to find file
        bundle_file = self.closeouts_path / f"bundle_{bundle_id}.json"
        if not bundle_file.exists():
            matching = list(self.closeouts_path.glob(f"*{bundle_id}*"))
            if matching:
                bundle_file = matching[0]
            else:
                results["verdict"] = "INSUFFICIENT_EVIDENCE"
                results["findings"].append(f"Bundle {bundle_id} not found in {self.closeouts_path}.")
                return results
            
        try:
            with open(bundle_file, 'r') as f:
                bundle = json.load(f)
            
            manifest = bundle.get("context_manifest", {})
            subjects = manifest.get("subject_refs", [])
            
            if not subjects:
                results["verdict"] = "LINEAGE_INCOMPLETE"
                results["findings"].append("Missing subject_refs in context manifest.")
            
            # Check for ambiguity stalls
            ambiguities = manifest.get("open_ambiguities", [])
            if ambiguities:
                results["verdict"] = "ACCEPTABLE_WITH_LIMITATIONS"
                results["findings"].append(f"Context contains {len(ambiguities)} open ambiguities.")
                    
        except Exception as e:
            results["verdict"] = "LINEAGE_INCOMPLETE"
            results["findings"].append(f"Parse error: {str(e)}")
            
        return results

if __name__ == "__main__":
    auditor = ContextContractAuditor(".")
    print(json.dumps(auditor.audit_context_integrity("family-3-eco"), indent=2))
