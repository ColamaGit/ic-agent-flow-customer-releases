from datetime import datetime, timezone, timedelta

# Standard Taiwan Time Zone (UTC+08:00)
TW_TZ = timezone(timedelta(hours=8))

def get_tw_now() -> datetime:
    """Returns the current datetime in Taiwan Standard Time."""
    return datetime.now(TW_TZ)

def format_tw_timestamp(dt: datetime) -> str:
    """Formats a datetime object into a localized ISO 8601 string."""
    if dt.tzinfo is None:
        # If naive, assume it was intended as TW time but fix it
        dt = dt.replace(tzinfo=TW_TZ)
    return dt.isoformat()
