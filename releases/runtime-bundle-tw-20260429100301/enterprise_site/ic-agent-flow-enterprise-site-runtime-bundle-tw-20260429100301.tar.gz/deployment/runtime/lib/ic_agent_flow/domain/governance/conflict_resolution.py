"""
Conflict & Escalation Router (v0.5, PRD R6)
========================================
Handles logic for detecting decision conflicts and routing to escalation.
"""
from __future__ import annotations

import logging
from typing import List, Optional

from ic_agent_flow.domain.objects.decision_objects import ConflictType, DecisionConflictRecord
from ic_agent_flow.domain.objects.human_review import HumanDecisionRecord

logger = logging.getLogger(__name__)


class ConflictDetector:
    """
    PRD R6: Decision Conflict Handling.
    """

    @staticmethod
    def detect_conflicts(records: List[HumanDecisionRecord]) -> Optional[DecisionConflictRecord]:
        """
        Detects if multiple decisions for the same bundle are inconsistent.
        Minimal implementation: detect mismatch in DecisionEnum values.
        """
        if not records or len(records) < 2:
            return None

        # Check if all decisions are identical
        decisions = {r.decision for r in records}
        if len(decisions) > 1:
            logger.warning(f"Conflict detected between decisions: {decisions}")
            return DecisionConflictRecord(
                bundle_id=records[0].bundle_id,
                chip_scope=records[0].chip_scope,
                conflicting_decision_record_ids=[r.record_id for r in records],
                conflict_type=ConflictType.DECISION_MISMATCH,
            )
        
        return None


class EscalationRouter:
    """
    Routes conflicts or manual escalations to higher authority.
    """

    @staticmethod
    def route_to_higher_authority(conflict: DecisionConflictRecord) -> str:
        """
        Returns the human_id of the next-level authority (e.g., Governance Admin).
        """
        # In a real system, this would lookup a role registry.
        return "governance_admin_team"
