"""
Simulation Result Object (Phase 2, D2-5)
=========================================
Machine-usable evidence object produced by parsing & normalizing
a real Xcelium simulation log.

Authority: DERIVED — always produced from a real ArtifactRef via XceliumLogParser.
           Never hand-crafted. Never asserted without parser provenance.
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import List, Optional

from ic_agent_flow.domain.objects.artifact_ref import ArtifactRef
from ic_agent_flow.domain.objects.failure_taxonomy import (
    FailureCategory,
    FailureRecord,
    FailureSeverity,
)


class SimulationVerdict(str, Enum):
    """Final verdict of the simulation run."""
    PASS = "PASS"
    FAIL = "FAIL"
    INCOMPLETE = "INCOMPLETE"
    ELABORATION_ERROR = "ELABORATION_ERROR"
    UNKNOWN = "UNKNOWN"


@dataclass
class CoverageSnapshot:
    """Coverage metrics snapshot from the simulation run."""
    line_pct: Optional[float] = None
    branch_pct: Optional[float] = None
    fsm_pct: Optional[float] = None
    toggle_pct: Optional[float] = None
    functional_pct: Optional[float] = None

    @property
    def average_pct(self) -> Optional[float]:
        values = [v for v in [
            self.line_pct, self.branch_pct,
            self.fsm_pct, self.toggle_pct, self.functional_pct,
        ] if v is not None]
        return round(sum(values) / len(values), 2) if values else None

    def meets_threshold(self, threshold: float = 80.0) -> bool:
        avg = self.average_pct
        return avg is not None and avg >= threshold


@dataclass
class AssertionSummary:
    """Summary of assertion checking results."""
    total_checked: int = 0
    passed: int = 0
    failed: int = 0
    vacuous: int = 0

    @property
    def pass_rate_pct(self) -> Optional[float]:
        if self.total_checked == 0:
            return None
        return round(self.passed / self.total_checked * 100, 2)


@dataclass
class SimulationResult:
    """
    Canonical Simulation Result object (D2-5).

    This is the machine-usable evidence form of a simulation run.
    It is always chip-scoped and always traceable to a raw artifact.
    """
    result_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    chip_scope: str = ""                         # REQUIRED — chip identity binding
    workspace_id: str = "default-workspace"

    # Verdict
    verdict: SimulationVerdict = SimulationVerdict.UNKNOWN

    # Test summary
    tests_run: int = 0
    tests_passed: int = 0
    tests_failed: int = 0

    # Coverage
    coverage: CoverageSnapshot = field(default_factory=CoverageSnapshot)

    # Assertions
    assertions: AssertionSummary = field(default_factory=AssertionSummary)

    # Failure records (classified)
    failure_records: List[FailureRecord] = field(default_factory=list)

    # Warnings (non-blocking)
    warning_count: int = 0
    warning_messages: List[str] = field(default_factory=list)

    # Simulation metadata
    sim_cpu_seconds: Optional[float] = None
    seed: Optional[int] = None
    xcelium_version: Optional[str] = None

    # Provenance — MUST reference the raw artifact
    source_artifact: Optional[ArtifactRef] = None

    # Timestamps
    produced_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    @property
    def is_pass(self) -> bool:
        return self.verdict == SimulationVerdict.PASS

    @property
    def is_fail(self) -> bool:
        return self.verdict in {
            SimulationVerdict.FAIL,
            SimulationVerdict.ELABORATION_ERROR,
        }

    @property
    def has_critical_failures(self) -> bool:
        return any(f.blocks_promotion for f in self.failure_records)

    @property
    def requires_human_review(self) -> bool:
        """True if any failure requires human adjudication."""
        return self.is_fail or any(f.requires_human_review for f in self.failure_records)

    @classmethod
    def from_parser_result(
        cls,
        parsed,      # SimulationParseResult from xcelium_parser
        chip_scope: str,
        source_artifact: Optional[ArtifactRef] = None,
        workspace_id: str = "default-workspace",
    ) -> "SimulationResult":
        """
        Produce a SimulationResult from XceliumLogParser output.
        This is the canonical bridge between parser output and domain object.
        """
        # Map verdict
        from ic_agent_flow.adapters.parsers.xcelium_parser import SimulationVerdict as PV
        verdict_map = {
            PV.PASS: SimulationVerdict.PASS,
            PV.FAIL: SimulationVerdict.FAIL,
            PV.INCOMPLETE: SimulationVerdict.INCOMPLETE,
            PV.ELABORATION_ERROR: SimulationVerdict.ELABORATION_ERROR,
            PV.UNKNOWN: SimulationVerdict.UNKNOWN,
        }

        # Map coverage
        coverage = CoverageSnapshot(
            line_pct=parsed.coverage.line_pct,
            branch_pct=parsed.coverage.branch_pct,
            fsm_pct=parsed.coverage.fsm_pct,
            toggle_pct=parsed.coverage.toggle_pct,
            functional_pct=parsed.coverage.functional_pct,
        )

        # Map assertions
        assertions = AssertionSummary(
            total_checked=parsed.assertions.total_checked,
            passed=parsed.assertions.passed,
            failed=parsed.assertions.failed,
            vacuous=parsed.assertions.vacuous,
        )

        # Classify failures from parser errors + assertion failures
        failure_records: List[FailureRecord] = []

        for error in parsed.errors:
            if "Elaboration failed" in error:
                cat = FailureCategory.ELABORATION_ERROR
                sev = FailureSeverity.CRITICAL
            elif "DATA_INTEGRITY" in error or "ASSERTFAIL" in error:
                cat = FailureCategory.DATA_INTEGRITY_VIOLATION
                sev = FailureSeverity.CRITICAL
            elif "PORTCNT" in error or "width" in error.lower():
                cat = FailureCategory.PORT_WIDTH_MISMATCH
                sev = FailureSeverity.HIGH
            else:
                cat = FailureCategory.UNKNOWN
                sev = FailureSeverity.HIGH

            failure_records.append(FailureRecord(
                category=cat,
                severity=sev,
                message=error,
                raw_text=error,
            ))

        if parsed.assertions.failed > 0:
            failure_records.append(FailureRecord(
                category=FailureCategory.ASSERTION_FAILURE,
                severity=FailureSeverity.CRITICAL,
                message=f"{parsed.assertions.failed} assertion(s) failed",
            ))

        for tc in parsed.test_cases:
            if tc.result in {"FAIL", "ERROR"}:
                failure_records.append(FailureRecord(
                    category=FailureCategory.TEST_CASE_FAILURE,
                    severity=FailureSeverity.HIGH,
                    message=f"Test case failed: {tc.name}",
                    test_case=tc.name,
                ))

        # Coverage classification
        if coverage.average_pct is not None and not coverage.meets_threshold(80.0):
            failure_records.append(FailureRecord(
                category=FailureCategory.COVERAGE_INSUFFICIENT,
                severity=FailureSeverity.MEDIUM,
                message=f"Coverage below 80% threshold: {coverage.average_pct}%",
            ))

        return cls(
            chip_scope=chip_scope,
            workspace_id=workspace_id,
            verdict=verdict_map.get(parsed.verdict, SimulationVerdict.UNKNOWN),
            tests_run=parsed.tests_run,
            tests_passed=parsed.tests_passed,
            tests_failed=parsed.tests_failed,
            coverage=coverage,
            assertions=assertions,
            failure_records=failure_records,
            warning_count=len(parsed.warnings),
            warning_messages=[f"[{w.location}] {w.message}" for w in parsed.warnings],
            sim_cpu_seconds=parsed.sim_cpu_seconds,
            seed=parsed.seed,
            xcelium_version=parsed.xcelium_version,
            source_artifact=source_artifact,
        )
