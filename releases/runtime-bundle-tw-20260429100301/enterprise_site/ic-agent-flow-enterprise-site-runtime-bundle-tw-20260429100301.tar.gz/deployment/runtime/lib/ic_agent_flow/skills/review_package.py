from typing import Dict, Any, Optional, List
from uuid import uuid4
from datetime import datetime
from ic_agent_flow.skills.registry import BaseSkill, register_skill
from ic_agent_flow.domain.objects.skill_records import SkillOutputRecord, SkillCognitiveEnvelope
from ic_agent_flow.domain.objects import AuthorityClass, DataClassification, Producer, ProducerType
from ic_agent_flow.domain.objects.human_review import HumanReviewPackageBuilder
from ic_agent_flow.domain.objects.evidence_bundle import EvidenceBundleRef

class ReviewPackageBuilderSkill(BaseSkill):
    """
    FW-2: Decision-Loop Bridge Skill.
    Assembles HumanReviewPackage and injects Skill Advisories.
    """
    
    def execute(
        self, 
        inputs: Dict[str, Any], 
        cognitive_context: Optional[SkillCognitiveEnvelope] = None
    ) -> SkillOutputRecord:
        # Inputs expected: bundle (EvidenceBundleRef), skill_advisories (List[SkillOutputRecord])
        bundle: EvidenceBundleRef = inputs.get("bundle")
        advisories: List[SkillOutputRecord] = inputs.get("skill_advisories", [])
        
        if not bundle:
            raise ValueError("ReviewPackageBuilderSkill requires a 'bundle' input.")
        
        # Build base package
        package = HumanReviewPackageBuilder.build(bundle)
        
        # Inject Skill Advisories into Layer B
        if advisories:
            for adv in advisories:
                package.layer_b_support.append(f"skill_output:{adv.invocation_id} ({adv.output_type})")
                
                # Append to Layer B section of summary
                output_data = adv.output_data
                summary = output_data.get("advisory_summary", "No summary available")
                package.summary += f"\n* [{adv.producer.id}] {summary}"
                
                # If triage suggested risk mitigation, add to open risks
                if output_data.get("risk_mitigation_suggested"):
                    package.open_risks.append(f"🚩 Skill Warning: Mitigation suggested by {adv.producer.id}")

        return SkillOutputRecord(
            id=uuid4(),
            invocation_id=uuid4(),
            version="v0.1.0",
            authority_class=AuthorityClass.OPERATIONAL_SUPPORT,
            classification=DataClassification.INTERNAL_RESTRICTED,
            producer=Producer(id="review_package_skill", type=ProducerType.AGENT),
            created_at=datetime.now(),
            output_type="package",
            output_data={
                "package_id": str(package.id),
                "summary_length": len(package.summary),
                "advisory_count": len(advisories)
            },
            decision_attachable=True,
            review_package_eligible=False
        )

# Register the skill
register_skill("review_package_builder", ReviewPackageBuilderSkill)
