"""
Decision Artifact Security (v0.5, PRD R7)
========================================
Implements baseline protection for decision-sensitive artifacts.
"""
from __future__ import annotations

import hashlib
import hmac
import json
from typing import Any, Dict


class IntegrityError(Exception):
    """Raised when artifact integrity verification fails."""
    pass


class DecisionArtifactProtector:
    """
    PRD R7/AC8: baseline at-rest protection (HMAC-SHA256).
    Ensures decision records cannot be tampered with.
    """

    @staticmethod
    def calculate_signature(data: Dict[str, Any], secret_key: str) -> str:
        """
        Calculates HMAC-SHA256 signature of canonical JSON representation.
        """
        # Canonical sort for consistent hashing
        canonical_json = json.dumps(data, sort_keys=True).encode("utf-8")
        signature = hmac.new(
            secret_key.encode("utf-8"), 
            canonical_json, 
            hashlib.sha256
        ).hexdigest()
        return signature

    @staticmethod
    def sign_artifact(data: Dict[str, Any], secret_key: str) -> Dict[str, Any]:
        """
        Adds a governance signature to the artifact.
        """
        data["gov_signature"] = DecisionArtifactProtector.calculate_signature(data, secret_key)
        return data

    @staticmethod
    def verify_artifact(data: Dict[str, Any], secret_key: str) -> bool:
        """
        Verifies the governance signature. Raises IntegrityError if mismatch.
        """
        if "gov_signature" not in data:
            raise IntegrityError("Artifact is missing governance signature.")
        
        sig_to_verify = data.pop("gov_signature")
        expected_sig = DecisionArtifactProtector.calculate_signature(data, secret_key)
        
        if not hmac.compare_digest(sig_to_verify, expected_sig):
            raise IntegrityError("Artifact tampered! Signature mismatch.")
        
        return True


class AuditRetentionPolicy:
    """PRD R7: Audit retention baseline."""
    MINIMUM_RETENTION_DAYS: int = 365
    
    # Fields that MUST be present and immutable for audit
    REQUIRED_AUDIT_FIELDS = {
        "record_id", "decision", "human_id", "decided_at", "role_id"
    }
