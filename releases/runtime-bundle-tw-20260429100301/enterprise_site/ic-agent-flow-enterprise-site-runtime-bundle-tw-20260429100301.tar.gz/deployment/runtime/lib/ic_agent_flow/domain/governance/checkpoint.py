from enum import Enum
from datetime import datetime
from uuid import uuid4
from typing import List, Optional, Any
import sys
import select

from pydantic import BaseModel, Field, UUID4

from ic_agent_flow.domain.utils.time import get_tw_now

class DecisionEnum(str, Enum):
    APPROVE = "APPROVE"
    APPROVE_WITH_CONDITIONS = "APPROVE_WITH_CONDITIONS"
    HOLD = "HOLD"
    REJECT = "REJECT"
    REQUEST_MORE_EVIDENCE = "REQUEST_MORE_EVIDENCE"
    TIMEOUT_HOLD = "TIMEOUT_HOLD"
    ESCALATE = "ESCALATE"

class RoleEnum(str, Enum):
    OPERATOR = "OPERATOR"
    REVIEWER = "REVIEWER"
    APPROVER = "APPROVER"
    AUDITOR = "AUDITOR"
    GOVERNANCE_ADMIN = "GOVERNANCE_ADMIN"

class RolePermission(BaseModel):
    can_view: bool = True
    can_review: bool = False
    can_approve: bool = False
    can_escalate: bool = False
    can_audit: bool = False
    can_admin_roles: bool = False

# PRD R5: Multi-role authority matrix
AUTHORITY_MATRIX = {
    RoleEnum.OPERATOR: RolePermission(can_view=True),
    RoleEnum.REVIEWER: RolePermission(can_view=True, can_review=True, can_escalate=True),
    RoleEnum.APPROVER: RolePermission(can_view=True, can_review=True, can_approve=True, can_escalate=True),
    RoleEnum.AUDITOR: RolePermission(can_view=True, can_audit=True),
    RoleEnum.GOVERNANCE_ADMIN: RolePermission(
        can_view=True, can_review=True, can_approve=True, 
        can_escalate=True, can_audit=True, can_admin_roles=True
    ),
}

class StageGateType(str, Enum):
    LAUNCH_APPROVAL = "LAUNCH_APPROVAL"
    ARTIFACT_REVIEW = "ARTIFACT_REVIEW"
    EXCEPTION_ACCEPTANCE = "EXCEPTION_ACCEPTANCE"
    PROMOTION_SIGN_OFF = "PROMOTION_SIGN_OFF"

class HumanReviewPackage(BaseModel):
    """
    Structured data package containing all evidence and risks for a human checkpoint.
    PRD Phase 3: Forced Source Stratification.
    """
    id: UUID4 = Field(default_factory=uuid4)
    subject_ref: str
    gate_type: StageGateType
    summary: str
    decision_options: List[DecisionEnum] = [
        DecisionEnum.APPROVE,
        DecisionEnum.APPROVE_WITH_CONDITIONS,
        DecisionEnum.HOLD,
        DecisionEnum.REJECT,
        DecisionEnum.REQUEST_MORE_EVIDENCE,
        DecisionEnum.ESCALATE
    ]
    
    # Layered Source Stratification
    layer_a_evidence: List[str] = []   # Raw / Normalized Truth
    layer_b_support: List[str] = []    # Skill-produced support materials
    layer_c_history: List[str] = []    # Human decision artifacts / history

    evidence_links: List[str] = []     # Legacy support
    open_risks: List[str] = []
    created_at: datetime = Field(default_factory=get_tw_now)

class CheckpointPolicy(BaseModel):
    timeout_seconds: int = 60
    default_timeout_decision: DecisionEnum = DecisionEnum.TIMEOUT_HOLD

class HumanDecision(BaseModel):
    id: UUID4 = Field(default_factory=uuid4)
    package_id: Optional[UUID4] = None
    role_id: RoleEnum = RoleEnum.OPERATOR
    decision: DecisionEnum
    rationale: str
    human_id: str
    timestamp: datetime = Field(default_factory=get_tw_now)
    is_timeout: bool = False
    conditions: List[str] = []

class AuthorityRecord(BaseModel):
    """
    The formal digital record of a human's decision at a specific stage gate.
    Serves as first-class evidence in the CloseoutBundle.
    """
    id: UUID4 = Field(default_factory=uuid4)
    gate_type: StageGateType
    decision: DecisionEnum
    rationale: str
    approver: str
    role_id: Optional[RoleEnum] = None
    subject_refs: List[str] = []
    evidence_refs: List[str] = []
    created_at: datetime = Field(default_factory=get_tw_now)

class HumanCheckpointRunner:
    """Provides a live mechanism to wait for formal human sign-off on a Review Package."""

    @staticmethod
    def execute_checkpoint(
        package: HumanReviewPackage, 
        policy: CheckpointPolicy, 
        human_id: str = "local_operator_01",
        role_id: RoleEnum = RoleEnum.OPERATOR
    ) -> HumanDecision:
        
        # Pre-check: Does this role have ANY review/approve permission?
        permissions = AUTHORITY_MATRIX.get(role_id, RolePermission())
        
        print("\n" + "="*60)
        print("🚨 HUMAN AUTHORITY CHECKPOINT 🚨")
        print("="*60)
        print(f"Package ID: {package.id}")
        print(f"Subject: {package.subject_ref}")
        print(f"Gate Type: {package.gate_type}")
        print(f"Operator: {human_id} ({role_id.value})")
        print(f"\n[Summary]\n{package.summary}")
        
        if package.open_risks:
            print("\n[Open Risks]")
            for r in package.open_risks:
                print(f" - {r}")
                
        print("-" * 60)
        
        # Filter decisions based on RBAC
        allowed_decisions = []
        for d in package.decision_options:
            if d == DecisionEnum.APPROVE and not permissions.can_approve:
                continue
            if d == DecisionEnum.APPROVE_WITH_CONDITIONS and not permissions.can_approve:
                continue
            if d == DecisionEnum.ESCALATE and not permissions.can_escalate:
                continue
            # Anyone can HOLD/REJECT/REQUEST_MORE if they can review
            if not permissions.can_review and d in {DecisionEnum.HOLD, DecisionEnum.REJECT, DecisionEnum.REQUEST_MORE_EVIDENCE}:
                continue
            allowed_decisions.append(d)

        print(f"Allowed Decisions for your Role: {', '.join([d.value for d in allowed_decisions])}")
        
        if not allowed_decisions:
            print("❌ Access Denied: Your role has no decision authority for this package.")
            return HumanDecision(
                decision=DecisionEnum.HOLD,
                rationale=f"Access Denied: Role {role_id.value} cannot perform decisions.",
                human_id=human_id,
                role_id=role_id,
                is_timeout=False
            )

        print(f"Timeout: {policy.timeout_seconds} seconds -> Default: {policy.default_timeout_decision.value}")
        print("="*60)
        
        print(f"\nPlease enter your decision [A=Approve, H=Hold, R=Reject, M=More Evidence, E=Escalate]: ", end="", flush=True)

        i, o, e = select.select([sys.stdin], [], [], policy.timeout_seconds)

        if (i):
            choice = sys.stdin.readline().strip().upper()
            decision_map = {
                "A": DecisionEnum.APPROVE,
                "H": DecisionEnum.HOLD,
                "R": DecisionEnum.REJECT,
                "M": DecisionEnum.REQUEST_MORE_EVIDENCE,
                "E": DecisionEnum.ESCALATE
            }
            
            final_decision = decision_map.get(choice, DecisionEnum.HOLD)
            
            # Re-verify allowed
            if final_decision not in allowed_decisions:
                print(f"❌ Policy Violation: Role {role_id.value} is not allowed to perform {final_decision.value}")
                final_decision = DecisionEnum.HOLD
                rationale = f"Policy Violation: Attempted {choice} without authority."
            else:
                rationale_prompt = f"Enter rationale for {final_decision.value}: "
                print(rationale_prompt, end="", flush=True)
                rationale_i, _, _ = select.select([sys.stdin], [], [], 30)
                if rationale_i:
                    rationale = sys.stdin.readline().strip()
                else:
                    rationale = "No rationale provided within prompt timeout."

            return HumanDecision(
                decision=final_decision,
                role_id=role_id,
                rationale=rationale if rationale else "Manual input recorded.",
                human_id=human_id,
                is_timeout=False
            )
        else:
            print("\n[TIMEOUT REACHED] No human response detected.")
            return HumanDecision(
                decision=policy.default_timeout_decision,
                role_id=role_id,
                rationale=f"Timeout reached after {policy.timeout_seconds}s. Fail-closed safety engaged.",
                human_id="system_timeout_handler",
                is_timeout=True
            )
