"""
Cognitive Backend Adapter — Schema Layer (Layer 2: Logical Contract)
=====================================================================
Defines the provider-agnostic data contracts for all cognitive operations.
These schemas are the boundary between agent logic and backend diversity.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


# ── Enumerations ──────────────────────────────────────────────────────────────

class BackendCategory(str, Enum):
    """Canonical backend taxonomy (Law 2)."""
    MODEL_STYLE = "model_style"
    MANAGED_AGENT_STYLE = "managed_agent_style"


class BackendProvider(str, Enum):
    """Canonical provider identifiers."""
    LOCAL_MOCK = "local_mock"
    GEMINI = "gemini"
    VERTEX_AI = "vertex_ai"      # reserved
    BEDROCK = "bedrock"          # reserved
    OPENAI = "openai"            # reserved


class BackendPolicy(str, Enum):
    """Routing policy families (Law 5)."""
    LOCAL_ONLY = "local_only"
    REMOTE_ALLOWED_WITH_CONTROLS = "remote_allowed_with_controls"


class SensitivityLevel(str, Enum):
    """Data sensitivity class for redaction gate."""
    PUBLIC = "public"
    INTERNAL = "internal"
    RESTRICTED = "restricted"       # Requires redaction before remote
    CONFIDENTIAL = "confidential"   # local_only


class ResponseType(str, Enum):
    """Normalized response classification."""
    TEXT = "text"
    TOOL_CALL = "tool_call"
    REFUSAL = "refusal"
    ERROR = "error"


# ── Request Schema ─────────────────────────────────────────────────────────────

class CognitiveRequest(BaseModel):
    """
    Issued by an Agent to the Cognitive Adapter.
    Encapsulates intent, chip scope, and sensitivity declaration.
    """
    request_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    agent_id: str
    chip_scope: str                          # e.g. "legacy-chip-v0.1"
    task_type: str                           # e.g. "simulation_triage"
    prompt: str
    system_context: Optional[str] = None
    sensitivity: SensitivityLevel = SensitivityLevel.INTERNAL
    policy: BackendPolicy = BackendPolicy.REMOTE_ALLOWED_WITH_CONTROLS
    preferred_provider: Optional[BackendProvider] = None
    max_tokens: int = 2048
    temperature: float = 0.2
    metadata: Dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


# ── Selection Schema ───────────────────────────────────────────────────────────

class BackendSelection(BaseModel):
    """Records the matchmaking decision for a specific backend."""
    request_id: str
    selected_provider: BackendProvider
    selected_category: BackendCategory
    selection_reason: str
    policy_rule_applied: BackendPolicy
    redaction_applied: bool = False
    fallback_used: bool = False


# ── Response Envelope ──────────────────────────────────────────────────────────

class CognitiveResponse(BaseModel):
    """
    Normalized response envelope (Law 3).
    Shields agent decision chain from provider-specific structures.
    """
    request_id: str
    response_type: ResponseType
    content: str                             # Normalized text output
    provider: BackendProvider
    model_id: str
    usage_input_tokens: Optional[int] = None
    usage_output_tokens: Optional[int] = None
    refusal_reason: Optional[str] = None
    error_message: Optional[str] = None
    raw_metadata: Dict[str, Any] = Field(default_factory=dict)
    responded_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    @property
    def is_success(self) -> bool:
        return self.response_type == ResponseType.TEXT

    @property
    def is_error(self) -> bool:
        return self.response_type == ResponseType.ERROR


# ── Audit Record ──────────────────────────────────────────────────────────────

class CognitiveAuditRecord(BaseModel):
    """
    Immutable governance evidence for every cognitive invocation (Law 4).
    Provider-agnostic: reviewers read the same structure regardless of backend.
    """
    audit_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    request_id: str
    agent_id: str
    chip_scope: str
    task_type: str
    provider: BackendProvider
    category: BackendCategory
    policy_applied: BackendPolicy
    routing_reason: str
    redaction_applied: bool
    response_type: ResponseType
    success: bool
    latency_ms: Optional[float] = None
    input_tokens: Optional[int] = None
    output_tokens: Optional[int] = None
    error_message: Optional[str] = None
    recorded_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
