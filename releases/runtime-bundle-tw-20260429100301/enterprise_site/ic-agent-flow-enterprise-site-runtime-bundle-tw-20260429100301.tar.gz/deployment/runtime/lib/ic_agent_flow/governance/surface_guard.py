from typing import Dict, Any

class SurfaceGuard:
    @staticmethod
    def validate_surface_state(evidence_status: str) -> bool:
        """
        若底層 evidence status 為 TRUTH_DEPRECATED，則衍生層禁止顯示
        """
        return evidence_status != "TRUTH_DEPRECATED"
