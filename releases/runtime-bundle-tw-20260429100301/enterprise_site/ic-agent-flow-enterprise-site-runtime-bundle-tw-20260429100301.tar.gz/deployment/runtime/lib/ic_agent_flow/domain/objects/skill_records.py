from datetime import datetime
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field, UUID4
from . import BaseObject, Producer, AuthorityClass, DataClassification
import os
import json
from pathlib import Path

class SkillCognitiveEnvelope(BaseModel):
    """
    Structured envelope for cognitive results injected into Skills.
    Prevents Skills from direct backend access (Law 5).
    """
    invocation_id: UUID4
    raw_response: str
    structured_data: Dict[str, Any] = Field(default_factory=dict)
    prompt_metadata: Dict[str, Any] = Field(default_factory=dict)
    backend_provider: str
    suggested_advisory_class: AuthorityClass = AuthorityClass.ADVISORY
    latency_ms: Optional[int] = None

class SkillInvocationRecord(BaseModel):
    invocation_id: UUID4
    skill_name: str
    skill_version: str
    workspace_id: str
    chip_id: str
    task_id: str
    input_refs: List[str]
    context_manifest_ref: Optional[str] = None
    invoked_at: datetime = Field(default_factory=datetime.now)
    invoker: Producer
    status: str = "PENDING"

    def persist(self, project_root: str) -> str:
        """
        Persist invocation to chips/<chip>/evidence/skills/<inv_id>/invocation.json
        """
        base_dir = Path(project_root) / "chips" / self.chip_id / "evidence" / "skills" / str(self.invocation_id)
        base_dir.mkdir(parents=True, exist_ok=True)
        
        path = base_dir / "invocation.json"
        path.write_text(self.model_dump_json(indent=2))
        return str(path)

class SkillOutputRecord(BaseObject):
    """
    EDA Agent Skill Output Envelope.
    Law 6: Skill Output Is Derived by Default.
    PRD Phase 3: Authority Hardening & Attachment Metadata.
    """
    type: str = "skill_output"
    invocation_id: UUID4
    output_type: str  # e.g., 'triage', 'package', 'gap_analysis'
    output_data: Dict[str, Any]
    
    # Attachment Controls (Attachment Matrix Gate keepers)
    decision_attachable: bool = False
    review_package_eligible: bool = False
    
    # Provenance Refs
    trace_ref: Optional[str] = None
    authority_note: Optional[str] = None  # e.g., "support_only"

    def persist(self, project_root: str, chip_id: str) -> str:
        """
        Persist output to chips/<chip>/evidence/skills/<inv_id>/output.json
        """
        base_dir = Path(project_root) / "chips" / chip_id / "evidence" / "skills" / str(self.invocation_id)
        base_dir.mkdir(parents=True, exist_ok=True)
        
        path = base_dir / "output.json"
        path.write_text(self.model_dump_json(indent=2))
        return str(path)

class SkillTraceRecord(BaseModel):
    """
    Trace for skill interpretation reasoning.
    Law 8: Skill Must Be Replayable.
    """
    trace_id: UUID4
    invocation_id: UUID4
    input_refs: List[str]
    normalized_refs: List[str]
    backend_route_ref: Optional[str] = None  # Reference to Cognitive Adapter route
    trace_digest: str
    created_at: datetime = Field(default_factory=datetime.now)

class SkillGapRecord(BaseModel):
    """
    Record of evidence/artifact gaps identified by a skill.
    """
    gap_id: UUID4
    invocation_id: UUID4
    gap_type: str
    gap_description: str
    required_next_action: str
    blocking_severity: str = "MEDIUM"
    related_refs: List[str] = []

class SkillPackageRecord(BaseModel):
    """
    Support package assembled by a skill for human review.
    """
    package_id: UUID4
    invocation_id: UUID4
    package_type: str
    included_refs: List[str]
    package_digest: str
    decision_context_ref: Optional[str] = None
