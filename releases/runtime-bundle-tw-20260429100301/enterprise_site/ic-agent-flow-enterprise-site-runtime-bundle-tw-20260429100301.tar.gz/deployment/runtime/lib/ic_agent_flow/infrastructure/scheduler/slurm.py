import asyncio
import os
from uuid import uuid4
from typing import List, Optional, Dict
from ic_agent_flow.infrastructure.job_model import JobRecord, JobStatus
from ic_agent_flow.infrastructure.scheduler.base import AbstractScheduler

class SlurmJobAdapter(AbstractScheduler):
    """
    Skeleton implementation for Slurm HPC scheduler.
    Simulates sbatch/squeue/scancel interaction for architectural validation.
    """
    
    def __init__(self, cluster_name: str = "ic_hpc_prod"):
        self.cluster_name = cluster_name
        self._jobs: Dict[str, JobRecord] = {}

    async def submit(self, command: List[str], run_id: str, working_dir: str) -> JobRecord:
        job_id = f"slurm_{uuid4().hex[:8]}"
        slurm_id = f"{100000 + len(self._jobs)}"
        
        print(f"INFRA_SIM: Executing 'sbatch --job-name={job_id} {command[0]}' on {self.cluster_name}")
        
        job = JobRecord(
            job_id=job_id,
            run_id=run_id,
            status=JobStatus.SUBMITTED,
            command=command,
            working_dir=working_dir,
            pid=int(slurm_id), # Mocking SLURM JobID as PID for now
            metadata={"cluster": self.cluster_name, "slurm_job_id": slurm_id}
        )
        job.transition_to(JobStatus.QUEUED, f"Job queued in partition 'normal' as {slurm_id}")
        
        self._jobs[job_id] = job
        return job

    async def poll(self, job_id: str) -> JobRecord:
        if job_id not in self._jobs:
            raise ValueError(f"Job {job_id} unknown")
            
        job = self._jobs[job_id]
        if job.status == JobStatus.QUEUED:
            job.transition_to(JobStatus.RUNNING, "Job allocated to node compute-01")
        elif job.status == JobStatus.RUNNING:
            job.transition_to(JobStatus.COMPLETED, "Job finished (simulated)")
            job.exit_code = 0
            
        return job

    async def cancel(self, job_id: str) -> bool:
        if job_id not in self._jobs:
            return False
            
        job = self._jobs[job_id]
        print(f"INFRA_SIM: Executing 'scancel {job.metadata['slurm_job_id']}'")
        job.transition_to(JobStatus.CANCELLED, "Job cancelled by operator")
        return True

    async def list_jobs(self, run_id: Optional[str] = None) -> List[JobRecord]:
        if run_id:
            return [j for j in self._jobs.values() if j.run_id == run_id]
        return list(self._jobs.values())
