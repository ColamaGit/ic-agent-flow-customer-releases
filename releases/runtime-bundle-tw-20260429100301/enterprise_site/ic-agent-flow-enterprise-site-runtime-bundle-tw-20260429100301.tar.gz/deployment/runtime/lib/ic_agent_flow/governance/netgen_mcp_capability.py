from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List
from uuid import uuid4

from pydantic import BaseModel

from ic_agent_flow.registry.scenario_registry import Disposition


class NetgenMcpCapabilityRequest(BaseModel):
    workspace_id: str
    chip_id: str
    task_id: str
    decision_context_ref: str
    contract_name: str
    contract_version: str
    source_a_path: str
    source_a_top: str
    source_b_path: str
    source_b_top: str
    setup_file: str | None = None
    timeout_sec: int = 120
    output_root: str = "artifacts/v0.9/netgen"
    netgen_bin: str = "netgen"
    request_schema_version: str = "v0.1"
    run_key: str | None = None


class NetgenMcpCapabilityResponse(BaseModel):
    disposition: Disposition
    reason: str
    contract_id: str
    request_schema_version: str
    boundary_mode: str
    error_taxonomy: List[str]
    run_id: str | None = None
    execution_run_ref: str | None = None
    tool_version: str | None = None
    artifact_paths: Dict[str, str] = {}
    artifact_refs: Dict[str, str] = {}


NetgenMcpCapabilityRequest.model_rebuild()
NetgenMcpCapabilityResponse.model_rebuild()


class NetgenMcpCapabilityBoundary:
    """
    Formal MCP capability boundary for netgen_lvs (local mode).
    """

    CAPABILITY_NAME = "netgen_lvs"
    CONTRACT_NAME = "netgen_lvs_contract"
    CONTRACT_VERSION = "v0.1"
    BOUNDARY_MODE = "formal_mcp_capability_boundary_local_mode_v0.1"
    ERROR_TAXONOMY = [
        "chip_scope_unresolved",
        "input_schema_invalid",
        "tool_missing",
        "tool_timeout",
        "tool_runtime_error",
        "artifact_missing",
        "output_unparseable",
        "decision_context_mismatch",
    ]

    @staticmethod
    def _sha256_file(path: Path) -> str:
        h = hashlib.sha256()
        with path.open("rb") as f:
            while True:
                chunk = f.read(8192)
                if not chunk:
                    break
                h.update(chunk)
        return h.hexdigest()

    @classmethod
    def _fail(cls, reason: str, req: NetgenMcpCapabilityRequest) -> NetgenMcpCapabilityResponse:
        return NetgenMcpCapabilityResponse(
            disposition=Disposition.FAIL_CLOSED,
            reason=reason,
            contract_id=f"{req.contract_name}@{req.contract_version}",
            request_schema_version=req.request_schema_version,
            boundary_mode=cls.BOUNDARY_MODE,
            error_taxonomy=list(cls.ERROR_TAXONOMY),
        )

    def execute(self, req: NetgenMcpCapabilityRequest) -> NetgenMcpCapabilityResponse:
        required_values = [
            req.workspace_id,
            req.chip_id,
            req.task_id,
            req.decision_context_ref,
            req.contract_name,
            req.contract_version,
            req.source_a_path,
            req.source_a_top,
            req.source_b_path,
            req.source_b_top,
        ]
        if any(not value for value in required_values):
            return self._fail("input_schema_invalid:envelope_missing", req)

        if req.contract_name != self.CONTRACT_NAME or req.contract_version != self.CONTRACT_VERSION:
            return self._fail("input_schema_invalid:unsupported_contract", req)

        if not req.decision_context_ref.startswith("decision://"):
            return self._fail("decision_context_mismatch:invalid_context", req)

        source_a = Path(req.source_a_path)
        source_b = Path(req.source_b_path)
        if not source_a.exists() or not source_b.exists():
            return self._fail("input_schema_invalid:compare_source_not_found", req)

        if req.setup_file and req.setup_file != "nosetup" and not Path(req.setup_file).exists():
            return self._fail("input_schema_invalid:setup_file_not_found", req)

        if shutil.which(req.netgen_bin) is None:
            return self._fail("tool_missing:netgen_not_in_path", req)

        run_id = req.run_key or f"netgen-{uuid4().hex[:12]}"
        out_dir = Path(req.output_root) / run_id
        out_dir.mkdir(parents=True, exist_ok=True)

        raw_log_path = out_dir / "netgen.raw.log"
        normalized_metadata_path = out_dir / "normalized.lvs.meta.json"
        input_manifest_path = out_dir / "input_manifest.json"
        lineage_path = out_dir / "lineage.json"
        evidence_bundle_path = out_dir / "evidence_bundle.json"
        comp_result_path = out_dir / "comp.out"

        # Netgen cannot compare circuits if they are in the same file.
        if source_a.resolve() == source_b.resolve():
            temp_b = out_dir / f"temp_b_{source_b.name}"
            shutil.copy2(source_b, temp_b)
            source_b = temp_b

        # netgen -batch lvs "file1 top1" "file2 top2" setup_file output_file
        setup = req.setup_file or "nosetup"
        command_argv = [
            req.netgen_bin,
            "-batch",
            "lvs",
            f'"{source_a.as_posix()}" {req.source_a_top}',
            f'"{source_b.as_posix()}" {req.source_b_top}',
            setup,
            comp_result_path.as_posix(),
        ]

        started_at = datetime.now(timezone.utc)
        try:
            proc = subprocess.run(
                command_argv,
                cwd=str(Path.cwd()),
                capture_output=True,
                text=True,
                timeout=req.timeout_sec,
            )
            finished_at = datetime.now(timezone.utc)
        except subprocess.TimeoutExpired:
            return self._fail("tool_timeout:netgen_execution_timeout", req)

        raw_log_path.write_text((proc.stdout or "") + (proc.stderr or ""), encoding="utf-8")
        
        # Netgen usually returns 0 even if LVS fails, so we must check the output file.
        if not comp_result_path.exists():
            return self._fail("artifact_missing:comp_out_not_generated", req)

        lvs_report = comp_result_path.read_text(encoding="utf-8")
        lvs_status = "FAIL"
        if "Circuits match uniquely" in lvs_report:
            lvs_status = "PASS"
        elif "Circuits match" in lvs_report:
            lvs_status = "PASS_WITH_WARNINGS"
        elif "Not checked." in lvs_report:
            lvs_status = "NOT_CHECKED"

        version_proc = subprocess.run(
            [req.netgen_bin, "-batch", "quit"],
            capture_output=True,
            text=True,
            timeout=15,
        )
        tool_version = (version_proc.stdout or version_proc.stderr or "").strip().splitlines()[0]

        input_manifest = {
            "workspace_id": req.workspace_id,
            "chip_id": req.chip_id,
            "task_id": req.task_id,
            "tool": "netgen",
            "tool_version": tool_version,
            "tool_binary_path": req.netgen_bin,
            "command": " ".join(command_argv),
            "setup_file": req.setup_file or "nosetup",
            "sources": [
                {"path": req.source_a_path, "top": req.source_a_top},
                {"path": req.source_b_path, "top": req.source_b_top}
            ],
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }
        input_manifest_path.write_text(json.dumps(input_manifest, indent=2), encoding="utf-8")

        normalized = {
            "tool": "netgen",
            "tool_version": tool_version,
            "tool_binary_path": req.netgen_bin,
            "status": lvs_status,
            "report_ref": comp_result_path.as_posix(),
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }
        normalized_metadata_path.write_text(json.dumps(normalized, indent=2), encoding="utf-8")

        duration_ms = int((finished_at - started_at).total_seconds() * 1000)
        lineage = {
            "run_id": run_id,
            "started_at": started_at.isoformat(),
            "finished_at": finished_at.isoformat(),
            "duration_ms": duration_ms,
            "input_manifest_ref": input_manifest_path.as_posix(),
            "decision_context_ref": req.decision_context_ref,
            "workspace_id": req.workspace_id,
            "chip_id": req.chip_id,
        }
        lineage_path.write_text(json.dumps(lineage, indent=2), encoding="utf-8")

        evidence_bundle = {
            "run_id": run_id,
            "raw_refs": [
                raw_log_path.as_posix(),
                comp_result_path.as_posix(),
            ],
            "normalized_refs": [normalized_metadata_path.as_posix()],
            "lineage_ref": lineage_path.as_posix(),
            "digests": {
                "raw_log_sha256": self._sha256_file(raw_log_path),
                "lvs_report_sha256": self._sha256_file(comp_result_path),
                "normalized_sha256": self._sha256_file(normalized_metadata_path),
                "input_manifest_sha256": self._sha256_file(input_manifest_path),
                "lineage_sha256": self._sha256_file(lineage_path),
            },
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }
        evidence_bundle_path.write_text(json.dumps(evidence_bundle, indent=2), encoding="utf-8")

        return NetgenMcpCapabilityResponse(
            disposition=Disposition.PASS,
            reason="formal_netgen_mcp_capability_execution_pass",
            contract_id=f"{req.contract_name}@{req.contract_version}",
            request_schema_version=req.request_schema_version,
            boundary_mode=self.BOUNDARY_MODE,
            error_taxonomy=list(self.ERROR_TAXONOMY),
            run_id=run_id,
            tool_version=tool_version,
            artifact_paths={
                "raw_log": raw_log_path.as_posix(),
                "lvs_report": comp_result_path.as_posix(),
                "normalized_metadata": normalized_metadata_path.as_posix(),
                "input_manifest": input_manifest_path.as_posix(),
                "lineage": lineage_path.as_posix(),
                "evidence_bundle": evidence_bundle_path.as_posix(),
            },
            artifact_refs={
                "raw_log_ref": f"artifact://netgen/{run_id}/netgen.raw.log",
                "lvs_report_ref": f"artifact://netgen/{run_id}/comp.out",
                "normalized_ref": f"norm://netgen/{run_id}/normalized.lvs.meta.json",
                "lineage_ref": f"lineage://netgen/{run_id}/lineage.json",
                "evidence_bundle_ref": f"evidence_bundle://netgen/{run_id}",
            },
        )
