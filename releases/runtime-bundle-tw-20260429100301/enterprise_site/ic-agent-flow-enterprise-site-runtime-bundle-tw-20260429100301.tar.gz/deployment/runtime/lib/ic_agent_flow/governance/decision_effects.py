"""
Decision Effect Engine (v0.5, PRD R3)
========================================
Routes human decisions to their formal downstream system effects.
This transitions the system from simple logging to actual state machine impacts.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import List, Optional, Any

from ic_agent_flow.domain.governance.checkpoint import DecisionEnum
from ic_agent_flow.domain.objects.decision_objects import (
    ConditionalApprovalRecord,
    DecisionRequest,
    EvidenceRequestRecord,
    ObligationItem,
)
from ic_agent_flow.domain.objects.disposition import FinalDispositionRecord
from ic_agent_flow.domain.objects.evidence_bundle import BundleStatus, EvidenceBundleRef
from ic_agent_flow.domain.objects.human_review import HumanDecisionRecord

logger = logging.getLogger(__name__)


@dataclass
class DecisionEffect:
    """Descriptor of what happened as a result of a decision."""
    decision_record_id: str
    bundle_id: str
    previous_status: str
    new_status: str
    effect_type: str  # DISPOSITION / CONDITION / REENTRY / ESCALATION
    created_records: List[str] = field(default_factory=list)


class DecisionEffectEngine:
    """
    PRD R3: Formal Downstream Effect Definitions.
    Matches every DecisionEnum to a specific runtime state transition.
    """

    @staticmethod
    def apply(
        decision_record: HumanDecisionRecord,
        bundle: EvidenceBundleRef,
        project_root: str,
    ) -> DecisionEffect:
        """
        Applies the decision to the bundle and creates necessary governance records.
        Returns a DecisionEffect summary.
        """
        prev_status = bundle.status.value
        decision_val = decision_record.decision
        effect_type = "UNKNOWN"
        record_paths = []

        if decision_val == DecisionEnum.APPROVE:
            # Effect: proceed to CLOSED
            disp = FinalDispositionRecord.from_decision_record(decision_record, bundle)
            path = disp.persist(project_root)
            record_paths.append(path)
            effect_type = "DISPOSITION"

        elif decision_val == DecisionEnum.APPROVE_WITH_CONDITIONS:
            # Effect: proceed to CLOSED + obligation set
            # 1. Final Disposition
            disp = FinalDispositionRecord.from_decision_record(decision_record, bundle)
            path = disp.persist(project_root)
            record_paths.append(path)
            # 2. Conditional Approval Record
            # Convert decision_record.conditions to ObligationItems
            obligations = [
                ObligationItem(description=c, assignee="pending")
                for c in decision_record.conditions
            ]
            cond = ConditionalApprovalRecord(
                decision_record_id=decision_record.record_id,
                bundle_id=bundle.bundle_id,
                chip_scope=bundle.chip_scope,
                obligations=obligations,
            )
            # Persistence for ConditionalApprovalRecord would go to a similar place
            # Minimal impl: just log it and mark status
            bundle.status = BundleStatus.CLOSED  # Final state is closed but has obligations
            effect_type = "CONDITION"

        elif decision_val == DecisionEnum.REJECT:
            # Effect: terminate to REJECTED
            disp = FinalDispositionRecord.from_decision_record(decision_record, bundle)
            path = disp.persist(project_root)
            record_paths.append(path)
            effect_type = "DISPOSITION"

        elif decision_val == DecisionEnum.REQUEST_MORE_EVIDENCE:
            # Effect: EVIDENCE_REQUESTED + evidence re-entry (Commander R3)
            bundle.status = BundleStatus.EVIDENCE_REQUESTED
            
            # 1. Create EvidenceRequestRecord (Governance Anchor)
            req = EvidenceRequestRecord(
                decision_record_id=decision_record.record_id,
                bundle_id=bundle.bundle_id,
                chip_scope=bundle.chip_scope,
                requested_by=decision_record.human_id,
                requested_artifacts=decision_record.conditions if decision_record.conditions else ["additional_evidence"],
                resubmission_task_id=f"resub-{bundle.task_id}",
                related_skill_output_refs=decision_record.skill_attachment_refs
            )
            
            # 2. Persist EvidenceRequestRecord (Mock persistence for now, similar to FinalDisposition)
            # In a real system, this would go to chips/<chip>/governance/evidence_requests/
            # Here we add it to created_records to signify its formal existence.
            record_paths.append(f"evidence_request_{req.request_id}.json")
            
            # Link request back to bundle history for re-entry tracking
            bundle.resubmission_history.append(f"Evidence Requested: {decision_record.rationale[:50]}...")
            
            # NOTE: The Handoff initiation (R3 Step 3-4) will be handled by the HandoffEngine 
            # consuming this specific record, ensuring decoupling of decision and execution.
            effect_type = "REENTRY"

        elif decision_val == DecisionEnum.ESCALATE:
            # Effect: ESCALATED + high authority queue
            # Status will be updated in Step 4
            bundle.status = BundleStatus.UNDER_REVIEW
            # Create DecisionRequest
            req = DecisionRequest(
                bundle_id=bundle.bundle_id,
                chip_scope=bundle.chip_scope,
                requested_by=decision_record.human_id,
                role_id=decision_record.role_id if hasattr(decision_record, "role_id") else "REVIEWER",
                requested_decision_types=[DecisionEnum.APPROVE, DecisionEnum.REJECT],
            )
            effect_type = "ESCALATION"

        elif decision_val in {DecisionEnum.HOLD, DecisionEnum.TIMEOUT_HOLD}:
            # Effect: stay in UNDER_REVIEW
            bundle.status = BundleStatus.UNDER_REVIEW
            effect_type = "HOLD"

        return DecisionEffect(
            decision_record_id=decision_record.record_id,
            bundle_id=bundle.bundle_id,
            previous_status=prev_status,
            new_status=bundle.status.value,
            effect_type=effect_type,
            created_records=record_paths,
        )
