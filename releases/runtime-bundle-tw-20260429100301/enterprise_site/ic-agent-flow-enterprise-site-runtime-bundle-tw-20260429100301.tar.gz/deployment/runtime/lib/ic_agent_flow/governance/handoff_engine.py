"""
Inter-Agent Handoff Engine (v0.6, PRD v0.6 Baseline)
===================================================
Core engine for managing the governed state transitions of inter-agent handoffs.
Enforces Law 2 (Formal Handoff), Law 3 (Chip-Scoped), and Law 5 (Target Rejection).
"""
from __future__ import annotations

import hashlib
import json
import logging
from typing import List, Optional, Tuple, Dict, Any, Set
from uuid import UUID

from ic_agent_flow.domain.objects.handoff_objects import (
    HandoffStatus,
    HandoffFailureType,
    HandoffPayloadManifest,
    HandoffRequest,
    HandoffRecord,
    HandoffAcceptanceRecord,
    HandoffRejectionRecord,
    HandoffReturnRecord
)
from ic_agent_flow.domain.objects.decision_objects import EvidenceRequestRecord
from ic_agent_flow.domain.utils.time import get_tw_now

logger = logging.getLogger(__name__)

class InterAgentHandoffEngine:
    """
    Governs the lifecycle and validation of inter-agent handoffs.
    Ensures that handoffs are not treated as informal shortcuts.
    """

    @staticmethod
    def calc_payload_digest(manifest_data: Dict[str, Any]) -> str:
        """
        Calculates a stable HMAC-SHA256 digest for the payload manifest.
        Ensures physical integrity of the handoff contract.
        """
        # Sort keys for stable hashing
        serialized = json.dumps(manifest_data, sort_keys=True)
        return hashlib.sha256(serialized.encode()).hexdigest()

    @staticmethod
    def initiate_handoff(
        source_agent_id: str,
        target_agent_id: str,
        source_task_id: str,
        target_task_type: str,
        workspace_id: str,
        chip_id: str,
        handoff_reason: str,
        evidence_request: EvidenceRequestRecord,
        requested_outputs: List[str]
    ) -> Tuple[HandoffRequest, HandoffRecord]:
        """
        PRD 6.2: Formal Handoff Initiation.
        Creates the request and record, performing initial precondition checks.
        """
        # 1. Build Payload Manifest (Law 4)
        manifest_data = {
            "workspace_id": workspace_id,
            "chip_id": chip_id,
            "source_agent_id": source_agent_id,
            "target_agent_id": target_agent_id,
            "subject_refs": [evidence_request.bundle_id],
            "evidence_refs": [], # To be populated by source agent
            "unresolved_issue_ids": evidence_request.requested_artifacts,
            "decision_context_ref": evidence_request.decision_record_id,
            "evidence_request_record_ref": str(evidence_request.request_id),
            "requested_outputs": requested_outputs,
            "authority_class": "operational"
        }
        
        digest = InterAgentHandoffEngine.calc_payload_digest(manifest_data)
        
        manifest = HandoffPayloadManifest(
            workspace_id=workspace_id,
            chip_id=chip_id,
            source_agent_id=source_agent_id,
            target_agent_id=target_agent_id,
            subject_refs=manifest_data["subject_refs"],
            unresolved_issue_ids=manifest_data["unresolved_issue_ids"],
            decision_context_ref=manifest_data["decision_context_ref"],
            evidence_request_record_ref=manifest_data["evidence_request_record_ref"],
            requested_outputs=requested_outputs,
            payload_digest=digest
        )

        # 2. Create Handoff Request (Law 2)
        request = HandoffRequest(
            source_agent_id=source_agent_id,
            target_agent_id=target_agent_id,
            source_task_id=source_task_id,
            target_task_type=target_task_type,
            workspace_id=workspace_id,
            chip_id=chip_id,
            handoff_reason=handoff_reason,
            payload_manifest_ref=f"handoff_manifest_{manifest.manifest_id}.json"
        )

        # 3. Create Handoff Record (Traceability)
        record = HandoffRecord(
            request_id=request.request_id,
            status=HandoffStatus.REQUESTED,
            workspace_id=workspace_id,
            chip_id=chip_id,
            current_payload_manifest_ref=request.payload_manifest_ref,
            history=[{
                "timestamp": get_tw_now().isoformat(),
                "event": "HANDOFF_INITIATED",
                "source": source_agent_id
            }]
        )

        return request, record

    @staticmethod
    def validate_preconditions(
        record: HandoffRecord,
        manifest: HandoffPayloadManifest,
        target_agent_role: str
    ) -> List[HandoffFailureType]:
        """
        PRD 6.2/6.4: Safety checks before acceptance.
        """
        failures = []
        
        # 1. Chip Scope Check (Law 3)
        if not manifest.chip_id or manifest.chip_id != record.chip_id:
            failures.append(HandoffFailureType.SCOPE_MISMATCH)
            
        # Payload integrity verification
        manifest_dict = manifest.model_dump()
        # Remove dynamic fields for digest verification
        if "payload_digest" in manifest_dict:
            del manifest_dict["payload_digest"]
        if "created_at" in manifest_dict:
            del manifest_dict["created_at"]
        if "metadata" in manifest_dict:
            del manifest_dict["metadata"]
        if "manifest_id" in manifest_dict:
            del manifest_dict["manifest_id"]

        # 2. Integrity Verification (Law 9)
        expected_digest = InterAgentHandoffEngine.calc_payload_digest(manifest_dict)
        if manifest.payload_digest != expected_digest:
            failures.append(HandoffFailureType.INTEGRITY_VIOLATION)

        # 3. Simple ID membership check for target_task_type (Placeholder for v0.6)
        # In a real impl, we'd check if target agent supports the requested output types
        
        return failures

    @staticmethod
    def accept_handoff(
        record: HandoffRecord,
        target_agent_id: str,
        accepted_scope: str
    ) -> Tuple[HandoffRecord, HandoffAcceptanceRecord]:
        """
        PRD 6.4: Target agent accepts the tasks.
        """
        record.status = HandoffStatus.ACCEPTED
        record.updated_at = get_tw_now()
        record.history.append({
            "timestamp": get_tw_now().isoformat(),
            "event": "HANDOFF_ACCEPTED",
            "agent": target_agent_id,
            "scope": accepted_scope
        })
        
        acceptance = HandoffAcceptanceRecord(
            handoff_id=record.handoff_id,
            target_agent_id=target_agent_id,
            accepted_scope=accepted_scope
        )
        
        return record, acceptance

    @staticmethod
    def reject_handoff(
        record: HandoffRecord,
        target_agent_id: str,
        failure_type: HandoffFailureType,
        reason: str
    ) -> Tuple[HandoffRecord, HandoffRejectionRecord]:
        """
        PRD 6.5: Target agent formally rejects.
        """
        record.status = HandoffStatus.REJECTED
        record.updated_at = get_tw_now()
        record.history.append({
            "timestamp": get_tw_now().isoformat(),
            "event": "HANDOFF_REJECTED",
            "agent": target_agent_id,
            "reason": reason,
            "type": failure_type.value
        })
        
        rejection = HandoffRejectionRecord(
            handoff_id=record.handoff_id,
            target_agent_id=target_agent_id,
            rejection_type=failure_type,
            rejection_reason=reason
        )
        
        return record, rejection

    @staticmethod
    def return_handoff(
        record: HandoffRecord,
        target_agent_id: str,
        reason: str,
        partial_outputs: List[str] = [],
        remaining_gaps: List[str] = []
    ) -> Tuple[HandoffRecord, HandoffReturnRecord]:
        """
        Commander R1: First-class return semantics.
        """
        record.status = HandoffStatus.RETURNED
        record.updated_at = get_tw_now()
        record.history.append({
            "timestamp": get_tw_now().isoformat(),
            "event": "HANDOFF_RETURNED",
            "agent": target_agent_id,
            "reason": reason
        })
        
        ret_record = HandoffReturnRecord(
            handoff_id=record.handoff_id,
            target_agent_id=target_agent_id,
            return_reason=reason,
            partial_outputs=partial_outputs,
            remaining_gaps=remaining_gaps
        )
        
        return record, ret_record

    @staticmethod
    def complete_handoff(
        record: HandoffRecord,
        target_agent_id: str,
        result_bundle_ref: str
    ) -> HandoffRecord:
        """
        Finalizes the handoff successfully.
        """
        record.status = HandoffStatus.COMPLETED
        record.updated_at = get_tw_now()
        record.history.append({
            "timestamp": get_tw_now().isoformat(),
            "event": "HANDOFF_COMPLETED",
            "agent": target_agent_id,
            "bundle": result_bundle_ref
        })
        
        return record
