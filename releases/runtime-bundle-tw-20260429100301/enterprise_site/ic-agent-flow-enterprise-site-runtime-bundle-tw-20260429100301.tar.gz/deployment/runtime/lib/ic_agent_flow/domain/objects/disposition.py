"""
Final Disposition Record (Phase 3, D3-4)
==========================================
Captures the final runtime disposition of an evidence bundle
after human review. This is the governance closeout record
that links the human decision to the evidence chain.

Authority:
- Only created AFTER HumanDecisionRecord exists.
- agent CANNOT create disposition without human decision.
- Disposition updates EvidenceBundleRef.status to final state.
"""
from __future__ import annotations

import json
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from ic_agent_flow.domain.governance.checkpoint import (
    AuthorityRecord,
    DecisionEnum,
    StageGateType,
)
from ic_agent_flow.domain.objects.evidence_bundle import BundleStatus, EvidenceBundleRef
from ic_agent_flow.domain.objects.human_review import HumanDecisionRecord


class DispositionError(Exception):
    """Raised when disposition cannot be applied."""
    pass


@dataclass
class FinalDispositionRecord:
    """
    D3-4: Final Disposition Record.

    The authoritative runtime record summarizing:
    1. What evidence was reviewed (bundle_id)
    2. What the human decided (decision)
    3. What the system's final state is (final_status)
    4. The AuthorityRecord (governance audit trail)

    Persisted to: chips/<chip_scope>/evidence/human_reviews/<disposition_id>_disposition.json
    """
    disposition_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    bundle_id: str = ""
    chip_scope: str = ""
    task_id: str = ""

    # Human decision
    human_decision_record_id: str = ""
    decision: str = ""
    rationale: str = ""
    human_id: str = ""
    role_id: Optional[str] = None
    is_timeout: bool = False

    # Final runtime state
    final_status: str = BundleStatus.CLOSED.value
    disposition_reason: str = ""

    # Authority record (governance anchor)
    authority_record_id: Optional[str] = None

    # Timestamps
    disposed_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    @classmethod
    def from_decision_record(
        cls,
        decision_record: HumanDecisionRecord,
        bundle: EvidenceBundleRef,
    ) -> "FinalDispositionRecord":
        """
        Apply a HumanDecisionRecord to produce a FinalDispositionRecord.
        Also updates bundle.status to its final value.
        Raises DispositionError if bundle is not in UNDER_REVIEW or READY_FOR_REVIEW state.
        """
        if bundle.status not in {
            BundleStatus.READY_FOR_REVIEW,
            BundleStatus.UNDER_REVIEW,
        }:
            raise DispositionError(
                f"Cannot dispose bundle {bundle.bundle_id}: "
                f"status={bundle.status.value}. Expected READY_FOR_REVIEW or UNDER_REVIEW."
            )

        # Determine final bundle status
        decision_val = decision_record.decision
        if decision_val in {DecisionEnum.APPROVE.value, DecisionEnum.APPROVE_WITH_CONDITIONS.value}:
            final_status = BundleStatus.CLOSED
            disposition_reason = f"Human approved: {decision_record.rationale[:80]}"
        elif decision_val == DecisionEnum.REJECT.value:
            final_status = BundleStatus.REJECTED
            disposition_reason = f"Human rejected: {decision_record.rationale[:80]}"
        elif decision_val in {DecisionEnum.HOLD.value, DecisionEnum.TIMEOUT_HOLD.value}:
            final_status = BundleStatus.UNDER_REVIEW
            disposition_reason = (
                f"Timeout hold — no human response: fail-closed engaged."
                if decision_record.is_timeout
                else f"Human placed on hold: {decision_record.rationale[:80]}"
            )
        elif decision_val == DecisionEnum.REQUEST_MORE_EVIDENCE.value:
            final_status = BundleStatus.UNDER_REVIEW
            disposition_reason = f"More evidence requested: {decision_record.rationale[:80]}"
        else:
            final_status = BundleStatus.UNDER_REVIEW
            disposition_reason = f"Unknown decision, defaulting to UNDER_REVIEW (fail-closed)"

        # Apply to bundle
        bundle.status = final_status

        return cls(
            bundle_id=bundle.bundle_id,
            chip_scope=bundle.chip_scope,
            task_id=bundle.task_id,
            human_decision_record_id=decision_record.record_id,
            decision=decision_val,
            rationale=decision_record.rationale,
            human_id=decision_record.human_id,
            role_id=decision_record.role_id,
            is_timeout=decision_record.is_timeout,
            final_status=final_status.value,
            disposition_reason=disposition_reason,
        )

    def build_authority_record(self) -> AuthorityRecord:
        """
        Build an AuthorityRecord from this disposition.
        AuthorityRecord is the formal governance anchor for the CloseoutBundle.
        """
        from ic_agent_flow.domain.governance.checkpoint import RoleEnum
        record = AuthorityRecord(
            gate_type=StageGateType.ARTIFACT_REVIEW,
            decision=DecisionEnum(self.decision)
            if self.decision in DecisionEnum._value2member_map_
            else DecisionEnum.HOLD,
            rationale=self.rationale,
            approver=self.human_id,
            role_id=RoleEnum(self.role_id) if self.role_id else None,
            subject_refs=[self.bundle_id, self.chip_scope],
            evidence_refs=[self.human_decision_record_id],
        )
        self.authority_record_id = str(record.id)
        return record

    def persist(self, project_root: str) -> str:
        """
        Persist to: chips/<chip_scope>/evidence/human_reviews/<disposition_id>_disposition.json
        Returns the saved file path.
        """
        reviews_dir = (
            Path(project_root) / "chips" / self.chip_scope / "evidence" / "human_reviews"
        )
        reviews_dir.mkdir(parents=True, exist_ok=True)

        disp_path = reviews_dir / f"{self.disposition_id}_disposition.json"
        data = {
            "disposition_id": self.disposition_id,
            "bundle_id": self.bundle_id,
            "chip_scope": self.chip_scope,
            "task_id": self.task_id,
            "human_decision_record_id": self.human_decision_record_id,
            "decision": self.decision,
            "rationale": self.rationale,
            "human_id": self.human_id,
            "role_id": self.role_id,
            "is_timeout": self.is_timeout,
            "final_status": self.final_status,
            "disposition_reason": self.disposition_reason,
            "authority_record_id": self.authority_record_id,
            "disposed_at": self.disposed_at.isoformat(),
        }
        disp_path.write_text(json.dumps(data, indent=2, ensure_ascii=False))
        return str(disp_path)
