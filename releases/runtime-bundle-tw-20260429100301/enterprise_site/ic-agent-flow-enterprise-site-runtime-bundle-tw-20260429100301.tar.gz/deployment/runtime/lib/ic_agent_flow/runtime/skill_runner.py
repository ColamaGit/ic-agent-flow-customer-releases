import os
import uuid
from typing import Dict, Any, Optional
from pydantic import ValidationError

from ic_agent_flow.domain.contracts.skill_contract import EDAAgentSkillContract
from ic_agent_flow.domain.objects.skill_records import (
    SkillInvocationRecord, 
    SkillOutputRecord, 
    SkillCognitiveEnvelope
)
from ic_agent_flow.domain.objects import AuthorityClass
from ic_agent_flow.domain.governance.attachability import AttachabilityGuard
from ic_agent_flow.domain.governance.checkpoint import DecisionEnum
from ic_agent_flow.registry.capability_registry import CapabilityRegistry, CapabilityFamily
from ic_agent_flow.skills.registry import get_skill_implementation
from ic_agent_flow.cognitive.adapter import CognitiveAdapter
from ic_agent_flow.cognitive.schemas import CognitiveRequest, SensitivityLevel, BackendPolicy

class SkillRunner:
    """
    The execution engine for EDA Agent Skills.
    Handles orchestration, cognitive injection, and persistence.
    """
    
    def __init__(self, registry: CapabilityRegistry, project_root: Optional[str] = None):
        self.registry = registry
        self.project_root = project_root or os.getenv("PROJECT_ROOT", os.getcwd())
        self._cognitive_adapter = CognitiveAdapter()

    def run_skill(self, invocation: SkillInvocationRecord, inputs: Dict[str, Any]) -> SkillOutputRecord:
        """
        Execute a skill following the governance baseline.
        """
        invocation.status = "RUNNING"
        invocation.persist(self.project_root)

        # 1. Fetch Contract
        entry = self.registry.get_entry(CapabilityFamily.EDA_AGENT_SKILL, invocation.skill_name)
        if not entry:
            raise ValueError(f"Skill '{invocation.skill_name}' not found in CapabilityRegistry.")
        
        # In a real system, we'd fetch the actual contract object. 
        # For the baseline, we assume the entry has metadata or we load it.
        # Here we'll mock the contract loading for the implementation phase.
        contract = self._load_contract(invocation.skill_name)

        # 2. Fetch Implementation
        skill_cls = get_skill_implementation(invocation.skill_name)
        if not skill_cls:
            raise ValueError(f"No implementation found for skill '{invocation.skill_name}' in static registry.")

        # 3. Handle Cognitive Injection (Option B: Centralized)
        cognitive_env: Optional[SkillCognitiveEnvelope] = None
        if contract.cognitive_backend_requirement:
            cognitive_env = self._perform_cognitive_injection(invocation, contract, inputs)

        # 4. Execute Skill
        skill_inst = skill_cls(contract)
        
        # --- Guard 1: Provenance Check (PRD Phase 3) ---
        if not invocation.input_refs:
            invocation.status = "FAILED_PROVENANCE"
            invocation.persist(self.project_root)
            raise ValueError(f"Guard 1 Violation: Skill {invocation.skill_name} missing input_refs.")

        try:
            output = skill_inst.execute(inputs, cognitive_env)
            output.invocation_id = invocation.invocation_id
            
            # --- Guard 2: Authority Promotion Block (PRD Phase 3) ---
            # Enforce attachment matrix rules
            err = AttachabilityGuard.validate_attachment(
                output.output_type, 
                DecisionEnum.HOLD, # Baseline check against generic hold
                output.authority_class
            )
            if err:
                invocation.status = "FAILED_AUTHORITY_GUARD"
                invocation.persist(self.project_root)
                raise ValueError(f"Guard 2 Violation: {err}")

            # 5. Persistence
            output.persist(self.project_root, invocation.chip_id)
            
            invocation.status = "COMPLETED"
            invocation.persist(self.project_root)
            
            return output
            
        except Exception as e:
            if invocation.status == "RUNNING":
                invocation.status = "FAILED"
            invocation.persist(self.project_root)
            raise e

    def _perform_cognitive_injection(
        self, 
        invocation: SkillInvocationRecord, 
        contract: EDAAgentSkillContract,
        inputs: Dict[str, Any]
    ) -> SkillCognitiveEnvelope:
        """
        Centralized cognitive backend call for skills.
        """
        # Build prompt based on skill purpose and inputs
        prompt = f"Skill: {contract.skill_name}\nPurpose: {contract.purpose}\nInputs: {inputs}"
        
        req = CognitiveRequest(
            agent_id=invocation.invoker.id,
            chip_scope=invocation.chip_id,
            task_type="SKILL_COGNITION",
            prompt=prompt,
            system_context=f"You are providing cognitive support for the EDA Skill: {contract.skill_name}.",
            sensitivity=SensitivityLevel.INTERNAL,
            policy=BackendPolicy.REMOTE_ALLOWED_WITH_CONTROLS
        )
        
        response = self._cognitive_adapter.invoke(req)
        
        return SkillCognitiveEnvelope(
            invocation_id=invocation.invocation_id,
            raw_response=response.content or "",
            backend_provider=response.provider.value if hasattr(response.provider, 'value') else str(response.provider),
            latency_ms=None # Not present in response envelope
        )

    def _load_contract(self, skill_name: str) -> EDAAgentSkillContract:
        """
        Mock contract loader. In production, this would read from registries/
        """
        # For now, we'll return a generic contract or specialized one if name matches
        if skill_name == "verification_triage":
            from ic_agent_flow.domain.contracts.skill_contract import SkillFamily
            return EDAAgentSkillContract(
                skill_name="verification_triage",
                skill_version="v0.1.0",
                skill_family=SkillFamily.TRIAGE,
                purpose="Analytic triage of verification results",
                input_schema={},
                output_schema={},
                cognitive_backend_requirement=True
            )
        else:
             from ic_agent_flow.domain.contracts.skill_contract import SkillFamily
             return EDAAgentSkillContract(
                skill_name=skill_name,
                skill_version="v0.1.0",
                skill_family=SkillFamily.INTERPRETATION,
                purpose="Generic Skill",
                input_schema={},
                output_schema={}
            )
