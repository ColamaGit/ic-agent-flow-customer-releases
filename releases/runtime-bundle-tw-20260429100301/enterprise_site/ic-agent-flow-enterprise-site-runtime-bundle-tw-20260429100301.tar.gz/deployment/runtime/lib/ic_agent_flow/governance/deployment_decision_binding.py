
from typing import Dict, Any, List
from ic_agent_flow.domain.governance.checkpoint import DecisionEnum
from ic_agent_flow.domain.objects.human_review import HumanDecisionRecord

class DeploymentDecisionLoopBinding:
    """
    將 Deployment 門禁結果綁定至 v0.5 Decision Loop 語義
    """
    
    @staticmethod
    def map_to_decision_request(gate_id: str, results: Dict[str, Any]) -> Dict[str, Any]:
        """
        將 Entry/Checkpoint 失敗結果轉譯為 Decision Loop 所需的 request
        """
        # 繼承 v0.5 的決策語義，針對不同门禁狀態進行轉譯
        if results.get("status") == "FAIL_CLOSED":
            return {
                "decision_type": DecisionEnum.REJECT,
                "reason": f"Deployment Gate {gate_id} failed: {results.get('reason')}",
                "context": "deployment_admission_phase"
            }
        elif results.get("status") == "HOLD":
            return {
                "decision_type": DecisionEnum.HOLD,
                "reason": f"Deployment Gate {gate_id} requires human intervention: {results.get('reason')}",
                "context": "deployment_admission_phase"
            }
        # 通過 gate，請求繼續執行
        return {"decision_type": DecisionEnum.APPROVE, "context": "deployment_admission_phase"}

    @staticmethod
    def bind_to_decision_record(decision_record: HumanDecisionRecord, gate_id: str):
        """
        將 gate_id 寫入 DecisionRecord metadata，作為審計鏈的正式錨點
        """
        if not hasattr(decision_record, "metadata"):
            decision_record.metadata = {}
        decision_record.metadata["gate_id"] = gate_id
        decision_record.metadata["pipeline"] = "H1-H2-H4-H3"
        return decision_record
