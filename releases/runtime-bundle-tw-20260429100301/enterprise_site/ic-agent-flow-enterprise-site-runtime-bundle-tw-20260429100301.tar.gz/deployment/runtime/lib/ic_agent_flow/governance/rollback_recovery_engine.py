"""
Rollback & Recovery Engine (v0.1)
================================
Logic for handling signoff rejections and lifecycle recovery.
Ensures that a "REJECT" verdict results in a formal, auditable rollback.
"""
from __future__ import annotations

from typing import List, Optional
from uuid import UUID

from ic_agent_flow.domain.objects.production_bridge_objects import (
    ReleaseGateVerdict,
    RollbackTriggerRecord,
    RecoveryPlanRecord
)
from ic_agent_flow.domain.governance.checkpoint import DecisionEnum
from ic_agent_flow.domain.utils.time import get_tw_now


class RollbackRecoveryEngine:
    """ 
    Handles the transition from a rejected signoff gate to a formal 
    recovery phase.
    """

    @staticmethod
    def initiate_rollback(verdict: ReleaseGateVerdict) -> Tuple[RollbackTriggerRecord, RecoveryPlanRecord]:
        """
        Creates the pair of records needed to document a rollback event.
        """
        if verdict.verdict != DecisionEnum.REJECT.value:
            raise ValueError(f"Rollback can only be initiated on REJECT verdict. Found: {verdict.verdict}")

        # 1. Create Trigger Record
        trigger = RollbackTriggerRecord(
            chip_id=verdict.chip_id,
            trigger_reason=f"Signoff Gate REJECTED: {verdict.gate_type}",
            evidence_failure_ref=str(verdict.id),
            triggered_at=get_tw_now()
        )

        # 2. Propose Recovery Plan (Template based in v0.1)
        steps = [
            "1. Audit the REJECT rationale in the DecisionRecord.",
            "2. Identify the specific evidence failure (Triage).",
            "3. Correct RTL or Constraints as required.",
            "4. Re-run Phase 5A validation flow.",
            "5. Re-initiate Phase 6 Signoff Assist."
        ]
        
        recovery = RecoveryPlanRecord(
            trigger_record_id=trigger.id,
            steps=steps,
            is_validated=False,
            created_at=get_tw_now()
        )

        return trigger, recovery

    @staticmethod
    def validate_recovery_completion(plan: RecoveryPlanRecord, validation_logic_ref: str) -> RecoveryPlanRecord:
        """
        Marks a recovery plan as validated after human/system check.
        """
        plan.is_validated = True
        return plan
