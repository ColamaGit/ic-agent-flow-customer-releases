from ic_agent_flow.domain.utils.time import get_tw_now
from uuid import uuid4
from typing import List, Dict, Any, Optional
from ic_agent_flow.domain.objects import RTLSnapshot, AuthorityClass, Producer, ProducerType, DataClassification
from ic_agent_flow.context.assembler import ContextAssembler
from ic_agent_flow.domain.verification import GateVerdict, Verdict, AdjudicationRecord, AdjudicationAuthority, Decision
from ic_agent_flow.domain.verification.evaluator import ContractEvaluator
from ic_agent_flow.domain.governance import (
    ExecutionRunRecord, 
    ReadinessNote, 
    CloseoutBundle, 
    HumanReviewPackage
)
from ic_agent_flow.domain.governance.checkpoint import (
    HumanCheckpointRunner, 
    CheckpointPolicy, 
    DecisionEnum,
    StageGateType,
    AuthorityRecord
)
from ic_agent_flow.domain.contracts import Contract, SelectedContracts, ExecutionScope
from ic_agent_flow.domain.execution import ToolCommand, ExecutionBounds, CompilationResult, ToolInvocation
from ic_agent_flow.adapters.tools.mock_compiler import MockCompiler
import json
import os

class HumanGovernedCompileElabScenario:
    """
    Implements Program 3 scenario: Formal Human Authority Plane.
    Integrates Stage-Gates for Launch Approval and Exception Handling.
    """
    
    def __init__(self):
        self.assembler = ContextAssembler()
        self.compiler = MockCompiler(tool_name="vcs", version="T-2022.06")
        self.evaluator = ContractEvaluator()
    
    def run(self, rtl_files: List[str], requested_args: List[str], timeout_override: int = 60, classification: DataClassification = DataClassification.HIGHLY_SENSITIVE_DESIGN):
        
        # 1. RTL Source Snapshot (with Classification)
        rtl_snap = RTLSnapshot(
            id=uuid4(),
            version="v1.0.0",
            status="stable",
            authority_class=AuthorityClass.CANONICAL,
            classification=classification,
            producer=Producer(id="eng_alice", type=ProducerType.HUMAN),
            files=[{"path": path, "hash": "abc"} for path in rtl_files],
            created_at=get_tw_now()
        )

        # -------------------------------------------------------------
        # STAGE GATE: LAUNCH APPROVAL (Program 3)
        # -------------------------------------------------------------
        if classification == DataClassification.HIGHLY_SENSITIVE_DESIGN:
            launch_pkg = HumanReviewPackage(
                id=uuid4(),
                subject_objects=[f"scenario:human-governed-compile"],
                gate_verdict_summary="High-Value IP Launch Request.",
                authoritative_evidence_refs=[f"rtl_snapshot:{rtl_snap.id}"],
                open_risks=["Scenario involves Tier 3 design objects. Explicit launch authority required."],
                downstream_effect="Execution of compilation tools on proprietary design data.",
                allowed_decisions=["APPROVE", "REJECT", "HOLD"],
                created_at=get_tw_now()
            )
            launch_policy = CheckpointPolicy(timeout_seconds=30)
            launch_decision = HumanCheckpointRunner.execute_checkpoint(launch_pkg, launch_policy)
            
            if launch_decision.decision != DecisionEnum.APPROVE:
                print(f"\n[TERMINATED] Launch Authorization Denied: {launch_decision.rationale}")
                return {"status": "DENIED", "gate": "LAUNCH_APPROVAL", "rationale": launch_decision.rationale}

        # 2. Define Execution Bounds
        bounds = ExecutionBounds(
            allowed_tools=["vcs", "ncverilog"],
            forbidden_args=["-DDEBUG_MODE"],
            max_memory_gb=16,
            timeout_seconds=3600
        )
        
        # 3. Assemble Context
        manifest = self.assembler.assemble(
            task_type="human-governed-compile",
            subjects=[rtl_snap],
            assembler_id="v1_orchestrator"
        )
        
        # 4. Prepare Tool Command
        cmd = ToolCommand(
            tool_name="vcs",
            version="T-2022.06",
            args=requested_args,
            working_dir="/scratch/build"
        )
        
        # 5. Invocation
        invocation = ToolInvocation(
            id=uuid4(),
            type="tool_invocation",
            version="v1.0.0",
            authority_class=AuthorityClass.DERIVED,
            producer=Producer(id="antigravity_agent", type=ProducerType.AGENT),
            command=cmd,
            bounds_applied=bounds,
            start_time=datetime.now(timezone.utc),
            created_at=get_tw_now()
        )
        
        # 6. Execute (Adapter)
        comp_result = self.compiler.execute(cmd, bounds)
        invocation.end_time = datetime.now(timezone.utc)
        
        # 7. Define Contracts
        contracts = SelectedContracts(
            version="v1.0.0",
            contracts=[
                Contract(
                    id="C-01", 
                    name="Zero Error Comp", 
                    schema_ref="comp_res.json", 
                    description="Compilation MUST succeed with 0 errors.",
                    execution_scope=ExecutionScope(tool_execution=True)
                ),
                Contract(
                    id="C-02", 
                    name="Warning Limit", 
                    schema_ref="comp_res.json", 
                    description="Warnings must be < 5.",
                    execution_scope=ExecutionScope(tool_execution=True)
                )
            ]
        )
        
        # 8. Evaluate Verdicts
        v1 = self.evaluator.evaluate(contracts.contracts[0], comp_result)
        v2 = self.evaluator.evaluate(contracts.contracts[1], comp_result)
        
        # -------------------------------------------------------------
        # STAGE GATE: EXCEPTION ACCEPTANCE (Program 3)
        # -------------------------------------------------------------
        all_passed = all(v.verdict == Verdict.PASS for v in [v1, v2])
        is_exception = not all_passed and comp_result.error_count == 0 # Only allow exceptions on warnings, not errors.
        
        review_package = HumanReviewPackage(
            id=uuid4(),
            subject_objects=[f"rtl_snapshot:{rtl_snap.id}"],
            authoritative_evidence_refs=[f"compilation_result:{comp_result.id}"],
            gate_verdict_summary=f"C-01: {v1.verdict}, C-02: {v2.verdict}",
            open_risks=[r for r in [comp_result.metadata.get("error")] if r] + (["Warnings exceed safety limit."] if not v2.verdict == Verdict.PASS else []),
            downstream_effect="Handoff to verification gate.",
            created_at=get_tw_now()
        )

        policy = CheckpointPolicy(timeout_seconds=timeout_override, default_timeout_decision=DecisionEnum.TIMEOUT_HOLD)
        human_decision = HumanCheckpointRunner.execute_checkpoint(review_package, policy)
        
        # 9. Map to Final Authority Record
        final_decision = Decision.HOLD
        gate_type = StageGateType.ARTIFACT_REVIEW
        
        if human_decision.decision == DecisionEnum.APPROVE:
            final_decision = Decision.PROCEED
            if is_exception:
                gate_type = StageGateType.EXCEPTION_ACCEPTANCE
        elif human_decision.decision == DecisionEnum.REJECT:
            final_decision = Decision.REJECT
        
        # Create persistent Authority Record
        auth_record = AuthorityRecord(
            gate_type=gate_type,
            decision=human_decision,
            subject_refs=[f"rtl_snapshot:{rtl_snap.id}"],
            evidence_refs=[f"gate_verdict:{v1.id}", f"gate_verdict:{v2.id}", f"compilation_result:{comp_result.id}"],
            scope_accepted=[str(cmd.args)] if is_exception else []
        )

        adjudication = AdjudicationRecord(
            adjudication_id=uuid4(),
            subject_refs=[f"rtl_snapshot:{rtl_snap.id}"],
            gate_verdict_refs=[f"gate_verdict:{v1.id}", f"gate_verdict:{v2.id}"],
            decision=final_decision,
            decision_rationale=f"[{human_decision.decision.value}] {human_decision.rationale} (Gate: {gate_type.value})",
            authority=AdjudicationAuthority(human_id=human_decision.human_id, role="Lead_Validator"),
            approved_at=human_decision.timestamp
        )
        
        # 10. Closeout Bundle
        run_record = ExecutionRunRecord(
            run_id=uuid4(),
            timestamp=datetime.now(timezone.utc),
            producer=Producer(id="antigravity_agent", type=ProducerType.AGENT),
            environment="local_dev_mac",
            task_type="human-governed-compile"
        )

        readiness_note = ReadinessNote(
            id=uuid4(),
            current_readiness="RR",
            target_readiness="BR",
            claims=[
                "Interactive Human Checkpoint installed", 
                "Adjudication state directly tied to physical human verification",
                "Program 3: Formal Authority Records implemented for Launch/Review/Exception"
            ],
            limitations=["Mock compiler used"],
            evidence_delta="Introduced StageGateType and AuthorityRecord supporting tiered governance.",
            created_at=get_tw_now()
        )
        
        bundle = CloseoutBundle(
            id=uuid4(),
            task_type="human-governed-compile",
            input_objects=[rtl_snap, invocation],
            context_manifest=manifest,
            selected_contracts=contracts,
            execution_run_record=run_record,
            normalized_artifacts=[comp_result],
            gate_verdicts=[v1, v2],
            adjudication_record=adjudication,
            human_review_package=review_package,
            final_readiness_note=readiness_note,
            created_at=get_tw_now()
        )
        
        # Save Bundle
        os.makedirs("artifacts/closeouts", exist_ok=True)
        bundle_path = f"artifacts/closeouts/bundle_{bundle.id}.json"
        with open(bundle_path, "w") as f:
            f.write(bundle.model_dump_json(indent=2))
            
        return {
            "bundle_id": bundle.id,
            "decision": adjudication.decision,
            "gate_used": gate_type,
            "auth_record_id": auth_record.id
        }

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--timeout", type=int, default=10)
    args = parser.parse_args()
    scenario = HumanGovernedCompileElabScenario()
    res = scenario.run(["top.v"], ["-O2"], timeout_override=args.timeout)
    print(f"\n[Scenario Completed] Decision: {res['decision']} via gate {res['gate_used']}")
