from typing import Dict, Any

class DecisionIntakeGuard:
    @staticmethod
    def validate_intake(review_package: Dict[str, Any]) -> bool:
        """
        在 DecisionRecord 建立前，強制驗證輸入的完整性
        """
        # 檢查是否有 integrity verdict
        if "_integrity_verdict" not in review_package:
            return False
            
        # 檢查 scope 綁定
        if "scope_resolution_ref" not in review_package:
            return False
            
        return True
