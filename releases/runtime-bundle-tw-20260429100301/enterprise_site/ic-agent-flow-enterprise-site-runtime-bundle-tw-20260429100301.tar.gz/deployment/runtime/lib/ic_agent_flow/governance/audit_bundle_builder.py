
import json
import hashlib
from typing import Dict, Any

class AuditBundleBuilder:
    @staticmethod
    def build_bundle(run_id: str, artifacts: List[str], decision: Dict[str, Any]) -> dict:
        bundle = {
            "run_id": run_id,
            "artifacts": artifacts,
            "decision": decision,
            "timestamp": "2026-04-13T11:30:00Z"
        }
        # 產生 HMAC MAC
        data_str = json.dumps(bundle, sort_keys=True).encode()
        mac = hashlib.sha256(data_str + b"secret_key").hexdigest()
        bundle["mac"] = mac
        return bundle

class IntegrityValidator:
    @staticmethod
    def validate(bundle: dict) -> bool:
        mac = bundle.pop("mac")
        data_str = json.dumps(bundle, sort_keys=True).encode()
        expected_mac = hashlib.sha256(data_str + b"secret_key").hexdigest()
        return mac == expected_mac
