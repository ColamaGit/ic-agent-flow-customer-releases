"""
Scenario: Timing vs Power Conflict Adjudication
Family: Family A (Strategic Adjudication Package)
Tier: Tier 3 (High-Value)

This scenario demonstrates a conflict between two automated gates:
1. Timing Gate (T-01): Fails (Negative Slack)
2. Power Gate (P-01): Passes (Under Budget)
"""

import asyncio
from ic_agent_flow.domain.governance import (
    ContextManifest,
    CloseoutBundle,
    HumanReviewPackage
)
from ic_agent_flow.domain.governance.checkpoint import DecisionEnum, StageGateType, AuthorityRecord
from ic_agent_flow.domain.governance.events import emit_governance_event, StallEvent
from ic_agent_flow.domain.governance.registry import ReadinessRegistry

async def run_timing_vs_power_conflict_scenario():
    registry = ReadinessRegistry()
    
    print("--- Step 1: Automated Gate Evaluations ---")
    print("GATE T-01: FAILED. Negative Slack on clk_fast_path_3 (-45ps).")
    print("GATE P-01: PASSED. Total power within 120mW budget.")
    
    print("--- Step 2: Conflict Detection ---")
    print("CONFLICT: Timing fail on path_3 but Power is very healthy.")
    
    print("--- Step 3: HEARTBEAT_STALL for Strategic Adjudication ---")
    stall = StallEvent(
        run_id="run_conflict_001",
        reason="Cross-Gate Conflict (Timing Fail vs Power Pass). Strategic Adjudication needed.",
        expected_action="Operator must decide if path_3 is non-critical or needs rework."
    )
    emit_governance_event(stall)
    
    # Prepare Review Package
    review_pkg = HumanReviewPackage(
        subject_ref="fast-path-3-violation",
        gate_type=StageGateType.EXCEPTION_ACCEPTANCE,
        summary="Path 3 is a diagnostic port used only for debug. Accepting timing violation."
    )
    
    # Human Authority Decision
    print("H-GATE: Human Authority adjudicating conflict...")
    auth_record = AuthorityRecord(
        decision=DecisionEnum.APPROVE,
        rationale="Path is non-critical debug logic. Accepting timing violation.",
        approver="LeadArchitect",
        gate_type=StageGateType.EXCEPTION_ACCEPTANCE
    )
    
    # Record in Registry
    registry.propose_claim(
        subject_id="path-3-strategic-waiver",
        subject_type="scenario",
        evidence_link="conflict_bundle_001.json"
    )
    registry.process_authority_record("path-3-strategic-waiver", auth_record)
    
    # Final Bundle
    bundle = CloseoutBundle(
        run_id="run_conflict_001",
        manifest=ContextManifest(subjects=["debug_module_v1"]),
        verdicts={
            "T-01": "FAILED_ACC-BY-HUMAN",
            "P-01": "PASSED"
        },
        authority=auth_record
    )
    
    print(f"Scenario Complete. Final Verdict: {bundle.authority.decision}")

if __name__ == "__main__":
    asyncio.run(run_timing_vs_power_conflict_scenario())
