"""
Agent Runtime State Machine (Phase 1, D1-4 & D1-5)
====================================================
Defines the execution states and valid transitions for bounded agent runs.

States follow fail-closed semantics:
- Unknown transitions → FAILED
- Missing chip scope → FAILED (before reaching RUNNING)
- timeout / escalation → ESCALATED (never silently continues)
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

from pydantic import BaseModel, Field


class RunState(str, Enum):
    """v0.4 Agent execution state taxonomy (D1-4)."""
    PENDING = "pending"
    CONTEXT_RESOLVED = "context_resolved"
    RUNNING = "running"
    WAITING_FOR_ARTIFACT = "waiting_for_artifact"
    TRIAGE_READY = "triage_ready"
    WAITING_FOR_HUMAN_REVIEW = "waiting_for_human_review"
    COMPLETED = "completed"
    BLOCKED = "blocked"
    FAILED = "failed"
    ESCALATED = "escalated"


# Valid state transitions (D1-5) — fail-closed: anything not listed → FAILED
VALID_TRANSITIONS: Dict[RunState, List[RunState]] = {
    RunState.PENDING: [RunState.CONTEXT_RESOLVED, RunState.FAILED, RunState.ESCALATED],
    RunState.CONTEXT_RESOLVED: [RunState.RUNNING, RunState.FAILED, RunState.ESCALATED],
    RunState.RUNNING: [RunState.WAITING_FOR_ARTIFACT, RunState.TRIAGE_READY, RunState.FAILED, RunState.ESCALATED],
    RunState.WAITING_FOR_ARTIFACT: [RunState.TRIAGE_READY, RunState.BLOCKED, RunState.FAILED, RunState.ESCALATED],
    RunState.TRIAGE_READY: [RunState.WAITING_FOR_HUMAN_REVIEW, RunState.COMPLETED, RunState.FAILED],
    RunState.WAITING_FOR_HUMAN_REVIEW: [RunState.COMPLETED, RunState.BLOCKED, RunState.ESCALATED],
    # Terminal states — no further transitions
    RunState.COMPLETED: [],
    RunState.BLOCKED: [],
    RunState.FAILED: [],
    RunState.ESCALATED: [],
}


class StateTransitionError(Exception):
    """Raised when an illegal state transition is attempted."""
    pass


class StateTransitionEvent(BaseModel):
    """Records a single state transition with reason."""
    from_state: RunState
    to_state: RunState
    reason: str
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class AgentRunState(BaseModel):
    """
    The live state of a single agent execution run.
    Maintains history of all transitions for audit purposes.
    """
    run_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    agent_id: str
    chip_scope: str
    task_id: str
    current_state: RunState = RunState.PENDING
    history: List[StateTransitionEvent] = Field(default_factory=list)
    failure_reason: Optional[str] = None
    escalation_reason: Optional[str] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    @property
    def is_terminal(self) -> bool:
        return self.current_state in {
            RunState.COMPLETED, RunState.BLOCKED,
            RunState.FAILED, RunState.ESCALATED
        }

    def transition(self, to: RunState, reason: str) -> None:
        """
        Attempt a state transition. Raises StateTransitionError if illegal.
        Records the event in history — always.
        """
        allowed = VALID_TRANSITIONS.get(self.current_state, [])

        if to not in allowed:
            # Fail-closed: illegal transition → forced FAILED
            msg = (
                f"Illegal transition: {self.current_state} → {to}. "
                f"Allowed: {[s.value for s in allowed]}. "
                "Fail-closed: marking run as FAILED."
            )
            self.history.append(StateTransitionEvent(
                from_state=self.current_state,
                to_state=RunState.FAILED,
                reason=msg,
            ))
            self.current_state = RunState.FAILED
            self.failure_reason = msg
            self.updated_at = datetime.now(timezone.utc)
            raise StateTransitionError(msg)

        self.history.append(StateTransitionEvent(
            from_state=self.current_state,
            to_state=to,
            reason=reason,
        ))
        self.current_state = to
        self.updated_at = datetime.now(timezone.utc)

        # Capture failure / escalation reason for audit
        if to == RunState.FAILED:
            self.failure_reason = reason
        elif to == RunState.ESCALATED:
            self.escalation_reason = reason

    def fail(self, reason: str) -> None:
        """Convenience method to force FAILED state."""
        if not self.is_terminal:
            self.transition(RunState.FAILED, reason)

    def escalate(self, reason: str) -> None:
        """Convenience method to force ESCALATED state."""
        if not self.is_terminal:
            self.transition(RunState.ESCALATED, reason)


class RunResult(BaseModel):
    """
    Final container for an agent execution run (D1-4 Summary).
    Bundles the state history, the task, and the cognitive outcomes.
    """
    state: AgentRunState
    task: Any                                   # TaskRequest
    cognitive_output: Optional[str] = None
    audit_json: Optional[Dict[str, Any]] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    @property
    def is_success(self) -> bool:
        return self.state.current_state == RunState.COMPLETED
