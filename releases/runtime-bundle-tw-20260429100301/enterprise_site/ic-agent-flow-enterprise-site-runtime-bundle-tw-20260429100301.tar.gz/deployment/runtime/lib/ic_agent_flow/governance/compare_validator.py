from .schemas.compare_contract import CompareContract

class CompareValidator:
    @staticmethod
    def validate(data: dict) -> bool:
        contract = CompareContract(**data)
        contract.validate_sources()
        return True
