"""
Decision Object Families (v0.5, PRD R2)
========================================
Formally defines the authority-bearing objects for the Human-Agent Decision Loop.
These objects transition the system from simple callbacks to a governed decision system.
"""
from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import List, Optional, Dict, Any
from uuid import uuid4

from pydantic import BaseModel, Field, UUID4

from ic_agent_flow.domain.governance.checkpoint import DecisionEnum, RoleEnum
from ic_agent_flow.domain.utils.time import get_tw_now


class ObligationStatus(str, Enum):
    PENDING = "PENDING"
    PARTIALLY_MET = "PARTIALLY_MET"
    MET = "MET"
    OVERRIDDEN = "OVERRIDDEN"
    WAIVED = "WAIVED"


class ObligationItem(BaseModel):
    """Machine-followable obligation arising from conditional approval."""
    obligation_id: UUID4 = Field(default_factory=uuid4)
    description: str
    assignee: str
    due_by: Optional[datetime] = None
    status: ObligationStatus = ObligationStatus.PENDING
    evidence_ref: Optional[str] = None


class DecisionRequest(BaseModel):
    """Represents a formal request for human authority."""
    request_id: UUID4 = Field(default_factory=uuid4)
    bundle_id: str
    chip_scope: str
    requested_by: str  # human_id or agent_id
    role_id: RoleEnum
    requested_decision_types: List[DecisionEnum]
    created_at: datetime = Field(default_factory=get_tw_now)


class DecisionAssignment(BaseModel):
    """Assignment of a DecisionRequest to a specific human role."""
    assignment_id: UUID4 = Field(default_factory=uuid4)
    request_id: UUID4
    assigned_to: str  # human_id
    assigned_role: RoleEnum
    deadline_at: Optional[datetime] = None
    assigned_at: datetime = Field(default_factory=get_tw_now)


class ConditionalApprovalRecord(BaseModel):
    """Formal record of approval subject to specific obligations."""
    conditional_id: UUID4 = Field(default_factory=uuid4)
    decision_record_id: str
    bundle_id: str
    chip_scope: str
    obligations: List[ObligationItem]
    status: ObligationStatus = ObligationStatus.PENDING
    created_at: datetime = Field(default_factory=get_tw_now)


class RuntimeState(str, Enum):
    PENDING = "PENDING"
    IN_PROGRESS = "IN_PROGRESS"
    SUBMITTED = "SUBMITTED"
    EXPIRED = "EXPIRED"


class EvidenceRequestRecord(BaseModel):
    """Formal request for additional evidence, driving runtime re-entry."""
    request_id: UUID4 = Field(default_factory=uuid4)
    decision_record_id: str
    bundle_id: str
    chip_scope: str
    requested_by: str  # human_id
    requested_artifacts: List[str]  # e.g. ["simulation_log", "coverage_report"]
    resubmission_task_id: str
    runtime_state: RuntimeState = RuntimeState.PENDING
    
    # Re-entry linkage (PRD Phase 3)
    related_skill_output_refs: List[str] = []  # Links to gaps/triage that triggered this
    
    created_at: datetime = Field(default_factory=get_tw_now)
    submitted_at: Optional[datetime] = None


class ConflictType(str, Enum):
    ROLE_CONFLICT = "ROLE_CONFLICT"
    DECISION_MISMATCH = "DECISION_MISMATCH"
    CONDITION_CONFLICT = "CONDITION_CONFLICT"


class DecisionConflictRecord(BaseModel):
    """Detected conflict between multiple human decisions."""
    conflict_id: UUID4 = Field(default_factory=uuid4)
    bundle_id: str
    chip_scope: str
    conflicting_decision_record_ids: List[str]
    conflict_type: ConflictType
    detected_at: datetime = Field(default_factory=get_tw_now)
    resolution_ref: Optional[str] = None


class DecisionResolutionRecord(BaseModel):
    """Formal resolution of a DecisionConflictRecord by high authority."""
    resolution_id: UUID4 = Field(default_factory=uuid4)
    conflict_id: UUID4
    resolved_by: str  # human_id
    resolved_role: RoleEnum
    resolution_decision: DecisionEnum
    resolution_rationale: str
    resolved_at: datetime = Field(default_factory=get_tw_now)


class DecisionAuditBundle(BaseModel):
    """Aggregated governance bundle for a closed decision loop."""
    audit_bundle_id: UUID4 = Field(default_factory=uuid4)
    bundle_id: str
    chip_scope: str
    review_package_ref: str
    evidence_refs: List[str] = []
    decision_assignment_refs: List[str] = []
    decision_record_refs: List[str] = []
    conditional_approval_refs: List[str] = []
    evidence_request_refs: List[str] = []
    conflict_record_refs: List[str] = []
    resolution_record_refs: List[str] = []
    # Skill Layer Integration (PRD Phase 3)
    skill_invocation_refs: List[str] = []
    skill_output_refs: List[str] = []
    skill_trace_refs: List[str] = []
    
    bundle_digest: str  # HMAC-SHA256 integrity protection anchor
    metadata: Dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=get_tw_now)


class RoleGrantRecord(BaseModel):
    """Governance record of a role granted to a human."""
    grant_id: UUID4 = Field(default_factory=uuid4)
    granted_to: str  # human_id
    role: RoleEnum
    granted_by: str  # Admin human_id
    scope: str = "*"  # chip_scope or "*"
    granted_at: datetime = Field(default_factory=get_tw_now)
    expires_at: Optional[datetime] = None
    is_revoked: bool = False
