from enum import Enum
from typing import List, Optional
from pydantic import BaseModel
from ic_agent_flow.domain.objects import DataClassification

class SecurityConstraints(BaseModel):
    """Operational boundaries for a specific IP Tier."""
    allow_network_egress: bool
    allow_external_summarization: bool
    mandatory_human_checkpoint: bool
    allowed_execution_modes: List[str] # e.g. ["local", "slurm"]
    audit_level: str # e.g. "basic", "enhanced", "full"

class IPTierPolicy:
    """
    Maps DataClassification to active operational constraints.
    """
    
    POLICY_MAP = {
        DataClassification.PUBLIC: SecurityConstraints(
            allow_network_egress=True,
            allow_external_summarization=True,
            mandatory_human_checkpoint=False,
            allowed_execution_modes=["local", "remote", "cloud"],
            audit_level="basic"
        ),
        DataClassification.INTERNAL_RESTRICTED: SecurityConstraints(
            allow_network_egress=False,
            allow_external_summarization=True,
            mandatory_human_checkpoint=True,
            allowed_execution_modes=["local", "slurm"],
            audit_level="enhanced"
        ),
        DataClassification.HIGHLY_SENSITIVE_DESIGN: SecurityConstraints(
            allow_network_egress=False,
            allow_external_summarization=False,
            mandatory_human_checkpoint=True,
            allowed_execution_modes=["local"], # Fail-closed on any remote/cloud
            audit_level="full"
        )
    }
    
    @staticmethod
    def get_constraints(classification: DataClassification) -> SecurityConstraints:
        return IPTierPolicy.POLICY_MAP.get(
            classification, 
            IPTierPolicy.POLICY_MAP[DataClassification.HIGHLY_SENSITIVE_DESIGN] # Default to safest
        )
