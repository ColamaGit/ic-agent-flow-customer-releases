"""
Decision Audit Bundle Builder (v0.5, PRD R8)
========================================
Assembles all decision-loop artifacts into a single verifiable bundle.
"""
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from typing import List

from ic_agent_flow.domain.objects.decision_objects import DecisionAuditBundle


class DecisionAuditBundleBuilder:
    """
    PRD R8: Replayability / Traceability Law.
    Aggregates the entire decision history.
    """

    @staticmethod
    def build_bundle(
        bundle_id: str,
        chip_scope: str,
        review_package_ref: str,
        decision_record_refs: List[str],
        final_disposition_ref: str,
        evidence_request_refs: List[str] = None,
        conflict_refs: List[str] = None,
    ) -> DecisionAuditBundle:
        """
        Creates a DecisionAuditBundle and computes an integrity digest.
        """
        audit_bundle = DecisionAuditBundle(
            bundle_id=bundle_id,
            chip_scope=chip_scope,
            review_package_ref=review_package_ref,
            decision_record_refs=decision_record_refs,
            final_disposition_ref=final_disposition_ref,
            evidence_request_refs=evidence_request_refs or [],
            conflict_record_refs=conflict_refs or [],
            bundle_digest="pending",
        )

        # Compute integrity anchor over all references
        refs_flat = sorted([
            review_package_ref,
            final_disposition_ref,
            *audit_bundle.decision_record_refs,
            *audit_bundle.evidence_request_refs,
            *audit_bundle.conflict_record_refs,
        ])
        digest = hashlib.sha256(json.dumps(refs_flat).encode("utf-8")).hexdigest()
        audit_bundle.bundle_digest = f"sha256:{digest}"
        
        return audit_bundle
