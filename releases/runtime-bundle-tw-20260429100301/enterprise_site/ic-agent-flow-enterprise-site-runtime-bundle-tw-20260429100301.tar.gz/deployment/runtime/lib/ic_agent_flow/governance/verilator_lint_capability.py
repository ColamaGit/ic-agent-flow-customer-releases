from __future__ import annotations

import hashlib
import json
import re
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional
from uuid import uuid4

from pydantic import BaseModel

from ic_agent_flow.registry.scenario_registry import Disposition


class VerilatorLintMcpCapabilityRequest(BaseModel):
    workspace_id: str
    chip_id: str
    task_id: str
    decision_context_ref: str
    contract_name: str
    contract_version: str
    rtl_path: str
    top_module: str
    timeout_sec: int = 60
    output_root: str = "artifacts/v0.9/verilator_lint"
    verilator_bin: str = "/usr/local/bin/verilator"
    request_schema_version: str = "v0.1"
    run_key: Optional[str] = None


class VerilatorLintMcpCapabilityResponse(BaseModel):
    disposition: Disposition
    reason: str
    contract_id: str
    request_schema_version: str
    boundary_mode: str
    error_taxonomy: List[str]
    run_id: Optional[str] = None
    execution_run_ref: Optional[str] = None
    tool_version: Optional[str] = None
    warning_count: int = 0
    error_count: int = 0
    artifact_paths: Dict[str, str] = {}
    artifact_refs: Dict[str, str] = {}


VerilatorLintMcpCapabilityRequest.model_rebuild()
VerilatorLintMcpCapabilityResponse.model_rebuild()


class VerilatorLintMcpCapabilityBoundary:
    """
    Formal MCP capability boundary for Verilator RTL Lint (V1-Stage).

    This is the first gate in the V-Stage pipeline. Invokes Verilator with
    --lint-only to detect syntax, width, and naming issues in RTL before
    any synthesis stage. Produces a normalized lint.meta.json and evidence
    bundle for downstream consumption by the v0.2 Readiness Report Compiler.
    """

    CAPABILITY_NAME = "verilator_rtl_lint"
    CONTRACT_NAME   = "verilator_lint_contract"
    CONTRACT_VERSION = "v0.1"
    BOUNDARY_MODE   = "formal_mcp_capability_boundary_local_mode_v0.1"
    ERROR_TAXONOMY  = [
        "chip_scope_unresolved",
        "input_schema_invalid",
        "tool_missing",
        "tool_timeout",
        "tool_runtime_error",
        "artifact_missing",
        "output_unparseable",
        "decision_context_mismatch",
    ]

    @staticmethod
    def _sha256_file(path: Path) -> str:
        h = hashlib.sha256()
        with path.open("rb") as f:
            while True:
                chunk = f.read(8192)
                if not chunk:
                    break
                h.update(chunk)
        return h.hexdigest()

    @classmethod
    def _fail(
        cls, reason: str, req: VerilatorLintMcpCapabilityRequest
    ) -> VerilatorLintMcpCapabilityResponse:
        return VerilatorLintMcpCapabilityResponse(
            disposition=Disposition.FAIL_CLOSED,
            reason=reason,
            contract_id=f"{req.contract_name}@{req.contract_version}",
            request_schema_version=req.request_schema_version,
            boundary_mode=cls.BOUNDARY_MODE,
            error_taxonomy=list(cls.ERROR_TAXONOMY),
        )

    @staticmethod
    def _parse_lint_output(raw: str) -> Dict:
        """
        Parse Verilator lint output and extract warning/error counts and issues.
        Returns a dict with warning_count, error_count, issues list.
        """
        issues = []
        warning_count = 0
        error_count = 0

        # Patterns: %Warning-TYPE: file:line:col: message
        warn_pattern = re.compile(
            r"^%Warning(-(\w+))?:\s*(.+?):(\d+):(\d+):\s*(.+)$", re.MULTILINE
        )
        error_pattern = re.compile(
            r"^%Error(-(\w+))?:\s*(.+?):(\d+):(\d+):\s*(.+)$", re.MULTILINE
        )

        for m in warn_pattern.finditer(raw):
            warning_count += 1
            issues.append({
                "level":   "warning",
                "type":    m.group(2) or "UNKNOWN",
                "file":    m.group(3),
                "line":    int(m.group(4)),
                "col":     int(m.group(5)),
                "message": m.group(6).strip(),
            })

        for m in error_pattern.finditer(raw):
            if "Exiting due to" in m.group(6):
                continue  # Ignore Verilator's synthetic summary error
            error_count += 1
            issues.append({
                "level":   "error",
                "type":    m.group(2) or "UNKNOWN",
                "file":    m.group(3),
                "line":    int(m.group(4)),
                "col":     int(m.group(5)),
                "message": m.group(6).strip(),
            })

        return {
            "warning_count": warning_count,
            "error_count":   error_count,
            "issues":        issues,
        }

    def execute(
        self, req: VerilatorLintMcpCapabilityRequest
    ) -> VerilatorLintMcpCapabilityResponse:
        # ── 1. Input Validation ──────────────────────────────────────────────
        required = [
            req.workspace_id, req.chip_id, req.task_id,
            req.decision_context_ref, req.contract_name,
            req.contract_version, req.rtl_path, req.top_module,
        ]
        if any(not v for v in required):
            return self._fail("input_schema_invalid:envelope_missing", req)

        if req.contract_name != self.CONTRACT_NAME or req.contract_version != self.CONTRACT_VERSION:
            return self._fail("input_schema_invalid:unsupported_contract", req)

        if not req.decision_context_ref.startswith("decision://"):
            return self._fail("decision_context_mismatch:invalid_context", req)

        rtl_path = Path(req.rtl_path)
        if not rtl_path.exists():
            return self._fail("input_schema_invalid:rtl_not_found", req)

        if not Path(req.verilator_bin).exists() and shutil.which(req.verilator_bin) is None:
            return self._fail("tool_missing:verilator_not_found", req)

        # ── 2. Prepare Output Directory ───────────────────────────────────────
        run_id   = req.run_key or f"vlint-{uuid4().hex[:12]}"
        out_dir  = Path(req.output_root) / run_id
        out_dir.mkdir(parents=True, exist_ok=True)

        raw_log_path       = out_dir / "verilator_lint.raw.log"
        normalized_path    = out_dir / "normalized.lint.meta.json"
        input_manifest_path = out_dir / "input_manifest.json"
        lineage_path       = out_dir / "lineage.json"
        evidence_bundle_path = out_dir / "evidence_bundle.json"

        # ── 3. Collect RTL files ──────────────────────────────────────────────
        rtl_inputs: List[Dict] = []
        v_files: List[Path] = []

        if rtl_path.is_dir():
            all_files = list(rtl_path.glob("*.v")) + list(rtl_path.glob("*.sv"))
            v_files = [
                f for f in all_files
                if "testbench" not in f.name.lower()
                and not f.name.lower().endswith("_tb.v")
                and not f.name.lower().endswith("_tb.sv")
            ]
            rtl_inputs = [
                {"path": f.as_posix(), "sha256": self._sha256_file(f)}
                for f in v_files
            ]
        else:
            v_files = [rtl_path]
            rtl_inputs = [{"path": rtl_path.as_posix(), "sha256": self._sha256_file(rtl_path)}]

        if not v_files:
            return self._fail("input_schema_invalid:no_verilog_files_found", req)

        # ── 4. Build Verilator Command ────────────────────────────────────────
        cmd = [
            req.verilator_bin,
            "--lint-only", "-Wall",
            # Silence non-critical warnings that are not design faults
            "-Wno-DECLFILENAME",  # allow file/module name mismatch (common in multi-file design)
            "--top-module", req.top_module,
        ]
        if rtl_path.is_dir():
            cmd.append(f"-I{rtl_path.as_posix()}")
        cmd += [f.as_posix() for f in v_files]

        # ── 5. Execute Tool ───────────────────────────────────────────────────
        started_at = datetime.now(timezone.utc)
        try:
            proc = subprocess.run(
                cmd,
                cwd=str(Path.cwd()),
                capture_output=True,
                text=True,
                timeout=req.timeout_sec,
            )
            finished_at = datetime.now(timezone.utc)
        except subprocess.TimeoutExpired:
            raw_log_path.write_text("tool_timeout: verilator exceeded timeout\n", encoding="utf-8")
            return self._fail("tool_timeout:verilator_execution_timeout", req)

        raw_output = (proc.stdout or "") + (proc.stderr or "")
        raw_log_path.write_text(raw_output, encoding="utf-8")

        # ── 6. Parse Results ──────────────────────────────────────────────────
        parsed = self._parse_lint_output(raw_output)
        warning_count = parsed["warning_count"]
        error_count   = parsed["error_count"]

        # Verilator lint-only: exit code 0 = clean or warnings only; non-zero = errors
        has_errors = error_count > 0
        lint_status = "FAIL" if has_errors else ("WARN" if warning_count > 0 else "PASS")

        # ── 7. Get Tool Version ────────────────────────────────────────────────
        ver_proc = subprocess.run(
            [req.verilator_bin, "--version"],
            capture_output=True, text=True, timeout=10,
        )
        tool_version = (ver_proc.stdout or ver_proc.stderr or "").strip().splitlines()[0] if ver_proc.returncode == 0 else "unknown"

        # ── 8. Write Artifacts ────────────────────────────────────────────────
        duration_ms = int((finished_at - started_at).total_seconds() * 1000)

        input_manifest = {
            "workspace_id":       req.workspace_id,
            "chip_id":            req.chip_id,
            "task_id":            req.task_id,
            "contract_name":      req.contract_name,
            "contract_version":   req.contract_version,
            "decision_context_ref": req.decision_context_ref,
            "tool":               "verilator",
            "tool_version":       tool_version,
            "tool_binary_path":   req.verilator_bin,
            "command":            " ".join(cmd),
            "cwd":                str(Path.cwd()),
            "rtl_inputs":         rtl_inputs,
            "top_module":         req.top_module,
            "generated_at":       datetime.now(timezone.utc).isoformat(),
        }
        input_manifest_path.write_text(json.dumps(input_manifest, indent=2), encoding="utf-8")

        normalized = {
            "tool":             "verilator",
            "tool_version":     tool_version,
            "tool_binary_path": req.verilator_bin,
            "contract_name":    req.contract_name,
            "contract_version": req.contract_version,
            "chip_id":          req.chip_id,
            "top_module":       req.top_module,
            "status":           lint_status,
            "exit_code":        proc.returncode,
            "warning_count":    warning_count,
            "error_count":      error_count,
            "issues":           parsed["issues"],
            "raw_log_ref":      raw_log_path.as_posix(),
            "generated_at":     datetime.now(timezone.utc).isoformat(),
        }
        normalized_path.write_text(json.dumps(normalized, indent=2), encoding="utf-8")

        lineage = {
            "run_id":             run_id,
            "started_at":         started_at.isoformat(),
            "finished_at":        finished_at.isoformat(),
            "exit_code":          proc.returncode,
            "duration_ms":        duration_ms,
            "command_argv":       cmd,
            "working_dir":        str(Path.cwd()),
            "input_manifest_ref": input_manifest_path.as_posix(),
            "output_refs":        [raw_log_path.as_posix(), normalized_path.as_posix()],
            "decision_context_ref": req.decision_context_ref,
            "task_id":            req.task_id,
            "workspace_id":       req.workspace_id,
            "chip_id":            req.chip_id,
        }
        lineage_path.write_text(json.dumps(lineage, indent=2), encoding="utf-8")

        evidence_bundle = {
            "run_id":          run_id,
            "raw_refs":        [raw_log_path.as_posix()],
            "normalized_refs": [normalized_path.as_posix()],
            "lineage_ref":     lineage_path.as_posix(),
            "digests": {
                "raw_log_sha256":   self._sha256_file(raw_log_path),
                "normalized_sha256": self._sha256_file(normalized_path),
                "input_manifest_sha256": self._sha256_file(input_manifest_path),
                "lineage_sha256":   self._sha256_file(lineage_path),
            },
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }
        evidence_bundle_path.write_text(json.dumps(evidence_bundle, indent=2), encoding="utf-8")

        # ── 9. Return ─────────────────────────────────────────────────────────
        # PASS = no errors (warnings are acceptable at WARN level)
        disposition = Disposition.FAIL_CLOSED if has_errors else Disposition.PASS

        return VerilatorLintMcpCapabilityResponse(
            disposition=disposition,
            reason=f"verilator_lint:{lint_status};warnings={warning_count};errors={error_count}",
            contract_id=f"{req.contract_name}@{req.contract_version}",
            request_schema_version=req.request_schema_version,
            boundary_mode=self.BOUNDARY_MODE,
            error_taxonomy=list(self.ERROR_TAXONOMY),
            run_id=run_id,
            execution_run_ref=f"run://{self.CAPABILITY_NAME}/{run_id}",
            tool_version=tool_version,
            warning_count=warning_count,
            error_count=error_count,
            artifact_paths={
                "raw_log":          raw_log_path.as_posix(),
                "normalized_meta":  normalized_path.as_posix(),
                "input_manifest":   input_manifest_path.as_posix(),
                "lineage":          lineage_path.as_posix(),
                "evidence_bundle":  evidence_bundle_path.as_posix(),
            },
            artifact_refs={
                "raw_log_ref":          f"artifact://verilator_lint/{run_id}/verilator_lint.raw.log",
                "normalized_ref":       f"norm://verilator_lint/{run_id}/normalized.lint.meta.json",
                "lineage_ref":          f"lineage://verilator_lint/{run_id}/lineage.json",
                "evidence_bundle_ref":  f"evidence_bundle://verilator_lint/{run_id}",
            },
        )
