from typing import List, Optional
from pydantic import BaseModel, ConfigDict
from enum import Enum
from datetime import datetime
from uuid import UUID

class ReadinessLevel(str, Enum):
    """The formal PRD escalation ladder for IC flow readiness."""
    INVENTORY_READY = "inventory_ready"
    READABLE_READY = "readable_ready"
    CONTRACTED_READY = "contracted_ready"
    VERIFICATION_READY = "verification_ready"
    HUMAN_GOVERNED_READY = "human_governed_ready"
    ECO_READY = "eco_ready"
    SIGNOFF_ASSIST_READY = "signoff_assist_ready"

class SubjectType(str, Enum):
    """Granular scoping to avoid forcing a single global readiness."""
    SCENARIO = "scenario"
    SCENARIO_FAMILY = "scenario-family"
    CAPABILITY = "capability"
    SYSTEM_PLANE = "plane"
    SUBSYSTEM = "subsystem"

class ClaimStatus(str, Enum):
    ACTIVE = "active"
    PROPOSED = "proposed"
    SUPERSEDED = "superseded"
    REVOKED = "revoked"
    PENDING_REVALIDATION = "pending_revalidation"

class RevalidationRecord(BaseModel):
    """Tracks a single revalidation event triggered by drift detection."""
    timestamp: datetime
    trigger_type: str # e.g., security_policy_change, new_scenario
    reason: str
    checks_performed: List[str]
    result: str # PASS / FAIL
    auditor: str

class StrategicMaturityClaim(BaseModel):
    """
    Formal detailed maturity statement for a specific capability or scenario line.
    Moves from 'subjective text' to 'verifiable governance boundary'.
    """
    id: UUID
    claim_type: str # e.g., security_readiness_claim, high_value_ip_protection_claim
    scope: str # scenarios, object classes, execution modes
    threat_boundary: List[str] # List of mitigated risks
    fail_closed_triggers: List[str] # Conditions triggering mandatory Verdict.FAILED
    required_evidence_classes: List[str]
    audit_completeness_criteria: List[str]
    forbidden_execution_patterns: List[str]
    known_limitations: List[str]
    revalidation_cadence: str
    version: str = "v1.0.0"

class ReadinessEntry(BaseModel):
    """Formal registry entry moving readiness from passive text to active OS object."""
    id: UUID
    subject_type: SubjectType
    subject_id: str
    claimed_level: ReadinessLevel
    previous_level: Optional[ReadinessLevel] = None
    scope: str
    entry_criteria_refs: List[str]
    evidence_refs: List[str]
    review_refs: List[str]
    known_gaps: List[str]
    forbidden_claims: List[str]
    maturity_claim_ref: Optional[str] = None # Reference to StrategicMaturityClaim JSON
    status: ClaimStatus = ClaimStatus.ACTIVE
    approved_by: str
    approved_at: datetime
    expires_at: Optional[datetime] = None
    revalidation_history: List[RevalidationRecord] = []
    
    model_config = ConfigDict(use_enum_values=True)
