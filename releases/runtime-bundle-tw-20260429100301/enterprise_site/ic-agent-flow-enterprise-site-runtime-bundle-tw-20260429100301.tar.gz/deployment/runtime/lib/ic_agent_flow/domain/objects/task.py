"""
Task Intake Object (Phase 1, D1-2)
===================================
Defines the formal task_request schema for the Evidence Collector Agent.
This is the entry point for all agent work in v0.4.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, Optional

from pydantic import BaseModel, Field


class TaskType(str, Enum):
    """Supported task types for v0.4 Evidence Collector Agent."""
    XCELIUM_SIMULATION_TRIAGE = "xcelium_simulation_triage"
    SIMULATION_EVIDENCE_COLLECTION = "simulation_evidence_collection"
    VERIFICATION_TRIAGE = "verification_triage"


class TaskStatus(str, Enum):
    """Task lifecycle status."""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    ESCALATED = "escalated"


class TaskRequest(BaseModel):
    """
    Formal task intake object (D1-2).
    All agent work begins with a TaskRequest.
    """
    task_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    task_type: str                              # TaskType enum value or free string
    workspace_id: str = "default-workspace"
    chip_id: str                                # REQUIRED — chip scope binding
    requester: str = "operator"
    requested_capability: str = "simulation_evidence_triage"
    description: Optional[str] = None
    expected_outputs: list[str] = Field(default_factory=lambda: [
        "simulation_result",
        "verification_triage_result",
        "evidence_bundle_ref",
    ])
    authority_class: str = "operator_request"
    metadata: Dict[str, Any] = Field(default_factory=dict)
    status: TaskStatus = TaskStatus.PENDING
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
