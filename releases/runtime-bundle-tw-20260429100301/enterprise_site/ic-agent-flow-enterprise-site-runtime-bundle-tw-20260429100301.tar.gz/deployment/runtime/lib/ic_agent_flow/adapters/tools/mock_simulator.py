from datetime import datetime, timezone
from uuid import uuid4
from ic_agent_flow.domain.objects import AuthorityClass, Producer, ProducerType
from ic_agent_flow.domain.execution import ToolCommand, ExecutionBounds, SimulationResult
import time

class MockSimulator:
    """Simulates a Logic Simulator like VCS or Xcelium."""
    
    def __init__(self, tool_name: str, version: str):
        self.tool_name = tool_name
        self.version = version
        
    def execute(self, cmd: ToolCommand, bounds: ExecutionBounds) -> SimulationResult:
        """Mocks the execution of a simulation, adhering to bounds."""
        
        # 1. Bounds Validation
        if cmd.tool_name not in bounds.allowed_tools:
            return SimulationResult(
                id=uuid4(),
                version="v1.0.0",
                authority_class=AuthorityClass.DERIVED,
                producer=Producer(id=self.tool_name, type=ProducerType.AGENT),
                status="FAILED",
                exit_code=-1,
                metadata={"error": "Tool not in allowed_tools"},
                created_at=datetime.now(timezone.utc)
            )
            
        for arg in cmd.args:
            if arg in bounds.forbidden_args:
                return SimulationResult(
                    id=uuid4(),
                    version="v1.0.0",
                    authority_class=AuthorityClass.DERIVED,
                    producer=Producer(id=self.tool_name, type=ProducerType.AGENT),
                    status="FAILED",
                    exit_code=-2,
                    metadata={"error": f"Forbidden flag used: {arg}"},
                    created_at=datetime.now(timezone.utc)
                )

        # 2. Simulate Success
        return SimulationResult(
            id=uuid4(),
            version="v1.0.0",
            authority_class=AuthorityClass.DERIVED,
            producer=Producer(id=self.tool_name, type=ProducerType.AGENT),
            status="SUCCESS",
            exit_code=0,
            coverage_score=98.5,
            pass_count=104,
            fail_count=0,
            metadata={"seed": 12345},
            created_at=datetime.now(timezone.utc)
        )
