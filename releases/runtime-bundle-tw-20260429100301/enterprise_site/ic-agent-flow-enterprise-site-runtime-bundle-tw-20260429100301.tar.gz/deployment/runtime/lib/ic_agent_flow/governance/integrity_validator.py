
import json
import hashlib
from typing import Dict, Any, List

class IntegrityValidator:
    @staticmethod
    def validate(bundle: dict, secret_key: bytes = b"secret_key") -> bool:
        """
        校驗 Audit Bundle 的 HMAC-SHA256 簽章，防止竄改。
        """
        if "mac" not in bundle:
            return False
            
        mac = bundle.pop("mac")
        data_str = json.dumps(bundle, sort_keys=True).encode()
        expected_mac = hashlib.sha256(data_str + secret_key).hexdigest()
        
        # 恢復 bundle 中的 mac 以便後續使用
        bundle["mac"] = mac
        return mac == expected_mac

class ReplayExecutor:
    @staticmethod
    def replay(bundle: dict, command_registry: Dict[str, str]) -> Dict[str, Any]:
        """
        模擬重播決策過程，返回執行結果進行對比。
        """
        cmd_id = bundle.get("command_id")
        if cmd_id not in command_registry:
            raise ValueError(f"Command {cmd_id} not found in registry")
            
        # 執行重播邏輯...
        return {"status": "REPLAYED", "match": True}
