"""
v0.7 Third Bounded Agent — Decision Follow-up / Obligation Resolution Agent
===========================================================================
Agent Identity Definition (PRD v0.7 Benchmark)

Agent C's role is strictly bounded to the resolution of obligations arising from 
formal human decisions (Conditional Approvals). It complies with Law 7 (Human Dominance) 
and Law 9 (Physical Integrity).
"""
from __future__ import annotations

from enum import Enum
from typing import List

from pydantic import BaseModel


# ── Agent Identity Constants ───────────────────────────────────────────────────

AGENT_ID = "decision_followup_agent_v0.7"
AGENT_NAME = "Decision Follow-up / Obligation Resolution Agent"
AGENT_ROLE = "decision_followup"
AGENT_VERSION = "v0.7.0"

AGENT_MISSION = (
    "Automatically resolve technical obligations (ObligationItems) arising from "
    "conditional approvals or evidence requests issued by human authority. "
    "This agent ensures that the 'approve-with-conditions' loop is physically closed "
    "without the agent assuming decision authority نفسه (itself)."
)


# ── Capability Taxonomy ────────────────────────────────────────────────────────

class AgentCapability(str, Enum):
    CONSUME_OBLIGATION_ITEMS = "consume_obligation_items"
    RESOLVE_TECHNICAL_GAPS = "resolve_technical_gaps"
    COORDINATE_RE_SUBMISSION = "coordinate_re_submission"
    UPDATE_SHARED_ISSUE_STATUS = "update_shared_issue_status"
    ATTACH_EVIDENCE_TO_OBLIGATION = "attach_evidence_to_obligation"
    INVOKE_COGNITIVE_BACKEND = "invoke_cognitive_backend"
    ESCALATE_ON_AMBIGUITY = "escalate_on_ambiguity"


class ProhibitedAction(str, Enum):
    # R1: Obligation Source Law
    DERIVE_OBLIGATION_FROM_PROSE = "derive_obligation_from_prose"
    CREATE_OWN_OBLIGATION = "create_own_obligation"
    
    # Authority Boundaries
    APPROVE_RELEASE = "approve_release"
    WAIVE_REQUIREMENT = "waive_requirement"
    OVERRIDE_HUMAN_DECISION = "override_human_decision"
    ISSUE_PASS_VERDICT = "issue_pass_verdict"
    MODIFY_AUTHORITY_CLASS = "modify_authority_class"


class EscalationCondition(str, Enum):
    OBLIGATION_AMBIGUOUS = "obligation_ambiguous"
    EVIDENCE_UNOBTAINABLE = "evidence_unobtainable"
    CONFLICT_WITH_HUMAN_INTENT = "conflict_with_human_intent"
    DEADLOCK_DETECTED = "deadlock_detected"


# ── Agent Identity Contract ────────────────────────────────────────────────────

class AgentIdentity(BaseModel):
    """
    Formal Agent Identity record for Agent C.
    Enforces R1 (Obligation Source) and Operational authority class.
    """
    agent_id: str = AGENT_ID
    agent_name: str = AGENT_NAME
    role: str = AGENT_ROLE
    version: str = AGENT_VERSION
    mission: str = AGENT_MISSION

    may: List[AgentCapability] = list(AgentCapability)
    may_not: List[ProhibitedAction] = list(ProhibitedAction)
    escalation_conditions: List[EscalationCondition] = list(EscalationCondition)

    output_contracts: List[str] = [
        "obligation_resolution_record",
        "evidence_bundle_ref",
        "shared_issue_update",
    ]

    def can_do(self, capability: AgentCapability) -> bool:
        return capability in self.may

    def is_prohibited(self, action: ProhibitedAction) -> bool:
        return action in self.may_not

    def should_escalate(self, condition: EscalationCondition) -> bool:
        return condition in self.escalation_conditions


# Singleton
DECISION_FOLLOWUP_AGENT_IDENTITY = AgentIdentity()
