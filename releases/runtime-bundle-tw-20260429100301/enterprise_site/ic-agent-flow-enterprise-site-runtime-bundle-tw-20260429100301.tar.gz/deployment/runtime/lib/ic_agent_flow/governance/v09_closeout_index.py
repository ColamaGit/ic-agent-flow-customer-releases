from __future__ import annotations

import json
from pathlib import Path
from typing import List

from pydantic import BaseModel

from ic_agent_flow.registry.scenario_registry import CanonicalCommandRegistry, Disposition


class CloseoutEvidenceIndexItem(BaseModel):
    command_id: str
    phase: str
    canonical_command: str
    evidence_path: str
    evidence_exists: bool
    default_disposition_if_missing: Disposition


class CloseoutEvidenceIndex(BaseModel):
    items: List[CloseoutEvidenceIndexItem]
    total_entries: int
    missing_artifact_count: int


def build_closeout_evidence_index(registry: CanonicalCommandRegistry) -> CloseoutEvidenceIndex:
    items: List[CloseoutEvidenceIndexItem] = []
    missing_count = 0
    for entry in registry.entries.values():
        evidence_path = Path(entry.closeout_evidence_path)
        exists = evidence_path.exists()
        if not exists:
            missing_count += 1
        items.append(
            CloseoutEvidenceIndexItem(
                command_id=entry.command_id,
                phase=entry.phase,
                canonical_command=entry.canonical_command,
                evidence_path=entry.closeout_evidence_path,
                evidence_exists=exists,
                default_disposition_if_missing=Disposition.HOLD,
            )
        )
    return CloseoutEvidenceIndex(
        items=items,
        total_entries=len(items),
        missing_artifact_count=missing_count,
    )


def write_closeout_evidence_index(
    index: CloseoutEvidenceIndex,
    json_path: str | Path,
    markdown_path: str | Path,
) -> None:
    json_output = Path(json_path)
    md_output = Path(markdown_path)
    json_output.parent.mkdir(parents=True, exist_ok=True)
    md_output.parent.mkdir(parents=True, exist_ok=True)

    payload = index.model_dump(mode="json")
    json_output.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")

    lines = [
        "# v0.9 Closeout Evidence Index",
        "",
        f"- Total Entries: {index.total_entries}",
        f"- Missing Artifact Count: {index.missing_artifact_count}",
        "",
        "| Command ID | Phase | Evidence Path | Exists | Default Disposition if Missing |",
        "|---|---|---|---|---|",
    ]
    for item in index.items:
        exists = "YES" if item.evidence_exists else "NO"
        lines.append(
            f"| {item.command_id} | {item.phase} | `{item.evidence_path}` | {exists} | {item.default_disposition_if_missing.value} |"
        )
    md_output.write_text("\n".join(lines) + "\n", encoding="utf-8")
