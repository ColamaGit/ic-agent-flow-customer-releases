"""
Sovereignty Guard (v0.1)
========================
Enforces strict physical and logical isolation between chip instances.
Ensures evidence cannot drift across chip boundaries ("Drawer Isolation").
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import List

from ic_agent_flow.domain.objects.production_bridge_objects import SignoffEvidenceManifest

class SovereigntyViolationError(Exception):
    """Raised when a path refers to a resource outside the authorized chip drawer."""
    pass

class SovereigntyGuard:
    """ 
    Enforces the "Drawer Metaphor" by validating path prefixes and 
    canonical chip boundaries.
    """

    @staticmethod
    def verify_chip_boundary(chip_id: str, path_to_check: str, base_chips_path: str = "chips") -> bool:
        """
        Validates that the provided path is strictly within the authorized chip directory.
        Prevents directory traversal and cross-chip leakage.
        """
        authorized_prefix = Path(os.path.abspath(base_chips_path)) / chip_id
        check_path = Path(os.path.abspath(path_to_check))

        # Sovereignty check: check_path must start with authorized_prefix
        try:
            check_path.relative_to(authorized_prefix)
            return True
        except ValueError:
            return False

    @staticmethod
    def validate_manifest_sovereignty(manifest: SignoffEvidenceManifest, base_chips_path: str = "chips") -> List[str]:
        """
        Full audit of a manifest to ensure all evidence refs are sovereign.
        Returns a list of violation paths.
        """
        violations = []
        for ref in manifest.evidence_refs:
            if not SovereigntyGuard.verify_chip_boundary(manifest.chip_id, ref, base_chips_path):
                violations.append(ref)
        return violations
