from typing import Dict, Any

class ReentryContract:
    @staticmethod
    def validate_continuity(old_envelope: Dict[str, Any], new_envelope: Dict[str, Any]) -> bool:
        """
        確保 re-entry 時 Subject Continuity 不中斷
        """
        return old_envelope.get("envelope_id") == new_envelope.get("envelope_id")
