from typing import Dict, Any

class LineageValidator:
    @staticmethod
    def validate_propagation(upstream: Dict[str, Any], downstream: Dict[str, Any]) -> bool:
        """
        驗證 Subject Envelope 是否在上下游正確傳遞
        """
        up_env = upstream.get("execution_subject_envelope")
        down_env = downstream.get("execution_subject_envelope")
        
        if not up_env or not down_env:
            return False
            
        # 確認 EnvelopeID 一致性
        return up_env.get("envelope_id") == down_env.get("envelope_id")
