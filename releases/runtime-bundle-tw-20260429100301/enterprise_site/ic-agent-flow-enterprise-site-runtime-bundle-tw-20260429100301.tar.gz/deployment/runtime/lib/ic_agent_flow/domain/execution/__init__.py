from pydantic import BaseModel, Field
from datetime import datetime
from uuid import UUID, uuid4
from typing import List, Optional, Dict, Any
from ic_agent_flow.domain.objects import BaseObject, AuthorityClass, Producer, ProducerType

class ToolCommand(BaseModel):
    tool_name: str
    version: str
    args: List[str]
    env: Dict[str, str] = Field(default_factory=dict)
    working_dir: str

class ExecutionBounds(BaseModel):
    allowed_tools: List[str]
    forbidden_args: List[str]
    max_memory_gb: int
    timeout_seconds: int

class CompilationResult(BaseObject):
    type: str = "compilation_result"
    status: str # SUCCESS, FAILURE, TIMEOUT
    exit_code: int
    log_hash: str
    error_count: int
    warning_count: int
    artifacts_generated: List[str] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)

class SimulationResult(BaseObject):
    type: str = "simulation_result"
    status: str
    exit_code: int = 0
    coverage_score: float = 0.0
    pass_count: int = 0
    fail_count: int = 0
    metadata: Dict[str, Any] = Field(default_factory=dict)
    
class EquivalenceResult(BaseObject):
    type: str = "equivalence_result"
    is_equivalent: bool
    unmapped_points: int = 0
    failing_points: int = 0
    metadata: Dict[str, Any] = Field(default_factory=dict)

class ToolInvocation(BaseObject):
    type: str = "tool_invocation"
    command: ToolCommand
    bounds_applied: ExecutionBounds
    start_time: datetime
    end_time: Optional[datetime] = None
    result_ref: Optional[str] = None # Reference to CompilationResult/SimulationResult etc.
