from __future__ import annotations

import json
from enum import Enum
from pathlib import Path
from typing import Dict, Optional

from pydantic import BaseModel, Field


class Disposition(str, Enum):
    PASS = "PASS"
    HOLD = "HOLD"
    FAIL_CLOSED = "FAIL_CLOSED"
    ESCALATE = "ESCALATE"


class CommandVerificationVerdict(BaseModel):
    allowed: bool
    disposition: Disposition
    reason: str


class CanonicalCommandEntry(BaseModel):
    command_id: str
    phase: str
    canonical_command: str
    closeout_evidence_path: str
    description: Optional[str] = None


class CanonicalCommandRegistry(BaseModel):
    entries: Dict[str, CanonicalCommandEntry] = Field(default_factory=dict)

    def register(self, entry: CanonicalCommandEntry) -> None:
        self.entries[entry.command_id] = entry

    def resolve(self, command_id: str) -> Optional[CanonicalCommandEntry]:
        return self.entries.get(command_id)

    def verify_command_id(self, command_id: str) -> CommandVerificationVerdict:
        if command_id not in self.entries:
            return CommandVerificationVerdict(
                allowed=False,
                disposition=Disposition.HOLD,
                reason=f"unregistered command id: {command_id}",
            )
        return CommandVerificationVerdict(
            allowed=True,
            disposition=Disposition.PASS,
            reason="registered command id",
        )

    def save_json(self, path: str | Path) -> None:
        output_path = Path(path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        payload = [entry.model_dump(mode="json") for entry in self.entries.values()]
        output_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")

    @classmethod
    def load_json(cls, path: str | Path) -> "CanonicalCommandRegistry":
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
        registry = cls()
        for item in payload:
            entry = CanonicalCommandEntry(**item)
            registry.register(entry)
        return registry
