"""
RBAC Guard (v0.5, PRD R5)
========================================
Enforces the role-based authority matrix for human decisions.
"""
from __future__ import annotations

from ic_agent_flow.domain.governance.checkpoint import (
    AUTHORITY_MATRIX,
    DecisionEnum,
    RoleEnum,
    RolePermission,
)


class PermissionDenied(Exception):
    """Raised when a role attempts an unauthorized decision."""
    pass


class RBACGuard:
    """
    PRD R5: Multi-role authority matrix enforcement.
    Validates visibility and decision authority.
    """

    @staticmethod
    def check_decision_permission(
        role_id: RoleEnum,
        decision: DecisionEnum,
    ) -> None:
        """
        Raises PermissionDenied if the role does not have authority for the decision.
        """
        permissions = AUTHORITY_MATRIX.get(role_id, RolePermission())
        
        if decision in {DecisionEnum.APPROVE, DecisionEnum.APPROVE_WITH_CONDITIONS}:
            if not permissions.can_approve:
                raise PermissionDenied(f"Role {role_id.value} is not authorized to APPROVE.")
        
        if decision == DecisionEnum.ESCALATE:
            if not permissions.can_escalate:
                raise PermissionDenied(f"Role {role_id.value} is not authorized to ESCALATE.")
        
        # General review authority for other types
        if decision in {DecisionEnum.HOLD, DecisionEnum.REJECT, DecisionEnum.REQUEST_MORE_EVIDENCE}:
            if not permissions.can_review:
                raise PermissionDenied(f"Role {role_id.value} is not authorized to perform REVIEWS.")

    @staticmethod
    def check_visibility(
        role_id: RoleEnum,
        artifact_type: str,
    ) -> bool:
        """
        Policy-based visibility check (PRD AC7).
        Minimal baseline implementation.
        """
        permissions = AUTHORITY_MATRIX.get(role_id, RolePermission())
        
        if artifact_type == "audit_log":
            return permissions.can_audit
        
        if artifact_type == "governance_config":
            return permissions.can_admin_roles
            
        return permissions.can_view
