from __future__ import annotations

from enum import Enum
from typing import Dict, List

from pydantic import BaseModel

from ic_agent_flow.registry.scenario_registry import Disposition


class Step(str, Enum):
    A = "A"
    B = "B"
    C = "C"
    D = "D"
    E = "E"
    F = "F"
    G = "G"
    H = "H"


class SequencingGateResult(BaseModel):
    allowed: bool
    disposition: Disposition
    missing_conditions: List[str]


class V09SequencingLaw:
    """
    Implements "Single-Path, Dual-Document Alignment" promotion gates.
    """

    REQUIRED_CONDITIONS: Dict[Step, List[str]] = {
        Step.A: ["boundary_frozen", "precedence_locked", "non_goals_locked"],
        Step.B: ["intent_object_family_ready", "redaction_policy_enforced"],
        Step.C: ["tool_session_exists", "one_shot_not_only_truth", "scope_authority_lineage_pass"],
        Step.D: ["rollback_replayable", "legal_checkpoint_set_exists", "rollback_target_validation_pass"],
        Step.E: ["adjudication_matrix_executable", "validator_schema_evidence_bound", "summary_only_fail_closed_enforced"],
        Step.F: ["no_parallel_review_system", "decision_loop_binding_pass", "authority_chain_preserved"],
        Step.G: ["request_more_evidence_reentry_legal", "delta_and_resubmission_history_complete", "illegal_reentry_disposition_enforced"],
        Step.H: ["tool_session_observability_pass", "surface_points_to_canonical_chain", "branch_is_compatibility_proof_only"],
    }

    FAIL_CLOSED_STEPS = {Step.C, Step.D, Step.E, Step.F, Step.G, Step.H}

    @classmethod
    def can_promote(cls, step: Step, evidence_flags: Dict[str, bool]) -> SequencingGateResult:
        required = cls.REQUIRED_CONDITIONS[step]
        missing = [name for name in required if not evidence_flags.get(name, False)]
        if missing:
            disposition = Disposition.FAIL_CLOSED if step in cls.FAIL_CLOSED_STEPS else Disposition.HOLD
            return SequencingGateResult(allowed=False, disposition=disposition, missing_conditions=missing)
        return SequencingGateResult(allowed=True, disposition=Disposition.PASS, missing_conditions=[])
