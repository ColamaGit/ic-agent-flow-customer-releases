"""
Addendum Phase 1 — Manifest Integrity & Subject Binding Baseline
Schema definitions for scope resolution, manifest binding, and execution subject envelope.
"""

from pydantic import BaseModel
from typing import List, Optional


class ScopeResolutionRecord(BaseModel):
    """
    Represents a formal pre-execution scope resolution result.
    All fields required; resolution_status must be VALIDATED before execution proceeds.
    """
    resolution_id: str
    workspace_id: str
    chip_id: str
    task_id: str
    subject_refs: List[str]
    resolution_status: str = "VALIDATED"
    resolved_by: str
    resolved_at: str


class ManifestBindingRecord(BaseModel):
    """
    Represents a formal manifest binding for an execution run.
    Carries chip identity metadata used by Header Compiler.
    """
    binding_id: str
    chip_program_manifest_ref: str
    chip_program_manifest_digest: str
    bound_scope_resolution_ref: str
    binding_status: str = "BOUND"
    created_at: str
    # Human-readable chip metadata for report surface
    chip_name: str
    rtl_function: str
    description: str
    technology_context: str
    baseline_tools: List[str]
    subject_alias: Optional[str] = None


class ExecutionSubjectEnvelope(BaseModel):
    """
    Execution-scoped subject envelope. Persists chip identity across the full chain.
    decision_context_ref and reentry_history_ref are schema-required but state-nullable
    on fresh pre-decision runs (ED Rule 2). Must always accompany explicit state fields.
    """
    envelope_id: str
    workspace_id: str
    chip_id: str
    chip_program_manifest_ref: str
    chip_program_manifest_digest: str
    task_id: str
    subject_refs: List[str]
    authority_context_refs: List[str] = []
    # State-nullable per ED-2; null allowed on fresh first-run
    decision_context_ref: Optional[str] = None
    decision_state: str  # e.g. PRE_DECISION, UNDER_REVIEW, APPROVED, REJECTED
    reentry_history_ref: Optional[str] = None
    reentry_state: str   # e.g. NO_REENTRY, REENTRY_IN_PROGRESS, REENTRY_COMPLETE
    created_at: str
