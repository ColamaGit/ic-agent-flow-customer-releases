"""
Signoff Governance Engine (v0.1)
================================
Core engine for managing the Phase 6 Signoff family objects and logic.
Handles Waiver lifecycles, Risk aggregation, and Audit bundle sealing.
"""
from __future__ import annotations

import hashlib
from typing import List, Optional, Tuple, Set
from uuid import UUID

from ic_agent_flow.domain.objects.production_bridge_objects import (
    SignoffRiskPackage,
    SignoffWaiverRequest,
    SignoffWaiverRecord,
    SignoffAuditBundle,
    ReleaseGateVerdict
)
from ic_agent_flow.domain.governance.checkpoint import DecisionEnum
from ic_agent_flow.domain.utils.time import get_tw_now


class SignoffGovernanceEngine:
    """ 
    Handles the logical transitions and bindings for Signoff objects.
    Enforces the separation of Technical Truth (Risk) and Governance Disposition (Verdict).
    """

    @staticmethod
    def process_waiver_decision(
        request: SignoffWaiverRequest,
        approver_id: str,
        decision: DecisionEnum,
        conditions: List[str] = []
    ) -> SignoffWaiverRecord:
        """
        Transforms a Waiver Request into a formal Authority-bearing Record.
        """
        record = SignoffWaiverRecord(
            request_id=request.id,
            risk_id=request.risk_id, # Inherit risk_id for precise matching
            decision=decision.value,
            approver_id=approver_id,
            conditions=conditions,
            timestamp=get_tw_now()
        )
        return record

    @staticmethod
    def apply_governance_context(
        package: SignoffRiskPackage,
        waivers: List[SignoffWaiverRecord]
    ) -> SignoffRiskPackage:
        """
        Appends governance context to the risk package without altering the technical risk_level.
        """
        approved_waivers = [w for w in waivers if w.decision in [DecisionEnum.APPROVE.value, DecisionEnum.APPROVE_WITH_CONDITIONS.value]]
        
        if approved_waivers:
            package.governance_risk_summary += f"\n[Governance Context] {len(approved_waivers)} valid waivers linked."
            # NOTE: Technical risk_level remains untouched to preserve truth.
        
        return package

    @staticmethod
    def calculate_residual_risk(
        chip_id: str,
        technical_violations: List[str], # These should ideally be IDs
        missing_evidence: List[str],     # These should ideally be IDs
        active_waivers: List[SignoffWaiverRecord]
    ) -> SignoffRiskPackage:
        """
        Calculates the quantified residual risk for a signoff event (Technical Truth).
        Now populates structured IDs for automated coverage checks.
        """
        risk_level = 1
        tech_summary = "Technical Baseline: " + ("; ".join(technical_violations) if technical_violations else "Clean")
        gov_summary = "Governance Baseline: "
        
        # 1. Evaluate Technical Debt
        risk_level += len(technical_violations)
        
        # 2. Evaluate Evidence Debt
        risk_level += len(missing_evidence)
        gov_summary += f"{len(missing_evidence)} missing evidence artifacts detected."
        
        # 3. Final Level Capping
        risk_level = min(5, risk_level)
        
        package = SignoffRiskPackage(
            chip_id=chip_id,
            technical_risk_summary=tech_summary,
            governance_risk_summary=gov_summary,
            technical_violation_ids=technical_violations, # Mapping strings to IDs for now
            missing_evidence_ids=missing_evidence,
            risk_level=risk_level,
            readiness_ladder=6
        )
        
        # 4. Attach Context
        package = SignoffGovernanceEngine.apply_governance_context(package, active_waivers)
        
        return package

    @staticmethod
    def determine_gate_verdict(
        package: SignoffRiskPackage,
        waivers: List[SignoffWaiverRecord],
        gate_type: str,
        adjudicator_role: str
    ) -> ReleaseGateVerdict:
        """
        Determines the gate disposition based on set-theory coverage matching.
        """
        # 1. Define the Problem Set (All items that require a waiver)
        required_waiver_set: Set[str] = set(package.technical_violation_ids) | set(package.missing_evidence_ids)
        
        # 2. Define the Solution Set (All valid waiver coverage)
        # Only APPROVE and APPROVE_WITH_CONDITIONS count.
        valid_waivers = [
            w for w in waivers 
            if w.decision in [DecisionEnum.APPROVE.value, DecisionEnum.APPROVE_WITH_CONDITIONS.value]
        ]
        covered_risk_ids: Set[str] = {w.risk_id for w in valid_waivers}
        
        # 3. Adjudication Logic
        verdict_val = DecisionEnum.REJECT.value
        
        if not required_waiver_set:
            # Clean case
            verdict_val = DecisionEnum.APPROVE.value
        elif required_waiver_set.issubset(covered_risk_ids):
            # All risks covered by valid waivers
            verdict_val = DecisionEnum.APPROVE_WITH_CONDITIONS.value
        else:
            # Missing coverage for at least one risk
            verdict_val = DecisionEnum.REJECT.value

        verdict = ReleaseGateVerdict(
            chip_id=package.chip_id,
            gate_type=gate_type,
            verdict=verdict_val,
            is_fail_closed=True,
            adjudicator_role=adjudicator_role,
            associated_waiver_ids=[w.id for w in valid_waivers]
        )
        return verdict

    @staticmethod
    def seal_signoff_audit_bundle(
        chip_id: str,
        manifest_id: UUID,
        verdict_id: UUID,
        decision_chain_refs: List[str]
    ) -> SignoffAuditBundle:
        """
        Finalizes the production signoff by sealing the evidence and decision chains.
        """
        raw_seal_data = f"{chip_id}|{manifest_id}|{verdict_id}|{','.join(decision_chain_refs)}"
        audit_digest = hashlib.sha256(raw_seal_data.encode()).hexdigest()
        
        bundle = SignoffAuditBundle(
            chip_id=chip_id,
            manifest_id=manifest_id,
            verdict_id=verdict_id,
            decision_chain=decision_chain_refs,
            audit_digest=audit_digest,
            closed_at=get_tw_now()
        )
        return bundle
