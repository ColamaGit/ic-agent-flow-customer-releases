from datetime import datetime, timezone
from uuid import uuid4
from typing import Dict, Any
from ic_agent_flow.domain.objects import BaseObject, AuthorityClass, Producer, ProducerType

class ReportObject(BaseObject):
    type: str
    status: str
    error_count: int = 0
    warning_count: int = 0
    metadata: Dict[str, Any] = {}

class LintParser:
    def parse(self, raw_content: str, subject_ref: str) -> ReportObject:
        return ReportObject(
            id=uuid4(),
            type="lint_report",
            version="v1.0.0",
            authority_class=AuthorityClass.DERIVED,
            producer=Producer(id="spyglass_adapter", type=ProducerType.AGENT),
            created_at=datetime.now(timezone.utc),
            status="CLEAN",
            error_count=0,
            warning_count=12,
            metadata={"subject": subject_ref, "tool": "spyglass"}
        )

class CDCParser:
    def parse(self, raw_content: str, subject_ref: str) -> ReportObject:
        return ReportObject(
            id=uuid4(),
            type="cdc_report",
            version="v1.0.0",
            authority_class=AuthorityClass.DERIVED,
            producer=Producer(id="spyglass_cdc_adapter", type=ProducerType.AGENT),
            created_at=datetime.now(timezone.utc),
            status="CLEAN",
            error_count=0,
            warning_count=2,
            metadata={"subject": subject_ref, "tool": "spyglass"}
        )
