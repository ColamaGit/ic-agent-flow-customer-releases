from enum import Enum
from typing import List, Any
from ic_agent_flow.domain.objects import BaseObject, DataClassification, ProducerType, Producer
from ic_agent_flow.domain.contracts import Contract
from ic_agent_flow.domain.security.tiering import IPTierPolicy

class SecurityViolation(Exception):
    """Raised when an IP or security policy is violated."""
    pass

class SecurityGuard:
    """Enforces zero-trust IP boundaries based on Sensitivity Tiers."""
    
    @staticmethod
    def check_access(subjects: List[BaseObject], contract: Contract) -> None:
        """
        Evaluates whether the given objects are legally allowed to be processed
        by a contract with a specific execution scope.
        """
        for subject in subjects:
            classification = getattr(subject, "classification", DataClassification.HIGHLY_SENSITIVE_DESIGN)
            constraints = IPTierPolicy.get_constraints(classification)
            
            scope = getattr(contract, "execution_scope", None)
            if not scope:
                raise SecurityViolation(f"Contract {contract.id} is missing an explicit execution_scope.")

            # Constraint 1: Network Egress
            if scope.network_egress and not constraints.allow_network_egress:
                raise SecurityViolation(
                    f"IP Boundary Violation: Contract {contract.id} ({contract.name}) requests network_egress, "
                    f"but subject {subject.id} has classification {classification} which forbids it."
                )
                
            # Constraint 2: Artifact Visibility
            if scope.artifact_visibility == "global" and classification != DataClassification.PUBLIC:
                 raise SecurityViolation(
                     f"IP Boundary Violation: Contract {contract.id} requests global visibility, "
                     f"but subject {subject.id} is NOT public."
                 )
        
    @staticmethod
    def check_producer(subjects: List[BaseObject], producer: Producer) -> None:
        """
        Enforce restrictions on WHO (or WHAT) can process specific data tiers.
        e.g., Tier 3 (High-Value) cannot be processed by externalized agents.
        """
        is_high_value = any(
            getattr(s, "classification", DataClassification.HIGHLY_SENSITIVE_DESIGN) == DataClassification.HIGHLY_SENSITIVE_DESIGN
            for s in subjects
        )
        
        if is_high_value:
            # High-Value IP requires local-first or human authority.
            # Minimal implementation: mark specific producers as 'external' if needed.
            # For now, block 'agent' from being the sole producer of High-Value IP promotion artifacts
            # unless a human checkpoint follows.
            
            if producer.type == ProducerType.AGENT and producer.id.startswith("external_"):
                raise SecurityViolation(
                    "IP Boundary Violation: Tier 3 (High-Value) objects cannot be processed by EXTERNAL agents."
                )
