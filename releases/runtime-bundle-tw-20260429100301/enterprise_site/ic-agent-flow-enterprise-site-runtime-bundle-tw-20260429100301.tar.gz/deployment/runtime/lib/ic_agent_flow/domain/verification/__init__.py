from datetime import datetime
from enum import Enum
from typing import List, Optional
from pydantic import BaseModel, UUID4

class Verdict(str, Enum):
    PASS = "PASS"
    PASS_WITH_WARNING = "PASS_WITH_WARNING"
    BLOCKED = "BLOCKED"
    FAILED = "FAILED"
    NOT_READY = "NOT_READY"

class Decision(str, Enum):
    PROCEED = "PROCEED"
    HOLD = "HOLD"
    ROLLBACK = "ROLLBACK"
    REJECT = "REJECT"
    ESCALATE = "ESCALATE"

class GateVerdict(BaseModel):
    id: UUID4
    subject_ref: str
    verdict: Verdict
    gate_type: str
    evidence_refs: List[str]
    created_at: datetime
    rationale: Optional[str] = None

class AdjudicationAuthority(BaseModel):
    human_id: str
    role: str

class AdjudicationRecord(BaseModel):
    adjudication_id: UUID4
    subject_refs: List[str]
    gate_verdict_refs: List[str] = []
    decision: Decision
    decision_rationale: Optional[str] = None
    authority: AdjudicationAuthority
    approved_at: datetime
    exception_refs: List[str] = []
