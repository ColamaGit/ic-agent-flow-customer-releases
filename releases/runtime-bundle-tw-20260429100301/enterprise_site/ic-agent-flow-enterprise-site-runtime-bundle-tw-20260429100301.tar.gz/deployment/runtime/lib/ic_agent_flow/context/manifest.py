from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, UUID4

class ContextManifest(BaseModel):
    task_type: str
    subject_refs: List[str]
    included_refs: List[str] = []
    authority_order: List[str] = ["Canonical", "Derived", "Ephemeral"]
    assembly_time: datetime
    assembler: str
    open_ambiguities: List[str] = []
    applied_governance_versions: dict = {}
