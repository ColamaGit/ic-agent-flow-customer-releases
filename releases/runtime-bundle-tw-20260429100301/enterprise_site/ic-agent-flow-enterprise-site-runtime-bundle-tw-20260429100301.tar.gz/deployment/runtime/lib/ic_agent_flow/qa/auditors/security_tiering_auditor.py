import json
from pathlib import Path
from typing import Dict, List

class SecurityTieringAuditor:
    """Suite 5: Security & Tiering QA Auditor.
    Audits DataClassification, Tier 1/2/3 boundaries, and IP protection logic.
    """
    
    def __init__(self, workspace_root: str):
        self.root = Path(workspace_root)
        self.closeouts_path = self.root / "artifacts" / "closeouts"
        
    def audit_tier_boundary(self, bundle_id: str) -> Dict:
        """Verifies if a Tier 3 Run complies with Egress and Producer restrictions."""
        results = {
            "auditor": "SecurityTieringAuditor",
            "check": f"tier_boundary_{bundle_id}",
            "verdict": "ACCEPTABLE",
            "findings": []
        }
        
        # Try to find file
        bundle_file = self.closeouts_path / f"bundle_{bundle_id}.json"
        if not bundle_file.exists():
            matching = list(self.closeouts_path.glob(f"*{bundle_id}*"))
            if matching:
                bundle_file = matching[0]
            else:
                results["verdict"] = "INSUFFICIENT_EVIDENCE"
                results["findings"].append(f"Bundle {bundle_id} not found in {self.closeouts_path}.")
                return results
            
        try:
            with open(bundle_file, 'r') as f:
                bundle = json.load(f)
            
            # Check for Tier based on task type or metadata
            task_type = bundle.get("task_type", "unknown")
            results["findings"].append(f"Auditing task type: {task_type}")
            
            # Check producers
            exec_rec = bundle.get("execution_run_record", {})
            producer = exec_rec.get("producer", {}).get("id", "unknown")
            
            if "external" in producer.lower():
                results["verdict"] = "CLAIM_SCOPE_TOO_BROAD"
                results["findings"].append(f"External producer {producer} handled bundle data.")
            else:
                results["findings"].append(f"Producer {producer} is within authorized boundaries.")
                    
        except Exception as e:
            results["verdict"] = "LINEAGE_INCOMPLETE"
            results["findings"].append(f"Parse error: {str(e)}")
            
        return results

if __name__ == "__main__":
    auditor = SecurityTieringAuditor(".")
    print(json.dumps(auditor.audit_tier_boundary("family-1-formal"), indent=2))
