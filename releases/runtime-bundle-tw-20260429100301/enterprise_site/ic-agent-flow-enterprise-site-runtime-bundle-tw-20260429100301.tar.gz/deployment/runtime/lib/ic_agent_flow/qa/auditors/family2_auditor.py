import json
import os
from typing import Dict, Any
from ic_agent_flow.qa.evidence_assessor import EvidenceAssessor

class Family2Auditor(EvidenceAssessor):
    """ Specialized Auditor for Tier 2 Timing Gate (Family 2). """

    def audit_timing_bundle(self, bundle_path: str) -> Dict[str, Any]:
        """ Specific audits for Timing Signoff artifacts. """
        report = self.assess_bundle(bundle_path)
        
        # Additional Family 2 Rules
        if report["qa_verdict"]["verdict"] == "ACCEPTABLE":
            try:
                with open(bundle_path, 'r') as f:
                    data = json.load(f)
                
                # Check WNS
                wns = data.get("timing_results", {}).get("wns", -1.0)
                if wns < 0:
                    report["qa_verdict"]["verdict"] = "REJECTION_WARNING"
                    report["qa_verdict"]["summary"] = f"Negative slack ({wns}ps) detected. Automated SIGN-OFF gate must fail."
                    report["qa_verdict"]["severity"] = "CRITICAL"
                
                # Check SDC
                if not data.get("sdc_verified"):
                    report["qa_verdict"]["verdict"] = "INSUFFICIENT_EVIDENCE"
                    report["qa_verdict"]["summary"] = "Missing SDC mapping verification. Timing evidence rejected."
                    report["qa_verdict"]["severity"] = "CRITICAL"

            except:
                pass
                
        return report
