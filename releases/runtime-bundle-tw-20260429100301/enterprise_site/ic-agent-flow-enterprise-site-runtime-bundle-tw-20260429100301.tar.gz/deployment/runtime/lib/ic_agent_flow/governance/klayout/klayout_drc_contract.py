
from pydantic import BaseModel, Field
from typing import List, Optional

class KLayoutDRCContract(BaseModel):
    contract_name: str = "klayout_drc_contract"
    contract_version: str = "v0.1"
    input_gds: str
    drc_rules: str
    report_xml: str

class NormalizedKLayoutDRCMeta(BaseModel):
    tool: str = "klayout"
    tool_version: str
    contract_name: str = "klayout_drc_contract"
    contract_version: str = "v0.1"
    status: str
    violations_total: int
    generated_at: str
