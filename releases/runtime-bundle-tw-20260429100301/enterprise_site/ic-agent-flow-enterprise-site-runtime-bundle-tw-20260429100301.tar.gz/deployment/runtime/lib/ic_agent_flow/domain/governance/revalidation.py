import os
from typing import List, Dict, Set
from enum import Enum
from pathlib import Path
from ic_agent_flow.domain.governance.registry import ReadinessRegistry
from ic_agent_flow.domain.governance.readiness import ClaimStatus, SubjectType
from ic_agent_flow.domain.governance.events import emit_governance_event, RevalidationTrigger

class TriggerType(str, Enum):
    SCENARIO_CHANGE = "scenario_change"
    POLICY_CHANGE = "policy_policy_change"
    SECURITY_CHANGE = "security_scope_change"
    INFRA_CHANGE = "artifact_retention_change"
    CONSOLE_CHANGE = "operator_console_change"

# Maps directory/file patterns to the subjects they affect
DRIFT_MAP: Dict[str, List[str]] = {
    "src/ic_agent_flow/scenarios/read_only_verification_digest.py": ["read-only-verification"],
    "src/ic_agent_flow/scenarios/bounded_compile_elab.py": ["bounded-compile-elab"],
    "src/ic_agent_flow/scenarios/restricted_eco_prep.py": ["eco-legality-analysis"],
    "src/ic_agent_flow/domain/governance/checkpoint.py": ["human-judgment", "eco-legality-analysis"],
    "src/ic_agent_flow/domain/security/guard.py": ["security-guard", "eco-legality-analysis"],
    "src/ic_agent_flow/infrastructure/storage/engine.py": ["security-guard", "read-only-verification"],
    "console/src/pages/": ["human-judgment", "eco-legality-analysis"],
}

class DriftDetector:
    """Detects modifications in critical paths and identifies revalidation needs."""
    
    def __init__(self, repo_root: str):
        self.repo_root = Path(repo_root)

    def identify_impacted_subjects(self, modified_files: List[str]) -> Dict[str, Set[str]]:
        """
        Returns a mapping of subject_id -> set of triggers that hit it.
        """
        impacts: Dict[str, Set[str]] = {}
        
        for file_path in modified_files:
            for pattern, subjects in DRIFT_MAP.items():
                if file_path.startswith(pattern):
                    for sub in subjects:
                        if sub not in impacts:
                            impacts[sub] = set()
                        
                        # Determine trigger type based on pattern
                        trigger = self._get_trigger_type(pattern)
                        impacts[sub].add(trigger)
        
        return impacts

    def revoke_impacted_claims(self, impacts: Dict[str, Set[str]], registry: ReadinessRegistry):
        """
        Transitions impacted subjects to PENDING_REVALIDATION and emits a trigger event.
        """
        if not impacts:
            return

        impacted_subject_ids = list(impacts.keys())
        
        # Update Registry
        for sub_id in impacted_subject_ids:
            # We check both SCENARIO and CAPABILITY types as a baseline
            for sub_type in [SubjectType.SCENARIO, SubjectType.CAPABILITY]:
                entry = registry.query_active(sub_type, sub_id)
                if entry:
                    entry.status = ClaimStatus.PENDING_REVALIDATION
                    print(f"GOVERNANCE_REVOKE: Subject '{sub_id}' moved to PENDING_REVALIDATION")
        
        registry._save()

        # Emit Event
        trigger = RevalidationTrigger(
            trigger_type="drift_detected",
            impacted_subjects=impacted_subject_ids,
            original_drift_files=[], # In a real implementation, we'd pass these through
            status="PENDING"
        )
        emit_governance_event(trigger)

    def _get_trigger_type(self, pattern: str) -> str:
        if "scenarios" in pattern: return TriggerType.SCENARIO_CHANGE
        if "checkpoint" in pattern: return TriggerType.POLICY_CHANGE
        if "security" in pattern: return TriggerType.SECURITY_CHANGE
        if "storage" in pattern: return TriggerType.INFRA_CHANGE
        if "console" in pattern: return TriggerType.CONSOLE_CHANGE
        return "generic_drift"
