"""
Cognitive Backend Adapter — Main Entry Point
=============================================
Orchestrates routing → backend invocation → audit record generation.

Usage:
    adapter = CognitiveAdapter()
    response = adapter.invoke(CognitiveRequest(...))
    audit = adapter.last_audit  # always available after invoke()
"""
from __future__ import annotations

import time
from typing import Optional

from ic_agent_flow.cognitive.routing import CognitiveRouter, RoutingError
from ic_agent_flow.cognitive.schemas import (
    BackendProvider,
    BackendSelection,
    CognitiveAuditRecord,
    CognitiveRequest,
    CognitiveResponse,
    ResponseType,
)


class CognitiveAdapter:
    """
    Single entry point for all agent cognitive invocations.

    Responsibilities:
    1. Route request to correct backend via CognitiveRouter (policy-driven)
    2. Invoke the selected backend driver
    3. Normalize the response into CognitiveResponse
    4. Generate CognitiveAuditRecord — always, even on failure
    5. Return normalized response to the agent
    """

    def __init__(self):
        self._router = CognitiveRouter()
        self._last_audit: Optional[CognitiveAuditRecord] = None
        self._last_selection: Optional[BackendSelection] = None

    @property
    def last_audit(self) -> Optional[CognitiveAuditRecord]:
        return self._last_audit

    @property
    def last_selection(self) -> Optional[BackendSelection]:
        return self._last_selection

    def invoke(self, request: CognitiveRequest) -> CognitiveResponse:
        """
        Full invocation pipeline:
        request → route → backend → normalize → audit → return
        """
        start = time.monotonic()
        selection: Optional[BackendSelection] = None
        response: Optional[CognitiveResponse] = None
        error_msg: Optional[str] = None

        try:
            # Step 1: Route
            selection = self._router.select(request)
            self._last_selection = selection

            # Step 2: Invoke the selected backend
            response = self._invoke_backend(request, selection)

        except RoutingError as e:
            error_msg = f"RoutingError: {e}"
            response = self._error_response(request, str(e))

        except Exception as e:
            error_msg = f"{type(e).__name__}: {e}"
            response = self._error_response(request, error_msg)

        finally:
            latency_ms = (time.monotonic() - start) * 1000
            self._last_audit = self._build_audit(
                request=request,
                selection=selection,
                response=response,
                latency_ms=latency_ms,
                error_message=error_msg,
            )

        return response

    def _invoke_backend(
        self,
        request: CognitiveRequest,
        selection: BackendSelection,
    ) -> CognitiveResponse:
        """Dispatch to the correct backend driver."""
        provider = selection.selected_provider

        if provider == BackendProvider.LOCAL_MOCK:
            from ic_agent_flow.cognitive.backends.local import LocalMockBackend
            return LocalMockBackend().invoke(request)

        elif provider == BackendProvider.GEMINI:
            from ic_agent_flow.cognitive.backends.gemini import GeminiBackend
            return GeminiBackend().invoke(request)

        else:
            raise RoutingError(
                f"No driver registered for provider={provider.value}. "
                "This is a fail-closed condition."
            )

    def _error_response(self, request: CognitiveRequest, error_msg: str) -> CognitiveResponse:
        """Construct a structured error envelope. Never raises — always returns."""
        return CognitiveResponse(
            request_id=request.request_id,
            response_type=ResponseType.ERROR,
            content="",
            provider=BackendProvider.LOCAL_MOCK,
            model_id="error",
            error_message=error_msg,
        )

    def _build_audit(
        self,
        request: CognitiveRequest,
        selection: Optional[BackendSelection],
        response: Optional[CognitiveResponse],
        latency_ms: float,
        error_message: Optional[str],
    ) -> CognitiveAuditRecord:
        """Build provider-agnostic audit record (Law 4). Always called, even on failure."""
        provider = selection.selected_provider if selection else BackendProvider.LOCAL_MOCK
        from ic_agent_flow.cognitive.schemas import BackendCategory
        category = selection.selected_category if selection else BackendCategory.MODEL_STYLE
        policy = selection.policy_rule_applied if selection else request.policy
        routing_reason = selection.selection_reason if selection else "routing_failed"
        redaction = selection.redaction_applied if selection else False

        resp_type = response.response_type if response else ResponseType.ERROR
        success = response.is_success if response else False

        return CognitiveAuditRecord(
            request_id=request.request_id,
            agent_id=request.agent_id,
            chip_scope=request.chip_scope,
            task_type=request.task_type,
            provider=provider,
            category=category,
            policy_applied=policy,
            routing_reason=routing_reason,
            redaction_applied=redaction,
            response_type=resp_type,
            success=success,
            latency_ms=round(latency_ms, 2),
            input_tokens=response.usage_input_tokens if response else None,
            output_tokens=response.usage_output_tokens if response else None,
            error_message=error_message,
        )
