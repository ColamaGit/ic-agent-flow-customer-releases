import json
import os
from datetime import datetime
from enum import Enum
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field, UUID4
from uuid import uuid4
from ic_agent_flow.domain.utils.time import get_tw_now
from ic_agent_flow.domain.governance.checkpoint import StageGateType, DecisionEnum

# Simulated event bus file
EVENT_STORE_PATH = "artifacts/events/run_events.jsonl"

class Priority(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    NORMAL = "normal"
    LOW = "low"

class LaunchGateRequest(BaseModel):
    id: UUID4 = Field(default_factory=uuid4)
    run_id: UUID4
    subject_ref: str
    intent_summary: str
    security_tier: str = "Tier 2"
    timestamp: datetime = Field(default_factory=get_tw_now)
    requested_by: str = "Assistant"

class StallEvent(BaseModel):
    id: UUID4 = Field(default_factory=uuid4)
    package_id: UUID4
    reason: str
    timeout_at: Optional[datetime] = None
    severity: str = "INFO"
    timestamp: datetime = Field(default_factory=get_tw_now)

class RevalidationTrigger(BaseModel):
    id: UUID4 = Field(default_factory=uuid4)
    trigger_type: str
    impacted_subjects: List[str]
    original_drift_files: List[str]
    status: str = "PENDING"
    timestamp: datetime = Field(default_factory=get_tw_now)

def emit_governance_event(event: BaseModel):
    """
    Appends a governance event to the persistent event store.
    """
    os.makedirs(os.path.dirname(EVENT_STORE_PATH), exist_ok=True)
    
    event_data = {
        "event_type": event.__class__.__name__,
        "payload": event.model_dump(mode="json"),
        "timestamp": get_tw_now().isoformat()
    }
    
    with open(EVENT_STORE_PATH, "a") as f:
        f.write(json.dumps(event_data) + "\n")
    
    print(f"EVENT_EMITTED: {event.__class__.__name__} for {getattr(event, 'subject_id', getattr(event, 'run_id', 'unknown'))}")
