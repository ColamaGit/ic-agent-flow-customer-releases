from datetime import datetime
from enum import Enum
from typing import List, Optional
from pydantic import BaseModel, UUID4

class AuthorityClass(str, Enum):
    CANONICAL = "Canonical"
    DERIVED = "Derived"
    EPHEMERAL = "Ephemeral"
    REVIEW_ONLY = "Review-Only"
    ADVISORY = "Advisory"
    OPERATIONAL_SUPPORT = "Operational-Support"
    AUTHORITY_BEARING = "Authority-Bearing"
    VERIFICATION_FINAL = "Verification-Final"

class DataClassification(str, Enum):
    PUBLIC = "public_or_sample"
    INTERNAL_RESTRICTED = "internal_restricted"
    HIGHLY_SENSITIVE_DESIGN = "highly_sensitive_design"

class ProducerType(str, Enum):
    HUMAN = "human"
    AGENT = "agent"
    TOOL = "tool"

class Producer(BaseModel):
    id: str
    type: ProducerType

class BaseObject(BaseModel):
    id: UUID4
    type: str
    schema_version: str = "v0.1.0"
    version: str
    authority_class: AuthorityClass
    classification: DataClassification = DataClassification.INTERNAL_RESTRICTED
    producer: Producer
    created_at: datetime
    input_refs: List[str] = []
    lineage_refs: List[str] = []
    evidence_refs: List[str] = []

class RTLSnapshot(BaseObject):
    type: str = "rtl_snapshot"
    status: str
    files: List[dict]

class DesignSpec(BaseObject):
    type: str = "design_spec"
    content: dict

class TimingReport(BaseObject):
    type: str = "timing_report"
    summary: dict
    paths: List[dict]

from .eco import EcoRequest, RtlDiff, SpareCellInventory, ImpactScope

__all__ = [
    "AuthorityClass",
    "DataClassification",
    "ProducerType",
    "Producer",
    "BaseObject",
    "RTLSnapshot",
    "DesignSpec",
    "TimingReport",
    "EcoRequest",
    "RtlDiff",
    "SpareCellInventory",
    "ImpactScope"
]
