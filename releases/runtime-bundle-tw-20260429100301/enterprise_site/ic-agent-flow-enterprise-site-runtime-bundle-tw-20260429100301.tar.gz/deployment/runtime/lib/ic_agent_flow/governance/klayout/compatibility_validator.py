
from pydantic import BaseModel
from typing import List, Dict, Optional
import json
from ic_agent_flow.domain.objects.qualification.deployment_qualification import EnvironmentFingerprint

class ToolchainCompatibilityRecord(BaseModel):
    verdict: str # SUPPORTED, RESTRICTED, UNSUPPORTED
    restrictions: List[str]
    qualified_at: str

class CompatibilityValidator:
    def __init__(self, matrix_path: str):
        with open(matrix_path, 'r') as f:
            self.matrix = json.load(f)

    def validate(self, fingerprint: EnvironmentFingerprint) -> ToolchainCompatibilityRecord:
        # 簡易判定邏輯：對照矩陣
        # 實際實作中應整合更多複雜規則與 tolerance 檢查
        tool_versions = fingerprint.tool_versions
        
        # 模擬比對邏輯
        if "NOT_FOUND" in tool_versions.values():
            return ToolchainCompatibilityRecord(
                verdict="UNSUPPORTED",
                restrictions=["Missing required EDA tools"],
                qualified_at=fingerprint.collected_at.isoformat()
            )
            
        return ToolchainCompatibilityRecord(
            verdict="SUPPORTED",
            restrictions=[],
            qualified_at=fingerprint.collected_at.isoformat()
        )
