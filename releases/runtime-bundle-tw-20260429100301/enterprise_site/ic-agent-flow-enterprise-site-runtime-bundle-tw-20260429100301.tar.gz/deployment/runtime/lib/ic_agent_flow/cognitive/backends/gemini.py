"""
Google Gemini API Backend Driver (Step 5 — Land one remote model_style backend)
=================================================================================
Connects to Google Gemini API as the first remote model_style backend.

Reads from environment:
  GEMINI_API_KEY  — required for remote invocation
  GEMINI_MODEL    — model name (default: gemini-2.0-flash)

If GEMINI_API_KEY is missing or invalid, raises CognitiveBackendError.
Never falls back silently — caller must handle failure explicitly (Law 5).
"""
from __future__ import annotations

import os
import time
from typing import Optional

from ic_agent_flow.cognitive.schemas import (
    BackendProvider,
    CognitiveRequest,
    CognitiveResponse,
    ResponseType,
)


class CognitiveBackendError(Exception):
    """Raised when a backend invocation fails. Caller must handle — no silent fallback."""
    pass


class GeminiBackend:
    """
    Google Gemini API driver (model_style backend).
    Wraps the google-genai SDK and normalizes responses into CognitiveResponse.
    """

    PROVIDER = BackendProvider.GEMINI

    def __init__(self):
        self._api_key: Optional[str] = None
        self._model_id: Optional[str] = None
        self._client = None

    def _ensure_initialized(self):
        """Lazy initialization — only connect when first invoked."""
        if self._client is not None:
            return

        api_key = os.getenv("GEMINI_API_KEY", "")
        if not api_key or api_key == "your_gemini_api_key_here":
            raise CognitiveBackendError(
                "GEMINI_API_KEY is not configured. "
                "Set it in .env to enable remote Gemini backend."
            )

        self._api_key = api_key
        self._model_id = os.getenv("GEMINI_MODEL", "gemini-2.0-flash")

        try:
            from google import genai
            self._client = genai.Client(api_key=self._api_key)
        except ImportError:
            raise CognitiveBackendError(
                "google-genai package not installed. "
                "Run: pip install google-genai"
            )

    def invoke(self, request: CognitiveRequest) -> CognitiveResponse:
        """
        Invoke Google Gemini API with the given CognitiveRequest.
        Returns a normalized CognitiveResponse.
        Raises CognitiveBackendError on failure — never returns silently degraded output.
        """
        self._ensure_initialized()

        # Build prompt with system context if provided
        full_prompt = request.prompt
        if request.system_context:
            full_prompt = f"{request.system_context}\n\n{request.prompt}"

        start = time.monotonic()

        try:
            response = self._client.models.generate_content(
                model=self._model_id,
                contents=full_prompt,
            )
            latency_ms = (time.monotonic() - start) * 1000

            # Normalize response
            content = response.text or ""
            if not content:
                return CognitiveResponse(
                    request_id=request.request_id,
                    response_type=ResponseType.REFUSAL,
                    content="",
                    provider=self.PROVIDER,
                    model_id=self._model_id,
                    refusal_reason="Empty response from Gemini API",
                    raw_metadata={"latency_ms": round(latency_ms, 2)},
                )

            # Extract token usage if available
            input_tokens = None
            output_tokens = None
            try:
                usage = response.usage_metadata
                input_tokens = getattr(usage, "prompt_token_count", None)
                output_tokens = getattr(usage, "candidates_token_count", None)
            except Exception:
                pass

            return CognitiveResponse(
                request_id=request.request_id,
                response_type=ResponseType.TEXT,
                content=content,
                provider=self.PROVIDER,
                model_id=self._model_id,
                usage_input_tokens=input_tokens,
                usage_output_tokens=output_tokens,
                raw_metadata={"latency_ms": round(latency_ms, 2)},
            )

        except CognitiveBackendError:
            raise
        except Exception as e:
            latency_ms = (time.monotonic() - start) * 1000
            raise CognitiveBackendError(
                f"Gemini API invocation failed: {type(e).__name__}: {e}"
            ) from e
