from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime

class EnvironmentFingerprint(BaseModel):
    site_id: str
    deployment_profile: str
    host_os: str
    kernel_version: str
    cpu_arch: str
    container_image_digest: Optional[str]
    host_fingerprint: Optional[str]
    tool_versions: dict  # yosys, openroad, etc.
    pdk_digest_set: dict
    policy_fingerprint: str
    collected_at: datetime

class ToolchainCompatibilityRecord(BaseModel):
    record_id: str
    compatibility_verdict: str  # SUPPORTED, RESTRICTED, UNSUPPORTED
    restrictions: List[str]
    evidence_refs: List[str]
    qualified_at: datetime

class SiteQualificationRecord(BaseModel):
    qualification_id: str
    site_id: str
    environment_fingerprint_ref: str
    compatibility_record_ref: str
    bundle_ref: str
    profile_ref: str
    qualification_verdict: str
    valid_until: datetime
    signed_by: str  # human authority
