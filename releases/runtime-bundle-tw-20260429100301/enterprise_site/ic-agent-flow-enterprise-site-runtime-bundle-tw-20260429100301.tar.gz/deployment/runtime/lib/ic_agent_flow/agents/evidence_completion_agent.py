"""
v0.6 Second Specialized Agent — Evidence Completion Agent
==========================================================
Agent Identity Definition (PRD v0.6, Commander R6)

This agent is specialized in reacting to "Request More Evidence" decisions.
Its mission is strictly operational: to close evidence gaps and collect missing artifacts.
It operates under a governed handoff from the Verification Triage Agent or the System.
"""
from __future__ import annotations

from enum import Enum
from typing import List

from pydantic import BaseModel


# ── Agent Identity Constants ───────────────────────────────────────────────────

AGENT_ID = "evidence_completion_agent_v0.6"
AGENT_NAME = "Evidence Completion Agent"
AGENT_ROLE = "evidence_completer"
AGENT_VERSION = "v0.6.0"

AGENT_MISSION = (
    "Close evidence gaps, collect missing artifacts, and re-submit to decision loop. "
    "This agent is strictly operational and does not have the authority to adjudicate "
    "design quality, approve releases, or waive risks."
)


# ── Capability Taxonomy (Commander R6 - may) ───────────────────────────────────

class CompletionAgentCapability(str, Enum):
    """Explicitly approved capabilities for the completion agent."""
    COLLECT_MISSING_EVIDENCE = "collect_missing_evidence"
    GENERATE_REQUESTED_ARTIFACTS = "generate_requested_artifacts"
    ATTACH_COMPLETION_PAYLOAD = "attach_completion_payload"
    ACCEPT_REJECT_RETURN_HANDOFF = "accept_reject_return_handoff"
    
    # Inherited foundational capabilities
    RECEIVE_CHIP_SCOPED_TASK = "receive_chip_scoped_task"
    RESOLVE_CONTEXT_MANIFEST = "resolve_context_manifest"
    INVOKE_READ_ONLY_CONTRACTS = "invoke_read_only_contracts"
    INVOKE_COGNITIVE_BACKEND = "invoke_cognitive_backend"


# ── Prohibited Actions (Commander R6 - may_not) ────────────────────────────────

class CompletionProhibitedAction(str, Enum):
    """Explicitly forbidden actions for the completion agent."""
    APPROVE = "approve"
    WAIVE = "waive"
    FINALIZE_DISPOSITION = "finalize_disposition"
    OVERWRITE_CANONICAL_TRUTH = "overwrite_canonical_truth"
    BYPASS_HUMAN_CHECKPOINT = "bypass_human_checkpoint"
    
    # Generic baseline prohibitions
    EXECUTE_WITHOUT_CHIP_SCOPE = "execute_without_resolved_chip_scope"
    MODIFY_DESIGN_ARTIFACTS = "modify_design_artifacts"
    ESCALATE_OWN_AUTHORITY = "escalate_own_authority_class"


class CompletionEscalationCondition(str, Enum):
    """Conditions under which this agent must stop and return/escalate."""
    CHIP_SCOPE_UNRESOLVED = "chip_scope_unresolved"
    EVIDENCE_RECOVERY_IMPOSSIBLE = "evidence_recovery_impossible"
    ACCESS_DENIED = "access_denied"
    HANDOFF_PAYLOAD_MALFORMED = "handoff_payload_malformed"
    AUTHORITY_MISMATCH = "authority_mismatch"
    COGNITIVE_BACKEND_FAILED = "cognitive_backend_failed"


# ── Agent Identity Contract ────────────────────────────────────────────────────

class EvidenceCompletionAgentIdentity(BaseModel):
    """
    Formal Agent Identity record for the Completion Agent.
    Strictly follows the Commander's R6 explicit matrix.
    """
    agent_id: str = AGENT_ID
    agent_name: str = AGENT_NAME
    role: str = AGENT_ROLE
    version: str = AGENT_VERSION
    mission: str = AGENT_MISSION

    # R6 Matrix
    may: List[CompletionAgentCapability] = list(CompletionAgentCapability)
    may_not: List[CompletionProhibitedAction] = list(CompletionProhibitedAction)
    escalation_conditions: List[CompletionEscalationCondition] = list(CompletionEscalationCondition)

    # Authority Class (Mandated in Implementation Plan v2.0)
    authority_class: str = "operational"

    output_contracts: List[str] = [
        "execution_run",
        "artifact_ref_set",
        "evidence_bundle_ref",  # Will produce a NEW bundle with lineage
        "handoff_acceptance_record",
        "handoff_return_record",
        "handoff_rejection_record",
        "cognitive_invocation_audit_record",
    ]

    def can_do(self, capability: CompletionAgentCapability) -> bool:
        return capability in self.may

    def is_prohibited(self, action: CompletionProhibitedAction) -> bool:
        return action in self.may_not

    def should_escalate(self, condition: CompletionEscalationCondition) -> bool:
        return condition in self.escalation_conditions


# Singleton — load once, use everywhere
EVIDENCE_COMPLETION_AGENT_IDENTITY = EvidenceCompletionAgentIdentity()
