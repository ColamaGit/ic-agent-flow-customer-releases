from typing import List, Optional, Dict, Any
from datetime import datetime
from uuid import uuid4
from pydantic import BaseModel, Field, UUID4

from ic_agent_flow.domain.utils.time import get_tw_now
from ic_agent_flow.domain.governance.checkpoint import (
    StageGateType, 
    DecisionEnum, 
    HumanReviewPackage, 
    AuthorityRecord,
    HumanDecision
)
from ic_agent_flow.domain.governance.readiness import ReadinessLevel, ClaimStatus

class ContextManifest(BaseModel):
    """Refers to the state of all subjects being evaluated."""
    subjects: List[str]
    version_id: str = "v1.0.0"
    created_at: datetime = Field(default_factory=get_tw_now)

class ExecutionRunRecord(BaseModel):
    """Record of a tool or agent execution event."""
    run_id: str
    timestamp: datetime = Field(default_factory=get_tw_now)
    tool_invocations: List[Any] = []
    metadata: Dict[str, Any] = {}

class CloseoutBundle(BaseModel):
    """
    The final 'Truth Chain' object proving a scenario or stage is complete.
    Combines manifest, execution records, evidence, and human authority.
    """
    id: UUID4 = Field(default_factory=uuid4)
    run_id: str
    manifest: ContextManifest
    verdicts: Dict[str, str] = {} # GateID -> STATUS (e.g. T-01 -> PASSED)
    authority: Optional[AuthorityRecord] = None
    execution_record: Optional[ExecutionRunRecord] = None
    created_at: datetime = Field(default_factory=get_tw_now)

class ReadinessNote(BaseModel):
    """A human-readable but structured explanation of a readiness transition."""
    id: UUID4 = Field(default_factory=uuid4)
    from_level: Optional[ReadinessLevel] = None
    to_level: ReadinessLevel
    rationale: str
    claims_verified: List[str] = []
    created_at: datetime = Field(default_factory=get_tw_now)
