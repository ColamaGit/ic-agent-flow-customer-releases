from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional
from uuid import uuid4

from pydantic import BaseModel, Field, UUID4

from ic_agent_flow.domain.utils.time import get_tw_now


class ToolSessionState(str, Enum):
    SESSION_INITIALIZED = "session_initialized"
    ATTACHED = "attached"
    QUEUED = "queued"
    RUNNING = "running"
    WAITING_ON_EXTERNAL_JOB = "waiting_on_external_job"
    ARTIFACT_PARTIAL_READY = "artifact_partial_ready"
    CHECKPOINTED = "checkpointed"
    PAUSED = "paused"
    RESUMING = "resuming"
    ROLLBACK_PENDING = "rollback_pending"
    ROLLED_BACK = "rolled_back"
    FAILED = "failed"
    TERMINATED = "terminated"
    COMPLETED = "completed"
    STALE_REJECTED = "stale_rejected"


class DataClassification(str, Enum):
    C0_PUBLIC = "C0"
    C1_INTERNAL = "C1"
    C2_SENSITIVE = "C2"
    C3_RESTRICTED = "C3"


class IntentRecord(BaseModel):
    intent_id: UUID4 = Field(default_factory=uuid4)
    workspace_id: str
    chip_id: str
    natural_language_design_intent: str
    classification: DataClassification = DataClassification.C1_INTERNAL
    created_at: datetime = Field(default_factory=get_tw_now)


class TranslationRecord(BaseModel):
    translation_record_id: UUID4 = Field(default_factory=uuid4)
    intent_id: UUID4
    structured_brief_ref: str
    adapter_ref: str
    redaction_policy_ref: str
    classification: DataClassification = DataClassification.C2_SENSITIVE
    created_at: datetime = Field(default_factory=get_tw_now)


class ToolCheckpoint(BaseModel):
    checkpoint_id: UUID4 = Field(default_factory=uuid4)
    tool_session_id: UUID4
    checkpoint_label: str
    stage: str
    artifact_refs: List[str] = Field(default_factory=list)
    lineage_refs: List[str] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=get_tw_now)


class CheckpointDeltaReport(BaseModel):
    delta_report_id: UUID4 = Field(default_factory=uuid4)
    tool_session_id: UUID4
    from_checkpoint_ref: str
    to_checkpoint_ref: str
    delta_summary: str
    degradation_detected: bool
    created_at: datetime = Field(default_factory=get_tw_now)


class RollbackCandidate(BaseModel):
    rollback_candidate_id: UUID4 = Field(default_factory=uuid4)
    tool_session_id: UUID4
    target_checkpoint_ref: str
    causal_reason: str
    delta_report_ref: str
    created_at: datetime = Field(default_factory=get_tw_now)


class RollbackDecisionRecord(BaseModel):
    rollback_decision_id: UUID4 = Field(default_factory=uuid4)
    tool_session_id: UUID4
    rollback_candidate_ref: str
    target_checkpoint_ref: str
    approved: bool
    reason: str
    created_at: datetime = Field(default_factory=get_tw_now)


class ToolSession(BaseModel):
    tool_session_id: UUID4 = Field(default_factory=uuid4)
    tool_family: str = "open_source_eda"
    contract_name: str = "eda_tool_contract"
    contract_version: str = "v1"

    workspace_id: str
    chip_id: str
    task_id: str = "task://unspecified"
    subject_refs: List[str]
    decision_context_ref: str

    session_status: ToolSessionState = ToolSessionState.SESSION_INITIALIZED
    execution_run_refs: List[str] = Field(default_factory=list)
    job_handle_refs: List[str] = Field(default_factory=list)
    artifact_refs: List[str] = Field(default_factory=list)
    normalized_output_refs: List[str] = Field(default_factory=list)
    lineage_refs: List[str] = Field(default_factory=list)
    checkpoint_refs: List[str] = Field(default_factory=list)
    rollback_decision_refs: List[str] = Field(default_factory=list)
    child_session_refs: List[str] = Field(default_factory=list)

    last_checkpoint_ref: Optional[str] = None
    resume_token: Optional[str] = None
    staleness_guard: str = "active"
    audit_refs: List[str] = Field(default_factory=list)
    checkpoint_absence_reason: Optional[str] = None

    created_at: datetime = Field(default_factory=get_tw_now)
    updated_at: datetime = Field(default_factory=get_tw_now)

    def attach_checkpoint(self, checkpoint: ToolCheckpoint) -> None:
        if checkpoint.tool_session_id != self.tool_session_id:
            raise ValueError("checkpoint session mismatch")
        checkpoint_ref = str(checkpoint.checkpoint_id)
        self.checkpoint_refs.append(checkpoint_ref)
        self.last_checkpoint_ref = checkpoint_ref
        self.session_status = ToolSessionState.CHECKPOINTED
        self.updated_at = get_tw_now()
        self.checkpoint_absence_reason = None

    def mark_checkpoint_absence_reason(self, reason: str) -> None:
        self.checkpoint_absence_reason = reason
        self.updated_at = get_tw_now()

    def apply_rollback(self, decision_record: RollbackDecisionRecord) -> None:
        if decision_record.tool_session_id != self.tool_session_id:
            raise ValueError("rollback session mismatch")
        if decision_record.target_checkpoint_ref not in self.checkpoint_refs:
            raise ValueError("rollback target is not a legal checkpoint")
        if not decision_record.approved:
            raise ValueError("rollback decision not approved")
        self.rollback_decision_refs.append(str(decision_record.rollback_decision_id))
        self.last_checkpoint_ref = decision_record.target_checkpoint_ref
        self.session_status = ToolSessionState.ROLLED_BACK
        self.updated_at = get_tw_now()

    def observability_snapshot(self) -> Dict[str, object]:
        return {
            "active_tool_sessions": 1,
            "tool_session_id": str(self.tool_session_id),
            "session_status": self.session_status.value,
            "tool_family": self.tool_family,
            "current_stage": self.last_checkpoint_ref or "pre-checkpoint",
            "requester_or_owner": self.task_id,
            "waiting_reason": "" if self.session_status != ToolSessionState.WAITING_ON_EXTERNAL_JOB else "external_job_pending",
            "timeout_risk": self.staleness_guard == "at_risk",
            "retry_count": len([r for r in self.execution_run_refs if "retry" in r]),
            "last_checkpoint": self.last_checkpoint_ref,
            "rollback_candidate_flag": self.session_status == ToolSessionState.ROLLBACK_PENDING,
            "attached_artifact_refs": self.artifact_refs,
            "current_decision_context_ref": self.decision_context_ref,
            "pending_human_checkpoint": self.session_status in {ToolSessionState.PAUSED, ToolSessionState.ROLLBACK_PENDING},
            "staleness_or_scope_mismatch_flags": self.staleness_guard != "active",
        }
