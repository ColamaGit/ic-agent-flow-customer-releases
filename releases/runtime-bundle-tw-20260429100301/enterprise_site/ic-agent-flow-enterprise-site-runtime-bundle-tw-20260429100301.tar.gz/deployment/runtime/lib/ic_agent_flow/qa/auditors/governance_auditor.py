import json
from pathlib import Path
from typing import Dict, List
from src.ic_agent_flow.domain.governance.registry import ReadinessRegistry
from src.ic_agent_flow.qa.evidence_assessor import EvidenceAssessor

class GovernanceAuditor:
    """Suite 1: Governance QA Auditor.
    Audits ReadinessRegistry, Drift Detection, and Revalidation logic.
    """
    
    def __init__(self, workspace_root: str):
        self.root = Path(workspace_root)
        self.registry_path = self.root / "artifacts" / "governance_registry.json"
        self.assessor = EvidenceAssessor()
        
    def audit_registry_integrity(self) -> Dict:
        """Checks if the registry is machine-readable and follows state transition laws."""
        results = {
            "auditor": "GovernanceAuditor",
            "check": "registry_integrity",
            "verdict": "ACCEPTABLE",
            "findings": []
        }
        
        if not self.registry_path.exists():
            results["verdict"] = "INSUFFICIENT_EVIDENCE"
            results["findings"].append("Registry file missing.")
            return results
            
        try:
            with open(self.registry_path, 'r') as f:
                entries = json.load(f)
                
            if not isinstance(entries, list):
                results["verdict"] = "LINEAGE_INCOMPLETE"
                results["findings"].append("Registry is not a valid list.")
                return results
            
            if not entries:
                results["findings"].append("Registry is empty.")
            
            # Check for active claims without evidence refs
            for entry in entries:
                if entry.get("status") == "active" and not entry.get("evidence_refs"):
                    results["verdict"] = "CLAIM_SCOPE_TOO_BROAD"
                    results["findings"].append(f"Active claim {entry.get('subject_id')} has no evidence references.")
                elif entry.get("status") == "pending_revalidation":
                    results["findings"].append(f"Claim {entry.get('subject_id')} is currently PENDING_REVALIDATION.")
                    
        except Exception as e:
            results["verdict"] = "LINEAGE_INCOMPLETE"
            results["findings"].append(f"Parse error: {str(e)}")
            
        return results

    def audit_drift_response(self) -> Dict:
        """Verifies if drift detection correctly triggers PENDING_REVALIDATION."""
        # Simulated check: check if any PENDING_REVALIDATION exists in registry
        results = {
            "auditor": "GovernanceAuditor",
            "check": "drift_response",
            "verdict": "ACCEPTABLE",
            "findings": []
        }
        
        try:
            with open(self.registry_path, 'r') as f:
                entries = json.load(f)
            
            pending = [e for e in entries if e.get("status") == "pending_revalidation"]
            if not pending:
                results["findings"].append("No claims in PENDING_REVALIDATION. Drift detector may not have run or no drift found.")
            else:
                results["findings"].append(f"Found {len(pending)} claims in revalidation loop.")
                
        except Exception:
            pass
            
        return results

if __name__ == "__main__":
    auditor = GovernanceAuditor(".")
    print(json.dumps(auditor.audit_registry_integrity(), indent=2))
    print(json.dumps(auditor.audit_drift_response(), indent=2))
