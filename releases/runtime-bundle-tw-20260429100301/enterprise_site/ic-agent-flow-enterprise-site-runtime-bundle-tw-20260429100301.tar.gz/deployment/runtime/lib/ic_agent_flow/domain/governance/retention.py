from enum import Enum
from datetime import datetime, timedelta

class RetentionClass(str, Enum):
    EPHEMERAL = "ephemeral" # Cleanup after job ends
    SHORT_TERM = "short-term" # Keeps for 7 days
    GOVERNED = "governed" # Keeps for 30 days
    PERMANENT = "permanent" # Keeps forever (Audits/Closeouts)

class RetentionPolicy:
    """
    Defines TTL (Time-To-Live) for different data types.
    """
    
    TTL_MAP = {
        RetentionClass.EPHEMERAL: timedelta(minutes=60), 
        RetentionClass.SHORT_TERM: timedelta(days=7),
        RetentionClass.GOVERNED: timedelta(days=30),
        RetentionClass.PERMANENT: timedelta(days=3650) # Approx 10 years
    }
    
    @staticmethod
    def get_ttl(retention: RetentionClass) -> timedelta:
        return RetentionPolicy.TTL_MAP.get(retention, timedelta(days=7))
        
    @staticmethod
    def is_expired(created_at: datetime, retention: RetentionClass) -> bool:
        ttl = RetentionPolicy.get_ttl(retention)
        if retention == RetentionClass.PERMANENT: 
            return False
        return (datetime.now() - created_at) > ttl
