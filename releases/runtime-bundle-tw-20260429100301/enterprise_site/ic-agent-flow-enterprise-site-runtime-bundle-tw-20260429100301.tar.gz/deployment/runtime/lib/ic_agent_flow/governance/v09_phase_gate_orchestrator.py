from __future__ import annotations

from pathlib import Path
from typing import Dict

from pydantic import BaseModel

from ic_agent_flow.governance.v09_sequencing_law import Step, V09SequencingLaw
from ic_agent_flow.registry.scenario_registry import (
    CanonicalCommandRegistry,
    CommandVerificationVerdict,
    Disposition,
)


class PhaseGateInput(BaseModel):
    step: Step
    command_id: str
    evidence_flags: Dict[str, bool]


class PhaseGateOutcome(BaseModel):
    allowed: bool
    disposition: Disposition
    reason: str


class V09PhaseGateOrchestrator:
    def __init__(self, registry: CanonicalCommandRegistry):
        self.registry = registry

    @classmethod
    def from_registry_path(cls, registry_path: Path) -> "V09PhaseGateOrchestrator":
        return cls(CanonicalCommandRegistry.load_json(registry_path))

    def evaluate(self, gate_input: PhaseGateInput) -> PhaseGateOutcome:
        command_verdict: CommandVerificationVerdict = self.registry.verify_command_id(gate_input.command_id)
        if not command_verdict.allowed:
            return PhaseGateOutcome(
                allowed=False,
                disposition=command_verdict.disposition,
                reason=command_verdict.reason,
            )

        sequencing = V09SequencingLaw.can_promote(gate_input.step, gate_input.evidence_flags)
        if not sequencing.allowed:
            return PhaseGateOutcome(
                allowed=False,
                disposition=sequencing.disposition,
                reason=f"missing_conditions: {','.join(sequencing.missing_conditions)}",
            )

        return PhaseGateOutcome(
            allowed=True,
            disposition=Disposition.PASS,
            reason="command and sequencing gates satisfied",
        )
