from ic_agent_flow.domain.execution import ToolCommand, CompilationResult, ExecutionBounds
from ic_agent_flow.domain.objects import AuthorityClass, Producer, ProducerType
from datetime import datetime, timezone
from uuid import uuid4
import hashlib

class MockCompiler:
    """Mock compiler adapter for bounded-compile-elab scenario."""
    
    def __init__(self, tool_name: str, version: str):
        self.tool_name = tool_name
        self.version = version

    def execute(self, command: ToolCommand, bounds: ExecutionBounds) -> CompilationResult:
        # Standard Producer
        tool_producer = Producer(id=f"tool_{self.tool_name}", type=ProducerType.TOOL)
        
        # Validate Bounds
        for arg in command.args:
            if arg in bounds.forbidden_args:
                return CompilationResult(
                    id=uuid4(),
                    status="FAILURE",
                    version="v1.0.0",
                    authority_class=AuthorityClass.DERIVED,
                    producer=tool_producer,
                    created_at=datetime.now(timezone.utc),
                    exit_code=1,
                    log_hash="N/A",
                    error_count=1,
                    warning_count=0,
                    metadata={"error": f"Forbidden argument found: {arg}"}
                )
        
        # Simulate Execution
        log_content = f"Compiling with {self.tool_name} {self.version}...\n"
        log_content += f"Arguments: {' '.join(command.args)}\n"
        log_content += "Success: 0 errors, 2 warnings.\n"
        
        log_hash = hashlib.sha256(log_content.encode()).hexdigest()
        
        return CompilationResult(
            id=uuid4(),
            status="SUCCESS",
            version="v1.0.0",
            authority_class=AuthorityClass.DERIVED,
            producer=tool_producer,
            created_at=datetime.now(timezone.utc),
            exit_code=0,
            log_hash=log_hash,
            error_count=0,
            warning_count=2,
            artifacts_generated=["top.vdb", "top.simv"],
            metadata={"tool": self.tool_name, "version": self.version}
        )
