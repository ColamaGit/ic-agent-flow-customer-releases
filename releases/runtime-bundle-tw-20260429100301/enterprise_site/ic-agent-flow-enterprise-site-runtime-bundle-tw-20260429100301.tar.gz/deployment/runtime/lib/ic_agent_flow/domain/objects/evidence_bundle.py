"""
Evidence Bundle Reference (Phase 2, D2-8)
==========================================
The top-level evidence container submitted for human review.
Bundles all D2-4 through D2-7 outputs into one auditable package.

Authority: DERIVED — produced by Evidence Collector Agent at end of triage run.
           This is the handoff object to the Human Review Loop (Phase 3).
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import List, Optional

from ic_agent_flow.domain.objects.artifact_ref import ArtifactRef
from ic_agent_flow.domain.objects.triage_result import VerificationTriageResult


class BundleStatus(str, Enum):
    """Lifecycle status of the evidence bundle."""
    ASSEMBLING = "assembling"
    READY_FOR_REVIEW = "ready_for_review"
    UNDER_REVIEW = "under_review"
    REVIEWED = "reviewed"
    CLOSED = "closed"
    REJECTED = "rejected"
    EVIDENCE_REQUESTED = "evidence_requested"
    OBLIGATION_PENDING = "obligation_pending"
    ESCALATED = "escalated"


@dataclass
class EvidenceBundleRef:
    """
    Evidence Bundle Reference (D2-8).

    This is the final output package of Phase 2 and the handoff
    object to Phase 3 (Human Review Loop Materialization).

    Invariants:
    - bundle_id is globally unique
    - chip_scope MUST match all contained evidence objects
    - triage_result MUST be present before status transitions to READY_FOR_REVIEW
    - raw_artifacts contains all ArtifactRefs consumed during evidence collection
    - agent CANNOT mark status = REVIEWED or CLOSED (human-only)
    """
    bundle_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    chip_scope: str = ""
    workspace_id: str = "default-workspace"
    task_id: str = ""
    agent_id: str = ""

    # Core deliverables
    triage_result: Optional[VerificationTriageResult] = None
    raw_artifacts: List[ArtifactRef] = field(default_factory=list)

    # Audit & Lineage (v0.6 R4)
    status: BundleStatus = BundleStatus.ASSEMBLING
    assembly_notes: List[str] = field(default_factory=list)
    resubmission_history: List[str] = field(default_factory=list)
    parent_bundle_id: Optional[str] = None      # ID of the bundle that triggered the gap/handoff
    prior_bundle_refs: List[str] = field(default_factory=list) # Full lineage trail

    # Timestamps
    assembled_at: Optional[datetime] = None
    submitted_at: Optional[datetime] = None
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def mark_ready(self) -> None:
        """Mark bundle as ready for human review. Validates required fields."""
        if self.triage_result is None:
            raise ValueError("EvidenceBundleRef requires triage_result before marking ready.")
        if not self.chip_scope:
            raise ValueError("EvidenceBundleRef requires chip_scope before marking ready.")

        self.status = BundleStatus.READY_FOR_REVIEW
        self.assembled_at = datetime.now(timezone.utc)
        self.submitted_at = datetime.now(timezone.utc)

    def to_summary_dict(self) -> dict:
        """Return a human-readable summary for audit logging."""
        sim = self.triage_result.simulation_result if self.triage_result else None
        return {
            "bundle_id": self.bundle_id,
            "chip_scope": self.chip_scope,
            "status": self.status.value,
            "task_id": self.task_id,
            "agent_id": self.agent_id,
            "verdict": sim.verdict.value if sim else "N/A",
            "tests_run": sim.tests_run if sim else 0,
            "tests_passed": sim.tests_passed if sim else 0,
            "tests_failed": sim.tests_failed if sim else 0,
            "coverage_avg_pct": sim.coverage.average_pct if sim else None,
            "assertions_failed": sim.assertions.failed if sim else 0,
            "critical_failures": self.triage_result.critical_failure_count if self.triage_result else 0,
            "risk_level": self.triage_result.risk_level.value if self.triage_result else "unknown",
            "recommendation": self.triage_result.recommendation.value if self.triage_result else "unknown",
            "raw_artifact_count": len(self.raw_artifacts),
            "evidence_complete": self.triage_result.evidence_complete if self.triage_result else False,
            "assembled_at": self.assembled_at.isoformat() if self.assembled_at else None,
        }
