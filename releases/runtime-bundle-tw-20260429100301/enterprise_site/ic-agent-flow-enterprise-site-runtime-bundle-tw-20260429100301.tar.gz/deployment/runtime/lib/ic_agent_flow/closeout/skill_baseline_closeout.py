"""
Skill Baseline Closeout Engine (Phase 4)
=========================================
Generates the 5-Layer Integrity Protection Manifest and final Closure Adjudication.
Ensures formal Message Authentication Code (MAC) protection for audit bundles.

Layers:
1. Case Identity / Scope
2. MCP Evidence (Canonical Truth)
3. Skill Support Materials (Advisory Only)
4. Decision Chain (Authority Log)
5. Re-entry / Closeout History (Governance State)

Audit Bundle Integrity Note:
`DecisionAuditBundle.bundle_digest` 採用 HMAC-SHA256 做 integrity protection / 
MAC-based tamper-evidence，用於 at-rest integrity baseline；此機制不等同於 
asymmetric digital signature，亦不改變 bundle 內各 object 的 authority class。
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional
from uuid import uuid4

from ic_agent_flow.domain.objects.decision_objects import DecisionAuditBundle
from ic_agent_flow.domain.utils.time import get_tw_now

class SkillBaselineCloseout:
    """
    Phase 4 Baseline Closeout Engine.
    Focus: Integrity protection, canonical payload verification, and MAC-based tamper-evidence.
    """
    
    def __init__(self, chip_scope: str, bundle_id: str, secret_key: Optional[str] = None):
        self.chip_scope = chip_scope
        self.bundle_id = bundle_id
        # Minimal Key Governance: environment-based secret loading
        self.secret_key = (secret_key or os.getenv("GOVERNANCE_HMAC_KEY", "governance-baseline-secret")).encode()
        self.key_id = "gov-mac-v1-baseline"
        
        self.layers: Dict[str, Any] = {
            "layer_1_identity": {},
            "layer_2_mcp": [],
            "layer_3_skills": {},
            "layer_4_decision": [],
            "layer_5_history": {},
            "layer_6_hardened_evidence": {} # NEW: For R3/R4 remediation
        }

    def generate_layered_manifest(
        self,
        subject_refs: List[str],
        mcp_evidence_refs: List[str],
        skill_invocation_refs: List[str],
        skill_output_refs: List[str],
        decision_record_refs: List[str],
        reentry_history: List[str],
        matrix_verdict: str = "baseline_closed_with_documented_limits",
        skill_trace_refs: Optional[List[str]] = None,
        negative_proof_refs: Optional[List[str]] = None,
        integrity_verification_refs: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """Builds the 6-layer (remastered) Integrity Protection Manifest structure."""
        
        self.layers["layer_1_identity"] = {
            "chip_scope": self.chip_scope,
            "bundle_id": self.bundle_id,
            "subject_refs": subject_refs,
            "timestamp": get_tw_now().isoformat()
        }
        
        # Layer 2: MCP Evidence (The Canonical Truth Spine)
        self.layers["layer_2_mcp"] = mcp_evidence_refs
        
        # Layer 3: Skill Support Materials (Advisory/Derived, Support-Material-Only)
        self.layers["layer_3_skills"] = {
            "invocations": skill_invocation_refs,
            "outputs": skill_output_refs,
            "traces": skill_trace_refs or [],
            "role": "ADVISORY_SUPPORT_ONLY",
            "authority_class": "Derived/Advisory"
        }
        
        # Layer 4: Decision Chain (The Authority Authority Log)
        self.layers["layer_4_decision"] = decision_record_refs
        
        # Layer 5: Re-entry / Closeout History
        self.layers["layer_5_history"] = {
            "reentry_chain": reentry_history,
            "final_judgment": matrix_verdict,
            "closeout_status": "CLOSED"
        }

        # Layer 6: Hardened Evidence (Remediation R3/R4)
        self.layers["layer_6_hardened_evidence"] = {
            "negative_proof_packs": negative_proof_refs or [],
            "integrity_verification_records": integrity_verification_refs or []
        }
        
        return self.layers

    def compute_bundle_mac(self, manifest: Dict[str, Any]) -> str:
        """
        Computes HMAC-SHA256 MAC for the canonical bundle payload.
        Used for integrity protection and at-rest tamper-evidence.
        """
        # Canonicalization: sort keys to ensure deterministic digest
        manifest_str = json.dumps(manifest, sort_keys=True).encode()
        mac = hmac.new(self.secret_key, manifest_str, hashlib.sha256).hexdigest()
        return mac

    def create_audit_bundle(self, manifest: Dict[str, Any], extra_metadata: Optional[Dict[str, Any]] = None) -> DecisionAuditBundle:
        """
        Produces a formal DecisionAuditBundle with Integrity Protection (MAC).
        """
        mac = self.compute_bundle_mac(manifest)
        
        metadata = {
            "mac_algorithm": "HMAC-SHA256",
            "key_id": self.key_id,
            "integrity_protection_type": "tamper_evidence_mac",
            "created_at": get_tw_now().isoformat(),
            "terminology_verdict": "INTEGRITY_PROTECTION_ONLY_NOT_DIGITAL_SIGNATURE",
            "remediation_grade": "R1-R5_HARDENED"
        }
        if extra_metadata:
            metadata.update(extra_metadata)
            
        return DecisionAuditBundle(
            bundle_id=self.bundle_id,
            chip_scope=self.chip_scope,
            review_package_ref=f"pkg-{self.bundle_id}",
            evidence_refs=manifest["layer_2_mcp"],
            decision_record_refs=manifest["layer_4_decision"],
            skill_invocation_refs=manifest["layer_3_skills"]["invocations"],
            skill_output_refs=manifest["layer_3_skills"]["outputs"],
            bundle_digest=mac, # Use MAC as the digest string
            metadata=metadata
        )

    def persist_closeout_package(self, project_root: str, bundle: DecisionAuditBundle, manifest: Dict[str, Any]):
        """Persists the bundle and manifest with verified integrity metadata."""
        evidence_dir = Path(project_root) / "chips" / self.chip_scope / "evidence" / "closeout"
        evidence_dir.mkdir(parents=True, exist_ok=True)
        
        # Save manifest (The Layered Evidence)
        manifest_path = evidence_dir / f"audit_manifest_{self.bundle_id}.v2.json"
        manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False))
        
        # Save bundle (The Authority Linkage + MAC)
        bundle_path = evidence_dir / f"audit_bundle_{self.bundle_id}.v2.json"
        bundle_data = bundle.model_dump() if hasattr(bundle, "model_dump") else bundle.__dict__
        bundle_path.write_text(json.dumps(bundle_data, indent=2, default=str))
        
        return str(bundle_path)
