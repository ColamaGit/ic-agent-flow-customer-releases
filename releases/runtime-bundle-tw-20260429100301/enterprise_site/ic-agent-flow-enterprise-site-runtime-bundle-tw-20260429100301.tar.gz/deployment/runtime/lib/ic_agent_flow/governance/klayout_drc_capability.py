from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List
from uuid import uuid4

from pydantic import BaseModel

from ic_agent_flow.registry.scenario_registry import Disposition


class KlayoutMcpCapabilityRequest(BaseModel):
    workspace_id: str
    chip_id: str
    task_id: str
    decision_context_ref: str
    contract_name: str
    contract_version: str
    def_path: str | None = None
    gds_path: str | None = None
    timeout_sec: int = 120
    output_root: str = "artifacts/v0.9/klayout"
    python_bin: str = ".venv/bin/python3"
    request_schema_version: str = "v0.1"
    run_key: str | None = None


class KlayoutMcpCapabilityResponse(BaseModel):
    disposition: Disposition
    reason: str
    contract_id: str
    request_schema_version: str
    boundary_mode: str
    error_taxonomy: List[str]
    run_id: str | None = None
    execution_run_ref: str | None = None
    tool_version: str | None = None
    artifact_paths: Dict[str, str] = {}
    artifact_refs: Dict[str, str] = {}


KlayoutMcpCapabilityRequest.model_rebuild()
KlayoutMcpCapabilityResponse.model_rebuild()


class KlayoutMcpCapabilityBoundary:
    """
    Formal MCP capability boundary for klayout_drc (local mode).
    Uses the .venv klayout Python package.
    """

    CAPABILITY_NAME = "klayout_drc"
    CONTRACT_NAME = "klayout_drc_contract"
    CONTRACT_VERSION = "v0.1"
    BOUNDARY_MODE = "formal_mcp_capability_boundary_local_mode_v0.1"
    ERROR_TAXONOMY = [
        "chip_scope_unresolved",
        "input_schema_invalid",
        "tool_missing",
        "tool_timeout",
        "tool_runtime_error",
        "artifact_missing",
        "output_unparseable",
        "decision_context_mismatch",
    ]

    @staticmethod
    def _sha256_file(path: Path) -> str:
        h = hashlib.sha256()
        with path.open("rb") as f:
            while True:
                chunk = f.read(8192)
                if not chunk:
                    break
                h.update(chunk)
        return h.hexdigest()

    @classmethod
    def _fail(cls, reason: str, req: KlayoutMcpCapabilityRequest) -> KlayoutMcpCapabilityResponse:
        return KlayoutMcpCapabilityResponse(
            disposition=Disposition.FAIL_CLOSED,
            reason=reason,
            contract_id=f"{req.contract_name}@{req.contract_version}",
            request_schema_version=req.request_schema_version,
            boundary_mode=cls.BOUNDARY_MODE,
            error_taxonomy=list(cls.ERROR_TAXONOMY),
        )

    def execute(self, req: KlayoutMcpCapabilityRequest) -> KlayoutMcpCapabilityResponse:
        required_values = [
            req.workspace_id,
            req.chip_id,
            req.task_id,
            req.decision_context_ref,
            req.contract_name,
            req.contract_version,
        ]
        if any(not value for value in required_values):
            return self._fail("input_schema_invalid:envelope_missing", req)

        if req.contract_name != self.CONTRACT_NAME or req.contract_version != self.CONTRACT_VERSION:
            return self._fail("input_schema_invalid:unsupported_contract", req)

        if not req.decision_context_ref.startswith("decision://"):
            return self._fail("decision_context_mismatch:invalid_context", req)

        if not Path(req.python_bin).exists() and shutil.which(req.python_bin) is None:
            return self._fail("tool_missing:python_not_found", req)

        run_id = req.run_key or f"klayout-{uuid4().hex[:12]}"
        out_dir = Path(req.output_root) / run_id
        out_dir.mkdir(parents=True, exist_ok=True)

        raw_log_path = out_dir / "klayout.raw.log"
        normalized_metadata_path = out_dir / "normalized.drc.meta.json"
        input_manifest_path = out_dir / "input_manifest.json"
        lineage_path = out_dir / "lineage.json"
        evidence_bundle_path = out_dir / "evidence_bundle.json"
        script_path = out_dir / "klayout_drc_script.py"
        report_xml_path = out_dir / "klayout_drc.xml"
        realized_gds_path = out_dir / "top.h4.gds"
        summary_path = out_dir / "klayout.summary.json"

        gds_path = Path(req.gds_path).resolve() if req.gds_path else None
        def_path = Path(req.def_path).resolve() if req.def_path else None
        if gds_path and not gds_path.exists():
            return self._fail("artifact_missing:gds_input_not_found", req)
        if def_path and not def_path.exists():
            return self._fail("artifact_missing:def_input_not_found", req)
        if not gds_path and not def_path:
            return self._fail("input_schema_invalid:no_layout_input", req)

        # Real H4 execution: materialize a KLayout layout from H2 DEF or provided GDS,
        # emit a GDS artifact, and write an XML report with real geometry checks.
        script_content = [
            "import json",
            "import re",
            "import os",
            "import sys",
            "import xml.etree.ElementTree as ET",
            "from pathlib import Path",
            "try:",
            "    import klayout.db as kdb",
            "except ImportError as e:",
            "    print('KLAYOUT_IMPORT_FAILED:', e)",
            "    sys.exit(1)",
            "",
            "def _parse_def(def_path):",
            "    text = Path(def_path).read_text(encoding='utf-8', errors='ignore')",
            "    design_match = re.search(r'^DESIGN\\s+(\\S+)\\s+;$', text, re.MULTILINE)",
            "    die_match = re.search(r'^DIEAREA\\s+\\(\\s*(-?\\d+)\\s+(-?\\d+)\\s*\\)\\s+\\(\\s*(-?\\d+)\\s+(-?\\d+)\\s*\\)\\s*;$', text, re.MULTILINE)",
            "    dbu_match = re.search(r'^UNITS DISTANCE MICRONS\\s+(\\d+)\\s+;$', text, re.MULTILINE)",
            "    component_match = re.search(r'^COMPONENTS\\s+(\\d+)\\s+;$', text, re.MULTILINE)",
            "    pins = []",
            "    current = None",
            "    in_pins = False",
            "    for raw_line in text.splitlines():",
            "        line = raw_line.strip()",
            "        if line.startswith('PINS '):",
            "            in_pins = True",
            "            continue",
            "        if line == 'END PINS':",
            "            in_pins = False",
            "            continue",
            "        if not in_pins:",
            "            continue",
            "        if line.startswith('- '):",
            "            parts = line.split()",
            "            current = {'name': parts[1]}",
            "            pins.append(current)",
            "            continue",
            "        if current is None:",
            "            continue",
            "        layer_match = re.search(r'\\+ LAYER\\s+(\\S+)\\s+\\(\\s*(-?\\d+)\\s+(-?\\d+)\\s*\\)\\s+\\(\\s*(-?\\d+)\\s+(-?\\d+)\\s*\\)', line)",
            "        if layer_match:",
            "            current['layer'] = layer_match.group(1)",
            "            current['rect'] = [int(layer_match.group(i)) for i in range(2, 6)]",
            "            continue",
            "        placed_match = re.search(r'\\+ (?:PLACED|FIXED)\\s+\\(\\s*(-?\\d+)\\s+(-?\\d+)\\s*\\)\\s+(\\S+)', line)",
            "        if placed_match:",
            "            current['origin'] = [int(placed_match.group(1)), int(placed_match.group(2))]",
            "            current['orient'] = placed_match.group(3)",
            "    return {",
            "        'design': design_match.group(1) if design_match else 'TOP',",
            "        'dbu': int(dbu_match.group(1)) if dbu_match else 1000,",
            "        'die_area': [int(die_match.group(i)) for i in range(1, 5)] if die_match else None,",
            "        'components_total': int(component_match.group(1)) if component_match else 0,",
            "        'pins': pins,",
            "    }",
            "",
            "def _insert_box(cell, layer_index, box):",
            "    x1, y1, x2, y2 = box",
            "    cell.shapes(layer_index).insert(kdb.Box(min(x1, x2), min(y1, y2), max(x1, x2), max(y1, y2)))",
            "",
            "def _build_layout_from_def(parsed, output_gds):",
            "    layout = kdb.Layout()",
            "    layout.dbu = 1.0 / parsed['dbu']",
            "    top = layout.create_cell(parsed['design'])",
            "    outline_layer = layout.layer(kdb.LayerInfo(900, 0))",
            "    if parsed.get('die_area'):",
            "        _insert_box(top, outline_layer, parsed['die_area'])",
            "    layer_map = {}",
            "    next_layer = 1",
            "    for pin in parsed['pins']:",
            "        if 'layer' not in pin or 'rect' not in pin or 'origin' not in pin:",
            "            continue",
            "        layer_name = pin['layer']",
            "        if layer_name not in layer_map:",
            "            layer_map[layer_name] = layout.layer(kdb.LayerInfo(next_layer, 0))",
            "            next_layer += 1",
            "        ox, oy = pin['origin']",
            "        x1, y1, x2, y2 = pin['rect']",
            "        _insert_box(top, layer_map[layer_name], [ox + x1, oy + y1, ox + x2, oy + y2])",
            "    layout.write(output_gds)",
            "    return layout",
            "",
            "def _load_layout_from_gds(gds_path, output_gds):",
            "    layout = kdb.Layout()",
            "    layout.read(gds_path)",
            "    if Path(gds_path).resolve() != Path(output_gds).resolve():",
            "        layout.write(output_gds)",
            "    return layout",
            "",
            "def _count_shapes(cell, layer_count):",
            "    total = 0",
            "    for layer_index in range(layer_count):",
            "        for _shape in cell.shapes(layer_index).each():",
            "            total += 1",
            "    return total",
            "",
            "def _run_checks(layout, parsed=None):",
            "    violations = []",
            "    top_cells = list(layout.top_cells())",
            "    if not top_cells:",
            "        violations.append('No top cell present in realized layout')",
            "        return violations",
            "    top = top_cells[0]",
            "    shape_count = _count_shapes(top, layout.layers())",
            "    if shape_count == 0:",
            "        violations.append('No layout shapes realized for H4 DRC')",
            "    if parsed and parsed.get('die_area'):",
            "        dx1, dy1, dx2, dy2 = parsed['die_area']",
            "        pin_boxes_by_layer = {}",
            "        for pin in parsed['pins']:",
            "            if 'layer' not in pin or 'rect' not in pin or 'origin' not in pin:",
            "                continue",
            "            ox, oy = pin['origin']",
            "            x1, y1, x2, y2 = pin['rect']",
            "            box = [min(ox + x1, ox + x2), min(oy + y1, oy + y2), max(ox + x1, ox + x2), max(oy + y1, oy + y2)]",
            "            if box[0] < dx1 or box[1] < dy1 or box[2] > dx2 or box[3] > dy2:",
            "                violations.append(f\"Pin {pin['name']} extends outside DIEAREA\")",
            "            existing = pin_boxes_by_layer.setdefault(pin['layer'], [])",
            "            for other_name, other_box in existing:",
            "                overlap = not (box[2] <= other_box[0] or box[0] >= other_box[2] or box[3] <= other_box[1] or box[1] >= other_box[3])",
            "                if overlap:",
            "                    violations.append(f\"Pin overlap on {pin['layer']}: {other_name} vs {pin['name']}\")",
            "            existing.append((pin['name'], box))",
            "    return violations",
            "",
            "def _write_xml_report(report_path, violations):",
            "    root = ET.Element('report')",
            "    for violation in violations:",
            "        item = ET.SubElement(root, 'item')",
            "        item.text = violation",
            "    tree = ET.ElementTree(root)",
            "    tree.write(report_path, encoding='utf-8', xml_declaration=True)",
            "",
            "print(f'KLAYOUT_VERSION: {kdb.__version__}')",
            f"gds_input = {repr(gds_path.as_posix() if gds_path else None)}",
            f"def_input = {repr(def_path.as_posix() if def_path else None)}",
            f"report_path = {repr(report_xml_path.as_posix())}",
            f"realized_gds_path = {repr(realized_gds_path.as_posix())}",
            f"summary_path = {repr(summary_path.as_posix())}",
            "parsed = None",
            "if gds_input:",
            "    layout = _load_layout_from_gds(gds_input, realized_gds_path)",
            "    source_kind = 'gds'",
            "else:",
            "    parsed = _parse_def(def_input)",
            "    layout = _build_layout_from_def(parsed, realized_gds_path)",
            "    source_kind = 'def'",
            "violations = _run_checks(layout, parsed)",
            "_write_xml_report(report_path, violations)",
            "summary = {",
            "    'tool': 'klayout',",
            "    'tool_version': kdb.__version__,",
            "    'source_kind': source_kind,",
            "    'violations_total': len(violations),",
            "    'status': 'PASS' if not violations else 'FAIL',",
            "    'report_ref': report_path,",
            "    'gds_ref': realized_gds_path,",
            "}",
            "Path(summary_path).write_text(json.dumps(summary, indent=2), encoding='utf-8')",
            "print('KLAYOUT_H4_REAL_RUN_PASS')",
            "sys.exit(0)",
        ]

        script_path.write_text("\n".join(script_content) + "\n", encoding="utf-8")
        env = os.environ.copy()

        command_argv = [
            req.python_bin,
            script_path.as_posix(),
        ]

        started_at = datetime.now(timezone.utc)
        try:
            cwd_path = str(Path.cwd())
            proc = subprocess.run(
                command_argv,
                cwd=cwd_path,
                capture_output=True,
                text=True,
                timeout=req.timeout_sec,
                env=env
            )
            finished_at = datetime.now(timezone.utc)
        except subprocess.TimeoutExpired:
            raw_log_path.write_text("tool_timeout: klayout exceeded timeout\n", encoding="utf-8")
            return self._fail("tool_timeout:klayout_execution_timeout", req)

        raw_log_path.write_text((proc.stdout or "") + "\n" + (proc.stderr or ""), encoding="utf-8")
        if proc.returncode != 0:
            return self._fail("tool_runtime_error:klayout_non_zero_exit", req)
        
        output_text = raw_log_path.read_text(encoding="utf-8")
        if "KLAYOUT_H4_REAL_RUN_PASS" not in output_text:
            return self._fail("output_unparseable:missing_pass_marker", req)

        import re
        version_match = re.search(r"KLAYOUT_VERSION:\s*([\d\.]+)", output_text)
        tool_version = version_match.group(1) if version_match else "0.30.7"
        if not summary_path.exists():
            return self._fail("artifact_missing:klayout_summary_not_generated", req)
        summary = json.loads(summary_path.read_text(encoding="utf-8"))

        input_manifest = {
            "workspace_id": req.workspace_id,
            "chip_id": req.chip_id,
            "task_id": req.task_id,
            "contract_name": req.contract_name,
            "contract_version": req.contract_version,
            "decision_context_ref": req.decision_context_ref,
            "tool": "klayout",
            "tool_version": tool_version,
            "tool_binary_path": req.python_bin,
            "command": " ".join(command_argv),
            "cwd": cwd_path,
            "layout_input_kind": summary["source_kind"],
            "layout_input_path": gds_path.as_posix() if gds_path else def_path.as_posix(),
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }
        input_manifest_path.write_text(json.dumps(input_manifest, indent=2), encoding="utf-8")

        normalized = {
            "tool": "klayout",
            "tool_version": tool_version,
            "contract_name": req.contract_name,
            "contract_version": req.contract_version,
            "tool_binary_path": req.python_bin,
            "status": summary["status"],
            "source_kind": summary["source_kind"],
            "violations_total": summary["violations_total"],
            "report_ref": report_xml_path.as_posix(),
            "gds_ref": realized_gds_path.as_posix(),
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }
        normalized_metadata_path.write_text(json.dumps(normalized, indent=2), encoding="utf-8")

        duration_ms = int((finished_at - started_at).total_seconds() * 1000)
        lineage = {
            "run_id": run_id,
            "started_at": started_at.isoformat(),
            "finished_at": finished_at.isoformat(),
            "exit_code": proc.returncode,
            "duration_ms": duration_ms,
            "command_argv": command_argv,
            "working_dir": cwd_path,
            "input_manifest_ref": input_manifest_path.as_posix(),
            "output_refs": [
                raw_log_path.as_posix(),
                normalized_metadata_path.as_posix(),
                report_xml_path.as_posix(),
                realized_gds_path.as_posix(),
            ],
            "decision_context_ref": req.decision_context_ref,
            "session_id": "",
            "task_id": req.task_id,
            "workspace_id": req.workspace_id,
            "chip_id": req.chip_id,
        }
        lineage_path.write_text(json.dumps(lineage, indent=2), encoding="utf-8")

        evidence_bundle = {
            "run_id": run_id,
            "raw_refs": [raw_log_path.as_posix()],
            "normalized_refs": [normalized_metadata_path.as_posix(), report_xml_path.as_posix()],
            "lineage_ref": lineage_path.as_posix(),
            "digests": {
                "raw_log_sha256": self._sha256_file(raw_log_path),
                "normalized_sha256": self._sha256_file(normalized_metadata_path),
                "input_manifest_sha256": self._sha256_file(input_manifest_path),
                "lineage_sha256": self._sha256_file(lineage_path),
                "report_xml_sha256": self._sha256_file(report_xml_path),
                "gds_sha256": self._sha256_file(realized_gds_path),
            },
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }
        evidence_bundle_path.write_text(json.dumps(evidence_bundle, indent=2), encoding="utf-8")

        return KlayoutMcpCapabilityResponse(
            disposition=Disposition.PASS,
            reason="formal_klayout_mcp_capability_execution_pass",
            contract_id=f"{req.contract_name}@{req.contract_version}",
            request_schema_version=req.request_schema_version,
            boundary_mode=self.BOUNDARY_MODE,
            error_taxonomy=list(self.ERROR_TAXONOMY),
            run_id=run_id,
            execution_run_ref=f"run://{self.CAPABILITY_NAME}/{run_id}",
            tool_version=tool_version,
            artifact_paths={
                "raw_log": raw_log_path.as_posix(),
                "normalized_metadata": normalized_metadata_path.as_posix(),
                "report_xml": report_xml_path.as_posix(),
                "gds": realized_gds_path.as_posix(),
                "summary": summary_path.as_posix(),
                "input_manifest": input_manifest_path.as_posix(),
                "lineage": lineage_path.as_posix(),
                "evidence_bundle": evidence_bundle_path.as_posix(),
            },
            artifact_refs={
                "raw_log_ref": f"artifact://klayout/{run_id}/klayout.raw.log",
                "normalized_ref": f"norm://klayout/{run_id}/normalized.drc.meta.json",
                "lineage_ref": f"lineage://klayout/{run_id}/lineage.json",
                "evidence_bundle_ref": f"evidence_bundle://klayout/{run_id}",
            },
        )
