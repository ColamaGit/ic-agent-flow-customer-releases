from enum import Enum
from typing import Dict, List, Any, Optional
from pydantic import BaseModel, Field

class CapabilityFamily(str, Enum):
    MCP_CAPABILITY = "mcp_capability"
    EDA_AGENT_SKILL = "eda_agent_skill"

class CapabilityEntry(BaseModel):
    name: str
    version: str
    family: CapabilityFamily
    contract_id: Optional[str] = None
    status: str = "active"
    metadata: Dict[str, Any] = Field(default_factory=dict)

class CapabilityRegistry(BaseModel):
    """
    Centralized Registry for ic-agent-flow capabilities.
    Enforces distinction between MCP_CAPABILITY and EDA_AGENT_SKILL (Design AC1/FA-1).
    """
    entries: Dict[CapabilityFamily, Dict[str, CapabilityEntry]] = Field(
        default_factory=lambda: {
            CapabilityFamily.MCP_CAPABILITY: {},
            CapabilityFamily.EDA_AGENT_SKILL: {}
        }
    )
    
    def register(self, entry: CapabilityEntry):
        """
        Registers a new capability entry into its family (Design AC1).
        """
        self.entries[entry.family][entry.name] = entry
        
    def get_entry(self, family: CapabilityFamily, name: str) -> Optional[CapabilityEntry]:
        return self.entries.get(family, {}).get(name)

    def list_entries(self, family: CapabilityFamily) -> List[CapabilityEntry]:
        return list(self.entries.get(family, {}).values())
