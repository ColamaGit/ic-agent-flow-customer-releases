"""
Deployment Guard Engine (v3.2 Negative Proof Baseline)
=====================================================
Enforces deployment policies and integrity checks for the EDA Agent Skill Layer.
Responsible for generating first-class negative proofs (IntegrityFailure, PolicyDenial).
"""
from __future__ import annotations

import hmac
import hashlib
from typing import Optional, Tuple
from uuid import UUID

from ic_agent_flow.domain.objects.deployment_objects import (
    DeploymentAdmissionRecord,
    DeploymentPolicy,
    DeploymentIntegrityResult,
    DeploymentAuditRecord,
    DeploymentStatus,
    DispositionReasonCode,
)
from ic_agent_flow.domain.utils.time import get_tw_now


class DeploymentGuardEngine:
    """The authoritative enforcement component for controlled production deployment."""

    def __init__(self, hmac_key: bytes):
        self.hmac_key = hmac_key

    def verify_policy_alignment(
        self, admission: DeploymentAdmissionRecord, policy: DeploymentPolicy, target_scope: str
    ) -> Tuple[bool, Optional[DispositionReasonCode]]:
        """
        R7 Deny-case: Verifies if the target scope is within the allowed policy.
        """
        if admission.policy_id != policy.policy_id:
            return False, DispositionReasonCode.ERR_POLICY_SCOPE_VIOLATION
        
        if target_scope not in policy.allowed_chip_scopes:
            return False, DispositionReasonCode.ERR_POLICY_SCOPE_VIOLATION
        
        return True, None

    def verify_temporal_validity(self, policy: DeploymentPolicy) -> Tuple[bool, Optional[DispositionReasonCode]]:
        """
        Priority 3: Verifies if the deployment window is open.
        """
        now = get_tw_now()
        if policy.valid_from and now < policy.valid_from:
            return False, DispositionReasonCode.ERR_TEMPORAL_EXPIRED # Not yet active
        if policy.valid_until and now > policy.valid_until:
            return False, DispositionReasonCode.ERR_TEMPORAL_EXPIRED
        return True, None

    def verify_family_authorization(
        self, policy: DeploymentPolicy, skill_family: str
    ) -> Tuple[bool, Optional[DispositionReasonCode]]:
        """
        Priority 3: Verifies if the skill family is authorized in this policy.
        """
        if skill_family not in policy.allowed_skill_families:
            return False, DispositionReasonCode.ERR_FAMILY_UNAUTHORIZED
        return True, None

    def verify_artifact_integrity(
        self, artifact_content: bytes, expected_mac: str, target_ref: str
    ) -> DeploymentIntegrityResult:
        """
        R7 Tamper-case: Verifies HMAC-SHA256 integrity and produces a formal result object.
        """
        actual_mac_bytes = hmac.new(self.hmac_key, artifact_content, hashlib.sha256).digest()
        actual_mac = actual_mac_bytes.hex()
        
        is_verified = (actual_mac == expected_mac)
        blocking_reason = None if is_verified else "Integrity Failure: MAC mismatch detected (Artifact may be tampered)."
        
        return DeploymentIntegrityResult(
            target_ref=target_ref,
            expected_mac=expected_mac,
            actual_mac=actual_mac,
            is_verified=is_verified,
            blocking_reason=blocking_reason,
            verified_at=get_tw_now()
        )

    def adjudicate_deployment(
        self, 
        admission: DeploymentAdmissionRecord, 
        policy: DeploymentPolicy, 
        target_scope: str,
        integrity_result: DeploymentIntegrityResult,
        skill_family: Optional[str] = None
    ) -> Tuple[DeploymentStatus, DispositionReasonCode]:
        """
        Final fail-closed adjudication combining policy, temporal, family and integrity results.
        """
        # 1. Check Policy Alignment
        policy_ok, reason = self.verify_policy_alignment(admission, policy, target_scope)
        if not policy_ok:
            return DeploymentStatus.BLOCKED, reason or DispositionReasonCode.ERR_POLICY_SCOPE_VIOLATION
        
        # 2. Check Temporal Validity
        temporal_ok, t_reason = self.verify_temporal_validity(policy)
        if not temporal_ok:
            return DeploymentStatus.BLOCKED, t_reason or DispositionReasonCode.ERR_TEMPORAL_EXPIRED

        # 3. Check Family Authorization
        if skill_family:
            family_ok, f_reason = self.verify_family_authorization(policy, skill_family)
            if not family_ok:
                return DeploymentStatus.BLOCKED, f_reason or DispositionReasonCode.ERR_FAMILY_UNAUTHORIZED

        # 4. Check Integrity Result
        if not integrity_result.is_verified:
            return DeploymentStatus.FAILED, DispositionReasonCode.ERR_INTEGRITY_DRIFT
        
        # 5. Check Admission Status
        if admission.status != DeploymentStatus.ACTIVATED:
            return DeploymentStatus.REVOKED, DispositionReasonCode.EMERGENCY_REVOCATION

        return DeploymentStatus.ACTIVATED, DispositionReasonCode.OK_ADMISSION_GRANTED
