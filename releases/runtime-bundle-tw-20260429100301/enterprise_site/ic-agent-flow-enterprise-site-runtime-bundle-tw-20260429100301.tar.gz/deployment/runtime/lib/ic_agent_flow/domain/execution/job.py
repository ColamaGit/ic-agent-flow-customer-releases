from enum import Enum
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime
from uuid import UUID, uuid4
from ic_agent_flow.domain.objects import BaseObject, DataClassification

class JobStatus(str, Enum):
    PENDING = "pending"
    SUBMITTED = "submitted"
    QUEUED = "queued"
    RUNNING = "running"
    PARTIAL_OUTPUT_AVAILABLE = "partial_output_available"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    TIMED_OUT = "timed_out"

class AsyncJob(BaseObject):
    """
    Represents an asynchronous execution unit (process, Slurm job, etc.)
    that tracks a ToolInvocation.
    """
    type: str = "async_job"
    target_invocation_id: UUID
    status: JobStatus = JobStatus.PENDING
    scheduler_type: str = "local" # local, slurm, batch
    scheduler_id: Optional[str] = None # PID or Job ID from Scheduler
    submit_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    exit_code: Optional[int] = None
    stdout_ref: Optional[str] = None
    stderr_ref: Optional[str] = None
    partial_results: List[str] = Field(default_factory=list)
    
    def is_terminal(self) -> bool:
        return self.status in [JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED, JobStatus.TIMED_OUT]
