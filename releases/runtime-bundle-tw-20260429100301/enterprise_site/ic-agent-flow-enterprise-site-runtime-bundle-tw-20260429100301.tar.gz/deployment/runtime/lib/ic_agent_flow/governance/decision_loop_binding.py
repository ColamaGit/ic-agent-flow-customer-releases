from typing import Dict, Any, List
from ic_agent_flow.domain.governance.checkpoint import DecisionEnum
from ic_agent_flow.domain.objects.human_review import HumanDecisionRecord

class DecisionLoopBinding:
    """
    將 Ops Line 的門禁結果綁定至 v0.5 Decision Loop 語義
    """
    
    @staticmethod
    def map_to_decision_request(gate_id: str, results: Dict[str, Any]) -> Dict[str, Any]:
        """
        將 Entry/Checkpoint 失敗結果轉譯為 Decision Loop 所需的 request
        """
        if results.get("status") == "FAIL_CLOSED":
            return {
                "decision_type": DecisionEnum.REJECT,
                "reason": f"Gate {gate_id} failed: {results.get('reason')}",
                "context": "deployment_admission"
            }
        elif results.get("status") == "HOLD":
            return {
                "decision_type": DecisionEnum.HOLD,
                "reason": f"Gate {gate_id} requires human intervention: {results.get('reason')}",
                "context": "deployment_admission"
            }
        # 如果門禁通過，預設請求 APPROVE
        return {"decision_type": DecisionEnum.APPROVE, "context": "deployment_admission"}

    @staticmethod
    def bind_to_decision_record(decision_record: HumanDecisionRecord, checkpoint_id: str):
        """
        確保 DecisionRecord 記錄了對應的 checkpoint 引用
        """
        if not hasattr(decision_record, "metadata"):
            decision_record.metadata = {}
        decision_record.metadata["checkpoint_id"] = checkpoint_id
        return decision_record
