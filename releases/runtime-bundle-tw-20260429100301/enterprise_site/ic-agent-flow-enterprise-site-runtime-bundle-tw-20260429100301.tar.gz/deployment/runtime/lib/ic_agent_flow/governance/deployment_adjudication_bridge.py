"""
Deployment Adjudication Bridge (v3.3 Consolidation)
==================================================
Bridges deployment拦截事件 (DeploymentAuditBundle) to the human decision loop.
Converts system-level blocks into authority-bearing HumanReviewPackages.
"""
from __future__ import annotations

from typing import Optional
from uuid import UUID

from ic_agent_flow.domain.objects.deployment_objects import (
    DeploymentAuditBundle,
    DeploymentStatus,
)
from ic_agent_flow.domain.governance.checkpoint import (
    HumanReviewPackage,
    StageGateType,
    DecisionEnum,
)
from ic_agent_flow.domain.utils.time import get_tw_now


class DeploymentAdjudicationBridge:
    """Bridges the gap between automatic enforcement and human authority."""

    @staticmethod
    def create_escalation_package(bundle: DeploymentAuditBundle) -> HumanReviewPackage:
        """
        R10: Transforms a failed/blocked deployment bundle into a HumanReviewPackage.
        """
        status = bundle.admission_record.status
        # In a real scenario, we'd check if any audit_record outcome is FAILED/BLOCKED
        primary_outcome = bundle.audit_records[0].outcome if bundle.audit_records else "UNKNOWN"
        
        target_id = bundle.audit_records[0].target_id if bundle.audit_records else "NA"
        
        summary = (
            f"🚨 DEPLOYMENT GOVERNANCE ESCALATION: {primary_outcome}\n"
            f"Target: {target_id}\n"
            f"Policy: {bundle.admission_record.policy_id}\n"
            f"Reason: {bundle.integrity_results[0].blocking_reason if bundle.integrity_results else 'Policy Denial'}"
        )
        
        # Layered Evidence Construction
        layer_a = [f"deployment_bundle_id: {bundle.deployment_bundle_id}"]
        layer_b = []
        for ir in bundle.integrity_results:
            layer_b.append(f"integrity_result: {ir.result_id} (is_verified={ir.is_verified})")
            if ir.blocking_reason:
                layer_b.append(f"  - block_reason: {ir.blocking_reason}")
        
        layer_c = [f"admission_record: {bundle.admission_record.admission_id}"]

        package = HumanReviewPackage(
            subject_ref=target_id,
            gate_type=StageGateType.EXCEPTION_ACCEPTANCE,  # Formal Exception path
            summary=summary,
            decision_options=[
                DecisionEnum.REJECT,              # Confirm the block
                DecisionEnum.REQUEST_MORE_EVIDENCE, # Ask for better proof
                DecisionEnum.APPROVE_WITH_CONDITIONS # Emergency override (requires high authority)
            ],
            layer_a_evidence=layer_a,
            layer_b_support=layer_b,
            layer_c_history=layer_c,
            open_risks=[
                "Deployment integrity failure detected.",
                "Executing unauthorized target (Policy Denial)."
            ]
        )
        
        # Back-link the bundle
        bundle.escalation_package_ref = package.id
        
        return package
