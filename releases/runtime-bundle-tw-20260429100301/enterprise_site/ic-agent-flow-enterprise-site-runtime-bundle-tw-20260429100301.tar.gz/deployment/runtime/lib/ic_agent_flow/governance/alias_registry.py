from typing import Dict

class SubjectAliasRegistry:
    # 儲存 Canonical ID -> Alias 的映射
    _registry: Dict[str, str] = {
        "SN2025": "Governed EDA Flow Baseline (Yosys/OpenROAD)"
    }
    
    @classmethod
    def get_alias(cls, canonical_id: str) -> str:
        return cls._registry.get(canonical_id, canonical_id)
