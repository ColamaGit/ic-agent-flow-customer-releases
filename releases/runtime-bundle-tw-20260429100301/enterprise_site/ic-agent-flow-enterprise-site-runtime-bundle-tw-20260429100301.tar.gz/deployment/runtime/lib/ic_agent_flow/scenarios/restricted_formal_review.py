"""
Scenario: Restricted Formal Review (Family 1)
Type: human-gated
Tier: Tier 3 (High-Value)

E2E review of Tier 3 Formal Verification results with manual adjudication.
"""

import asyncio
from uuid import uuid4
from datetime import datetime, timedelta

from ic_agent_flow.domain.governance.checkpoint import (
    HumanReviewPackage, StageGateType, DecisionEnum, 
    HumanCheckpointRunner, CheckpointPolicy, AuthorityRecord
)
from ic_agent_flow.domain.governance.events import (
    emit_governance_event, LaunchGateRequest, StallEvent
)
from ic_agent_flow.domain.governance.registry import ReadinessRegistry
from ic_agent_flow.domain.governance.readiness import SubjectType
from ic_agent_flow.domain.utils.time import get_tw_now

async def run_restricted_formal_review():
    print("🚀 [Family 1] Initializing Tier 3 Formal Review Scenario...")
    registry = ReadinessRegistry()
    run_id = uuid4()
    subject_id = "cpu-ctrl-formal-clean"
    
    # 1. Launch Gate
    print("\n--- Phase 1: Launch Gate Request ---")
    launch_req = LaunchGateRequest(
        run_id=run_id,
        subject_ref=subject_id,
        intent_summary="Formal Property Verification for CPU Controller (Tier 3 IP)",
        security_tier="Tier 3",
        requested_by="verification_lead_01"
    )
    emit_governance_event(launch_req)
    
    # 2. Execution & Stall
    print("\n--- Phase 2: Formal Execution & Property Violation Detection ---")
    print("JasperGold: 2 property violations found in reset_logic_block.")
    
    stall = StallEvent(
        package_id=str(uuid4()), # Simulated package ID
        reason="Property Violations require human waiver for Tier 3 promotion.",
        severity="CRITICAL",
        timeout_at=get_tw_now() + timedelta(minutes=15)
    )
    emit_governance_event(stall)
    
    # 3. Human Adjudication Surface
    print("\n--- Phase 3: Human Review Package Generation ---")
    package = HumanReviewPackage(
        subject_ref=subject_id,
        gate_type=StageGateType.ARTIFACT_REVIEW,
        summary="Formal run completed with 2 violations. Analyzed as unreachable in current SOC config.",
        open_risks=["Violation in reset_logic_block (waived)", "Tier 3 Boundary Access"],
        evidence_links=["lineage://formal/cpu_ctrl_jg_report.log"]
    )
    
    # Interactive Review Simulation
    policy = CheckpointPolicy(timeout_seconds=60)
    decision = HumanCheckpointRunner.execute_checkpoint(package, policy)
    
    # 4. Authority Recording
    print("\n--- Phase 4: Recording Authority & Registry Update ---")
    record = AuthorityRecord(
        gate_type=package.gate_type,
        decision=decision.decision,
        rationale=decision.rationale,
        approver=decision.human_id,
        subject_refs=[subject_id],
        evidence_refs=package.evidence_links
    )
    
    # Propose the claim first
    registry.propose_claim(subject_id, SubjectType.SCENARIO, "formal_review_bundle.json")
    
    # Process the decision
    registry.process_authority_record(subject_id, record)
    
    print(f"\nFinal Registry Status for '{subject_id}': {registry.query_active(SubjectType.SCENARIO, subject_id).status if registry.query_active(SubjectType.SCENARIO, subject_id) else 'STALLED'}")
    print("\n✅ Family 1 Scenario Complete.")

if __name__ == "__main__":
    asyncio.run(run_restricted_formal_review())
