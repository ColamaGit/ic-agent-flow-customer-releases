"""
Collaboration Queue Manager (v0.8, PRD v0.8 Baseline)
=====================================================
R7: Implements fairness-aware, resource-scoped task queueing.
Ensures that starvation is prevented and chip-scope isolation is maintained.
"""
import heapq
from datetime import datetime
from typing import List, Optional, Dict, Any
from uuid import UUID

from ic_agent_flow.domain.objects.collaboration_objects import (
    CollaborationQueueRecord,
    ResourceAllocationRecord
)
from ic_agent_flow.domain.utils.time import get_tw_now


class CollaborationQueueManager:
    """
    Governed scheduler for collaboration sessions.
    Sorts by (priority_class, waited_since, fairness_class).
    """

    def __init__(self, capacity_slots: int = 4):
        self.queue: List[CollaborationQueueRecord] = []
        self.active_allocations: Dict[UUID, ResourceAllocationRecord] = {}
        self.capacity_slots = capacity_slots

    def enqueue(self, session_id: UUID, priority_class: int = 100) -> CollaborationQueueRecord:
        """
        Adds a session to the queue.
        """
        record = CollaborationQueueRecord(
            session_ref=session_id,
            priority_class=priority_class,
            waited_since=get_tw_now()
        )
        self.queue.append(record)
        # Sort queue: Lower priority_class first, then older waited_since
        self.queue.sort(key=lambda r: (r.priority_class, r.waited_since))
        return record

    def try_allocate(self, session_id: UUID, resource_class: str = "CPU_MINIMAL") -> Optional[ResourceAllocationRecord]:
        """
        Attempts to allocate a slot for a session.
        R7: Fairness and capacity accounting.
        """
        # 1. Capacity Check
        if len(self.active_allocations) >= self.capacity_slots:
            return None
            
        # 2. Check if it's the session's turn
        # R7: Strict head-of-queue discipline. 
        # Only the head of the queue is allowed to allocate resources in v0.8.
        if not self.queue or self.queue[0].session_ref != session_id:
            # We deny allocation if session is not at the head
            return None

        # 3. Create Allocation
        allocation = ResourceAllocationRecord(
            session_ref=session_id,
            resource_class=resource_class,
            lease_start=get_tw_now()
        )
        self.active_allocations[session_id] = allocation
        
        # 4. Remove from queue
        self.queue = [r for r in self.queue if r.session_ref != session_id]
        
        return allocation

    def release(self, session_id: UUID):
        """
        Releases a resource slot.
        """
        if session_id in self.active_allocations:
            alloc = self.active_allocations.pop(session_id)
            alloc.released_at = get_tw_now()
            # In a real system, we'd log this or update a persistence layer

    def get_queue_status(self) -> List[Dict[str, Any]]:
        return [
            {
                "session_id": str(r.session_ref),
                "priority": r.priority_class,
                "waited_for": (get_tw_now() - r.waited_since).total_seconds()
            }
            for r in self.queue
        ]
