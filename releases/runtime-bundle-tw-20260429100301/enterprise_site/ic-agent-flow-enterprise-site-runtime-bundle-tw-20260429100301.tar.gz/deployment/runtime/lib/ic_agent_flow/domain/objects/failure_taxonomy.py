"""
Failure Taxonomy (Phase 2, D2-7)
==================================
Canonical classification of IC verification failure types.
Used in VerificationTriageResult to classify what went wrong.

Authority: CANONICAL — this is the source of truth for failure classification.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Optional


class FailureCategory(str, Enum):
    """Top-level failure category taxonomy for IC verification."""
    # Simulation failures
    ASSERTION_FAILURE = "assertion_failure"
    TEST_CASE_FAILURE = "test_case_failure"
    ELABORATION_ERROR = "elaboration_error"
    SIMULATION_ABORT = "simulation_abort"
    # Coverage failures
    COVERAGE_INSUFFICIENT = "coverage_insufficient"
    COVERAGE_GOAL_MISSED = "coverage_goal_missed"
    # Structural issues
    PORT_WIDTH_MISMATCH = "port_width_mismatch"
    UNUSED_PORT_WARNING = "unused_port_warning"
    # Data integrity
    DATA_INTEGRITY_VIOLATION = "data_integrity_violation"
    # Tool / environment issues
    TOOL_ERROR = "tool_error"
    TIMEOUT = "timeout"
    # Unknown
    UNKNOWN = "unknown"


class FailureSeverity(str, Enum):
    """Severity class for a failure record."""
    CRITICAL = "critical"     # Blocks promotion — must be resolved
    HIGH = "high"             # Requires human review decision
    MEDIUM = "medium"         # Should be documented
    LOW = "low"               # Informational only
    WARNING = "warning"       # Non-blocking concern


@dataclass
class FailureRecord:
    """
    A single classified failure from a verification run (D2-7).

    Each FailureRecord maps one raw failure event to a canonical
    FailureCategory and FailureSeverity, with optional location and evidence.
    """
    category: FailureCategory
    severity: FailureSeverity
    message: str
    location: Optional[str] = None          # e.g. "mem_ctrl.sv:202"
    raw_text: Optional[str] = None          # Original log line(s)
    test_case: Optional[str] = None         # Associated test case name
    assertion_name: Optional[str] = None    # Assertion identifier if applicable
    recorded_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    @property
    def blocks_promotion(self) -> bool:
        return self.severity == FailureSeverity.CRITICAL

    @property
    def requires_human_review(self) -> bool:
        return self.severity in {FailureSeverity.CRITICAL, FailureSeverity.HIGH}
