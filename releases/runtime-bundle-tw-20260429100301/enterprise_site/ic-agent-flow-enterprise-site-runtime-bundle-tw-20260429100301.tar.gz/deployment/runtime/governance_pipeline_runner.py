#!/usr/bin/env python3
"""
governance_pipeline_runner.py — Governed EDA Pipeline Runner
=============================================================
Assembles a chip-scoped production run from canonical EDA artifacts.

Subject Integrity Guard (Addendum Law 2, Law 9):
  Before copying any canonical artifact into a new chip run, the runner
  validates that the artifact's chip_id matches the target chip_id.
  On mismatch → emit ERR_INTEGRITY_DRIFT and generate a subject-aware
  placeholder directory instead of blindly copying subject-invalid data.

Compare-Class Stage Guard (Addendum Section 8.3):
  For h3_netgen (LVS compare-class stage), the runner validates that
  source_ref_a != source_ref_b.  If they are identical (self-comparison),
  the stage is marked ERR_INTEGRITY_DRIFT.duplicate_compare_source_invalid
  and a placeholder is emitted.

v0.2 Report generation:
  After artifact assembly, calls the v0.2 compiler (generate_readiness_report.py)
  which requires subject_binding/ fixtures to exist first.
"""

import json
import os
import shutil
import hashlib
import re
import sys
from pathlib import Path
from pathlib import Path


def _find_repo_root(start_file: str) -> str:
    for candidate in Path(start_file).resolve().parents:
        if (candidate / "README.md").exists() and (candidate / "deployment").exists():
            return str(candidate)
    return os.path.abspath(os.path.join(os.path.dirname(start_file), "..", "..", ".."))


BASE_DIR = _find_repo_root(__file__)
sys.path.append(os.path.join(BASE_DIR, "workspace", "shared-runtime", "lib"))
sys.path.append(os.path.join(BASE_DIR, "workspace", "shared-runtime", "scripts"))
sys.path.append(os.path.join(BASE_DIR, "deployment", "runtime", "lib"))
from ic_agent_flow.registry.scenario_registry import Disposition
from ic_agent_flow.governance.verilator_lint_capability import VerilatorLintMcpCapabilityBoundary, VerilatorLintMcpCapabilityRequest
from ic_agent_flow.governance.verilator_sim_capability import VerilatorSimMcpCapabilityBoundary, VerilatorSimMcpCapabilityRequest
from ic_agent_flow.governance.cdc_rdc_analysis_capability import (
    CdcRdcAnalysisCapabilityBoundary,
    CdcRdcAnalysisRequest,
)
from ic_agent_flow.governance.toolchain_profile_resolver import (
    resolve_toolchain_profile,
    write_toolchain_resolution_artifact,
)
from ic_agent_flow.governance.v10_upstream_snapshot import (
    KickoffMode,
    materialize_v10_upstream_input_snapshot,
)
from ic_agent_flow.governance.v10_downstream_gate import (
    DownstreamAdmissionStatus,
    derive_downstream_admission,
)
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Optional, Tuple

sys.path.append(os.path.dirname(__file__))

# ─────────────────────────────────────────────────────────────────────────────
# ERR codes (Addendum Section 11)
# ─────────────────────────────────────────────────────────────────────────────

ERR_CHIP_IDENTITY_MISMATCH  = "ERR_INTEGRITY_DRIFT.chip_identity_mismatch"
ERR_MANIFEST_UNBOUND        = "ERR_INTEGRITY_DRIFT.chip_manifest_unbound"
ERR_DUPLICATE_COMPARE       = "ERR_INTEGRITY_DRIFT.duplicate_compare_source_invalid"
ERR_ARTIFACT_UNBOUND        = "ERR_INTEGRITY_DRIFT.artifact_subject_unbound"


def _fail_closed_on_environment_adjudication(toolchain_resolution: Dict) -> None:
    adjudication = toolchain_resolution.get("environment_adjudication") or {}
    if not adjudication.get("fail_closed"):
        return
    triggers = adjudication.get("active_invalidation_triggers") or []
    trigger_suffix = ",".join(str(item) for item in triggers) if triggers else "unresolved_environment_provenance"
    raise RuntimeError(f"environment_invalid:{trigger_suffix}")


def _capture_v10_upstream_inputs(
    *,
    run_dir: str,
    chip_id: str,
    rtl_src: str,
    kickoff_mode: str = "rtl_compat",
) -> str:
    chip_dir = Path(BASE_DIR) / "chips" / chip_id
    manifest = materialize_v10_upstream_input_snapshot(
        chip_dir=chip_dir,
        run_dir=Path(run_dir),
        rtl_src=Path(rtl_src),
        kickoff_mode=KickoffMode(kickoff_mode),
    )
    print(
        "  ✅ [inputs] v1.0 snapshot materialized: "
        f"inputs/spec|graph|design  gate={manifest.upstream_gate_state.value}"
    )
    print("  ✅ [inputs] RTL read-compat alias available at inputs/rtl")
    return str(Path(run_dir) / "inputs" / "design" / "rtl")


def _enforce_v10_downstream_admission(chip_id: str) -> None:
    admission = derive_downstream_admission(Path(BASE_DIR) / "chips" / chip_id)
    if admission.status == DownstreamAdmissionStatus.ALLOWED:
        print("  ✅ [v1.0] downstream admission allowed: frozen graph + generation plan ready")
        return
    reasons = ",".join(admission.blocking_reasons) or "unknown"
    raise RuntimeError(f"v1_0_downstream_admission_blocked:{reasons}")


def get_tw_time():
    return datetime.now(timezone(timedelta(hours=8)))


def _templates_root() -> str:
    return os.environ.get("IC_AGENT_FLOW_TEMPLATES_ROOT", "templates")


def _template_path(*parts: str) -> str:
    return os.path.join(_templates_root(), *parts)


def _sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(8192)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


# ─────────────────────────────────────────────────────────────────────────────
# Subject Integrity Validator
# ─────────────────────────────────────────────────────────────────────────────

def _load_artifact_chip_id(artifact_dir: str) -> Optional[str]:
    """Read chip_id from input_manifest.json or lineage.json in an artifact dir."""
    for fname in ("input_manifest.json", "lineage.json"):
        p = os.path.join(artifact_dir, fname)
        if os.path.exists(p):
            with open(p) as f:
                data = json.load(f)
            chip_id = data.get("chip_id")
            if chip_id:
                return chip_id
    return None


def _check_lvs_compare_sources(artifact_dir: str) -> Tuple[bool, Optional[str]]:
    """
    Validate h3 LVS compare sources are not identical (Addendum 8.3).
    Returns (is_valid, error_code_or_None).
    """
    manifest_path = os.path.join(artifact_dir, "input_manifest.json")
    if not os.path.exists(manifest_path):
        return True, None  # No manifest: let downstream handle
    with open(manifest_path) as f:
        data = json.load(f)
    sources = data.get("sources", [])
    if len(sources) >= 2:
        ref_a = sources[0].get("path", "")
        ref_b = sources[1].get("path", "")
        if ref_a and ref_b and ref_a == ref_b:
            return False, ERR_DUPLICATE_COMPARE
    return True, None


def _write_integrity_drift_marker(stage_dir: str, error_code: str, reason: str,
                                   source_chip_id: Optional[str], target_chip_id: str):
    """
    Write integrity_drift.json marker and override the normalized result stub
    so downstream mappers see INTEGRITY_DRIFT status.
    Called AFTER full artifact copytree — raw EDA outputs are preserved,
    but governance layer marks them as subject-invalid.
    """
    marker = {
        "integrity_status": "ERR_INTEGRITY_DRIFT",
        "error_code": error_code,
        "reason": reason,
        "source_chip_id": source_chip_id,
        "target_chip_id": target_chip_id,
        "generated_at": get_tw_time().isoformat(),
        "action_required": (
            "Raw EDA tool outputs are preserved in this directory for audit reference. "
            "However they are NOT subject-valid evidence for this chip. "
            "Rerun this EDA stage with the correct chip subject before evidence is admissible."
        )
    }
    with open(os.path.join(stage_dir, "integrity_drift.json"), "w") as f:
        json.dump(marker, f, indent=2)

    # Override normalized result stub to INTEGRITY_DRIFT status
    # so downstream mappers (generate_readiness_report.py) detect it correctly
    normalized_stub_map = {
        "h3_netgen": "normalized.lvs.meta.json",
        "h1_yosys":  "normalized.netlist.meta.json",
        "h2_openroad": "normalized.drc.meta.json",
    }
    for prefix, filename in normalized_stub_map.items():
        if prefix in stage_dir:
            stub = {
                "tool": "N/A",
                "status": "INTEGRITY_DRIFT",
                "error_code": error_code,
                "reason": reason,
                "note": (
                    "Raw EDA tool output preserved for audit. "
                    "Not admissible as subject-valid evidence until rerun with correct chip subject."
                ),
                "generated_at": get_tw_time().isoformat(),
            }
            with open(os.path.join(stage_dir, filename), "w") as f:
                json.dump(stub, f, indent=2)
            break


def _copy_stage_with_integrity_guard(
    stage: str, src_path: str, dest_dir: str,
    target_chip_id: str
) -> Dict:
    """
    Copy ALL EDA tool outputs from a canonical artifact stage into the run directory,
    then apply subject integrity validation.

    Design principle (Addendum Law 9 + PRD v0.9 evidence preservation):
      - Raw EDA tool outputs are ALWAYS copied (they are audit records).
      - If subject_id mismatches or compare semantics are invalid, integrity_drift.json
        is written AFTER copy, and the normalized result stub is overridden to
        INTEGRITY_DRIFT status, so downstream mappers see the correct governance state.
      - This ensures: every run dir has complete EDA artifacts for audit replay,
        while governance layer correctly blocks subject-invalid evidence from
        entering the readiness claim.
    """
    if not os.path.exists(src_path):
        return {"stage": stage, "status": "SKIPPED", "reason": f"Source path not found: {src_path}"}

    # Always copy all EDA tool outputs first
    dest = os.path.join(dest_dir, stage)
    shutil.copytree(src_path, dest, dirs_exist_ok=True)

    # 1. Subject chip_id validation (Addendum Law 2, Law 9)
    source_chip_id = _load_artifact_chip_id(src_path)
    if source_chip_id and source_chip_id != target_chip_id:
        reason = (
            f"Source artifact chip_id='{source_chip_id}' does not match "
            f"target chip_id='{target_chip_id}'. Subject-invalid artifact rejected."
        )
        dest = os.path.join(dest_dir, stage)
        _write_integrity_drift_marker(dest, ERR_CHIP_IDENTITY_MISMATCH,
                                       reason, source_chip_id, target_chip_id)
        print(f"  ⚠️  [{stage}] {ERR_CHIP_IDENTITY_MISMATCH}: {reason}")
        return {
            "stage": stage, "status": "INTEGRITY_DRIFT",
            "error_code": ERR_CHIP_IDENTITY_MISMATCH, "reason": reason
        }

    # 2. Compare-class stage guard for h3_netgen (Addendum Section 8.3)
    if stage == "h3_netgen":
        lvs_ok, lvs_err = _check_lvs_compare_sources(src_path)
        if not lvs_ok:
            reason = (
                f"LVS compare sources are identical (self-comparison). "
                f"This is not a valid LVS evidence artifact. Placeholder emitted."
            )
            dest = os.path.join(dest_dir, stage)
            _write_integrity_drift_marker(dest, ERR_DUPLICATE_COMPARE,
                                           reason, source_chip_id, target_chip_id)
            print(f"  ⚠️  [{stage}] {ERR_DUPLICATE_COMPARE}: {reason}")
            return {
                "stage": stage, "status": "INTEGRITY_DRIFT",
                "error_code": ERR_DUPLICATE_COMPARE, "reason": reason
            }

    # 3. All validations passed — already copied at top of function
    print(f"  ✅ [{stage}] Copied from {src_path}  (chip_id={source_chip_id or 'N/A'} validated)")
    return {"stage": stage, "status": "COPIED", "source": src_path}


# ─────────────────────────────────────────────────────────────────────────────
# Subject Binding Fixture Writer
# ─────────────────────────────────────────────────────────────────────────────

def _write_subject_binding_fixtures(run_dir: str, chip_id: str, task_id: str,
                                     chip_name: str, rtl_function: str,
                                     technology_context: str, baseline_tools: List[str]):
    """Write Addendum Phase 1 subject-binding fixtures (scope_resolution_record,
    manifest_binding_record, execution_subject_envelope) into <run_dir>/subject_binding/."""
    binding_dir = os.path.join(run_dir, "subject_binding")
    os.makedirs(binding_dir, exist_ok=True)
    ts = get_tw_time().isoformat()
    workspace_id = f"ws-{chip_id}"

    srr = {
        "resolution_id":    f"srr-{chip_id}-{task_id}-auto",
        "workspace_id":     workspace_id,
        "chip_id":          chip_id,
        "task_id":          task_id,
        "subject_refs":     [f"chips/{chip_id}/chip_program_manifest.json"],
        "resolution_status": "VALIDATED",
        "resolved_by":      "system:governance_pipeline_runner",
        "resolved_at":      ts,
    }
    mbr = {
        "binding_id":                   f"mbr-{chip_id}-{task_id}-auto",
        "chip_program_manifest_ref":    f"chips/{chip_id}/chip_program_manifest.json",
        "chip_program_manifest_digest": f"sha256:auto-generated-{chip_id}",
        "bound_scope_resolution_ref":   srr["resolution_id"],
        "binding_status":               "BOUND",
        "created_at":                   ts,
        "chip_name":                    chip_name,
        "rtl_function":                 rtl_function,
        "description":                  f"{chip_name} — auto-assembled run for {task_id}",
        "technology_context":           technology_context,
        "baseline_tools":               baseline_tools,
        "subject_alias":                chip_name,
    }
    ese = {
        "envelope_id":                  f"ese-{chip_id}-{task_id}-auto",
        "workspace_id":                 workspace_id,
        "chip_id":                      chip_id,
        "chip_program_manifest_ref":    mbr["chip_program_manifest_ref"],
        "chip_program_manifest_digest": mbr["chip_program_manifest_digest"],
        "task_id":                      task_id,
        "subject_refs":                 srr["subject_refs"],
        "authority_context_refs":       [],
        "decision_context_ref":         f"decision://{task_id}/formal-release",
        "decision_state":               "PRE_DECISION",
        "reentry_history_ref":          None,
        "reentry_state":                "NO_REENTRY",
        "created_at":                   ts,
    }

    for filename, obj in [
        ("scope_resolution_record.json",    srr),
        ("manifest_binding_record.json",    mbr),
        ("execution_subject_envelope.json", ese),
    ]:
        with open(os.path.join(binding_dir, filename), "w") as f:
            json.dump(obj, f, indent=2)

    print(f"  ✅ [subject_binding] fixtures written: chip_id={chip_id}  task_id={task_id}")
    return srr, mbr, ese


def _stage_contract_profile(stage: str) -> Tuple[Optional[str], Optional[str]]:
    mapping = {
        "v1_verilator_lint": ("verilator_lint", "capability_profile://verilator_lint/v0.1"),
        "v2_verilator_sim": ("verilator_sim", "capability_profile://verilator_sim/v0.1"),
        "v3_cdc_rdc": ("cdc_rdc_analysis", "capability_profile://cdc_rdc_analysis/v0.1"),
        "v4_yosys_lec": ("yosys_lec", "capability_profile://yosys_lec/v0.1"),
        "h1_yosys": ("yosys_synth", "capability_profile://yosys_synth/v0.1"),
        "h2_openroad": ("openroad_execute", "capability_profile://openroad_execute/v0.1"),
        "h3_netgen": ("netgen_lvs", "capability_profile://netgen_lvs/v0.1"),
        "h4_klayout": ("klayout_drc", "capability_profile://klayout_drc/v0.1"),
    }
    return mapping.get(stage, (None, None))


def _normalized_status_for_stage(stage_dir: str) -> str:
    candidates = [
        "normalized.lint.meta.json",
        "normalized.sim.meta.json",
        "normalized.cdc.meta.json",
        "normalized.lec.meta.json",
        "normalized.netlist.meta.json",
        "normalized.drc.meta.json",
        "normalized.lvs.meta.json",
    ]
    for name in candidates:
        path = os.path.join(stage_dir, name)
        if not os.path.exists(path):
            continue
        with open(path, "r", encoding="utf-8") as f:
            payload = json.load(f)
        return str(payload.get("status", "UNKNOWN"))
    return "UNKNOWN"


def _hydrate_stage_evidence_refs(stage: str, stage_dir: str, evidence_bundle: Dict) -> Dict:
    stage_path = Path(stage_dir)

    raw_refs = list(evidence_bundle.get("raw_refs") or [])
    normalized_refs = list(evidence_bundle.get("normalized_refs") or [])
    lineage_ref = evidence_bundle.get("lineage_ref")

    raw_candidates = {
        "h3_netgen": ["netgen.raw.log", "comp.out"],
    }.get(stage, [])
    normalized_candidates = {
        "h3_netgen": ["normalized.lvs.meta.json"],
    }.get(stage, [])

    if not raw_refs:
        for name in raw_candidates:
            path = stage_path / name
            if path.exists():
                raw_refs.append(path.as_posix())

    if not normalized_refs:
        for name in normalized_candidates:
            path = stage_path / name
            if path.exists():
                normalized_refs.append(path.as_posix())

    if not lineage_ref:
        lineage_path = stage_path / "lineage.json"
        if lineage_path.exists():
            lineage_ref = lineage_path.as_posix()

    evidence_bundle["raw_refs"] = raw_refs
    evidence_bundle["normalized_refs"] = normalized_refs
    if lineage_ref:
        evidence_bundle["lineage_ref"] = lineage_ref
    return evidence_bundle


def _augment_capability_contract_artifacts(run_dir: str, task_id: str) -> Dict[str, str]:
    stage_dirs = [
        "v1_verilator_lint",
        "v2_verilator_sim",
        "v3_cdc_rdc",
        "v4_yosys_lec",
        "h1_yosys",
        "h2_openroad",
        "h3_netgen",
        "h4_klayout",
    ]
    contract_refs: Dict[str, str] = {}
    for stage in stage_dirs:
        stage_dir = os.path.join(run_dir, stage)
        input_manifest_path = os.path.join(stage_dir, "input_manifest.json")
        evidence_bundle_path = os.path.join(stage_dir, "evidence_bundle.json")
        if not os.path.exists(input_manifest_path) or not os.path.exists(evidence_bundle_path):
            continue

        capability_id, profile_ref = _stage_contract_profile(stage)
        if not capability_id or not profile_ref:
            continue

        with open(input_manifest_path, "r", encoding="utf-8") as f:
            input_manifest = json.load(f)
        input_manifest["capability_id"] = capability_id
        input_manifest["capability_profile_ref"] = profile_ref
        input_manifest.setdefault("decision_context_ref", f"decision://{task_id}/formal-release")
        with open(input_manifest_path, "w", encoding="utf-8") as f:
            json.dump(input_manifest, f, indent=2)

        with open(evidence_bundle_path, "r", encoding="utf-8") as f:
            evidence_bundle = json.load(f)
        evidence_bundle = _hydrate_stage_evidence_refs(stage, stage_dir, evidence_bundle)

        capability_verdict = _normalized_status_for_stage(stage_dir)
        blocked_status = {"FAIL", "BLOCKED", "INVALID", "INTEGRITY_DRIFT"}
        blocking_reasons = [f"{stage}:{capability_verdict}"] if capability_verdict in blocked_status else []
        reentry_recommendation = "request_more_evidence" if blocking_reasons else None

        output_envelope = {
            "capability_id": capability_id,
            "capability_profile_ref": profile_ref,
            "capability_verdict": capability_verdict,
            "capability_blocking_reasons": blocking_reasons,
            "raw_artifact_refs": evidence_bundle.get("raw_refs", []),
            "normalized_output_ref": (evidence_bundle.get("normalized_refs") or [None])[0],
            "decision_package_ref": "subject_binding/decision_package.v0.1.json",
            "re_entry_recommendation": reentry_recommendation,
            "re_entry_record_ref": "subject_binding/re_entry_record.v0.1.json",
            "generated_at": get_tw_time().isoformat(),
        }
        output_envelope_path = os.path.join(stage_dir, "output_envelope.json")
        with open(output_envelope_path, "w", encoding="utf-8") as f:
            json.dump(output_envelope, f, indent=2)

        evidence_bundle["capability_id"] = capability_id
        evidence_bundle["capability_profile_ref"] = profile_ref
        evidence_bundle["output_envelope_ref"] = output_envelope_path
        with open(evidence_bundle_path, "w", encoding="utf-8") as f:
            json.dump(evidence_bundle, f, indent=2)

        lineage_path = os.path.join(stage_dir, "lineage.json")
        if os.path.exists(lineage_path):
            with open(lineage_path, "r", encoding="utf-8") as f:
                lineage = json.load(f)
            lineage["capability_id"] = capability_id
            lineage["capability_profile_ref"] = profile_ref
            with open(lineage_path, "w", encoding="utf-8") as f:
                json.dump(lineage, f, indent=2)

        contract_refs[stage] = output_envelope_path

    if contract_refs:
        index_path = os.path.join(run_dir, "subject_binding", "capability_contract_index.v0.1.json")
        os.makedirs(os.path.dirname(index_path), exist_ok=True)
        with open(index_path, "w", encoding="utf-8") as f:
            json.dump(
                {
                    "schema_version": "capability-contract-index.v0.1",
                    "run_dir": run_dir,
                    "output_envelope_refs": contract_refs,
                    "generated_at": get_tw_time().isoformat(),
                },
                f,
                indent=2,
            )
    return contract_refs


def _write_route_b_decision_package(run_dir: str, task_id: str) -> str:
    stage_dirs = [
        "v1_verilator_lint",
        "v2_verilator_sim",
        "v3_cdc_rdc",
        "v4_yosys_lec",
        "h1_yosys",
        "h2_openroad",
        "h3_netgen",
        "h4_klayout",
    ]
    evidence_refs: List[str] = []
    for stage in stage_dirs:
        bundle_path = os.path.join(run_dir, stage, "evidence_bundle.json")
        if not os.path.exists(bundle_path):
            continue
        with open(bundle_path, "r", encoding="utf-8") as f:
            bundle = json.load(f)
        lineage_ref = bundle.get("lineage_ref")
        if lineage_ref:
            evidence_refs.append(lineage_ref)
        output_envelope_ref = bundle.get("output_envelope_ref")
        if output_envelope_ref:
            evidence_refs.append(output_envelope_ref)

    payload = {
        "schema_version": "decision-package.v0.1",
        "decision_package_id": f"dp-{task_id}",
        "decision_context_ref": f"decision://{task_id}/formal-release",
        "candidate_decisions": [
            "approve",
            "approve_with_conditions",
            "request_more_evidence",
            "reject",
        ],
        "decision_state": "PRE_DECISION",
        "decision_outcome": None,
        "consumed_evidence_refs": [],
        "capability_evidence_refs": evidence_refs,
        "authority_required": True,
        "generated_at": get_tw_time().isoformat(),
    }
    out_path = os.path.join(run_dir, "subject_binding", "decision_package.v0.1.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)
    return out_path


def _write_route_b_reentry_record(run_dir: str, task_id: str) -> str:
    payload = {
        "schema_version": "re-entry-record.v0.1",
        "re_entry_id": f"re-{task_id}",
        "reentry_state": "NO_REENTRY",
        "trigger_type": None,
        "source_run_ref": run_dir,
        "source_decision_ref": None,
        "supersedes_ref": None,
        "carry_forward_issue_refs": [],
        "re_entry_scope": None,
        "generated_at": get_tw_time().isoformat(),
    }
    out_path = os.path.join(run_dir, "subject_binding", "re_entry_record.v0.1.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)
    return out_path


def _apply_route_b_decision_outcome(
    *,
    run_dir: str,
    decision_outcome: str,
    consumed_evidence_refs: List[str],
    decision_record_ref: str,
) -> str:
    decision_package_path = os.path.join(run_dir, "subject_binding", "decision_package.v0.1.json")
    if not os.path.exists(decision_package_path):
        raise RuntimeError("route_b_contract_invalid:missing_decision_package")

    with open(decision_package_path, "r", encoding="utf-8") as f:
        payload = json.load(f)

    candidate_decisions = payload.get("candidate_decisions") or []
    if decision_outcome not in candidate_decisions:
        raise RuntimeError("route_b_contract_invalid:decision_outcome_not_in_candidate_set")
    if not consumed_evidence_refs:
        raise RuntimeError("route_b_contract_invalid:decision_outcome_missing_consumed_evidence_refs")

    payload["decision_state"] = "DECIDED"
    payload["decision_outcome"] = decision_outcome
    payload["consumed_evidence_refs"] = consumed_evidence_refs
    payload["decision_record_ref"] = decision_record_ref
    payload["decided_at"] = get_tw_time().isoformat()

    with open(decision_package_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)
    return decision_package_path


def _apply_route_b_reentry_request(
    *,
    run_dir: str,
    trigger_type: str,
    source_decision_ref: str,
    supersedes_ref: str,
    carry_forward_issue_refs: List[str],
    re_entry_scope: Dict,
) -> str:
    reentry_path = os.path.join(run_dir, "subject_binding", "re_entry_record.v0.1.json")
    if not os.path.exists(reentry_path):
        raise RuntimeError("route_b_contract_invalid:missing_re_entry_record")

    if not supersedes_ref:
        raise RuntimeError("route_b_contract_invalid:re_entry_missing_supersedes_ref")
    if not carry_forward_issue_refs:
        raise RuntimeError("route_b_contract_invalid:re_entry_missing_carry_forward_issue_refs")

    with open(reentry_path, "r", encoding="utf-8") as f:
        payload = json.load(f)

    payload["reentry_state"] = "REENTRY_REQUESTED"
    payload["trigger_type"] = trigger_type
    payload["source_decision_ref"] = source_decision_ref
    payload["supersedes_ref"] = supersedes_ref
    payload["carry_forward_issue_refs"] = carry_forward_issue_refs
    payload["re_entry_scope"] = re_entry_scope
    payload["updated_at"] = get_tw_time().isoformat()

    with open(reentry_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)
    return reentry_path


def _enforce_route_b_contract_fail_closed(run_dir: str) -> None:
    stage_dirs = [
        "v1_verilator_lint",
        "v2_verilator_sim",
        "v3_cdc_rdc",
        "v4_yosys_lec",
        "h1_yosys",
        "h2_openroad",
        "h3_netgen",
        "h4_klayout",
    ]
    capability_reentry_required = False
    for stage in stage_dirs:
        stage_dir = os.path.join(run_dir, stage)
        input_manifest_path = os.path.join(stage_dir, "input_manifest.json")
        evidence_bundle_path = os.path.join(stage_dir, "evidence_bundle.json")
        output_envelope_path = os.path.join(stage_dir, "output_envelope.json")
        if not os.path.exists(input_manifest_path) or not os.path.exists(evidence_bundle_path):
            continue

        with open(input_manifest_path, "r", encoding="utf-8") as f:
            input_manifest = json.load(f)
        if not input_manifest.get("capability_id") or not input_manifest.get("capability_profile_ref"):
            raise RuntimeError("route_b_contract_invalid:missing_capability_envelope_fields")

        if not os.path.exists(output_envelope_path):
            raise RuntimeError("route_b_contract_invalid:missing_output_envelope")
        with open(output_envelope_path, "r", encoding="utf-8") as f:
            output_envelope = json.load(f)
        for required_field in (
            "capability_id",
            "capability_profile_ref",
            "capability_verdict",
            "capability_blocking_reasons",
            "raw_artifact_refs",
            "normalized_output_ref",
            "decision_package_ref",
            "re_entry_record_ref",
        ):
            if required_field not in output_envelope:
                raise RuntimeError(f"route_b_contract_invalid:output_envelope_missing_{required_field}")
        if output_envelope.get("re_entry_recommendation") == "request_more_evidence":
            capability_reentry_required = True
        if output_envelope.get("capability_blocking_reasons"):
            capability_reentry_required = True

        with open(evidence_bundle_path, "r", encoding="utf-8") as f:
            evidence_bundle = json.load(f)
        if not evidence_bundle.get("raw_refs") or not evidence_bundle.get("normalized_refs"):
            raise RuntimeError("route_b_contract_invalid:missing_raw_normalized_mapping")

    decision_package_path = os.path.join(run_dir, "subject_binding", "decision_package.v0.1.json")
    if not os.path.exists(decision_package_path):
        raise RuntimeError("route_b_contract_invalid:missing_decision_package")
    with open(decision_package_path, "r", encoding="utf-8") as f:
        dp = json.load(f)
    candidate_decisions = dp.get("candidate_decisions") or []
    decision_state = dp.get("decision_state", "PRE_DECISION")
    decision_outcome = dp.get("decision_outcome")

    if decision_outcome is not None and decision_outcome not in candidate_decisions:
        raise RuntimeError("route_b_contract_invalid:decision_outcome_not_in_candidate_set")
    if decision_state == "PRE_DECISION" and decision_outcome is not None:
        raise RuntimeError("route_b_contract_invalid:pre_decision_state_with_outcome")
    if decision_state != "PRE_DECISION" and not decision_outcome:
        raise RuntimeError("route_b_contract_invalid:decision_state_without_outcome")
    if decision_state != "PRE_DECISION" and not dp.get("consumed_evidence_refs"):
        raise RuntimeError("route_b_contract_invalid:decision_outcome_missing_consumed_evidence_refs")

    reentry_path = os.path.join(run_dir, "subject_binding", "re_entry_record.v0.1.json")
    if not os.path.exists(reentry_path):
        raise RuntimeError("route_b_contract_invalid:missing_re_entry_record")
    with open(reentry_path, "r", encoding="utf-8") as f:
        reentry = json.load(f)
    reentry_state = reentry.get("reentry_state", "NO_REENTRY")
    if decision_outcome == "request_more_evidence" and reentry_state == "NO_REENTRY":
        raise RuntimeError("route_b_contract_invalid:re_entry_required_for_request_more_evidence")
    if capability_reentry_required and reentry_state == "NO_REENTRY":
        raise RuntimeError("route_b_contract_invalid:re_entry_required_for_capability_blocked")
    if reentry_state != "NO_REENTRY":
        if not reentry.get("supersedes_ref"):
            raise RuntimeError("route_b_contract_invalid:re_entry_missing_supersedes_ref")
        carry_forward_issue_refs = reentry.get("carry_forward_issue_refs")
        if not isinstance(carry_forward_issue_refs, list) or not carry_forward_issue_refs:
            raise RuntimeError("route_b_contract_invalid:re_entry_missing_carry_forward_issue_refs")


def _write_production_intent_artifact(run_dir: str, chip_id: str, task_id: str):
    source_path = os.path.join("chips", chip_id, "production_intent.json")
    if not os.path.exists(source_path):
        return None

    out_dir = os.path.join(run_dir, "production_intent")
    os.makedirs(out_dir, exist_ok=True)
    copied_source = os.path.join(out_dir, "production_intent.source.json")
    shutil.copy2(source_path, copied_source)

    with open(copied_source, "r", encoding="utf-8") as f:
        source_data = json.load(f)

    ts = get_tw_time().isoformat()
    normalized = {
        "chip_id": chip_id,
        "task_id": task_id,
        "pad_ring": source_data.get("pad_ring", {}),
        "dft": source_data.get("dft", {}),
        "bringup": source_data.get("bringup", {}),
        "esd": source_data.get("esd", {}),
        "packaging_lab_notes": source_data.get("packaging_lab_notes", {}),
        "generated_at": ts,
    }
    normalized_path = os.path.join(out_dir, "normalized.production.meta.json")
    with open(normalized_path, "w", encoding="utf-8") as f:
        json.dump(normalized, f, indent=2)

    input_manifest = {
        "chip_id": chip_id,
        "task_id": task_id,
        "source_ref": source_path,
        "copied_source_ref": copied_source,
        "generated_at": ts,
    }
    input_manifest_path = os.path.join(out_dir, "input_manifest.json")
    with open(input_manifest_path, "w", encoding="utf-8") as f:
        json.dump(input_manifest, f, indent=2)

    lineage = {
        "run_id": f"production-intent-{chip_id}-{task_id}",
        "chip_id": chip_id,
        "task_id": task_id,
        "working_dir": os.path.abspath(run_dir),
        "input_manifest_ref": input_manifest_path,
        "output_refs": [copied_source, normalized_path],
        "generated_at": ts,
    }
    lineage_path = os.path.join(out_dir, "lineage.json")
    with open(lineage_path, "w", encoding="utf-8") as f:
        json.dump(lineage, f, indent=2)

    evidence_bundle = {
        "lineage_ref": lineage_path,
        "normalized_refs": [normalized_path],
        "raw_refs": [copied_source],
        "digests": {
            "source_sha256": _sha256_file(copied_source),
            "normalized_sha256": _sha256_file(normalized_path),
            "input_manifest_sha256": _sha256_file(input_manifest_path),
            "lineage_sha256": _sha256_file(lineage_path),
        },
        "generated_at": ts,
    }
    evidence_bundle_path = os.path.join(out_dir, "evidence_bundle.json")
    with open(evidence_bundle_path, "w", encoding="utf-8") as f:
        json.dump(evidence_bundle, f, indent=2)

    print(f"  ✅ [production_intent] artifact written from {source_path}")
    return out_dir


def _augment_production_intent_with_runtime_observations(run_dir: str):
    prod_path = os.path.join(run_dir, "production_intent", "normalized.production.meta.json")
    if not os.path.exists(prod_path):
        return

    with open(prod_path, "r", encoding="utf-8") as f:
        prod = json.load(f)

    h1_netlist_path = os.path.join(run_dir, "h1_yosys", "top.synth.v")
    h2_def_path = os.path.join(run_dir, "h2_openroad", "top.def")

    h1_text = ""
    if os.path.exists(h1_netlist_path):
        with open(h1_netlist_path, "r", encoding="utf-8", errors="ignore") as f:
            h1_text = f.read()
    h2_text = ""
    if os.path.exists(h2_def_path):
        with open(h2_def_path, "r", encoding="utf-8", errors="ignore") as f:
            h2_text = f.read()

    scan_markers = re.findall(r"\b(scan_(?:in|out|en|enable)|test_mode|mbist)\b", h1_text, flags=re.IGNORECASE)
    pad_markers = re.findall(r"\b(?:pad|gpio|vccd|vssd|io_)[A-Za-z0-9_]*\b", h2_text, flags=re.IGNORECASE)
    esd_markers = re.findall(r"\b(?:esd|clamp|diode)[A-Za-z0-9_]*\b", h2_text, flags=re.IGNORECASE)

    chip_id = prod.get("chip_id")
    doc_records = []
    if chip_id:
        chip_dir = os.path.join("chips", chip_id)
        if os.path.isdir(chip_dir):
            for root, _, files in os.walk(chip_dir):
                for fn in files:
                    lower = fn.lower()
                    if not (lower.endswith(".md") or lower.endswith(".txt")):
                        continue
                    abs_path = os.path.join(root, fn)
                    rel_path = os.path.relpath(abs_path, os.getcwd())
                    try:
                        with open(abs_path, "r", encoding="utf-8", errors="ignore") as fh:
                            content = fh.read().lower()
                    except OSError:
                        content = ""
                    doc_records.append({"ref": rel_path, "name": lower, "content": content})

    bringup_docs = [
        d["ref"] for d in doc_records
        if ("bringup" in d["name"]) or ("bringup" in d["content"])
    ]
    dft_docs = [
        d["ref"] for d in doc_records
        if any(tok in d["name"] or tok in d["content"] for tok in ("dft", "scan"))
    ]
    esd_docs = [
        d["ref"] for d in doc_records
        if "esd" in d["name"] or "esd" in d["content"]
    ]
    pad_docs = [
        d["ref"] for d in doc_records
        if any(tok in d["name"] or tok in d["content"] for tok in ("pad", "io ring", "padring"))
    ]

    prod.setdefault("dft", {})
    prod["dft"]["runtime_observation"] = {
        "scan_marker_count": len(scan_markers),
        "scan_markers_sample": sorted(set(scan_markers))[:20],
        "probe_source_ref": "h1_yosys/top.synth.v",
        "dft_doc_count": len(dft_docs),
        "dft_doc_refs": dft_docs[:20],
    }
    prod.setdefault("pad_ring", {})
    prod["pad_ring"]["runtime_observation"] = {
        "pad_marker_count_in_def": len(pad_markers),
        "pad_markers_sample": sorted(set(pad_markers))[:20],
        "probe_source_ref": "h2_openroad/top.def",
        "pad_doc_count": len(pad_docs),
        "pad_doc_refs": pad_docs[:20],
    }
    prod.setdefault("esd", {})
    prod["esd"]["runtime_observation"] = {
        "esd_marker_count_in_def": len(esd_markers),
        "esd_markers_sample": sorted(set(esd_markers))[:20],
        "probe_source_ref": "h2_openroad/top.def",
        "esd_doc_count": len(esd_docs),
        "esd_doc_refs": esd_docs[:20],
    }
    prod.setdefault("bringup", {})
    prod["bringup"]["runtime_observation"] = {
        "bringup_doc_count": len(bringup_docs),
        "bringup_doc_refs": bringup_docs[:20],
        "probe_scope": f"chips/{chip_id}" if chip_id else "chips/<unknown>",
    }
    prod["runtime_observation_generated_at"] = get_tw_time().isoformat()

    with open(prod_path, "w", encoding="utf-8") as f:
        json.dump(prod, f, indent=2)


def _write_timing_exception_review_artifact(run_dir: str):
    h2_dir = os.path.join(run_dir, "h2_openroad")
    if not os.path.isdir(h2_dir):
        return None

    cdc_meta = {}
    cdc_path = os.path.join(run_dir, "v3_cdc_rdc", "normalized.cdc.meta.json")
    if os.path.exists(cdc_path):
        with open(cdc_path, "r", encoding="utf-8") as f:
            cdc_meta = json.load(f)

    clock_domains = cdc_meta.get("clock_domain_count")
    if clock_domains is not None and int(clock_domains) <= 1:
        status = "DONE"
        review_result = "no_exceptions_required_for_single_clock_scope"
        notes = "Single-clock bounded review found no false-path or multicycle exception requirement."
    else:
        status = "PARTIAL"
        review_result = "multi_clock_exception_review_required"
        notes = "Multi-clock structure requires explicit false-path/multicycle review before stronger timing closure."

    review = {
        "status": status,
        "review_scope": "bounded_sdc_exception_review",
        "clock_domain_count": clock_domains,
        "false_path_count": 0,
        "multicycle_path_count": 0,
        "review_result": review_result,
        "notes": notes,
        "generated_at": get_tw_time().isoformat(),
    }
    out_path = os.path.join(h2_dir, "timing_exception_review.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(review, f, indent=2)
    return out_path


def _write_rdc_review_artifact(run_dir: str):
    v3_dir = os.path.join(run_dir, "v3_cdc_rdc")
    rdc_path = os.path.join(v3_dir, "normalized.rdc.meta.json")
    if not os.path.exists(rdc_path):
        return None

    with open(rdc_path, "r", encoding="utf-8") as f:
        rdc_meta = json.load(f)

    reset_domains = int(rdc_meta.get("reset_domain_count") or 0)
    async_reset_blocks = int(rdc_meta.get("async_reset_blocks") or 0)
    if reset_domains == 1:
        status = "DONE"
        review_result = "accepted_for_bounded_digital_readiness"
        notes = (
            "Single reset net reviewed; async assertion pattern accepted for bounded digital readiness. "
            "Dedicated RDC signoff remains required for stronger claims."
        )
    elif reset_domains == 0 and async_reset_blocks == 0:
        status = "DONE"
        review_result = "no_reset_domain_crossing_detected"
        notes = "No reset-domain crossing structure detected by bounded RTL structural review."
    else:
        status = "PARTIAL"
        review_result = "multi_reset_review_required"
        notes = "Multiple reset domains require explicit reset release/sequencing review before closure."

    review = {
        "status": status,
        "review_scope": "bounded_rdc_structural_review",
        "reset_domain_count": reset_domains,
        "async_reset_blocks": async_reset_blocks,
        "review_result": review_result,
        "notes": notes,
        "generated_at": get_tw_time().isoformat(),
    }
    out_path = os.path.join(v3_dir, "normalized.rdc_review.meta.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(review, f, indent=2)
    return out_path


def _resolve_sim_testbench(chip_id: str, inputs_rtl_dir: str):
    if chip_id == "test-chip-02":
        return {
            "testbench_path": os.path.join(inputs_rtl_dir, "top_tb.v"),
            "testbench_top": "top_tb",
            "top_module": "top",
        }
    if chip_id == "uart-controller-v0.1":
        return {
            "testbench_path": os.path.join(inputs_rtl_dir, "UART_Top_tb.v"),
            "testbench_top": "UART_Top_tb",
            "top_module": "UART_Top",
        }
    if chip_id == "async-fifo-v0.1":
        return {
            "testbench_path": os.path.join(inputs_rtl_dir, "testbench.sv"),
            "testbench_top": "asynchronous_fifo_tb",
            "top_module": "asynchronous_fifo",
        }
    return None


# ─────────────────────────────────────────────────────────────────────────────
# Main pipeline runner
# ─────────────────────────────────────────────────────────────────────────────

def run_governed_pipeline(
    chip_id: str,
    task_id: str,
    rtl_src: str,
    chip_name: str,
    rtl_function: str,
    technology_context: str = "SKY130 / OpenLane baseline",
    baseline_tools: List[str] = None,
    kickoff_mode: str = "rtl_compat",
):
    if baseline_tools is None:
        baseline_tools = ["yosys", "openroad", "netgen", "klayout"]

    ts = get_tw_time().strftime("%Y%m%d-%H%M%S")
    run_dir = os.path.abspath(
        os.path.join("artifacts", "production-runs", chip_id, task_id, ts)
    )
    os.makedirs(run_dir, exist_ok=True)

    print(f"\n[Pipeline] chip_id={chip_id}  task_id={task_id}")
    print(f"[Pipeline] run_dir={run_dir}")

    # A. Capture v1.0 upstream inputs
    inputs_rtl_dir = _capture_v10_upstream_inputs(
        run_dir=run_dir,
        chip_id=chip_id,
        rtl_src=rtl_src,
        kickoff_mode=kickoff_mode,
    )

    # B. Write Addendum Phase 1 subject_binding fixtures
    _write_subject_binding_fixtures(
        run_dir, chip_id, task_id, chip_name, rtl_function,
        technology_context, baseline_tools
    )
    _write_production_intent_artifact(run_dir, chip_id, task_id)
    _enforce_v10_downstream_admission(chip_id)
    toolchain_resolution = resolve_toolchain_profile()
    _fail_closed_on_environment_adjudication(toolchain_resolution)
    write_toolchain_resolution_artifact(run_dir, toolchain_resolution)


    assembly_log = []
    # C.1 V1: Verilator Lint (REAL Execution)
    
    verilator_bin = toolchain_resolution["binaries"]["verilator"]["path"]
    lint_req = VerilatorLintMcpCapabilityRequest(
        workspace_id=f"ws-{chip_id}",
        chip_id=chip_id,
        task_id=task_id,
        decision_context_ref=f"decision://{task_id}/formal-release",
        contract_name="verilator_lint_contract",
        contract_version="v0.1",
        rtl_path=inputs_rtl_dir,
        top_module="top" if chip_id == "test-chip-02" else ("UART_Top" if "uart" in chip_id else "asynchronous_fifo"),
        output_root=os.path.join(run_dir, "v1_verilator_lint"),
        verilator_bin=verilator_bin,
    )
    lint_boundary = VerilatorLintMcpCapabilityBoundary()
    lint_resp = lint_boundary.execute(lint_req)
    
    # Extract inner run_dir
    v1_out = os.path.join(run_dir, "v1_verilator_lint")
    inner_dirs = [d for d in os.listdir(v1_out) if os.path.isdir(os.path.join(v1_out, d))]
    if inner_dirs:
        # flatten it
        inner = os.path.join(v1_out, inner_dirs[0])
        for f in os.listdir(inner):
            shutil.move(os.path.join(inner, f), v1_out)
        os.rmdir(inner)

    assembly_log.append({
        "stage": "v1_verilator_lint",
        "output_dir": v1_out,
        "status": "PASS" if lint_resp.disposition == Disposition.PASS else "WARN" if lint_resp.warning_count > 0 else "FAIL",
        "warning_count": lint_resp.warning_count,
        "error_count": lint_resp.error_count,
    })

    sim_cfg = _resolve_sim_testbench(chip_id, inputs_rtl_dir)
    if sim_cfg and os.path.exists(sim_cfg["testbench_path"]):
        sim_req = VerilatorSimMcpCapabilityRequest(
            workspace_id=f"ws-{chip_id}",
            chip_id=chip_id,
            task_id=task_id,
            decision_context_ref=f"decision://{task_id}/formal-release",
            contract_name="verilator_sim_contract",
            contract_version="v0.1",
            rtl_path=inputs_rtl_dir,
            top_module=sim_cfg["top_module"],
            testbench_path=sim_cfg["testbench_path"],
            testbench_top=sim_cfg["testbench_top"],
            output_root=os.path.join(run_dir, "v2_verilator_sim"),
            verilator_bin=verilator_bin,
        )
        sim_boundary = VerilatorSimMcpCapabilityBoundary()
        sim_resp = sim_boundary.execute(sim_req)

        v2_out = os.path.join(run_dir, "v2_verilator_sim")
        inner_dirs = [d for d in os.listdir(v2_out) if os.path.isdir(os.path.join(v2_out, d))]
        if inner_dirs:
            inner = os.path.join(v2_out, inner_dirs[0])
            for f in os.listdir(inner):
                shutil.move(os.path.join(inner, f), v2_out)
            os.rmdir(inner)

        sim_meta_path = os.path.join(v2_out, "normalized.sim.meta.json")
        sim_meta = None
        if os.path.exists(sim_meta_path):
            with open(sim_meta_path, "r", encoding="utf-8") as f:
                sim_meta = json.load(f)
        assembly_log.append({
            "stage": "v2_verilator_sim",
            "output_dir": v2_out,
            "status": (sim_meta or {}).get("status", "FAIL" if sim_resp.disposition != Disposition.PASS else "UNKNOWN"),
            "warning_count": (sim_meta or {}).get("warning_count", 0),
            "error_count": (sim_meta or {}).get("error_count", 0),
            "detail": sim_resp.reason,
        })
    else:
        assembly_log.append({
            "stage": "v2_verilator_sim",
            "output_dir": os.path.join(run_dir, "v2_verilator_sim"),
            "status": "SKIPPED",
            "detail": "skipped: no chip-scoped testbench available",
        })

    cdc_req = CdcRdcAnalysisRequest(
        workspace_id=f"ws-{chip_id}",
        chip_id=chip_id,
        task_id=task_id,
        decision_context_ref=f"decision://{task_id}/formal-release",
        contract_name="cdc_rdc_structural_contract",
        contract_version="v0.1",
        rtl_path=inputs_rtl_dir,
        top_module="top" if chip_id == "test-chip-02" else ("UART_Top" if "uart" in chip_id else "asynchronous_fifo"),
        output_root=os.path.join(run_dir, "v3_cdc_rdc"),
    )
    cdc_boundary = CdcRdcAnalysisCapabilityBoundary()
    cdc_resp = cdc_boundary.execute(cdc_req)
    v3_out = os.path.join(run_dir, "v3_cdc_rdc")
    if os.path.isdir(v3_out):
        inner_dirs = [d for d in os.listdir(v3_out) if os.path.isdir(os.path.join(v3_out, d))]
        if inner_dirs:
            inner = os.path.join(v3_out, inner_dirs[0])
            for f in os.listdir(inner):
                shutil.move(os.path.join(inner, f), v3_out)
            os.rmdir(inner)
    cdc_meta = None
    rdc_meta = None
    cdc_meta_path = os.path.join(v3_out, "normalized.cdc.meta.json")
    rdc_meta_path = os.path.join(v3_out, "normalized.rdc.meta.json")
    if os.path.exists(cdc_meta_path):
        with open(cdc_meta_path, "r", encoding="utf-8") as f:
            cdc_meta = json.load(f)
    if os.path.exists(rdc_meta_path):
        with open(rdc_meta_path, "r", encoding="utf-8") as f:
            rdc_meta = json.load(f)
    rdc_review_ref = _write_rdc_review_artifact(run_dir)
    assembly_log.append({
        "stage": "v3_cdc_rdc",
        "output_dir": v3_out,
        "status": "PASS" if cdc_resp.disposition == Disposition.PASS else "FAIL",
        "cdc_status": (cdc_meta or {}).get("status"),
        "rdc_status": (rdc_meta or {}).get("status"),
        "rdc_review_ref": rdc_review_ref,
        "detail": cdc_resp.reason,
    })

    # C.2 Real EDA Flow: H1(Yosys) → H2(OpenROAD) → H4(KLayout) → H3(Netgen)
    # Replaces the old artifact/v0.9 copy approach (which caused INTEGRITY_DRIFT for test-chip-02).
    # Tool binary paths (validated present on this machine):
    #   H1 Yosys:    /usr/local/bin/yosys  (Homebrew)
    #   H2 OpenROAD: /Users/imac/eda/openroad-cxx17/build-clang/bin/openroad
    #   H3 Netgen:   /Users/imac/eda/netgen-install/bin/netgen
    #   H4 KLayout:  real H4 realization from H2 layout artifacts (DEF/GDS)
    print("  [C.2] Running real EDA flow: H1→H2→H4→H3...")
    top_module = ("top" if chip_id == "test-chip-02"
                  else ("UART_Top" if "uart" in chip_id
                        else "asynchronous_fifo"))
    from run_real_eda import run_real_eda as _run_real_eda
    h_stage_log = _run_real_eda(
        run_dir,
        chip_id,
        task_id,
        inputs_rtl_dir,
        top_module,
        workspace_id=f"ws-{chip_id}",
        toolchain_resolution=toolchain_resolution,
    )

    # Flatten each H-stage nested sub-directory so generate_readiness_report.py
    # can locate normalized files directly at e.g. h1_yosys/normalized.netlist.meta.json
    for _stage in ("h1_yosys", "h2_openroad", "h4_klayout", "h3_netgen"):
        _stage_dir = os.path.join(run_dir, _stage)
        if not os.path.isdir(_stage_dir):
            continue
        _inner_dirs = [
            d for d in os.listdir(_stage_dir)
            if os.path.isdir(os.path.join(_stage_dir, d))
        ]
        if _inner_dirs:
            _inner = os.path.join(_stage_dir, _inner_dirs[0])
            for _f in os.listdir(_inner):
                _dst = os.path.join(_stage_dir, _f)
                if not os.path.exists(_dst):
                    shutil.move(os.path.join(_inner, _f), _stage_dir)
            try:
                os.rmdir(_inner)
            except OSError:
                pass  # inner dir not empty (has sub-dirs); leave remainder
        print(f"  ✅ [{_stage}] Flattened to run_dir")

    assembly_log.extend(h_stage_log)
    _augment_production_intent_with_runtime_observations(run_dir)
    timing_review_ref = _write_timing_exception_review_artifact(run_dir)
    if timing_review_ref:
        assembly_log.append({
            "stage": "timing_exception_review",
            "output_dir": os.path.dirname(timing_review_ref),
            "status": "DONE",
            "review_ref": timing_review_ref,
            "detail": "bounded timing exception review artifact emitted",
        })

    # C.3 Route-B B0 capability contract materialization and fail-closed checks
    contract_refs = _augment_capability_contract_artifacts(run_dir, task_id)
    decision_package_ref = _write_route_b_decision_package(run_dir, task_id)
    reentry_record_ref = _write_route_b_reentry_record(run_dir, task_id)
    _enforce_route_b_contract_fail_closed(run_dir)
    assembly_log.append({
        "stage": "route_b_b0_contract_materialization",
        "output_dir": os.path.join(run_dir, "subject_binding"),
        "status": "DONE",
        "detail": "capability envelope + decision package + re-entry record materialized and fail-closed validated",
        "contract_ref_count": len(contract_refs),
        "decision_package_ref": decision_package_ref,
        "reentry_record_ref": reentry_record_ref,
    })

    # Write pipeline assembly log
    log_path = os.path.join(run_dir, "pipeline_assembly_log.json")
    with open(log_path, "w") as f:
        json.dump({
            "chip_id":       chip_id,
            "task_id":       task_id,
            "run_dir":       run_dir,
            "assembled_at":  get_tw_time().isoformat(),
            "assembly_log":  assembly_log,
            "integrity_drift_count": sum(
                1 for r in assembly_log if r.get("status") == "INTEGRITY_DRIFT"
            ),
        }, f, indent=2)
    print(f"  ✅ [pipeline] Assembly log written: {log_path}")

    # D. Generate v0.2 readiness report
    print(f"  [report] Generating v0.2 readiness report...")
    from generate_readiness_report import compile_report
    rc = compile_report(run_dir)
    if rc == 0:
        print(f"  ✅ [report] v0.2 report generated (all gates passed)")
    elif rc == 1:
        print(f"  ⚠️  [report] v0.2 report generated (gate failures detected — see generation_log)")
    else:
        print(f"  ❌ [report] v0.2 report generation FAILED (fatal input error)")

    print(f"[Pipeline] ✅ Done: {chip_name} → {run_dir}\n")
    return run_dir


# ─────────────────────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    chips = [
        {
            "chip_id":   "test-chip-02",
            "task_id":   "T-SN2025-01",
            "rtl_src":   _template_path("baseline-digital-soc", "rtl"),
            "chip_name": "SN2025",
            "rtl_function": "Digital Controller",
        },
        {
            "chip_id":   "uart-controller-v0.1",
            "task_id":   "T-UART-001",
            "rtl_src":   _template_path("UART Protocol"),
            "chip_name": "UART Controller",
            "rtl_function": "Universal Asynchronous Receiver-Transmitter (Full-Duplex Transceiver)",
        },
        {
            "chip_id":   "async-fifo-v0.1",
            "task_id":   "T-FIFO-001",
            "rtl_src":   _template_path("Asynchronous FIFO"),
            "chip_name": "Async FIFO",
            "rtl_function": "Dual-Clock Memory FIFO",
        },
    ]
    for c in chips:
        run_governed_pipeline(**c)
