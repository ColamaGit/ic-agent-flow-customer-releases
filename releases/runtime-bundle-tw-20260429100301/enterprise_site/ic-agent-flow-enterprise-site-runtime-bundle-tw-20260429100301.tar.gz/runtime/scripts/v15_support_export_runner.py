#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from ic_agent_flow.domain.objects.deployment_packaging_objects import (
    ExportClass,
    RedactionLevel,
    SignatureBlock,
    KeyLifecycle,
    VerifierAuthority,
)
from ic_agent_flow.governance.customer_support_export import (
    SupportBundleBuilder,
    SupportBundleRequest,
    SupportExportAuditor,
    SupportExportClassifier,
    SupportRedactionPolicy,
)


def _signature_factory() -> SignatureBlock:
    return SignatureBlock(
        key_id="key-v15-support",
        algorithm="ed25519",
        trust_root_ref="trust-root://customer-a",
        verifier_authority=VerifierAuthority.SECURITY,
        key_lifecycle=KeyLifecycle.ACTIVE,
    )


def run_support_export(
    *,
    incident_id: str,
    time_window: str,
    included_logs: list[str],
    export_reason: str,
    customer_approval_ref: str,
    requested_by: str,
    exported_to: str,
    allowlist: list[str],
    denylist: list[str],
    redaction_level: str,
    export_class: str,
    audit_log_path: Path,
    output_path: Path,
) -> dict[str, Any]:
    
    redaction = RedactionLevel(redaction_level)
    export_cls = ExportClass(export_class)
    
    redaction_policy = SupportRedactionPolicy(level=redaction)
    classifier = SupportExportClassifier(allowlist=allowlist, denylist=denylist, default_export_class=export_cls)
    auditor = SupportExportAuditor(audit_log_path=str(audit_log_path))
    builder = SupportBundleBuilder(
        classifier=classifier,
        redaction_policy=redaction_policy,
        auditor=auditor,
        signature_factory=_signature_factory,
    )
    
    request = SupportBundleRequest(
        incident_id=incident_id,
        time_window=time_window,
        included_logs=included_logs,
        export_reason=export_reason,
        customer_approval_ref=customer_approval_ref,
        requested_by=requested_by,
        exported_to=exported_to,
    )
    
    try:
        bundle = builder.build_bundle(request)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(json.dumps(bundle.model_dump(mode="json"), indent=2), encoding="utf-8")
        
        # Write audit logs
        audit_log_path.parent.mkdir(parents=True, exist_ok=True)
        audit_log_path.write_text(json.dumps(auditor._records, indent=2), encoding="utf-8")
        
        return {"status": "SUCCESS", "bundle_path": str(output_path), "audit_path": str(audit_log_path)}
    except ValueError as e:
        audit_log_path.parent.mkdir(parents=True, exist_ok=True)
        audit_log_path.write_text(json.dumps(auditor._records, indent=2), encoding="utf-8")
        return {"status": "FAILED", "reason": str(e), "audit_path": str(audit_log_path)}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--incident-id", required=True)
    parser.add_argument("--time-window", required=True)
    parser.add_argument("--included-logs", required=True, help="Comma-separated list of logs")
    parser.add_argument("--export-reason", required=True)
    parser.add_argument("--customer-approval-ref", required=True)
    parser.add_argument("--requested-by", required=True)
    parser.add_argument("--exported-to", required=True)
    parser.add_argument("--allowlist", default="", help="Comma-separated allowlist")
    parser.add_argument("--denylist", default="", help="Comma-separated denylist")
    parser.add_argument("--redaction-level", required=True, choices=[r.value for r in RedactionLevel])
    parser.add_argument("--export-class", required=True, choices=[e.value for e in ExportClass])
    parser.add_argument("--audit-log-path", required=True)
    parser.add_argument("--output-path", required=True)
    
    args = parser.parse_args(argv)
    
    result = run_support_export(
        incident_id=args.incident_id,
        time_window=args.time_window,
        included_logs=args.included_logs.split(",") if args.included_logs else [],
        export_reason=args.export_reason,
        customer_approval_ref=args.customer_approval_ref,
        requested_by=args.requested_by,
        exported_to=args.exported_to,
        allowlist=args.allowlist.split(",") if args.allowlist else [],
        denylist=args.denylist.split(",") if args.denylist else [],
        redaction_level=args.redaction_level,
        export_class=args.export_class,
        audit_log_path=Path(args.audit_log_path),
        output_path=Path(args.output_path),
    )
    
    print(json.dumps(result, indent=2))
    return 0 if result["status"] == "SUCCESS" else 1


if __name__ == "__main__":
    sys.exit(main())
