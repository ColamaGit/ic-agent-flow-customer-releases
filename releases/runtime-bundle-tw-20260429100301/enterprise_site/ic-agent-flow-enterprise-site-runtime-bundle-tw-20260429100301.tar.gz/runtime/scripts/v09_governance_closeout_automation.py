#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

# Allow direct execution from repo root without manual PYTHONPATH export.
THIS_FILE = Path(__file__).resolve()
LIB_DIR = THIS_FILE.parents[1] / "lib"
if str(LIB_DIR) not in sys.path:
    sys.path.insert(0, str(LIB_DIR))

from ic_agent_flow.governance.eda_execution_gateway import EDAExecutionGateway
from ic_agent_flow.governance.h1_freeze_integrity import (
    validate_h1_freeze_integrity,
    write_h1_freeze_integrity_report,
)
from ic_agent_flow.governance.mcp_capability_e2e import (
    NetgenExecutionSpec,
    NetgenSingleCapValidator,
    OpenroadExecutionSpec,
    OpenroadSingleCapValidator,
    OpenSourceEDAMinimalE2EFlow,
    YosysExecutionSpec,
    YosysSingleCapValidator,
    build_h2_prep_artifacts,
)
from ic_agent_flow.governance.v09_closeout_index import (
    build_closeout_evidence_index,
    write_closeout_evidence_index,
)
from ic_agent_flow.governance.v09_phase_gate_convergence import (
    build_phase_gate_convergence_report,
    write_phase_gate_convergence_report,
)
from ic_agent_flow.registry.capability_registry import CapabilityRegistry
from ic_agent_flow.registry.scenario_registry import CanonicalCommandRegistry, Disposition


DEFAULT_CLOSEOUT_DIR = Path("workspace/docs/governance/closeout/v0.9")
DEFAULT_REGISTRY_PATH = DEFAULT_CLOSEOUT_DIR / "canonical_command_registry.v0.1.json"
DEFAULT_H1_FREEZE_NOTE = DEFAULT_CLOSEOUT_DIR / "h1_freeze_note.v0.1.md"
DEFAULT_TEMPLATES_ROOT = Path(os.environ.get("IC_AGENT_FLOW_TEMPLATES_ROOT", "templates"))


def run_single_capability_e2e(closeout_dir: Path) -> None:
    flow = OpenSourceEDAMinimalE2EFlow(gateway=EDAExecutionGateway(), registry=CapabilityRegistry())
    result = flow.execute_real_yosys_single_cap(
        YosysExecutionSpec(
            workspace_id="ws-v09",
            chip_id="chip-v09",
            task_id="task://single-cap-e2e",
            decision_context_ref="decision://ctx-single-cap-e2e",
            contract_name="yosys_synth_contract",
            contract_version="v0.1",
            rtl_path=(DEFAULT_TEMPLATES_ROOT / "baseline-digital-soc" / "rtl" / "top.v").as_posix(),
            top_module="top",
            output_root="artifacts/v0.9/yosys",
            run_key="yosys-h1-canonical",
        )
    )
    verdict = YosysSingleCapValidator().validate(result)

    validator_path = closeout_dir / "mcp_capability_single_e2e_validator.v0.2.json"
    validator_path.write_text(
        json.dumps(
            {
                "ac_id": "AC4",
                "command_id": "CMD-H1-MCP-SINGLE-CAP-E2E",
                "validator": "runtime execution check + schema validator + traceability validator + replay-minimum validator",
                "subject": "yosys_synth_compile",
                "boundary_positioning": "formal_mcp_capability_boundary_local_mode",
                "boundary_mode": result.boundary_mode,
                "contract_id": result.contract_id,
                "tool_version": result.record.tool_version,
                "disposition": verdict.disposition.value,
                "reason": verdict.reason,
                "artifact_paths": {
                    "raw_log": result.raw_log_path,
                    "netlist": result.netlist_path,
                    "normalized_metadata": result.normalized_metadata_path,
                    "input_manifest": result.input_manifest_path,
                    "lineage": result.lineage_path,
                    "evidence_bundle": result.evidence_bundle_path,
                },
            },
            indent=2,
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )

    report_path = closeout_dir / "phase6_mcp_single_cap_e2e_report.v0.2.md"
    report_path.write_text(
        "\n".join(
            [
                "# Phase 6 MCP Single-Capability E2E Report",
                "",
                "- Command ID: `CMD-H1-MCP-SINGLE-CAP-E2E`",
                "- Capability: `yosys_synth_compile`",
                f"- Verdict: `{verdict.disposition.value}`",
                f"- Runtime Disposition: `{result.disposition.value}`",
                f"- Tool Version: `{result.record.tool_version or 'unknown'}`",
                "",
                "## Proven Boundary",
                "",
                "- Proven: formal yosys MCP capability boundary (local mode) with contract envelope and governed evidence chain.",
                "",
                "## Not Proven Yet",
                "",
                "- Not proven: remote/deployed MCP server transport and multi-node deployment boundary.",
                "",
                "## Evidence Artifacts",
                "",
                f"- `{validator_path.as_posix()}`",
                f"- `{result.raw_log_path}`",
                f"- `{result.netlist_path}`",
                f"- `{result.normalized_metadata_path}`",
                f"- `{result.input_manifest_path}`",
                f"- `{result.lineage_path}`",
                f"- `{result.evidence_bundle_path}`",
            ]
        )
        + "\n",
        encoding="utf-8",
    )


def generate_closeout_index(registry_path: Path, closeout_dir: Path) -> None:
    registry = CanonicalCommandRegistry.load_json(registry_path)
    index = build_closeout_evidence_index(registry)
    write_closeout_evidence_index(
        index=index,
        json_path=closeout_dir / "closeout_evidence_index.v0.1.json",
        markdown_path=closeout_dir / "closeout_evidence_index.v0.1.md",
    )


def run_phase_gate_convergence(registry_path: Path, closeout_dir: Path) -> None:
    report = build_phase_gate_convergence_report(registry_path)
    write_phase_gate_convergence_report(
        report=report,
        json_path=closeout_dir / "phase_gate_convergence_report.v0.1.json",
        markdown_path=closeout_dir / "phase_gate_convergence_report.v0.1.md",
    )


def run_h1_freeze_integrity(closeout_dir: Path) -> None:
    result = validate_h1_freeze_integrity(note_path=DEFAULT_H1_FREEZE_NOTE)
    write_h1_freeze_integrity_report(
        result=result,
        json_path=closeout_dir / "h1_freeze_integrity_report.v0.1.json",
        markdown_path=closeout_dir / "h1_freeze_integrity_report.v0.1.md",
    )


def run_h2_prep(closeout_dir: Path) -> None:
    build_h2_prep_artifacts(closeout_dir)


def run_h2_real_run(closeout_dir: Path, openroad_bin: str = "openroad") -> None:
    # Use H1 (Yosys) output as H2 (OpenROAD) input to form a real design chain.
    yosys_output_v = Path("artifacts/v0.9/yosys/yosys-h1-canonical/top.synth.v")
    sdc_path = DEFAULT_TEMPLATES_ROOT / "baseline-digital-soc" / "constraints" / "base.sdc"
    
    flow = OpenSourceEDAMinimalE2EFlow(gateway=EDAExecutionGateway(), registry=CapabilityRegistry())
    result = flow.execute_real_openroad_single_cap(
        OpenroadExecutionSpec(
            workspace_id="ws-v09",
            chip_id="chip-v09",
            task_id="task://h2-real-openroad",
            decision_context_ref="decision://ctx-h2-real-openroad",
            contract_name="openroad_drc_contract",
            contract_version="v0.1",
            netlist_v_path=yosys_output_v.as_posix() if yosys_output_v.exists() else None,
            sdc_path=sdc_path.as_posix() if sdc_path.exists() else None,
            output_root="artifacts/v0.9/openroad",
            openroad_bin=openroad_bin,
            run_key="openroad-h2-canonical",
        )
    )

    if result.disposition == Disposition.PASS:
        validator = OpenroadSingleCapValidator()
        verdict = validator.validate(result)
        
        report_path = closeout_dir / "phase6_mcp_single_cap_e2e_report.v0.2.md"
        report_path.write_text(
            f"# Phase 6 MCP Single-Capability E2E Report\n\n"
            f"- Command ID: `CMD-H2-MCP-MULTI-CAP-BATCH`\n"
            f"- Verdict: `{verdict.disposition.name}`\n"
            f"- Reason: `{verdict.reason}`\n"
            f"- Tool Version: `{result.record.tool_version}`\n\n"
            f"## Evidence Artifacts\n\n"
            f"- `{result.raw_log_path}`\n"
            f"- `{result.normalized_metadata_path}`\n",
            encoding="utf-8"
        )


def run_h3_real_run(closeout_dir: Path, netgen_bin: str = "netgen") -> None:
    # Use H1 (Yosys) output as both sources for H3 (Netgen) to perform a self-LVS check.
    yosys_output_v = Path("artifacts/v0.9/yosys/yosys-h1-canonical/top.synth.v")
    
    flow = OpenSourceEDAMinimalE2EFlow(gateway=EDAExecutionGateway(), registry=CapabilityRegistry())
    result = flow.execute_real_netgen_single_cap(
        NetgenExecutionSpec(
            workspace_id="ws-v09",
            chip_id="chip-v09",
            task_id="task://h3-real-netgen",
            decision_context_ref="decision://ctx-h3-real-netgen",
            contract_name="netgen_lvs_contract",
            contract_version="v0.1",
            source_a_path=yosys_output_v.as_posix() if yosys_output_v.exists() else "missing",
            source_a_top="top",
            source_b_path=yosys_output_v.as_posix() if yosys_output_v.exists() else "missing",
            source_b_top="top",
            output_root="artifacts/v0.9/netgen",
            netgen_bin=netgen_bin,
            run_key="netgen-h3-canonical",
        )
    )

    if result.disposition == Disposition.PASS:
        validator = NetgenSingleCapValidator()
        verdict = validator.validate(result)
        
        report_path = closeout_dir / "phase6_netgen_lvs_report.v0.1.md"
        report_path.write_text(
            f"# Phase 6 Netgen LVS Real-Run Report v0.1\n\n"
            f"- Command ID: `CMD-H3-NETGEN-LVS-E2E`\n"
            f"- Verdict: `{verdict.disposition.name}`\n"
            f"- Reason: `{verdict.reason}`\n"
            f"- Tool Version: `{result.record.tool_version}`\n\n"
            f"## Evidence Artifacts\n\n"
            f"- `{result.raw_log_path}`\n"
            f"- `{result.lvs_report_path}`\n"
            f"- `{result.normalized_metadata_path}`\n",
            encoding="utf-8"
        )

    if result.disposition == Disposition.PASS:
        verdict = OpenroadSingleCapValidator().validate(result)
        final_disposition = verdict.disposition
        final_reason = verdict.reason
    else:
        # Tool-not-ready path: do not overclaim, keep gate pending.
        final_disposition = Disposition.HOLD if "tool_missing" in result.reason else Disposition.FAIL_CLOSED
        final_reason = result.reason

    validator_path = closeout_dir / "mcp_h2_real_run_validator.v0.2.json"
    validator_path.write_text(
        json.dumps(
            {
                "ac_id": "AC4",
                "command_id": "CMD-H2-MCP-MULTI-CAP-BATCH",
                "validator": "OpenroadSingleCapValidator",
                "subject": "openroad_drc",
                "disposition": final_disposition.value,
                "reason": final_reason,
                "runtime_disposition": result.disposition.value,
                "boundary_mode": result.boundary_mode,
                "contract_id": result.contract_id,
                "tool_version": result.record.tool_version,
                "artifact_paths": {
                    "raw_log": result.raw_log_path,
                    "normalized_metadata": result.normalized_metadata_path,
                    "input_manifest": result.input_manifest_path,
                    "lineage": result.lineage_path,
                    "evidence_bundle": result.evidence_bundle_path,
                },
            },
            indent=2,
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )

    report_path = closeout_dir / "phase6_mcp_multi_cap_batch_real_run.v0.2.md"
    evidence_lines = [f"- `{validator_path.as_posix()}`"]
    for path in [
        result.raw_log_path,
        result.normalized_metadata_path,
        result.input_manifest_path,
        result.lineage_path,
        result.evidence_bundle_path,
    ]:
        if path:
            evidence_lines.append(f"- `{path}`")
        else:
            evidence_lines.append("- `unavailable (tool missing)`")

    report_path.write_text(
        "\n".join(
            [
                "# Phase 6 MCP Multi-Capability Batch Real-Run Report v0.2",
                "",
                "- Command ID: `CMD-H2-MCP-MULTI-CAP-BATCH`",
                "- Real-Run Scope: `openroad_drc`",
                f"- Verdict: `{final_disposition.value}`",
                f"- Runtime Disposition: `{result.disposition.value}`",
                f"- Reason: `{final_reason}`",
                "",
                "## Boundary Position",
                "",
                "- H2 real-run requires real OpenROAD execution evidence before closeout PASS.",
                "- If OpenROAD binary is missing, disposition remains HOLD.",
                "",
                "## Evidence Artifacts",
                "",
                *evidence_lines,
            ]
        )
        + "\n",
        encoding="utf-8",
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="v0.9 governance closeout automation")
    parser.add_argument(
        "--action",
        choices=("single-cap-e2e", "h2-prep", "h2-real-run", "h3-real-run", "index", "phase-gate", "freeze-integrity", "all"),
        default="all",
    )
    parser.add_argument(
        "--openroad-bin",
        default=os.environ.get("OPENROAD_BIN", "openroad"),
        help="OpenROAD executable name/path for h2-real-run (default: OPENROAD_BIN env or 'openroad')",
    )
    parser.add_argument(
        "--netgen-bin",
        default=os.environ.get("NETGEN_BIN", "netgen"),
        help="Netgen executable name/path for h3-real-run (default: NETGEN_BIN env or 'netgen')",
    )
    parser.add_argument("--registry-path", default=DEFAULT_REGISTRY_PATH.as_posix())
    parser.add_argument("--closeout-dir", default=DEFAULT_CLOSEOUT_DIR.as_posix())
    args = parser.parse_args()

    registry_path = Path(args.registry_path)
    closeout_dir = Path(args.closeout_dir)
    closeout_dir.mkdir(parents=True, exist_ok=True)

    if args.action in ("prep", "h2-prep", "all"):
        run_h2_prep(closeout_dir)
    if args.action in ("single-cap-e2e", "h1-real-run", "all"):
        run_single_capability_e2e(closeout_dir)
    if args.action in ("h2-real-run", "all"):
        run_h2_real_run(closeout_dir, openroad_bin=args.openroad_bin)
    if args.action in ("h3-real-run", "all"):
        run_h3_real_run(closeout_dir, netgen_bin=args.netgen_bin)
    if args.action in ("index", "all"):
        generate_closeout_index(registry_path=registry_path, closeout_dir=closeout_dir)
    if args.action in ("phase-gate", "all"):
        run_phase_gate_convergence(registry_path=registry_path, closeout_dir=closeout_dir)
    if args.action in ("freeze-integrity", "all"):
        run_h1_freeze_integrity(closeout_dir=closeout_dir)


if __name__ == "__main__":
    main()
