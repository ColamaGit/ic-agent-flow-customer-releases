import json
import os
from pathlib import Path
from src.ic_agent_flow.qa.auditors.governance_auditor import GovernanceAuditor
from src.ic_agent_flow.qa.auditors.evidence_auditor import EvidenceAuditor
from src.ic_agent_flow.qa.auditors.context_contract_auditor import ContextContractAuditor
from src.ic_agent_flow.qa.auditors.human_authority_auditor import HumanAuthorityAuditor
from src.ic_agent_flow.qa.auditors.security_tiering_auditor import SecurityTieringAuditor

class QABaselineRunner:
    """Master runner to execute all 5 QA Suites and generate the Baseline Report."""
    
    def __init__(self, workspace_root: str):
        self.root = Path(workspace_root)
        self.output_path = self.root / "artifacts" / "qa" / "qa_baseline_report.v0.1.json"
        
        # Initialize Auditors
        self.gov = GovernanceAuditor(workspace_root)
        self.evid = EvidenceAuditor(workspace_root)
        self.ctx = ContextContractAuditor(workspace_root)
        self.human = HumanAuthorityAuditor(workspace_root)
        self.sec = SecurityTieringAuditor(workspace_root)
        
    def run_baseline(self):
        print("=== Commencing Multi-Suite QA Baseline Run ===")
        
        report = {
            "version": "0.1",
            "timestamp": "2026-04-07T18:07:00+08:00",
            "suites": []
        }
        
        # Suite 1
        print("Running Suite 1: Governance...")
        report["suites"].append({
            "name": "Suite 1: Governance QA",
            "results": [
                self.gov.audit_registry_integrity(),
                self.gov.audit_drift_response()
            ]
        })
        
        # Discovery: Find all bundles in closeouts/
        closeouts_path = self.root / "artifacts" / "closeouts"
        bundle_files = list(closeouts_path.glob("bundle_*.json"))
        bundle_ids = [f.name.replace("bundle_", "").replace(".json", "") for f in bundle_files]
        
        print(f"Discovered {len(bundle_ids)} bundles for auditing.")
        
        # Suite 1
        print("Running Suite 1: Governance...")
        report["suites"].append({
            "name": "Suite 1: Governance QA",
            "results": [
                self.gov.audit_registry_integrity(),
                self.gov.audit_drift_response()
            ]
        })
        
        # Loop through discovered bundles for other suites
        suite_2_results = []
        suite_3_results = []
        suite_4_results = []
        suite_5_results = []
        
        for bid in bundle_ids:
            suite_2_results.append(self.evid.audit_bundle_integrity(bid))
            suite_3_results.append(self.ctx.audit_context_integrity(bid))
            suite_4_results.append(self.human.audit_review_package(bid))
            suite_5_results.append(self.sec.audit_tier_boundary(bid))
            
        print("Finalizing Suite 2-5 Results...")
        report["suites"].append({"name": "Suite 2: Evidence QA", "results": suite_2_results})
        report["suites"].append({"name": "Suite 3: Context & Contract QA", "results": suite_3_results})
        report["suites"].append({"name": "Suite 4: Human Authority QA", "results": suite_4_results})
        report["suites"].append({"name": "Suite 5: Security & Tiering QA", "results": suite_5_results})
        
        print(f"Baseline complete. Saving to {self.output_path}")
        with open(self.output_path, 'w') as f:
            json.dump(report, f, indent=2)
            
        return report

if __name__ == "__main__":
    runner = QABaselineRunner(".")
    runner.run_baseline()
