#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

from ic_agent_flow.governance.vendor_ip_leak_scanner import VendorIPLeakScanner


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bundle-ref", required=True)
    parser.add_argument("--asset-text", action="append", default=[])
    parser.add_argument("--emit", required=True)
    args = parser.parse_args(argv)

    assets = {f"asset-{index}.txt": text for index, text in enumerate(args.asset_text)}
    report = VendorIPLeakScanner().scan_text_assets(bundle_ref=args.bundle_ref, assets=assets)
    payload = {
        "scan_id": report.scan_id,
        "bundle_ref": report.bundle_ref,
        "findings": [finding.__dict__ | {"severity": finding.severity.value} for finding in report.findings],
        "severity_summary": report.severity_summary,
        "blocked": report.blocked,
        "scanner_version": report.scanner_version,
    }
    output = Path(args.emit)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return 0 if not report.blocked else 2


if __name__ == "__main__":
    raise SystemExit(main())
