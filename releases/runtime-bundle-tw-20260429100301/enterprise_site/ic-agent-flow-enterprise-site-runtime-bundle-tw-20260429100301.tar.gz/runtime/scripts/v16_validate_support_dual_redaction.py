#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

from ic_agent_flow.governance.support_dual_redaction import (
    DualRedactionPolicy,
    SupportDualRedactionValidator,
    SupportExportCandidate,
)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--incident-id", required=True)
    parser.add_argument("--object", action="append", default=[])
    parser.add_argument("--log", action="append", default=[])
    parser.add_argument("--emit", required=True)
    args = parser.parse_args(argv)

    candidate = SupportExportCandidate(
        incident_id=args.incident_id,
        included_objects=args.object,
        logs=args.log,
        export_recipient_scope="customer-support",
        support_operator_authority="person://support-owner",
    )
    report = SupportDualRedactionValidator().validate(
        candidate,
        policy=DualRedactionPolicy(customer_ip_redaction=True, vendor_ip_redaction=True),
    )
    output = Path(args.emit)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report.audit_record, indent=2), encoding="utf-8")
    return 0 if report.allowed else 2


if __name__ == "__main__":
    raise SystemExit(main())
