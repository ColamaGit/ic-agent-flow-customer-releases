#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

from ic_agent_flow.governance.controlled_distribution import DistributionMode
from ic_agent_flow.governance.product_ip_classification import ProductIPClass, ProductIPClassificationRecord
from ic_agent_flow.governance.vendor_ip_packaging_gates import VendorIPGateRunner


def _record(asset_path: str, classification: ProductIPClass) -> ProductIPClassificationRecord:
    return ProductIPClassificationRecord(
        classification_id=f"classification://{asset_path}",
        asset_ref=f"asset://{asset_path}",
        asset_path=asset_path,
        asset_type="runtime",
        classification=classification,
        classification_reason="script input",
        allowed_distribution_modes=[DistributionMode.BINARY_RUNTIME],
        prohibited_distribution_modes=[],
        redaction_required=False,
        source_disclosure_allowed=False,
        reviewer="v16-gate-runner",
        created_at="2026-04-25T00:00:00+00:00",
        digest=f"sha256:{asset_path}",
        signature=f"sig://{asset_path}",
    )


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--asset", action="append", required=True)
    parser.add_argument("--emit", required=True)
    args = parser.parse_args(argv)

    records = [_record(asset, ProductIPClass.CUSTOMER_RUNTIME) for asset in args.asset]
    report = VendorIPGateRunner().run_source_exclusion(
        included_assets=args.asset,
        classification_records=records,
        distribution_mode=DistributionMode.BINARY_RUNTIME,
    )
    payload = {"gate_id": report.gate_id, "allowed": report.allowed, "blocking_reasons": report.blocking_reasons}
    output = Path(args.emit)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return 0 if report.allowed else 2


if __name__ == "__main__":
    raise SystemExit(main())
