#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from ic_agent_flow.domain.objects.deployment_packaging_objects import (
    AuthorityClass,
    KeyLifecycle,
    ObjectStatus,
    RollbackPackage,
    SignatureBlock,
    UpgradePackage,
    VerifierAuthority,
)
from ic_agent_flow.governance.customer_upgrade_operations import (
    RollbackDrillRunner,
    RollbackRequest,
    UpgradeExecutor,
    UpgradePostcheckRunner,
    UpgradePrecheckRunner,
    UpgradeRequest,
    UpgradeRollbackAuditEmitter,
)


def _signature_factory() -> SignatureBlock:
    return SignatureBlock(
        key_id="key-v15-upgrade",
        algorithm="ed25519",
        trust_root_ref="trust-root://customer-a",
        verifier_authority=VerifierAuthority.SECURITY,
        key_lifecycle=KeyLifecycle.ACTIVE,
    )


def _read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _write_json(path: Path, payload: dict[str, Any]) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return str(path)


def run_upgrade(
    *,
    site_id: str,
    upgrade_package_path: Path,
    customer_approval_ref: str,
    approved_by: str,
    env_state_path: Path,
    post_state_path: Path,
    output_path: Path,
    dry_run: bool = False,
) -> dict[str, Any]:

    pkg_data = _read_json(upgrade_package_path)
    upgrade_pkg = UpgradePackage.model_validate(pkg_data)
    env_state = _read_json(env_state_path) if env_state_path.exists() else {}
    post_state = _read_json(post_state_path) if post_state_path.exists() else {}

    request = UpgradeRequest(
        site_id=site_id,
        from_version=upgrade_pkg.from_version,
        to_version=upgrade_pkg.to_version,
        upgrade_package_ref=str(upgrade_pkg.id),
        customer_approval_ref=customer_approval_ref,
        approved_by=approved_by,
        dry_run=dry_run,
    )

    precheck = UpgradePrecheckRunner().run_precheck(upgrade_pkg, env_state)
    postcheck_result = {}
    exec_status = "NOT_STARTED"

    try:
        if precheck["passed"]:
            exec_res = UpgradeExecutor().execute_upgrade(request, upgrade_pkg)
            exec_status = exec_res["status"]
            if exec_status == "SUCCESS":
                postcheck_result = UpgradePostcheckRunner().run_postcheck(upgrade_pkg, post_state)
    except ValueError as e:
        exec_status = f"BLOCKED_{str(e).upper()}"

    emitter = UpgradeRollbackAuditEmitter(signature_factory=_signature_factory)
    record = emitter.emit_upgrade_record(
        request=request,
        precheck_result=precheck,
        postcheck_result=postcheck_result,
        execution_status=exec_status,
    )

    _write_json(output_path, record.model_dump(mode="json"))

    return {
        "status": record.result,
        "precheck_passed": precheck.get("passed", False),
        "postcheck_passed": postcheck_result.get("passed", False),
        "record_path": str(output_path),
    }


def run_rollback(
    *,
    site_id: str,
    rollback_package_path: Path,
    customer_approval_ref: str,
    approved_by: str,
    output_path: Path,
    drill_only: bool = False,
) -> dict[str, Any]:

    pkg_data = _read_json(rollback_package_path)
    rollback_pkg = RollbackPackage.model_validate(pkg_data)

    request = RollbackRequest(
        site_id=site_id,
        from_version="current", # typically inferred from environment
        target_version=rollback_pkg.target_version,
        rollback_package_ref=str(rollback_pkg.id),
        customer_approval_ref=customer_approval_ref,
        approved_by=approved_by,
        drill_only=drill_only,
    )

    exec_status = "NOT_STARTED"
    try:
        res = RollbackDrillRunner().execute_rollback(request, rollback_pkg)
        exec_status = res["status"]
    except ValueError as e:
        exec_status = f"BLOCKED_{str(e).upper()}"

    emitter = UpgradeRollbackAuditEmitter(signature_factory=_signature_factory)
    record = emitter.emit_rollback_record(
        request=request,
        rollback_pkg=rollback_pkg,
        execution_status=exec_status,
    )

    _write_json(output_path, record.model_dump(mode="json"))

    return {
        "status": record.result,
        "record_path": str(output_path),
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--action", required=True, choices=["upgrade", "rollback"])
    parser.add_argument("--site-id", required=True)
    parser.add_argument("--package-path", required=True)
    parser.add_argument("--customer-approval-ref", required=True)
    parser.add_argument("--approved-by", required=True)
    parser.add_argument("--output-path", required=True)
    
    # Optional for upgrade
    parser.add_argument("--env-state-path", default="")
    parser.add_argument("--post-state-path", default="")
    parser.add_argument("--dry-run", action="store_true")
    
    # Optional for rollback
    parser.add_argument("--drill-only", action="store_true")

    args = parser.parse_args(argv)

    if args.action == "upgrade":
        res = run_upgrade(
            site_id=args.site_id,
            upgrade_package_path=Path(args.package_path),
            customer_approval_ref=args.customer_approval_ref,
            approved_by=args.approved_by,
            env_state_path=Path(args.env_state_path) if args.env_state_path else Path("missing.json"),
            post_state_path=Path(args.post_state_path) if args.post_state_path else Path("missing.json"),
            output_path=Path(args.output_path),
            dry_run=args.dry_run,
        )
    else:
        res = run_rollback(
            site_id=args.site_id,
            rollback_package_path=Path(args.package_path),
            customer_approval_ref=args.customer_approval_ref,
            approved_by=args.approved_by,
            output_path=Path(args.output_path),
            drill_only=args.drill_only,
        )

    print(json.dumps(res, indent=2))
    return 0 if res["status"] in ["SUCCESS", "STAGED"] else 1


if __name__ == "__main__":
    sys.exit(main())
