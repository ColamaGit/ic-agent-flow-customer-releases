#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

from ic_agent_flow.governance.controlled_distribution import DistributionMode
from ic_agent_flow.governance.entitlement_policy import EntitlementPolicyValidator, EntitlementRecord


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--entitlement", required=True)
    parser.add_argument("--capability", action="append", required=True)
    parser.add_argument("--emit", required=True)
    args = parser.parse_args(argv)

    data = json.loads(Path(args.entitlement).read_text(encoding="utf-8"))
    data["allowed_distribution_modes"] = [DistributionMode(value) for value in data["allowed_distribution_modes"]]
    entitlement = EntitlementRecord(**data)
    report = EntitlementPolicyValidator().validate(
        entitlement=entitlement,
        distribution_mode=DistributionMode.BINARY_RUNTIME,
        deployment_profile_ref=entitlement.allowed_profiles[0],
        enabled_capabilities=args.capability,
    )
    output = Path(args.emit)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report.feature_gate_report, indent=2), encoding="utf-8")
    return 0 if report.allowed else 2


if __name__ == "__main__":
    raise SystemExit(main())
