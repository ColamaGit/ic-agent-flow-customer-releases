#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from ic_agent_flow.domain.objects.deployment_packaging_objects import (
    KeyLifecycle,
    SignatureBlock,
    VerifierAuthority,
)
from ic_agent_flow.domain.objects.v15_customer_site_activation_objects import (
    SiteEnvironmentFingerprint,
    SiteRuntimeManifest,
)
from ic_agent_flow.governance.customer_drift_verification import (
    DriftRecordBuilder,
    ManifestDriftEvaluator,
)


def _signature_factory() -> SignatureBlock:
    return SignatureBlock(
        key_id="key-v15-drift",
        algorithm="ed25519",
        trust_root_ref="trust-root://customer-a",
        verifier_authority=VerifierAuthority.SECURITY,
        key_lifecycle=KeyLifecycle.ACTIVE,
    )


def _read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _write_json(path: Path, payload: dict[str, Any]) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return str(path)


def run_drift_verification(
    *,
    manifest_path: Path,
    fingerprint_path: Path,
    output_path: Path,
) -> dict[str, Any]:
    manifest_data = _read_json(manifest_path)
    manifest = SiteRuntimeManifest.model_validate(manifest_data)

    fingerprint_data = _read_json(fingerprint_path)
    fingerprint = SiteEnvironmentFingerprint.model_validate(fingerprint_data)

    evaluator = ManifestDriftEvaluator()
    drift_items = evaluator.evaluate(manifest, fingerprint)

    builder = DriftRecordBuilder(signature_factory=_signature_factory)
    record = builder.build_record(
        site_id=manifest.site_id,
        manifest_ref=str(manifest.id) if hasattr(manifest, "id") else "manifest-ref",
        drift_items=drift_items,
    )

    _write_json(output_path, record.model_dump(mode="json"))

    return {
        "status": "DRIFT_DETECTED" if record.drift_detected else "NO_DRIFT",
        "drift_detected": record.drift_detected,
        "drift_items_count": len(drift_items),
        "record_path": str(output_path),
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest-path", required=True)
    parser.add_argument("--fingerprint-path", required=True)
    parser.add_argument("--output-path", required=True)

    args = parser.parse_args(argv)

    res = run_drift_verification(
        manifest_path=Path(args.manifest_path),
        fingerprint_path=Path(args.fingerprint_path),
        output_path=Path(args.output_path),
    )

    print(json.dumps(res, indent=2))
    # Return 1 if drift detected, fail-closed mechanism
    return 1 if res["drift_detected"] else 0


if __name__ == "__main__":
    sys.exit(main())
