#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

from ic_agent_flow.governance.product_ip_classification import ProductIPClass


def classify_path(path: str) -> ProductIPClass:
    if path.startswith("workspace/") or path.startswith("internal-dev/") or path.startswith("tests/"):
        return ProductIPClass.INTERNAL_ONLY
    if "/source/" in path or path.endswith(".py"):
        return ProductIPClass.SOURCE_ESCROW_ONLY
    if "contract" in path or "schema" in path:
        return ProductIPClass.PUBLIC_CONTRACT
    return ProductIPClass.CUSTOMER_RUNTIME


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", action="append", required=True)
    parser.add_argument("--emit", required=True)
    args = parser.parse_args(argv)

    output = Path(args.emit)
    output.parent.mkdir(parents=True, exist_ok=True)
    records = []
    for asset_path in args.input:
        classification = classify_path(asset_path)
        records.append({
            "classification_id": f"classification://{asset_path}",
            "asset_ref": f"asset://{asset_path}",
            "asset_path": asset_path,
            "classification": classification.value,
            "reviewer": "v16-classifier",
            "digest": f"sha256:{asset_path}",
            "signature": f"sig://v16/{asset_path}",
        })
    output.write_text("\n".join(json.dumps(record) for record in records) + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
