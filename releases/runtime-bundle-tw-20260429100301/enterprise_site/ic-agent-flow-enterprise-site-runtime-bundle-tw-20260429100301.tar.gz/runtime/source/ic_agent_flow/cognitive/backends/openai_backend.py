"""
OpenAI Backend Driver (Route A / minimal skeleton)
==================================================
Provides a minimal OpenAI model_style backend via the governed adapter route.
"""
from __future__ import annotations

import os
import time
from typing import Optional

from ic_agent_flow.cognitive.backends.gemini import CognitiveBackendError
from ic_agent_flow.cognitive.schemas import (
    BackendProvider,
    CognitiveRequest,
    CognitiveResponse,
    ResponseType,
)


class OpenAIBackend:
    """Minimal OpenAI backend wrapper with fail-closed behavior."""

    PROVIDER = BackendProvider.OPENAI

    def __init__(self):
        self._client = None
        self._api_key: Optional[str] = None
        self._model_id: str = os.getenv("OPENAI_MODEL", "gpt-5.4-mini")

    def _ensure_initialized(self) -> None:
        if self._client is not None:
            return

        api_key = os.getenv("OPENAI_API_KEY", "")
        if not api_key or api_key == "your_openai_api_key_here":
            raise CognitiveBackendError(
                "OPENAI_API_KEY is not configured. Set it in environment before OPENAI routing."
            )
        self._api_key = api_key

        try:
            from openai import OpenAI  # lazy import for optional dependency

            self._client = OpenAI(api_key=api_key)
        except ImportError as exc:
            raise CognitiveBackendError(
                "openai package not installed. Run: pip install openai"
            ) from exc

    def invoke(self, request: CognitiveRequest) -> CognitiveResponse:
        """
        Invoke OpenAI backend.
        Test mode: when metadata contains `openai_test_text`, no external call is made.
        """
        test_text = (request.metadata or {}).get("openai_test_text")
        if test_text:
            return self._mock_response(request, str(test_text))

        self._ensure_initialized()
        prompt = request.prompt if not request.system_context else f"{request.system_context}\n\n{request.prompt}"
        start = time.monotonic()
        try:
            resp = self._client.responses.create(
                model=self._model_id,
                input=prompt,
                max_output_tokens=request.max_tokens,
            )
            latency_ms = (time.monotonic() - start) * 1000
            text = getattr(resp, "output_text", "") or ""
            if not text:
                return CognitiveResponse(
                    request_id=request.request_id,
                    response_type=ResponseType.REFUSAL,
                    content="",
                    provider=self.PROVIDER,
                    model_id=self._model_id,
                    refusal_reason="Empty response from OpenAI API",
                    raw_metadata={"latency_ms": round(latency_ms, 2)},
                )
            return CognitiveResponse(
                request_id=request.request_id,
                response_type=ResponseType.TEXT,
                content=text,
                provider=self.PROVIDER,
                model_id=self._model_id,
                raw_metadata={"latency_ms": round(latency_ms, 2)},
            )
        except CognitiveBackendError:
            raise
        except Exception as exc:
            raise CognitiveBackendError(
                f"OpenAI API invocation failed: {type(exc).__name__}: {exc}"
            ) from exc

    def _mock_response(self, request: CognitiveRequest, text: str) -> CognitiveResponse:
        return CognitiveResponse(
            request_id=request.request_id,
            response_type=ResponseType.TEXT,
            content=text,
            provider=self.PROVIDER,
            model_id="openai-test-skeleton",
            usage_input_tokens=len(request.prompt.split()),
            usage_output_tokens=len(text.split()),
            raw_metadata={"mode": "openai_test_skeleton"},
        )
