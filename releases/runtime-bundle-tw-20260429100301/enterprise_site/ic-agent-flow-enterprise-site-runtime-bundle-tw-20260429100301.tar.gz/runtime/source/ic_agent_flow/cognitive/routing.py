"""
Cognitive Routing Engine (Step 3 — Routing Core)
=================================================
Policy-driven backend selection. No implicit fallback. Fail-closed.

Design Laws enforced here:
- Law 5: Routing MUST be policy-driven, not convenience-driven.
- Law 1: Agent identity is never exposed to the backend.
- Law 2: Every selection MUST categorize the backend type.
"""
from __future__ import annotations

import os
from typing import Optional

from ic_agent_flow.cognitive.schemas import (
    BackendCategory,
    BackendPolicy,
    BackendProvider,
    BackendSelection,
    CognitiveRequest,
    SensitivityLevel,
)


class RoutingError(Exception):
    """Raised when routing cannot find a valid backend under current policy."""
    pass


class CognitiveRouter:
    """
    Evaluates a CognitiveRequest against the active policy and selects a backend.
    All decisions are recorded in BackendSelection for audit purposes.
    """

    # Provider → Category mapping (canonical taxonomy)
    PROVIDER_CATEGORY: dict[BackendProvider, BackendCategory] = {
        BackendProvider.LOCAL_MOCK: BackendCategory.MODEL_STYLE,
        BackendProvider.GEMINI: BackendCategory.MODEL_STYLE,
        BackendProvider.VERTEX_AI: BackendCategory.MODEL_STYLE,
        BackendProvider.BEDROCK: BackendCategory.MODEL_STYLE,
        BackendProvider.OPENAI: BackendCategory.MODEL_STYLE,
    }

    # Sensitivity levels that MUST stay local (hard rule)
    LOCAL_ONLY_SENSITIVITIES = {
        SensitivityLevel.CONFIDENTIAL,
    }
    _ADAPTER_ROUTE_TOKEN = "cognitive_adapter"

    def __init__(self):
        self._active_policy = BackendPolicy(
            os.getenv("COGNITIVE_BACKEND_POLICY", BackendPolicy.REMOTE_ALLOWED_WITH_CONTROLS)
        )

    def select(self, request: CognitiveRequest) -> BackendSelection:
        """
        Core routing decision. Returns a BackendSelection or raises RoutingError.
        Never falls back silently — fail-closed is the only safe default.
        """
        effective_policy = self._resolve_effective_policy(request)
        self._enforce_no_direct_provider_binding(request)

        if effective_policy == BackendPolicy.LOCAL_ONLY:
            return self._select_local(request, effective_policy, "Policy or sensitivity requires local execution")

        # Remote allowed — pick best available remote
        if effective_policy == BackendPolicy.REMOTE_ALLOWED_WITH_CONTROLS:
            return self._select_remote(request, effective_policy)

        raise RoutingError(f"Unknown policy: {effective_policy}. Fail-closed.")

    def _enforce_no_direct_provider_binding(self, request: CognitiveRequest) -> None:
        """
        Remote provider preference must come through adapter-governed route.
        This blocks direct provider binding attempts outside adapter orchestration.
        """
        preferred = request.preferred_provider
        if preferred is None or preferred == BackendProvider.LOCAL_MOCK:
            return

        adapter_route = (request.metadata or {}).get("adapter_route")
        if adapter_route != self._ADAPTER_ROUTE_TOKEN:
            raise RoutingError(
                "Direct provider binding rejected: remote provider preference requires "
                "adapter_route=cognitive_adapter."
            )

    def _resolve_effective_policy(self, request: CognitiveRequest) -> BackendPolicy:
        """Sensitivity may override policy to be more restrictive."""
        if request.sensitivity in self.LOCAL_ONLY_SENSITIVITIES:
            return BackendPolicy.LOCAL_ONLY
        return request.policy or self._active_policy

    def _select_local(
        self,
        request: CognitiveRequest,
        policy: BackendPolicy,
        reason: str,
        redaction_applied: bool = False,
    ) -> BackendSelection:
        return BackendSelection(
            request_id=request.request_id,
            selected_provider=BackendProvider.LOCAL_MOCK,
            selected_category=self.PROVIDER_CATEGORY[BackendProvider.LOCAL_MOCK],
            selection_reason=reason,
            policy_rule_applied=policy,
            redaction_applied=redaction_applied,
            fallback_used=False,
        )

    def _select_remote(
        self,
        request: CognitiveRequest,
        policy: BackendPolicy,
    ) -> BackendSelection:
        """Select the preferred remote provider, with redaction gate for sensitive data."""
        redaction_needed = request.sensitivity == SensitivityLevel.RESTRICTED

        # Honor explicit preference if provided
        provider = request.preferred_provider or self._default_remote_provider()

        if provider == BackendProvider.LOCAL_MOCK:
            # Caller explicitly requested local
            return self._select_local(request, policy, "Caller explicitly preferred local", redaction_needed)

        return BackendSelection(
            request_id=request.request_id,
            selected_provider=provider,
            selected_category=self.PROVIDER_CATEGORY.get(provider, BackendCategory.MODEL_STYLE),
            selection_reason=f"Remote backend selected: {provider.value} (policy={policy.value})",
            policy_rule_applied=policy,
            redaction_applied=redaction_needed,
            fallback_used=False,
        )

    def _default_remote_provider(self) -> BackendProvider:
        """Returns the configured default remote provider."""
        openai_key = os.getenv("OPENAI_API_KEY", "")
        if openai_key and openai_key != "your_openai_api_key_here":
            return BackendProvider.OPENAI
        gemini_key = os.getenv("GEMINI_API_KEY", "")
        if gemini_key and gemini_key != "your_gemini_api_key_here":
            return BackendProvider.GEMINI
        # No remote configured → fail-closed to local
        return BackendProvider.LOCAL_MOCK
