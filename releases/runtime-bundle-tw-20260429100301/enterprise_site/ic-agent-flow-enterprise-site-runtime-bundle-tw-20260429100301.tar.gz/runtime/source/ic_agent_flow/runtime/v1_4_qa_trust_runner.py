"""
R1 Runtime Proof — v1.4 QA Trust Runner

Risk Mitigation Plan v0.1 — R1 (P0): Runtime Proof Convergence
Governing PRD: v1.4 QA Trust Layer

Purpose:
    Provides a unified, auditable runner for the v1.4 QA Trust Layer evaluation:
      functional_qa → evidence_qa → scenario_qa → governance_qa → adjudication → trust_report

    This runner answers the critical question:
      "Is the evidence, scenario coverage, and claim set trustworthy?"

Proof Ladder:
    L1 — Object Proof:  QA report schema + sample objects
    L2 — Runner Proof:  this runner + QA adjudication + trust report artifact
    L3 — Scenario Proof: happy path, negative path (overclaim / insufficient evidence)

No-Proof-No-Claim Gate mapping:
    claim: "QA trusted" → required proof: v1.4 trust report (runner + artifact)
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import List, Optional


# ---------------------------------------------------------------------------
# Runner Enums
# ---------------------------------------------------------------------------

class V14QAVerdict(str, Enum):
    PROCEED = "PROCEED"                       # all QA layers pass
    REQUEST_MORE_EVIDENCE = "REQUEST_MORE_EVIDENCE"  # evidence surface weak
    HOLD = "HOLD"                             # insufficient evidence / scenario gap / lineage broken
    REJECT = "REJECT"                         # overbroad claim detected


class V14QADimension(str, Enum):
    FUNCTIONAL = "FUNCTIONAL_QA"
    EVIDENCE = "EVIDENCE_QA"
    SCENARIO = "SCENARIO_QA"
    GOVERNANCE = "GOVERNANCE_QA"


# ---------------------------------------------------------------------------
# QA Input Models
# ---------------------------------------------------------------------------

@dataclass
class EvidenceQAInput:
    """Input for the Evidence QA dimension."""
    evidence_refs: List[dict]     # list of {ref_id, uri, digest, raw_bound}
    chip_id: str
    expected_families: List[str]  # e.g. ["SIMULATION", "LINT", "FORMAL", "TIMING"]


@dataclass
class ScenarioQAInput:
    """Input for the Scenario QA dimension."""
    scenarios: List[dict]         # list of {name, has_happy_path, has_negative_path, has_reentry}
    require_negative_path: bool = True


@dataclass
class ClaimQAInput:
    """Input for the Governance (Claim) QA dimension."""
    claims: List[dict]            # list of {claim_text, supporting_evidence_refs}


@dataclass
class FunctionalQAInput:
    """Input for the Functional QA dimension."""
    runner_results: List[dict]    # list of {runner_id, verdict, artifact_refs}


# ---------------------------------------------------------------------------
# Runner Result Model
# ---------------------------------------------------------------------------

@dataclass
class V14DimensionResult:
    dimension: str
    verdict: str            # ACCEPTABLE / INSUFFICIENT_EVIDENCE / SCENARIO_GAP / OVERBROAD_CLAIM / REVIEW_SURFACE_WEAK / LINEAGE_BROKEN
    issues: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)


@dataclass
class V14QATrustRunnerResult:
    """
    Evidence artifact produced by the v1.4 QA Trust runner.
    Constitutes L2 Runner Proof for the No-Proof-No-Claim Gate (claim: QA trusted).
    """
    runner_id: str
    chip_id: str
    run_dir: str
    overall_verdict: V14QAVerdict
    recommendation: str
    dimension_results: List[V14DimensionResult] = field(default_factory=list)
    blocking_issues: List[str] = field(default_factory=list)
    non_blocking_warnings: List[str] = field(default_factory=list)
    negative_path_triggered: bool = False
    artifact_refs: List[str] = field(default_factory=list)
    created_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )

    def to_dict(self) -> dict:
        return {
            "runner_id": self.runner_id,
            "chip_id": self.chip_id,
            "run_dir": self.run_dir,
            "overall_verdict": self.overall_verdict.value,
            "recommendation": self.recommendation,
            "dimension_results": [
                {
                    "dimension": d.dimension,
                    "verdict": d.verdict,
                    "issues": d.issues,
                    "warnings": d.warnings,
                }
                for d in self.dimension_results
            ],
            "blocking_issues": self.blocking_issues,
            "non_blocking_warnings": self.non_blocking_warnings,
            "negative_path_triggered": self.negative_path_triggered,
            "artifact_refs": self.artifact_refs,
            "created_at": self.created_at,
        }


# ---------------------------------------------------------------------------
# Dimension Evaluators
# ---------------------------------------------------------------------------

_VERDICT_PRIORITY = {
    "LINEAGE_BROKEN": 0,
    "INSUFFICIENT_EVIDENCE": 1,
    "SCENARIO_GAP": 2,
    "OVERBROAD_CLAIM": 3,
    "REVIEW_SURFACE_WEAK": 4,
    "ACCEPTABLE": 5,
}


def _evaluate_functional_qa(inp: FunctionalQAInput) -> V14DimensionResult:
    """Functional QA: are runner artifacts present and passing?"""
    issues = []
    if not inp.runner_results:
        return V14DimensionResult(
            dimension=V14QADimension.FUNCTIONAL.value,
            verdict="INSUFFICIENT_EVIDENCE",
            issues=["No runner results provided — functional proof absent"],
        )
    for r in inp.runner_results:
        if r.get("verdict") not in ("PASS", "PARTIAL"):
            issues.append(
                f"Runner '{r.get('runner_id', '?')}' verdict = '{r.get('verdict')}' — not passing"
            )
        if not r.get("artifact_refs"):
            issues.append(
                f"Runner '{r.get('runner_id', '?')}' has no artifact_refs — unverifiable"
            )
    verdict = "INSUFFICIENT_EVIDENCE" if issues else "ACCEPTABLE"
    return V14DimensionResult(
        dimension=V14QADimension.FUNCTIONAL.value,
        verdict=verdict,
        issues=issues,
    )


def _evaluate_evidence_qa(inp: EvidenceQAInput) -> V14DimensionResult:
    """Evidence QA: are evidence refs raw-bound, chip-scoped, digest-verified?"""
    issues = []
    warnings = []

    if not inp.evidence_refs:
        return V14DimensionResult(
            dimension=V14QADimension.EVIDENCE.value,
            verdict="INSUFFICIENT_EVIDENCE",
            issues=["No evidence refs provided"],
        )

    # Check digest and chip scope
    for ref in inp.evidence_refs:
        if not ref.get("digest"):
            issues.append(f"Evidence '{ref.get('ref_id', '?')}' missing digest — lineage broken")
        if inp.chip_id and inp.chip_id not in ref.get("uri", ""):
            issues.append(
                f"Evidence '{ref.get('ref_id', '?')}' uri missing chip_id '{inp.chip_id}'"
            )

    # Check expected evidence families covered
    present_families = {r.get("evidence_family", "") for r in inp.evidence_refs}
    missing_families = [f for f in inp.expected_families if f not in present_families]
    if missing_families:
        warnings.append(f"Missing evidence families: {missing_families}")

    if any("lineage broken" in i for i in issues):
        verdict = "LINEAGE_BROKEN"
    elif issues:
        verdict = "INSUFFICIENT_EVIDENCE"
    elif warnings:
        verdict = "REVIEW_SURFACE_WEAK"
    else:
        verdict = "ACCEPTABLE"

    return V14DimensionResult(
        dimension=V14QADimension.EVIDENCE.value,
        verdict=verdict,
        issues=issues,
        warnings=warnings,
    )


def _evaluate_scenario_qa(inp: ScenarioQAInput) -> V14DimensionResult:
    """Scenario QA: do scenarios include negative path and re-entry coverage?"""
    issues = []
    warnings = []

    if not inp.scenarios:
        return V14DimensionResult(
            dimension=V14QADimension.SCENARIO.value,
            verdict="SCENARIO_GAP",
            issues=["No scenarios registered"],
        )

    for s in inp.scenarios:
        name = s.get("name", "?")
        if not s.get("has_happy_path"):
            issues.append(f"Scenario '{name}': missing happy path")
        if inp.require_negative_path and not s.get("has_negative_path"):
            issues.append(f"Scenario '{name}': missing negative path (required by policy)")
        if not s.get("has_reentry"):
            warnings.append(f"Scenario '{name}': re-entry path not validated")

    verdict = "SCENARIO_GAP" if issues else ("REVIEW_SURFACE_WEAK" if warnings else "ACCEPTABLE")
    return V14DimensionResult(
        dimension=V14QADimension.SCENARIO.value,
        verdict=verdict,
        issues=issues,
        warnings=warnings,
    )


def _evaluate_governance_qa(inp: ClaimQAInput) -> V14DimensionResult:
    """Governance (Claim) QA: are all claims backed by evidence?"""
    issues = []

    if not inp.claims:
        return V14DimensionResult(
            dimension=V14QADimension.GOVERNANCE.value,
            verdict="REVIEW_SURFACE_WEAK",
            warnings=["No claims submitted for review — overclaim risk cannot be evaluated"],
        )

    for claim in inp.claims:
        claim_text = claim.get("claim_text", "?")
        if not claim.get("supporting_evidence_refs"):
            issues.append(
                f"Claim '{claim_text[:60]}...' has no supporting_evidence_refs — OVERBROAD"
            )

    verdict = "OVERBROAD_CLAIM" if issues else "ACCEPTABLE"
    return V14DimensionResult(
        dimension=V14QADimension.GOVERNANCE.value,
        verdict=verdict,
        issues=issues,
    )


def _verdict_to_recommendation(verdict: str) -> str:
    if verdict == "ACCEPTABLE":
        return "PROCEED"
    if verdict == "REVIEW_SURFACE_WEAK":
        return "REQUEST_MORE_EVIDENCE"
    if verdict == "OVERBROAD_CLAIM":
        return "REJECT"
    return "HOLD"


# ---------------------------------------------------------------------------
# Runner Entry Point
# ---------------------------------------------------------------------------

def run_v14_qa_trust(
    *,
    chip_id: str,
    run_dir: Path | str,
    functional_input: FunctionalQAInput,
    evidence_input: EvidenceQAInput,
    scenario_input: ScenarioQAInput,
    claim_input: ClaimQAInput,
    runner_id: Optional[str] = None,
    emit_artifact: bool = True,
) -> V14QATrustRunnerResult:
    """
    Execute the v1.4 QA Trust Layer proof runner across all four dimensions:
    Functional QA / Evidence QA / Scenario QA / Governance (Claim) QA.

    Happy path: all dimensions return ACCEPTABLE → overall verdict = PROCEED.
    Negative path: any dimension fails → HOLD / REJECT / REQUEST_MORE_EVIDENCE.

    Args:
        chip_id:           Chip identity being evaluated.
        run_dir:           Path to the evidence run output directory.
        functional_input:  Runner results input.
        evidence_input:    Evidence refs input.
        scenario_input:    Scenario coverage input.
        claim_input:       Claim review input.
        runner_id:         Optional unique ID for this run.
        emit_artifact:     If True, writes the result JSON to run_dir/evidence/.

    Returns:
        V14QATrustRunnerResult with overall verdict, per-dimension results, and artifact refs.
    """
    run_dir = Path(run_dir)

    if runner_id is None:
        ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        runner_id = f"v14-runner-{chip_id}-{ts}"

    # Evaluate all four dimensions
    dim_functional = _evaluate_functional_qa(functional_input)
    dim_evidence = _evaluate_evidence_qa(evidence_input)
    dim_scenario = _evaluate_scenario_qa(scenario_input)
    dim_governance = _evaluate_governance_qa(claim_input)

    dimension_results = [dim_functional, dim_evidence, dim_scenario, dim_governance]

    # Combine verdicts — worst (lowest priority) wins
    all_verdicts = [d.verdict for d in dimension_results]
    combined_verdict = min(all_verdicts, key=lambda v: _VERDICT_PRIORITY.get(v, 999))
    recommendation = _verdict_to_recommendation(combined_verdict)

    # Aggregate issues
    blocking_issues: List[str] = []
    non_blocking_warnings: List[str] = []
    for d in dimension_results:
        if d.verdict not in ("ACCEPTABLE", "REVIEW_SURFACE_WEAK"):
            blocking_issues.extend(d.issues)
        else:
            non_blocking_warnings.extend(d.warnings)

    negative_path_triggered = len(blocking_issues) > 0

    # Map combined verdict string to enum
    verdict_map = {
        "ACCEPTABLE": V14QAVerdict.PROCEED,
        "REVIEW_SURFACE_WEAK": V14QAVerdict.REQUEST_MORE_EVIDENCE,
        "OVERBROAD_CLAIM": V14QAVerdict.REJECT,
        "LINEAGE_BROKEN": V14QAVerdict.HOLD,
        "INSUFFICIENT_EVIDENCE": V14QAVerdict.HOLD,
        "SCENARIO_GAP": V14QAVerdict.HOLD,
    }
    overall_verdict = verdict_map.get(combined_verdict, V14QAVerdict.HOLD)

    result = V14QATrustRunnerResult(
        runner_id=runner_id,
        chip_id=chip_id,
        run_dir=str(run_dir),
        overall_verdict=overall_verdict,
        recommendation=recommendation,
        dimension_results=dimension_results,
        blocking_issues=blocking_issues,
        non_blocking_warnings=non_blocking_warnings,
        negative_path_triggered=negative_path_triggered,
        artifact_refs=[],
    )

    if emit_artifact:
        evidence_dir = run_dir / "evidence" / "v14_qa_trust"
        evidence_dir.mkdir(parents=True, exist_ok=True)
        artifact_path = evidence_dir / f"{runner_id}.json"
        artifact_path.write_text(
            json.dumps(result.to_dict(), indent=2),
            encoding="utf-8",
        )
        result.artifact_refs.append(str(artifact_path))

    return result


# ---------------------------------------------------------------------------
# Negative Path Test Helpers
# ---------------------------------------------------------------------------

def assert_v14_negative_path_overclaim(run_dir: Path | str) -> bool:
    """
    Negative test: claim with no evidence refs → REJECT (OVERBROAD_CLAIM).
    """
    result = run_v14_qa_trust(
        chip_id="SN2025",
        run_dir=run_dir,
        functional_input=FunctionalQAInput(
            runner_results=[{"runner_id": "r1", "verdict": "PASS", "artifact_refs": ["a.json"]}]
        ),
        evidence_input=EvidenceQAInput(
            evidence_refs=[{"ref_id": "ev1", "uri": "chips/SN2025/sim.json", "digest": "abc", "evidence_family": "SIMULATION"}],
            chip_id="SN2025",
            expected_families=["SIMULATION"],
        ),
        scenario_input=ScenarioQAInput(
            scenarios=[{"name": "bounded-digital-block", "has_happy_path": True, "has_negative_path": True, "has_reentry": False}]
        ),
        claim_input=ClaimQAInput(
            claims=[{"claim_text": "system is customer-ready", "supporting_evidence_refs": []}]  # no evidence
        ),
        emit_artifact=False,
    )
    assert result.overall_verdict == V14QAVerdict.REJECT
    assert "OVERBROAD_CLAIM" in [d.verdict for d in result.dimension_results]
    return True


def assert_v14_negative_path_no_negative_scenario(run_dir: Path | str) -> bool:
    """
    Negative test: scenario without negative path → HOLD (SCENARIO_GAP).
    """
    result = run_v14_qa_trust(
        chip_id="SN2025",
        run_dir=run_dir,
        functional_input=FunctionalQAInput(
            runner_results=[{"runner_id": "r1", "verdict": "PASS", "artifact_refs": ["a.json"]}]
        ),
        evidence_input=EvidenceQAInput(
            evidence_refs=[{"ref_id": "ev1", "uri": "chips/SN2025/sim.json", "digest": "abc", "evidence_family": "SIMULATION"}],
            chip_id="SN2025",
            expected_families=["SIMULATION"],
        ),
        scenario_input=ScenarioQAInput(
            scenarios=[{"name": "bounded-digital-block", "has_happy_path": True, "has_negative_path": False, "has_reentry": False}]
        ),
        claim_input=ClaimQAInput(claims=[]),
        emit_artifact=False,
    )
    assert result.overall_verdict == V14QAVerdict.HOLD
    assert "SCENARIO_GAP" in [d.verdict for d in result.dimension_results]
    return True
