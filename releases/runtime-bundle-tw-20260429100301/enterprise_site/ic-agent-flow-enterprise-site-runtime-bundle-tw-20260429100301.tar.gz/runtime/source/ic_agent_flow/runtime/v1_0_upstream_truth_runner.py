"""
R1 Runtime Proof — v1.0 Upstream Truth Runner

Risk Mitigation Plan v0.1 — R1 (P0): Runtime Proof Convergence
Governing PRD: v1.0 Upstream Truth

Purpose:
    Provides a unified, auditable runner for the v1.0 upstream truth pipeline:
      requirement_intake → spec_completion → architecture_graph → graph_validation → freeze → generation_plan

Proof Ladder:
    L1 — Object Proof:  schema, sample object, validator
    L2 — Runner Proof:  this runner + state transitions + artifact
    L3 — Scenario Proof: happy path, negative path, audit bundle

Usage:
    result = run_v10_upstream_truth(chip_dir=..., run_dir=..., rtl_src=...)
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import List, Optional


# ---------------------------------------------------------------------------
# Runner Result Model
# ---------------------------------------------------------------------------

class V10RunnerVerdict(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    PARTIAL = "PARTIAL"


class V10ProofLevel(str, Enum):
    L1_OBJECT = "L1_OBJECT"
    L2_RUNNER = "L2_RUNNER"
    L3_SCENARIO = "L3_SCENARIO"
    NONE = "NONE"


@dataclass
class V10UpstreamTruthRunnerResult:
    """
    Evidence artifact produced by the v1.0 upstream truth runner.
    Constitutes L2 Runner Proof for the No-Proof-No-Claim Gate.
    """
    runner_id: str
    chip_id: str
    run_dir: str
    verdict: V10RunnerVerdict
    proof_level_achieved: V10ProofLevel
    upstream_gate_state: str
    steps_completed: List[str] = field(default_factory=list)
    steps_failed: List[str] = field(default_factory=list)
    issues: List[str] = field(default_factory=list)
    artifact_refs: List[str] = field(default_factory=list)
    negative_path_triggered: bool = False
    negative_path_reason: Optional[str] = None
    created_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )

    def to_dict(self) -> dict:
        return {
            "runner_id": self.runner_id,
            "chip_id": self.chip_id,
            "run_dir": self.run_dir,
            "verdict": self.verdict.value,
            "proof_level_achieved": self.proof_level_achieved.value,
            "upstream_gate_state": self.upstream_gate_state,
            "steps_completed": self.steps_completed,
            "steps_failed": self.steps_failed,
            "issues": self.issues,
            "artifact_refs": self.artifact_refs,
            "negative_path_triggered": self.negative_path_triggered,
            "negative_path_reason": self.negative_path_reason,
            "created_at": self.created_at,
        }


# ---------------------------------------------------------------------------
# Upstream Gate State Derivation (inline, no external dependency)
# ---------------------------------------------------------------------------

def _derive_gate_state(chip_dir: Path) -> str:
    """
    Derive the UpstreamGateState from the chip directory structure.
    Returns a string matching UpstreamGateState enum values.
    """
    specs_dir = chip_dir / "specs"
    architecture_dir = chip_dir / "architecture"

    has_spec = any(specs_dir.glob("*.json")) if specs_dir.exists() else False
    has_graph = (architecture_dir / "architecture_graph.json").exists()
    has_validation = (architecture_dir / "graph_validation_result.json").exists()
    has_freeze = (architecture_dir / "graph_freeze_record.json").exists()
    has_plan = (architecture_dir / "graph_to_generation_plan.json").exists()

    if has_freeze and has_plan:
        return "FROZEN_PLAN_READY"
    if has_freeze:
        return "FREEZE_ELIGIBLE"
    if has_validation:
        return "VALIDATED_NOT_FROZEN"
    if has_graph:
        return "PROVISIONAL_GRAPH_PRESENT"
    if has_spec:
        return "PROVISIONAL_SPEC_ONLY"
    return "NO_UPSTREAM_OBJECTS"


# ---------------------------------------------------------------------------
# Step Validators
# ---------------------------------------------------------------------------

def _validate_requirement_intake(chip_dir: Path) -> tuple[bool, str]:
    """L1: Verify requirement intake objects exist under specs/intake/."""
    intake_dir = chip_dir / "specs" / "intake"
    if not intake_dir.exists():
        return False, "specs/intake/ directory missing — requirement intake not materialized"
    intake_files = list(intake_dir.glob("*.json"))
    if not intake_files:
        return False, "specs/intake/ exists but contains no .json objects"
    return True, f"requirement_intake: {len(intake_files)} object(s) found"


def _validate_spec_completion(chip_dir: Path) -> tuple[bool, str]:
    """L1: Verify spec completion objects exist under specs/."""
    specs_dir = chip_dir / "specs"
    if not specs_dir.exists():
        return False, "specs/ directory missing — spec_completion not materialized"
    spec_files = [f for f in specs_dir.glob("*.json") if f.name != "intake"]
    if not spec_files:
        return False, "specs/ exists but contains no spec .json objects"
    return True, f"spec_completion: {len(spec_files)} spec object(s) found"


def _validate_architecture_graph(chip_dir: Path) -> tuple[bool, str]:
    """L1: Verify architecture graph object exists."""
    graph_path = chip_dir / "architecture" / "architecture_graph.json"
    if not graph_path.exists():
        return False, "architecture/architecture_graph.json missing — graph not materialized"
    return True, "architecture_graph.json present"


def _validate_graph_validation(chip_dir: Path) -> tuple[bool, str]:
    """L2: Verify graph_validation_result exists (machine-checkable)."""
    validation_path = chip_dir / "architecture" / "graph_validation_result.json"
    if not validation_path.exists():
        return False, "graph_validation_result.json missing — graph not yet validated"
    return True, "graph_validation_result.json present"


def _validate_freeze(chip_dir: Path) -> tuple[bool, str]:
    """L2: Verify graph freeze record exists."""
    freeze_path = chip_dir / "architecture" / "graph_freeze_record.json"
    if not freeze_path.exists():
        return False, "graph_freeze_record.json missing — spec/graph not yet frozen"
    return True, "graph_freeze_record.json present"


def _validate_generation_plan(chip_dir: Path) -> tuple[bool, str]:
    """L2: Verify generation plan derived from frozen graph exists."""
    plan_path = chip_dir / "architecture" / "graph_to_generation_plan.json"
    if not plan_path.exists():
        return False, "graph_to_generation_plan.json missing — generation plan not derived"
    return True, "graph_to_generation_plan.json present"


# ---------------------------------------------------------------------------
# Runner Entry Point
# ---------------------------------------------------------------------------

def run_v10_upstream_truth(
    *,
    chip_dir: Path | str,
    run_dir: Path | str,
    runner_id: Optional[str] = None,
    emit_artifact: bool = True,
) -> V10UpstreamTruthRunnerResult:
    """
    Execute the v1.0 Upstream Truth proof runner.

    Happy path: validates all 6 upstream truth steps in order.
    Negative path: returns FAIL with first blocking step recorded.

    Args:
        chip_dir:      Path to the chip workspace directory (e.g. chips/SN2025/).
        run_dir:       Path to the evidence run output directory.
        runner_id:     Optional unique ID for this run (auto-generated if None).
        emit_artifact: If True, writes the result JSON to run_dir/evidence/.

    Returns:
        V10UpstreamTruthRunnerResult with verdict, proof level, and artifact refs.
    """
    chip_dir = Path(chip_dir)
    run_dir = Path(run_dir)
    chip_id = chip_dir.name

    if runner_id is None:
        ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        runner_id = f"v10-runner-{chip_id}-{ts}"

    steps_completed: List[str] = []
    steps_failed: List[str] = []
    issues: List[str] = []
    negative_path_triggered = False
    negative_path_reason: Optional[str] = None

    # Step sequence: must pass in order (fail-fast on critical steps)
    step_validators = [
        ("requirement_intake",     _validate_requirement_intake),
        ("spec_completion",        _validate_spec_completion),
        ("architecture_graph",     _validate_architecture_graph),
        ("graph_validation",       _validate_graph_validation),
        ("graph_freeze",           _validate_freeze),
        ("graph_to_generation_plan", _validate_generation_plan),
    ]

    for step_name, validator in step_validators:
        ok, message = validator(chip_dir)
        if ok:
            steps_completed.append(f"{step_name}: {message}")
        else:
            steps_failed.append(f"{step_name}: {message}")
            issues.append(message)
            negative_path_triggered = True
            negative_path_reason = message
            # Fail-fast: downstream steps cannot be valid without upstream passing
            break

    # Derive proof level and verdict
    n_completed = len(steps_completed)
    if n_completed == 0:
        proof_level = V10ProofLevel.NONE
        verdict = V10RunnerVerdict.FAIL
    elif n_completed < 3:
        proof_level = V10ProofLevel.L1_OBJECT
        verdict = V10RunnerVerdict.PARTIAL if not negative_path_triggered else V10RunnerVerdict.FAIL
    elif n_completed < 6:
        proof_level = V10ProofLevel.L2_RUNNER
        verdict = V10RunnerVerdict.PARTIAL if not negative_path_triggered else V10RunnerVerdict.FAIL
    else:
        proof_level = V10ProofLevel.L3_SCENARIO
        verdict = V10RunnerVerdict.PASS

    gate_state = _derive_gate_state(chip_dir)

    result = V10UpstreamTruthRunnerResult(
        runner_id=runner_id,
        chip_id=chip_id,
        run_dir=str(run_dir),
        verdict=verdict,
        proof_level_achieved=proof_level,
        upstream_gate_state=gate_state,
        steps_completed=steps_completed,
        steps_failed=steps_failed,
        issues=issues,
        artifact_refs=[],
        negative_path_triggered=negative_path_triggered,
        negative_path_reason=negative_path_reason,
    )

    if emit_artifact:
        evidence_dir = run_dir / "evidence" / "v10_upstream_truth"
        evidence_dir.mkdir(parents=True, exist_ok=True)
        artifact_path = evidence_dir / f"{runner_id}.json"
        artifact_path.write_text(
            json.dumps(result.to_dict(), indent=2),
            encoding="utf-8",
        )
        result.artifact_refs.append(str(artifact_path))

    return result


# ---------------------------------------------------------------------------
# Negative Path Test Helper
# ---------------------------------------------------------------------------

def assert_v10_negative_path(chip_dir: Path | str, run_dir: Path | str) -> bool:
    """
    Negative test: run the v1.0 runner against an incomplete chip_dir.
    Asserts that verdict == FAIL and negative_path_triggered == True.
    Returns True if negative path was correctly triggered.
    """
    result = run_v10_upstream_truth(
        chip_dir=chip_dir,
        run_dir=run_dir,
        emit_artifact=False,
    )
    assert result.verdict == V10RunnerVerdict.FAIL, (
        f"Expected FAIL on negative path, got {result.verdict}"
    )
    assert result.negative_path_triggered, "Expected negative_path_triggered=True"
    return True
