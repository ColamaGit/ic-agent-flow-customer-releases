"""
R1 Runtime Proof — v1.3 Silicon Contract Runner

Risk Mitigation Plan v0.1 — R1 (P0): Runtime Proof Convergence
Governing PRD: v1.3 Silicon Contract

Purpose:
    Provides a unified, auditable runner for the v1.3 silicon contract pipeline:
      evidence_attachment → authority_binding → fail_closed_check → contract_state_transition → binder_output

Proof Ladder:
    L1 — Object Proof:  SiliconContract schema + sample
    L2 — Runner Proof:  this runner + state transitions + artifact
    L3 — Scenario Proof: happy path, negative path (evidence missing / authority not closed)

No-Proof-No-Claim Gate mapping:
    claim: "release-ready" → required proof: silicon contract binder (runner + artifact)
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import List, Optional


# ---------------------------------------------------------------------------
# Runner Result Model
# ---------------------------------------------------------------------------

class V13RunnerVerdict(str, Enum):
    PASS = "PASS"                 # contract reached APPROVED_FOR_RELEASE
    FAIL = "FAIL"                 # fail-closed triggered
    PARTIAL = "PARTIAL"           # some steps completed, blocked before approval


class V13NegativePathReason(str, Enum):
    EVIDENCE_MISSING = "EVIDENCE_MISSING"
    EVIDENCE_LINEAGE_BROKEN = "EVIDENCE_LINEAGE_BROKEN"
    AUTHORITY_CLOSURE_INCOMPLETE = "AUTHORITY_CLOSURE_INCOMPLETE"
    CHIP_IDENTITY_MISSING = "CHIP_IDENTITY_MISSING"
    DELIVERY_CLASS_UNDEFINED = "DELIVERY_CLASS_UNDEFINED"
    CRITICAL_RISK_UNRESOLVED = "CRITICAL_RISK_UNRESOLVED"
    QA_TRUST_VIOLATION = "QA_TRUST_VIOLATION"


@dataclass
class V13SiliconContractRunnerResult:
    """
    Evidence artifact produced by the v1.3 silicon contract runner.
    Constitutes L2 Runner Proof for the No-Proof-No-Claim Gate (claim: release-ready).
    """
    runner_id: str
    chip_id: str
    contract_id: str
    run_dir: str
    verdict: V13RunnerVerdict
    final_contract_status: str
    steps_completed: List[str] = field(default_factory=list)
    steps_failed: List[str] = field(default_factory=list)
    block_reasons: List[str] = field(default_factory=list)
    negative_path_triggered: bool = False
    negative_path_reasons: List[str] = field(default_factory=list)
    evidence_count: int = 0
    authority_closed: bool = False
    artifact_refs: List[str] = field(default_factory=list)
    created_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )

    def to_dict(self) -> dict:
        return {
            "runner_id": self.runner_id,
            "chip_id": self.chip_id,
            "contract_id": self.contract_id,
            "run_dir": self.run_dir,
            "verdict": self.verdict.value,
            "final_contract_status": self.final_contract_status,
            "steps_completed": self.steps_completed,
            "steps_failed": self.steps_failed,
            "block_reasons": self.block_reasons,
            "negative_path_triggered": self.negative_path_triggered,
            "negative_path_reasons": self.negative_path_reasons,
            "evidence_count": self.evidence_count,
            "authority_closed": self.authority_closed,
            "artifact_refs": self.artifact_refs,
            "created_at": self.created_at,
        }


# ---------------------------------------------------------------------------
# Lightweight Contract Input (decoupled from domain objects for runner portability)
# ---------------------------------------------------------------------------

@dataclass
class ContractInput:
    """Minimal contract input for the runner — does not require domain object imports."""
    contract_id: str
    chip_id: str
    delivery_classification: Optional[str]          # e.g. "PRODUCTION_RELEASE"
    signoff_evidence_refs: List[dict]                # list of {ref_id, uri, digest, evidence_family}
    authority_records: List[dict]                    # list of {role, id, decision}
    open_risk_refs: List[str]                        # open risk IDs blocking release
    qa_adjudication_ref: Optional[str] = None       # ref to QA trust adjudication record


# ---------------------------------------------------------------------------
# Step Validators
# ---------------------------------------------------------------------------

def _validate_chip_identity(inp: ContractInput) -> tuple[bool, str]:
    if not inp.chip_id or not inp.chip_id.strip():
        return False, f"CHIP_IDENTITY_MISSING: contract '{inp.contract_id}' has no chip_id"
    return True, f"chip_id '{inp.chip_id}' present"


def _validate_delivery_classification(inp: ContractInput) -> tuple[bool, str]:
    if not inp.delivery_classification:
        return False, f"DELIVERY_CLASS_UNDEFINED: contract '{inp.contract_id}' has no delivery_classification"
    return True, f"delivery_classification = '{inp.delivery_classification}'"


def _validate_evidence_attachment(inp: ContractInput) -> tuple[bool, str]:
    if not inp.signoff_evidence_refs:
        return False, "EVIDENCE_MISSING: no signoff_evidence_refs attached"

    issues = []
    for ref in inp.signoff_evidence_refs:
        if not ref.get("digest"):
            issues.append(f"ref '{ref.get('ref_id', '?')}' has no digest — lineage broken")
        if inp.chip_id and inp.chip_id not in ref.get("uri", ""):
            issues.append(
                f"ref '{ref.get('ref_id', '?')}' uri does not contain chip_id '{inp.chip_id}'"
            )

    if issues:
        return False, "EVIDENCE_LINEAGE_BROKEN: " + "; ".join(issues)
    return True, f"{len(inp.signoff_evidence_refs)} evidence ref(s) attached and scoped"


def _validate_authority_closure(inp: ContractInput) -> tuple[bool, str]:
    if not inp.authority_records:
        return False, "AUTHORITY_CLOSURE_INCOMPLETE: no authority_records present"

    pending = [
        r.get("role", "?")
        for r in inp.authority_records
        if r.get("decision") not in ("APPROVED", "APPROVED_WITH_CONDITIONS")
    ]
    if pending:
        return False, f"AUTHORITY_CLOSURE_INCOMPLETE: pending roles = {pending}"
    return True, f"all {len(inp.authority_records)} authority role(s) closed"


def _validate_open_risks(inp: ContractInput) -> tuple[bool, str]:
    if inp.open_risk_refs:
        return False, f"CRITICAL_RISK_UNRESOLVED: open risks = {inp.open_risk_refs}"
    return True, "no open risks blocking release"


def _validate_qa_adjudication(inp: ContractInput) -> tuple[bool, str]:
    if not inp.qa_adjudication_ref:
        return False, "QA_TRUST_VIOLATION: qa_adjudication_ref not attached to contract"
    return True, f"QA adjudication ref = '{inp.qa_adjudication_ref}'"


# ---------------------------------------------------------------------------
# Runner Entry Point
# ---------------------------------------------------------------------------

def run_v13_silicon_contract(
    *,
    contract_input: ContractInput,
    run_dir: Path | str,
    runner_id: Optional[str] = None,
    emit_artifact: bool = True,
) -> V13SiliconContractRunnerResult:
    """
    Execute the v1.3 Silicon Contract proof runner.

    Happy path: validates chip identity → delivery classification → evidence attachment
                → authority closure → open risks → QA adjudication → APPROVED_FOR_RELEASE.
    Negative path: returns FAIL with first blocking reason recorded.

    Args:
        contract_input:  ContractInput dataclass populated with contract data.
        run_dir:         Path to the evidence run output directory.
        runner_id:       Optional unique ID for this run.
        emit_artifact:   If True, writes the result JSON to run_dir/evidence/.

    Returns:
        V13SiliconContractRunnerResult with verdict, block reasons, and artifact refs.
    """
    run_dir = Path(run_dir)
    chip_id = contract_input.chip_id
    contract_id = contract_input.contract_id

    if runner_id is None:
        ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        runner_id = f"v13-runner-{chip_id}-{ts}"

    steps_completed: List[str] = []
    steps_failed: List[str] = []
    block_reasons: List[str] = []
    negative_path_reasons: List[str] = []

    step_validators = [
        ("chip_identity",          _validate_chip_identity),
        ("delivery_classification", _validate_delivery_classification),
        ("evidence_attachment",    _validate_evidence_attachment),
        ("authority_closure",      _validate_authority_closure),
        ("open_risks",             _validate_open_risks),
        ("qa_adjudication",        _validate_qa_adjudication),
    ]

    for step_name, validator in step_validators:
        ok, message = validator(contract_input)
        if ok:
            steps_completed.append(f"{step_name}: {message}")
        else:
            steps_failed.append(f"{step_name}: {message}")
            block_reasons.append(message)
            negative_path_reasons.append(message)

    # Determine final contract status
    negative_path_triggered = len(steps_failed) > 0
    authority_closed = not any(
        "AUTHORITY_CLOSURE_INCOMPLETE" in r for r in block_reasons
    )
    evidence_count = len(contract_input.signoff_evidence_refs)

    if not negative_path_triggered:
        final_status = "APPROVED_FOR_RELEASE"
        verdict = V13RunnerVerdict.PASS
    elif len(steps_completed) == 0:
        final_status = "DRAFT"
        verdict = V13RunnerVerdict.FAIL
    else:
        # Map first block to status
        first_block = block_reasons[0] if block_reasons else ""
        if "EVIDENCE" in first_block:
            final_status = "EVIDENCE_INCOMPLETE"
        elif "AUTHORITY" in first_block:
            final_status = "AUTHORITY_PENDING"
        elif "CRITICAL_RISK" in first_block or "QA_TRUST" in first_block:
            final_status = "HOLD"
        else:
            final_status = "UNDER_REVIEW"
        verdict = V13RunnerVerdict.FAIL

    result = V13SiliconContractRunnerResult(
        runner_id=runner_id,
        chip_id=chip_id,
        contract_id=contract_id,
        run_dir=str(run_dir),
        verdict=verdict,
        final_contract_status=final_status,
        steps_completed=steps_completed,
        steps_failed=steps_failed,
        block_reasons=block_reasons,
        negative_path_triggered=negative_path_triggered,
        negative_path_reasons=negative_path_reasons,
        evidence_count=evidence_count,
        authority_closed=authority_closed,
        artifact_refs=[],
    )

    if emit_artifact:
        evidence_dir = run_dir / "evidence" / "v13_silicon_contract"
        evidence_dir.mkdir(parents=True, exist_ok=True)
        artifact_path = evidence_dir / f"{runner_id}.json"
        artifact_path.write_text(
            json.dumps(result.to_dict(), indent=2),
            encoding="utf-8",
        )
        result.artifact_refs.append(str(artifact_path))

    return result


# ---------------------------------------------------------------------------
# Negative Path Test Helpers
# ---------------------------------------------------------------------------

def assert_v13_negative_path_evidence_missing(run_dir: Path | str) -> bool:
    """
    Negative test: contract with no evidence refs → FAIL with EVIDENCE_MISSING.
    """
    inp = ContractInput(
        contract_id="neg-test-evidence-missing",
        chip_id="SN2025",
        delivery_classification="PRODUCTION_RELEASE",
        signoff_evidence_refs=[],   # intentionally empty
        authority_records=[{"role": "chip_program_director", "decision": "APPROVED"}],
        open_risk_refs=[],
        qa_adjudication_ref="qa-adj-001",
    )
    result = run_v13_silicon_contract(
        contract_input=inp,
        run_dir=run_dir,
        emit_artifact=False,
    )
    assert result.verdict == V13RunnerVerdict.FAIL
    assert any("EVIDENCE_MISSING" in r for r in result.block_reasons)
    return True


def assert_v13_negative_path_authority_incomplete(run_dir: Path | str) -> bool:
    """
    Negative test: contract with no authority closure → FAIL with AUTHORITY_CLOSURE_INCOMPLETE.
    """
    inp = ContractInput(
        contract_id="neg-test-authority-incomplete",
        chip_id="SN2025",
        delivery_classification="PRODUCTION_RELEASE",
        signoff_evidence_refs=[
            {"ref_id": "ev-001", "uri": "chips/SN2025/evidence/sim.json", "digest": "abc123", "evidence_family": "SIMULATION"}
        ],
        authority_records=[{"role": "chip_program_director", "decision": "PENDING"}],  # not closed
        open_risk_refs=[],
        qa_adjudication_ref="qa-adj-001",
    )
    result = run_v13_silicon_contract(
        contract_input=inp,
        run_dir=run_dir,
        emit_artifact=False,
    )
    assert result.verdict == V13RunnerVerdict.FAIL
    assert any("AUTHORITY_CLOSURE_INCOMPLETE" in r for r in result.block_reasons)
    return True
