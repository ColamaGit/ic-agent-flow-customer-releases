from __future__ import annotations

from pydantic import BaseModel


V12_RESPONSIBILITIES = (
    "ecosystem_boundary",
    "external_asset_adjudication",
    "customer_update_propagation",
)

V12_EXCLUDED_RESPONSIBILITIES = (
    "v1.0_upstream_truth_layer",
    "v1.1_internal_knowledge_flywheel",
    "v1.3_silicon_contract_release_authority",
)

V12_SHARE_SCOPE_CLASSES = (
    "customer_local_only",
    "customer_approved_sanitized_candidate",
    "partner_shared",
    "upstream_canonical_candidate",
)

V12_FIRST_WAVE_EXTERNAL_ASSET_FAMILIES = (
    "review_checklist_delta",
    "ambiguity_pattern",
    "timing_completeness_pattern",
    "verification_failure_pattern",
)

SANITIZATION_LEVELS = (
    "none",
    "basic",
    "strict",
)

CONFIDENTIALITY_DECLARATIONS = (
    "sanitized_no_customer_identity",
    "sanitized_with_limited_context",
)

V12_CONFIDENTIALITY_RISK_FLAGS = (
    "customer_identity_leakage",
    "chip_project_trace_leakage",
    "product_codename_leakage",
    "proprietary_architecture_leakage",
    "foundry_pdk_sensitive_context_leakage",
)

V12_ADJUDICATION_REVIEW_ROLES = (
    "governance_reviewer",
    "domain_reviewer",
    "canonical_approver",
)

V12_ADJUDICATION_DECISION_VOCAB = (
    "reject",
    "accept_local_reference_only",
    "accept_partner_scope",
    "accept_shared_noncanonical",
    "promote_canonical",
    "promote_canonical_with_conditions",
)

V12_RELEASE_CHANNELS = (
    "advisory_feed",
    "approved_pack_sync",
    "managed_upgrade_path",
)

V12_RECOMMENDED_ADOPTION_MODES = (
    "adopt_after_local_review",
    "defer",
    "reject",
    "override",
)

V12_CUSTOMER_ADOPTION_DECISIONS = (
    "accept",
    "defer",
    "reject",
    "override",
)


class CustomerAssetScopeRecord(BaseModel):
    record_id: str
    asset_ref: str
    scope_class: str
    share_back_intent: bool = False
    customer_approval_ref: str | None = None
    sanitization_level: str = "none"
    source_family: str
    created_at: str


class ExternalAssetSubmissionRecord(BaseModel):
    submission_id: str
    asset_ref: str
    source_scope_class: str
    source_family: str
    share_back_intent: bool
    customer_approval_ref: str | None = None
    sanitization_level: str
    confidentiality_declaration: str
    submitted_by: str
    submitted_at: str
    evidence_refs: list[str]


class ExternalConfidentialityReviewRecord(BaseModel):
    review_id: str
    submission_ref: str
    status: str
    risk_flags: list[str]
    rejection_reasons: list[str]
    downgraded_scope_class: str | None = None
    requires_resubmission: bool = False
    reviewed_at: str


class ExternalAssetAdjudicationRecord(BaseModel):
    adjudication_id: str
    submission_ref: str
    confidentiality_review_ref: str
    final_decision: str
    registry_target: str
    reviewer_roles: list[str]
    rejection_reasons: list[str]
    conditions: list[str]
    created_at: str


class ExternalAssetPlacementRecord(BaseModel):
    placement_id: str
    asset_ref: str
    submission_ref: str
    adjudication_ref: str
    registry_scope: str
    status: str
    lineage_refs: list[str]
    placed_at: str


class ExternalAssetPlacementAuditRecord(BaseModel):
    audit_id: str
    submission_ref: str
    adjudication_ref: str
    requested_target: str
    outcome: str
    reasons: list[str]
    created_at: str


class SharedAssetPackRelease(BaseModel):
    release_id: str
    version: str
    channel: str
    asset_refs: list[str]
    placement_refs: list[str]
    release_notes: list[str]
    compatibility_scope: str
    recommended_adoption_mode: str
    breaking_change: bool
    created_at: str


class CustomerPackAdoptionRecord(BaseModel):
    record_id: str
    customer_id: str
    release_id: str
    pack_version: str
    decision: str
    reviewer_ref: str
    rationale: str
    override_ref: str | None = None
    active: bool
    reviewed_at: str


def can_leave_customer_boundary(record: CustomerAssetScopeRecord) -> bool:
    if record.scope_class == "customer_local_only":
        return False
    if not record.share_back_intent:
        return False
    if not (record.customer_approval_ref or "").strip():
        return False
    if record.sanitization_level not in {"basic", "strict"}:
        return False
    return True
