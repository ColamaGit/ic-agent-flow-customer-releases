from __future__ import annotations

from pydantic import BaseModel


V14_RESPONSIBILITIES = (
    "evidence_trust_evaluation",
    "scenario_trust_validation",
    "claim_scope_governance",
    "review_signal_surfacing",
)

V14_EXCLUDED_RESPONSIBILITIES = (
    "v1.0_upstream_truth_generation",
    "v1.3_release_authority_decision",
    "parallel_truth_source_creation",
)

V14_OBJECT_FAMILIES = (
    "qa_assessment_run",
    "evidence_quality_report",
    "scenario_validation_report",
    "claim_scope_assessment",
    "qa_adjudication_record",
)

V14_VERDICT_VOCAB = (
    "ACCEPTABLE",
    "INSUFFICIENT_EVIDENCE",
    "LINEAGE_BROKEN",
    "SCENARIO_GAP",
    "OVERBROAD_CLAIM",
    "REVIEW_SURFACE_WEAK",
)

V14_RECOMMENDATION_VOCAB = (
    "PROCEED",
    "HOLD",
    "REJECT",
    "REQUEST_MORE_EVIDENCE",
)


class QARef(BaseModel):
    ref_id: str
    ref_type: str
    uri: str
    digest: str | None = None


class QATargetScope(BaseModel):
    workspace_id: str
    chip_id: str
    prd_scope: str


class QAAssessmentRun(BaseModel):
    id: str
    type: str = "qa_assessment_run"
    version: str = "0.1"
    target_scope: QATargetScope
    started_at: str
    completed_at: str | None = None
    producer: str
    input_refs: list[QARef]
    output_refs: list[QARef] = []


class EvidenceQualityReport(BaseModel):
    id: str
    type: str = "evidence_quality_report"
    version: str = "0.1"
    qa_run_ref: str
    artifact_refs: list[QARef]
    raw_artifact_status: str = "PRESENT"
    normalized_mapping_status: str = "MATCHED"
    lineage_status: str
    integrity_status: str
    missing_artifacts: list[str] = []
    issues: list[str] = []
    verdict: str


class ScenarioCoverageSummary(BaseModel):
    covered_paths: int
    required_paths: int


class ScenarioValidationReport(BaseModel):
    id: str
    type: str = "scenario_validation_report"
    version: str = "0.1"
    qa_run_ref: str
    scenario_id: str
    scenario_name: str
    happy_path_status: str
    negative_path_status: str
    reentry_status: str
    fail_closed_status: str
    coverage_summary: ScenarioCoverageSummary
    evidence_refs: list[QARef]
    gaps: list[str] = []
    verdict: str


class ClaimSource(BaseModel):
    source_type: str
    uri: str


class ClaimAssessmentItem(BaseModel):
    claim_id: str
    claim_text: str
    prd_boundary: str
    supporting_evidence_refs: list[QARef]
    scope_status: str


class ClaimScopeAssessment(BaseModel):
    id: str
    type: str = "claim_scope_assessment"
    version: str = "0.1"
    qa_run_ref: str
    claim_source: ClaimSource
    claims: list[ClaimAssessmentItem]
    unsupported_claims: list[str] = []
    verdict: str


class QAAdjudicator(BaseModel):
    role: str
    id: str


class QAAdjudicationRecord(BaseModel):
    id: str
    type: str = "qa_adjudication_record"
    version: str = "0.1"
    qa_run_ref: str
    input_report_refs: list[QARef]
    combined_verdict: str
    recommendation: str
    blocking_issues: list[str]
    non_blocking_warnings: list[str]
    created_at: str
    adjudicator: QAAdjudicator
