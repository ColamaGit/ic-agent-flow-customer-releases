from __future__ import annotations

from enum import Enum
from typing import List

from pydantic import BaseModel, Field


V11_RESPONSIBILITIES = (
    "knowledge_asset_extraction",
    "asset_promotion",
    "shared_asset_compounding",
)

V11_EXCLUDED_RESPONSIBILITIES = (
    "v1.0_upstream_truth_freeze",
    "v1.2_external_contribution_taxonomy_authority",
    "v1.2_customer_adoption_mode_authority",
    "v1.3_silicon_contract_release_authority",
)

V11_LOOP_MODEL = (
    "project_execution_loop",
    "asset_extraction_loop",
    "shared_evolution_loop",
)

V11_SHARED_SCOPE_LEVELS = (
    "project_private",
    "team_shared",
    "org_shared",
    "canonical_shared",
)

V11_FIRST_WAVE_EVENT_TYPES = (
    "ambiguity_clarification",
    "verification_failure",
    "timing_completeness_correction",
    "decision_rationale",
    "eco_root_cause_pattern",
)

V11_OBJECT_FAMILIES = (
    "knowledge_asset",
    "asset_promotion_record",
    "shared_asset_registry_record",
    "asset_consumption_record",
    "asset_impact_record",
)

PROMOTION_DECISION_VOCAB = (
    "reject",
    "keep_project_private",
    "share_team_scope",
    "share_org_scope",
    "promote_canonical",
    "promote_with_conditions",
)


class KnowledgeAssetLifecycleState(str, Enum):
    RAW_EVENT = "raw_event"
    NORMALIZED_PROJECT_ASSET = "normalized_project_asset"
    REUSABLE_SHARED_ASSET = "reusable_shared_asset"
    GOVERNED_CANONICAL_ASSET = "governed_canonical_asset"
    DEPRECATED = "deprecated"
    SUPERSEDED = "superseded"
    RETIRED = "retired"


class KnowledgeAsset(BaseModel):
    asset_id: str
    asset_type: str = "knowledge_asset"
    lifecycle_state: KnowledgeAssetLifecycleState
    source_event_type: str
    project_ref: str
    scope_level: str
    summary: str
    source_event_refs: List[str] = Field(default_factory=list)
    evidence_refs: List[str] = Field(default_factory=list)
    tags: List[str] = Field(default_factory=list)


class AssetPromotionRecord(BaseModel):
    record_id: str
    asset_ref: str
    decision: str
    decision_rationale: str
    reviewer_refs: List[str] = Field(default_factory=list)
    conditions: List[str] = Field(default_factory=list)
    target_scope_level: str
    evidence_refs: List[str] = Field(default_factory=list)
    created_at: str


class SharedAssetRegistryRecord(BaseModel):
    registry_id: str
    asset_ref: str
    scope_level: str
    status: str
    taxonomy_path: str
    current_version: str
    supersedes_refs: List[str] = Field(default_factory=list)
    lineage_refs: List[str] = Field(default_factory=list)
    created_at: str


class AssetConsumptionRecord(BaseModel):
    record_id: str
    asset_ref: str
    consumer_project_ref: str
    usage_context: str
    consumed_at: str
    input_binding_refs: List[str] = Field(default_factory=list)
    outcome_refs: List[str] = Field(default_factory=list)


class AssetImpactRecord(BaseModel):
    record_id: str
    asset_ref: str
    measured_window: str
    impact_summary: str
    delta_metrics: dict
    evidence_refs: List[str] = Field(default_factory=list)
    measured_at: str


def is_valid_promotion_decision(decision: str) -> bool:
    return decision in PROMOTION_DECISION_VOCAB


def allows_shared_registry_write(decision: str) -> bool:
    return decision in {
        "share_team_scope",
        "share_org_scope",
        "promote_canonical",
        "promote_with_conditions",
    }

