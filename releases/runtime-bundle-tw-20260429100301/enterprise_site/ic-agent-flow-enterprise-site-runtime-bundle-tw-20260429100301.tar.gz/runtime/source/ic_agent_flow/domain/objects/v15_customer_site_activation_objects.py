from __future__ import annotations

from typing import List, Literal

from pydantic import Field

from ic_agent_flow.domain.objects.deployment_packaging_objects import (
    DeliveryObjectBase,
)


V15_RESPONSIBILITIES = (
    "customer_site_activation",
    "deployment_profile_activation_binding",
    "customer_org_operating_model",
    "site_operations_governance",
)

V15_OBJECT_FAMILIES = (
    "site_activation_request",
    "site_environment_fingerprint",
    "trust_root_binding",
    "deployment_profile_binding",
    "site_policy_overlay_binding",
    "bootstrap_run_record",
    "site_preflight_report",
    "site_smoke_run_record",
    "site_readiness_report",
    "activation_decision_record",
    "site_runtime_manifest",
    "site_support_boundary_record",
    "environment_drift_record",
    "customer_operations_surface_snapshot",
    "customer_operations_surface_audit_record",
)

V15_CUSTOMER_OPERATING_MODES = (
    "solo_eval",
    "team_project",
    "enterprise_site",
)

V15_SITE_ACTIVATION_STATES = (
    "PACKAGE_RECEIVED",
    "PACKAGE_VERIFIED",
    "PROFILE_BOUND",
    "POLICY_BOUND",
    "PREFLIGHT_RUNNING",
    "PREFLIGHT_PASSED",
    "PREFLIGHT_BLOCKED",
    "SMOKE_RUNNING",
    "READY_FOR_ACTIVATION_REVIEW",
    "ACTIVE",
    "HOLD",
    "REJECTED",
    "ROLLBACK_REQUIRED",
    "ARCHIVED",
)

V15_READINESS_VERDICTS = (
    "PASS",
    "PASS_WITH_WARNINGS",
    "BLOCKED",
    "HUMAN_REVIEW_REQUIRED",
    "ROLLBACK_RECOMMENDED",
)

V15_ACTIVATION_DECISIONS = (
    "APPROVE_ACTIVATION",
    "APPROVE_WITH_CONDITIONS",
    "HOLD_ACTIVATION",
    "REJECT_ACTIVATION",
    "REQUEST_MORE_EVIDENCE",
    "ROLLBACK_REQUIRED",
    "ESCALATE_TO_SECURITY",
)


class SiteActivationRequest(DeliveryObjectBase):
    type: str = "site_activation_request"
    site_id: str
    bundle_ref: str
    profile_ref: str
    requested_mode: Literal["solo_eval", "team_project", "enterprise_site"]
    customer_authority_ref: str
    requested_state: Literal[
        "PACKAGE_RECEIVED",
        "PACKAGE_VERIFIED",
        "PROFILE_BOUND",
        "POLICY_BOUND",
        "PREFLIGHT_RUNNING",
        "PREFLIGHT_PASSED",
        "PREFLIGHT_BLOCKED",
        "SMOKE_RUNNING",
        "READY_FOR_ACTIVATION_REVIEW",
        "ACTIVE",
        "HOLD",
        "REJECTED",
        "ROLLBACK_REQUIRED",
        "ARCHIVED",
    ] = "PACKAGE_RECEIVED"


class SiteEnvironmentFingerprint(DeliveryObjectBase):
    type: str = "site_environment_fingerprint"
    site_id: str
    os_family: str
    machine_arch: str
    runtime_version: str
    profile_ref: str


class TrustRootBinding(DeliveryObjectBase):
    type: str = "trust_root_binding"
    site_id: str
    bundle_ref: str
    trust_root_ref: str
    binding_status: str
    blocking_reasons: List[str] = Field(default_factory=list)


class DeploymentProfileBinding(DeliveryObjectBase):
    type: str = "deployment_profile_binding"
    site_id: str
    bundle_ref: str
    profile_ref: str
    binding_status: str
    forbidden_capabilities: List[str] = Field(default_factory=list)
    blocking_reasons: List[str] = Field(default_factory=list)


class SitePolicyOverlayBinding(DeliveryObjectBase):
    type: str = "site_policy_overlay_binding"
    site_id: str
    profile_ref: str
    policy_overlay_ref: str | None = None
    binding_status: str
    blocking_reasons: List[str] = Field(default_factory=list)


class BootstrapRunRecord(DeliveryObjectBase):
    type: str = "bootstrap_run_record"
    site_id: str
    activation_request_ref: str
    mode: Literal["solo_eval", "team_project", "enterprise_site"]
    dry_run: bool = False
    result: str


class SitePreflightReport(DeliveryObjectBase):
    type: str = "site_preflight_report"
    site_id: str
    activation_request_ref: str
    checks_passed: List[str] = Field(default_factory=list)
    checks_failed: List[str] = Field(default_factory=list)
    verdict: Literal["PASS", "PASS_WITH_WARNINGS", "BLOCKED", "HUMAN_REVIEW_REQUIRED", "ROLLBACK_RECOMMENDED"]


class SiteSmokeRunRecord(DeliveryObjectBase):
    type: str = "site_smoke_run_record"
    site_id: str
    activation_request_ref: str
    scenario_id: str
    verdict: Literal["PASS", "PASS_WITH_WARNINGS", "BLOCKED", "HUMAN_REVIEW_REQUIRED", "ROLLBACK_RECOMMENDED"]
    evidence_refs: List[str] = Field(default_factory=list)


class SiteReadinessReport(DeliveryObjectBase):
    type: str = "site_readiness_report"
    site_id: str
    activation_request_ref: str
    readiness_verdict: Literal[
        "PASS",
        "PASS_WITH_WARNINGS",
        "BLOCKED",
        "HUMAN_REVIEW_REQUIRED",
        "ROLLBACK_RECOMMENDED",
    ]
    blocked_reasons: List[str] = Field(default_factory=list)


class ActivationDecisionRecord(DeliveryObjectBase):
    type: str = "activation_decision_record"
    site_id: str
    site_activation_request_ref: str = Field(default="")
    readiness_report_ref: str
    actor: str
    role: str = Field(default="Customer Approver")
    authority_scope: str = Field(default="")
    decision: Literal[
        "APPROVE_ACTIVATION",
        "APPROVE_WITH_CONDITIONS",
        "HOLD_ACTIVATION",
        "REJECT_ACTIVATION",
        "REQUEST_MORE_EVIDENCE",
        "ROLLBACK_REQUIRED",
        "ESCALATE_TO_SECURITY"
    ]
    conditions: List[str] = Field(default_factory=list)
    required_followups: List[str] = Field(default_factory=list)
    audit_refs: List[str] = Field(default_factory=list)
    decided_by: str = Field(default="")  # legacy field mapping to actor


class SiteRuntimeManifest(DeliveryObjectBase):
    type: str = "site_runtime_manifest"
    site_id: str
    installed_bundle_ref: str
    active_profile_ref: str
    policy_overlay_refs: List[str] = Field(default_factory=list)
    active_mode: Literal["solo_eval", "team_project", "enterprise_site"]


class SiteSupportBoundaryRecord(DeliveryObjectBase):
    type: str = "site_support_boundary_record"
    site_id: str
    support_owner_ref: str
    export_classification: str
    allowed_exports: List[str] = Field(default_factory=list)


class EnvironmentDriftRecord(DeliveryObjectBase):
    type: str = "environment_drift_record"
    site_id: str
    manifest_ref: str
    drift_detected: bool
    drift_items: List[str] = Field(default_factory=list)
    verified_at: str


class CustomerOperationsSurfaceSnapshot(DeliveryObjectBase):
    type: str = "customer_operations_surface_snapshot"
    site_id: str
    installed_version: str
    active_profile_ref: str
    policy_overlay_refs: List[str] = Field(default_factory=list)
    trust_root_ref: str
    enabled_capabilities: List[str] = Field(default_factory=list)
    forbidden_capabilities: List[str] = Field(default_factory=list)
    role_grant_refs: List[str] = Field(default_factory=list)
    pending_activation_decision_refs: List[str] = Field(default_factory=list)
    support_export_status: str
    upgrade_rollback_status: str
    update_adoption_status: str
    audit_replay_refs: List[str] = Field(default_factory=list)
    source_object_refs: List[str] = Field(default_factory=list)


class CustomerOperationsSurfaceAuditRecord(DeliveryObjectBase):
    type: str = "customer_operations_surface_audit_record"
    site_id: str
    action: str
    actor: str
    actor_role: str
    mutation_requested: bool
    mutation_allowed: bool
    produced_object_refs: List[str] = Field(default_factory=list)
    audit_refs: List[str] = Field(default_factory=list)
    blocked_reasons: List[str] = Field(default_factory=list)
