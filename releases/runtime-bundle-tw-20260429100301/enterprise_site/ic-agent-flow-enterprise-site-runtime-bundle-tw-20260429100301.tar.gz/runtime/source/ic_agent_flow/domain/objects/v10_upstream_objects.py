from __future__ import annotations

from enum import Enum
from typing import List

from pydantic import BaseModel, Field


V10_RESPONSIBILITIES = (
    "spec_completion",
    "architecture_graph",
    "upstream_truth_freeze",
)

V10_EXCLUDED_RESPONSIBILITIES = (
    "v1.1_knowledge_flywheel",
    "v1.1_asset_extraction",
    "v1.2_propagation_taxonomy",
    "v1.2_ecosystem_boundary",
    "v1.3_silicon_contract",
    "v1.3_controlled_release",
    "v1.3_delivery_boundary",
)

V10_CANONICAL_OBJECT_FAMILIES = (
    "requirement_item",
    "design_spec",
    "spec_completeness_report",
    "requirement_freeze_record",
    "architecture_graph",
    "graph_validation_result",
    "graph_issue",
    "validator_run_record",
    "interface_binding_record",
    "graph_freeze_record",
    "graph_to_generation_plan",
)

V10_DOWNSTREAM_CONSUMABLE_OBJECTS = (
    "design_spec",
    "architecture_graph",
    "graph_validation_result",
    "graph_freeze_record",
    "graph_to_generation_plan",
)

GRAPH_REVIEW_DECISION_VOCAB = (
    "approve",
    "approve_with_conditions",
    "hold",
    "reject",
    "request_more_evidence",
    "escalate",
)


class GraphValidationVerdict(str, Enum):
    PASS = "PASS"
    PASS_WITH_WARNINGS = "PASS_WITH_WARNINGS"
    BLOCKED = "BLOCKED"
    INVALID = "INVALID"


FAIL_CLOSED_GRAPH_VERDICTS = {
    GraphValidationVerdict.BLOCKED,
    GraphValidationVerdict.INVALID,
}


def is_fail_closed_graph_verdict(verdict: GraphValidationVerdict) -> bool:
    return verdict in FAIL_CLOSED_GRAPH_VERDICTS


def is_downstream_consumable_object(object_type: str) -> bool:
    return object_type in V10_DOWNSTREAM_CONSUMABLE_OBJECTS


def decision_allows_freeze_transition(
    decision: str,
    verdict: GraphValidationVerdict,
) -> bool:
    """
    Freeze transition binding for Route A:
    - Validation verdict must not be fail-closed (BLOCKED/INVALID)
    - Decision must be approve or approve_with_conditions
    """
    if decision not in GRAPH_REVIEW_DECISION_VOCAB:
        return False
    if is_fail_closed_graph_verdict(verdict):
        return False
    return decision in {"approve", "approve_with_conditions"}


class GraphIssue(BaseModel):
    issue_id: str
    graph_ref: str
    issue_type: str
    severity: str
    location_ref: str
    description: str
    blocking: bool
    suggested_resolution: str
    status: str
    created_at: str


class GraphValidationResult(BaseModel):
    graph_ref: str
    verdict: GraphValidationVerdict
    validator_run_refs: List[str] = Field(default_factory=list)
    issue_refs: List[str] = Field(default_factory=list)

    @property
    def freeze_candidate(self) -> bool:
        return not is_fail_closed_graph_verdict(self.verdict)
