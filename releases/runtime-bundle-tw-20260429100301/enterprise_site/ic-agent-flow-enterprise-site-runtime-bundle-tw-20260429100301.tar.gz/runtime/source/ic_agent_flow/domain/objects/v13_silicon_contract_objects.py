"""
PRD v1.3 — Silicon Contract & Controlled Release Baseline
Object Family v0.1

Governing PRD: workspace/docs/prd/PRD v1.3 — Silicon Contract & Controlled Release Baseline.md
Schema Pack:   workspace/docs/prd/Silicon Contract JSON Schema Pack v0.1.md

Design Laws enforced here:
  - Law 1: silicon_contract is a governance object (versioned, replayable, auditable)
  - Law 4: Draft vs Authority separation is mandatory
  - Law 6: Contract must fail-closed
  - Law 7: Delivery boundary must be explicit
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import List, Optional


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class ContractStatus(str, Enum):
    DRAFT = "DRAFT"
    UNDER_REVIEW = "UNDER_REVIEW"
    EVIDENCE_INCOMPLETE = "EVIDENCE_INCOMPLETE"
    AUTHORITY_PENDING = "AUTHORITY_PENDING"
    HOLD = "HOLD"
    REJECTED = "REJECTED"
    APPROVED_FOR_RELEASE = "APPROVED_FOR_RELEASE"
    ARCHIVED = "ARCHIVED"


class DeliveryClass(str, Enum):
    INTERNAL_ONLY = "INTERNAL_ONLY"
    CUSTOMER_REVIEWABLE = "CUSTOMER_REVIEWABLE"
    FOUNDRY_DELIVERABLE = "FOUNDRY_DELIVERABLE"
    AUDIT_ONLY = "AUDIT_ONLY"
    ARCHIVE_ONLY = "ARCHIVE_ONLY"


class AuthorityRole(str, Enum):
    CHIP_PROGRAM_OWNER = "CHIP_PROGRAM_OWNER"
    SIGNOFF_OWNER = "SIGNOFF_OWNER"
    TAPEOUT_OWNER = "TAPEOUT_OWNER"
    AUDITOR = "AUDITOR"
    RELEASE_MANAGER = "RELEASE_MANAGER"


class AuthorityStatus(str, Enum):
    PENDING = "PENDING"
    ACKNOWLEDGED = "ACKNOWLEDGED"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"
    ESCALATED = "ESCALATED"


class BlockReason(str, Enum):
    CHIP_IDENTITY_MISSING = "CHIP_IDENTITY_MISSING"
    EVIDENCE_MISSING = "EVIDENCE_MISSING"
    EVIDENCE_LINEAGE_BROKEN = "EVIDENCE_LINEAGE_BROKEN"
    AUTHORITY_CLOSURE_INCOMPLETE = "AUTHORITY_CLOSURE_INCOMPLETE"
    PACKAGE_REFS_UNVERIFIABLE = "PACKAGE_REFS_UNVERIFIABLE"
    DELIVERY_CLASS_UNDEFINED = "DELIVERY_CLASS_UNDEFINED"
    CRITICAL_RISK_UNRESOLVED = "CRITICAL_RISK_UNRESOLVED"
    CONFLICT_UNRESOLVED = "CONFLICT_UNRESOLVED"
    QA_TRUST_VIOLATION = "QA_TRUST_VIOLATION"


class ReleaseDisposition(str, Enum):
    PROCEED = "PROCEED"
    HOLD = "HOLD"
    REJECT = "REJECT"
    REQUIRE_MORE_EVIDENCE = "REQUIRE_MORE_EVIDENCE"
    ESCALATE = "ESCALATE"


class EvidenceFamily(str, Enum):
    SIMULATION = "SIMULATION"
    FORMAL_EQUIVALENCE = "FORMAL_EQUIVALENCE"
    STA_TIMING = "STA_TIMING"
    DRC_LVS = "DRC_LVS"
    PPA = "PPA"
    ECO_LEGALITY = "ECO_LEGALITY"
    DECISION_CHAIN = "DECISION_CHAIN"
    EXCEPTION_WAIVER = "EXCEPTION_WAIVER"


class SectionStatus(str, Enum):
    PENDING = "PENDING"
    ACKNOWLEDGED = "ACKNOWLEDGED"
    APPROVED = "APPROVED"
    APPROVED_WITH_CONDITIONS = "APPROVED_WITH_CONDITIONS"
    HOLD = "HOLD"
    REJECTED = "REJECTED"


class AcknowledgementDecision(str, Enum):
    ACCEPTED = "ACCEPTED"
    WAIVED = "WAIVED"
    DEFERRED = "DEFERRED"
    ESCALATED = "ESCALATED"


# ---------------------------------------------------------------------------
# Vocab Constants
# ---------------------------------------------------------------------------

V13_MANDATORY_AUTHORITY_ROLES: List[AuthorityRole] = [
    AuthorityRole.CHIP_PROGRAM_OWNER,
    AuthorityRole.SIGNOFF_OWNER,
]

V13_ALL_AUTHORITY_ROLES: List[AuthorityRole] = [
    AuthorityRole.CHIP_PROGRAM_OWNER,
    AuthorityRole.SIGNOFF_OWNER,
    AuthorityRole.TAPEOUT_OWNER,
    AuthorityRole.AUDITOR,
    AuthorityRole.RELEASE_MANAGER,
]

V13_MANDATORY_EVIDENCE_FAMILIES: List[EvidenceFamily] = [
    EvidenceFamily.SIMULATION,
    EvidenceFamily.DRC_LVS,
]

V13_CONDITIONAL_EVIDENCE_FAMILIES: List[EvidenceFamily] = [
    EvidenceFamily.FORMAL_EQUIVALENCE,
    EvidenceFamily.STA_TIMING,
    EvidenceFamily.PPA,
    EvidenceFamily.ECO_LEGALITY,
]

V13_AGENT_ALLOWED_ACTIONS = frozenset([
    "gather_artifacts",
    "detect_missing_items",
    "assemble_draft_contract",
    "validate_completeness",
])

V13_AGENT_PROHIBITED_ACTIONS = frozenset([
    "accept_final_risk",
    "approve_waiver",
    "declare_final_release",
    "overwrite_authority_conflict",
])

# Delivery boundary law: which content can appear in which package classes
V13_DELIVERY_BOUNDARY_MAP = {
    "workspace_internal": [DeliveryClass.INTERNAL_ONLY],
    "normalized_evidence": [DeliveryClass.CUSTOMER_REVIEWABLE, DeliveryClass.AUDIT_ONLY],
    "final_gds": [DeliveryClass.FOUNDRY_DELIVERABLE],
    "audit_chain": [DeliveryClass.AUDIT_ONLY, DeliveryClass.ARCHIVE_ONLY],
}


# ---------------------------------------------------------------------------
# Shared sub-objects
# ---------------------------------------------------------------------------

@dataclass
class EvidenceRef:
    ref_id: str
    ref_type: str
    uri: str
    digest: Optional[str] = None
    evidence_family: Optional[EvidenceFamily] = None


@dataclass
class AuthorityBinding:
    role: AuthorityRole
    required: bool
    status: AuthorityStatus = AuthorityStatus.PENDING
    actor_id: Optional[str] = None
    decision_ref: Optional[str] = None
    timestamp: Optional[datetime] = None


# ---------------------------------------------------------------------------
# Primary Object: silicon_contract
# ---------------------------------------------------------------------------

@dataclass
class SiliconContract:
    """
    Primary release binder object — PRD v1.3 Law 1.
    Binds chip scope, evidence, named human authority, release disposition
    and delivery boundary into a single governance object.
    """
    contract_id: str
    schema_version: str
    workspace_id: str
    chip_id: str
    release_scope: str
    contract_status: ContractStatus
    source_spec_refs: List[EvidenceRef]
    authority_bindings: List[AuthorityBinding]
    delivery_classification: DeliveryClass
    created_at: datetime

    # Optional evidence refs
    design_state_refs: List[EvidenceRef] = field(default_factory=list)
    signoff_evidence_refs: List[EvidenceRef] = field(default_factory=list)
    decision_chain_refs: List[EvidenceRef] = field(default_factory=list)
    exception_refs: List[EvidenceRef] = field(default_factory=list)
    open_risk_refs: List[EvidenceRef] = field(default_factory=list)
    package_refs: List[EvidenceRef] = field(default_factory=list)
    audit_refs: List[EvidenceRef] = field(default_factory=list)
    qa_adjudication_refs: List[EvidenceRef] = field(default_factory=list)

    # Authority closure summary
    all_mandatory_closed: bool = False

    # Revision tracking
    supersedes: Optional[str] = None
    updated_at: Optional[datetime] = None
    notes: Optional[str] = None

    OBJECT_TYPE: str = field(default="silicon_contract", init=False, repr=False)


# ---------------------------------------------------------------------------
# Release Package Objects
# ---------------------------------------------------------------------------

@dataclass
class ChipReleasePackage:
    """Release-ready assembly — distinct from silicon_contract (binder)."""
    package_id: str
    schema_version: str
    contract_ref: str
    chip_id: str
    workspace_id: str
    delivery_classification: DeliveryClass
    contents: List[EvidenceRef]
    created_at: datetime

    excluded_paths: List[str] = field(default_factory=list)
    integrity_digest: Optional[str] = None
    notes: Optional[str] = None

    OBJECT_TYPE: str = field(default="chip_release_package", init=False, repr=False)


@dataclass
class SiliconReleasePackage:
    """Downstream customer/foundry delivery package."""

    class RecipientClass(str, Enum):
        INTERNAL = "INTERNAL"
        CUSTOMER = "CUSTOMER"
        FOUNDRY = "FOUNDRY"
        AUDIT_BODY = "AUDIT_BODY"

    package_id: str
    schema_version: str
    contract_ref: str
    chip_release_package_ref: str
    delivery_classification: DeliveryClass
    recipient_class: "SiliconReleasePackage.RecipientClass"
    created_at: datetime

    contents: List[EvidenceRef] = field(default_factory=list)
    prohibited_content_policy: Optional[str] = None
    integrity_digest: Optional[str] = None
    notes: Optional[str] = None

    OBJECT_TYPE: str = field(default="silicon_release_package", init=False, repr=False)


@dataclass
class ChipExportSnapshot:
    """Point-in-time audit/export snapshot."""

    class ExportPurpose(str, Enum):
        AUDIT = "AUDIT"
        CUSTOMER_REVIEW = "CUSTOMER_REVIEW"
        FOUNDRY_HANDOFF = "FOUNDRY_HANDOFF"
        ARCHIVE = "ARCHIVE"
        INTERNAL = "INTERNAL"

    snapshot_id: str
    schema_version: str
    chip_id: str
    workspace_id: str
    export_purpose: "ChipExportSnapshot.ExportPurpose"
    snapshot_refs: List[EvidenceRef]
    created_at: datetime

    contract_ref: Optional[str] = None
    excluded_paths: List[str] = field(default_factory=list)
    integrity_digest: Optional[str] = None

    OBJECT_TYPE: str = field(default="chip_export_snapshot", init=False, repr=False)


@dataclass
class ChipPortableWorkspaceBundle:
    """Portable workspace bundle for transfer/handoff."""

    class BundleScope(str, Enum):
        FULL_WORKSPACE = "FULL_WORKSPACE"
        EVIDENCE_ONLY = "EVIDENCE_ONLY"
        SPEC_ONLY = "SPEC_ONLY"
        AUDIT_BUNDLE = "AUDIT_BUNDLE"

    bundle_id: str
    schema_version: str
    chip_id: str
    workspace_id: str
    bundle_scope: "ChipPortableWorkspaceBundle.BundleScope"
    contents: List[EvidenceRef]
    created_at: datetime

    contract_ref: Optional[str] = None
    prohibited_domains: List[str] = field(default_factory=list)
    integrity_digest: Optional[str] = None

    OBJECT_TYPE: str = field(default="chip_portable_workspace_bundle", init=False, repr=False)


# ---------------------------------------------------------------------------
# Operational Record Objects
# ---------------------------------------------------------------------------

@dataclass
class SiliconContractSectionRecord:
    """Per-section review/acknowledgment record."""
    record_id: str
    schema_version: str
    contract_ref: str
    section_id: str
    actor_role: AuthorityRole
    section_status: SectionStatus
    created_at: datetime

    section_name: Optional[str] = None
    actor_id: Optional[str] = None
    conditions: List[str] = field(default_factory=list)
    evidence_refs: List[EvidenceRef] = field(default_factory=list)
    notes: Optional[str] = None

    OBJECT_TYPE: str = field(default="silicon_contract_section_record", init=False, repr=False)


@dataclass
class AuthorityClosureRecord:
    """Tracks whether all mandatory authority roles have closed."""
    record_id: str
    schema_version: str
    contract_ref: str
    mandatory_roles_required: List[AuthorityRole]
    mandatory_roles_closed: List[AuthorityRole]
    all_mandatory_closed: bool
    created_at: datetime

    pending_roles: List[AuthorityRole] = field(default_factory=list)
    conflict_detected: bool = False
    conflict_refs: List[str] = field(default_factory=list)

    OBJECT_TYPE: str = field(default="authority_closure_record", init=False, repr=False)


@dataclass
class ReleaseBlockRecord:
    """Formal release block — authority-bearing control object."""
    record_id: str
    schema_version: str
    contract_ref: str
    block_reason: BlockReason
    blocking_actor_role: AuthorityRole
    block_status: str  # "ACTIVE" | "RESOLVED" | "ESCALATED"
    created_at: datetime

    block_detail: Optional[str] = None
    blocking_actor_id: Optional[str] = None
    resolution_ref: Optional[str] = None
    resolved_at: Optional[datetime] = None

    OBJECT_TYPE: str = field(default="release_block_record", init=False, repr=False)


@dataclass
class RiskAcknowledgementRecord:
    """Named authority formally acknowledges an open risk."""
    record_id: str
    schema_version: str
    contract_ref: str
    risk_ref: EvidenceRef
    acknowledging_role: AuthorityRole
    acknowledgement_decision: AcknowledgementDecision
    created_at: datetime

    acknowledging_actor_id: Optional[str] = None
    waiver_justification: Optional[str] = None
    expiry: Optional[datetime] = None

    OBJECT_TYPE: str = field(default="risk_acknowledgement_record", init=False, repr=False)


@dataclass
class ReleaseDeclarationRecord:
    """
    Final release readiness declaration — authority-bearing.
    Only human authority may produce this object (Law 5).
    """
    record_id: str
    schema_version: str
    contract_ref: str
    declaring_role: AuthorityRole
    declaring_actor_id: str
    authority_closure_ref: str
    final_disposition: ReleaseDisposition
    created_at: datetime

    evidence_completeness_confirmed: bool = False
    delivery_classification_confirmed: bool = False
    blocking_issues_at_declaration: List[str] = field(default_factory=list)
    notes: Optional[str] = None

    OBJECT_TYPE: str = field(default="release_declaration_record", init=False, repr=False)
