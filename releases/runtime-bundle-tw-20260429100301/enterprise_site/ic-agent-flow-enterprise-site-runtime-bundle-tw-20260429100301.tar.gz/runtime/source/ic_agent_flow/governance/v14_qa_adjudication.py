from __future__ import annotations

from ic_agent_flow.domain.objects.v14_qa_trust_layer_objects import (
    ClaimScopeAssessment,
    EvidenceQualityReport,
    QAAdjudicationRecord,
    QAAdjudicator,
    QARef,
    ScenarioValidationReport,
)


_VERDICT_PRIORITY = {
    "LINEAGE_BROKEN": 0,
    "INSUFFICIENT_EVIDENCE": 1,
    "SCENARIO_GAP": 2,
    "OVERBROAD_CLAIM": 3,
    "REVIEW_SURFACE_WEAK": 4,
    "ACCEPTABLE": 5,
}


def _recommendation_for(verdict: str) -> str:
    if verdict == "ACCEPTABLE":
        return "PROCEED"
    if verdict == "REVIEW_SURFACE_WEAK":
        return "REQUEST_MORE_EVIDENCE"
    if verdict == "OVERBROAD_CLAIM":
        return "REJECT"
    if verdict in {"INSUFFICIENT_EVIDENCE", "LINEAGE_BROKEN", "SCENARIO_GAP"}:
        return "HOLD"
    raise ValueError("invalid_combined_verdict")


def adjudicate_qa_reports(
    *,
    adjudication_id: str,
    qa_run_ref: str,
    evidence_report: EvidenceQualityReport,
    scenario_report: ScenarioValidationReport,
    claim_assessment: ClaimScopeAssessment,
    created_at: str,
    adjudicator_role: str = "qa_system",
    adjudicator_id: str = "qa-trust-layer-v1.4",
) -> QAAdjudicationRecord:
    verdicts = [
        evidence_report.verdict,
        scenario_report.verdict,
        claim_assessment.verdict,
    ]
    combined_verdict = min(verdicts, key=lambda v: _VERDICT_PRIORITY.get(v, 999))

    blocking_issues: list[str] = []
    non_blocking_warnings: list[str] = []

    if evidence_report.verdict in {"INSUFFICIENT_EVIDENCE", "LINEAGE_BROKEN"}:
        blocking_issues.extend(evidence_report.issues)
    if scenario_report.verdict == "SCENARIO_GAP":
        blocking_issues.extend(scenario_report.gaps)
    if claim_assessment.verdict == "OVERBROAD_CLAIM":
        blocking_issues.extend(claim_assessment.unsupported_claims)
    if claim_assessment.verdict == "REVIEW_SURFACE_WEAK":
        non_blocking_warnings.extend(claim_assessment.unsupported_claims)

    return QAAdjudicationRecord(
        id=adjudication_id,
        qa_run_ref=qa_run_ref,
        input_report_refs=[
            QARef(
                ref_id=evidence_report.id,
                ref_type=evidence_report.type,
                uri=f"artifacts/qa/{evidence_report.id}.json",
            ),
            QARef(
                ref_id=scenario_report.id,
                ref_type=scenario_report.type,
                uri=f"artifacts/qa/{scenario_report.id}.json",
            ),
            QARef(
                ref_id=claim_assessment.id,
                ref_type=claim_assessment.type,
                uri=f"artifacts/qa/{claim_assessment.id}.json",
            ),
        ],
        combined_verdict=combined_verdict,
        recommendation=_recommendation_for(combined_verdict),
        blocking_issues=blocking_issues,
        non_blocking_warnings=non_blocking_warnings,
        created_at=created_at,
        adjudicator=QAAdjudicator(role=adjudicator_role, id=adjudicator_id),
    )
