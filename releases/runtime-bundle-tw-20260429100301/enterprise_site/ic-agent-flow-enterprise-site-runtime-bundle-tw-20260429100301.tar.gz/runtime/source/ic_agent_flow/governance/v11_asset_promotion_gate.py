from __future__ import annotations

import json
from pathlib import Path
from uuid import uuid4

from ic_agent_flow.domain.objects.v11_knowledge_flywheel_objects import (
    AssetPromotionRecord,
    KnowledgeAsset,
    SharedAssetRegistryRecord,
    allows_shared_registry_write,
    is_valid_promotion_decision,
)


_SENSITIVE_TAG_KEYWORDS = {
    "confidential",
    "customer-local-only",
    "ip-sensitive",
    "foundry-specific",
}


def _target_scope_for_decision(decision: str) -> str:
    if decision in {"reject", "keep_project_private"}:
        return "project_private"
    if decision == "share_team_scope":
        return "team_shared"
    if decision == "share_org_scope":
        return "org_shared"
    if decision in {"promote_canonical", "promote_with_conditions"}:
        return "canonical_shared"
    raise ValueError("invalid_promotion_decision")


def _requires_genericization(decision: str) -> bool:
    return decision in {
        "share_team_scope",
        "share_org_scope",
        "promote_canonical",
        "promote_with_conditions",
    }


def _is_sensitive_asset(asset: KnowledgeAsset) -> bool:
    tags = {tag.strip().lower() for tag in asset.tags}
    return any(keyword in tags for keyword in _SENSITIVE_TAG_KEYWORDS)


def adjudicate_asset_promotion(
    *,
    asset: KnowledgeAsset,
    decision: str,
    decision_rationale: str,
    reviewer_refs: list[str],
    evidence_refs: list[str],
    created_at: str,
    genericized_summary: str | None = None,
    conditions: list[str] | None = None,
) -> AssetPromotionRecord:
    if not is_valid_promotion_decision(decision):
        raise ValueError("invalid_promotion_decision")
    if not decision_rationale.strip():
        raise ValueError("decision_rationale_required")
    if not reviewer_refs:
        raise ValueError("reviewer_refs_required")
    if not evidence_refs:
        raise ValueError("evidence_refs_required")

    target_scope_level = _target_scope_for_decision(decision)

    if _requires_genericization(decision) and not (genericized_summary or "").strip():
        raise ValueError("genericization_required")
    if decision == "promote_with_conditions" and not (conditions or []):
        raise ValueError("promotion_conditions_required")
    if decision in {"share_team_scope", "share_org_scope", "promote_canonical", "promote_with_conditions"} and _is_sensitive_asset(asset):
        raise ValueError("confidentiality_guard_blocked")

    return AssetPromotionRecord(
        record_id=f"promotion://{uuid4()}",
        asset_ref=asset.asset_id,
        decision=decision,
        decision_rationale=decision_rationale.strip(),
        reviewer_refs=reviewer_refs,
        conditions=conditions or [],
        target_scope_level=target_scope_level,
        evidence_refs=evidence_refs,
        created_at=created_at,
    )


def build_shared_asset_registry_record(
    *,
    asset: KnowledgeAsset,
    promotion_record: AssetPromotionRecord,
    taxonomy_path: str,
    current_version: str,
    created_at: str,
) -> SharedAssetRegistryRecord:
    if not allows_shared_registry_write(promotion_record.decision):
        raise ValueError("registry_write_not_allowed")
    if not taxonomy_path.strip():
        raise ValueError("taxonomy_path_required")
    if not current_version.strip():
        raise ValueError("current_version_required")

    return SharedAssetRegistryRecord(
        registry_id=f"registry://{uuid4()}",
        asset_ref=asset.asset_id,
        scope_level=promotion_record.target_scope_level,
        status="ACTIVE",
        taxonomy_path=taxonomy_path.strip(),
        current_version=current_version.strip(),
        supersedes_refs=[],
        lineage_refs=[promotion_record.record_id],
        created_at=created_at,
    )


def write_shared_asset_registry_record(
    *,
    asset: KnowledgeAsset,
    promotion_record: AssetPromotionRecord,
    taxonomy_path: str,
    current_version: str,
    created_at: str,
    output_path: str | Path,
) -> Path:
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    record = build_shared_asset_registry_record(
        asset=asset,
        promotion_record=promotion_record,
        taxonomy_path=taxonomy_path,
        current_version=current_version,
        created_at=created_at,
    )
    out.write_text(json.dumps(record.model_dump(), indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return out

