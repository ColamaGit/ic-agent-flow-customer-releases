from __future__ import annotations

from typing import Any, List, Optional
from datetime import datetime
from pydantic import BaseModel

from ic_agent_flow.domain.objects.deployment_packaging_objects import (
    UpgradeRecord,
    RollbackRecord,
    AuthorityClass,
    ObjectStatus,
    SignatureBlock,
    UpgradePackage,
    RollbackPackage,
)


class UpgradeRequest(BaseModel):
    site_id: str
    from_version: str
    to_version: str
    upgrade_package_ref: str
    customer_approval_ref: str
    approved_by: str
    dry_run: bool = False


class RollbackRequest(BaseModel):
    site_id: str
    from_version: str
    target_version: str
    rollback_package_ref: str
    customer_approval_ref: str
    approved_by: str
    drill_only: bool = False


class UpgradePrecheckRunner:
    def run_precheck(self, upgrade_pkg: UpgradePackage, environment_state: dict[str, Any]) -> dict[str, Any]:
        failed_rules = []
        for rule in upgrade_pkg.precheck_rules:
            # Mock evaluation logic
            if rule not in environment_state.get("supported_rules", []):
                failed_rules.append(rule)
        
        passed = len(failed_rules) == 0
        return {
            "passed": passed,
            "failed_rules": failed_rules,
            "evidence": f"Precheck evaluated {len(upgrade_pkg.precheck_rules)} rules. Passed: {passed}"
        }


class UpgradeExecutor:
    def execute_upgrade(self, request: UpgradeRequest, upgrade_pkg: UpgradePackage) -> dict[str, Any]:
        if not request.customer_approval_ref:
            raise ValueError("upgrade_unauthorized")

        if request.dry_run:
            return {"status": "STAGED", "executed_steps": []}

        # Mock execution of migration steps
        executed = list(upgrade_pkg.migration_steps)
        return {"status": "SUCCESS", "executed_steps": executed}


class UpgradePostcheckRunner:
    def run_postcheck(self, upgrade_pkg: UpgradePackage, post_state: dict[str, Any]) -> dict[str, Any]:
        failed_rules = []
        for rule in upgrade_pkg.postcheck_rules:
            if rule not in post_state.get("validated_rules", []):
                failed_rules.append(rule)
                
        passed = len(failed_rules) == 0
        return {
            "passed": passed,
            "failed_rules": failed_rules,
            "evidence": f"Postcheck evaluated {len(upgrade_pkg.postcheck_rules)} rules. Passed: {passed}"
        }


class RollbackDrillRunner:
    def execute_rollback(self, request: RollbackRequest, rollback_pkg: RollbackPackage) -> dict[str, Any]:
        if not request.customer_approval_ref:
            raise ValueError("rollback_unauthorized")

        if request.drill_only:
            return {"status": "DRILL_SUCCESS", "restored_refs": []}

        # Mock restoration
        restored = list(rollback_pkg.state_restore_refs)
        return {"status": "SUCCESS", "restored_refs": restored}


class UpgradeRollbackAuditEmitter:
    def __init__(self, signature_factory: Any):
        self.signature_factory = signature_factory

    def emit_upgrade_record(
        self,
        request: UpgradeRequest,
        precheck_result: dict[str, Any],
        postcheck_result: dict[str, Any],
        execution_status: str,
    ) -> UpgradeRecord:
        
        overall_result = "SUCCESS"
        if not precheck_result.get("passed"):
            overall_result = "BLOCKED_PRECHECK_FAILED"
        elif execution_status.startswith("BLOCKED_"):
            overall_result = execution_status
        elif execution_status != "SUCCESS" and not request.dry_run:
            overall_result = "FAILED_EXECUTION"
        elif not postcheck_result.get("passed", True) and not request.dry_run:
            overall_result = "FAILED_POSTCHECK_ROLLBACK_REQUIRED"
            
        return UpgradeRecord(
            version="0.1",
            status=ObjectStatus.ACTIVE,
            authority_class=AuthorityClass.OPERATOR,
            producer="upgrade-manager@0.1",
            digest=f"sha256:upgrade-{request.site_id}-{request.to_version}",
            signature=self.signature_factory(),
            site_id=request.site_id,
            from_version=request.from_version,
            to_version=request.to_version,
            upgrade_package_ref=request.upgrade_package_ref,
            precheck_result="PASS" if precheck_result.get("passed") else "FAIL",
            postcheck_result="PASS" if postcheck_result.get("passed", True) else "FAIL",
            verifier="system-postcheck",
            result=overall_result,
            customer_approval_ref=request.customer_approval_ref,
            approved_by=request.approved_by,
        )

    def emit_rollback_record(
        self,
        request: RollbackRequest,
        rollback_pkg: RollbackPackage,
        execution_status: str,
    ) -> RollbackRecord:
        
        overall_result = "SUCCESS"
        if execution_status not in ["SUCCESS", "DRILL_SUCCESS"]:
            overall_result = "FAILED"
            
        return RollbackRecord(
            version="0.1",
            status=ObjectStatus.ACTIVE,
            authority_class=AuthorityClass.OPERATOR,
            producer="rollback-manager@0.1",
            digest=f"sha256:rollback-{request.site_id}-{request.target_version}",
            signature=self.signature_factory(),
            site_id=request.site_id,
            from_version=request.from_version,
            target_version=request.target_version,
            rollback_package_ref=request.rollback_package_ref,
            restore_scope=",".join(rollback_pkg.state_restore_refs),
            verifier="system-rollback",
            result=overall_result,
            customer_approval_ref=request.customer_approval_ref,
            approved_by=request.approved_by,
        )
