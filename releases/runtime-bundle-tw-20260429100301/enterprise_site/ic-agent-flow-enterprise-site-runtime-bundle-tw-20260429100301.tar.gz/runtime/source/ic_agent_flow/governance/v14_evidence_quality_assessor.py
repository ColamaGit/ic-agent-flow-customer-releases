from __future__ import annotations

from ic_agent_flow.domain.objects.v14_qa_trust_layer_objects import (
    EvidenceQualityReport,
    QAAssessmentRun,
    QARef,
)


_RAW_ARTIFACT_STATUSES = {"PRESENT", "MISSING", "PARTIAL"}
_NORMALIZED_MAPPING_STATUSES = {"MATCHED", "MISMATCHED", "MISSING", "NOT_APPLICABLE"}
_LINEAGE_STATUSES = {"COMPLETE", "BROKEN", "PARTIAL"}
_INTEGRITY_STATUSES = {"PASS", "FAIL", "NOT_CHECKED"}


def assess_evidence_quality(
    *,
    run: QAAssessmentRun,
    report_id: str,
    artifact_refs: list[QARef],
    raw_artifact_status: str,
    normalized_mapping_status: str,
    lineage_status: str,
    integrity_status: str,
    missing_artifacts: list[str] | None = None,
    issues: list[str] | None = None,
) -> EvidenceQualityReport:
    if raw_artifact_status not in _RAW_ARTIFACT_STATUSES:
        raise ValueError("invalid_raw_artifact_status")
    if normalized_mapping_status not in _NORMALIZED_MAPPING_STATUSES:
        raise ValueError("invalid_normalized_mapping_status")
    if lineage_status not in _LINEAGE_STATUSES:
        raise ValueError("invalid_lineage_status")
    if integrity_status not in _INTEGRITY_STATUSES:
        raise ValueError("invalid_integrity_status")

    resolved_issues = list(issues or [])
    resolved_missing = list(missing_artifacts or [])

    if raw_artifact_status in {"MISSING", "PARTIAL"}:
        verdict = "INSUFFICIENT_EVIDENCE"
        resolved_issues.append("raw_artifact_missing_or_partial")
    elif lineage_status == "BROKEN":
        verdict = "LINEAGE_BROKEN"
        resolved_issues.append("lineage_broken")
    elif integrity_status == "FAIL":
        verdict = "INSUFFICIENT_EVIDENCE"
        resolved_issues.append("integrity_check_failed")
    elif normalized_mapping_status in {"MISSING", "MISMATCHED"}:
        verdict = "INSUFFICIENT_EVIDENCE"
        resolved_issues.append("normalized_mapping_invalid")
    else:
        verdict = "ACCEPTABLE"

    return EvidenceQualityReport(
        id=report_id,
        qa_run_ref=run.id,
        artifact_refs=artifact_refs,
        raw_artifact_status=raw_artifact_status,
        normalized_mapping_status=normalized_mapping_status,
        lineage_status=lineage_status,
        integrity_status=integrity_status,
        missing_artifacts=resolved_missing,
        issues=resolved_issues,
        verdict=verdict,
    )
