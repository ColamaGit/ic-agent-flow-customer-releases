from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class LeakSeverity(str, Enum):
    INFO = "INFO"
    WARNING = "WARNING"
    BLOCKING = "BLOCKING"
    CRITICAL = "CRITICAL"


@dataclass(frozen=True)
class VendorIPLeakFinding:
    rule_id: str
    asset_path: str
    severity: LeakSeverity
    message: str
    remediation: str


@dataclass(frozen=True)
class VendorIPLeakScanReport:
    scan_id: str
    bundle_ref: str
    findings: list[VendorIPLeakFinding]
    severity_summary: dict[str, int]
    blocked: bool
    scanner_version: str


class VendorIPLeakScanner:
    rules = {
        "internal_prompt_or_context": {
            "patterns": ["prompt_trace", "context assembly", "context_assembly", "internal prompt"],
            "severity": LeakSeverity.BLOCKING,
            "remediation": "remove prompt/context trace or replace with redacted support summary",
        },
        "secret_token": {
            "patterns": ["OPENAI_API_KEY=", "sk-", "SECRET_KEY=", "TOKEN="],
            "severity": LeakSeverity.CRITICAL,
            "remediation": "remove secret and rotate credential",
        },
        "internal_roadmap": {
            "patterns": ["unreleased roadmap", "internal closeout reasoning"],
            "severity": LeakSeverity.BLOCKING,
            "remediation": "remove internal governance artifact from package",
        },
        "private_validator": {
            "patterns": ["private validator", "validator_internal"],
            "severity": LeakSeverity.BLOCKING,
            "remediation": "expose only public contract result",
        },
    }

    def scan_text_assets(self, *, bundle_ref: str, assets: dict[str, str]) -> VendorIPLeakScanReport:
        findings: list[VendorIPLeakFinding] = []
        for asset_path, content in assets.items():
            normalized = content.lower()
            for rule_id, rule in self.rules.items():
                if any(pattern.lower() in normalized for pattern in rule["patterns"]):
                    findings.append(
                        VendorIPLeakFinding(
                            rule_id=rule_id,
                            asset_path=asset_path,
                            severity=rule["severity"],
                            message=f"{rule_id} detected in {asset_path}",
                            remediation=rule["remediation"],
                        )
                    )
                    break

        severity_summary = {severity.value: 0 for severity in LeakSeverity}
        for finding in findings:
            severity_summary[finding.severity.value] += 1

        return VendorIPLeakScanReport(
            scan_id=f"leak-scan://{bundle_ref}",
            bundle_ref=bundle_ref,
            findings=findings,
            severity_summary=severity_summary,
            blocked=any(f.severity in {LeakSeverity.BLOCKING, LeakSeverity.CRITICAL} for f in findings),
            scanner_version="v1.6.0",
        )
