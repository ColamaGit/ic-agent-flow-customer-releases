from __future__ import annotations

from ic_agent_flow.domain.objects.v11_knowledge_flywheel_objects import (
    AssetPromotionRecord,
    SharedAssetRegistryRecord,
)


_SCOPE_RANK = {
    "project_private": 0,
    "team_shared": 1,
    "org_shared": 2,
    "canonical_shared": 3,
}


class RegistryMaintenanceService:
    def merge_duplicates(
        self,
        *,
        records: list[SharedAssetRegistryRecord],
        decision_record_ref: str,
    ) -> list[SharedAssetRegistryRecord]:
        grouped: dict[tuple[str, str], list[SharedAssetRegistryRecord]] = {}
        for record in records:
            key = (record.scope_level, record.taxonomy_path)
            grouped.setdefault(key, []).append(record)

        kept: list[SharedAssetRegistryRecord] = []
        for _, items in grouped.items():
            head = items[0]
            head.lineage_refs.append(decision_record_ref)
            kept.append(head)
            for extra in items[1:]:
                extra.status = "DEPRECATED"
                extra.lineage_refs.append(f"merged_into:{head.registry_id}")
                extra.lineage_refs.append(decision_record_ref)
                head.lineage_refs.append(f"merged_from:{extra.registry_id}")
        return kept

    def supersede_record(
        self,
        *,
        active: SharedAssetRegistryRecord,
        replacement: SharedAssetRegistryRecord,
        decision_record_ref: str,
    ) -> SharedAssetRegistryRecord:
        active.status = "SUPERSEDED"
        active.lineage_refs.append(decision_record_ref)
        replacement.supersedes_refs = [active.registry_id]
        replacement.lineage_refs.append(decision_record_ref)
        return replacement

    def retire_record(
        self,
        *,
        record: SharedAssetRegistryRecord,
        decision_record_ref: str,
        reason: str,
    ) -> SharedAssetRegistryRecord:
        record.status = "RETIRED"
        record.lineage_refs.append(decision_record_ref)
        record.lineage_refs.append(f"retire:{reason}")
        return record

    def revise_canonical_asset(
        self,
        *,
        record: SharedAssetRegistryRecord,
        new_version: str,
        decision_record_ref: str,
    ) -> SharedAssetRegistryRecord:
        if record.scope_level != "canonical_shared":
            raise ValueError("canonical_revision_requires_canonical_scope")
        record.current_version = new_version
        record.lineage_refs.append(decision_record_ref)
        record.lineage_refs.append(f"revision:{new_version}")
        return record

    def downgrade_scope(
        self,
        *,
        record: SharedAssetRegistryRecord,
        target_scope_level: str,
        decision_record_ref: str,
    ) -> SharedAssetRegistryRecord:
        current_rank = _SCOPE_RANK.get(record.scope_level, -1)
        target_rank = _SCOPE_RANK.get(target_scope_level, -1)
        if target_rank < 0 or current_rank < 0:
            raise ValueError("invalid_scope_level")
        if target_rank >= current_rank:
            raise ValueError("scope_downgrade_only")
        record.scope_level = target_scope_level
        record.lineage_refs.append(decision_record_ref)
        record.lineage_refs.append(f"downgrade_to:{target_scope_level}")
        return record

    def enforce_promotion_policy_hardening(self, promotion: AssetPromotionRecord) -> None:
        if promotion.decision in {"promote_canonical", "promote_with_conditions"} and len(promotion.reviewer_refs) < 2:
            raise ValueError("canonical_reviewers_insufficient")
        if promotion.decision == "promote_with_conditions" and not promotion.conditions:
            raise ValueError("promotion_conditions_required")

