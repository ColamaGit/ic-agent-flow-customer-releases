from __future__ import annotations

from datetime import datetime, timezone
from uuid import uuid4

from ic_agent_flow.domain.objects.v12_ecosystem_boundary_objects import (
    ExternalConfidentialityReviewRecord,
    ExternalAssetSubmissionRecord,
    V12_CONFIDENTIALITY_RISK_FLAGS,
)


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def review_external_submission_confidentiality(
    submission: ExternalAssetSubmissionRecord,
    *,
    detected_leakage_flags: list[str],
    reversible_reconstruction_risk: bool,
) -> ExternalConfidentialityReviewRecord:
    reasons: list[str] = []
    accepted_flags = set(V12_CONFIDENTIALITY_RISK_FLAGS)
    for flag in detected_leakage_flags:
        if flag not in accepted_flags:
            reasons.append(f"unknown_leakage_flag:{flag}")
        else:
            reasons.append(flag)

    if submission.sanitization_level not in {"basic", "strict"}:
        reasons.append("sanitization_level_not_allowed")
    if reversible_reconstruction_risk:
        reasons.append("reversible_reconstruction_risk")

    if reasons:
        return ExternalConfidentialityReviewRecord(
            review_id=f"confreview://{uuid4()}",
            submission_ref=submission.submission_id,
            status="REJECTED",
            risk_flags=detected_leakage_flags,
            rejection_reasons=reasons,
            downgraded_scope_class=None,
            requires_resubmission=True,
            reviewed_at=_now_iso(),
        )

    if (
        submission.confidentiality_declaration == "sanitized_with_limited_context"
        and submission.source_scope_class
        in {"partner_shared", "upstream_canonical_candidate"}
    ):
        return ExternalConfidentialityReviewRecord(
            review_id=f"confreview://{uuid4()}",
            submission_ref=submission.submission_id,
            status="DOWNGRADED_TO_CUSTOMER_APPROVED_SANITIZED_CANDIDATE",
            risk_flags=[],
            rejection_reasons=[],
            downgraded_scope_class="customer_approved_sanitized_candidate",
            requires_resubmission=False,
            reviewed_at=_now_iso(),
        )

    return ExternalConfidentialityReviewRecord(
        review_id=f"confreview://{uuid4()}",
        submission_ref=submission.submission_id,
        status="APPROVED_FOR_TECHNICAL_REVIEW",
        risk_flags=[],
        rejection_reasons=[],
        downgraded_scope_class=None,
        requires_resubmission=False,
        reviewed_at=_now_iso(),
    )
