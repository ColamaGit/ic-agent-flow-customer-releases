from __future__ import annotations

import json
from pathlib import Path
from typing import List, Optional

from pydantic import BaseModel, Field

from ic_agent_flow.domain.objects.v10_upstream_objects import (
    GraphValidationVerdict,
    is_fail_closed_graph_verdict,
)


GRAPH_VALIDATION_OBJECT_FILES = {
    "architecture_graph": "architecture_graph.json",
    "graph_validation_result": "graph_validation_result.json",
    "graph_issue": "graph_issue.json",
    "validator_run_record": "validator_run_record.json",
}


class GraphValidationAssessment(BaseModel):
    validation_chain_complete: bool
    missing_canonical_objects: List[str] = Field(default_factory=list)
    verdict: Optional[str] = None
    freeze_blocked: bool = True
    authority_required: bool = False
    missing_validator_families: List[str] = Field(default_factory=list)
    blocking_issue_ids: List[str] = Field(default_factory=list)
    companion_view_present: bool = False
    companion_view_has_source_digest: bool = False


def _load_json(path: Path) -> dict:
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def _validator_families(validator_run_record: dict) -> set[str]:
    return {
        item["validator_family"]
        for item in validator_run_record.get("validator_runs", [])
        if item.get("validator_family")
    }


def _blocking_issue_ids(graph_issue: dict) -> List[str]:
    return [
        item.get("issue_id", "unknown_graph_issue")
        for item in graph_issue.get("issues", [])
        if item.get("blocking")
    ]


def _companion_has_source_digest(path: Path) -> bool:
    if not path.exists():
        return False
    text = path.read_text(encoding="utf-8")
    return "Source canonical graph ref:" in text and "Derived-from JSON SHA-256 digest:" in text


def assess_graph_validation_chain(architecture_dir: Path | str) -> GraphValidationAssessment:
    architecture_dir = Path(architecture_dir)
    missing = [
        object_family
        for object_family, filename in GRAPH_VALIDATION_OBJECT_FILES.items()
        if not (architecture_dir / filename).exists()
    ]

    validation_result = _load_json(architecture_dir / GRAPH_VALIDATION_OBJECT_FILES["graph_validation_result"])
    validator_run_record = _load_json(architecture_dir / GRAPH_VALIDATION_OBJECT_FILES["validator_run_record"])
    graph_issue = _load_json(architecture_dir / GRAPH_VALIDATION_OBJECT_FILES["graph_issue"])

    required_families = set(validation_result.get("required_validator_families", []))
    executed_families = _validator_families(validator_run_record)
    missing_families = sorted(required_families - executed_families)

    verdict_value = validation_result.get("verdict")
    verdict = GraphValidationVerdict(verdict_value) if verdict_value else None
    blocking_issue_ids = _blocking_issue_ids(graph_issue)
    companion_path = architecture_dir / "architecture_graph.view.md"

    freeze_blocked = True
    if verdict is not None:
        freeze_blocked = is_fail_closed_graph_verdict(verdict) or bool(blocking_issue_ids)

    return GraphValidationAssessment(
        validation_chain_complete=not missing and not missing_families and not freeze_blocked,
        missing_canonical_objects=missing,
        verdict=verdict.value if verdict else None,
        freeze_blocked=freeze_blocked,
        authority_required=bool(validation_result.get("adjudication_required")),
        missing_validator_families=missing_families,
        blocking_issue_ids=blocking_issue_ids,
        companion_view_present=companion_path.exists(),
        companion_view_has_source_digest=_companion_has_source_digest(companion_path),
    )
