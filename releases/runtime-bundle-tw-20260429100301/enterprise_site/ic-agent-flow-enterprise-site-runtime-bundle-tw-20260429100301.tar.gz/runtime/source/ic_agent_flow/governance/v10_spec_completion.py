from __future__ import annotations

import json
from pathlib import Path
from typing import List, Optional

from pydantic import BaseModel, Field


SPEC_COMPLETION_OBJECT_FILES = {
    "requirement_item": "requirement_item.json",
    "design_spec": "design_spec.json",
    "spec_completeness_report": "spec_completeness_report.json",
    "requirement_freeze_record": "requirement_freeze_record.json",
}


class SpecCompletionAssessment(BaseModel):
    chain_complete: bool
    missing_canonical_objects: List[str] = Field(default_factory=list)
    unmapped_requirement_ids: List[str] = Field(default_factory=list)
    coverage_ratio: Optional[float] = None
    freeze_state: Optional[str] = None
    authority_required: bool = False
    authority_blocking_items: List[str] = Field(default_factory=list)


def _load_json(path: Path) -> dict:
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def _requirement_ids(requirement_item: dict) -> List[str]:
    return [
        item["requirement_id"]
        for item in requirement_item.get("requirement_items", [])
        if item.get("requirement_id")
    ]


def _mapped_requirement_ids(design_spec: dict) -> List[str]:
    return [
        item["requirement_id"]
        for item in design_spec.get("requirement_mapping", [])
        if item.get("requirement_id")
    ]


def _authority_blocking_items(spec_report: dict) -> List[str]:
    return [
        item.get("ambiguity_id") or item.get("related_requirement_id") or "unknown_ambiguity"
        for item in spec_report.get("open_ambiguity", [])
        if item.get("needs_authority_decision")
    ]


def assess_spec_completion_chain(specs_dir: Path | str) -> SpecCompletionAssessment:
    specs_dir = Path(specs_dir)
    missing = [
        object_family
        for object_family, filename in SPEC_COMPLETION_OBJECT_FILES.items()
        if not (specs_dir / filename).exists()
    ]

    requirement_item = _load_json(specs_dir / SPEC_COMPLETION_OBJECT_FILES["requirement_item"])
    design_spec = _load_json(specs_dir / SPEC_COMPLETION_OBJECT_FILES["design_spec"])
    spec_report = _load_json(specs_dir / SPEC_COMPLETION_OBJECT_FILES["spec_completeness_report"])
    freeze_record = _load_json(specs_dir / SPEC_COMPLETION_OBJECT_FILES["requirement_freeze_record"])

    requirement_ids = set(_requirement_ids(requirement_item))
    mapped_ids = set(_mapped_requirement_ids(design_spec))
    unmapped = sorted(requirement_ids - mapped_ids)
    authority_items = _authority_blocking_items(spec_report)

    return SpecCompletionAssessment(
        chain_complete=not missing and not unmapped,
        missing_canonical_objects=missing,
        unmapped_requirement_ids=unmapped,
        coverage_ratio=(spec_report.get("coverage") or {}).get("coverage_ratio"),
        freeze_state=freeze_record.get("freeze_state"),
        authority_required=bool(freeze_record.get("authority_required") or authority_items),
        authority_blocking_items=authority_items,
    )
