from __future__ import annotations

from datetime import datetime, timezone
from uuid import uuid4

from ic_agent_flow.domain.objects.v11_knowledge_flywheel_objects import AssetConsumptionRecord
from ic_agent_flow.governance.v11_shared_asset_registry import SharedAssetRegistryService, SharedRegistryEntry


_ROLE_ALLOWED_FAMILIES = {
    "designer": {"checklist", "failure-pattern"},
    "verifier": {"checklist", "failure-pattern"},
    "reviewer": {"checklist", "decision-pattern"},
}


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class SharedAssetConsumptionService:
    def __init__(
        self,
        registry: SharedAssetRegistryService,
        *,
        max_assets_per_target: int = 5,
    ) -> None:
        self._registry = registry
        self._max_assets_per_target = max_assets_per_target
        self._consumption_records: list[AssetConsumptionRecord] = []

    @staticmethod
    def _score_entry(
        entry: SharedRegistryEntry,
        *,
        design_class: str,
        interface_type: str,
        stage: str,
        risk_profile: str,
    ) -> int:
        score = 0
        if entry.design_class == design_class:
            score += 1
        if entry.interface_type == interface_type:
            score += 1
        if entry.stage == stage:
            score += 1
        if entry.risk_profile == risk_profile:
            score += 1
        return score

    def _allowed_families_for_role(self, role: str) -> set[str]:
        families = _ROLE_ALLOWED_FAMILIES.get(role)
        if families is None:
            raise ValueError("unsupported_role")
        return families

    def _select(
        self,
        *,
        role: str,
        design_class: str,
        interface_type: str,
        stage: str,
        risk_profile: str,
    ) -> list[SharedRegistryEntry]:
        allowed_families = self._allowed_families_for_role(role)
        candidates = self._registry.lookup(
            scope_levels=["team_shared", "org_shared", "canonical_shared"],
            design_class=design_class,
            interface_type=interface_type,
            stage=stage,
            risk_profile=risk_profile,
        )
        filtered = [entry for entry in candidates if entry.asset_family in allowed_families]
        filtered.sort(
            key=lambda entry: self._score_entry(
                entry,
                design_class=design_class,
                interface_type=interface_type,
                stage=stage,
                risk_profile=risk_profile,
            ),
            reverse=True,
        )
        return filtered[: self._max_assets_per_target]

    def _log_consumption(
        self,
        *,
        project_ref: str,
        usage_context: str,
        selected: list[SharedRegistryEntry],
    ) -> None:
        for entry in selected:
            self._consumption_records.append(
                AssetConsumptionRecord(
                    record_id=f"consumption://{uuid4()}",
                    asset_ref=entry.record.asset_ref,
                    consumer_project_ref=project_ref,
                    usage_context=usage_context,
                    consumed_at=_now_iso(),
                    input_binding_refs=[entry.record.registry_id],
                    outcome_refs=[],
                )
            )

    def consume_for_checkout(
        self,
        *,
        project_ref: str,
        role: str,
        design_class: str,
        interface_type: str,
        stage: str,
        risk_profile: str,
    ) -> list[SharedRegistryEntry]:
        selected = self._select(
            role=role,
            design_class=design_class,
            interface_type=interface_type,
            stage=stage,
            risk_profile=risk_profile,
        )
        self._log_consumption(project_ref=project_ref, usage_context="project_checkout", selected=selected)
        return selected

    def consume_for_context_assembly(
        self,
        *,
        project_ref: str,
        role: str,
        design_class: str,
        interface_type: str,
        stage: str,
        risk_profile: str,
    ) -> list[SharedRegistryEntry]:
        selected = self._select(
            role=role,
            design_class=design_class,
            interface_type=interface_type,
            stage=stage,
            risk_profile=risk_profile,
        )
        self._log_consumption(project_ref=project_ref, usage_context="context_assembly", selected=selected)
        return selected

    def list_consumption_records(self) -> list[AssetConsumptionRecord]:
        return list(self._consumption_records)

