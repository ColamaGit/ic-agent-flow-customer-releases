from __future__ import annotations

from datetime import datetime, timezone
from uuid import uuid4

from ic_agent_flow.domain.objects.v12_ecosystem_boundary_objects import (
    CustomerPackAdoptionRecord,
    SharedAssetPackRelease,
    V12_CUSTOMER_ADOPTION_DECISIONS,
)


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class CustomerInboundAdoptionGate:
    def __init__(self) -> None:
        self._records: list[CustomerPackAdoptionRecord] = []

    def review_pack(
        self,
        *,
        customer_id: str,
        pack: SharedAssetPackRelease,
        decision: str,
        reviewer_ref: str,
        rationale: str,
        override_ref: str | None = None,
    ) -> CustomerPackAdoptionRecord:
        if decision not in V12_CUSTOMER_ADOPTION_DECISIONS:
            raise ValueError("invalid_adoption_decision")
        if decision == "override" and not (override_ref or "").strip():
            raise ValueError("override_ref_required")

        active = decision in {"accept", "override"}
        record = CustomerPackAdoptionRecord(
            record_id=f"adoption://{uuid4()}",
            customer_id=customer_id,
            release_id=pack.release_id,
            pack_version=pack.version,
            decision=decision,
            reviewer_ref=reviewer_ref,
            rationale=rationale,
            override_ref=override_ref,
            active=active,
            reviewed_at=_now_iso(),
        )
        self._records.append(record)
        return record

    def is_pack_active(self, customer_id: str, release_id: str) -> bool:
        latest = None
        for rec in self._records:
            if rec.customer_id == customer_id and rec.release_id == release_id:
                latest = rec
        if latest is None:
            return False
        return latest.active

    def require_pack_active(self, *, customer_id: str, release_id: str) -> None:
        if not self.is_pack_active(customer_id, release_id):
            raise ValueError("pack_not_adopted")
