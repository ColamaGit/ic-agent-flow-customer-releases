from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

from ic_agent_flow.domain.objects.v11_knowledge_flywheel_objects import (
    AssetPromotionRecord,
    KnowledgeAsset,
    SharedAssetRegistryRecord,
)
from ic_agent_flow.governance.v11_asset_promotion_gate import (
    build_shared_asset_registry_record,
)


_CANONICAL_DECISIONS = {"promote_canonical", "promote_with_conditions"}


@dataclass
class SharedRegistryEntry:
    record: SharedAssetRegistryRecord
    design_class: str
    interface_type: str
    stage: str
    risk_profile: str
    asset_family: str
    dedup_key: str = field(default="")


class SharedAssetRegistryService:
    def __init__(self) -> None:
        self._entries: List[SharedRegistryEntry] = []

    @staticmethod
    def _normalize(value: str) -> str:
        return value.strip().lower()

    def _build_dedup_key(
        self,
        *,
        scope_level: str,
        taxonomy_path: str,
        design_class: str,
        interface_type: str,
        stage: str,
        risk_profile: str,
        asset_family: str,
    ) -> str:
        parts = (
            self._normalize(scope_level),
            self._normalize(taxonomy_path),
            self._normalize(design_class),
            self._normalize(interface_type),
            self._normalize(stage),
            self._normalize(risk_profile),
            self._normalize(asset_family),
        )
        return "|".join(parts)

    @staticmethod
    def _validate_canonical_distinction(promotion_record: AssetPromotionRecord) -> None:
        scope = promotion_record.target_scope_level
        decision = promotion_record.decision
        if scope == "canonical_shared" and decision not in _CANONICAL_DECISIONS:
            raise ValueError("canonical_scope_decision_mismatch")
        if scope != "canonical_shared" and decision in _CANONICAL_DECISIONS:
            raise ValueError("canonical_scope_decision_mismatch")

    def _match_filters(
        self,
        entry: SharedRegistryEntry,
        *,
        scope_levels: Optional[list[str]],
        design_class: Optional[str],
        interface_type: Optional[str],
        stage: Optional[str],
        risk_profile: Optional[str],
        asset_family: Optional[str],
    ) -> bool:
        if scope_levels and entry.record.scope_level not in scope_levels:
            return False
        if design_class and entry.design_class != design_class:
            return False
        if interface_type and entry.interface_type != interface_type:
            return False
        if stage and entry.stage != stage:
            return False
        if risk_profile and entry.risk_profile != risk_profile:
            return False
        if asset_family and entry.asset_family != asset_family:
            return False
        return True

    def list_records(self) -> List[SharedAssetRegistryRecord]:
        return [entry.record for entry in self._entries]

    def lookup(
        self,
        *,
        scope_levels: Optional[list[str]] = None,
        design_class: Optional[str] = None,
        interface_type: Optional[str] = None,
        stage: Optional[str] = None,
        risk_profile: Optional[str] = None,
        asset_family: Optional[str] = None,
    ) -> List[SharedRegistryEntry]:
        return [
            entry
            for entry in self._entries
            if self._match_filters(
                entry,
                scope_levels=scope_levels,
                design_class=design_class,
                interface_type=interface_type,
                stage=stage,
                risk_profile=risk_profile,
                asset_family=asset_family,
            )
        ]

    def register_promoted_asset(
        self,
        *,
        asset: KnowledgeAsset,
        promotion_record: AssetPromotionRecord,
        taxonomy_path: str,
        current_version: str,
        created_at: str,
        design_class: str,
        interface_type: str,
        stage: str,
        risk_profile: str,
        asset_family: str,
        dedup_strategy: str = "merge",
    ) -> SharedAssetRegistryRecord:
        self._validate_canonical_distinction(promotion_record)
        record = build_shared_asset_registry_record(
            asset=asset,
            promotion_record=promotion_record,
            taxonomy_path=taxonomy_path,
            current_version=current_version,
            created_at=created_at,
        )
        dedup_key = self._build_dedup_key(
            scope_level=record.scope_level,
            taxonomy_path=record.taxonomy_path,
            design_class=design_class,
            interface_type=interface_type,
            stage=stage,
            risk_profile=risk_profile,
            asset_family=asset_family,
        )
        existing = next((entry for entry in self._entries if entry.dedup_key == dedup_key and entry.record.status == "ACTIVE"), None)
        if existing is None:
            self._entries.append(
                SharedRegistryEntry(
                    record=record,
                    design_class=design_class,
                    interface_type=interface_type,
                    stage=stage,
                    risk_profile=risk_profile,
                    asset_family=asset_family,
                    dedup_key=dedup_key,
                )
            )
            return record

        if dedup_strategy not in {"merge", "supersede"}:
            raise ValueError("invalid_dedup_strategy")

        if dedup_strategy == "merge":
            existing.record.current_version = current_version
            existing.record.lineage_refs.append(promotion_record.record_id)
            return existing.record

        existing.record.status = "SUPERSEDED"
        record.supersedes_refs = [existing.record.registry_id]
        self._entries.append(
            SharedRegistryEntry(
                record=record,
                design_class=design_class,
                interface_type=interface_type,
                stage=stage,
                risk_profile=risk_profile,
                asset_family=asset_family,
                dedup_key=dedup_key,
            )
        )
        return record

