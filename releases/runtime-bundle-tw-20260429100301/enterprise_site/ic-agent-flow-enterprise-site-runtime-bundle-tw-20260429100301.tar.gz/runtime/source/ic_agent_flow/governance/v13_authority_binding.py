"""
PRD v1.3 — Phase 2: Authority Binding & Adjudication Baseline

Governing laws:
  - Law 4: Draft vs Authority separation is mandatory
  - Law 5: Final release declaration remains human-governed
  - PRD Section 8: Authority Model
"""

from __future__ import annotations

from typing import List, Optional, Tuple

from ic_agent_flow.domain.objects.v13_silicon_contract_objects import (
    AuthorityBinding,
    AuthorityClosureRecord,
    AuthorityRole,
    AuthorityStatus,
    BlockReason,
    ReleaseDisposition,
    SiliconContract,
    V13_AGENT_PROHIBITED_ACTIONS,
    V13_MANDATORY_AUTHORITY_ROLES,
)


# ---------------------------------------------------------------------------
# Authority Closure Check
# ---------------------------------------------------------------------------

def check_authority_closure(contract: SiliconContract) -> AuthorityClosureRecord:
    """
    Evaluate whether all mandatory authority roles have reached APPROVED status.
    Returns an AuthorityClosureRecord for the given contract state.
    """
    from datetime import datetime, timezone
    import uuid

    approved_roles = [
        b.role
        for b in contract.authority_bindings
        if b.required and b.status == AuthorityStatus.APPROVED
    ]
    required_roles = [b.role for b in contract.authority_bindings if b.required]
    pending_roles = [r for r in required_roles if r not in approved_roles]

    # Ensure V13_MANDATORY_AUTHORITY_ROLES are all required
    for mandatory_role in V13_MANDATORY_AUTHORITY_ROLES:
        if mandatory_role not in required_roles:
            pending_roles.append(mandatory_role)

    all_closed = len(pending_roles) == 0

    # Detect conflict (roles with REJECTED that are also required)
    conflict_detected, conflict_refs = detect_authority_conflict(contract.authority_bindings)

    return AuthorityClosureRecord(
        record_id=f"acr-{uuid.uuid4().hex[:8]}",
        schema_version="0.1",
        contract_ref=contract.contract_id,
        mandatory_roles_required=required_roles,
        mandatory_roles_closed=approved_roles,
        all_mandatory_closed=all_closed,
        pending_roles=pending_roles,
        conflict_detected=conflict_detected,
        conflict_refs=conflict_refs,
        created_at=datetime.now(timezone.utc),
    )


# ---------------------------------------------------------------------------
# Conflict Detection
# ---------------------------------------------------------------------------

def detect_authority_conflict(
    bindings: List[AuthorityBinding],
) -> Tuple[bool, List[str]]:
    """
    Detect conflicting decisions among key authority roles.
    Conflict = at least one required role APPROVED and another REJECTED.
    """
    approved_required = [
        b for b in bindings if b.required and b.status == AuthorityStatus.APPROVED
    ]
    rejected_required = [
        b for b in bindings if b.required and b.status == AuthorityStatus.REJECTED
    ]

    if approved_required and rejected_required:
        conflict_refs = [b.role.value for b in rejected_required]
        return True, conflict_refs

    return False, []


# ---------------------------------------------------------------------------
# Draft vs Authority Enforcement
# ---------------------------------------------------------------------------

def enforce_draft_vs_authority(action: str) -> None:
    """
    Fail-closed: raise ValueError if agent attempts a prohibited authority action.
    Law 4 & Law 5 enforcement.
    """
    if action in V13_AGENT_PROHIBITED_ACTIONS:
        raise ValueError(
            f"Agent authority violation: action '{action}' is prohibited. "
            f"Only human authority may perform: {sorted(V13_AGENT_PROHIBITED_ACTIONS)}"
        )


# ---------------------------------------------------------------------------
# Approval Closure Rule
# ---------------------------------------------------------------------------

def can_enter_approved_for_release(contract: SiliconContract) -> Tuple[bool, List[BlockReason]]:
    """
    Check all conditions required before contract can transition to APPROVED_FOR_RELEASE.
    Returns (can_approve, list_of_blocking_reasons).
    """
    blockers: List[BlockReason] = []

    # chip_id must be resolved
    if not contract.chip_id:
        blockers.append(BlockReason.CHIP_IDENTITY_MISSING)

    # At least one signoff evidence ref required
    if not contract.signoff_evidence_refs:
        blockers.append(BlockReason.EVIDENCE_MISSING)

    # Authority closure must be complete
    closure = check_authority_closure(contract)
    if not closure.all_mandatory_closed:
        blockers.append(BlockReason.AUTHORITY_CLOSURE_INCOMPLETE)

    # Conflict must not exist
    if closure.conflict_detected:
        blockers.append(BlockReason.CONFLICT_UNRESOLVED)

    # Delivery classification must be set
    if not contract.delivery_classification:
        blockers.append(BlockReason.DELIVERY_CLASS_UNDEFINED)

    # open risks must be acknowledged (empty open_risk_refs = no unresolved risks)
    if contract.open_risk_refs:
        blockers.append(BlockReason.CRITICAL_RISK_UNRESOLVED)

    return (len(blockers) == 0, blockers)


# ---------------------------------------------------------------------------
# Adjudication Vocabulary
# ---------------------------------------------------------------------------

V13_RELEASE_ADJUDICATION_VOCAB = frozenset([
    "approve",
    "approve_with_conditions",
    "hold",
    "reject",
    "request_more_evidence",
    "escalate",
    "sign_contract_section",
    "acknowledge_open_risk",
    "block_release",
    "unblock_release",
    "declare_release_ready",
    "return_to_evidence_completion",
])


def validate_adjudication_action(action: str) -> None:
    """Fail-closed: raise ValueError if action is not in V13 vocabulary."""
    if action not in V13_RELEASE_ADJUDICATION_VOCAB:
        raise ValueError(
            f"Invalid adjudication action: '{action}'. "
            f"Must be one of: {sorted(V13_RELEASE_ADJUDICATION_VOCAB)}"
        )


def disposition_from_action(action: str) -> ReleaseDisposition:
    """Map adjudication action to ReleaseDisposition."""
    mapping = {
        "approve": ReleaseDisposition.PROCEED,
        "approve_with_conditions": ReleaseDisposition.PROCEED,
        "hold": ReleaseDisposition.HOLD,
        "reject": ReleaseDisposition.REJECT,
        "request_more_evidence": ReleaseDisposition.REQUIRE_MORE_EVIDENCE,
        "escalate": ReleaseDisposition.ESCALATE,
        "block_release": ReleaseDisposition.HOLD,
        "return_to_evidence_completion": ReleaseDisposition.REQUIRE_MORE_EVIDENCE,
    }
    validate_adjudication_action(action)
    return mapping.get(action, ReleaseDisposition.HOLD)
