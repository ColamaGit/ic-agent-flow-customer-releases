from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from ic_agent_flow.governance.controlled_distribution import (
    DistributionMode,
    default_distribution_policy,
)
from ic_agent_flow.governance.entitlement_policy import (
    EntitlementPolicyValidator,
    EntitlementRecord,
)
from ic_agent_flow.governance.product_ip_classification import (
    DistributionEligibilityChecker,
    ProductIPClass,
    ProductIPClassificationRecord,
)


@dataclass(frozen=True)
class VendorIPGateReport:
    gate_id: str
    allowed: bool
    blocking_reasons: list[str]
    evidence: dict[str, object]


@dataclass(frozen=True)
class DistributionContentManifest:
    manifest_id: str
    bundle_ref: str
    distribution_mode: DistributionMode
    included_assets: list[str]
    excluded_assets: list[str]
    classification_summary: dict[str, int]
    source_exclusion_report_ref: str
    contract_surface_manifest_ref: str
    proprietary_component_manifest_ref: str
    entitlement_ref: str
    sbom_ref: str
    checksum_set_ref: str
    blocked: bool
    blocking_reasons: list[str]
    digest: str
    signature: str


class DistributionContentManifestBuilder:
    def build(
        self,
        *,
        bundle_ref: str,
        distribution_mode: DistributionMode,
        included_assets: list[str],
        classification_records: list[ProductIPClassificationRecord],
        sbom_ref: str,
        checksum_set_ref: str,
        excluded_assets: list[str] | None = None,
    ) -> DistributionContentManifest:
        policy = default_distribution_policy(distribution_mode)
        eligibility = DistributionEligibilityChecker().check_assets(
            asset_paths=included_assets,
            classification_records=classification_records,
            policy=policy,
        )
        classification_summary: dict[str, int] = {}
        for record in classification_records:
            classification_summary[record.classification.value] = classification_summary.get(record.classification.value, 0) + 1

        return DistributionContentManifest(
            manifest_id=f"manifest://{bundle_ref.rsplit('/', 1)[-1]}/distribution-content",
            bundle_ref=bundle_ref,
            distribution_mode=distribution_mode,
            included_assets=list(included_assets),
            excluded_assets=list(excluded_assets or []),
            classification_summary=classification_summary,
            source_exclusion_report_ref=f"source-exclusion://{bundle_ref}",
            contract_surface_manifest_ref=f"contract-surface://{bundle_ref}",
            proprietary_component_manifest_ref=f"proprietary-components://{bundle_ref}",
            entitlement_ref=f"entitlement://{bundle_ref}",
            sbom_ref=sbom_ref,
            checksum_set_ref=checksum_set_ref,
            blocked=not eligibility.allowed,
            blocking_reasons=eligibility.blocking_reasons,
            digest=f"sha256:distribution-content:{bundle_ref}",
            signature=f"sig://distribution-content/{bundle_ref}",
        )


@dataclass(frozen=True)
class ContractSurfaceManifest:
    contract_manifest_id: str
    bundle_ref: str
    schema_refs: list[str]
    internal_schema_refs: list[str]
    support_interface_refs: list[str]
    audit_verification_refs: list[str]


class EncapsulationType(str, Enum):
    COMPILED_BINARY = "compiled_binary"
    PYTHON_WHEEL_WITHOUT_SOURCE = "python_wheel_without_source"
    CONTAINER_LAYER = "container_layer"
    SIGNED_PLUGIN = "signed_plugin"
    MANAGED_SERVICE_ENDPOINT = "managed_service_endpoint"
    OBFUSCATED_INTERMEDIATE_ARTIFACT = "obfuscated_intermediate_artifact"


@dataclass(frozen=True)
class ProprietaryComponentManifest:
    component_manifest_id: str
    component_id: str
    component_type: str
    ip_classification: ProductIPClass
    encapsulation_type: EncapsulationType
    source_included: bool
    binary_ref: str | None = None
    container_layer_ref: str | None = None
    plugin_ref: str | None = None
    service_endpoint_ref: str | None = None
    build_provenance_ref: str | None = None
    allowed_distribution_modes: list[DistributionMode] | None = None


class VendorIPGateRunner:
    prohibited_paths = ["workspace/", "internal-dev/", "tests/", "progress.md", "findings.md"]

    def run_source_exclusion(
        self,
        *,
        included_assets: list[str],
        classification_records: list[ProductIPClassificationRecord],
        distribution_mode: DistributionMode,
    ) -> VendorIPGateReport:
        blocking_reasons: list[str] = []
        records = {record.asset_path: record for record in classification_records}
        for asset in included_assets:
            for prohibited_path in self.prohibited_paths:
                if asset.startswith(prohibited_path) or prohibited_path in asset:
                    blocking_reasons.append(f"prohibited_path:{asset}:{prohibited_path}")
                    break
            record = records.get(asset)
            if (
                distribution_mode != DistributionMode.SOURCE_ESCROW
                and record is not None
                and record.classification in {ProductIPClass.PROPRIETARY_SECRET, ProductIPClass.INTERNAL_ONLY}
            ):
                reason = f"source_exclusion_classification:{asset}:{record.classification.value}"
                if reason not in blocking_reasons:
                    blocking_reasons.append(reason)
        return VendorIPGateReport("IP-2", not blocking_reasons, blocking_reasons, {"included_assets": included_assets})

    def run_contract_surface(
        self,
        manifest: ContractSurfaceManifest,
        distribution_mode: DistributionMode,
    ) -> VendorIPGateReport:
        blocking_reasons: list[str] = []
        if distribution_mode != DistributionMode.SOURCE_ESCROW:
            blocking_reasons.extend(
                f"internal_schema_visible:{schema_ref}" for schema_ref in manifest.internal_schema_refs
            )
        return VendorIPGateReport("IP-3", not blocking_reasons, blocking_reasons, {"manifest_id": manifest.contract_manifest_id})

    def run_proprietary_encapsulation(
        self,
        manifest: ProprietaryComponentManifest,
        distribution_mode: DistributionMode,
    ) -> VendorIPGateReport:
        blocking_reasons: list[str] = []
        if manifest.ip_classification == ProductIPClass.PROPRIETARY_SECRET and manifest.source_included:
            blocking_reasons.append(f"proprietary_source_included:{manifest.component_id}")
        if manifest.allowed_distribution_modes and distribution_mode not in manifest.allowed_distribution_modes:
            blocking_reasons.append(f"component_mode_not_allowed:{manifest.component_id}:{distribution_mode.value}")
        if not manifest.build_provenance_ref:
            blocking_reasons.append(f"build_provenance_required:{manifest.component_id}")
        return VendorIPGateReport("IP-4", not blocking_reasons, blocking_reasons, {"component_id": manifest.component_id})

    def run_entitlement(
        self,
        *,
        entitlement: EntitlementRecord,
        distribution_mode: DistributionMode,
        deployment_profile_ref: str,
        enabled_capabilities: list[str],
    ) -> VendorIPGateReport:
        report = EntitlementPolicyValidator().validate(
            entitlement=entitlement,
            distribution_mode=distribution_mode,
            deployment_profile_ref=deployment_profile_ref,
            enabled_capabilities=enabled_capabilities,
        )
        return VendorIPGateReport("IP-5", report.allowed, report.blocking_reasons, report.feature_gate_report)
