"""
PRD v1.3 — Phase 3: Evidence Attachment & Freshness Law

Governing laws:
  - Law 3: Silicon Contract binds evidence, it does not replace evidence
  - Law 6: Contract must fail-closed
  - PRD Section 9: Evidence Attachment Model
"""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple

from ic_agent_flow.domain.objects.v13_silicon_contract_objects import (
    BlockReason,
    EvidenceFamily,
    EvidenceRef,
    SiliconContract,
    V13_CONDITIONAL_EVIDENCE_FAMILIES,
    V13_MANDATORY_EVIDENCE_FAMILIES,
)


# ---------------------------------------------------------------------------
# Evidence Policy Matrix
# ---------------------------------------------------------------------------

def build_evidence_policy_matrix() -> Dict[str, List[EvidenceFamily]]:
    """
    Return the evidence policy classification matrix.
    Mandatory = must be present before APPROVED_FOR_RELEASE.
    Conditional = required only when applicable (e.g. ECO flow).
    Deferred = explicitly allowed to be absent with justification.
    """
    return {
        "mandatory": list(V13_MANDATORY_EVIDENCE_FAMILIES),
        "conditional": list(V13_CONDITIONAL_EVIDENCE_FAMILIES),
        "deferred": [],  # can be extended for specific chip programs
    }


# ---------------------------------------------------------------------------
# Freshness & Scope Validation
# ---------------------------------------------------------------------------

def validate_evidence_freshness(
    evidence_refs: List[EvidenceRef],
    chip_id: str,
) -> Tuple[bool, List[str]]:
    """
    Validate that evidence refs are fresh and chip-scoped.
    Fails closed if:
      - uri does not contain chip_id (chip scope mismatch)
      - digest is missing (unverifiable source)

    Returns (is_valid, list_of_issues).
    """
    issues: List[str] = []

    for ref in evidence_refs:
        # Chip scope check: uri should reference the chip_id
        if chip_id and chip_id not in ref.uri:
            issues.append(
                f"Evidence '{ref.ref_id}' scope mismatch: "
                f"chip_id '{chip_id}' not found in uri '{ref.uri}'"
            )

        # Digest check: evidence without digest is unverifiable
        if not ref.digest:
            issues.append(
                f"Evidence '{ref.ref_id}' has no digest — source unverifiable"
            )

    return (len(issues) == 0, issues)


# ---------------------------------------------------------------------------
# Lineage Validation
# ---------------------------------------------------------------------------

def validate_evidence_lineage(evidence_refs: List[EvidenceRef]) -> Tuple[bool, List[str]]:
    """
    Validate evidence lineage integrity.
    An evidence ref is considered lineage-broken if its digest is missing or empty.
    Returns (is_valid, list_of_issues).
    """
    issues: List[str] = []

    for ref in evidence_refs:
        if not ref.digest or ref.digest.strip() == "":
            issues.append(
                f"Evidence '{ref.ref_id}' (type={ref.ref_type}): "
                f"lineage broken — digest missing or empty"
            )

    return (len(issues) == 0, issues)


# ---------------------------------------------------------------------------
# Mandatory Evidence Check
# ---------------------------------------------------------------------------

def check_mandatory_evidence_present(
    contract: SiliconContract,
) -> Tuple[bool, List[str]]:
    """
    Check that mandatory evidence families are covered by signoff_evidence_refs.
    Returns (all_present, missing_family_names).
    """
    present_families = set()
    for ref in contract.signoff_evidence_refs:
        if ref.evidence_family:
            present_families.add(ref.evidence_family)

    missing = [
        f.value
        for f in V13_MANDATORY_EVIDENCE_FAMILIES
        if f not in present_families
    ]

    return (len(missing) == 0, missing)


# ---------------------------------------------------------------------------
# Re-entry Compatibility
# ---------------------------------------------------------------------------

def check_reentry_compatibility(
    contract: SiliconContract,
    new_evidence_refs: List[EvidenceRef],
) -> Tuple[bool, List[str]]:
    """
    Validate that new evidence refs from a re-entry cycle can be attached
    to the contract without breaking existing audit chain.

    Rules:
      - New refs must not have the same ref_id as existing refs (collision)
      - New refs must have digest (verifiable source)
      - Chip scope must match
    """
    issues: List[str] = []
    existing_ids = {r.ref_id for r in contract.signoff_evidence_refs}

    for ref in new_evidence_refs:
        # Collision check
        if ref.ref_id in existing_ids:
            issues.append(
                f"Re-entry conflict: ref_id '{ref.ref_id}' already exists "
                f"in contract '{contract.contract_id}'. Use a new ref_id."
            )
        # Digest check
        if not ref.digest:
            issues.append(
                f"Re-entry ref '{ref.ref_id}' has no digest — cannot attach."
            )
        # Chip scope check
        if contract.chip_id and contract.chip_id not in ref.uri:
            issues.append(
                f"Re-entry ref '{ref.ref_id}' scope mismatch: "
                f"chip_id '{contract.chip_id}' not in uri '{ref.uri}'"
            )

    return (len(issues) == 0, issues)


# ---------------------------------------------------------------------------
# Evidence Block Reason Aggregator
# ---------------------------------------------------------------------------

def get_evidence_block_reasons(contract: SiliconContract) -> List[BlockReason]:
    """
    Aggregate all evidence-related block reasons for a contract.
    Used by state machine fail-closed checks.
    """
    reasons: List[BlockReason] = []

    if not contract.signoff_evidence_refs:
        reasons.append(BlockReason.EVIDENCE_MISSING)
        return reasons

    # Freshness check
    fresh_ok, _ = validate_evidence_freshness(
        contract.signoff_evidence_refs, contract.chip_id
    )
    if not fresh_ok:
        reasons.append(BlockReason.EVIDENCE_MISSING)

    # Lineage check
    lineage_ok, _ = validate_evidence_lineage(contract.signoff_evidence_refs)
    if not lineage_ok:
        reasons.append(BlockReason.EVIDENCE_LINEAGE_BROKEN)

    return reasons
