"""
R1 Runtime Proof — No-Proof-No-Claim Gate

Risk Mitigation Plan v0.1 — R1 (P0): Runtime Proof Convergence
Governing: Risk Mitigation Plan Section 3.3 A3

Purpose:
    Enforce the No-Proof-No-Claim law:
      Any claim in roadmap / README / deck / release note must be backed by a registered evidence artifact.

    This gate answers: "Is this claim allowed to be made?"

Claim → Required Proof Matrix:
    claim: "runtime implemented"    → runner + test + artifact
    claim: "customer-ready"         → v1.5 activation evidence
    claim: "IP-safe distribution"   → v1.6 source exclusion + leak scan
    claim: "QA trusted"             → v1.4 trust report
    claim: "release-ready"          → v1.3 silicon contract binder

Usage:
    gate = NoProofNoClaimGate()
    gate.register_proof("runtime implemented", proof_refs=["artifacts/v10-runner-SN2025.json"])
    result = gate.evaluate_claim("runtime implemented")
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional


# ---------------------------------------------------------------------------
# Claim Registry
# ---------------------------------------------------------------------------

# Canonical claim identifiers and their required proof types
CANONICAL_CLAIMS: Dict[str, str] = {
    "runtime implemented":   "runner + test + artifact",
    "customer-ready":        "v1.5 activation evidence",
    "IP-safe distribution":  "v1.6 source exclusion + leak scan",
    "QA trusted":            "v1.4 trust report",
    "release-ready":         "v1.3 silicon contract binder",
}


class ClaimVerdict(str, Enum):
    ALLOWED = "ALLOWED"           # claim is backed by registered proof
    BLOCKED = "BLOCKED"           # claim has no registered proof
    UNKNOWN_CLAIM = "UNKNOWN_CLAIM"  # claim not in canonical registry


# ---------------------------------------------------------------------------
# Data Models
# ---------------------------------------------------------------------------

@dataclass
class ProofRegistration:
    """A registered proof artifact backing a specific claim."""
    claim_id: str
    proof_refs: List[str]                    # artifact file paths or URIs
    registered_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    registered_by: str = "system"


@dataclass
class ClaimEvaluationResult:
    """Result of evaluating a single claim."""
    claim_id: str
    verdict: ClaimVerdict
    required_proof_type: Optional[str]
    registered_proofs: List[str] = field(default_factory=list)
    reason: str = ""


@dataclass
class GateEvaluationReport:
    """Full evaluation report across all claims."""
    gate_run_id: str
    chip_id: str
    run_dir: str
    allowed_claims: List[str] = field(default_factory=list)
    blocked_claims: List[str] = field(default_factory=list)
    unknown_claims: List[str] = field(default_factory=list)
    claim_results: List[ClaimEvaluationResult] = field(default_factory=list)
    overall_gate_pass: bool = False
    artifact_refs: List[str] = field(default_factory=list)
    created_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )

    def to_dict(self) -> dict:
        return {
            "gate_run_id": self.gate_run_id,
            "chip_id": self.chip_id,
            "run_dir": self.run_dir,
            "allowed_claims": self.allowed_claims,
            "blocked_claims": self.blocked_claims,
            "unknown_claims": self.unknown_claims,
            "claim_results": [
                {
                    "claim_id": r.claim_id,
                    "verdict": r.verdict.value,
                    "required_proof_type": r.required_proof_type,
                    "registered_proofs": r.registered_proofs,
                    "reason": r.reason,
                }
                for r in self.claim_results
            ],
            "overall_gate_pass": self.overall_gate_pass,
            "artifact_refs": self.artifact_refs,
            "created_at": self.created_at,
        }


# ---------------------------------------------------------------------------
# Gate Implementation
# ---------------------------------------------------------------------------

class NoProofNoClaimGate:
    """
    No-Proof-No-Claim Gate.

    Maintains a registry of claims → proof artifact refs.
    Evaluates whether a given claim (or set of claims) is allowed to be made.

    Rule: A claim is ALLOWED only if it has at least one registered proof ref.
          A claim with no proof is BLOCKED.
          A claim not in the canonical registry is UNKNOWN_CLAIM.
    """

    def __init__(self, chip_id: str = "GLOBAL"):
        self.chip_id = chip_id
        self._registry: Dict[str, ProofRegistration] = {}

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def register_proof(
        self,
        claim_id: str,
        proof_refs: List[str],
        registered_by: str = "system",
    ) -> None:
        """
        Register proof artifacts for a given claim.

        Args:
            claim_id:       Must match a key in CANONICAL_CLAIMS (or a custom claim).
            proof_refs:     List of artifact paths / URIs that constitute the proof.
            registered_by:  Who registered this proof.
        """
        self._registry[claim_id] = ProofRegistration(
            claim_id=claim_id,
            proof_refs=proof_refs,
            registered_by=registered_by,
        )

    def register_proof_from_runner_result(self, claim_id: str, runner_result_dict: dict) -> None:
        """
        Convenience: register proof from a runner result dict (produced by v1.0/v1.3/v1.4 runners).
        """
        artifact_refs = runner_result_dict.get("artifact_refs", [])
        verdict = runner_result_dict.get("verdict", "FAIL")
        if verdict in ("PASS", "PARTIAL") and artifact_refs:
            self.register_proof(claim_id, proof_refs=artifact_refs, registered_by="runner")

    # ------------------------------------------------------------------
    # Evaluation
    # ------------------------------------------------------------------

    def evaluate_claim(self, claim_id: str) -> ClaimEvaluationResult:
        """
        Evaluate whether a single claim is allowed.

        Returns:
            ClaimEvaluationResult with verdict ALLOWED / BLOCKED / UNKNOWN_CLAIM.
        """
        required_proof_type = CANONICAL_CLAIMS.get(claim_id)

        if claim_id not in CANONICAL_CLAIMS:
            return ClaimEvaluationResult(
                claim_id=claim_id,
                verdict=ClaimVerdict.UNKNOWN_CLAIM,
                required_proof_type=None,
                reason=(
                    f"Claim '{claim_id}' is not in the canonical claim registry. "
                    f"Register it or use one of: {list(CANONICAL_CLAIMS.keys())}"
                ),
            )

        registration = self._registry.get(claim_id)
        if registration and registration.proof_refs:
            return ClaimEvaluationResult(
                claim_id=claim_id,
                verdict=ClaimVerdict.ALLOWED,
                required_proof_type=required_proof_type,
                registered_proofs=registration.proof_refs,
                reason=f"Backed by {len(registration.proof_refs)} proof artifact(s)",
            )

        return ClaimEvaluationResult(
            claim_id=claim_id,
            verdict=ClaimVerdict.BLOCKED,
            required_proof_type=required_proof_type,
            registered_proofs=[],
            reason=(
                f"No proof registered for '{claim_id}'. "
                f"Required: {required_proof_type}"
            ),
        )

    def evaluate_all_canonical_claims(
        self,
        *,
        chip_id: Optional[str] = None,
        run_dir: Path | str = ".",
        gate_run_id: Optional[str] = None,
        emit_artifact: bool = True,
    ) -> GateEvaluationReport:
        """
        Evaluate all canonical claims in the registry.

        Returns a GateEvaluationReport indicating which claims are allowed / blocked.
        overall_gate_pass = True only if zero claims are BLOCKED.
        """
        run_dir = Path(run_dir)
        resolved_chip_id = chip_id or self.chip_id

        if gate_run_id is None:
            ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
            gate_run_id = f"npcg-{resolved_chip_id}-{ts}"

        claim_results: List[ClaimEvaluationResult] = []
        allowed: List[str] = []
        blocked: List[str] = []

        for claim_id in CANONICAL_CLAIMS:
            result = self.evaluate_claim(claim_id)
            claim_results.append(result)
            if result.verdict == ClaimVerdict.ALLOWED:
                allowed.append(claim_id)
            elif result.verdict == ClaimVerdict.BLOCKED:
                blocked.append(claim_id)

        overall_pass = len(blocked) == 0

        report = GateEvaluationReport(
            gate_run_id=gate_run_id,
            chip_id=resolved_chip_id,
            run_dir=str(run_dir),
            allowed_claims=allowed,
            blocked_claims=blocked,
            unknown_claims=[],
            claim_results=claim_results,
            overall_gate_pass=overall_pass,
            artifact_refs=[],
        )

        if emit_artifact:
            evidence_dir = run_dir / "evidence" / "no_proof_no_claim"
            evidence_dir.mkdir(parents=True, exist_ok=True)
            artifact_path = evidence_dir / f"{gate_run_id}.json"
            artifact_path.write_text(
                json.dumps(report.to_dict(), indent=2),
                encoding="utf-8",
            )
            report.artifact_refs.append(str(artifact_path))

        return report


# ---------------------------------------------------------------------------
# Convenience Factory
# ---------------------------------------------------------------------------

def build_gate_from_runner_results(
    chip_id: str,
    *,
    v10_result: Optional[dict] = None,
    v13_result: Optional[dict] = None,
    v14_result: Optional[dict] = None,
    v15_result: Optional[dict] = None,
) -> NoProofNoClaimGate:
    """
    Build a pre-populated NoProofNoClaimGate from runner result dicts.

    Maps runner results to canonical claims:
        v10 PASS → "runtime implemented"
        v13 PASS → "release-ready"
        v14 PROCEED → "QA trusted"
        v15 FULL_IMPL/PROCEED → "customer-ready"
    """
    gate = NoProofNoClaimGate(chip_id=chip_id)

    if v10_result and v10_result.get("verdict") == "PASS":
        gate.register_proof("runtime implemented", proof_refs=v10_result.get("artifact_refs", []))

    if v13_result and v13_result.get("verdict") == "PASS":
        gate.register_proof("release-ready", proof_refs=v13_result.get("artifact_refs", []))

    if v14_result and v14_result.get("overall_verdict") == "PROCEED":
        gate.register_proof("QA trusted", proof_refs=v14_result.get("artifact_refs", []))

    if v15_result and (
        v15_result.get("verdict") == "FULL_IMPL"
        or v15_result.get("recommendation") == "PROCEED"
    ):
        gate.register_proof("customer-ready", proof_refs=v15_result.get("artifact_refs", []))

    # "IP-safe distribution" requires v1.6 — not registered here.
    return gate
