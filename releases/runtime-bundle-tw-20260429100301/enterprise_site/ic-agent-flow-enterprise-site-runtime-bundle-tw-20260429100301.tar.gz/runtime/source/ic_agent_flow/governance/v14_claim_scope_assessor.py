from __future__ import annotations

from pydantic import BaseModel

from ic_agent_flow.domain.objects.v14_qa_trust_layer_objects import (
    ClaimAssessmentItem,
    ClaimScopeAssessment,
    ClaimSource,
    QAAssessmentRun,
    QARef,
)


class ClaimInput(BaseModel):
    claim_id: str
    claim_text: str
    prd_boundary: str
    supporting_evidence_refs: list[QARef]


def _looks_ambiguous(text: str) -> bool:
    normalized = text.lower().strip()
    markers = (
        "etc",
        "and so on",
        "kind of",
        "somehow",
        "...",
        "roughly",
        "full signoff",
    )
    if any(marker in normalized for marker in markers):
        return True
    if len(normalized) < 12:
        return True
    return False


def assess_claim_scope(
    *,
    run: QAAssessmentRun,
    assessment_id: str,
    claim_source: ClaimSource,
    claims: list[ClaimInput],
) -> ClaimScopeAssessment:
    claim_items: list[ClaimAssessmentItem] = []
    unsupported_claims: list[str] = []

    for item in claims:
        if not item.supporting_evidence_refs:
            scope_status = "UNSUPPORTED"
            unsupported_claims.append(item.claim_id)
        elif item.prd_boundary != run.target_scope.prd_scope:
            scope_status = "OVERBROAD"
            unsupported_claims.append(item.claim_id)
        elif _looks_ambiguous(item.claim_text):
            scope_status = "AMBIGUOUS"
        else:
            scope_status = "SUPPORTED"

        claim_items.append(
            ClaimAssessmentItem(
                claim_id=item.claim_id,
                claim_text=item.claim_text,
                prd_boundary=item.prd_boundary,
                supporting_evidence_refs=item.supporting_evidence_refs,
                scope_status=scope_status,
            )
        )

    statuses = {claim.scope_status for claim in claim_items}
    if "OVERBROAD" in statuses or "UNSUPPORTED" in statuses:
        verdict = "OVERBROAD_CLAIM"
    elif "AMBIGUOUS" in statuses:
        verdict = "REVIEW_SURFACE_WEAK"
    else:
        verdict = "ACCEPTABLE"

    return ClaimScopeAssessment(
        id=assessment_id,
        qa_run_ref=run.id,
        claim_source=claim_source,
        claims=claim_items,
        unsupported_claims=unsupported_claims,
        verdict=verdict,
    )
