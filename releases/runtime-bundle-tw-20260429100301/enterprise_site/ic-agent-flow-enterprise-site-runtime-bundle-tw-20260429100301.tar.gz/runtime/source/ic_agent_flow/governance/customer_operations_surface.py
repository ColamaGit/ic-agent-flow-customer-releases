from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from ic_agent_flow.domain.objects.deployment_packaging_objects import (
    AuthorityClass,
    ObjectStatus,
)
from ic_agent_flow.domain.objects.v15_customer_site_activation_objects import (
    CustomerOperationsSurfaceAuditRecord,
    CustomerOperationsSurfaceSnapshot,
    SiteRuntimeManifest,
)


MUTATION_ACTIONS = {
    "approve_activation",
    "grant_role",
    "export_support_bundle",
    "run_upgrade",
    "run_rollback",
    "adopt_update_pack",
}


@dataclass(frozen=True)
class OperationsSurfaceContext:
    site_id: str
    installed_version: str
    runtime_manifest: SiteRuntimeManifest
    trust_root_ref: str
    enabled_capabilities: list[str] = field(default_factory=list)
    forbidden_capabilities: list[str] = field(default_factory=list)
    role_grant_refs: list[str] = field(default_factory=list)
    pending_activation_decision_refs: list[str] = field(default_factory=list)
    support_export_status: str = "NO_PENDING_EXPORT"
    upgrade_rollback_status: str = "NO_PENDING_UPGRADE"
    update_adoption_status: str = "NO_PENDING_UPDATE"
    audit_replay_refs: list[str] = field(default_factory=list)
    source_object_refs: list[str] = field(default_factory=list)


def _digest(prefix: str, site_id: str) -> str:
    return f"sha256:{prefix}-{site_id}-{uuid.uuid4().hex[:8]}"


def build_operations_surface_snapshot(
    *,
    context: OperationsSurfaceContext,
    signature_factory: Any,
) -> CustomerOperationsSurfaceSnapshot:
    source_refs = list(context.source_object_refs)
    if str(context.runtime_manifest.id) not in source_refs:
        source_refs.append(str(context.runtime_manifest.id))

    return CustomerOperationsSurfaceSnapshot(
        version="0.1",
        status=ObjectStatus.ACTIVE,
        authority_class=AuthorityClass.OPERATOR,
        producer="customer-operations-surface@0.1",
        digest=_digest("ops-snapshot", context.site_id),
        signature=signature_factory(),
        site_id=context.site_id,
        installed_version=context.installed_version,
        active_profile_ref=context.runtime_manifest.active_profile_ref,
        policy_overlay_refs=list(context.runtime_manifest.policy_overlay_refs),
        trust_root_ref=context.trust_root_ref,
        enabled_capabilities=list(context.enabled_capabilities),
        forbidden_capabilities=list(context.forbidden_capabilities),
        role_grant_refs=list(context.role_grant_refs),
        pending_activation_decision_refs=list(context.pending_activation_decision_refs),
        support_export_status=context.support_export_status,
        upgrade_rollback_status=context.upgrade_rollback_status,
        update_adoption_status=context.update_adoption_status,
        audit_replay_refs=list(context.audit_replay_refs),
        source_object_refs=source_refs,
    )


def record_surface_action(
    *,
    site_id: str,
    action: str,
    actor: str,
    actor_role: str,
    read_only: bool,
    produced_object_refs: list[str] | None,
    audit_refs: list[str] | None,
    signature_factory: Any,
) -> CustomerOperationsSurfaceAuditRecord:
    mutation_requested = action in MUTATION_ACTIONS
    produced = list(produced_object_refs or [])
    audits = list(audit_refs or [])
    blocked_reasons: list[str] = []

    if read_only and mutation_requested:
        blocked_reasons.append("read_only_actor_cannot_mutate")
    if mutation_requested and not produced:
        blocked_reasons.append("mutation_requires_canonical_governance_object")
    if mutation_requested and not audits:
        blocked_reasons.append("mutation_requires_audit_record")

    return CustomerOperationsSurfaceAuditRecord(
        version="0.1",
        status=ObjectStatus.ACTIVE,
        authority_class=AuthorityClass.OPERATOR,
        producer="customer-operations-surface@0.1",
        digest=_digest("ops-audit", site_id),
        signature=signature_factory(),
        site_id=site_id,
        action=action,
        actor=actor,
        actor_role=actor_role,
        mutation_requested=mutation_requested,
        mutation_allowed=not blocked_reasons,
        produced_object_refs=produced,
        audit_refs=audits,
        blocked_reasons=blocked_reasons,
        created_at=datetime.now(timezone.utc),
    )
