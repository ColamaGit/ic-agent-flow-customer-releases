from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from ic_agent_flow.governance.controlled_distribution import DistributionMode


@dataclass(frozen=True)
class EntitlementRecord:
    entitlement_id: str
    customer_id: str
    license_ref: str
    allowed_distribution_modes: list[DistributionMode]
    allowed_profiles: list[str]
    enabled_capabilities: list[str]
    forbidden_capabilities: list[str]
    adapter_entitlements: list[str]
    backend_entitlements: list[str]
    support_level: str
    source_visibility: str
    valid_from: str
    valid_until: str
    created_at: str
    signature: str


@dataclass(frozen=True)
class EntitlementValidationReport:
    allowed: bool
    blocking_reasons: list[str]
    feature_gate_report: dict[str, object]


class EntitlementPolicyValidator:
    def validate(
        self,
        *,
        entitlement: EntitlementRecord,
        distribution_mode: DistributionMode,
        deployment_profile_ref: str,
        enabled_capabilities: list[str],
        now: str = "2026-04-25T00:00:00+00:00",
    ) -> EntitlementValidationReport:
        blocking_reasons: list[str] = []

        if distribution_mode not in entitlement.allowed_distribution_modes:
            blocking_reasons.append(f"distribution_mode_not_entitled:{distribution_mode.value}")
        if deployment_profile_ref not in entitlement.allowed_profiles:
            blocking_reasons.append(f"profile_not_entitled:{deployment_profile_ref}")

        allowed_capabilities = set(entitlement.enabled_capabilities)
        forbidden_capabilities = set(entitlement.forbidden_capabilities)
        for capability in enabled_capabilities:
            if capability not in allowed_capabilities:
                blocking_reasons.append(f"capability_not_entitled:{capability}")
            if capability in forbidden_capabilities:
                blocking_reasons.append(f"forbidden_capability_enabled:{capability}")

        current = datetime.fromisoformat(now)
        valid_until = datetime.fromisoformat(entitlement.valid_until)
        if current > valid_until:
            blocking_reasons.append("entitlement_expired")

        return EntitlementValidationReport(
            allowed=not blocking_reasons,
            blocking_reasons=blocking_reasons,
            feature_gate_report={
                "entitlement_id": entitlement.entitlement_id,
                "enabled_capabilities": list(enabled_capabilities),
                "allowed": not blocking_reasons,
                "blocking_reasons": blocking_reasons,
            },
        )
