from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from pydantic import BaseModel

from ic_agent_flow.domain.objects.v12_ecosystem_boundary_objects import (
    CustomerPackAdoptionRecord,
    SharedAssetPackRelease,
)


class AdoptionRequest(BaseModel):
    customer_id: str
    decision: str  # accept, defer, reject, override
    reviewer_ref: str
    rationale: str
    override_ref: Optional[str] = None


class SharedAssetPackReleaseReader:
    def read(self, raw_data: Dict[str, Any]) -> SharedAssetPackRelease:
        return SharedAssetPackRelease.model_validate(raw_data)


class CustomerCompatibilityChecker:
    def check_compatibility(self, release: SharedAssetPackRelease, site_manifest: Dict[str, Any]) -> bool:
        """
        Check if the release's compatibility_scope matches the current site configuration.
        """
        # Mock logic: if the required version is in supported_scopes, it's compatible
        # For our tests, we will pass a site_manifest with supported_scopes list
        supported_scopes = site_manifest.get("supported_scopes", [])
        return release.compatibility_scope in supported_scopes


class LocalOverrideBinder:
    def bind_override(self, request: AdoptionRequest) -> None:
        """
        If decision is override, validates that override_ref is present and links it.
        """
        if request.decision == "override":
            if not request.override_ref:
                raise ValueError("local_override_requires_reference")
            if not request.rationale:
                raise ValueError("local_override_requires_rationale")


class CustomerPackAdoptionRecordBuilder:
    def build_decision(self, release: SharedAssetPackRelease, request: AdoptionRequest, is_compatible: bool) -> str:
        """
        Evaluates the final decision state.
        If a user chooses 'accept' but compatibility fails, it fails closed or defaults to deferred/rejected.
        Here we raise ValueError to fail closed.
        """
        if request.decision == "accept" and not is_compatible:
            raise ValueError("compatibility_check_failed")
            
        if request.decision not in ["accept", "defer", "reject", "override"]:
            raise ValueError("invalid_decision")

        return request.decision


class AdoptionAuditEmitter:
    def emit_adoption_record(
        self,
        release: SharedAssetPackRelease,
        request: AdoptionRequest,
        final_decision: str,
    ) -> CustomerPackAdoptionRecord:
        
        # In a real environment, active is true only if the decision is current and applies to runtime
        active = final_decision in ["accept", "override"]
        
        return CustomerPackAdoptionRecord(
            record_id=f"adopt-{uuid.uuid4().hex[:8]}",
            customer_id=request.customer_id,
            release_id=release.release_id,
            pack_version=release.version,
            decision=final_decision,
            reviewer_ref=request.reviewer_ref,
            rationale=request.rationale,
            override_ref=request.override_ref if final_decision == "override" else None,
            active=active,
            reviewed_at=datetime.now(timezone.utc).isoformat(),
        )
