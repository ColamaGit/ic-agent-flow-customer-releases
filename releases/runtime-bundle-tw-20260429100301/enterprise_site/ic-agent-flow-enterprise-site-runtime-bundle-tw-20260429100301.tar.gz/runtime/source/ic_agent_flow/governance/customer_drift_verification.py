from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List

from ic_agent_flow.domain.objects.deployment_packaging_objects import (
    AuthorityClass,
    ObjectStatus,
)
from ic_agent_flow.domain.objects.v15_customer_site_activation_objects import (
    EnvironmentDriftRecord,
    SiteEnvironmentFingerprint,
    SiteRuntimeManifest,
)


class ManifestDriftEvaluator:
    def evaluate(
        self, manifest: SiteRuntimeManifest, fingerprint: SiteEnvironmentFingerprint
    ) -> List[str]:
        """
        Compare the declared SiteRuntimeManifest against the actual SiteEnvironmentFingerprint.
        Returns a list of drift items (strings describing the drift).
        """
        drift_items = []

        # Example validation rule: OS family must match the profile reference (simplified check)
        # In reality, this would check deeper bundle metadata. We simulate a drift condition here.
        if fingerprint.profile_ref != manifest.active_profile_ref:
            drift_items.append(
                f"ERR_INTEGRITY_DRIFT: Active profile mismatch. "
                f"Manifest declares '{manifest.active_profile_ref}', "
                f"environment reports '{fingerprint.profile_ref}'."
            )

        # Example validation rule: OS architecture consistency check
        if fingerprint.os_family == "unknown":
            drift_items.append("ERR_INTEGRITY_DRIFT: Environment OS family is 'unknown'.")

        return drift_items


class DriftRecordBuilder:
    def __init__(self, signature_factory: Any):
        self.signature_factory = signature_factory

    def build_record(
        self,
        site_id: str,
        manifest_ref: str,
        drift_items: List[str],
    ) -> EnvironmentDriftRecord:
        drift_detected = len(drift_items) > 0

        return EnvironmentDriftRecord(
            version="0.1",
            status=ObjectStatus.ACTIVE,
            authority_class=AuthorityClass.OPERATOR,
            producer="drift-evaluator@0.1",
            digest=f"sha256:drift-{site_id}-{uuid.uuid4().hex[:8]}",
            signature=self.signature_factory(),
            site_id=site_id,
            manifest_ref=manifest_ref,
            drift_detected=drift_detected,
            drift_items=drift_items,
            verified_at=datetime.now(timezone.utc).isoformat(),
        )
