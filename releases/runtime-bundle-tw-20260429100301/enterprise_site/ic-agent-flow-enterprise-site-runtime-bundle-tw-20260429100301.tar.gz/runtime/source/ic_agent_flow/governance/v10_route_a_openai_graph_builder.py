from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, Optional

from ic_agent_flow.cognitive import (
    BackendPolicy,
    BackendProvider,
    CognitiveAdapter,
    CognitiveRequest,
    ResponseType,
    SensitivityLevel,
)
from ic_agent_flow.domain.objects.v10_upstream_objects import is_downstream_consumable_object

TZ_TW = timezone(timedelta(hours=8))

REQUIRED_GRAPH_FIELDS = (
    "graph_id",
    "status",
    "module_nodes",
    "port_contracts",
    "dependency_edges",
    "interconnect_edges",
    "clock_reset_domains",
    "lineage_refs",
)
ALLOWED_GRAPH_DRAFT_STATUS = {
    "DRAFT",
    "DRAFT_REFINED",
    "BUILDER_DRAFT_PENDING_VALIDATION",
}


def _tw_now_iso() -> str:
    return datetime.now(TZ_TW).isoformat()


def _validate_graph_payload(payload: Dict[str, Any]) -> Optional[str]:
    missing = [field for field in REQUIRED_GRAPH_FIELDS if field not in payload]
    if missing:
        return f"missing_required_fields:{','.join(missing)}"
    for list_field in REQUIRED_GRAPH_FIELDS[2:]:
        if not isinstance(payload[list_field], list):
            return f"invalid_field_type:{list_field}:expected_list"
    graph_id = payload.get("graph_id")
    if not isinstance(graph_id, str) or not graph_id.strip():
        return "invalid_graph_id:expected_non_empty_string"
    status = payload.get("status")
    if status not in ALLOWED_GRAPH_DRAFT_STATUS:
        return "invalid_graph_status:expected_draft_status"
    return None


def _try_parse_json_payload(raw_text: str) -> Optional[Dict[str, Any]]:
    text = (raw_text or "").strip()
    if not text:
        return None
    try:
        parsed = json.loads(text)
        return parsed if isinstance(parsed, dict) else None
    except json.JSONDecodeError:
        pass

    fenced_marker = "```json"
    if fenced_marker in text:
        tail = text.split(fenced_marker, 1)[1]
        candidate = tail.split("```", 1)[0].strip()
        try:
            parsed = json.loads(candidate)
            return parsed if isinstance(parsed, dict) else None
        except json.JSONDecodeError:
            pass

    first_brace = text.find("{")
    last_brace = text.rfind("}")
    if first_brace != -1 and last_brace > first_brace:
        candidate = text[first_brace:last_brace + 1]
        try:
            parsed = json.loads(candidate)
            return parsed if isinstance(parsed, dict) else None
        except json.JSONDecodeError:
            return None
    return None


def _normalize_path_ref(path: Path, repo_root: Path) -> str:
    return str(path.resolve().relative_to(repo_root.resolve()))


def _dedupe_lineage_refs(items: list[Any]) -> list[Any]:
    deduped: list[Any] = []
    seen: set[str] = set()
    for item in items:
        key = json.dumps(item, ensure_ascii=True, sort_keys=True) if isinstance(item, dict) else str(item)
        if key in seen:
            continue
        seen.add(key)
        deduped.append(item)
    return deduped


def _resolve_existing_ref(repo_root: Path, ref: str) -> Optional[Path]:
    candidate = (repo_root / ref).resolve()
    if candidate.exists() and candidate.is_file():
        return candidate
    return None


def run_route_a_openai_graph_orchestration(
    *,
    chip_id: str,
    requirement_item_ref: str,
    prompt: str,
    repo_root: Path,
    adapter: Optional[CognitiveAdapter] = None,
    openai_test_text: Optional[str] = None,
    supersedes_graph_ref: Optional[str] = None,
) -> Dict[str, Any]:
    """
    System-level orchestration for Route A graph draft generation.
    Ensures:
    1) orchestrator boots OpenAI worker via adapter
    2) worker output is validated as graph payload
    3) draft + handoff + audit are persisted back to flow
    4) invalid output is fail-closed
    """
    adapter = adapter or CognitiveAdapter()
    architecture_dir = repo_root / "chips" / chip_id / "architecture"
    architecture_dir.mkdir(parents=True, exist_ok=True)
    requirement_item_path = _resolve_existing_ref(repo_root, requirement_item_ref)
    supersedes_path = (
        _resolve_existing_ref(repo_root, supersedes_graph_ref)
        if supersedes_graph_ref
        else None
    )

    request = CognitiveRequest(
        agent_id="route_a_graph_builder_worker",
        chip_scope=chip_id,
        task_type="architecture_graph_build",
        prompt=prompt,
        sensitivity=SensitivityLevel.INTERNAL,
        policy=BackendPolicy.REMOTE_ALLOWED_WITH_CONTROLS,
        preferred_provider=BackendProvider.OPENAI,
        max_tokens=2048,
        metadata={
            "orchestrator_id": "v1_0_route_a_orchestrator",
            **({"openai_test_text": openai_test_text} if openai_test_text else {}),
        },
    )

    response = adapter.invoke(request)
    audit = adapter.last_audit
    selection = adapter.last_selection

    audit_path = architecture_dir / "route_a_openai_worker_audit.json"
    audit_path.write_text(
        json.dumps(
            {
                "schema_version": "route-a-openai-worker-audit.v0.1",
                "chip_id": chip_id,
                "request_id": request.request_id,
                "orchestrator_id": request.metadata.get("orchestrator_id"),
                "response_type": response.response_type.value,
                "provider": response.provider.value,
                "model_id": response.model_id,
                "error_message": response.error_message,
                "selection": selection.model_dump(mode="json") if selection else None,
                "audit": audit.model_dump(mode="json") if audit else None,
                "recorded_at": _tw_now_iso(),
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    if requirement_item_path is None:
        return {
            "status": "BLOCKED",
            "reason": "missing_requirement_item_ref",
            "audit_ref": _normalize_path_ref(audit_path, repo_root),
        }
    if supersedes_graph_ref and supersedes_path is None:
        return {
            "status": "BLOCKED",
            "reason": "missing_supersedes_graph_ref",
            "audit_ref": _normalize_path_ref(audit_path, repo_root),
        }

    if response.response_type != ResponseType.TEXT:
        return {
            "status": "BLOCKED",
            "reason": f"worker_not_text:{response.response_type.value}",
            "audit_ref": _normalize_path_ref(audit_path, repo_root),
        }

    payload = _try_parse_json_payload(response.content)
    if payload is None:
        return {
            "status": "BLOCKED",
            "reason": "invalid_graph_payload_json",
            "audit_ref": _normalize_path_ref(audit_path, repo_root),
        }

    validation_error = _validate_graph_payload(payload)
    if validation_error:
        return {
            "status": "BLOCKED",
            "reason": validation_error,
            "audit_ref": _normalize_path_ref(audit_path, repo_root),
        }

    lineage_chain = [requirement_item_ref]
    if supersedes_graph_ref:
        lineage_chain.append(supersedes_graph_ref)
    lineage_chain.extend(payload.get("lineage_refs", []))
    deduped_lineage_chain = _dedupe_lineage_refs(lineage_chain)

    graph_draft_path = architecture_dir / "architecture_graph.draft.json"
    graph_draft = {
        **payload,
        "schema_version": "architecture-graph.v1.0.draft",
        "chip_id": chip_id,
        "draft_status": "BUILDER_DRAFT_PENDING_VALIDATION",
        "source_requirement_item_ref": requirement_item_ref,
        "supersedes_graph_ref": supersedes_graph_ref,
        "generated_by": "route_a_openai_graph_builder_worker",
        "generated_via_orchestrator": request.metadata.get("orchestrator_id"),
        "generated_at": _tw_now_iso(),
        "lineage_refs": deduped_lineage_chain,
    }
    graph_draft_path.write_text(json.dumps(graph_draft, indent=2), encoding="utf-8")

    lineage_record_path = architecture_dir / "route_a_lineage_record.json"
    lineage_record = {
        "schema_version": "route-a-lineage-record.v0.1",
        "chip_id": chip_id,
        "current_graph_draft_ref": _normalize_path_ref(graph_draft_path, repo_root),
        "source_requirement_item_ref": requirement_item_ref,
        "supersedes_graph_ref": supersedes_graph_ref,
        "supersedes_exists": supersedes_path is not None if supersedes_graph_ref else True,
        "lineage_chain": deduped_lineage_chain,
        "lineage_supersedes_complete": not supersedes_graph_ref or supersedes_path is not None,
        "audit_ref": _normalize_path_ref(audit_path, repo_root),
        "recorded_at": _tw_now_iso(),
    }
    lineage_record_path.write_text(json.dumps(lineage_record, indent=2), encoding="utf-8")

    handoff_path = architecture_dir / "builder_validation_handoff.json"
    handoff = {
        "schema_version": "builder-validation-handoff.v0.2",
        "chip_id": chip_id,
        "graph_draft_ref": _normalize_path_ref(graph_draft_path, repo_root),
        "requirement_item_ref": requirement_item_ref,
        "audit_ref": _normalize_path_ref(audit_path, repo_root),
        "lineage_record_ref": _normalize_path_ref(lineage_record_path, repo_root),
        "validation_handoff_contract": {
            "required_validator_families": [
                "schema",
                "interface",
            ],
            "allowed_freeze_verdicts": [
                "PASS",
                "PASS_WITH_WARNINGS",
            ],
            "freeze_blocking_verdicts": [
                "BLOCKED",
                "INVALID",
            ],
        },
        "authority_boundary": {
            "builder_may_freeze": False,
            "builder_may_declare_canonical": False,
            "validator_may_declare_freeze": False,
            "human_decision_required": True,
        },
        "downstream_consumable_check": {
            "architecture_graph": is_downstream_consumable_object("architecture_graph"),
            "graph_validation_result": is_downstream_consumable_object("graph_validation_result"),
            "graph_freeze_record": is_downstream_consumable_object("graph_freeze_record"),
            "graph_to_generation_plan": is_downstream_consumable_object("graph_to_generation_plan"),
        },
        "lineage_supersedes_complete": lineage_record["lineage_supersedes_complete"],
        "handoff_status": "PENDING_VALIDATION",
        "created_at": _tw_now_iso(),
    }
    handoff_path.write_text(json.dumps(handoff, indent=2), encoding="utf-8")

    return {
        "status": "DRAFT_SAVED",
        "graph_draft_ref": _normalize_path_ref(graph_draft_path, repo_root),
        "builder_handoff_ref": _normalize_path_ref(handoff_path, repo_root),
        "lineage_record_ref": _normalize_path_ref(lineage_record_path, repo_root),
        "audit_ref": _normalize_path_ref(audit_path, repo_root),
    }
