from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any

from ic_agent_flow.governance.product_ip_classification import ProductIPClass


class DistributionMode(str, Enum):
    BINARY_RUNTIME = "BINARY_RUNTIME"
    CONTAINER_RUNTIME = "CONTAINER_RUNTIME"
    SIGNED_PLUGIN_RUNTIME = "SIGNED_PLUGIN_RUNTIME"
    MANAGED_SERVICE = "MANAGED_SERVICE"
    SOURCE_AVAILABLE_ENTERPRISE = "SOURCE_AVAILABLE_ENTERPRISE"
    SOURCE_ESCROW = "SOURCE_ESCROW"
    PARTNER_SDK = "PARTNER_SDK"
    EVALUATION_LIMITED = "EVALUATION_LIMITED"


class SchemaClass(str, Enum):
    PUBLIC_CONTRACT_SCHEMA = "public_contract_schema"
    CUSTOMER_RUNTIME_SCHEMA = "customer_runtime_schema"
    DEPLOYMENT_PROFILE_SCHEMA = "deployment_profile_schema"
    SUPPORT_SCHEMA = "support_schema"
    AUDIT_VERIFICATION_SCHEMA = "audit_verification_schema"
    INTERNAL_GOVERNANCE_SCHEMA = "internal_governance_schema"
    VALIDATOR_INTERNAL_SCHEMA = "validator_internal_schema"
    SOURCE_ESCROW_SCHEMA = "source_escrow_schema"


@dataclass(frozen=True)
class DistributionModeValidationResult:
    allowed: bool
    blocking_reasons: list[str]


@dataclass(frozen=True)
class DistributionModePolicy:
    mode: DistributionMode
    allowed_ip_classes: list[ProductIPClass]
    prohibited_ip_classes: list[ProductIPClass]
    allowed_component_types: list[str]
    source_visibility: str
    allowed_schema_classes: list[SchemaClass]
    support_export_policy: str
    entitlement_required: bool
    license_ref_required: bool
    audit_required: bool

    def validate(self, *, entitlement: Any, license_ref: str | None) -> DistributionModeValidationResult:
        blocking_reasons: list[str] = []
        if self.entitlement_required and entitlement is None:
            blocking_reasons.append("entitlement_required")
        if self.license_ref_required and not license_ref:
            blocking_reasons.append("license_ref_required")
        return DistributionModeValidationResult(allowed=not blocking_reasons, blocking_reasons=blocking_reasons)


def default_distribution_policy(mode: DistributionMode) -> DistributionModePolicy:
    common_customer_schema = [
        SchemaClass.PUBLIC_CONTRACT_SCHEMA,
        SchemaClass.CUSTOMER_RUNTIME_SCHEMA,
        SchemaClass.DEPLOYMENT_PROFILE_SCHEMA,
        SchemaClass.SUPPORT_SCHEMA,
        SchemaClass.AUDIT_VERIFICATION_SCHEMA,
    ]
    prohibited_default = [
        ProductIPClass.INTERNAL_ONLY,
        ProductIPClass.PROPRIETARY_SECRET,
        ProductIPClass.SOURCE_ESCROW_ONLY,
    ]

    if mode == DistributionMode.PARTNER_SDK:
        return DistributionModePolicy(
            mode=mode,
            allowed_ip_classes=[ProductIPClass.PUBLIC_CONTRACT, ProductIPClass.PARTNER_SDK_ALLOWED],
            prohibited_ip_classes=[ProductIPClass.PROPRIETARY_SECRET, ProductIPClass.INTERNAL_ONLY],
            allowed_component_types=["sdk_boundary", "plugin_contract", "sample"],
            source_visibility="sdk_only",
            allowed_schema_classes=[SchemaClass.PUBLIC_CONTRACT_SCHEMA, SchemaClass.SUPPORT_SCHEMA],
            support_export_policy="bounded_dual_redaction",
            entitlement_required=True,
            license_ref_required=True,
            audit_required=True,
        )

    if mode == DistributionMode.SOURCE_ESCROW:
        return DistributionModePolicy(
            mode=mode,
            allowed_ip_classes=[
                ProductIPClass.PUBLIC_CONTRACT,
                ProductIPClass.CUSTOMER_RUNTIME,
                ProductIPClass.SOURCE_ESCROW_ONLY,
            ],
            prohibited_ip_classes=[ProductIPClass.INTERNAL_ONLY, ProductIPClass.PROPRIETARY_SECRET],
            allowed_component_types=["source_subset", "escrow_manifest"],
            source_visibility="escrow_subset",
            allowed_schema_classes=common_customer_schema + [SchemaClass.SOURCE_ESCROW_SCHEMA],
            support_export_policy="escrow_audited",
            entitlement_required=True,
            license_ref_required=True,
            audit_required=True,
        )

    if mode == DistributionMode.MANAGED_SERVICE:
        return DistributionModePolicy(
            mode=mode,
            allowed_ip_classes=[
                ProductIPClass.PUBLIC_CONTRACT,
                ProductIPClass.CUSTOMER_CONFIGURABLE,
                ProductIPClass.CUSTOMER_REVIEWABLE,
                ProductIPClass.SUPPORT_ONLY,
            ],
            prohibited_ip_classes=prohibited_default,
            allowed_component_types=["service_endpoint", "contract_manifest"],
            source_visibility="service_only",
            allowed_schema_classes=common_customer_schema,
            support_export_policy="bounded_dual_redaction",
            entitlement_required=True,
            license_ref_required=False,
            audit_required=True,
        )

    allowed = [
        ProductIPClass.PUBLIC_CONTRACT,
        ProductIPClass.CUSTOMER_RUNTIME,
        ProductIPClass.CUSTOMER_CONFIGURABLE,
        ProductIPClass.CUSTOMER_REVIEWABLE,
        ProductIPClass.SUPPORT_ONLY,
    ]
    if mode == DistributionMode.EVALUATION_LIMITED:
        allowed.append(ProductIPClass.PARTNER_SDK_ALLOWED)

    return DistributionModePolicy(
        mode=mode,
        allowed_ip_classes=allowed,
        prohibited_ip_classes=prohibited_default + [ProductIPClass.PARTNER_SDK_ALLOWED],
        allowed_component_types=["binary", "container_layer", "signed_plugin", "contract_manifest"],
        source_visibility="none",
        allowed_schema_classes=common_customer_schema,
        support_export_policy="bounded_dual_redaction",
        entitlement_required=True,
        license_ref_required=False,
        audit_required=True,
    )
