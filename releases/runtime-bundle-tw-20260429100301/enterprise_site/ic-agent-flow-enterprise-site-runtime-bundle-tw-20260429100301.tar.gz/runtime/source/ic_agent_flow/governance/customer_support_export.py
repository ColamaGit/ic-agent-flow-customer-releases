from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, List, Optional

from ic_agent_flow.domain.objects.deployment_packaging_objects import (
    ExportClass,
    RedactionLevel,
    SupportAuditBundle,
    AuthorityClass,
    ObjectStatus,
    SignatureBlock,
)

@dataclass
class SupportBundleRequest:
    incident_id: str
    time_window: str
    included_logs: List[str]
    export_reason: str
    customer_approval_ref: str
    requested_by: str
    exported_to: str


class SupportRedactionPolicy:
    def __init__(self, level: RedactionLevel, rules: dict[str, str] = None):
        self.level = level
        self.rules = rules or {}

    def apply_redaction(self, logs: List[str]) -> List[str]:
        # Minimal mock implementation
        if self.level == RedactionLevel.NONE:
            return list(logs)
        return [f"[REDACTED:{self.level.value}] {log}" for log in logs]


class SupportExportClassifier:
    def __init__(
        self,
        allowlist: List[str],
        denylist: List[str],
        default_export_class: ExportClass = ExportClass.CUSTOMER_SHAREABLE,
    ):
        self.allowlist = allowlist
        self.denylist = denylist
        self.default_export_class = default_export_class

    def check_compliance(self, target_logs: List[str]) -> bool:
        for log in target_logs:
            if any(denied in log for denied in self.denylist):
                return False
        return True


class SupportExportAuditor:
    def __init__(self, audit_log_path: str):
        self.audit_log_path = audit_log_path
        self._records: List[dict] = []

    def record_export(
        self,
        request: SupportBundleRequest,
        export_class: ExportClass,
        redaction_level: RedactionLevel,
        verdict: str,
    ) -> str:
        audit_id = f"audit://support-export/{request.incident_id}/{len(self._records) + 1}"
        record = {
            "audit_id": audit_id,
            "incident_id": request.incident_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "requested_by": request.requested_by,
            "exported_to": request.exported_to,
            "export_class": export_class.value,
            "redaction_level": redaction_level.value,
            "verdict": verdict,
            "approval_ref": request.customer_approval_ref,
        }
        self._records.append(record)
        return audit_id


class SupportBundleBuilder:
    def __init__(
        self,
        classifier: SupportExportClassifier,
        redaction_policy: SupportRedactionPolicy,
        auditor: SupportExportAuditor,
        signature_factory: Any,
    ):
        self.classifier = classifier
        self.redaction_policy = redaction_policy
        self.auditor = auditor
        self.signature_factory = signature_factory

    def build_bundle(self, request: SupportBundleRequest) -> SupportAuditBundle:
        if not request.customer_approval_ref:
            self.auditor.record_export(request, self.classifier.default_export_class, self.redaction_policy.level, "BLOCKED_UNAUTHORIZED")
            raise ValueError("support_export_unauthorized")

        if not self.classifier.check_compliance(request.included_logs):
            self.auditor.record_export(request, self.classifier.default_export_class, self.redaction_policy.level, "BLOCKED_DENYLIST")
            raise ValueError("support_export_contains_denied_objects")

        audit_ref = self.auditor.record_export(request, self.classifier.default_export_class, self.redaction_policy.level, "APPROVED")

        redacted_logs = self.redaction_policy.apply_redaction(request.included_logs)

        return SupportAuditBundle(
            version="0.1",
            status=ObjectStatus.ACTIVE,
            authority_class=AuthorityClass.OPERATOR,
            producer="customer-support-builder@0.1",
            digest=f"sha256:support-{request.incident_id}",
            signature=self.signature_factory(),
            incident_id=request.incident_id,
            time_window=request.time_window,
            included_logs=redacted_logs,
            redaction_policy=self.redaction_policy.level.value,
            export_reason=request.export_reason,
            export_class=self.classifier.default_export_class,
            included_object_allowlist=self.classifier.allowlist,
            prohibited_object_denylist=self.classifier.denylist,
            redaction_level=self.redaction_policy.level,
            customer_approval_ref=request.customer_approval_ref,
            generated_by=request.requested_by,
            exported_to=request.exported_to,
            audit_record_ref=audit_ref,
        )
