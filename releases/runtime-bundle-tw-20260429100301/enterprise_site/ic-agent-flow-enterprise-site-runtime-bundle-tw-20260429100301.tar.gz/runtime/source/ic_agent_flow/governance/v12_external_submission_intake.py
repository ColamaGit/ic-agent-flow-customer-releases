from __future__ import annotations

from dataclasses import dataclass, field

from ic_agent_flow.domain.objects.v12_ecosystem_boundary_objects import (
    CONFIDENTIALITY_DECLARATIONS,
    SANITIZATION_LEVELS,
    V12_FIRST_WAVE_EXTERNAL_ASSET_FAMILIES,
    V12_SHARE_SCOPE_CLASSES,
    ExternalAssetSubmissionRecord,
)


@dataclass
class IntakeDecision:
    status: str
    rejection_reasons: list[str] = field(default_factory=list)


class ExternalSubmissionIntakeQueue:
    def __init__(self) -> None:
        self._queue: list[ExternalAssetSubmissionRecord] = []

    def _validate(self, record: ExternalAssetSubmissionRecord) -> list[str]:
        reasons: list[str] = []
        if record.source_scope_class not in V12_SHARE_SCOPE_CLASSES:
            reasons.append("invalid_source_scope_class")
        elif record.source_scope_class == "customer_local_only":
            reasons.append("source_scope_not_shareable")

        if record.source_family not in V12_FIRST_WAVE_EXTERNAL_ASSET_FAMILIES:
            reasons.append("unsupported_source_family")
        if not record.share_back_intent:
            reasons.append("share_back_intent_required")
        if not (record.customer_approval_ref or "").strip():
            reasons.append("approval_required")
        if record.sanitization_level not in {"basic", "strict"}:
            reasons.append("sanitization_level_not_allowed")
        if record.confidentiality_declaration not in CONFIDENTIALITY_DECLARATIONS:
            reasons.append("confidentiality_declaration_invalid")
        if not record.evidence_refs:
            reasons.append("evidence_refs_required")
        return reasons

    def submit(self, record: ExternalAssetSubmissionRecord) -> IntakeDecision:
        reasons = self._validate(record)
        if reasons:
            return IntakeDecision(status="REJECTED", rejection_reasons=reasons)
        self._queue.append(record)
        return IntakeDecision(status="QUEUED", rejection_reasons=[])

    def list_queue(self) -> list[ExternalAssetSubmissionRecord]:
        return list(self._queue)

    def dequeue_next(self) -> ExternalAssetSubmissionRecord | None:
        if not self._queue:
            return None
        return self._queue.pop(0)
