from __future__ import annotations

from ic_agent_flow.domain.objects.v14_qa_trust_layer_objects import (
    QAAssessmentRun,
    QARef,
    ScenarioCoverageSummary,
    ScenarioValidationReport,
)


_SCENARIO_STATUSES = {"PASS", "FAIL", "NOT_TESTED"}


def assess_scenario_validation(
    *,
    run: QAAssessmentRun,
    report_id: str,
    scenario_id: str,
    scenario_name: str,
    happy_path_status: str,
    negative_path_status: str,
    reentry_status: str,
    fail_closed_status: str,
    evidence_refs: list[QARef],
    gaps: list[str] | None = None,
) -> ScenarioValidationReport:
    statuses = {
        "happy_path_status": happy_path_status,
        "negative_path_status": negative_path_status,
        "reentry_status": reentry_status,
        "fail_closed_status": fail_closed_status,
    }
    for key, value in statuses.items():
        if value not in _SCENARIO_STATUSES:
            raise ValueError(f"invalid_{key}")

    gap_items = list(gaps or [])
    all_pass = all(value == "PASS" for value in statuses.values())
    if not all_pass and not gap_items:
        gap_items.append("required_path_not_passed")

    if all_pass:
        verdict = "ACCEPTABLE"
    else:
        verdict = "SCENARIO_GAP"

    covered_paths = sum(1 for value in statuses.values() if value == "PASS")
    required_paths = len(statuses)

    return ScenarioValidationReport(
        id=report_id,
        qa_run_ref=run.id,
        scenario_id=scenario_id,
        scenario_name=scenario_name,
        happy_path_status=happy_path_status,
        negative_path_status=negative_path_status,
        reentry_status=reentry_status,
        fail_closed_status=fail_closed_status,
        coverage_summary=ScenarioCoverageSummary(
            covered_paths=covered_paths,
            required_paths=required_paths,
        ),
        evidence_refs=evidence_refs,
        gaps=gap_items,
        verdict=verdict,
    )
