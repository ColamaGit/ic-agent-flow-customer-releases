from __future__ import annotations

from dataclasses import dataclass

from ic_agent_flow.governance.controlled_distribution import DistributionMode


@dataclass(frozen=True)
class SourceEscrowRecord:
    escrow_id: str
    customer_id: str
    distribution_mode: DistributionMode
    legal_ref: str
    license_ref: str
    allowed_source_subset: list[str]
    excluded_internal_assets: list[str]
    trigger_condition: str
    audit_record_ref: str
    signature: str


@dataclass(frozen=True)
class SourceEscrowValidationReport:
    allowed: bool
    blocking_reasons: list[str]
    audit_report: dict[str, object]


class SourceEscrowPolicyValidator:
    internal_prefixes = ["workspace/", "internal-dev/", "tests/"]

    def validate_source_package(
        self,
        *,
        distribution_mode: DistributionMode,
        included_source_paths: list[str],
        escrow_record: SourceEscrowRecord | None,
    ) -> SourceEscrowValidationReport:
        blocking_reasons: list[str] = []
        if included_source_paths and distribution_mode not in {
            DistributionMode.SOURCE_ESCROW,
            DistributionMode.SOURCE_AVAILABLE_ENTERPRISE,
        }:
            blocking_reasons.extend(
                f"source_requires_escrow_mode:{source_path}" for source_path in included_source_paths
            )

        if distribution_mode in {DistributionMode.SOURCE_ESCROW, DistributionMode.SOURCE_AVAILABLE_ENTERPRISE}:
            if escrow_record is None:
                blocking_reasons.append("source_escrow_record_required")
            else:
                if not escrow_record.legal_ref:
                    blocking_reasons.append("legal_ref_required")
                if not escrow_record.license_ref:
                    blocking_reasons.append("license_ref_required")
                for source_path in included_source_paths:
                    if any(source_path.startswith(prefix) for prefix in self.internal_prefixes):
                        blocking_reasons.append(f"internal_asset_in_source_package:{source_path}")
                    elif source_path not in escrow_record.allowed_source_subset:
                        blocking_reasons.append(f"source_not_in_allowed_subset:{source_path}")

        audit_report = {
            "escrow_id": escrow_record.escrow_id if escrow_record else None,
            "distribution_mode": distribution_mode.value,
            "included_source_paths": list(included_source_paths),
            "allowed": not blocking_reasons,
            "blocking_reasons": blocking_reasons,
        }
        return SourceEscrowValidationReport(
            allowed=not blocking_reasons,
            blocking_reasons=blocking_reasons,
            audit_report=audit_report,
        )
