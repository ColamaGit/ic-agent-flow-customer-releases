from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional
from uuid import uuid4

from pydantic import BaseModel

from ic_agent_flow.registry.scenario_registry import Disposition


def _collect_rtl_files(rtl_path: Path) -> List[Path]:
    if rtl_path.is_file():
        return [rtl_path]
    if rtl_path.is_dir():
        return sorted(list(rtl_path.glob("*.v")) + list(rtl_path.glob("*.sv")))
    return []


def _signal_is_reset(name: str) -> bool:
    n = name.lower()
    return ("rst" in n) or ("reset" in n)


def _extract_sensitivity_blocks(text: str) -> List[str]:
    return re.findall(r"always(?:_ff)?\s*@\s*\((.*?)\)", text, flags=re.IGNORECASE | re.DOTALL)


def _extract_edge_signals(sensitivity: str) -> List[str]:
    return re.findall(r"(?:posedge|negedge)\s+([A-Za-z_][A-Za-z0-9_$]*)", sensitivity, flags=re.IGNORECASE)


def _extract_module_instantiations(text: str) -> List[str]:
    # Heuristic only: enough for bounded readiness analysis.
    return re.findall(
        r"^\s*([A-Za-z_][A-Za-z0-9_$]*)\s+[A-Za-z_][A-Za-z0-9_$]*\s*\(",
        text,
        flags=re.MULTILINE,
    )


def _compute_analysis(rtl_files: List[Path]) -> Dict:
    clock_signals = set()
    reset_signals = set()
    always_blocks = 0
    async_reset_blocks = 0
    module_instantiations = []
    assertion_count = 0
    assume_count = 0
    cover_count = 0

    for rtl in rtl_files:
        text = rtl.read_text(encoding="utf-8", errors="ignore")
        assertion_count += len(re.findall(r"\bassert\b", text))
        assume_count += len(re.findall(r"\bassume\b", text))
        cover_count += len(re.findall(r"\bcover\b", text))
        module_instantiations.extend(_extract_module_instantiations(text))
        for sensitivity in _extract_sensitivity_blocks(text):
            always_blocks += 1
            edge_signals = _extract_edge_signals(sensitivity)
            if not edge_signals:
                continue
            saw_clock = False
            saw_reset = False
            for sig in edge_signals:
                if _signal_is_reset(sig):
                    reset_signals.add(sig)
                    saw_reset = True
                else:
                    clock_signals.add(sig)
                    saw_clock = True
            if saw_clock and saw_reset:
                async_reset_blocks += 1

    synchronizer_candidates = [
        name for name in module_instantiations
        if any(token in name.lower() for token in ("sync", "synchronizer", "cdc"))
    ]

    clock_domain_count = len(clock_signals)
    reset_domain_count = len(reset_signals)
    cdc_status = "NOT CHECKED"
    cdc_notes = "No sequential always block with explicit edge-triggered clock detected"
    if clock_domain_count == 1:
        cdc_status = "PASS"
        cdc_notes = "Single clock-domain structure detected from RTL sensitivity lists"
    elif clock_domain_count > 1:
        cdc_status = "PARTIAL"
        if synchronizer_candidates:
            cdc_notes = (
                "Multi-clock structure detected; synchronizer-like instances found. "
                "Dedicated CDC signoff tool is still required for closure."
            )
        else:
            cdc_notes = (
                "Multi-clock structure detected; no synchronizer-like instance detected by heuristic scan. "
                "Manual review or CDC tool execution is required."
            )

    rdc_status = "NOT CHECKED"
    rdc_notes = "No reset signal detected in edge-triggered sensitivity lists"
    if reset_domain_count == 1 and async_reset_blocks == 0:
        rdc_status = "PASS"
        rdc_notes = "Single reset-domain detected and no async-reset edge-mixing observed"
    elif reset_domain_count >= 1:
        rdc_status = "PARTIAL"
        if reset_domain_count > 1:
            rdc_notes = "Multiple reset-domain signals detected; dedicated RDC analysis is required"
        else:
            rdc_notes = "Async reset edge-mixing detected; dedicated RDC analysis is required"

    formal_status = "NOT CHECKED"
    formal_notes = "No assertion-like statement found in RTL text"
    if assertion_count > 0 or assume_count > 0 or cover_count > 0:
        formal_status = "PARTIAL"
        formal_notes = (
            "Structural formal properties detected in RTL; property-proving run is still required "
            "for formal closure"
        )

    return {
        "clock_signals": sorted(clock_signals),
        "reset_signals": sorted(reset_signals),
        "clock_domain_count": clock_domain_count,
        "reset_domain_count": reset_domain_count,
        "always_block_count": always_blocks,
        "async_reset_blocks": async_reset_blocks,
        "module_instantiations_sample": sorted(set(module_instantiations))[:80],
        "synchronizer_candidates": sorted(set(synchronizer_candidates)),
        "assertion_count": assertion_count,
        "assume_count": assume_count,
        "cover_count": cover_count,
        "cdc_status": cdc_status,
        "cdc_notes": cdc_notes,
        "rdc_status": rdc_status,
        "rdc_notes": rdc_notes,
        "formal_status": formal_status,
        "formal_notes": formal_notes,
    }


class CdcRdcAnalysisRequest(BaseModel):
    workspace_id: str
    chip_id: str
    task_id: str
    decision_context_ref: str
    contract_name: str
    contract_version: str
    rtl_path: str
    top_module: str
    output_root: str = "artifacts/v0.9/cdc_rdc"
    request_schema_version: str = "v0.1"
    run_key: Optional[str] = None


class CdcRdcAnalysisResponse(BaseModel):
    disposition: Disposition
    reason: str
    contract_id: str
    request_schema_version: str
    boundary_mode: str
    error_taxonomy: List[str]
    run_id: Optional[str] = None
    execution_run_ref: Optional[str] = None
    artifact_paths: Dict[str, str] = {}
    artifact_refs: Dict[str, str] = {}


CdcRdcAnalysisRequest.model_rebuild()
CdcRdcAnalysisResponse.model_rebuild()


class CdcRdcAnalysisCapabilityBoundary:
    CAPABILITY_NAME = "cdc_rdc_structural_analysis"
    CONTRACT_NAME = "cdc_rdc_structural_contract"
    CONTRACT_VERSION = "v0.1"
    BOUNDARY_MODE = "formal_mcp_capability_boundary_local_mode_v0.1"
    ERROR_TAXONOMY = [
        "chip_scope_unresolved",
        "input_schema_invalid",
        "artifact_missing",
        "output_unparseable",
        "decision_context_mismatch",
    ]

    @staticmethod
    def _sha256_file(path: Path) -> str:
        h = hashlib.sha256()
        with path.open("rb") as f:
            while True:
                chunk = f.read(8192)
                if not chunk:
                    break
                h.update(chunk)
        return h.hexdigest()

    @classmethod
    def _fail(cls, reason: str, req: CdcRdcAnalysisRequest) -> CdcRdcAnalysisResponse:
        return CdcRdcAnalysisResponse(
            disposition=Disposition.FAIL_CLOSED,
            reason=reason,
            contract_id=f"{req.contract_name}@{req.contract_version}",
            request_schema_version=req.request_schema_version,
            boundary_mode=cls.BOUNDARY_MODE,
            error_taxonomy=list(cls.ERROR_TAXONOMY),
        )

    def execute(self, req: CdcRdcAnalysisRequest) -> CdcRdcAnalysisResponse:
        required = [
            req.workspace_id,
            req.chip_id,
            req.task_id,
            req.decision_context_ref,
            req.contract_name,
            req.contract_version,
            req.rtl_path,
            req.top_module,
        ]
        if any(not value for value in required):
            return self._fail("input_schema_invalid:envelope_missing", req)
        if req.contract_name != self.CONTRACT_NAME or req.contract_version != self.CONTRACT_VERSION:
            return self._fail("input_schema_invalid:unsupported_contract", req)
        if not req.decision_context_ref.startswith("decision://"):
            return self._fail("decision_context_mismatch:invalid_context", req)

        rtl_path = Path(req.rtl_path)
        rtl_files = _collect_rtl_files(rtl_path)
        if not rtl_files:
            return self._fail("artifact_missing:rtl_sources_not_found", req)

        run_id = req.run_key or f"cra-{uuid4().hex[:12]}"
        out_dir = Path(req.output_root) / run_id
        out_dir.mkdir(parents=True, exist_ok=True)

        raw_path = out_dir / "structural_analysis.raw.json"
        cdc_path = out_dir / "normalized.cdc.meta.json"
        rdc_path = out_dir / "normalized.rdc.meta.json"
        formal_path = out_dir / "normalized.formal.meta.json"
        input_manifest_path = out_dir / "input_manifest.json"
        lineage_path = out_dir / "lineage.json"
        evidence_bundle_path = out_dir / "evidence_bundle.json"

        started_at = datetime.now(timezone.utc)
        analysis = _compute_analysis(rtl_files)
        finished_at = datetime.now(timezone.utc)
        duration_ms = int((finished_at - started_at).total_seconds() * 1000)

        raw_payload = {
            "chip_id": req.chip_id,
            "task_id": req.task_id,
            "top_module": req.top_module,
            "rtl_files": [p.as_posix() for p in rtl_files],
            "analysis": analysis,
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }
        raw_path.write_text(json.dumps(raw_payload, indent=2), encoding="utf-8")

        cdc_meta = {
            "tool": "rtl_structural_analyzer",
            "status": analysis["cdc_status"],
            "clock_domain_count": analysis["clock_domain_count"],
            "clock_signals": analysis["clock_signals"],
            "synchronizer_candidates": analysis["synchronizer_candidates"],
            "always_block_count": analysis["always_block_count"],
            "notes": analysis["cdc_notes"],
            "contract_name": req.contract_name,
            "contract_version": req.contract_version,
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }
        cdc_path.write_text(json.dumps(cdc_meta, indent=2), encoding="utf-8")

        rdc_meta = {
            "tool": "rtl_structural_analyzer",
            "status": analysis["rdc_status"],
            "reset_domain_count": analysis["reset_domain_count"],
            "reset_signals": analysis["reset_signals"],
            "async_reset_blocks": analysis["async_reset_blocks"],
            "notes": analysis["rdc_notes"],
            "contract_name": req.contract_name,
            "contract_version": req.contract_version,
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }
        rdc_path.write_text(json.dumps(rdc_meta, indent=2), encoding="utf-8")

        formal_meta = {
            "tool": "rtl_structural_analyzer",
            "status": analysis["formal_status"],
            "assertion_count": analysis["assertion_count"],
            "assume_count": analysis["assume_count"],
            "cover_count": analysis["cover_count"],
            "proof_engine": "not_executed",
            "notes": analysis["formal_notes"],
            "contract_name": req.contract_name,
            "contract_version": req.contract_version,
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }
        formal_path.write_text(json.dumps(formal_meta, indent=2), encoding="utf-8")

        input_manifest = {
            "workspace_id": req.workspace_id,
            "chip_id": req.chip_id,
            "task_id": req.task_id,
            "decision_context_ref": req.decision_context_ref,
            "tool": "rtl_structural_analyzer",
            "rtl_path": rtl_path.as_posix(),
            "rtl_files": [p.as_posix() for p in rtl_files],
            "top_module": req.top_module,
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }
        input_manifest_path.write_text(json.dumps(input_manifest, indent=2), encoding="utf-8")

        lineage = {
            "run_id": run_id,
            "started_at": started_at.isoformat(),
            "finished_at": finished_at.isoformat(),
            "duration_ms": duration_ms,
            "working_dir": str(Path.cwd()),
            "input_manifest_ref": input_manifest_path.as_posix(),
            "output_refs": [
                raw_path.as_posix(),
                cdc_path.as_posix(),
                rdc_path.as_posix(),
                formal_path.as_posix(),
            ],
            "decision_context_ref": req.decision_context_ref,
            "task_id": req.task_id,
            "workspace_id": req.workspace_id,
            "chip_id": req.chip_id,
        }
        lineage_path.write_text(json.dumps(lineage, indent=2), encoding="utf-8")

        evidence_bundle = {
            "run_id": run_id,
            "raw_refs": [raw_path.as_posix()],
            "normalized_refs": [cdc_path.as_posix(), rdc_path.as_posix(), formal_path.as_posix()],
            "lineage_ref": lineage_path.as_posix(),
            "digests": {
                "raw_sha256": self._sha256_file(raw_path),
                "cdc_sha256": self._sha256_file(cdc_path),
                "rdc_sha256": self._sha256_file(rdc_path),
                "formal_sha256": self._sha256_file(formal_path),
                "input_manifest_sha256": self._sha256_file(input_manifest_path),
                "lineage_sha256": self._sha256_file(lineage_path),
            },
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }
        evidence_bundle_path.write_text(json.dumps(evidence_bundle, indent=2), encoding="utf-8")

        return CdcRdcAnalysisResponse(
            disposition=Disposition.PASS,
            reason="cdc_rdc_structural_analysis_completed",
            contract_id=f"{req.contract_name}@{req.contract_version}",
            request_schema_version=req.request_schema_version,
            boundary_mode=self.BOUNDARY_MODE,
            error_taxonomy=list(self.ERROR_TAXONOMY),
            run_id=run_id,
            execution_run_ref=f"run://{self.CAPABILITY_NAME}/{run_id}",
            artifact_paths={
                "raw_analysis": raw_path.as_posix(),
                "normalized_cdc": cdc_path.as_posix(),
                "normalized_rdc": rdc_path.as_posix(),
                "normalized_formal": formal_path.as_posix(),
                "input_manifest": input_manifest_path.as_posix(),
                "lineage": lineage_path.as_posix(),
                "evidence_bundle": evidence_bundle_path.as_posix(),
            },
            artifact_refs={
                "raw_ref": f"artifact://cdc_rdc/{run_id}/structural_analysis.raw.json",
                "cdc_ref": f"norm://cdc_rdc/{run_id}/normalized.cdc.meta.json",
                "rdc_ref": f"norm://cdc_rdc/{run_id}/normalized.rdc.meta.json",
                "formal_ref": f"norm://cdc_rdc/{run_id}/normalized.formal.meta.json",
                "lineage_ref": f"lineage://cdc_rdc/{run_id}/lineage.json",
                "evidence_bundle_ref": f"evidence_bundle://cdc_rdc/{run_id}",
            },
        )
