from __future__ import annotations

from datetime import datetime, timezone

from ic_agent_flow.domain.objects.v12_ecosystem_boundary_objects import (
    ExternalAssetPlacementRecord,
    SharedAssetPackRelease,
    V12_RECOMMENDED_ADOPTION_MODES,
    V12_RELEASE_CHANNELS,
)


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def build_shared_asset_pack_release(
    *,
    release_id: str,
    version: str,
    channel: str,
    placements: list[ExternalAssetPlacementRecord],
    release_notes: list[str],
    compatibility_scope: str,
    recommended_adoption_mode: str,
    breaking_change: bool,
) -> SharedAssetPackRelease:
    if channel not in V12_RELEASE_CHANNELS:
        raise ValueError("invalid_release_channel")
    if recommended_adoption_mode not in V12_RECOMMENDED_ADOPTION_MODES:
        raise ValueError("invalid_recommended_adoption_mode")
    if not placements:
        raise ValueError("placements_required")
    if not release_notes:
        raise ValueError("release_notes_required")
    if channel == "advisory_feed" and breaking_change:
        raise ValueError("advisory_channel_cannot_publish_breaking_change")

    for placement in placements:
        if placement.registry_scope == "canonical_shared":
            has_adjudication_ref = any(ref.startswith("adjudication://") for ref in placement.lineage_refs)
            if not has_adjudication_ref:
                raise ValueError("placement_lineage_incomplete")

    return SharedAssetPackRelease(
        release_id=release_id,
        version=version,
        channel=channel,
        asset_refs=[placement.asset_ref for placement in placements],
        placement_refs=[placement.placement_id for placement in placements],
        release_notes=release_notes,
        compatibility_scope=compatibility_scope,
        recommended_adoption_mode=recommended_adoption_mode,
        breaking_change=breaking_change,
        created_at=_now_iso(),
    )
