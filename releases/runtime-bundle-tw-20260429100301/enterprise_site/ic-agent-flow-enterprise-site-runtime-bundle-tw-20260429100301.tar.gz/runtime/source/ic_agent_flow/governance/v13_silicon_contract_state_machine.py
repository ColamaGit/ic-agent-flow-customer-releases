"""
PRD v1.3 — Phase 5: Contract State Machine & Fail-Closed Enforcement

Governing laws:
  - Law 6: Contract must fail-closed
  - PRD Section 11: State Machine
  - PRD Section 13: Suggested Implementation Sequence
"""

from __future__ import annotations

from typing import List, Tuple

from ic_agent_flow.domain.objects.v13_silicon_contract_objects import (
    BlockReason,
    ContractStatus,
    SiliconContract,
)
from ic_agent_flow.governance.v13_authority_binding import (
    can_enter_approved_for_release,
    check_authority_closure,
)
from ic_agent_flow.governance.v13_evidence_attachment import get_evidence_block_reasons


# ---------------------------------------------------------------------------
# Valid State Transitions
# ---------------------------------------------------------------------------

# (from_status, to_status) -> description
V13_VALID_TRANSITIONS = {
    (ContractStatus.DRAFT, ContractStatus.UNDER_REVIEW): "scope_resolved",
    (ContractStatus.UNDER_REVIEW, ContractStatus.EVIDENCE_INCOMPLETE): "evidence_missing",
    (ContractStatus.UNDER_REVIEW, ContractStatus.AUTHORITY_PENDING): "authority_not_closed",
    (ContractStatus.UNDER_REVIEW, ContractStatus.HOLD): "critical_risk_or_conflict",
    (ContractStatus.UNDER_REVIEW, ContractStatus.APPROVED_FOR_RELEASE): "all_conditions_met",
    (ContractStatus.UNDER_REVIEW, ContractStatus.REJECTED): "explicit_rejection",
    (ContractStatus.EVIDENCE_INCOMPLETE, ContractStatus.UNDER_REVIEW): "evidence_resubmitted",
    (ContractStatus.EVIDENCE_INCOMPLETE, ContractStatus.HOLD): "critical_risk_found",
    (ContractStatus.AUTHORITY_PENDING, ContractStatus.UNDER_REVIEW): "authority_updated",
    (ContractStatus.AUTHORITY_PENDING, ContractStatus.HOLD): "conflict_detected",
    (ContractStatus.HOLD, ContractStatus.UNDER_REVIEW): "hold_resolved",
    (ContractStatus.HOLD, ContractStatus.REJECTED): "explicit_rejection",
    (ContractStatus.APPROVED_FOR_RELEASE, ContractStatus.ARCHIVED): "post_delivery_archival",
    (ContractStatus.REJECTED, ContractStatus.ARCHIVED): "archived_after_rejection",
}

# Statuses that block any transition except to ARCHIVED or REJECTED
V13_TERMINAL_STATUSES = {ContractStatus.ARCHIVED}


# ---------------------------------------------------------------------------
# Fail-Closed Conditions Check
# ---------------------------------------------------------------------------

def check_fail_closed_conditions(contract: SiliconContract) -> List[BlockReason]:
    """
    Evaluate all fail-closed conditions for the contract.
    Returns a list of BlockReasons that are currently blocking release progress.
    An empty list means no fail-closed conditions are triggered.
    """
    reasons: List[BlockReason] = []

    # 1. Chip identity
    if not contract.chip_id or not contract.chip_id.strip():
        reasons.append(BlockReason.CHIP_IDENTITY_MISSING)

    # 2. Evidence checks
    evidence_blocks = get_evidence_block_reasons(contract)
    reasons.extend(evidence_blocks)

    # 3. Authority closure
    closure = check_authority_closure(contract)
    if not closure.all_mandatory_closed:
        reasons.append(BlockReason.AUTHORITY_CLOSURE_INCOMPLETE)
    if closure.conflict_detected:
        reasons.append(BlockReason.CONFLICT_UNRESOLVED)

    # 4. Delivery classification
    if not contract.delivery_classification:
        reasons.append(BlockReason.DELIVERY_CLASS_UNDEFINED)

    # 5. Open risks
    if contract.open_risk_refs:
        reasons.append(BlockReason.CRITICAL_RISK_UNRESOLVED)

    return list(dict.fromkeys(reasons))  # deduplicate while preserving order


# ---------------------------------------------------------------------------
# State Transition
# ---------------------------------------------------------------------------

def transition_contract_state(
    contract: SiliconContract,
    to_status: ContractStatus,
    actor_role: str = "SYSTEM",
) -> Tuple[bool, List[str], SiliconContract]:
    """
    Attempt to transition contract to to_status.
    Returns (success, list_of_rejection_reasons, updated_contract).

    Key rule: transitioning to APPROVED_FOR_RELEASE requires ALL conditions met.
    All other transitions to non-terminal statuses follow the valid-transition table.
    """
    from datetime import datetime, timezone

    issues: List[str] = []
    current = contract.contract_status

    # Terminal status guard
    if current in V13_TERMINAL_STATUSES:
        return False, [f"Contract is in terminal status '{current}' — no further transitions allowed."], contract

    # Validate transition is known
    transition_key = (current, to_status)
    if transition_key not in V13_VALID_TRANSITIONS:
        return False, [
            f"Invalid transition: '{current}' → '{to_status}'. "
            f"Valid from '{current}': {[t[1].value for t in V13_VALID_TRANSITIONS if t[0] == current]}"
        ], contract

    # Special guard for APPROVED_FOR_RELEASE
    if to_status == ContractStatus.APPROVED_FOR_RELEASE:
        can_approve, blockers = can_enter_approved_for_release(contract)
        if not can_approve:
            return False, [f"Blocked from APPROVED_FOR_RELEASE: {[b.value for b in blockers]}"], contract

    # Apply transition
    updated = _apply_status(contract, to_status)
    return True, [], updated


def _apply_status(contract: SiliconContract, new_status: ContractStatus) -> SiliconContract:
    """Return a copy of the contract with updated status and timestamp."""
    from datetime import datetime, timezone
    from dataclasses import replace

    return replace(
        contract,
        contract_status=new_status,
        updated_at=datetime.now(timezone.utc),
    )


# ---------------------------------------------------------------------------
# Can Approve For Release (public helper)
# ---------------------------------------------------------------------------

def can_approve_for_release(contract: SiliconContract) -> Tuple[bool, List[BlockReason]]:
    """
    Public helper: checks whether contract meets all requirements for APPROVED_FOR_RELEASE.
    Returns (can_approve, blocking_reasons).
    """
    return can_enter_approved_for_release(contract)


# ---------------------------------------------------------------------------
# State Diagnostic
# ---------------------------------------------------------------------------

def diagnose_contract_state(contract: SiliconContract) -> dict:
    """
    Return a structured diagnostic of the contract's current governance state.
    Useful for dashboard surface / human review.
    """
    blocks = check_fail_closed_conditions(contract)
    closure = check_authority_closure(contract)
    can_release, release_blockers = can_enter_approved_for_release(contract)

    return {
        "contract_id": contract.contract_id,
        "current_status": contract.contract_status.value,
        "chip_id": contract.chip_id,
        "delivery_classification": contract.delivery_classification.value if contract.delivery_classification else None,
        "fail_closed_blocks": [b.value for b in blocks],
        "authority_closure": {
            "all_mandatory_closed": closure.all_mandatory_closed,
            "pending_roles": [r.value for r in closure.pending_roles],
            "conflict_detected": closure.conflict_detected,
        },
        "can_approve_for_release": can_release,
        "release_blockers": [b.value for b in release_blockers],
        "evidence_count": len(contract.signoff_evidence_refs),
        "open_risk_count": len(contract.open_risk_refs),
    }
