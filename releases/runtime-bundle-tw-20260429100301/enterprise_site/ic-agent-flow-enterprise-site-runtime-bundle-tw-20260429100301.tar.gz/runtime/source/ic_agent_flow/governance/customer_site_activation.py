from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from ic_agent_flow.domain.objects.v15_customer_site_activation_objects import (
    ActivationDecisionRecord,
    SiteActivationRequest,
)
from ic_agent_flow.governance.customer_package_verifier import CustomerPackageVerificationResult


class SiteActivationState(str, Enum):
    PACKAGE_RECEIVED = "PACKAGE_RECEIVED"
    PACKAGE_VERIFIED = "PACKAGE_VERIFIED"
    PROFILE_BOUND = "PROFILE_BOUND"
    POLICY_BOUND = "POLICY_BOUND"
    PREFLIGHT_RUNNING = "PREFLIGHT_RUNNING"
    PREFLIGHT_PASSED = "PREFLIGHT_PASSED"
    PREFLIGHT_BLOCKED = "PREFLIGHT_BLOCKED"
    SMOKE_RUNNING = "SMOKE_RUNNING"
    READY_FOR_ACTIVATION_REVIEW = "READY_FOR_ACTIVATION_REVIEW"
    ACTIVE = "ACTIVE"
    HOLD = "HOLD"
    REJECTED = "REJECTED"
    ROLLBACK_REQUIRED = "ROLLBACK_REQUIRED"
    ARCHIVED = "ARCHIVED"


class SiteActivationFailClosedReason(str, Enum):
    SIGNATURE_INVALID = "signature_invalid"
    DIGEST_MISMATCH = "digest_mismatch"
    SBOM_MISSING = "sbom_missing"
    TRUST_ROOT_UNRESOLVED = "trust_root_unresolved"
    DEPLOYMENT_PROFILE_INVALID = "deployment_profile_invalid"
    FORBIDDEN_CAPABILITY_ENABLED = "forbidden_capability_enabled"
    SITE_POLICY_UNRESOLVED = "site_policy_unresolved"
    REQUIRED_ROLE_MISSING = "required_role_missing"
    PREFLIGHT_FAILED = "preflight_failed"
    SMOKE_SCENARIO_FAILED = "smoke_scenario_failed"
    SUPPORT_BOUNDARY_UNDEFINED = "support_boundary_undefined"
    ACTIVATION_AUTHORITY_MISSING = "activation_authority_missing"


@dataclass(frozen=True)
class SiteActivationRunResult:
    current_state: SiteActivationState
    state_history: list[SiteActivationState]
    fail_closed_reasons: list[SiteActivationFailClosedReason]


class SiteActivationTransitionValidator:
    _valid_transitions = {
        (SiteActivationState.PACKAGE_RECEIVED, SiteActivationState.PACKAGE_VERIFIED),
        (SiteActivationState.PACKAGE_VERIFIED, SiteActivationState.PROFILE_BOUND),
        (SiteActivationState.PROFILE_BOUND, SiteActivationState.POLICY_BOUND),
        (SiteActivationState.POLICY_BOUND, SiteActivationState.PREFLIGHT_RUNNING),
        (SiteActivationState.PREFLIGHT_RUNNING, SiteActivationState.PREFLIGHT_PASSED),
        (SiteActivationState.PREFLIGHT_RUNNING, SiteActivationState.PREFLIGHT_BLOCKED),
        (SiteActivationState.PREFLIGHT_PASSED, SiteActivationState.SMOKE_RUNNING),
        (SiteActivationState.SMOKE_RUNNING, SiteActivationState.READY_FOR_ACTIVATION_REVIEW),
        (SiteActivationState.READY_FOR_ACTIVATION_REVIEW, SiteActivationState.ACTIVE),
        (SiteActivationState.READY_FOR_ACTIVATION_REVIEW, SiteActivationState.HOLD),
        (SiteActivationState.READY_FOR_ACTIVATION_REVIEW, SiteActivationState.REJECTED),
        (SiteActivationState.READY_FOR_ACTIVATION_REVIEW, SiteActivationState.ROLLBACK_REQUIRED),
        (SiteActivationState.READY_FOR_ACTIVATION_REVIEW, SiteActivationState.PREFLIGHT_RUNNING),
        (SiteActivationState.ACTIVE, SiteActivationState.ARCHIVED),
        (SiteActivationState.HOLD, SiteActivationState.ARCHIVED),
        (SiteActivationState.REJECTED, SiteActivationState.ARCHIVED),
        (SiteActivationState.ROLLBACK_REQUIRED, SiteActivationState.ARCHIVED),
    }

    @classmethod
    def validate_transition(
        cls,
        from_state: SiteActivationState,
        to_state: SiteActivationState,
    ) -> None:
        if (from_state, to_state) not in cls._valid_transitions:
            raise ValueError(f"invalid_activation_transition:{from_state.value}->{to_state.value}")


class SiteActivationEngine:
    _verification_reason_map = {
        "trust_root_unresolved": SiteActivationFailClosedReason.TRUST_ROOT_UNRESOLVED,
        "forbidden_capability_enabled": SiteActivationFailClosedReason.FORBIDDEN_CAPABILITY_ENABLED,
        "base_profile_ref_mismatch": SiteActivationFailClosedReason.SITE_POLICY_UNRESOLVED,
        "bundle profile_ref does not match selected profile": SiteActivationFailClosedReason.DEPLOYMENT_PROFILE_INVALID,
        "bundle digest missing": SiteActivationFailClosedReason.DIGEST_MISMATCH,
        "signature trust root missing": SiteActivationFailClosedReason.TRUST_ROOT_UNRESOLVED,
    }

    def run_to_review_with_verification(
        self,
        *,
        request: SiteActivationRequest,
        verification: CustomerPackageVerificationResult,
        required_roles_present: bool,
        preflight_passed: bool,
        smoke_passed: bool,
        support_boundary_defined: bool,
    ) -> SiteActivationRunResult:
        if not verification.allowed:
            first_reason = verification.blocking_reasons[0] if verification.blocking_reasons else "deployment_profile_invalid"
            mapped = self._verification_reason_map.get(
                first_reason,
                SiteActivationFailClosedReason.DEPLOYMENT_PROFILE_INVALID,
            )
            return SiteActivationRunResult(
                current_state=SiteActivationState.PACKAGE_RECEIVED,
                state_history=[SiteActivationState.PACKAGE_RECEIVED],
                fail_closed_reasons=[mapped],
            )

        return self.run_to_review(
            request=request,
            signature_valid=True,
            digest_valid=True,
            sbom_present=True,
            trust_root_resolved=True,
            deployment_profile_valid=verification.profile_binding.binding_status == "BOUND",
            forbidden_capabilities=verification.profile_binding.forbidden_capabilities
            if any(result.blocking_reasons for result in verification.gate_results if result.gate_name == "profile_compliance")
            else [],
            site_policy_resolved=verification.policy_binding.binding_status == "BOUND",
            required_roles_present=required_roles_present,
            preflight_passed=preflight_passed,
            smoke_passed=smoke_passed,
            support_boundary_defined=support_boundary_defined,
        )

    def run_to_review(
        self,
        *,
        request: SiteActivationRequest,
        signature_valid: bool,
        digest_valid: bool,
        sbom_present: bool,
        trust_root_resolved: bool,
        deployment_profile_valid: bool,
        forbidden_capabilities: list[str],
        site_policy_resolved: bool,
        required_roles_present: bool,
        preflight_passed: bool,
        smoke_passed: bool,
        support_boundary_defined: bool,
    ) -> SiteActivationRunResult:
        state = SiteActivationState.PACKAGE_RECEIVED
        history = [state]

        if not signature_valid:
            return self._result(state, history, SiteActivationFailClosedReason.SIGNATURE_INVALID)
        if not digest_valid:
            return self._result(state, history, SiteActivationFailClosedReason.DIGEST_MISMATCH)
        if not sbom_present:
            return self._result(state, history, SiteActivationFailClosedReason.SBOM_MISSING)
        if not trust_root_resolved:
            return self._result(state, history, SiteActivationFailClosedReason.TRUST_ROOT_UNRESOLVED)

        state = self._advance(history, state, SiteActivationState.PACKAGE_VERIFIED)

        if not request.profile_ref or not deployment_profile_valid:
            return self._result(state, history, SiteActivationFailClosedReason.DEPLOYMENT_PROFILE_INVALID)
        state = self._advance(history, state, SiteActivationState.PROFILE_BOUND)

        if forbidden_capabilities:
            return self._result(state, history, SiteActivationFailClosedReason.FORBIDDEN_CAPABILITY_ENABLED)
        if not site_policy_resolved:
            return self._result(state, history, SiteActivationFailClosedReason.SITE_POLICY_UNRESOLVED)

        state = self._advance(history, state, SiteActivationState.POLICY_BOUND)
        if not request.customer_authority_ref or not required_roles_present:
            return self._result(state, history, SiteActivationFailClosedReason.REQUIRED_ROLE_MISSING)
        state = self._advance(history, state, SiteActivationState.PREFLIGHT_RUNNING)

        if not preflight_passed:
            blocked = self._advance(history, state, SiteActivationState.PREFLIGHT_BLOCKED)
            return self._result(blocked, history, SiteActivationFailClosedReason.PREFLIGHT_FAILED)

        state = self._advance(history, state, SiteActivationState.PREFLIGHT_PASSED)

        if not support_boundary_defined:
            return self._result(state, history, SiteActivationFailClosedReason.SUPPORT_BOUNDARY_UNDEFINED)

        state = self._advance(history, state, SiteActivationState.SMOKE_RUNNING)
        if not smoke_passed:
            return self._result(state, history, SiteActivationFailClosedReason.SMOKE_SCENARIO_FAILED)

        state = self._advance(history, state, SiteActivationState.READY_FOR_ACTIVATION_REVIEW)
        return SiteActivationRunResult(
            current_state=state,
            state_history=history,
            fail_closed_reasons=[],
        )

    def finalize_activation(
        self,
        review_ready: SiteActivationRunResult,
        *,
        decision_record: ActivationDecisionRecord | None,
    ) -> SiteActivationRunResult:
        if review_ready.current_state != SiteActivationState.READY_FOR_ACTIVATION_REVIEW:
            raise ValueError("activation_not_ready_for_review")

        history = list(review_ready.state_history)
        state = review_ready.current_state

        if decision_record is None or not decision_record.actor:
            return SiteActivationRunResult(
                current_state=state,
                state_history=history,
                fail_closed_reasons=[SiteActivationFailClosedReason.ACTIVATION_AUTHORITY_MISSING],
            )

        next_state = {
            "APPROVE_ACTIVATION": SiteActivationState.ACTIVE,
            "APPROVE_WITH_CONDITIONS": SiteActivationState.ACTIVE,
            "HOLD_ACTIVATION": SiteActivationState.HOLD,
            "REJECT_ACTIVATION": SiteActivationState.REJECTED,
            "REQUEST_MORE_EVIDENCE": SiteActivationState.PREFLIGHT_RUNNING,  # fallback for re-entry
            "ROLLBACK_REQUIRED": SiteActivationState.ROLLBACK_REQUIRED,
            "ESCALATE_TO_SECURITY": SiteActivationState.HOLD,
        }[decision_record.decision]
        self._advance(history, state, next_state)
        return SiteActivationRunResult(
            current_state=next_state,
            state_history=history,
            fail_closed_reasons=[],
        )

    def _advance(
        self,
        history: list[SiteActivationState],
        current_state: SiteActivationState,
        next_state: SiteActivationState,
    ) -> SiteActivationState:
        SiteActivationTransitionValidator.validate_transition(current_state, next_state)
        history.append(next_state)
        return next_state

    @staticmethod
    def _result(
        state: SiteActivationState,
        history: list[SiteActivationState],
        reason: SiteActivationFailClosedReason,
    ) -> SiteActivationRunResult:
        return SiteActivationRunResult(
            current_state=state,
            state_history=history,
            fail_closed_reasons=[reason],
        )
