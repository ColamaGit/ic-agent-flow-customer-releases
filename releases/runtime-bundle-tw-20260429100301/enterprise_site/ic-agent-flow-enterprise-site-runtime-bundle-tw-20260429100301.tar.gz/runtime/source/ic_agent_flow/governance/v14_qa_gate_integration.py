"""
PRD v1.4 — Phase 4: QA Gate Integration

Governing laws:
  - Law 7: Fail-Closed on Trust Violation
  - PRD Section 9: Phase 4 — QA Gate
"""

from __future__ import annotations

from typing import List, Tuple

from ic_agent_flow.domain.objects.v13_silicon_contract_objects import (
    BlockReason,
    ContractStatus,
    SiliconContract,
)
from ic_agent_flow.domain.objects.v14_qa_trust_layer_objects import QAAdjudicationRecord
from ic_agent_flow.governance.v13_silicon_contract_state_machine import can_approve_for_release


def evaluate_qa_gate_for_contract(
    contract: SiliconContract,
    qa_records: List[QAAdjudicationRecord],
) -> List[BlockReason]:
    """
    Evaluate QA trust records against the contract.
    Returns a list of BlockReasons (specifically QA_TRUST_VIOLATION) if QA fails.
    """
    reasons: List[BlockReason] = []

    # If the contract requires QA but no records exist, we might fail-close.
    # However, since we rely on `qa_adjudication_refs` in the contract, let's verify
    # if the contract *claims* to have been QA'd. If there are refs but no records passed,
    # that's a problem. But if records are passed, we check their verdicts.

    if not qa_records:
        # If the integration requires a QA record and none is provided, it's a violation.
        reasons.append(BlockReason.QA_TRUST_VIOLATION)
        return reasons

    # Sort records to find the most recent one (assuming they have `created_at` or we trust the list order)
    # The caller is responsible for passing the relevant records for this contract/chip_id.
    
    latest_record = qa_records[-1]

    if latest_record.recommendation != "PROCEED":
        # Any non-PROCEED recommendation is a hard block under Law 7.
        reasons.append(BlockReason.QA_TRUST_VIOLATION)

    return reasons


def can_approve_for_release_with_qa(
    contract: SiliconContract,
    qa_records: List[QAAdjudicationRecord],
) -> Tuple[bool, List[BlockReason]]:
    """
    Wrapper around v1.3 `can_approve_for_release` that also enforces the v1.4 QA Gate.
    """
    # 1. Run base v1.3 checks
    base_can_approve, base_blockers = can_approve_for_release(contract)

    # 2. Run v1.4 QA checks
    qa_blockers = evaluate_qa_gate_for_contract(contract, qa_records)

    all_blockers = base_blockers + qa_blockers
    
    # Deduplicate while preserving order
    all_blockers = list(dict.fromkeys(all_blockers))

    return (len(all_blockers) == 0, all_blockers)
