from __future__ import annotations

from enum import Enum
from pathlib import Path
from typing import List

from pydantic import BaseModel, Field

from ic_agent_flow.governance.v10_freeze_to_plan import assess_freeze_to_plan
from ic_agent_flow.governance.v10_graph_validation import assess_graph_validation_chain
from ic_agent_flow.governance.v10_spec_completion import assess_spec_completion_chain


class DownstreamAdmissionStatus(str, Enum):
    ALLOWED = "ALLOWED"
    BLOCKED = "BLOCKED"


class DownstreamAdmission(BaseModel):
    status: DownstreamAdmissionStatus
    h1_plus_allowed: bool
    blocking_reasons: List[str] = Field(default_factory=list)


def derive_downstream_admission(chip_dir: Path | str) -> DownstreamAdmission:
    chip_dir = Path(chip_dir)
    spec = assess_spec_completion_chain(chip_dir / "specs")
    graph = assess_graph_validation_chain(chip_dir / "architecture")
    freeze_to_plan = assess_freeze_to_plan(chip_dir / "architecture")

    blocking_reasons: List[str] = []
    if not spec.chain_complete:
        blocking_reasons.append("spec_completion_chain_incomplete")
    if graph.freeze_blocked or not graph.validation_chain_complete:
        blocking_reasons.append("graph_validation_not_ready")
    if not freeze_to_plan.plan_ready:
        blocking_reasons.append("freeze_to_plan_not_ready")

    h1_plus_allowed = not blocking_reasons
    return DownstreamAdmission(
        status=DownstreamAdmissionStatus.ALLOWED if h1_plus_allowed else DownstreamAdmissionStatus.BLOCKED,
        h1_plus_allowed=h1_plus_allowed,
        blocking_reasons=blocking_reasons,
    )
