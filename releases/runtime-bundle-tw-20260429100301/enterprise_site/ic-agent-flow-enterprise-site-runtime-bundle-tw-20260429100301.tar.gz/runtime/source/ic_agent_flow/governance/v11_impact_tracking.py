from __future__ import annotations

import json
from pathlib import Path

from ic_agent_flow.domain.objects.v11_knowledge_flywheel_objects import (
    AssetConsumptionRecord,
    AssetImpactRecord,
    AssetPromotionRecord,
    SharedAssetRegistryRecord,
)


def build_asset_impact_records(
    *,
    consumptions: list[AssetConsumptionRecord],
    outcome_signals: dict[str, dict],
    measured_window: str,
    measured_at: str,
) -> list[AssetImpactRecord]:
    consumption_counts: dict[str, int] = {}
    for consumption in consumptions:
        consumption_counts[consumption.asset_ref] = consumption_counts.get(consumption.asset_ref, 0) + 1

    records: list[AssetImpactRecord] = []
    for asset_ref, count in consumption_counts.items():
        signal = outcome_signals.get(asset_ref, {})
        delta_metrics = {"consumption_count": count}
        delta_metrics.update(signal)
        records.append(
            AssetImpactRecord(
                record_id=f"impact://{asset_ref}",
                asset_ref=asset_ref,
                measured_window=measured_window,
                impact_summary=f"consumed {count} times in {measured_window}",
                delta_metrics=delta_metrics,
                evidence_refs=[],
                measured_at=measured_at,
            )
        )
    records.sort(key=lambda x: (-x.delta_metrics.get("consumption_count", 0), x.asset_ref))
    return records


def build_flywheel_health_report(
    *,
    promotions: list[AssetPromotionRecord],
    registry_records: list[SharedAssetRegistryRecord],
    consumptions: list[AssetConsumptionRecord],
    stale_asset_refs: list[str],
    generated_at: str,
) -> dict:
    promotions_total = len(promotions)
    shared_promotion_count = sum(
        1
        for p in promotions
        if p.decision in {"share_team_scope", "share_org_scope", "promote_canonical", "promote_with_conditions"}
    )
    admission_rate = shared_promotion_count / promotions_total if promotions_total else 0.0

    active_registry_records = [r for r in registry_records if r.status == "ACTIVE"]
    active_asset_refs = {r.asset_ref for r in active_registry_records}
    consumed_asset_refs = {c.asset_ref for c in consumptions}
    consumed_active_refs = active_asset_refs & consumed_asset_refs
    consumption_reuse = len(consumed_active_refs) / len(active_asset_refs) if active_asset_refs else 0.0

    superseded_count = sum(1 for r in registry_records if r.status == "SUPERSEDED")
    supersede_ratio = superseded_count / len(registry_records) if registry_records else 0.0

    stale_count = len(set(stale_asset_refs) & active_asset_refs)
    stale_asset_ratio = stale_count / len(active_asset_refs) if active_asset_refs else 0.0

    return {
        "schema_version": "v11-flywheel-health-report.v0.1",
        "generated_at": generated_at,
        "metrics": {
            "admission_rate": admission_rate,
            "consumption_reuse": consumption_reuse,
            "supersede_ratio": supersede_ratio,
            "stale_asset_ratio": stale_asset_ratio,
        },
        "counts": {
            "promotions_total": promotions_total,
            "shared_promotions": shared_promotion_count,
            "registry_total": len(registry_records),
            "active_registry_total": len(active_registry_records),
            "consumptions_total": len(consumptions),
            "stale_asset_total": stale_count,
        },
    }


def write_flywheel_health_report(*, report: dict, output_dir: str | Path) -> tuple[Path, Path]:
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    json_path = out / "v11_flywheel_health_report.v0.1.json"
    md_path = out / "v11_flywheel_health_report.v0.1.md"
    json_path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    lines = [
        "# Flywheel Health Report",
        "",
        f"- generated_at: `{report.get('generated_at', '')}`",
        "",
        "## Metrics",
        "",
        "| metric | value |",
        "|---|---:|",
    ]
    for key, value in report.get("metrics", {}).items():
        lines.append(f"| {key} | {value} |")
    lines.extend(["", "## Counts", "", "| key | value |", "|---|---:|"])
    for key, value in report.get("counts", {}).items():
        lines.append(f"| {key} | {value} |")
    md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return json_path, md_path

