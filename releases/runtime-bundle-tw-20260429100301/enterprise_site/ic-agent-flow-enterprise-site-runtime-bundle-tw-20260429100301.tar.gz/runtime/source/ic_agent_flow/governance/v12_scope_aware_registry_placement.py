from __future__ import annotations

from datetime import datetime, timezone
from uuid import uuid4

from ic_agent_flow.domain.objects.v12_ecosystem_boundary_objects import (
    ExternalAssetAdjudicationRecord,
    ExternalAssetPlacementAuditRecord,
    ExternalAssetPlacementRecord,
    ExternalAssetSubmissionRecord,
)


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


_DECISION_TO_TARGET = {
    "reject": "none",
    "accept_local_reference_only": "local_reference_registry",
    "accept_partner_scope": "partner_scope_registry",
    "accept_shared_noncanonical": "shared_noncanonical_registry",
    "promote_canonical": "canonical_shared_registry",
    "promote_canonical_with_conditions": "canonical_shared_registry",
}

_TARGET_TO_SCOPE = {
    "local_reference_registry": "local_reference",
    "partner_scope_registry": "partner_scope",
    "shared_noncanonical_registry": "shared_noncanonical",
    "canonical_shared_registry": "canonical_shared",
}


class ScopeAwareExternalRegistryPlacementService:
    def __init__(self) -> None:
        self._records: list[ExternalAssetPlacementRecord] = []
        self._audits: list[ExternalAssetPlacementAuditRecord] = []

    def _write_audit(
        self,
        *,
        submission_ref: str,
        adjudication_ref: str,
        requested_target: str,
        outcome: str,
        reasons: list[str],
    ) -> None:
        self._audits.append(
            ExternalAssetPlacementAuditRecord(
                audit_id=f"placement-audit://{uuid4()}",
                submission_ref=submission_ref,
                adjudication_ref=adjudication_ref,
                requested_target=requested_target,
                outcome=outcome,
                reasons=reasons,
                created_at=_now_iso(),
            )
        )

    def place(
        self,
        *,
        submission: ExternalAssetSubmissionRecord,
        adjudication: ExternalAssetAdjudicationRecord,
    ) -> ExternalAssetPlacementRecord | None:
        expected_target = _DECISION_TO_TARGET.get(adjudication.final_decision)
        if expected_target is None or expected_target != adjudication.registry_target:
            raise ValueError("decision_target_mismatch")

        if adjudication.registry_target == "none":
            self._write_audit(
                submission_ref=submission.submission_id,
                adjudication_ref=adjudication.adjudication_id,
                requested_target=adjudication.registry_target,
                outcome="SKIPPED_REJECTED",
                reasons=adjudication.rejection_reasons or ["rejected_by_court"],
            )
            return None

        scope = _TARGET_TO_SCOPE.get(adjudication.registry_target)
        if scope is None:
            raise ValueError("unknown_registry_target")

        if scope == "canonical_shared" and adjudication.final_decision not in {
            "promote_canonical",
            "promote_canonical_with_conditions",
        }:
            raise ValueError("decision_target_mismatch")
        if scope != "canonical_shared" and adjudication.final_decision in {
            "promote_canonical",
            "promote_canonical_with_conditions",
        }:
            raise ValueError("decision_target_mismatch")

        record = ExternalAssetPlacementRecord(
            placement_id=f"placement://{uuid4()}",
            asset_ref=submission.asset_ref,
            submission_ref=submission.submission_id,
            adjudication_ref=adjudication.adjudication_id,
            registry_scope=scope,
            status="PLACED",
            lineage_refs=[
                submission.submission_id,
                adjudication.adjudication_id,
                adjudication.confidentiality_review_ref,
            ],
            placed_at=_now_iso(),
        )
        self._records.append(record)
        self._write_audit(
            submission_ref=submission.submission_id,
            adjudication_ref=adjudication.adjudication_id,
            requested_target=adjudication.registry_target,
            outcome="PLACED",
            reasons=[],
        )
        return record

    def list_by_scope(self, scope: str) -> list[ExternalAssetPlacementRecord]:
        return [record for record in self._records if record.registry_scope == scope]

    def list_placement_audits(self) -> list[ExternalAssetPlacementAuditRecord]:
        return list(self._audits)
