from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any


class ProductIPClass(str, Enum):
    PUBLIC_CONTRACT = "PUBLIC_CONTRACT"
    CUSTOMER_RUNTIME = "CUSTOMER_RUNTIME"
    CUSTOMER_CONFIGURABLE = "CUSTOMER_CONFIGURABLE"
    CUSTOMER_REVIEWABLE = "CUSTOMER_REVIEWABLE"
    SUPPORT_ONLY = "SUPPORT_ONLY"
    INTERNAL_ONLY = "INTERNAL_ONLY"
    PROPRIETARY_SECRET = "PROPRIETARY_SECRET"
    SOURCE_ESCROW_ONLY = "SOURCE_ESCROW_ONLY"
    PARTNER_SDK_ALLOWED = "PARTNER_SDK_ALLOWED"


@dataclass(frozen=True)
class ProductIPClassificationRecord:
    classification_id: str
    asset_ref: str
    asset_path: str
    asset_type: str
    classification: ProductIPClass
    classification_reason: str
    allowed_distribution_modes: list[Any]
    prohibited_distribution_modes: list[Any]
    redaction_required: bool
    source_disclosure_allowed: bool
    reviewer: str
    created_at: str
    digest: str
    signature: str

    def __post_init__(self) -> None:
        if not self.reviewer:
            raise ValueError("reviewer_required")
        if not self.digest:
            raise ValueError("digest_required")
        if not self.signature:
            raise ValueError("signature_required")


@dataclass(frozen=True)
class DistributionEligibilityResult:
    allowed: bool
    blocking_reasons: list[str]
    checked_assets: list[str]


class ProductIPClassifier:
    def index_by_path(
        self,
        classification_records: list[ProductIPClassificationRecord],
    ) -> dict[str, ProductIPClassificationRecord]:
        return {record.asset_path: record for record in classification_records}


class DistributionEligibilityChecker:
    def check_assets(
        self,
        *,
        asset_paths: list[str],
        classification_records: list[ProductIPClassificationRecord],
        policy: Any,
    ) -> DistributionEligibilityResult:
        indexed = ProductIPClassifier().index_by_path(classification_records)
        blocking_reasons: list[str] = []

        for asset_path in asset_paths:
            record = indexed.get(asset_path)
            if record is None:
                blocking_reasons.append(f"unclassified_asset:{asset_path}")
                continue

            if record.classification not in policy.allowed_ip_classes:
                blocking_reasons.append(
                    f"classification_not_allowed:{asset_path}:{record.classification.value}"
                )
                continue

            if getattr(policy, "mode", None) in record.prohibited_distribution_modes:
                blocking_reasons.append(
                    f"mode_explicitly_prohibited:{asset_path}:{getattr(policy.mode, 'value', policy.mode)}"
                )

        return DistributionEligibilityResult(
            allowed=not blocking_reasons,
            blocking_reasons=blocking_reasons,
            checked_assets=list(asset_paths),
        )
