from __future__ import annotations

import json
from pathlib import Path
from typing import List, Optional

from pydantic import BaseModel, Field


REQUIRED_FREEZE_PRECONDITIONS = (
    "scope_resolved",
    "schema_valid",
    "required_validators_executed",
    "blocking_issue_closed_or_adjudicated",
    "required_review_package_present",
    "lineage_supersedes_complete",
)

REQUIRED_GENERATION_PLAN_FIELDS = (
    "generation_order",
    "module_dependency_constraints",
    "interface_freeze_assumptions",
    "verification_handoff_obligations",
    "fail_closed_stop_conditions",
)


class FreezeToPlanAssessment(BaseModel):
    freeze_eligible: bool
    plan_ready: bool
    freeze_state: Optional[str] = None
    missing_freeze_preconditions: List[str] = Field(default_factory=list)
    missing_plan_fields: List[str] = Field(default_factory=list)


def _load_json(path: Path) -> dict:
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def _missing_freeze_preconditions(freeze_record: dict) -> List[str]:
    eligibility = freeze_record.get("freeze_eligibility") or {}
    return [
        key
        for key in REQUIRED_FREEZE_PRECONDITIONS
        if eligibility.get(key) is not True
    ]


def _missing_plan_fields(plan: dict) -> List[str]:
    missing = [
        key
        for key in REQUIRED_GENERATION_PLAN_FIELDS
        if not plan.get(key)
    ]
    if plan.get("machine_consumable") is not True:
        missing.append("machine_consumable")
    return missing


def assess_freeze_to_plan(architecture_dir: Path | str) -> FreezeToPlanAssessment:
    architecture_dir = Path(architecture_dir)
    freeze_record = _load_json(architecture_dir / "graph_freeze_record.json")
    generation_plan = _load_json(architecture_dir / "graph_to_generation_plan.json")

    missing_freeze = _missing_freeze_preconditions(freeze_record)
    missing_plan = _missing_plan_fields(generation_plan)
    freeze_eligible = bool(freeze_record) and not missing_freeze
    plan_ready = freeze_eligible and bool(generation_plan) and not missing_plan

    return FreezeToPlanAssessment(
        freeze_eligible=freeze_eligible,
        plan_ready=plan_ready,
        freeze_state=freeze_record.get("freeze_state"),
        missing_freeze_preconditions=missing_freeze,
        missing_plan_fields=missing_plan,
    )
