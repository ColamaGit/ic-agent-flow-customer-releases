from __future__ import annotations

from datetime import datetime, timezone
from uuid import uuid4

from ic_agent_flow.domain.objects.v12_ecosystem_boundary_objects import (
    ExternalAssetAdjudicationRecord,
    ExternalAssetSubmissionRecord,
    ExternalConfidentialityReviewRecord,
    V12_ADJUDICATION_DECISION_VOCAB,
    V12_ADJUDICATION_REVIEW_ROLES,
)


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _registry_target_for_decision(decision: str) -> str:
    if decision == "reject":
        return "none"
    if decision == "accept_local_reference_only":
        return "local_reference_registry"
    if decision == "accept_partner_scope":
        return "partner_scope_registry"
    if decision == "accept_shared_noncanonical":
        return "shared_noncanonical_registry"
    if decision in {"promote_canonical", "promote_canonical_with_conditions"}:
        return "canonical_shared_registry"
    raise ValueError("invalid_decision_vocab")


def _validate_roles(reviewer_votes: list[dict]) -> list[str]:
    roles = {vote.get("role", "").strip() for vote in reviewer_votes}
    required = set(V12_ADJUDICATION_REVIEW_ROLES)
    if not required.issubset(roles):
        raise ValueError("three_role_review_required")
    return sorted(roles)


def adjudicate_external_submission(
    *,
    submission: ExternalAssetSubmissionRecord,
    confidentiality_review: ExternalConfidentialityReviewRecord,
    reviewer_votes: list[dict],
    requested_decision: str,
    reusable_pattern: bool,
    duplication_conflict_unresolved: bool,
    conditions: list[str] | None = None,
) -> ExternalAssetAdjudicationRecord:
    if requested_decision not in V12_ADJUDICATION_DECISION_VOCAB:
        raise ValueError("invalid_decision_vocab")
    reviewer_roles = _validate_roles(reviewer_votes)
    if requested_decision == "promote_canonical_with_conditions" and not (conditions or []):
        raise ValueError("conditions_required")

    rejection_reasons: list[str] = []
    final_decision = requested_decision

    if confidentiality_review.status == "REJECTED":
        final_decision = "reject"
        rejection_reasons.append("confidentiality_gate_not_passed")
    if not reusable_pattern and requested_decision in {
        "accept_partner_scope",
        "accept_shared_noncanonical",
        "promote_canonical",
        "promote_canonical_with_conditions",
    }:
        final_decision = "reject"
        rejection_reasons.append("reusable_pattern_not_established")
    if duplication_conflict_unresolved and requested_decision in {
        "accept_partner_scope",
        "accept_shared_noncanonical",
        "promote_canonical",
        "promote_canonical_with_conditions",
    }:
        final_decision = "reject"
        rejection_reasons.append("duplication_conflict_unresolved")
    if (
        confidentiality_review.status == "DOWNGRADED_TO_CUSTOMER_APPROVED_SANITIZED_CANDIDATE"
        and requested_decision in {"promote_canonical", "promote_canonical_with_conditions"}
    ):
        final_decision = "reject"
        rejection_reasons.append("scope_downgrade_blocks_canonical_promotion")

    return ExternalAssetAdjudicationRecord(
        adjudication_id=f"adjudication://{uuid4()}",
        submission_ref=submission.submission_id,
        confidentiality_review_ref=confidentiality_review.review_id,
        final_decision=final_decision,
        registry_target=_registry_target_for_decision(final_decision),
        reviewer_roles=reviewer_roles,
        rejection_reasons=rejection_reasons,
        conditions=conditions or [],
        created_at=_now_iso(),
    )
