from __future__ import annotations

from dataclasses import dataclass

from ic_agent_flow.domain.objects.deployment_packaging_objects import (
    AuthorityClass,
    DeploymentProfile,
    GateResult,
    ObjectStatus,
    ProductManifest,
    RuntimeDistributionBundle,
    SitePolicyOverlay,
    SupportAuditBundle,
)
from ic_agent_flow.domain.objects.v15_customer_site_activation_objects import (
    DeploymentProfileBinding,
    SitePolicyOverlayBinding,
)
from ic_agent_flow.governance.deployment.packaging_gates import (
    GateContext,
    run_p2_semantic_integrity_gate,
    run_p3_profile_compliance_gate,
    run_p6_support_bundle_gate,
)


def _profile_ref_for(profile: DeploymentProfile) -> str:
    if profile.network_policy == "local-only":
        return "profile://airgap_local"
    if profile.network_policy == "customer-vpc":
        return "profile://customer_managed_vpc"
    if profile.network_policy == "managed-sandbox":
        return "profile://managed_sandbox"
    return f"profile://{profile.network_policy}"


@dataclass(frozen=True)
class CustomerPackageVerificationResult:
    allowed: bool
    blocking_reasons: list[str]
    gate_results: list[GateResult]
    profile_binding: DeploymentProfileBinding
    policy_binding: SitePolicyOverlayBinding


class TrustRootVerifier:
    def verify(self, bundle: RuntimeDistributionBundle, trust_root_ref: str) -> list[str]:
        if bundle.signature.trust_root_ref != trust_root_ref:
            return ["trust_root_unresolved"]
        return []


class DeploymentProfileBinder:
    def bind_profile(
        self,
        *,
        bundle: RuntimeDistributionBundle,
        profile: DeploymentProfile,
        context_ref: str,
    ) -> DeploymentProfileBinding:
        selected_profile_ref = _profile_ref_for(profile)
        blocking_reasons: list[str] = []
        if bundle.profile_ref != selected_profile_ref:
            blocking_reasons.append("bundle profile_ref does not match selected profile")
        return DeploymentProfileBinding(
            version="0.1",
            status=ObjectStatus.ACTIVE,
            authority_class=AuthorityClass.SYSTEM,
            producer="customer-package-verifier@0.1",
            digest=f"sha256:profile-binding:{bundle.digest}",
            signature=bundle.signature,
            site_id=context_ref,
            bundle_ref=str(bundle.id),
            profile_ref=selected_profile_ref,
            binding_status="BLOCKED" if blocking_reasons else "BOUND",
            forbidden_capabilities=list(profile.forbidden_capabilities),
            blocking_reasons=blocking_reasons,
        )


class ForbiddenCapabilityChecker:
    def check_profile(
        self,
        profile: DeploymentProfile,
        requested_adapters: list[str],
        context_ref: str,
    ) -> GateResult:
        gate_result, _, _ = run_p3_profile_compliance_gate(
            profile=profile,
            requested_adapters=requested_adapters,
            context=GateContext(subject_ref=context_ref, run_ref="v15-profile-compliance"),
        )
        return gate_result


class SitePolicyOverlayApplier:
    def apply_overlay(
        self,
        *,
        profile: DeploymentProfile,
        site_policy_overlay: SitePolicyOverlay | None,
    ) -> SitePolicyOverlayBinding:
        profile_ref = _profile_ref_for(profile)
        blocking_reasons: list[str] = []
        policy_overlay_ref = None
        if site_policy_overlay is not None:
            policy_overlay_ref = str(site_policy_overlay.id)
            if site_policy_overlay.base_profile_ref != profile_ref:
                blocking_reasons.append("base_profile_ref_mismatch")
        return SitePolicyOverlayBinding(
            version="0.1",
            status=ObjectStatus.ACTIVE,
            authority_class=AuthorityClass.SYSTEM,
            producer="customer-package-verifier@0.1",
            digest=f"sha256:policy-binding:{profile.digest}",
            signature=profile.signature,
            site_id="site-activation",
            profile_ref=profile_ref,
            policy_overlay_ref=policy_overlay_ref,
            binding_status="BLOCKED" if blocking_reasons else "BOUND",
            blocking_reasons=blocking_reasons,
        )


class RuntimeBundleVerifier:
    def __init__(self) -> None:
        self._trust_root_verifier = TrustRootVerifier()
        self._profile_binder = DeploymentProfileBinder()
        self._forbidden_checker = ForbiddenCapabilityChecker()
        self._overlay_applier = SitePolicyOverlayApplier()

    def verify_bundle(
        self,
        *,
        bundle: RuntimeDistributionBundle,
        product_manifest: ProductManifest,
        profile: DeploymentProfile,
        trust_root_ref: str,
        requested_adapters: list[str],
        site_policy_overlay: SitePolicyOverlay | None,
        support_bundle: SupportAuditBundle,
        context_ref: str,
    ) -> CustomerPackageVerificationResult:
        blocking_reasons: list[str] = []
        gate_results: list[GateResult] = []

        trust_root_blocks = self._trust_root_verifier.verify(bundle, trust_root_ref)
        blocking_reasons.extend(trust_root_blocks)

        semantic_gate, _, _ = run_p2_semantic_integrity_gate(
            bundle=bundle,
            profile_ref=_profile_ref_for(profile),
            product_manifest_ref=bundle.product_manifest_ref,
            context=GateContext(subject_ref=context_ref, run_ref="v15-semantic-integrity"),
        )
        if semantic_gate.blocking_reasons:
            blocking_reasons.extend(semantic_gate.blocking_reasons)
        gate_results.append(semantic_gate)

        profile_binding = self._profile_binder.bind_profile(
            bundle=bundle,
            profile=profile,
            context_ref=context_ref,
        )
        if profile_binding.blocking_reasons:
            blocking_reasons.extend(profile_binding.blocking_reasons)

        profile_gate = self._forbidden_checker.check_profile(profile, requested_adapters, context_ref)
        if profile_gate.blocking_reasons:
            normalized = [
                "forbidden_capability_enabled" if "forbidden entries" in reason else reason
                for reason in profile_gate.blocking_reasons
            ]
            blocking_reasons.extend(normalized)
        gate_results.append(profile_gate)

        policy_binding = self._overlay_applier.apply_overlay(
            profile=profile,
            site_policy_overlay=site_policy_overlay,
        )
        if policy_binding.blocking_reasons:
            blocking_reasons.extend(policy_binding.blocking_reasons)

        support_gate, _, _ = run_p6_support_bundle_gate(
            support_bundle=support_bundle,
            context=GateContext(subject_ref=context_ref, run_ref="v15-support-boundary"),
        )
        if support_gate.blocking_reasons:
            blocking_reasons.extend(support_gate.blocking_reasons)
        gate_results.append(support_gate)

        # Emit an explicit trust-root gate result so activation has a machine-readable record.
        gate_results.append(
            GateResult(
                gate_id="V15-TRUST",
                gate_name="trust_root_binding",
                verdict="FAIL" if trust_root_blocks else "PASS",
                blocking_reasons=trust_root_blocks,
                evidence_refs=[trust_root_ref],
                subject_ref=context_ref,
                run_ref="v15-trust-root",
            )
        )

        deduped = list(dict.fromkeys(blocking_reasons))
        return CustomerPackageVerificationResult(
            allowed=not deduped,
            blocking_reasons=deduped,
            gate_results=gate_results,
            profile_binding=profile_binding,
            policy_binding=policy_binding,
        )
