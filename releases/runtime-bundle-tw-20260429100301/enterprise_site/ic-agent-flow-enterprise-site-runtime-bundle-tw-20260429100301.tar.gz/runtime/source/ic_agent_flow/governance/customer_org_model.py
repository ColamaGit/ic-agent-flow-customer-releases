from __future__ import annotations

from datetime import datetime, timezone
from typing import Literal

from pydantic import BaseModel, Field


CUSTOMER_OPERATING_MODES = (
    "solo_eval",
    "team_project",
    "enterprise_site",
)

MINIMUM_MODE_ROLES = {
    "solo_eval": {"evaluator", "local_operator"},
    "team_project": {"operator", "reviewer", "approver", "auditor"},
    "enterprise_site": {"security_owner", "runtime_admin", "release_board", "auditor", "support_owner"},
}

AGENT_SERVICE_ACCOUNT_ALLOWED_ROLES = (
    "evaluator",
    "local_operator",
    "support_exporter",
)


class CustomerSiteManifest(BaseModel):
    site_id: str
    site_name: str
    site_owner_ref: str
    operating_mode: Literal["solo_eval", "team_project", "enterprise_site"]


class OrgUnitRecord(BaseModel):
    org_unit_id: str
    site_id: str
    unit_name: str
    parent_unit_ref: str | None = None


class TeamRecord(BaseModel):
    team_id: str
    site_id: str
    team_name: str
    org_unit_ref: str | None = None


class TeamMembershipRecord(BaseModel):
    team_id: str
    member_ref: str
    role: str


class CustomerRoleGrantRecord(BaseModel):
    grant_id: str
    subject_ref: str
    role: str
    scope_ref: str
    granted_by: str
    granted_at: str
    expires_at: str | None = None
    revoked: bool = False


class CustomerAuthorityMatrix(BaseModel):
    mode: Literal["solo_eval", "team_project", "enterprise_site"]
    required_roles: list[str] = Field(default_factory=list)
    activation_decision_roles: list[str] = Field(default_factory=list)
    support_export_roles: list[str] = Field(default_factory=list)


class ApprovalQuorumRecord(BaseModel):
    quorum_id: str
    scope_ref: str
    required_roles: list[str]
    minimum_approvals: int


class DelegationRecord(BaseModel):
    delegation_id: str
    delegated_from: str
    delegated_to: str
    delegated_role: str
    scope_ref: str
    delegated_at: str
    expires_at: str


class AgentServiceAccountRecord(BaseModel):
    account_id: str
    granted_roles: list[str]
    scope_ref: str | None = None


class SupportAccessRecord(BaseModel):
    access_id: str
    subject_ref: str
    support_scope_ref: str
    granted_role: str


class CustomerOrgManifest(BaseModel):
    org_id: str
    org_name: str
    operating_mode: Literal["solo_eval", "team_project", "enterprise_site"]
    sites: list[CustomerSiteManifest] = Field(default_factory=list)
    teams: list[TeamRecord] = Field(default_factory=list)
    memberships: list[TeamMembershipRecord] = Field(default_factory=list)
    role_grants: list[CustomerRoleGrantRecord] = Field(default_factory=list)
    authority_matrix: CustomerAuthorityMatrix


def _active_grant(grant: CustomerRoleGrantRecord) -> bool:
    if grant.revoked:
        return False
    if not grant.expires_at:
        return True
    return datetime.fromisoformat(grant.expires_at) > datetime.now(timezone.utc)


def validate_customer_org_manifest(manifest: CustomerOrgManifest) -> list[str]:
    issues: list[str] = []
    required = set(manifest.authority_matrix.required_roles)
    present = {membership.role for membership in manifest.memberships}
    missing = sorted(required - present)
    if missing:
        issues.append(f"missing_required_roles:{missing}")

    if not manifest.sites:
        issues.append("missing_customer_site")
    for site in manifest.sites:
        if not site.site_owner_ref.strip():
            issues.append(f"missing_customer_site_owner:{site.site_id}")
    return issues


def validate_role_action(
    *,
    actor_ref: str,
    actor_role: str,
    action: str,
    role_grants: list[CustomerRoleGrantRecord],
    allowed_roles: list[str],
) -> None:
    if actor_role not in allowed_roles:
        raise ValueError("role_mismatch_blocks_authority_action")

    for grant in role_grants:
        if grant.subject_ref == actor_ref and grant.role == actor_role:
            if not _active_grant(grant):
                raise ValueError("expired_role_grant_blocks_authority_action")
            return
    raise ValueError(f"missing_role_grant_for_action:{action}")


def validate_delegation_record(record: DelegationRecord) -> None:
    if not record.scope_ref.strip() or not record.expires_at.strip():
        raise ValueError("delegation_requires_expiry_and_scope")


def validate_agent_service_account(*, account_id: str, granted_roles: list[str]) -> None:
    excess = sorted(set(granted_roles) - set(AGENT_SERVICE_ACCOUNT_ALLOWED_ROLES))
    if excess:
        raise ValueError("agent_service_account_has_excess_authority")


def validate_activation_roles(manifest: CustomerOrgManifest, *, site_id: str) -> list[str]:
    issues: list[str] = []
    site = next((item for item in manifest.sites if item.site_id == site_id), None)
    if site is None:
        issues.append("missing_customer_site")
        return issues
    if not site.site_owner_ref.strip():
        issues.append("missing_customer_site_owner")
    required = MINIMUM_MODE_ROLES[manifest.operating_mode]
    present = {membership.role for membership in manifest.memberships}
    missing = sorted(required - present)
    if missing:
        issues.append(f"missing_activation_roles:{missing}")
    return issues
