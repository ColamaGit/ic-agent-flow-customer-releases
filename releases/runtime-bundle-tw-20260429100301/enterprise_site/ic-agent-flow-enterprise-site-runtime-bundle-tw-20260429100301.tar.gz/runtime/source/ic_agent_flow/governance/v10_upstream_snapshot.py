from __future__ import annotations

import hashlib
import json
import os
import shutil
from enum import Enum
from pathlib import Path
from typing import Dict, Optional

from pydantic import BaseModel, Field

from ic_agent_flow.domain.utils.time import get_tw_now


class KickoffMode(str, Enum):
    SPEC_FIRST = "spec_first"
    RTL_COMPAT = "rtl_compat"


class UpstreamGateState(str, Enum):
    NO_UPSTREAM_OBJECTS = "NO_UPSTREAM_OBJECTS"
    PROVISIONAL_SPEC_ONLY = "PROVISIONAL_SPEC_ONLY"
    PROVISIONAL_GRAPH_PRESENT = "PROVISIONAL_GRAPH_PRESENT"
    VALIDATED_NOT_FROZEN = "VALIDATED_NOT_FROZEN"
    FREEZE_ELIGIBLE = "FREEZE_ELIGIBLE"
    FROZEN_PLAN_READY = "FROZEN_PLAN_READY"


class UpstreamAdmissionManifest(BaseModel):
    chip_id: str
    kickoff_mode: KickoffMode
    upstream_gate_state: UpstreamGateState
    snapshot_refs: Dict[str, str]
    canonical_refs: Dict[str, Optional[str]]
    snapshot_digests: Dict[str, str]
    freeze_ref: Optional[str] = None
    generation_plan_ref: Optional[str] = None
    created_at: str = Field(default_factory=lambda: get_tw_now().isoformat())


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def _copy_dir_if_exists(src: Path, dest: Path) -> None:
    dest.mkdir(parents=True, exist_ok=True)
    if src.is_dir():
        shutil.copytree(src, dest, dirs_exist_ok=True)


def _copy_constraints_snapshot(rtl_src: Path, design_root: Path) -> None:
    constraints_dest = design_root / "constraints"
    candidate_dirs = []
    if rtl_src.is_dir():
        candidate_dirs.append(rtl_src / "constraints")
        candidate_dirs.append(rtl_src.parent / "constraints")
    elif rtl_src.is_file():
        candidate_dirs.append(rtl_src.parent / "constraints")
    for candidate in candidate_dirs:
        if not candidate.is_dir():
            continue
        copied = False
        constraints_dest.mkdir(parents=True, exist_ok=True)
        for sdc in sorted(candidate.glob("*.sdc")):
            shutil.copy2(sdc, constraints_dest / sdc.name)
            copied = True
        if copied:
            return


def _materialize_rtl_read_compat_alias(design_rtl_snapshot_dir: Path, rtl_compat_dir: Path) -> None:
    # Keep `inputs/rtl` as read-compat alias while converging canonical sink to `inputs/design/rtl`.
    if rtl_compat_dir.is_symlink() or rtl_compat_dir.exists():
        if rtl_compat_dir.is_symlink() or rtl_compat_dir.is_file():
            rtl_compat_dir.unlink()
        else:
            shutil.rmtree(rtl_compat_dir)

    try:
        relative_target = os.path.relpath(design_rtl_snapshot_dir, rtl_compat_dir.parent)
        rtl_compat_dir.symlink_to(relative_target, target_is_directory=True)
    except OSError:
        # Fallback for environments where symlink is not permitted.
        shutil.copytree(design_rtl_snapshot_dir, rtl_compat_dir, dirs_exist_ok=True)


def _relative_ref(path: Path, base: Path) -> Optional[str]:
    if not path.exists():
        return None
    return path.relative_to(base).as_posix()


def _digest_tree(root: Path, run_dir: Path) -> Dict[str, str]:
    if not root.exists():
        return {}
    return {
        path.relative_to(run_dir).as_posix(): _sha256_file(path)
        for path in sorted(root.rglob("*"))
        if path.is_file()
    }


def _derive_upstream_gate_state(chip_dir: Path) -> UpstreamGateState:
    specs_dir = chip_dir / "specs"
    architecture_dir = chip_dir / "architecture"
    has_spec = any(specs_dir.glob("*.json")) if specs_dir.exists() else False
    has_graph = (architecture_dir / "architecture_graph.json").exists()
    has_validation = (architecture_dir / "graph_validation_result.json").exists()
    has_freeze = (architecture_dir / "graph_freeze_record.json").exists()
    has_plan = (architecture_dir / "graph_to_generation_plan.json").exists()

    if has_freeze and has_plan:
        return UpstreamGateState.FROZEN_PLAN_READY
    if has_validation:
        return UpstreamGateState.VALIDATED_NOT_FROZEN
    if has_graph:
        return UpstreamGateState.PROVISIONAL_GRAPH_PRESENT
    if has_spec:
        return UpstreamGateState.PROVISIONAL_SPEC_ONLY
    return UpstreamGateState.NO_UPSTREAM_OBJECTS


def materialize_v10_upstream_input_snapshot(
    *,
    chip_dir: Path | str,
    run_dir: Path | str,
    rtl_src: Path | str,
    kickoff_mode: KickoffMode,
) -> UpstreamAdmissionManifest:
    chip_dir = Path(chip_dir)
    run_dir = Path(run_dir)
    rtl_src = Path(rtl_src)

    inputs_dir = run_dir / "inputs"
    spec_snapshot_dir = inputs_dir / "spec"
    graph_snapshot_dir = inputs_dir / "graph"
    design_rtl_snapshot_dir = inputs_dir / "design" / "rtl"
    design_snapshot_dir = inputs_dir / "design"
    rtl_compat_dir = inputs_dir / "rtl"

    _copy_dir_if_exists(chip_dir / "specs", spec_snapshot_dir)
    _copy_dir_if_exists(chip_dir / "architecture", graph_snapshot_dir)
    _copy_dir_if_exists(rtl_src, design_rtl_snapshot_dir)
    _copy_constraints_snapshot(rtl_src, design_snapshot_dir)
    _materialize_rtl_read_compat_alias(design_rtl_snapshot_dir, rtl_compat_dir)

    graph_freeze_record = chip_dir / "architecture" / "graph_freeze_record.json"
    graph_to_generation_plan = chip_dir / "architecture" / "graph_to_generation_plan.json"
    canonical_refs = {
        "specs": _relative_ref(chip_dir / "specs", chip_dir.parent.parent),
        "intake": _relative_ref(chip_dir / "specs" / "intake", chip_dir.parent.parent),
        "architecture": _relative_ref(chip_dir / "architecture", chip_dir.parent.parent),
        "graph_freeze_record": _relative_ref(graph_freeze_record, chip_dir.parent.parent),
        "graph_to_generation_plan": _relative_ref(graph_to_generation_plan, chip_dir.parent.parent),
    }

    manifest = UpstreamAdmissionManifest(
        chip_id=chip_dir.name,
        kickoff_mode=kickoff_mode,
        upstream_gate_state=_derive_upstream_gate_state(chip_dir),
        snapshot_refs={
            "spec": "inputs/spec",
            "intake": "inputs/spec/intake",
            "graph": "inputs/graph",
            "design": "inputs/design",
            "rtl_read_compat": "inputs/rtl",
        },
        canonical_refs=canonical_refs,
        snapshot_digests=_digest_tree(inputs_dir, run_dir),
        freeze_ref=canonical_refs["graph_freeze_record"],
        generation_plan_ref=canonical_refs["graph_to_generation_plan"],
    )

    manifest_path = run_dir / "subject_binding" / "upstream_admission_manifest.json"
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(
        json.dumps(manifest.model_dump(mode="json"), indent=2),
        encoding="utf-8",
    )
    return manifest
