from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone

from ic_agent_flow.domain.objects.v14_qa_trust_layer_objects import (
    ClaimSource,
    EvidenceQualityReport,
    QAAdjudicationRecord,
    QAAssessmentRun,
    QARef,
    QATargetScope,
    ScenarioValidationReport,
)
from ic_agent_flow.governance.v14_claim_scope_assessor import ClaimInput, assess_claim_scope
from ic_agent_flow.governance.v14_evidence_quality_assessor import assess_evidence_quality
from ic_agent_flow.governance.v14_qa_adjudication import adjudicate_qa_reports
from ic_agent_flow.governance.v14_scenario_validation_assessor import (
    assess_scenario_validation,
)


@dataclass(frozen=True)
class V15QAGateResult:
    qa_run: QAAssessmentRun
    evidence_report: EvidenceQualityReport
    scenario_report: ScenarioValidationReport
    claim_report_id: str
    adjudication: QAAdjudicationRecord


def build_v15_qa_run(
    *,
    run_id: str,
    input_refs: list[QARef],
    workspace_id: str = "customer-site",
    site_id: str = "customer-site",
) -> QAAssessmentRun:
    now = datetime.now(timezone.utc).isoformat()
    return QAAssessmentRun(
        id=run_id,
        target_scope=QATargetScope(
            workspace_id=workspace_id,
            chip_id=site_id,
            prd_scope="PRD_v1.5_customer_site_bootstrap",
        ),
        started_at=now,
        completed_at=now,
        producer="v15-customer-site-qa-gate@0.1",
        input_refs=input_refs,
    )


def evaluate_v15_customer_ready_claim(
    *,
    run_id: str,
    evidence_refs: list[QARef],
    raw_artifact_status: str = "PRESENT",
    normalized_mapping_status: str = "MATCHED",
    lineage_status: str = "COMPLETE",
    integrity_status: str = "PASS",
    happy_path_status: str = "PASS",
    negative_path_status: str = "PASS",
    reentry_status: str = "PASS",
    fail_closed_status: str = "PASS",
    claims: list[ClaimInput] | None = None,
) -> V15QAGateResult:
    run = build_v15_qa_run(run_id=run_id, input_refs=evidence_refs)

    evidence_report = assess_evidence_quality(
        run=run,
        report_id=f"{run_id}-evidence",
        artifact_refs=evidence_refs,
        raw_artifact_status=raw_artifact_status,
        normalized_mapping_status=normalized_mapping_status,
        lineage_status=lineage_status,
        integrity_status=integrity_status,
    )
    scenario_report = assess_scenario_validation(
        run=run,
        report_id=f"{run_id}-scenario",
        scenario_id="v15-closeout-scenario-pack",
        scenario_name="PRD v1.5 closeout scenario pack",
        happy_path_status=happy_path_status,
        negative_path_status=negative_path_status,
        reentry_status=reentry_status,
        fail_closed_status=fail_closed_status,
        evidence_refs=evidence_refs,
    )
    claim_assessment = assess_claim_scope(
        run=run,
        assessment_id=f"{run_id}-claim",
        claim_source=ClaimSource(
            source_type="closeout_report",
            uri="workspace/docs/governance/closeout/v1.5/v1.5_closeout_report.md",
        ),
        claims=claims
        or [
            ClaimInput(
                claim_id="v15-customer-ready",
                claim_text="PRD v1.5 customer-ready baseline is supported by activation, operations, support, upgrade, update adoption, QA, and fail-closed closeout evidence.",
                prd_boundary="PRD_v1.5_customer_site_bootstrap",
                supporting_evidence_refs=evidence_refs,
            )
        ],
    )

    adjudication = adjudicate_qa_reports(
        adjudication_id=f"{run_id}-adjudication",
        qa_run_ref=run.id,
        evidence_report=evidence_report,
        scenario_report=scenario_report,
        claim_assessment=claim_assessment,
        created_at=datetime.now(timezone.utc).isoformat(),
        adjudicator_role="qa_system",
        adjudicator_id="v14-qa-trust-layer-for-v15",
    )

    return V15QAGateResult(
        qa_run=run,
        evidence_report=evidence_report,
        scenario_report=scenario_report,
        claim_report_id=claim_assessment.id,
        adjudication=adjudication,
    )
