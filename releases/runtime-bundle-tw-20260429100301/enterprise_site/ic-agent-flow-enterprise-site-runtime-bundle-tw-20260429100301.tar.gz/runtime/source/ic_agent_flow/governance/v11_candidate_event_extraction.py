from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Iterable, List

from ic_agent_flow.domain.objects.v11_knowledge_flywheel_objects import (
    KnowledgeAsset,
    KnowledgeAssetLifecycleState,
)


SUPPORTED_PHASE2_EVENT_TYPES = (
    "ambiguity_clarification",
    "verification_failure",
    "decision_rationale",
)


def _as_list_of_strings(value: Any) -> List[str]:
    if not isinstance(value, list):
        return []
    return [str(item) for item in value]


def _build_asset(project_ref: str, event: dict[str, Any]) -> KnowledgeAsset:
    event_id = str(event.get("event_id", "")).strip()
    return KnowledgeAsset(
        asset_id=f"asset://{project_ref}/{event_id}",
        lifecycle_state=KnowledgeAssetLifecycleState.NORMALIZED_PROJECT_ASSET,
        source_event_type=str(event.get("event_type", "")).strip(),
        project_ref=project_ref,
        scope_level="project_private",
        summary=str(event.get("summary", "")).strip(),
        source_event_refs=_as_list_of_strings(event.get("source_event_refs")),
        evidence_refs=_as_list_of_strings(event.get("evidence_refs")),
        tags=_as_list_of_strings(event.get("tags")),
    )


def extract_candidate_assets(project_ref: str, events: Iterable[dict[str, Any]]) -> List[KnowledgeAsset]:
    candidates: List[KnowledgeAsset] = []
    for event in events:
        event_type = str(event.get("event_type", "")).strip()
        event_id = str(event.get("event_id", "")).strip()
        summary = str(event.get("summary", "")).strip()
        if event_type not in SUPPORTED_PHASE2_EVENT_TYPES:
            continue
        if not event_id or not summary:
            continue
        candidates.append(_build_asset(project_ref=project_ref, event=event))
    return candidates


def write_candidate_review_queue(
    project_ref: str,
    events: Iterable[dict[str, Any]],
    output_path: str | Path,
) -> Path:
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    candidates = extract_candidate_assets(project_ref=project_ref, events=events)
    payload = {
        "schema_version": "v11-candidate-review-queue.v0.1",
        "project_ref": project_ref,
        "candidate_count": len(candidates),
        "candidates": [c.model_dump() for c in candidates],
    }
    out.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return out

